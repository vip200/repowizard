# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
global teleupdate #line:32
teleupdate =False #line:33
ADDON_ID =uservar .ADDON_ID #line:34
ADDONTITLE =uservar .ADDONTITLE #line:35
ADDON =wiz .addonId (ADDON_ID )#line:36
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:37
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:38
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:39
DIALOG =xbmcgui .Dialog ()#line:40
DP =xbmcgui .DialogProgress ()#line:41
DP2 =xbmcgui .DialogProgressBG ()#line:42
HOME =xbmc .translatePath ('special://home/')#line:43
PROFILE =xbmc .translatePath ('special://profile/')#line:44
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:45
ADDONS =os .path .join (HOME ,'addons')#line:46
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:47
USERDATA =os .path .join (HOME ,'userdata')#line:48
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:49
PACKAGES =os .path .join (ADDONS ,'packages')#line:50
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:51
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:52
ICON =os .path .join (ADDONPATH ,'icon.png')#line:53
ART =os .path .join (ADDONPATH ,'resources','art')#line:54
SKIN =xbmc .getSkinDir ()#line:55
BUILDNAME =wiz .getS ('buildname')#line:56
DEFAULTSKIN =wiz .getS ('defaultskin')#line:57
DEFAULTNAME =wiz .getS ('defaultskinname')#line:58
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:59
BUILDVERSION =wiz .getS ('buildversion')#line:60
BUILDLATEST =wiz .getS ('latestversion')#line:61
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:62
DISABLEUPDATE =wiz .getS ('disableupdate')#line:63
AUTOCLEANUP =wiz .getS ('autoclean')#line:64
AUTOCACHE =wiz .getS ('clearcache')#line:65
AUTOPACKAGES =wiz .getS ('clearpackages')#line:66
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:67
AUTOFEQ =wiz .getS ('autocleanfeq')#line:68
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:69
TRAKTSAVE =wiz .getS ('traktlastsave')#line:70
REALSAVE =wiz .getS ('debridlastsave')#line:71
LOGINSAVE =wiz .getS ('loginlastsave')#line:72
INSTALLMETHOD =wiz .getS ('installmethod')#line:73
KEEPTRAKT =wiz .getS ('keeptrakt')#line:74
KEEPREAL =wiz .getS ('keepdebrid')#line:75
KEEPLOGIN =wiz .getS ('keeplogin')#line:76
INSTALLED =wiz .getS ('installed')#line:77
EXTRACT =wiz .getS ('extract')#line:78
EXTERROR =wiz .getS ('errors')#line:79
NOTIFY =wiz .getS ('notify')#line:80
NOTEDISMISS =wiz .getS ('notedismiss')#line:81
NOTEID =wiz .getS ('noteid')#line:82
NOTIFY2 =wiz .getS ('notify2')#line:83
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:84
NOTEID2 =wiz .getS ('noteid2')#line:85
NOTIFY3 =wiz .getS ('notify3')#line:86
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:87
NOTEID3 =wiz .getS ('noteid3')#line:88
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:89
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:90
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:91
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:92
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:93
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:94
TODAY =date .today ()#line:95
TOMORROW =TODAY +timedelta (days =1 )#line:96
TWODAYS =TODAY +timedelta (days =2 )#line:97
THREEDAYS =TODAY +timedelta (days =3 )#line:98
ONEWEEK =TODAY +timedelta (days =7 )#line:99
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:100
EXCLUDES =uservar .EXCLUDES #line:101
SPEEDFILE =speedtest .SPEEDFILE #line:102
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:103
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:104
NOTIFICATION =uservar .NOTIFICATION #line:105
NOTIFICATION2 =uservar .NOTIFICATION2 #line:106
NOTIFICATION3 =uservar .NOTIFICATION3 #line:107
ENABLE =uservar .ENABLE #line:108
UNAME =speedtest .UNAME #line:109
HEADERMESSAGE =uservar .HEADERMESSAGE #line:110
AUTOUPDATE =uservar .AUTOUPDATE #line:111
WIZARDFILE =uservar .WIZARDFILE #line:112
AUTOINSTALL =uservar .AUTOINSTALL #line:113
REPOID =uservar .REPOID #line:114
REPOADDONXML =uservar .REPOADDONXML #line:115
REPOZIPURL =uservar .REPOZIPURL #line:116
REPOID18 =uservar .REPOID18 #line:117
REPOADDONXML18 =uservar .REPOADDONXML18 #line:118
REPOZIPURL18 =uservar .REPOZIPURL18 #line:119
REQUESTSID =uservar .REQUESTSID #line:121
REQUESTSXML =uservar .REQUESTSXML #line:122
REQUESTSURL =uservar .REQUESTSURL #line:123
COLOR1 =uservar .COLOR1 #line:127
COLOR2 =uservar .COLOR2 #line:128
TMDB_NEW_API =uservar .TMDB_NEW_API #line:129
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:130
FAILED =False #line:131
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:132
AddonID ='plugin.program.Anonymous'#line:134
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:135
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:136
telecach =xbmc .translatePath ('special://home/userdata/addon_data/plugin.video.telemedia/logo')#line:137
dialog =xbmcgui .Dialog ()#line:138
setting =xbmcaddon .Addon ().getSetting #line:139
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:140
notify_mode =setting ('notify_mode')#line:141
auto_clean =setting ('startup.cache')#line:142
filesize_thumb =int (setting ('filesizethumb_alert'))#line:144
filesize_tele =int (setting ('filesizetele_alert'))#line:145
total_size2 =0 #line:148
total_size =0 #line:149
count =0 #line:150
def infobuild ():#line:161
	OOO0O0OO0O00OOO00 =wiz .workingURL (NOTIFICATION )#line:162
	if OOO0O0OO0O00OOO00 ==True :#line:163
		try :#line:164
			O0O000OO0O00OOOOO ,O00OOOO00O00OOO0O =wiz .splitNotify (NOTIFICATION )#line:165
			if O0O000OO0O00OOOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:166
			if STARTP2 ()=='ok':#line:167
				notify .updateinfo (O00OOOO00O00OOO0O ,True )#line:168
		except Exception as O0O000OO00OO0O0O0 :#line:169
			wiz .log ("Error on Notifications Window: %s"%str (O0O000OO00OO0O0O0 ),xbmc .LOGERROR )#line:170
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:171
def disply_hwr ():#line:172
   try :#line:173
    OO0O00OOOOO0OOOOO =tmdb_list (TMDB_NEW_API )#line:174
    O0000O0OO00000O00 =str ((getHwAddr ('eth0'))*OO0O00OOOOO0OOOOO )#line:175
    O0O0O0OOO0000O0OO =(O0000O0OO00000O00 [1 ]+O0000O0OO00000O00 [2 ]+O0000O0OO00000O00 [5 ]+O0000O0OO00000O00 [7 ])#line:182
    OO0OOOO00O0000OOO =(ADDON .getSetting ("action"))#line:183
    wiz .setS ('action',str (O0O0O0OOO0000O0OO ))#line:185
   except :pass #line:186
def getHwAddr (O0O000O0O0OO0OO0O ):#line:187
   import subprocess ,time #line:188
   O0O0O00OO0O000000 ='windows'#line:189
   if xbmc .getCondVisibility ('system.platform.android'):#line:190
       O0O0O00OO0O000000 ='android'#line:191
   if xbmc .getCondVisibility ('system.platform.android'):#line:192
     OO00O0O0000O000O0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:193
     O0O0O00OO0O0O00O0 =re .compile ('link/ether (.+?) brd').findall (str (OO00O0O0000O000O0 ))#line:195
     O0O00O0000O00OO00 =0 #line:196
     for O00OO00OOOO000O0O in O0O0O00OO0O0O00O0 :#line:197
      if O0O0O00OO0O0O00O0 !='00:00:00:00:00:00':#line:198
          OO0O00O0OO0O0OO00 =O00OO00OOOO000O0O #line:199
          O0O00O0000O00OO00 =O0O00O0000O00OO00 +int (OO0O00O0OO0O0OO00 .replace (':',''),16 )#line:200
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:202
       O0O000O000O00000O =0 #line:203
       O0O00O0000O00OO00 =0 #line:204
       O0O00OO000O000O00 =[]#line:205
       O0O0O00OO00OOOO00 =os .popen ("getmac").read ()#line:206
       O0O0O00OO00OOOO00 =O0O0O00OO00OOOO00 .split ("\n")#line:207
       for O0OO000O0OO0OO0OO in O0O0O00OO00OOOO00 :#line:209
            O0O0O000O0O0O00O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OO000O0OO0OO0OO ,re .I )#line:210
            if O0O0O000O0O0O00O0 :#line:211
                O0O0O00OO0O0O00O0 =O0O0O000O0O0O00O0 .group ().replace ('-',':')#line:212
                O0O00OO000O000O00 .append (O0O0O00OO0O0O00O0 )#line:213
                O0O00O0000O00OO00 =O0O00O0000O00OO00 +int (O0O0O00OO0O0O00O0 .replace (':',''),16 )#line:216
   else :#line:218
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:219
   try :#line:236
    return O0O00O0000O00OO00 #line:237
   except :pass #line:238
def decode (O00O00OO0O00OOO00 ,O0OOOO00OOOO00O0O ):#line:239
    import base64 #line:240
    OO000O0000O0O00O0 =[]#line:241
    if (len (O00O00OO0O00OOO00 ))!=4 :#line:243
     return 10 #line:244
    O0OOOO00OOOO00O0O =base64 .urlsafe_b64decode (O0OOOO00OOOO00O0O )#line:245
    for OOOO0OO0O00OO00O0 in range (len (O0OOOO00OOOO00O0O )):#line:247
        O0OOOO0OO00OO0O0O =O00O00OO0O00OOO00 [OOOO0OO0O00OO00O0 %len (O00O00OO0O00OOO00 )]#line:248
        OO0O0O000O0O00O00 =chr ((256 +ord (O0OOOO00OOOO00O0O [OOOO0OO0O00OO00O0 ])-ord (O0OOOO0OO00OO0O0O ))%256 )#line:249
        OO000O0000O0O00O0 .append (OO0O0O000O0O00O00 )#line:250
    return "".join (OO000O0000O0O00O0 )#line:251
def tmdb_list (O0O0OOOOO0O0O0O0O ):#line:252
    OO00O00O0000O00O0 =decode ("7643",O0O0OOOOO0O0O0O0O )#line:255
    return int (OO00O00O0000O00O0 )#line:258
def u_list (O0O0O0OO0OO0OOO0O ):#line:259
    from math import sqrt #line:261
    O000OOO0000OO0O00 =tmdb_list (TMDB_NEW_API )#line:262
    OO0O0000OO0000OO0 =str ((getHwAddr ('eth0'))*O000OOO0000OO0O00 )#line:264
    O0O00000O0O0O0000 =int (OO0O0000OO0000OO0 [1 ]+OO0O0000OO0000OO0 [2 ]+OO0O0000OO0000OO0 [5 ]+OO0O0000OO0000OO0 [7 ])#line:265
    O0O0O00OO000O0O0O =(ADDON .getSetting ("pass"))#line:267
    O00OOOO0O00OO0O00 =(str (round (sqrt ((O0O00000O0O0O0000 *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:272
    if '.'in O00OOOO0O00OO0O00 :#line:273
     O00OOOO0O00OO0O00 =(str (round (sqrt ((O0O00000O0O0O0000 *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:274
    if O0O0O00OO000O0O0O ==O00OOOO0O00OO0O00 :#line:275
      O0O0OO0000OO0O00O =O0O0O0OO0OO0OOO0O #line:277
    else :#line:279
       if STARTP ()and STARTP2 ()=='ok':#line:280
         return O0O0O0OO0OO0OOO0O #line:282
       O0O0OO0000OO0O00O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:283
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:284
       sys .exit ()#line:285
    return O0O0OO0000OO0O00O #line:286
try :#line:287
   disply_hwr ()#line:288
except :#line:289
   pass #line:290
def dis_or_enable_addon (OOO0OO00O0O000O0O ,OOOOO00OOO0O0O00O ,enable ="true"):#line:291
    import json #line:292
    OOOO0OOOOO0O00OOO ='"%s"'%OOO0OO00O0O000O0O #line:293
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0OO00O0O000O0O )and enable =="true":#line:294
        logging .warning ('already Enabled')#line:295
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0OO00O0O000O0O )#line:296
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0OO00O0O000O0O )and enable =="false":#line:297
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0OO00O0O000O0O )#line:298
    else :#line:299
        OO0OOO0OOOOO0000O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOOO0OOOOO0O00OOO ,enable )#line:300
        O0O00O000OOO0O0O0 =xbmc .executeJSONRPC (OO0OOO0OOOOO0000O )#line:301
        O00000O00OOOOOO00 =json .loads (O0O00O000OOO0O0O0 )#line:302
        if enable =="true":#line:303
            xbmc .log ("### Enabled %s, response = %s"%(OOO0OO00O0O000O0O ,O00000O00OOOOOO00 ))#line:304
        else :#line:305
            xbmc .log ("### Disabled %s, response = %s"%(OOO0OO00O0O000O0O ,O00000O00OOOOOO00 ))#line:306
    if OOOOO00OOO0O0O00O =='auto':#line:307
     return True #line:308
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:309
def update_Votes ():#line:310
   try :#line:311
        import requests #line:312
        OO0OO00O000O00000 ='18773068'#line:313
        O000OOO000O0OO000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0OO00O000O00000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:325
        O0O00OOOOO0OO0OOO ='145273321'#line:327
        O00OO00OO0OO000OO ={'options':O0O00OOOOO0OO0OOO }#line:333
        OO0O0O000O0OOOOO0 =requests .post ('https://www.strawpoll.me/'+OO0OO00O000O00000 ,headers =O000OOO000O0OO000 ,data =O00OO00OO0OO000OO )#line:335
   except :pass #line:336
def display_Votes ():#line:337
    try :#line:338
        O0O00000O0OO0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:339
        O0OO0O00O00OO00O0 =open (O0O00000O0OO0000O ,'r')#line:341
        O0OO0O0OOOO0OOOOO =O0OO0O00O00OO00O0 .read ()#line:342
        O0OO0O00O00OO00O0 .close ()#line:343
        OO0O0OOO0OO0OOO00 ='<setting id="HomeS" type="string">(.+?)</setting>'#line:344
        OO00000000OO0O0OO =re .compile (OO0O0OOO0OO0OOO00 ).findall (O0OO0O0OOOO0OOOOO )[0 ]#line:346
        import requests #line:352
        OO00O000O000O0O0O ='18782966'#line:353
        OOOOOOO0OOO0000OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO00O000O000O0O0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:365
        OO0O0OOO0OOOO0000 ='145313053'#line:367
        O0OO0O0OOOO000O00 ='145313054'#line:368
        O000O0OO0O0000O0O ='145313057'#line:369
        O00O00000O00O00O0 ='145313058'#line:370
        O0OOOO0OO0OOO0O0O ='145313055'#line:371
        O0O0O000OOOO000O0 ='145313060'#line:372
        OOO0OO0OOOOO0000O ='145313056'#line:373
        O0O0O0O000OOOOO0O ='145313059'#line:374
        if OO00000000OO0O0OO =='emin':#line:377
           OO000OO00OOOOOO0O =OO0O0OOO0OOOO0000 #line:378
        if OO00000000OO0O0OO =='nox':#line:379
           OO000OO00OOOOOO0O =O0OO0O0OOOO000O00 #line:380
        if OO00000000OO0O0OO =='noxtitan':#line:381
           OO000OO00OOOOOO0O =O0OO0O0OOOO000O00 #line:382
        if OO00000000OO0O0OO =='titan':#line:383
           OO000OO00OOOOOO0O =O000O0OO0O0000O0O #line:384
        if OO00000000OO0O0OO =='pheno':#line:385
           OO000OO00OOOOOO0O =O00O00000O00O00O0 #line:386
        if OO00000000OO0O0OO =='netflix':#line:387
           OO000OO00OOOOOO0O =O0OOOO0OO0OOO0O0O #line:388
        if OO00000000OO0O0OO =='nebula':#line:389
           OO000OO00OOOOOO0O =O0O0O000OOOO000O0 #line:390
        if OO00000000OO0O0OO =='pellucid':#line:391
           OO000OO00OOOOOO0O =OOO0OO0OOOOO0000O #line:392
        if OO00000000OO0O0OO =='pellucid2':#line:393
           OO000OO00OOOOOO0O =O0O0O0O000OOOOO0O #line:394
        OOOOO000OO00000OO ={'options':OO000OO00OOOOOO0O }#line:400
        OO00OO00OO0OOO000 =requests .post ('https://www.strawpoll.me/'+OO00O000O000O0O0O ,headers =OOOOOOO0OOO0000OO ,data =OOOOO000OO00000OO )#line:402
    except :pass #line:403
def resetkodi ():#line:404
		if xbmc .getCondVisibility ('system.platform.windows'):#line:405
			O000O0OO00000O000 =xbmcgui .DialogProgress ()#line:406
			O000O0OO00000O000 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:409
			O000O0OO00000O000 .update (0 )#line:410
			for O0OO0000000000OO0 in range (5 ,-1 ,-1 ):#line:411
				time .sleep (1 )#line:412
				O000O0OO00000O000 .update (int ((5 -O0OO0000000000OO0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OO0000000000OO0 ),'')#line:413
				if O000O0OO00000O000 .iscanceled ():#line:414
					from resources .libs import win #line:415
					return None ,None #line:416
			from resources .libs import win #line:417
		else :#line:418
			O000O0OO00000O000 =xbmcgui .DialogProgress ()#line:419
			O000O0OO00000O000 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:422
			O000O0OO00000O000 .update (0 )#line:423
			for O0OO0000000000OO0 in range (5 ,-1 ,-1 ):#line:424
				time .sleep (1 )#line:425
				O000O0OO00000O000 .update (int ((5 -O0OO0000000000OO0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OO0000000000OO0 ),'')#line:426
				if O000O0OO00000O000 .iscanceled ():#line:427
					os ._exit (1 )#line:428
					return None ,None #line:429
			os ._exit (1 )#line:430
def indicatorfastupdate ():#line:431
       try :#line:432
          import json #line:433
          wiz .log ('FRESH MESSAGE')#line:434
          OO0O0O0OO0O00O0O0 =(ADDON .getSetting ("user"))#line:435
          O0000OO00O00OOOOO =(ADDON .getSetting ("pass"))#line:436
          O0000000O00OOOO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:437
          OO0O000OOOOOOO0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:439
          OO00OOOO000O00000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:440
          OOOO00O00OO000000 =str (json .loads (OO00OOOO000O00000 )['ip'])#line:441
          O0O0OO0O0O00OOOO0 =OO0O0O0OO0O00O0O0 #line:442
          OO0000OOOOO00OOOO =O0000OO00O00OOOOO #line:443
          import socket #line:444
          OO00OOOO000O00000 =urllib2 .urlopen (OO0O000OOOOOOO0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0OO0O0O00OOOO0 +' - '+OO0000OOOOO00OOOO +' - '+O0000000O00OOOO0O +' - '+OOOO00O00OO000000 ).readlines ()#line:445
       except :pass #line:447
def skindialogsettind18 ():#line:448
	try :#line:449
		O000OOOO0O000OO00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:450
		OOO0OOO0O00O0O0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:451
		copyfile (O000OOOO0O000OO00 ,OOO0OOO0O00O0O0O0 )#line:452
	except :pass #line:453
def telemedia_android5fix ():#line:454
    OOO00OO000OO0OO00 =ADDON .getSetting ('systemtype')#line:455
    O0O0OOO00OOO0O0OO =ADDON .getSetting ('teleandro')#line:456
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in OOO00OO000OO0OO00 or O0O0OOO00OOO0O0OO =='true':#line:457
        O000OOOOOO0000OOO ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:459
        OOO0OO0O00O0OO000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:460
        O00O0OO0O00OO0OOO =xbmcgui .DialogProgress ()#line:461
        O00O0OO0O00OO0OOO .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:462
        O000OOOO000O0O00O =os .path .join (PACKAGES ,'isr.zip')#line:463
        O0O0000000OOOOOO0 =urllib2 .Request (O000OOOOOO0000OOO )#line:464
        O0OO0O0000O0000O0 =urllib2 .urlopen (O0O0000000OOOOOO0 )#line:465
        OO0O0OO0O0O00O0O0 =xbmcgui .DialogProgress ()#line:467
        OO0O0OO0O0O00O0O0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:468
        OO0O0OO0O0O00O0O0 .update (0 )#line:469
        OO000O0OO0000OO0O =open (O000OOOO000O0O00O ,'wb')#line:471
        try :#line:473
          O00O000O00O00OO0O =O0OO0O0000O0000O0 .info ().getheader ('Content-Length').strip ()#line:474
          OO000OO000OO00O0O =True #line:475
        except AttributeError :#line:476
              OO000OO000OO00O0O =False #line:477
        if OO000OO000OO00O0O :#line:479
              O00O000O00O00OO0O =int (O00O000O00O00OO0O )#line:480
        O00O000OO0O000000 =0 #line:482
        O00O0O000000OOOOO =time .time ()#line:483
        while True :#line:484
              OOOO0OOO0000000O0 =O0OO0O0000O0000O0 .read (8192 )#line:485
              if not OOOO0OOO0000000O0 :#line:486
                  sys .stdout .write ('\n')#line:487
                  break #line:488
              O00O000OO0O000000 +=len (OOOO0OOO0000000O0 )#line:490
              OO000O0OO0000OO0O .write (OOOO0OOO0000000O0 )#line:491
              if not OO000OO000OO00O0O :#line:493
                  O00O000O00O00OO0O =O00O000OO0O000000 #line:494
              if OO0O0OO0O0O00O0O0 .iscanceled ():#line:495
                 OO0O0OO0O0O00O0O0 .close ()#line:496
                 try :#line:497
                  os .remove (O000OOOO000O0O00O )#line:498
                 except :#line:499
                  pass #line:500
                 break #line:501
              O00OOOO0O0O00OO00 =float (O00O000OO0O000000 )/O00O000O00O00OO0O #line:502
              O00OOOO0O0O00OO00 =round (O00OOOO0O0O00OO00 *100 ,2 )#line:503
              OOOOO00OO00OO0O0O =O00O000OO0O000000 /(1024 *1024 )#line:504
              O00000O0OOOO00OO0 =O00O000O00O00OO0O /(1024 *1024 )#line:505
              OOOOO0O00OOO00O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO00OO00OO0O0O ,'teal',O00000O0OOOO00OO0 )#line:506
              if (time .time ()-O00O0O000000OOOOO )>0 :#line:507
                O00OO000O00O0OOO0 =O00O000OO0O000000 /(time .time ()-O00O0O000000OOOOO )#line:508
                O00OO000O00O0OOO0 =O00OO000O00O0OOO0 /1024 #line:509
              else :#line:510
               O00OO000O00O0OOO0 =0 #line:511
              OO00OO0OO000OO000 ='KB'#line:512
              if O00OO000O00O0OOO0 >=1024 :#line:513
                 O00OO000O00O0OOO0 =O00OO000O00O0OOO0 /1024 #line:514
                 OO00OO0OO000OO000 ='MB'#line:515
              if O00OO000O00O0OOO0 >0 and not O00OOOO0O0O00OO00 ==100 :#line:516
                  O0O0O0O00O00O000O =(O00O000O00O00OO0O -O00O000OO0O000000 )/O00OO000O00O0OOO0 #line:517
              else :#line:518
                  O0O0O0O00O00O000O =0 #line:519
              OO0OO0000O0O0O00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OO000O00O0OOO0 ,OO00OO0OO000OO000 )#line:520
              OO0O0OO0O0O00O0O0 .update (int (O00OOOO0O0O00OO00 ),OOOOO0O00OOO00O00 ,OO0OO0000O0O0O00O +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:522
        OOOO00O0O0OOO0O00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:525
        OO000O0OO0000OO0O .close ()#line:528
        extract .all (O000OOOO000O0O00O ,OOOO00O0O0OOO0O00 ,OO0O0OO0O0O00O0O0 )#line:529
        try :#line:533
          os .remove (O000OOOO000O0O00O )#line:534
        except :#line:535
          pass #line:536
def checkidupdate ():#line:537
				OO0O00O0OO00O0O0O =True #line:538
				wiz .setS ("notedismiss","true")#line:539
				O0OO0OO00OOOO0000 =wiz .workingURL (NOTIFICATION )#line:540
				O0OO00OO0O0O00000 =" Kodi Premium"#line:542
				OOOOO0000OO0O0O0O =wiz .checkBuild (O0OO00OO0O0O00000 ,'gui')#line:543
				O0000OO0OOOOOO00O =O0OO00OO0O0O00000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:544
				if not wiz .workingURL (OOOOO0000OO0O0O0O )==True :return #line:545
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:546
				OOOOOO0OOOOO0OOOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0000OO0OOOOOO00O )#line:549
				try :os .remove (OOOOOO0OOOOO0OOOO )#line:550
				except :pass #line:551
				if 'google'in OOOOO0000OO0O0O0O :#line:553
				   OOO000OO00OOO0O00 =googledrive_download (OOOOO0000OO0O0O0O ,OOOOOO0OOOOO0OOOO ,DP2 ,wiz .checkBuild (O0OO00OO0O0O00000 ,'filesize'))#line:554
				else :#line:557
				  downloaderbg .download3 (OOOOO0000OO0O0O0O ,OOOOOO0OOOOO0OOOO ,DP2 )#line:558
				xbmc .sleep (100 )#line:559
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:560
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:562
				extract .all2 (OOOOOO0OOOOO0OOOO ,HOME ,DP2 )#line:564
				DP2 .close ()#line:565
				wiz .defaultSkin ()#line:566
				wiz .lookandFeelData ('save')#line:567
				try :#line:568
					telemedia_android5fix ()#line:569
				except :pass #line:570
				wiz .kodi17Fix ()#line:571
				if KODIV >=18 :#line:572
					skindialogsettind18 ()#line:573
				debridit .debridIt ('restore','all')#line:578
				traktit .traktIt ('restore','all')#line:579
				if INSTALLMETHOD ==1 :OO000OOOOOOOOO00O =1 #line:580
				elif INSTALLMETHOD ==2 :OO000OOOOOOOOO00O =0 #line:581
				else :DP2 .close ()#line:582
				OO0O0OOOOOO0OOOO0 =(NOTIFICATION2 )#line:583
				O0O000OO0000OOO0O =urllib2 .urlopen (OO0O0OOOOOO0OOOO0 )#line:584
				OOOOO0O00O00O0O0O =O0O000OO0000OOO0O .readlines ()#line:585
				O00O0OO0000O0OO0O =0 #line:586
				for OO0O000OOO00OO0O0 in OOOOO0O00O00O0O0O :#line:589
					if OO0O000OOO00OO0O0 .split (' ==')[0 ]=="noreset"or OO0O000OOO00OO0O0 .split ()[0 ]=="noreset":#line:590
						xbmc .executebuiltin ("ReloadSkin()")#line:592
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:593
						OOO0O0O0O0O0O0000 =(ADDON .getSetting ("message"))#line:594
						if OOO0O0O0O0O0O0000 =='true':#line:595
							infobuild ()#line:596
						update_Votes ()#line:597
						indicatorfastupdate ()#line:598
					if OO0O000OOO00OO0O0 .split (' ==')[0 ]=="reset"or OO0O000OOO00OO0O0 .split ()[0 ]=="reset":#line:599
						update_Votes ()#line:601
						indicatorfastupdate ()#line:602
						resetkodi ()#line:603
def checkvictory ():#line:604
				wiz .setS ("notedismiss2","true")#line:606
				OOO00O0000O0O00OO =wiz .workingURL (NOTIFICATION2 )#line:607
				OOOOO00OOOOO0O00O =" Kodi Premium"#line:609
				O00OOOO00O00OOO00 ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:610
				O0OO000000OOOO0O0 =OOOOO00OOOOO0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:611
				if not wiz .workingURL (O00OOOO00O00OOO00 )==True :return #line:612
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:613
				OO0O000O0OOOOOOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO000000OOOO0O0 )#line:616
				try :os .remove (OO0O000O0OOOOOOO0 )#line:617
				except :pass #line:618
				if 'google'in O00OOOO00O00OOO00 :#line:620
				   OO0OOOOO0OO0OOO00 =googledrive_download (O00OOOO00O00OOO00 ,OO0O000O0OOOOOOO0 ,DP2 ,wiz .checkBuild (OOOOO00OOOOO0O00O ,'filesize'))#line:621
				else :#line:624
				  downloaderbg .download5 (O00OOOO00O00OOO00 ,OO0O000O0OOOOOOO0 ,DP2 )#line:625
				xbmc .sleep (100 )#line:626
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:627
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:629
				extract .all2 (OO0O000O0OOOOOOO0 ,ADDONS ,DP2 )#line:631
				DP2 .close ()#line:632
				wiz .defaultSkin ()#line:633
				wiz .lookandFeelData ('save')#line:634
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:635
				if INSTALLMETHOD ==1 :OO00OO0O0O0O0O0OO =1 #line:637
				elif INSTALLMETHOD ==2 :OO00OO0O0O0O0O0OO =0 #line:638
				else :DP2 .close ()#line:639
def checkUpdate ():#line:644
	OOOOO0O0O0OO00OO0 =wiz .getS ('buildname')#line:645
	OO00O0000OO0OO0O0 =wiz .getS ('buildversion')#line:646
	OO0OO00000OOOO00O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:647
	O00OO000O0OO0O0OO =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOOOO0O0O0OO00OO0 ).findall (OO0OO00000OOOO00O )#line:648
	if len (O00OO000O0OO0O0OO )>0 :#line:649
		O00O0O0O000O0000O =O00OO000O0OO0O0OO [0 ][0 ]#line:650
		O0O00000000OOO0O0 =O00OO000O0OO0O0OO [0 ][1 ]#line:651
		OO0000O0OO00OOOOO =O00OO000O0OO0O0OO [0 ][2 ]#line:652
		wiz .setS ('latestversion',O00O0O0O000O0000O )#line:653
		if O00O0O0O000O0000O >OO00O0000OO0OO0O0 :#line:654
			if DISABLEUPDATE =='false':#line:655
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OO00O0000OO0OO0O0 ,O00O0O0O000O0000O ),xbmc .LOGNOTICE )#line:656
				notify .updateWindow (OOOOO0O0O0OO00OO0 ,OO00O0000OO0OO0O0 ,O00O0O0O000O0000O ,O0O00000000OOO0O0 ,OO0000O0OO00OOOOO )#line:657
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OO00O0000OO0OO0O0 ,O00O0O0O000O0000O ),xbmc .LOGNOTICE )#line:658
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OO00O0000OO0OO0O0 ,O00O0O0O000O0000O ),xbmc .LOGNOTICE )#line:659
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:660
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:695
if AUTOUPDATE =='Yes':#line:696
	input =(ADDON .getSetting ("autoupdate"))#line:697
	xbmc .executebuiltin ("UpdateLocalAddons")#line:698
	xbmc .executebuiltin ("UpdateAddonRepos")#line:699
	wiz .wizardUpdate ('startup')#line:700
if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'skin.estuary'):#line:705
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:706
    setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")#line:708
    src =os .path .join (xbmc .translatePath ("special://home/"),"addons/skin.estuary")#line:709
    extract .all (setting_file ,src )#line:712
    wiz .kodi17Fix ()#line:724
    if KODIV >=18 :#line:726
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","addon.xml")#line:728
        with open (setting_file ,'r')as file :#line:729
          filedata =file .read ()#line:730
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.12.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.14.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''')#line:779
        with open (setting_file ,'w')as file :#line:782
          file .write (filedata )#line:783
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")#line:789
        with open (setting_file ,'r')as file :#line:790
          filedata =file .read ()#line:791
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">2</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="-" />
			<param name="DialogHeaderId" value="20" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="99">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>9</onleft>
			<onright>9</onright>
			<onup>2</onup>
			<ondown>2</ondown>
		</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(9).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(9).HasNext</visible>
		</control>
		<control type="grouplist" id="2">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>9</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="10">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>12</onleft>
				<onright>11</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
			<control type="button" id="11">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>10</onleft>
				<onright>12</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="13">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="3">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="4">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="5">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="7">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="6">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="8">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">5</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="" />
			<param name="DialogHeaderId" value="2" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="3">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>3</onleft>
			<onright>3</onright>
			<onup>5</onup>
			<ondown>5</ondown>
		</control>
			<control type="button" id="10">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
			</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(3).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(3).HasNext</visible>
		</control>
		<control type="grouplist" id="5">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>3</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="28">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
			<control type="button" id="29">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="10">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="7">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="8">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="9">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="14">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="11">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="13">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''')#line:1182
        with open (setting_file ,'w')as file :#line:1185
          file .write (filedata )#line:1186
    wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:1194
    xbmc .executebuiltin ("ReloadSkin()")#line:1195
    xbmc .executebuiltin ("ActivateWindow(home)")#line:1196
    f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:1197
    xbmc .Player ().play (f_play ,windowed =False )#line:1198
def setuname ():#line:1325
    OOOOO0O00OOO0OOO0 =''#line:1326
    O0O0O0OOO00O0O00O =xbmc .Keyboard (OOOOO0O00OOO0OOO0 ,'הכנס שם משתמש')#line:1327
    O0O0O0OOO00O0O00O .doModal ()#line:1328
    if O0O0O0OOO00O0O00O .isConfirmed ():#line:1329
           OOOOO0O00OOO0OOO0 =O0O0O0OOO00O0O00O .getText ()#line:1330
           wiz .setS ('user',str (OOOOO0O00OOO0OOO0 ))#line:1331
def STARTP2 ():#line:1332
	if BUILDNAME ==" Kodi Premium":#line:1333
		OOO00O0OOOO0OO0O0 =(ADDON .getSetting ("user"))#line:1334
		OO0O000O00OOO0O00 =(UNAME )#line:1335
		OO0O0O0000OO00OO0 =urllib2 .urlopen (OO0O000O00OOO0O00 )#line:1336
		O00O0OO0O0O0O0OOO =OO0O0O0000OO00OO0 .readlines ()#line:1337
		O0O0OOOOO00O00O00 =0 #line:1338
		for OOO000OO0OOOOOOO0 in O00O0OO0O0O0O0OOO :#line:1339
			if OOO000OO0OOOOOOO0 .split (' ==')[0 ]==OOO00O0OOOO0OO0O0 or OOO000OO0OOOOOOO0 .split ()[0 ]==OOO00O0OOOO0OO0O0 :#line:1340
				O0O0OOOOO00O00O00 =1 #line:1341
				break #line:1342
		if O0O0OOOOO00O00O00 ==0 :#line:1343
			OOO000OO000000OO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:1345
			if OOO000OO000000OO0 :#line:1347
				ADDON .openSettings ()#line:1348
				sys .exit ()#line:1349
			else :#line:1350
				sys .exit ()#line:1351
		return 'ok'#line:1355
def skinWIN ():#line:1358
	idle ()#line:1359
	O0000O0000O000OOO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:1360
	OO000O000O0OO0O00 =[];O0OOOOOO00OO00O0O =[]#line:1361
	for OO000000000OOO0O0 in sorted (O0000O0000O000OOO ,key =lambda OOO00OOO00OO00000 :OOO00OOO00OO00000 ):#line:1362
		O0OO0O0OOO0OO0000 =os .path .split (OO000000000OOO0O0 [:-1 ])[1 ]#line:1363
		OO0O0000OOOOOO000 =os .path .join (OO000000000OOO0O0 ,'addon.xml')#line:1364
		if os .path .exists (OO0O0000OOOOOO000 ):#line:1365
			OOOO00O0OO0O0O000 =open (OO0O0000OOOOOO000 )#line:1366
			O0O0O0000OOO0000O =OOOO00O0OO0O0O000 .read ()#line:1367
			OO0000OOOOOOO0OO0 =parseDOM2 (O0O0O0000OOO0000O ,'addon',ret ='id')#line:1368
			OOOO0O00O000OO000 =O0OO0O0OOO0OO0000 if len (OO0000OOOOOOO0OO0 )==0 else OO0000OOOOOOO0OO0 [0 ]#line:1369
			try :#line:1370
				O0OOOOOO0O000OO0O =xbmcaddon .Addon (id =OOOO0O00O000OO000 )#line:1371
				OO000O000O0OO0O00 .append (O0OOOOOO0O000OO0O .getAddonInfo ('name'))#line:1372
				O0OOOOOO00OO00O0O .append (OOOO0O00O000OO000 )#line:1373
			except :#line:1374
				pass #line:1375
	OO00OO0O000OO0O0O =[];OOOOO0OOOOOOO0O00 =0 #line:1376
	O00OO0000O0000O0O =["Current Skin -- %s"%currSkin ()]+OO000O000O0OO0O00 #line:1377
	OOOOO0OOOOOOO0O00 =DIALOG .select ("Select the Skin you want to swap with.",O00OO0000O0000O0O )#line:1378
	if OOOOO0OOOOOOO0O00 ==-1 :return #line:1379
	else :#line:1380
		OOOOO00000OOOOOO0 =(OOOOO0OOOOOOO0O00 -1 )#line:1381
		OO00OO0O000OO0O0O .append (OOOOO00000OOOOOO0 )#line:1382
		O00OO0000O0000O0O [OOOOO0OOOOOOO0O00 ]="%s"%(OO000O000O0OO0O00 [OOOOO00000OOOOOO0 ])#line:1383
	if OO00OO0O000OO0O0O ==None :return #line:1384
	for OO00000O00OO0OO0O in OO00OO0O000OO0O0O :#line:1385
		swapSkins (O0OOOOOO00OO00O0O [OO00000O00OO0OO0O ])#line:1386
def currSkin ():#line:1388
	return xbmc .getSkinDir ('Container.PluginName')#line:1389
def fix17update ():#line:1391
	if KODIV >=17 and KODIV <18 :#line:1392
		wiz .kodi17Fix ()#line:1393
		xbmc .sleep (4000 )#line:1394
		try :#line:1395
			OOOOO00O0O000O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1396
			O000O00O000OO0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1397
			os .rename (OOOOO00O0O000O000 ,O000O00O000OO0OOO )#line:1398
		except :#line:1399
				pass #line:1400
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1401
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1402
		fixfont ()#line:1403
		OO00OO0OO000000OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1404
		try :#line:1406
			O0O0OOOO0OO0OO000 =open (OO00OO0OO000000OO ,'r')#line:1407
			O0OO000OOO0OO0000 =O0O0OOOO0OO0OO000 .read ()#line:1408
			O0O0OOOO0OO0OO000 .close ()#line:1409
			O0OO0O0OOO0O0O0O0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:1410
			OO0O0OO0OOO00O0OO =re .compile (O0OO0O0OOO0O0O0O0 ).findall (O0OO000OOO0OO0000 )[0 ]#line:1411
			O0O0OOOO0OO0OO000 =open (OO00OO0OO000000OO ,'w')#line:1412
			O0O0OOOO0OO0OO000 .write (O0OO000OOO0OO0000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0O0OO0OOO00O0OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:1413
			O0O0OOOO0OO0OO000 .close ()#line:1414
		except :#line:1415
				pass #line:1416
		wiz .kodi17Fix ()#line:1417
		OO00OO0OO000000OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1418
		try :#line:1419
			O0O0OOOO0OO0OO000 =open (OO00OO0OO000000OO ,'r')#line:1420
			O0OO000OOO0OO0000 =O0O0OOOO0OO0OO000 .read ()#line:1421
			O0O0OOOO0OO0OO000 .close ()#line:1422
			O0OO0O0OOO0O0O0O0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:1423
			OO0O0OO0OOO00O0OO =re .compile (O0OO0O0OOO0O0O0O0 ).findall (O0OO000OOO0OO0000 )[0 ]#line:1424
			O0O0OOOO0OO0OO000 =open (OO00OO0OO000000OO ,'w')#line:1425
			O0O0OOOO0OO0OO000 .write (O0OO000OOO0OO0000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0O0OO0OOO00O0OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:1426
			O0O0OOOO0OO0OO000 .close ()#line:1427
		except :#line:1428
				pass #line:1429
		swapSkins ('skin.Premium.mod')#line:1430
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1431
	os ._exit (1 )#line:1432
def fix18update ():#line:1433
	if KODIV >=18 :#line:1434
		xbmc .sleep (4000 )#line:1435
		if BUILDNAME =="":#line:1436
			try :#line:1437
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:1438
			except :#line:1439
				pass #line:1440
		try :#line:1441
			O00000OOOO0O0OOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1442
			O0OOOO00OO00OO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1443
			os .rename (O00000OOOO0O0OOOO ,O0OOOO00OO00OO000 )#line:1444
		except :#line:1445
				pass #line:1446
		skindialogsettind18 ()#line:1447
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1448
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1449
		fixfont ()#line:1450
		O00OO000000O00000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1451
		try :#line:1452
			OOOO00000O00O00O0 =open (O00OO000000O00000 ,'r')#line:1453
			OO00OOO0O00000O00 =OOOO00000O00O00O0 .read ()#line:1454
			OOOO00000O00O00O0 .close ()#line:1455
			OOOO0OOOO0OOO00OO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:1456
			O0O0000OO0OO0OO0O =re .compile (OOOO0OOOO0OOO00OO ).findall (OO00OOO0O00000O00 )[0 ]#line:1457
			OOOO00000O00O00O0 =open (O00OO000000O00000 ,'w')#line:1458
			OOOO00000O00O00O0 .write (OO00OOO0O00000O00 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O0000OO0OO0OO0O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:1459
			OOOO00000O00O00O0 .close ()#line:1460
		except :#line:1461
				pass #line:1462
		wiz .kodi17Fix ()#line:1463
		O00OO000000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1464
		try :#line:1465
			OOOO00000O00O00O0 =open (O00OO000000O00000 ,'r')#line:1466
			OO00OOO0O00000O00 =OOOO00000O00O00O0 .read ()#line:1467
			OOOO00000O00O00O0 .close ()#line:1468
			OOOO0OOOO0OOO00OO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:1469
			O0O0000OO0OO0OO0O =re .compile (OOOO0OOOO0OOO00OO ).findall (OO00OOO0O00000O00 )[0 ]#line:1470
			OOOO00000O00O00O0 =open (O00OO000000O00000 ,'w')#line:1471
			OOOO00000O00O00O0 .write (OO00OOO0O00000O00 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O0000OO0OO0OO0O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:1472
			OOOO00000O00O00O0 .close ()#line:1473
		except :#line:1474
				pass #line:1475
		swapSkins ('skin.Premium.mod')#line:1476
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1477
	os ._exit (1 )#line:1478
def swapSkins (O00O00OO000OO00O0 ,title ="Error"):#line:1479
	OO0O0O0O0000OOOOO ='lookandfeel.skin'#line:1480
	OO00000O0OO00O0OO =O00O00OO000OO00O0 #line:1481
	O0O0O0OOO00000000 =getOld (OO0O0O0O0000OOOOO )#line:1482
	OOOOOO00OO0000OOO =OO0O0O0O0000OOOOO #line:1483
	setNew (OOOOOO00OO0000OOO ,OO00000O0OO00O0OO )#line:1484
	O000O0OO0O000OO00 =0 #line:1485
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0OO0O000OO00 <100 :#line:1486
		O000O0OO0O000OO00 +=1 #line:1487
		xbmc .sleep (1 )#line:1488
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1489
		xbmc .executebuiltin ('SendClick(11)')#line:1490
	return True #line:1491
def getOld (OO0000OO00O00OO0O ):#line:1493
	try :#line:1494
		OO0000OO00O00OO0O ='"%s"'%OO0000OO00O00OO0O #line:1495
		O000O0O0O0O0OOOOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0000OO00O00OO0O )#line:1496
		O0O0O0OOOOO0O0O00 =xbmc .executeJSONRPC (O000O0O0O0O0OOOOO )#line:1498
		O0O0O0OOOOO0O0O00 =simplejson .loads (O0O0O0OOOOO0O0O00 )#line:1499
		if O0O0O0OOOOO0O0O00 .has_key ('result'):#line:1500
			if O0O0O0OOOOO0O0O00 ['result'].has_key ('value'):#line:1501
				return O0O0O0OOOOO0O0O00 ['result']['value']#line:1502
	except :#line:1503
		pass #line:1504
	return None #line:1505
def setNew (O0O0000O0000OOOO0 ,OO0O0OO00O00OOO00 ):#line:1508
	try :#line:1509
		O0O0000O0000OOOO0 ='"%s"'%O0O0000O0000OOOO0 #line:1510
		OO0O0OO00O00OOO00 ='"%s"'%OO0O0OO00O00OOO00 #line:1511
		OOO0O0O00O0OO00OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0O0000O0000OOOO0 ,OO0O0OO00O00OOO00 )#line:1512
		O000O0O0OO0OOOOO0 =xbmc .executeJSONRPC (OOO0O0O00O0OO00OO )#line:1514
	except :#line:1515
		pass #line:1516
	return None #line:1517
def idle ():#line:1518
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:1519
def fixfont ():#line:1520
	OOOO0000O0O0O0OO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1521
	O00O0O0O0O00000O0 =json .loads (OOOO0000O0O0O0OO0 );#line:1523
	O0OO000O00OO0OO0O =O00O0O0O0O00000O0 ["result"]["settings"]#line:1524
	OO0000000O000OOO0 =[OOOOO0OO000O000O0 for OOOOO0OO000O000O0 in O0OO000O00OO0OO0O if OOOOO0OO000O000O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1526
	OO00O0O0000000OO0 =OO0000000O000OOO0 ["options"];#line:1527
	O00O0O0000000OO00 =OO0000000O000OOO0 ["value"];#line:1528
	O0OOOOOOO00OO0O00 =[OOO00OOOO0O0O0O0O for (OOO00OOOO0O0O0O0O ,O0OOOO00O0O00O00O )in enumerate (OO00O0O0000000OO0 )if O0OOOO00O0O00O00O ["value"]==O00O0O0000000OO00 ][0 ];#line:1530
	O0O00OOO0O0OO000O =(O0OOOOOOO00OO0O00 +1 )%len (OO00O0O0000000OO0 )#line:1532
	O000O0O0O000O0O00 =OO00O0O0000000OO0 [O0O00OOO0O0OO000O ]["value"]#line:1534
	O0OOO00OO000000O0 =OO00O0O0000000OO0 [O0O00OOO0O0OO000O ]["label"]#line:1535
	O0O00000000OOO0OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1537
	try :#line:1539
		OO0000OO0O0O0O0O0 =json .loads (O0O00000000OOO0OO );#line:1540
		if OO0000OO0O0O0O0O0 ["result"]!=True :#line:1542
			raise Exception #line:1543
	except :#line:1544
		sys .stderr .write ("Error switching audio output device")#line:1545
		raise Exception #line:1546
def checkSkin ():#line:1549
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:1550
	O0O0O0OO0O000000O =wiz .getS ('defaultskin')#line:1551
	O00O0000000OO0OOO =wiz .getS ('defaultskinname')#line:1552
	O0O00000OOOO0000O =wiz .getS ('defaultskinignore')#line:1553
	O0O0OOO0OOO00OOOO =False #line:1554
	if not O0O0O0OO0O000000O =='':#line:1555
		if os .path .exists (os .path .join (ADDONS ,O0O0O0OO0O000000O )):#line:1556
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0000000OO0OOO )):#line:1557
				O0O0OOO0OOO00OOOO =O0O0O0OO0O000000O #line:1558
				OO0OOOO0000O00000 =O00O0000000OO0OOO #line:1559
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O0O0OOO0OOO00OOOO =False #line:1560
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O0O0O0OO0O000000O ='';O00O0000000OO0OOO =''#line:1561
	if O0O0O0OO0O000000O =='':#line:1562
		OOOOO0000O0O0OOOO =[]#line:1563
		O00O00OOO00OOOO00 =[]#line:1564
		for O0OO0OO0OO0000O00 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:1565
			OOO00O000OOO00000 ="%s/addon.xml"%O0OO0OO0OO0000O00 #line:1566
			if os .path .exists (OOO00O000OOO00000 ):#line:1567
				O0O0000000O0O00O0 =open (OOO00O000OOO00000 ,mode ='r');O0OOO000O000000O0 =O0O0000000O0O00O0 .read ().replace ('\n','').replace ('\r','').replace ('\t','');O0O0000000O0O00O0 .close ();#line:1568
				O0OOO000O0O0O0OO0 =wiz .parseDOM (O0OOO000O000000O0 ,'addon',ret ='id')#line:1569
				O00OO00O00OO0000O =wiz .parseDOM (O0OOO000O000000O0 ,'addon',ret ='name')#line:1570
				wiz .log ("%s: %s"%(O0OO0OO0OO0000O00 ,str (O0OOO000O0O0O0OO0 [0 ])),xbmc .LOGNOTICE )#line:1571
				if len (O0OOO000O0O0O0OO0 )>0 :O00O00OOO00OOOO00 .append (str (O0OOO000O0O0O0OO0 [0 ]));OOOOO0000O0O0OOOO .append (str (O00OO00O00OO0000O [0 ]))#line:1572
				else :wiz .log ("ID not found for %s"%O0OO0OO0OO0000O00 ,xbmc .LOGNOTICE )#line:1573
			else :wiz .log ("ID not found for %s"%O0OO0OO0OO0000O00 ,xbmc .LOGNOTICE )#line:1574
		if len (O00O00OOO00OOOO00 )>0 :#line:1575
			if len (O00O00OOO00OOOO00 )>1 :#line:1576
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:1577
					O0O0OO0OOO00O0O00 =DIALOG .select ("Select skin to switch to!",OOOOO0000O0O0OOOO )#line:1578
					if O0O0OO0OOO00O0O00 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1579
					else :#line:1580
						O0O0OOO0OOO00OOOO =O00O00OOO00OOOO00 [O0O0OO0OOO00O0O00 ]#line:1581
						OO0OOOO0000O00000 =OOOOO0000O0O0OOOO [O0O0OO0OOO00O0O00 ]#line:1582
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1583
	if O0O0OOO0OOO00OOOO :#line:1590
		skinSwitch .swapSkins (O0O0OOO0OOO00OOOO )#line:1591
		OO0OOO0O000O00OO0 =0 #line:1592
		xbmc .sleep (1000 )#line:1593
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OOO0O000O00OO0 <150 :#line:1594
			OO0OOO0O000O00OO0 +=1 #line:1595
			xbmc .sleep (200 )#line:1596
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1598
			wiz .ebi ('SendClick(11)')#line:1599
			wiz .lookandFeelData ('restore')#line:1600
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1601
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1602
while xbmc .Player ().isPlayingVideo ():#line:1604
	xbmc .sleep (1000 )#line:1605
if KODIV >=17 :#line:1607
	NOW =datetime .now ()#line:1608
	temp =wiz .getS ('kodi17iscrap')#line:1609
	if not temp =='':#line:1610
		if temp >str (NOW -timedelta (minutes =2 )):#line:1611
			wiz .log ("Killing Start Up Script")#line:1612
			sys .exit ()#line:1613
	wiz .log ("%s"%(NOW ))#line:1614
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1615
	xbmc .sleep (1000 )#line:1616
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1617
		wiz .log ("Killing Start Up Script")#line:1618
		sys .exit ()#line:1619
	else :#line:1620
		wiz .log ("Continuing Start Up Script")#line:1621
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1623
path =os .path .split (ADDONPATH )#line:1624
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1625
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1626
if KODIADDONS in ADDONPATH :#line:1629
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1630
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1631
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1632
	if os .path .exists (newpath ):#line:1633
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1634
		wiz .cleanHouse (newpath )#line:1635
		wiz .removeFolder (newpath )#line:1636
	try :#line:1637
		wiz .copytree (ADDONPATH ,newpath )#line:1638
	except Exception as e :#line:1639
		pass #line:1640
	wiz .forceUpdate (True )#line:1641
try :#line:1643
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1644
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1645
except :#line:1646
	pass #line:1647
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1649
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1653
			wiz .kodi17Fix ()#line:1654
			fix18update ()#line:1655
			fix17update ()#line:1656
if INSTALLED =='true':#line:1659
    input =(ADDON .getSetting ("auto_rd"))#line:1660
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1662
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1663
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1664
    wiz .clearS ('install')#line:1665
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1750
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1752
	STARTP2 ()#line:1754
	if not NOTIFY =='true':#line:1755
		url =wiz .workingURL (NOTIFICATION )#line:1756
		if url ==True :#line:1757
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1758
			if not id ==False :#line:1759
				try :#line:1760
					id =int (id );NOTEID =int (NOTEID )#line:1761
					if id ==NOTEID :#line:1762
						if NOTEDISMISS =='false':#line:1763
							debridit .debridIt ('update','all')#line:1764
							traktit .traktIt ('update','all')#line:1765
							checkidupdate ()#line:1766
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1767
					elif id >NOTEID :#line:1768
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1769
						wiz .setS ('noteid',str (id ))#line:1770
						wiz .setS ('notedismiss','false')#line:1771
						debridit .debridIt ('update','all')#line:1773
						traktit .traktIt ('update','all')#line:1774
						checkidupdate ()#line:1775
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1777
				except Exception as e :#line:1778
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1779
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1780
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1781
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1782
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1783
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1785
if ENABLE =='No':#line:1786
	if not NOTIFY2 =='true':#line:1787
		url =wiz .workingURL (NOTIFICATION2 )#line:1788
		if url ==True :#line:1789
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1790
			if not id ==False :#line:1791
				try :#line:1792
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1793
					if id ==NOTEID2 :#line:1794
						if NOTEDISMISS2 =='false':#line:1795
							checkvictory ()#line:1796
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1797
					elif id >NOTEID2 :#line:1798
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1799
						wiz .setS ('noteid2',str (id ))#line:1800
						wiz .setS ('notedismiss2','false')#line:1801
						checkvictory ()#line:1802
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1803
				except Exception as e :#line:1804
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1805
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1806
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1807
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1808
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1809
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1811
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1812
	if not NOTIFY3 =='true':#line:1813
		url =wiz .workingURL (NOTIFICATION3 )#line:1814
		if url ==True :#line:1815
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1816
			if not id ==False :#line:1817
				try :#line:1818
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1819
					if id ==NOTEID3 :#line:1820
						if NOTEDISMISS3 =='false':#line:1821
							notify .notification3 (msg )#line:1822
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1823
					elif id >NOTEID3 :#line:1824
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1825
						wiz .setS ('noteid3',str (id ))#line:1826
						wiz .setS ('notedismiss3','false')#line:1827
						notify .notification3 (msg =msg )#line:1828
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1829
				except Exception as e :#line:1830
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1831
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1832
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1833
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1834
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1835
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1836
if KEEPTRAKT =='true':#line:1837
	if TRAKTSAVE <=str (TODAY ):#line:1838
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1839
		traktit .autoUpdate ('all')#line:1840
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1841
	else :#line:1842
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1843
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1844
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1846
if KEEPREAL =='true':#line:1847
	if REALSAVE <=str (TODAY ):#line:1848
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1849
		debridit .autoUpdate ('all')#line:1850
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1851
	else :#line:1852
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1853
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1854
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1856
if KEEPLOGIN =='true':#line:1857
	if LOGINSAVE <=str (TODAY ):#line:1858
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1859
		loginit .autoUpdate ('all')#line:1860
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1861
	else :#line:1862
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1863
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1864
wiz .clearCache (True )#line:1865
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1866
if AUTOCLEANUP =='false':#line:1867
	service =False #line:1868
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1869
	feq =int (float (AUTOFEQ ))#line:1870
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1871
		service =True #line:1872
		next_run =days [feq ]#line:1873
		wiz .setS ('nextautocleanup',str (next_run ))#line:1874
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1875
	if service ==True :#line:1876
		AUTOCACHE =wiz .getS ('clearcache')#line:1877
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1878
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1879
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1880
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1881
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1882
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1883
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1884
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1885
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1886
wiz .setS ('kodi17iscrap','')#line:1888
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1957
	count =0 #line:1958
	for f in filenames :#line:1959
		count +=1 #line:1960
		fp =os .path .join (dirpath ,f )#line:1961
		total_size +=os .path .getsize (fp )#line:1962
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1963
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1970
	for f2 in filenames2 :#line:1971
		fp2 =os .path .join (dirpath2 ,f2 )#line:1972
		total_size2 +=os .path .getsize (fp2 )#line:1973
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1974
if int (total_sizetext2 )>filesize_thumb :#line:1976
		maintenance .deleteThumbnails ()#line:1978
for dirpath2 ,dirnames2 ,filenames2 in os .walk (telecach ):#line:1982
	for f2 in filenames2 :#line:1983
		fp2 =os .path .join (dirpath2 ,f2 )#line:1984
		total_size2 +=os .path .getsize (fp2 )#line:1985
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1986
if int (total_sizetext2 )>filesize_tele :#line:1988
		maintenance .deleteTele ()#line:1990
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1995
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1996
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1998
time .sleep (3 )#line:1999
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:2001
        display_Votes ()#line:2002
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:2004
        file .write (str ('Done'))#line:2006
        file .close ()#line:2007
tele =(ADDON .getSetting ("auto_tele"))#line:2012
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:2014
    if tele =='true':#line:2016
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:2017
