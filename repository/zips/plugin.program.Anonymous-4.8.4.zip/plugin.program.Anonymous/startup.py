import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs #line:3
import shutil #line:4
import urllib #line:5
import re #line:6
import uservar #line:7
import time #line:8
import json #line:9
import platform #line:10
from shutil import copyfile #line:12
from resources .libs import extract ,notify ,maintenance #line:13
try :#line:14
 import wizard as wiz #line:15
except :#line:16
 from resources .libs import wizard as wiz #line:17
translatepath =xbmcvfs .translatePath #line:20
global teleupdate #line:21
teleupdate =False #line:22
ADDON_ID =uservar .ADDON_ID #line:23
ADDONTITLE =uservar .ADDONTITLE #line:24
ADDON =wiz .addonId (ADDON_ID )#line:25
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:26
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:27
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:28
DIALOG =xbmcgui .Dialog ()#line:29
DP =xbmcgui .DialogProgress ()#line:30
HOME =translatepath ('special://home/')#line:31
ADDONS =os .path .join (HOME ,'addons')#line:32
USERDATA =os .path .join (HOME ,'userdata')#line:33
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:34
SKIN =xbmc .getSkinDir ()#line:35
BUILDNAME =wiz .getS ('buildname')#line:36
BUILDVERSION =wiz .getS ('buildversion')#line:37
COLOR1 =uservar .COLOR1 #line:40
COLOR2 =uservar .COLOR2 #line:41
TMDB_NEW_API =uservar .TMDB_NEW_API #line:42
AddonID ='plugin.program.Anonymous'#line:46
packagesdir =translatepath (os .path .join ('special://home/addons/packages',''))#line:47
thumbnails =translatepath ('special://home/userdata/Thumbnails')#line:48
telecach =translatepath ('special://home/userdata/addon_data/plugin.video.telemedia/database')#line:49
temp_folder =translatepath ('special://home/temp/')#line:50
dialog =xbmcgui .Dialog ()#line:51
setting =xbmcaddon .Addon ().getSetting #line:52
iconpath =translatepath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:53
notify_mode =setting ('notify_mode')#line:54
auto_clean =setting ('startup.cache')#line:55
filesize_thumb =int (setting ('filesizethumb_alert'))#line:56
filesize_tele =int (setting ('filesizetele_alert2'))#line:57
total_size2 =0 #line:59
total_size3 =0 #line:60
total_size4 =0 #line:61
total_size =0 #line:62
count =0 #line:63
def disply_hwr ():#line:66
   try :#line:67
        O0OOO00OO0OO0000O =tmdb_list (TMDB_NEW_API )#line:68
        OO00O00OO000O00OO =str ((getHwAddr ('eth0'))*O0OOO00OO0OO0000O )#line:69
        O0000OOO0O0000O00 =(OO00O00OO000O00OO [1 ]+OO00O00OO000O00OO [2 ]+OO00O00OO000O00OO [5 ]+OO00O00OO000O00OO [7 ])#line:75
        OOO0OO0OO0000OOOO =(ADDON .getSetting ("action"))#line:76
        ADDON .setSetting ('action',str (O0000OOO0O0000O00 ))#line:78
        if not os .path .exists (os .path .join (ADDONDATA ,'4.5.0')):#line:81
            xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:82
            try :#line:83
                tryinstall (O0000OOO0O0000O00 )#line:84
            except :pass #line:85
            try :#line:86
                OOOO0O0OOO0OOOOO0 =open (os .path .join (ADDONDATA ,'4.5.0'),'w')#line:87
                OOOO0O0OOO0OOOOO0 .write (str ('Done'))#line:89
                OOOO0O0OOO0OOOOO0 .close ()#line:90
            except :pass #line:91
   except :#line:92
        if not os .path .exists (os .path .join (ADDONDATA ,'4.5.0')):#line:93
          xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:94
          try :#line:95
            tryinstall ('no_code')#line:96
          except :pass #line:97
          try :#line:98
                OOOO0O0OOO0OOOOO0 =open (os .path .join (ADDONDATA ,'4.5.0'),'w')#line:99
                OOOO0O0OOO0OOOOO0 .write (str ('Done'))#line:101
                OOOO0O0OOO0OOOOO0 .close ()#line:102
          except :pass #line:103
def getHwAddr (O0O0O0000O000OOO0 ):#line:104
   import subprocess ,time #line:105
   if xbmc .getCondVisibility ('system.platform.android'):#line:106
     OOOO0O0O0O0OO0O0O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:107
     OO000O0O0OOOO0O0O =re .compile ('link/ether (.+?) brd').findall (str (OOOO0O0O0O0OO0O0O ))#line:108
     OO0OO0OOO0OO0OOO0 =0 #line:109
     for OOO0OOO000OOO0000 in OO000O0O0OOOO0O0O :#line:110
      if OO000O0O0OOOO0O0O !='00:00:00:00:00:00':#line:111
          OOO000O0OOO0O0000 =OOO0OOO000OOO0000 #line:112
          OO0OO0OOO0OO0OOO0 =OO0OO0OOO0OO0OOO0 +int (OOO000O0OOO0O0000 .replace (':',''),16 )#line:113
          break #line:114
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:115
       OO00OO0000O00O000 =0 #line:116
       OO0OO0OOO0OO0OOO0 =0 #line:117
       O0O0OO0000OOO000O =[]#line:118
       O000O000OO000O00O =os .popen ("getmac").read ()#line:119
       O000O000OO000O00O =O000O000OO000O00O .split ("\n")#line:120
       for OOO0O00000O00O0O0 in O000O000OO000O00O :#line:121
            O00O00OOO0O0O0000 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0O00000O00O0O0 ,re .I )#line:122
            if O00O00OOO0O0O0000 :#line:123
                OO000O0O0OOOO0O0O =O00O00OOO0O0O0000 .group ().replace ('-',':')#line:124
                O0O0OO0000OOO000O .append (OO000O0O0OOOO0O0O )#line:125
                OO0OO0OOO0OO0OOO0 =OO0OO0OOO0OO0OOO0 +int (OO000O0O0OOOO0O0O .replace (':',''),16 )#line:126
                break #line:127
   elif xbmc .getCondVisibility ('system.platform.linux'):#line:128
       OO0OO0OOO0OO0OOO0 =0 #line:129
       import uuid #line:130
       OO000O0O0OOOO0O0O =hex (uuid .getnode ())#line:131
       OO0OO0OOO0OO0OOO0 =OO0OO0OOO0OO0OOO0 +int (OO000O0O0OOOO0O0O .replace (':',''),16 )#line:132
   else :#line:134
       OO0OO0OOO0OO0OOO0 =0 #line:135
       import uuid #line:136
       OO000O0O0OOOO0O0O =hex (uuid .getnode ())#line:137
       OO0OO0OOO0OO0OOO0 =OO0OO0OOO0OO0OOO0 +int (OO000O0O0OOOO0O0O .replace (':',''),16 )#line:138
   try :#line:140
    return OO0OO0OOO0OO0OOO0 #line:141
   except :pass #line:142
def decode (O000OO0OOOOO0OOO0 ,OO0OO0O0O000OOOO0 ):#line:143
    import base64 #line:144
    OO0O00O000O0O000O =[]#line:145
    if (len (O000OO0OOOOO0OOO0 ))!=4 :#line:147
     return 10 #line:148
    OO0OO0O0O000OOOO0 =base64 .urlsafe_b64decode (OO0OO0O0O000OOOO0 )#line:149
    for O0000OO0O00O0O00O in range (len (OO0OO0O0O000OOOO0 )):#line:151
        OOOOO0O00O00OO00O =O000OO0OOOOO0OOO0 [O0000OO0O00O0O00O %len (O000OO0OOOOO0OOO0 )]#line:152
        try :#line:153
          OOOOOO0O00O00OO0O =chr ((256 +ord (OO0OO0O0O000OOOO0 [O0000OO0O00O0O00O ])-ord (OOOOO0O00O00OO00O ))%256 )#line:154
        except :#line:155
          OOOOOO0O00O00OO0O =chr ((256 +(OO0OO0O0O000OOOO0 [O0000OO0O00O0O00O ])-ord (OOOOO0O00O00OO00O ))%256 )#line:156
        OO0O00O000O0O000O .append (OOOOOO0O00O00OO0O )#line:157
    return "".join (OO0O00O000O0O000O )#line:158
def tmdb_list (OO000OOOO0O0O00O0 ):#line:159
    O0OOO0O00000OO00O =decode ("7643",OO000OOOO0O0O00O0 )#line:162
    return int (O0OOO0O00000OO00O )#line:165
def tryinstall (O0O000OO0OO0OO0O0 ):#line:168
          import json ,base64 ,requests #line:170
          O0OO000OOOOO0O0OO =urllib .parse .quote_plus #line:171
          OO0OOO0OO00OOO0OO =urllib .parse .urlencode #line:172
          OO00OO0OOOO0OO0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:174
          O0OO00O000OO00000 =platform .uname ()#line:175
          OO0OOOOO00OO00O0O =O0OO00O000OO00000 [1 ]#line:176
          O00O0O000O000OOO0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:177
          OO000OOO0OOOOOO00 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:178
          OO0OOOOOO00OO0OOO =requests .get (O00O0O000O000OOO0 +O0OO000OOOOO0O0OO ('התקנה חדשה - ')+O0OO000OOOOO0O0OO (' קוד מכשיר: ')+str (O0O000OO0OO0OO0O0 )+O0OO000OOOOO0O0OO (' קודי: ')+OO00OO0OOOO0OO0O0 +O0OO000OOOOO0O0OO (' כתובת: ')+OO000OOO0OOOOOO00 +O0OO000OOOOO0O0OO (' מערכת הפעלה: ')+wiz .platform_d ()+O0OO000OOOOO0O0OO (' שם המערכת: ')+OO0OOOOO00OO00O0O +O0OO000OOOOO0O0OO (' גירסת ויזארד: ')+VERSION ).json ()#line:180
          OO0OOOOOO00OO0OOO =requests .get (O00O0O000O000OOO0 +str (O0O000OO0OO0OO0O0 )).json ()#line:181
def setNew (O0OO0OO0OOOOOOO0O ,OO00O00000O0000OO ):#line:184
	try :#line:185
		O0OO0OO0OOOOOOO0O ='"%s"'%O0OO0OO0OOOOOOO0O #line:186
		OO00O00000O0000OO ='"%s"'%OO00O00000O0000OO #line:187
		O00OO0O0O0O0000OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0OO0OO0OOOOOOO0O ,OO00O00000O0000OO )#line:188
		OO0O0O0O000000O00 =xbmc .executeJSONRPC (O00OO0O0O0O0000OO )#line:190
	except :#line:191
		pass #line:192
	return None #line:193
def backtokodi ():#line:194
    O0O000OO00OOOOO0O =DIALOG .yesno (ADDONTITLE ,"נראה שהייתה תקלה , האם לחזור לבילד",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:196
    if O0O000OO00OOOOO0O ==1 :#line:197
        O0OOOOO000O0OO0OO =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/guisettings"),"19","guisettings.xml")#line:198
        O000O000O0O00OO00 =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:199
        copyfile (O0OOOOO000O0OO0OO ,O000O000O0O00OO00 )#line:201
        xbmc .sleep (200 )#line:203
        os ._exit (1 )#line:204
if SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:207
      backtokodi ()#line:209
disply_hwr ()#line:211
if BUILDNAME ==""and not os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:212
    wiz .wizardUpdateDP ('startup')#line:213
try :#line:223
    if not os .path .exists (translatepath ("special://home/addons/")+'skin.estuary'):#line:224
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:225
            setting_file =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")#line:226
            src =os .path .join (translatepath ("special://home/"),"addons/skin.estuary")#line:227
            extract .all (setting_file ,src )#line:228
            xbmc .executebuiltin ('UpdateLocalAddons()')#line:230
            xbmc .executebuiltin ("ActivateWindow(home)")#line:235
            f_play =(os .path .join (ADDONPATH ,'resources','netflix.mp4'))#line:236
            xbmc .Player ().play (f_play ,windowed =False )#line:237
            xbmc .executebuiltin ("ReloadSkin()")#line:238
except :pass #line:239
if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:242
    refreshCommand ='RunPlugin(plugin://plugin.program.Anonymous/?mode=update_tele)'#line:243
    xbmc .executebuiltin (refreshCommand )#line:244
    xbmc .executebuiltin ('AlarmClock(wizard,{0},05:00:00,silent,loop)'.format (refreshCommand ))#line:245
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:247
	for f2 in filenames2 :#line:248
		fp2 =os .path .join (dirpath2 ,f2 )#line:249
		total_size2 +=os .path .getsize (fp2 )#line:250
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:251
if int (total_sizetext2 )>filesize_thumb :#line:253
		maintenance .deleteThumbnails ()#line:255
if BUILDNAME ==" Kodi Premium":#line:257
    if len (ADDON .getSetting ("sync_user"))>0 :#line:258
        if ADDON .getSetting ("startup_sync")=='false':#line:259
            if os .path .exists (os .path .join (ADDONS ,'plugin.video.telemedia')):#line:260
                xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=207&url=www)")#line:261
            ADDON .setSetting ("startup_sync",'true')#line:263
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]System Is Started[/COLOR]'%COLOR2 )