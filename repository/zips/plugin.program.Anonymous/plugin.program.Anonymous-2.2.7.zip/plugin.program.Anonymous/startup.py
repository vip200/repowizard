# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
global teleupdate #line:32
teleupdate =False #line:33
ADDON_ID =uservar .ADDON_ID #line:34
ADDONTITLE =uservar .ADDONTITLE #line:35
ADDON =wiz .addonId (ADDON_ID )#line:36
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:37
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:38
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:39
DIALOG =xbmcgui .Dialog ()#line:40
DP =xbmcgui .DialogProgress ()#line:41
DP2 =xbmcgui .DialogProgressBG ()#line:42
HOME =xbmc .translatePath ('special://home/')#line:43
PROFILE =xbmc .translatePath ('special://profile/')#line:44
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:45
ADDONS =os .path .join (HOME ,'addons')#line:46
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:47
USERDATA =os .path .join (HOME ,'userdata')#line:48
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:49
PACKAGES =os .path .join (ADDONS ,'packages')#line:50
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:51
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:52
ICON =os .path .join (ADDONPATH ,'icon.png')#line:53
ART =os .path .join (ADDONPATH ,'resources','art')#line:54
SKIN =xbmc .getSkinDir ()#line:55
BUILDNAME =wiz .getS ('buildname')#line:56
DEFAULTSKIN =wiz .getS ('defaultskin')#line:57
DEFAULTNAME =wiz .getS ('defaultskinname')#line:58
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:59
BUILDVERSION =wiz .getS ('buildversion')#line:60
BUILDLATEST =wiz .getS ('latestversion')#line:61
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:62
DISABLEUPDATE =wiz .getS ('disableupdate')#line:63
AUTOCLEANUP =wiz .getS ('autoclean')#line:64
AUTOCACHE =wiz .getS ('clearcache')#line:65
AUTOPACKAGES =wiz .getS ('clearpackages')#line:66
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:67
AUTOFEQ =wiz .getS ('autocleanfeq')#line:68
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:69
TRAKTSAVE =wiz .getS ('traktlastsave')#line:70
REALSAVE =wiz .getS ('debridlastsave')#line:71
LOGINSAVE =wiz .getS ('loginlastsave')#line:72
INSTALLMETHOD =wiz .getS ('installmethod')#line:73
KEEPTRAKT =wiz .getS ('keeptrakt')#line:74
KEEPREAL =wiz .getS ('keepdebrid')#line:75
KEEPLOGIN =wiz .getS ('keeplogin')#line:76
INSTALLED =wiz .getS ('installed')#line:77
EXTRACT =wiz .getS ('extract')#line:78
EXTERROR =wiz .getS ('errors')#line:79
NOTIFY =wiz .getS ('notify')#line:80
NOTEDISMISS =wiz .getS ('notedismiss')#line:81
NOTEID =wiz .getS ('noteid')#line:82
NOTIFY2 =wiz .getS ('notify2')#line:83
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:84
NOTEID2 =wiz .getS ('noteid2')#line:85
NOTIFY3 =wiz .getS ('notify3')#line:86
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:87
NOTEID3 =wiz .getS ('noteid3')#line:88
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:89
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:90
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:91
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:92
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:93
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:94
TODAY =date .today ()#line:95
TOMORROW =TODAY +timedelta (days =1 )#line:96
TWODAYS =TODAY +timedelta (days =2 )#line:97
THREEDAYS =TODAY +timedelta (days =3 )#line:98
ONEWEEK =TODAY +timedelta (days =7 )#line:99
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:100
EXCLUDES =uservar .EXCLUDES #line:101
SPEEDFILE =speedtest .SPEEDFILE #line:102
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:103
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:104
NOTIFICATION =uservar .NOTIFICATION #line:105
NOTIFICATION2 =uservar .NOTIFICATION2 #line:106
NOTIFICATION3 =uservar .NOTIFICATION3 #line:107
ENABLE =uservar .ENABLE #line:108
UNAME =speedtest .UNAME #line:109
HEADERMESSAGE =uservar .HEADERMESSAGE #line:110
AUTOUPDATE =uservar .AUTOUPDATE #line:111
WIZARDFILE =uservar .WIZARDFILE #line:112
AUTOINSTALL =uservar .AUTOINSTALL #line:113
REPOID =uservar .REPOID #line:114
REPOADDONXML =uservar .REPOADDONXML #line:115
REPOZIPURL =uservar .REPOZIPURL #line:116
REPOID18 =uservar .REPOID18 #line:117
REPOADDONXML18 =uservar .REPOADDONXML18 #line:118
REPOZIPURL18 =uservar .REPOZIPURL18 #line:119
REQUESTSID =uservar .REQUESTSID #line:121
REQUESTSXML =uservar .REQUESTSXML #line:122
REQUESTSURL =uservar .REQUESTSURL #line:123
COLOR1 =uservar .COLOR1 #line:127
COLOR2 =uservar .COLOR2 #line:128
TMDB_NEW_API =uservar .TMDB_NEW_API #line:129
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:130
FAILED =False #line:131
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:132
AddonID ='plugin.program.Anonymous'#line:134
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:135
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:136
dialog =xbmcgui .Dialog ()#line:137
setting =xbmcaddon .Addon ().getSetting #line:138
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:139
notify_mode =setting ('notify_mode')#line:140
auto_clean =setting ('startup.cache')#line:141
filesize_thumb =int (setting ('filesizethumb_alert'))#line:143
total_size2 =0 #line:146
total_size =0 #line:147
count =0 #line:148
def infobuild ():#line:159
	O000000OO00OOOO0O =wiz .workingURL (NOTIFICATION )#line:160
	if O000000OO00OOOO0O ==True :#line:161
		try :#line:162
			OO0O000OO0000OOO0 ,O0000000OOOOO0OO0 =wiz .splitNotify (NOTIFICATION )#line:163
			if OO0O000OO0000OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:164
			if STARTP2 ()=='ok':#line:165
				notify .updateinfo (O0000000OOOOO0OO0 ,True )#line:166
		except Exception as OOOOOOO00O000OO0O :#line:167
			wiz .log ("Error on Notifications Window: %s"%str (OOOOOOO00O000OO0O ),xbmc .LOGERROR )#line:168
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:169
def disply_hwr ():#line:170
   try :#line:171
    O0OOO0OOOO0000O00 =tmdb_list (TMDB_NEW_API )#line:172
    OOOOOO0OO0O0000O0 =str ((getHwAddr ('eth0'))*O0OOO0OOOO0000O00 )#line:173
    O00O0O00O00O00O00 =(OOOOOO0OO0O0000O0 [1 ]+OOOOOO0OO0O0000O0 [2 ]+OOOOOO0OO0O0000O0 [5 ]+OOOOOO0OO0O0000O0 [7 ])#line:180
    OO0O00O000OO00OO0 =(ADDON .getSetting ("action"))#line:181
    wiz .setS ('action',str (O00O0O00O00O00O00 ))#line:183
   except :pass #line:184
def getHwAddr (OOOOO0OO0O000OO0O ):#line:185
   import subprocess ,time #line:186
   O00O000OO00000O0O ='windows'#line:187
   if xbmc .getCondVisibility ('system.platform.android'):#line:188
       O00O000OO00000O0O ='android'#line:189
   if xbmc .getCondVisibility ('system.platform.android'):#line:190
     O0OO00OO00O000OOO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:191
     O0O0O0OOOO0O00OOO =re .compile ('link/ether (.+?) brd').findall (str (O0OO00OO00O000OOO ))#line:193
     OO0OOO0000O0O0000 =0 #line:194
     for OOO0O0OOO0O000OO0 in O0O0O0OOOO0O00OOO :#line:195
      if O0O0O0OOOO0O00OOO !='00:00:00:00:00:00':#line:196
          OO00OO00O0O00OO00 =OOO0O0OOO0O000OO0 #line:197
          OO0OOO0000O0O0000 =OO0OOO0000O0O0000 +int (OO00OO00O0O00OO00 .replace (':',''),16 )#line:198
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:200
       O0OOOOO0O0O0OO00O =0 #line:201
       OO0OOO0000O0O0000 =0 #line:202
       O0000O0OO00O00OO0 =[]#line:203
       O00OO000O0O000OOO =os .popen ("getmac").read ()#line:204
       O00OO000O0O000OOO =O00OO000O0O000OOO .split ("\n")#line:205
       for OOO0O00O0O000O0O0 in O00OO000O0O000OOO :#line:207
            O00O0O0OO0OOO0O00 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0O00O0O000O0O0 ,re .I )#line:208
            if O00O0O0OO0OOO0O00 :#line:209
                O0O0O0OOOO0O00OOO =O00O0O0OO0OOO0O00 .group ().replace ('-',':')#line:210
                O0000O0OO00O00OO0 .append (O0O0O0OOOO0O00OOO )#line:211
                OO0OOO0000O0O0000 =OO0OOO0000O0O0000 +int (O0O0O0OOOO0O00OOO .replace (':',''),16 )#line:214
   else :#line:216
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:217
   try :#line:234
    return OO0OOO0000O0O0000 #line:235
   except :pass #line:236
def decode (OOO0O0O00O00O00O0 ,OO000O0OO00O000OO ):#line:237
    import base64 #line:238
    O00O0000O0O0OOOOO =[]#line:239
    if (len (OOO0O0O00O00O00O0 ))!=4 :#line:241
     return 10 #line:242
    OO000O0OO00O000OO =base64 .urlsafe_b64decode (OO000O0OO00O000OO )#line:243
    for OOOO00O00O0OOO0O0 in range (len (OO000O0OO00O000OO )):#line:245
        O00O0OO0OO0OOO0OO =OOO0O0O00O00O00O0 [OOOO00O00O0OOO0O0 %len (OOO0O0O00O00O00O0 )]#line:246
        OOOO0O0OO00O0O000 =chr ((256 +ord (OO000O0OO00O000OO [OOOO00O00O0OOO0O0 ])-ord (O00O0OO0OO0OOO0OO ))%256 )#line:247
        O00O0000O0O0OOOOO .append (OOOO0O0OO00O0O000 )#line:248
    return "".join (O00O0000O0O0OOOOO )#line:249
def tmdb_list (O0OO0OOO0O0O0OOO0 ):#line:250
    O0O0O0O0O0OO0OO00 =decode ("7643",O0OO0OOO0O0O0OOO0 )#line:253
    return int (O0O0O0O0O0OO0OO00 )#line:256
def u_list (OO00OO00000OO0OO0 ):#line:257
    from math import sqrt #line:259
    OO0OOOO00O0OO0000 =tmdb_list (TMDB_NEW_API )#line:260
    O0OO0O00O0OOOOO00 =str ((getHwAddr ('eth0'))*OO0OOOO00O0OO0000 )#line:262
    O0000OOO0O000000O =int (O0OO0O00O0OOOOO00 [1 ]+O0OO0O00O0OOOOO00 [2 ]+O0OO0O00O0OOOOO00 [5 ]+O0OO0O00O0OOOOO00 [7 ])#line:263
    OO0O0O0O0O000OOO0 =(ADDON .getSetting ("pass"))#line:265
    OO00OO0OOOOO0O00O =(str (round (sqrt ((O0000OOO0O000000O *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:270
    if '.'in OO00OO0OOOOO0O00O :#line:271
     OO00OO0OOOOO0O00O =(str (round (sqrt ((O0000OOO0O000000O *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:272
    if OO0O0O0O0O000OOO0 ==OO00OO0OOOOO0O00O :#line:273
      OOO0OO000O00O0O0O =OO00OO00000OO0OO0 #line:275
    else :#line:277
       if STARTP ()and STARTP2 ()=='ok':#line:278
         return OO00OO00000OO0OO0 #line:280
       OOO0OO000O00O0O0O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:281
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:282
       sys .exit ()#line:283
    return OOO0OO000O00O0O0O #line:284
try :#line:285
   disply_hwr ()#line:286
except :#line:287
   pass #line:288
def dis_or_enable_addon (O0OO000O00OO0OOO0 ,O0O000OO0O00OO0O0 ,enable ="true"):#line:289
    import json #line:290
    O00O00OOOO00O00OO ='"%s"'%O0OO000O00OO0OOO0 #line:291
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OO000O00OO0OOO0 )and enable =="true":#line:292
        logging .warning ('already Enabled')#line:293
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OO000O00OO0OOO0 )#line:294
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OO000O00OO0OOO0 )and enable =="false":#line:295
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OO000O00OO0OOO0 )#line:296
    else :#line:297
        OOO000O000O0OOO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O00OOOO00O00OO ,enable )#line:298
        O0O0000000OOO00O0 =xbmc .executeJSONRPC (OOO000O000O0OOO0O )#line:299
        O00OO0O000000O0OO =json .loads (O0O0000000OOO00O0 )#line:300
        if enable =="true":#line:301
            xbmc .log ("### Enabled %s, response = %s"%(O0OO000O00OO0OOO0 ,O00OO0O000000O0OO ))#line:302
        else :#line:303
            xbmc .log ("### Disabled %s, response = %s"%(O0OO000O00OO0OOO0 ,O00OO0O000000O0OO ))#line:304
    if O0O000OO0O00OO0O0 =='auto':#line:305
     return True #line:306
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:307
def update_Votes ():#line:308
   try :#line:309
        import requests #line:310
        OO0OO0OOOOOO0OOO0 ='18773068'#line:311
        O0O0O00O0O000OO00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0OO0OOOOOO0OOO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:323
        OO00OOOOOOOOOOO0O ='145273321'#line:325
        OOOO00O0OO00O0O0O ={'options':OO00OOOOOOOOOOO0O }#line:331
        O0O00O0O0OOO0OO00 =requests .post ('https://www.strawpoll.me/'+OO0OO0OOOOOO0OOO0 ,headers =O0O0O00O0O000OO00 ,data =OOOO00O0OO00O0O0O )#line:333
   except :pass #line:334
def display_Votes ():#line:335
    try :#line:336
        OO0OOO00000O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:337
        OO0OO00OOO0OOO000 =open (OO0OOO00000O00OOO ,'r')#line:339
        O0OOO000OO0O0O00O =OO0OO00OOO0OOO000 .read ()#line:340
        OO0OO00OOO0OOO000 .close ()#line:341
        OOO0O00OOOO0OOO00 ='<setting id="HomeS" type="string">(.+?)</setting>'#line:342
        OO0OO0OO00O00O0O0 =re .compile (OOO0O00OOOO0OOO00 ).findall (O0OOO000OO0O0O00O )[0 ]#line:344
        import requests #line:350
        OO000OOO000O0O0OO ='18782966'#line:351
        OO0OOOO0O00000000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO000OOO000O0O0OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:363
        O000O00OO0OO0O0O0 ='145313053'#line:365
        O00O0OO0OO0000OO0 ='145313054'#line:366
        OO000OO00O0OOOO00 ='145313057'#line:367
        OOO000000OO0000O0 ='145313058'#line:368
        OO0O0OOO00OO0OOOO ='145313055'#line:369
        O00OO0OOO0O0OOO0O ='145313060'#line:370
        OOOO0OO0O0OOOO0OO ='145313056'#line:371
        OO0O0O0O0000000OO ='145313059'#line:372
        if OO0OO0OO00O00O0O0 =='emin':#line:375
           OOO00OOO00O0O000O =O000O00OO0OO0O0O0 #line:376
        if OO0OO0OO00O00O0O0 =='nox':#line:377
           OOO00OOO00O0O000O =O00O0OO0OO0000OO0 #line:378
        if OO0OO0OO00O00O0O0 =='noxtitan':#line:379
           OOO00OOO00O0O000O =O00O0OO0OO0000OO0 #line:380
        if OO0OO0OO00O00O0O0 =='titan':#line:381
           OOO00OOO00O0O000O =OO000OO00O0OOOO00 #line:382
        if OO0OO0OO00O00O0O0 =='pheno':#line:383
           OOO00OOO00O0O000O =OOO000000OO0000O0 #line:384
        if OO0OO0OO00O00O0O0 =='netflix':#line:385
           OOO00OOO00O0O000O =OO0O0OOO00OO0OOOO #line:386
        if OO0OO0OO00O00O0O0 =='nebula':#line:387
           OOO00OOO00O0O000O =O00OO0OOO0O0OOO0O #line:388
        if OO0OO0OO00O00O0O0 =='pellucid':#line:389
           OOO00OOO00O0O000O =OOOO0OO0O0OOOO0OO #line:390
        if OO0OO0OO00O00O0O0 =='pellucid2':#line:391
           OOO00OOO00O0O000O =OO0O0O0O0000000OO #line:392
        O0O0OO0OOOO0OO0O0 ={'options':OOO00OOO00O0O000O }#line:398
        O0OOO0OOO00OOO0O0 =requests .post ('https://www.strawpoll.me/'+OO000OOO000O0O0OO ,headers =OO0OOOO0O00000000 ,data =O0O0OO0OOOO0OO0O0 )#line:400
    except :pass #line:401
def resetkodi ():#line:402
		if xbmc .getCondVisibility ('system.platform.windows'):#line:403
			O0000O00O00O0O0O0 =xbmcgui .DialogProgress ()#line:404
			O0000O00O00O0O0O0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:407
			O0000O00O00O0O0O0 .update (0 )#line:408
			for O00O00O000O0OO000 in range (5 ,-1 ,-1 ):#line:409
				time .sleep (1 )#line:410
				O0000O00O00O0O0O0 .update (int ((5 -O00O00O000O0OO000 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O00O00O000O0OO000 ),'')#line:411
				if O0000O00O00O0O0O0 .iscanceled ():#line:412
					from resources .libs import win #line:413
					return None ,None #line:414
			from resources .libs import win #line:415
		else :#line:416
			O0000O00O00O0O0O0 =xbmcgui .DialogProgress ()#line:417
			O0000O00O00O0O0O0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:420
			O0000O00O00O0O0O0 .update (0 )#line:421
			for O00O00O000O0OO000 in range (5 ,-1 ,-1 ):#line:422
				time .sleep (1 )#line:423
				O0000O00O00O0O0O0 .update (int ((5 -O00O00O000O0OO000 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O00O00O000O0OO000 ),'')#line:424
				if O0000O00O00O0O0O0 .iscanceled ():#line:425
					os ._exit (1 )#line:426
					return None ,None #line:427
			os ._exit (1 )#line:428
def indicatorfastupdate ():#line:429
       try :#line:430
          import json #line:431
          wiz .log ('FRESH MESSAGE')#line:432
          O0OOO0OOOO000OO0O =(ADDON .getSetting ("user"))#line:433
          OOOOO00OO00O000OO =(ADDON .getSetting ("pass"))#line:434
          OOO0O000O0O0000O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:435
          O0000OO0OOOO00000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:437
          OOOO0O00OOO0OO00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:438
          O00O00OO00000O0OO =str (json .loads (OOOO0O00OOO0OO00O )['ip'])#line:439
          OOO00O000OO0O0000 =O0OOO0OOOO000OO0O #line:440
          O00O00O00OO00O000 =OOOOO00OO00O000OO #line:441
          import socket #line:442
          OOOO0O00OOO0OO00O =urllib2 .urlopen (O0000OO0OOOO00000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOO00O000OO0O0000 +' - '+O00O00O00OO00O000 +' - '+OOO0O000O0O0000O0 +' - '+O00O00OO00000O0OO ).readlines ()#line:443
       except :pass #line:445
def skindialogsettind18 ():#line:446
	try :#line:447
		O0OOO00OO000O0000 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:448
		O0OOO0O00OO00OOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:449
		copyfile (O0OOO00OO000O0000 ,O0OOO0O00OO00OOO0 )#line:450
	except :pass #line:451
def telemedia_android5fix ():#line:452
    OO00000O00OO0000O =Addon .getSetting ('systemtype')#line:453
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in OO00000O00OO0000O :#line:454
        OO000OO0O0OO000OO ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:456
        O000OOO000O0O0O00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:457
        O0OO00OO00O0OOO00 =xbmcgui .DialogProgress ()#line:458
        O0OO00OO00O0OOO00 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:459
        O0OOOO00OOO0OO000 =os .path .join (PACKAGES ,'isr.zip')#line:460
        O0OO00000O0O0OOOO =urllib2 .Request (OO000OO0O0OO000OO )#line:461
        O0O0OO0O0000O00OO =urllib2 .urlopen (O0OO00000O0O0OOOO )#line:462
        OOOOOO000O000O000 =xbmcgui .DialogProgress ()#line:464
        OOOOOO000O000O000 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:465
        OOOOOO000O000O000 .update (0 )#line:466
        OOO00O000OO0OO000 =open (O0OOOO00OOO0OO000 ,'wb')#line:468
        try :#line:470
          O000000OO0000O000 =O0O0OO0O0000O00OO .info ().getheader ('Content-Length').strip ()#line:471
          OO0O0OO0O0OOO00OO =True #line:472
        except AttributeError :#line:473
              OO0O0OO0O0OOO00OO =False #line:474
        if OO0O0OO0O0OOO00OO :#line:476
              O000000OO0000O000 =int (O000000OO0000O000 )#line:477
        O0OOOO0O0O0OOO00O =0 #line:479
        O0OO0000000OO0000 =time .time ()#line:480
        while True :#line:481
              OOO0O000000OOOOO0 =O0O0OO0O0000O00OO .read (8192 )#line:482
              if not OOO0O000000OOOOO0 :#line:483
                  sys .stdout .write ('\n')#line:484
                  break #line:485
              O0OOOO0O0O0OOO00O +=len (OOO0O000000OOOOO0 )#line:487
              OOO00O000OO0OO000 .write (OOO0O000000OOOOO0 )#line:488
              if not OO0O0OO0O0OOO00OO :#line:490
                  O000000OO0000O000 =O0OOOO0O0O0OOO00O #line:491
              if OOOOOO000O000O000 .iscanceled ():#line:492
                 OOOOOO000O000O000 .close ()#line:493
                 try :#line:494
                  os .remove (O0OOOO00OOO0OO000 )#line:495
                 except :#line:496
                  pass #line:497
                 break #line:498
              OO0OO0OO000O00O0O =float (O0OOOO0O0O0OOO00O )/O000000OO0000O000 #line:499
              OO0OO0OO000O00O0O =round (OO0OO0OO000O00O0O *100 ,2 )#line:500
              O0O000O0O00OOOO00 =O0OOOO0O0O0OOO00O /(1024 *1024 )#line:501
              OOOOOO00OOO000O0O =O000000OO0000O000 /(1024 *1024 )#line:502
              O0OO0000O00O0O000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O000O0O00OOOO00 ,'teal',OOOOOO00OOO000O0O )#line:503
              if (time .time ()-O0OO0000000OO0000 )>0 :#line:504
                OOO0O00OO0OO0O00O =O0OOOO0O0O0OOO00O /(time .time ()-O0OO0000000OO0000 )#line:505
                OOO0O00OO0OO0O00O =OOO0O00OO0OO0O00O /1024 #line:506
              else :#line:507
               OOO0O00OO0OO0O00O =0 #line:508
              O0O0OOOOO00OO0000 ='KB'#line:509
              if OOO0O00OO0OO0O00O >=1024 :#line:510
                 OOO0O00OO0OO0O00O =OOO0O00OO0OO0O00O /1024 #line:511
                 O0O0OOOOO00OO0000 ='MB'#line:512
              if OOO0O00OO0OO0O00O >0 and not OO0OO0OO000O00O0O ==100 :#line:513
                  O0000O00OO00OOOOO =(O000000OO0000O000 -O0OOOO0O0O0OOO00O )/OOO0O00OO0OO0O00O #line:514
              else :#line:515
                  O0000O00OO00OOOOO =0 #line:516
              OO0O0O0OOO0OO0OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O00OO0OO0O00O ,O0O0OOOOO00OO0000 )#line:517
              OOOOOO000O000O000 .update (int (OO0OO0OO000O00O0O ),O0OO0000O00O0O000 ,OO0O0O0OOO0OO0OOO +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:519
        OOOO00OOO00OOO0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:522
        OOO00O000OO0OO000 .close ()#line:525
        extract .all (O0OOOO00OOO0OO000 ,OOOO00OOO00OOO0OO ,OOOOOO000O000O000 )#line:526
        try :#line:530
          os .remove (O0OOOO00OOO0OO000 )#line:531
        except :#line:532
          pass #line:533
def checkidupdate ():#line:534
				OOO0OO00O00000000 =True #line:535
				wiz .setS ("notedismiss","true")#line:536
				OOO00OO0OOOOOOOO0 =wiz .workingURL (NOTIFICATION )#line:537
				O00O00O0OO000OO00 =" Kodi Premium"#line:539
				O000OOOO0O00O00OO =wiz .checkBuild (O00O00O0OO000OO00 ,'gui')#line:540
				O000OOOO000O00OOO =O00O00O0OO000OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:541
				if not wiz .workingURL (O000OOOO0O00O00OO )==True :return #line:542
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:543
				O0OOOOO0OO00O00O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000OOOO000O00OOO )#line:546
				try :os .remove (O0OOOOO0OO00O00O0 )#line:547
				except :pass #line:548
				if 'google'in O000OOOO0O00O00OO :#line:550
				   O0O0O00O00O0000OO =googledrive_download (O000OOOO0O00O00OO ,O0OOOOO0OO00O00O0 ,DP2 ,wiz .checkBuild (O00O00O0OO000OO00 ,'filesize'))#line:551
				else :#line:554
				  downloaderbg .download3 (O000OOOO0O00O00OO ,O0OOOOO0OO00O00O0 ,DP2 )#line:555
				xbmc .sleep (100 )#line:556
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:557
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:559
				extract .all2 (O0OOOOO0OO00O00O0 ,HOME ,DP2 )#line:561
				DP2 .close ()#line:562
				wiz .defaultSkin ()#line:563
				wiz .lookandFeelData ('save')#line:564
				try :#line:565
					telemedia_android5fix ()#line:566
				except :pass #line:567
				wiz .kodi17Fix ()#line:568
				if KODIV >=18 :#line:569
					skindialogsettind18 ()#line:570
				debridit .debridIt ('restore','all')#line:575
				traktit .traktIt ('restore','all')#line:576
				if INSTALLMETHOD ==1 :OOO00O0O0OO000000 =1 #line:577
				elif INSTALLMETHOD ==2 :OOO00O0O0OO000000 =0 #line:578
				else :DP2 .close ()#line:579
				O0000O0OOOO00OOOO =(NOTIFICATION2 )#line:580
				OOO00O0000OOOOOO0 =urllib2 .urlopen (O0000O0OOOO00OOOO )#line:581
				OOO0000OOO00O0O0O =OOO00O0000OOOOOO0 .readlines ()#line:582
				OOOO0OOOO0OOOO0OO =0 #line:583
				for O0O0OO0OO00OO0OO0 in OOO0000OOO00O0O0O :#line:586
					if O0O0OO0OO00OO0OO0 .split (' ==')[0 ]=="noreset"or O0O0OO0OO00OO0OO0 .split ()[0 ]=="noreset":#line:587
						xbmc .executebuiltin ("ReloadSkin()")#line:589
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:590
						O0O0O000OO00O0000 =(ADDON .getSetting ("message"))#line:591
						if O0O0O000OO00O0000 =='true':#line:592
							infobuild ()#line:593
						update_Votes ()#line:594
						indicatorfastupdate ()#line:595
					if O0O0OO0OO00OO0OO0 .split (' ==')[0 ]=="reset"or O0O0OO0OO00OO0OO0 .split ()[0 ]=="reset":#line:596
						update_Votes ()#line:598
						indicatorfastupdate ()#line:599
						resetkodi ()#line:600
def checkvictory ():#line:601
				wiz .setS ("notedismiss2","true")#line:603
				O00OO0000O00OOO0O =wiz .workingURL (NOTIFICATION2 )#line:604
				O0O000OO0O00OOOO0 =" Kodi Premium"#line:606
				O0000O0O0O0O0O000 ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:607
				OO0O00OO0000O00OO =O0O000OO0O00OOOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:608
				if not wiz .workingURL (O0000O0O0O0O0O000 )==True :return #line:609
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:610
				O000O0O0O00O00000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O00OO0000O00OO )#line:613
				try :os .remove (O000O0O0O00O00000 )#line:614
				except :pass #line:615
				if 'google'in O0000O0O0O0O0O000 :#line:617
				   OOO00000OO000OO00 =googledrive_download (O0000O0O0O0O0O000 ,O000O0O0O00O00000 ,DP2 ,wiz .checkBuild (O0O000OO0O00OOOO0 ,'filesize'))#line:618
				else :#line:621
				  downloaderbg .download5 (O0000O0O0O0O0O000 ,O000O0O0O00O00000 ,DP2 )#line:622
				xbmc .sleep (100 )#line:623
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:624
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:626
				extract .all2 (O000O0O0O00O00000 ,ADDONS ,DP2 )#line:628
				DP2 .close ()#line:629
				wiz .defaultSkin ()#line:630
				wiz .lookandFeelData ('save')#line:631
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:632
				if INSTALLMETHOD ==1 :O0OOO0O00O00000OO =1 #line:634
				elif INSTALLMETHOD ==2 :O0OOO0O00O00000OO =0 #line:635
				else :DP2 .close ()#line:636
def checkUpdate ():#line:641
	O00OO0OO0O000O00O =wiz .getS ('buildname')#line:642
	OO0O000O00000OOOO =wiz .getS ('buildversion')#line:643
	OO0O000O0O0OO0OO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:644
	OOOOOO0OOOO0O00O0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O00OO0OO0O000O00O ).findall (OO0O000O0O0OO0OO0 )#line:645
	if len (OOOOOO0OOOO0O00O0 )>0 :#line:646
		O0O0O00O0O00O00O0 =OOOOOO0OOOO0O00O0 [0 ][0 ]#line:647
		O0OOO0000OO0O0O00 =OOOOOO0OOOO0O00O0 [0 ][1 ]#line:648
		OO0O0O00OO000OOO0 =OOOOOO0OOOO0O00O0 [0 ][2 ]#line:649
		wiz .setS ('latestversion',O0O0O00O0O00O00O0 )#line:650
		if O0O0O00O0O00O00O0 >OO0O000O00000OOOO :#line:651
			if DISABLEUPDATE =='false':#line:652
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OO0O000O00000OOOO ,O0O0O00O0O00O00O0 ),xbmc .LOGNOTICE )#line:653
				notify .updateWindow (O00OO0OO0O000O00O ,OO0O000O00000OOOO ,O0O0O00O0O00O00O0 ,O0OOO0000OO0O0O00 ,OO0O0O00OO000OOO0 )#line:654
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OO0O000O00000OOOO ,O0O0O00O0O00O00O0 ),xbmc .LOGNOTICE )#line:655
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OO0O000O00000OOOO ,O0O0O00O0O00O00O0 ),xbmc .LOGNOTICE )#line:656
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:657
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:692
if AUTOUPDATE =='Yes':#line:693
	input =(ADDON .getSetting ("autoupdate"))#line:694
	xbmc .executebuiltin ("UpdateLocalAddons")#line:695
	xbmc .executebuiltin ("UpdateAddonRepos")#line:696
	wiz .wizardUpdate ('startup')#line:697
if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'skin.estuary'):#line:702
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:703
    setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")#line:705
    src =os .path .join (xbmc .translatePath ("special://home/"),"addons/skin.estuary")#line:706
    extract .all (setting_file ,src )#line:709
    wiz .kodi17Fix ()#line:721
    if KODIV >=18 :#line:723
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","addon.xml")#line:725
        with open (setting_file ,'r')as file :#line:726
          filedata =file .read ()#line:727
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.12.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.14.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''')#line:776
        with open (setting_file ,'w')as file :#line:779
          file .write (filedata )#line:780
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")#line:786
        with open (setting_file ,'r')as file :#line:787
          filedata =file .read ()#line:788
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">2</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="-" />
			<param name="DialogHeaderId" value="20" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="99">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>9</onleft>
			<onright>9</onright>
			<onup>2</onup>
			<ondown>2</ondown>
		</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(9).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(9).HasNext</visible>
		</control>
		<control type="grouplist" id="2">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>9</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="10">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>12</onleft>
				<onright>11</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
			<control type="button" id="11">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>10</onleft>
				<onright>12</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="13">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="3">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="4">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="5">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="7">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="6">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="8">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">5</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="" />
			<param name="DialogHeaderId" value="2" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="3">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>3</onleft>
			<onright>3</onright>
			<onup>5</onup>
			<ondown>5</ondown>
		</control>
			<control type="button" id="10">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
			</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(3).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(3).HasNext</visible>
		</control>
		<control type="grouplist" id="5">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>3</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="28">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
			<control type="button" id="29">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="10">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="7">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="8">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="9">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="14">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="11">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="13">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''')#line:1179
        with open (setting_file ,'w')as file :#line:1182
          file .write (filedata )#line:1183
    wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:1191
    xbmc .executebuiltin ("ReloadSkin()")#line:1192
    xbmc .executebuiltin ("ActivateWindow(home)")#line:1193
    f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:1194
    xbmc .Player ().play (f_play ,windowed =False )#line:1195
def setuname ():#line:1322
    OO000O00O00O0OO00 =''#line:1323
    O0OO00O0OOO0O0OOO =xbmc .Keyboard (OO000O00O00O0OO00 ,'הכנס שם משתמש')#line:1324
    O0OO00O0OOO0O0OOO .doModal ()#line:1325
    if O0OO00O0OOO0O0OOO .isConfirmed ():#line:1326
           OO000O00O00O0OO00 =O0OO00O0OOO0O0OOO .getText ()#line:1327
           wiz .setS ('user',str (OO000O00O00O0OO00 ))#line:1328
def STARTP2 ():#line:1329
	if BUILDNAME ==" Kodi Premium":#line:1330
		O0O0O0OOOOO0OO00O =(ADDON .getSetting ("user"))#line:1331
		OOOOOO00OOOOOO00O =(UNAME )#line:1332
		OOO00000O00000000 =urllib2 .urlopen (OOOOOO00OOOOOO00O )#line:1333
		OOO0OO00O000O0OO0 =OOO00000O00000000 .readlines ()#line:1334
		O000OOO0O0O0O0OOO =0 #line:1335
		for O00OOOOOOO0O00OO0 in OOO0OO00O000O0OO0 :#line:1336
			if O00OOOOOOO0O00OO0 .split (' ==')[0 ]==O0O0O0OOOOO0OO00O or O00OOOOOOO0O00OO0 .split ()[0 ]==O0O0O0OOOOO0OO00O :#line:1337
				O000OOO0O0O0O0OOO =1 #line:1338
				break #line:1339
		if O000OOO0O0O0O0OOO ==0 :#line:1340
			O000000O000000OO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:1342
			if O000000O000000OO0 :#line:1344
				ADDON .openSettings ()#line:1345
				sys .exit ()#line:1346
			else :#line:1347
				sys .exit ()#line:1348
		return 'ok'#line:1352
def skinWIN ():#line:1355
	idle ()#line:1356
	OOO00O000OOO00OO0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:1357
	O0O0000OO00OO000O =[];O0O0OO0OOO0OOO0O0 =[]#line:1358
	for O000OO0OOOOOO0000 in sorted (OOO00O000OOO00OO0 ,key =lambda OO00OOO0O0OO0000O :OO00OOO0O0OO0000O ):#line:1359
		OO0O0OOOO000000OO =os .path .split (O000OO0OOOOOO0000 [:-1 ])[1 ]#line:1360
		OO0OOOO0OO0OOO000 =os .path .join (O000OO0OOOOOO0000 ,'addon.xml')#line:1361
		if os .path .exists (OO0OOOO0OO0OOO000 ):#line:1362
			O0O0OO00OOOO00O0O =open (OO0OOOO0OO0OOO000 )#line:1363
			O0OOO00O0O0O0OOOO =O0O0OO00OOOO00O0O .read ()#line:1364
			O00O0O0OOO000O0OO =parseDOM2 (O0OOO00O0O0O0OOOO ,'addon',ret ='id')#line:1365
			OOOOO00O000000OOO =OO0O0OOOO000000OO if len (O00O0O0OOO000O0OO )==0 else O00O0O0OOO000O0OO [0 ]#line:1366
			try :#line:1367
				OOOO00O0O00OOO0O0 =xbmcaddon .Addon (id =OOOOO00O000000OOO )#line:1368
				O0O0000OO00OO000O .append (OOOO00O0O00OOO0O0 .getAddonInfo ('name'))#line:1369
				O0O0OO0OOO0OOO0O0 .append (OOOOO00O000000OOO )#line:1370
			except :#line:1371
				pass #line:1372
	O000O00OOOOO0000O =[];O00OO0OO0000000OO =0 #line:1373
	O0OO00OOOOOOOOOOO =["Current Skin -- %s"%currSkin ()]+O0O0000OO00OO000O #line:1374
	O00OO0OO0000000OO =DIALOG .select ("Select the Skin you want to swap with.",O0OO00OOOOOOOOOOO )#line:1375
	if O00OO0OO0000000OO ==-1 :return #line:1376
	else :#line:1377
		O0000OO0OO000O0OO =(O00OO0OO0000000OO -1 )#line:1378
		O000O00OOOOO0000O .append (O0000OO0OO000O0OO )#line:1379
		O0OO00OOOOOOOOOOO [O00OO0OO0000000OO ]="%s"%(O0O0000OO00OO000O [O0000OO0OO000O0OO ])#line:1380
	if O000O00OOOOO0000O ==None :return #line:1381
	for O0O0OO00000000000 in O000O00OOOOO0000O :#line:1382
		swapSkins (O0O0OO0OOO0OOO0O0 [O0O0OO00000000000 ])#line:1383
def currSkin ():#line:1385
	return xbmc .getSkinDir ('Container.PluginName')#line:1386
def fix17update ():#line:1388
	if KODIV >=17 and KODIV <18 :#line:1389
		wiz .kodi17Fix ()#line:1390
		xbmc .sleep (4000 )#line:1391
		try :#line:1392
			OOO0O00OO0OOOO0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1393
			OO00000000OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1394
			os .rename (OOO0O00OO0OOOO0O0 ,OO00000000OOOOO00 )#line:1395
		except :#line:1396
				pass #line:1397
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1398
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1399
		fixfont ()#line:1400
		O00O0000O0O0O000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1401
		try :#line:1403
			O000000OOO0O0000O =open (O00O0000O0O0O000O ,'r')#line:1404
			OO0OOOO0OO00000OO =O000000OOO0O0000O .read ()#line:1405
			O000000OOO0O0000O .close ()#line:1406
			O00OOO0OO000OOO00 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:1407
			OO00OO000O0OOOO0O =re .compile (O00OOO0OO000OOO00 ).findall (OO0OOOO0OO00000OO )[0 ]#line:1408
			O000000OOO0O0000O =open (O00O0000O0O0O000O ,'w')#line:1409
			O000000OOO0O0000O .write (OO0OOOO0OO00000OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO00OO000O0OOOO0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:1410
			O000000OOO0O0000O .close ()#line:1411
		except :#line:1412
				pass #line:1413
		wiz .kodi17Fix ()#line:1414
		O00O0000O0O0O000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1415
		try :#line:1416
			O000000OOO0O0000O =open (O00O0000O0O0O000O ,'r')#line:1417
			OO0OOOO0OO00000OO =O000000OOO0O0000O .read ()#line:1418
			O000000OOO0O0000O .close ()#line:1419
			O00OOO0OO000OOO00 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:1420
			OO00OO000O0OOOO0O =re .compile (O00OOO0OO000OOO00 ).findall (OO0OOOO0OO00000OO )[0 ]#line:1421
			O000000OOO0O0000O =open (O00O0000O0O0O000O ,'w')#line:1422
			O000000OOO0O0000O .write (OO0OOOO0OO00000OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO00OO000O0OOOO0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:1423
			O000000OOO0O0000O .close ()#line:1424
		except :#line:1425
				pass #line:1426
		swapSkins ('skin.Premium.mod')#line:1427
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1428
	os ._exit (1 )#line:1429
def fix18update ():#line:1430
	if KODIV >=18 :#line:1431
		xbmc .sleep (4000 )#line:1432
		if BUILDNAME =="":#line:1433
			try :#line:1434
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:1435
			except :#line:1436
				pass #line:1437
		try :#line:1438
			OOOO0OOO00OOO00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1439
			OO0O000000O00OOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1440
			os .rename (OOOO0OOO00OOO00O0 ,OO0O000000O00OOOO )#line:1441
		except :#line:1442
				pass #line:1443
		skindialogsettind18 ()#line:1444
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1445
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1446
		fixfont ()#line:1447
		OOO0OO0O0000OO0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1448
		try :#line:1449
			OOO00000000OO000O =open (OOO0OO0O0000OO0O0 ,'r')#line:1450
			OO00O00O0O00OO00O =OOO00000000OO000O .read ()#line:1451
			OOO00000000OO000O .close ()#line:1452
			O0000OOOO0O0O0OO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:1453
			O0O00O0OO0OO00O0O =re .compile (O0000OOOO0O0O0OO0 ).findall (OO00O00O0O00OO00O )[0 ]#line:1454
			OOO00000000OO000O =open (OOO0OO0O0000OO0O0 ,'w')#line:1455
			OOO00000000OO000O .write (OO00O00O0O00OO00O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O00O0OO0OO00O0O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:1456
			OOO00000000OO000O .close ()#line:1457
		except :#line:1458
				pass #line:1459
		wiz .kodi17Fix ()#line:1460
		OOO0OO0O0000OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1461
		try :#line:1462
			OOO00000000OO000O =open (OOO0OO0O0000OO0O0 ,'r')#line:1463
			OO00O00O0O00OO00O =OOO00000000OO000O .read ()#line:1464
			OOO00000000OO000O .close ()#line:1465
			O0000OOOO0O0O0OO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:1466
			O0O00O0OO0OO00O0O =re .compile (O0000OOOO0O0O0OO0 ).findall (OO00O00O0O00OO00O )[0 ]#line:1467
			OOO00000000OO000O =open (OOO0OO0O0000OO0O0 ,'w')#line:1468
			OOO00000000OO000O .write (OO00O00O0O00OO00O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O00O0OO0OO00O0O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:1469
			OOO00000000OO000O .close ()#line:1470
		except :#line:1471
				pass #line:1472
		swapSkins ('skin.Premium.mod')#line:1473
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1474
	os ._exit (1 )#line:1475
def swapSkins (OOOOO0O00OO0OOO00 ,title ="Error"):#line:1476
	O0000O0000OO0O0OO ='lookandfeel.skin'#line:1477
	OOO0OOOO0OO0OOOOO =OOOOO0O00OO0OOO00 #line:1478
	O0O0OO00000OOO0O0 =getOld (O0000O0000OO0O0OO )#line:1479
	O000O00000OO0OOO0 =O0000O0000OO0O0OO #line:1480
	setNew (O000O00000OO0OOO0 ,OOO0OOOO0OO0OOOOO )#line:1481
	OOOO00OO0OO0O00O0 =0 #line:1482
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO00OO0OO0O00O0 <100 :#line:1483
		OOOO00OO0OO0O00O0 +=1 #line:1484
		xbmc .sleep (1 )#line:1485
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1486
		xbmc .executebuiltin ('SendClick(11)')#line:1487
	return True #line:1488
def getOld (OO0OOOO0O000O000O ):#line:1490
	try :#line:1491
		OO0OOOO0O000O000O ='"%s"'%OO0OOOO0O000O000O #line:1492
		O000OOOOO0OOO00OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0OOOO0O000O000O )#line:1493
		OO0OOOOO0000000O0 =xbmc .executeJSONRPC (O000OOOOO0OOO00OO )#line:1495
		OO0OOOOO0000000O0 =simplejson .loads (OO0OOOOO0000000O0 )#line:1496
		if OO0OOOOO0000000O0 .has_key ('result'):#line:1497
			if OO0OOOOO0000000O0 ['result'].has_key ('value'):#line:1498
				return OO0OOOOO0000000O0 ['result']['value']#line:1499
	except :#line:1500
		pass #line:1501
	return None #line:1502
def setNew (OOOOO0OO0O0O0OO00 ,O0OO0000OO000O0OO ):#line:1505
	try :#line:1506
		OOOOO0OO0O0O0OO00 ='"%s"'%OOOOO0OO0O0O0OO00 #line:1507
		O0OO0000OO000O0OO ='"%s"'%O0OO0000OO000O0OO #line:1508
		O0O0OOOO000O00000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOOOO0OO0O0O0OO00 ,O0OO0000OO000O0OO )#line:1509
		OO0OO000OOOO0O00O =xbmc .executeJSONRPC (O0O0OOOO000O00000 )#line:1511
	except :#line:1512
		pass #line:1513
	return None #line:1514
def idle ():#line:1515
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:1516
def fixfont ():#line:1517
	OOO00OOO0O00O0OO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1518
	OO00O00O0OOO00O0O =json .loads (OOO00OOO0O00O0OO0 );#line:1520
	OOOO0O00OOOO000OO =OO00O00O0OOO00O0O ["result"]["settings"]#line:1521
	O0OOOOO0O0OO0OO0O =[O0OO00O0O00OOOOOO for O0OO00O0O00OOOOOO in OOOO0O00OOOO000OO if O0OO00O0O00OOOOOO ["id"]=="audiooutput.audiodevice"][0 ]#line:1523
	OOOOO0O00O00O0O00 =O0OOOOO0O0OO0OO0O ["options"];#line:1524
	O0OO0O00OO0OOOO00 =O0OOOOO0O0OO0OO0O ["value"];#line:1525
	O0OOO0O00OOOO0OO0 =[OO00OOO0OOO000O00 for (OO00OOO0OOO000O00 ,O000O0O00000OO0O0 )in enumerate (OOOOO0O00O00O0O00 )if O000O0O00000OO0O0 ["value"]==O0OO0O00OO0OOOO00 ][0 ];#line:1527
	O0OOO00OO0OO0O00O =(O0OOO0O00OOOO0OO0 +1 )%len (OOOOO0O00O00O0O00 )#line:1529
	O000OO00O0OOO00OO =OOOOO0O00O00O0O00 [O0OOO00OO0OO0O00O ]["value"]#line:1531
	OOO0OO0OOOO00000O =OOOOO0O00O00O0O00 [O0OOO00OO0OO0O00O ]["label"]#line:1532
	O00000OO00000OO0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1534
	try :#line:1536
		O0OOOOOOO0OOOOOOO =json .loads (O00000OO00000OO0O );#line:1537
		if O0OOOOOOO0OOOOOOO ["result"]!=True :#line:1539
			raise Exception #line:1540
	except :#line:1541
		sys .stderr .write ("Error switching audio output device")#line:1542
		raise Exception #line:1543
def checkSkin ():#line:1546
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:1547
	O0OO00OOOO0O0OOOO =wiz .getS ('defaultskin')#line:1548
	OOO00OO0O0000OO0O =wiz .getS ('defaultskinname')#line:1549
	OO0OO00OOO0O0OOO0 =wiz .getS ('defaultskinignore')#line:1550
	OOOO00O00O000O0OO =False #line:1551
	if not O0OO00OOOO0O0OOOO =='':#line:1552
		if os .path .exists (os .path .join (ADDONS ,O0OO00OOOO0O0OOOO )):#line:1553
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00OO0O0000OO0O )):#line:1554
				OOOO00O00O000O0OO =O0OO00OOOO0O0OOOO #line:1555
				OOO0O0O0O0OO00OO0 =OOO00OO0O0000OO0O #line:1556
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');OOOO00O00O000O0OO =False #line:1557
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O0OO00OOOO0O0OOOO ='';OOO00OO0O0000OO0O =''#line:1558
	if O0OO00OOOO0O0OOOO =='':#line:1559
		OO00OOO0000O0OOOO =[]#line:1560
		O0000O000000O0OOO =[]#line:1561
		for O00OO0O0OO000OOO0 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:1562
			O000O0OO0OO000OO0 ="%s/addon.xml"%O00OO0O0OO000OOO0 #line:1563
			if os .path .exists (O000O0OO0OO000OO0 ):#line:1564
				OOOO0O0O0000OO00O =open (O000O0OO0OO000OO0 ,mode ='r');O00OOOOO0O0O000O0 =OOOO0O0O0000OO00O .read ().replace ('\n','').replace ('\r','').replace ('\t','');OOOO0O0O0000OO00O .close ();#line:1565
				O000O0O0OO000OO00 =wiz .parseDOM (O00OOOOO0O0O000O0 ,'addon',ret ='id')#line:1566
				OO0O0O0OO0O000O00 =wiz .parseDOM (O00OOOOO0O0O000O0 ,'addon',ret ='name')#line:1567
				wiz .log ("%s: %s"%(O00OO0O0OO000OOO0 ,str (O000O0O0OO000OO00 [0 ])),xbmc .LOGNOTICE )#line:1568
				if len (O000O0O0OO000OO00 )>0 :O0000O000000O0OOO .append (str (O000O0O0OO000OO00 [0 ]));OO00OOO0000O0OOOO .append (str (OO0O0O0OO0O000O00 [0 ]))#line:1569
				else :wiz .log ("ID not found for %s"%O00OO0O0OO000OOO0 ,xbmc .LOGNOTICE )#line:1570
			else :wiz .log ("ID not found for %s"%O00OO0O0OO000OOO0 ,xbmc .LOGNOTICE )#line:1571
		if len (O0000O000000O0OOO )>0 :#line:1572
			if len (O0000O000000O0OOO )>1 :#line:1573
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:1574
					OO0OO00OOO00OO0O0 =DIALOG .select ("Select skin to switch to!",OO00OOO0000O0OOOO )#line:1575
					if OO0OO00OOO00OO0O0 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1576
					else :#line:1577
						OOOO00O00O000O0OO =O0000O000000O0OOO [OO0OO00OOO00OO0O0 ]#line:1578
						OOO0O0O0O0OO00OO0 =OO00OOO0000O0OOOO [OO0OO00OOO00OO0O0 ]#line:1579
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1580
	if OOOO00O00O000O0OO :#line:1587
		skinSwitch .swapSkins (OOOO00O00O000O0OO )#line:1588
		OO00OOOO000O0OOO0 =0 #line:1589
		xbmc .sleep (1000 )#line:1590
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00OOOO000O0OOO0 <150 :#line:1591
			OO00OOOO000O0OOO0 +=1 #line:1592
			xbmc .sleep (200 )#line:1593
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1595
			wiz .ebi ('SendClick(11)')#line:1596
			wiz .lookandFeelData ('restore')#line:1597
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1598
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1599
while xbmc .Player ().isPlayingVideo ():#line:1601
	xbmc .sleep (1000 )#line:1602
if KODIV >=17 :#line:1604
	NOW =datetime .now ()#line:1605
	temp =wiz .getS ('kodi17iscrap')#line:1606
	if not temp =='':#line:1607
		if temp >str (NOW -timedelta (minutes =2 )):#line:1608
			wiz .log ("Killing Start Up Script")#line:1609
			sys .exit ()#line:1610
	wiz .log ("%s"%(NOW ))#line:1611
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1612
	xbmc .sleep (1000 )#line:1613
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1614
		wiz .log ("Killing Start Up Script")#line:1615
		sys .exit ()#line:1616
	else :#line:1617
		wiz .log ("Continuing Start Up Script")#line:1618
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1620
path =os .path .split (ADDONPATH )#line:1621
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1622
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1623
if KODIADDONS in ADDONPATH :#line:1626
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1627
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1628
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1629
	if os .path .exists (newpath ):#line:1630
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1631
		wiz .cleanHouse (newpath )#line:1632
		wiz .removeFolder (newpath )#line:1633
	try :#line:1634
		wiz .copytree (ADDONPATH ,newpath )#line:1635
	except Exception as e :#line:1636
		pass #line:1637
	wiz .forceUpdate (True )#line:1638
try :#line:1640
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1641
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1642
except :#line:1643
	pass #line:1644
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1646
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1650
			wiz .kodi17Fix ()#line:1651
			fix18update ()#line:1652
			fix17update ()#line:1653
if INSTALLED =='true':#line:1656
    input =(ADDON .getSetting ("auto_rd"))#line:1657
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1659
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1660
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1661
    wiz .clearS ('install')#line:1662
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1747
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1749
	STARTP2 ()#line:1751
	if not NOTIFY =='true':#line:1752
		url =wiz .workingURL (NOTIFICATION )#line:1753
		if url ==True :#line:1754
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1755
			if not id ==False :#line:1756
				try :#line:1757
					id =int (id );NOTEID =int (NOTEID )#line:1758
					if id ==NOTEID :#line:1759
						if NOTEDISMISS =='false':#line:1760
							debridit .debridIt ('update','all')#line:1761
							traktit .traktIt ('update','all')#line:1762
							checkidupdate ()#line:1763
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1764
					elif id >NOTEID :#line:1765
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1766
						wiz .setS ('noteid',str (id ))#line:1767
						wiz .setS ('notedismiss','false')#line:1768
						debridit .debridIt ('update','all')#line:1770
						traktit .traktIt ('update','all')#line:1771
						checkidupdate ()#line:1772
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1774
				except Exception as e :#line:1775
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1776
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1777
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1778
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1779
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1780
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1782
if ENABLE =='No':#line:1783
	if not NOTIFY2 =='true':#line:1784
		url =wiz .workingURL (NOTIFICATION2 )#line:1785
		if url ==True :#line:1786
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1787
			if not id ==False :#line:1788
				try :#line:1789
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1790
					if id ==NOTEID2 :#line:1791
						if NOTEDISMISS2 =='false':#line:1792
							checkvictory ()#line:1793
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1794
					elif id >NOTEID2 :#line:1795
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1796
						wiz .setS ('noteid2',str (id ))#line:1797
						wiz .setS ('notedismiss2','false')#line:1798
						checkvictory ()#line:1799
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1800
				except Exception as e :#line:1801
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1802
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1803
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1804
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1805
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1806
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1808
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1809
	if not NOTIFY3 =='true':#line:1810
		url =wiz .workingURL (NOTIFICATION3 )#line:1811
		if url ==True :#line:1812
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1813
			if not id ==False :#line:1814
				try :#line:1815
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1816
					if id ==NOTEID3 :#line:1817
						if NOTEDISMISS3 =='false':#line:1818
							notify .notification3 (msg )#line:1819
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1820
					elif id >NOTEID3 :#line:1821
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1822
						wiz .setS ('noteid3',str (id ))#line:1823
						wiz .setS ('notedismiss3','false')#line:1824
						notify .notification3 (msg =msg )#line:1825
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1826
				except Exception as e :#line:1827
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1828
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1829
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1830
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1831
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1832
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1833
if KEEPTRAKT =='true':#line:1834
	if TRAKTSAVE <=str (TODAY ):#line:1835
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1836
		traktit .autoUpdate ('all')#line:1837
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1838
	else :#line:1839
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1840
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1841
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1843
if KEEPREAL =='true':#line:1844
	if REALSAVE <=str (TODAY ):#line:1845
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1846
		debridit .autoUpdate ('all')#line:1847
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1848
	else :#line:1849
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1850
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1851
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1853
if KEEPLOGIN =='true':#line:1854
	if LOGINSAVE <=str (TODAY ):#line:1855
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1856
		loginit .autoUpdate ('all')#line:1857
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1858
	else :#line:1859
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1860
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1861
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1863
if AUTOCLEANUP =='true':#line:1864
	service =False #line:1865
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1866
	feq =int (float (AUTOFEQ ))#line:1867
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1868
		service =True #line:1869
		next_run =days [feq ]#line:1870
		wiz .setS ('nextautocleanup',str (next_run ))#line:1871
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1872
	if service ==True :#line:1873
		AUTOCACHE =wiz .getS ('clearcache')#line:1874
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1875
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1876
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1877
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1878
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1879
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1880
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1881
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1882
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1883
wiz .setS ('kodi17iscrap','')#line:1885
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1954
	count =0 #line:1955
	for f in filenames :#line:1956
		count +=1 #line:1957
		fp =os .path .join (dirpath ,f )#line:1958
		total_size +=os .path .getsize (fp )#line:1959
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1960
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1967
	for f2 in filenames2 :#line:1968
		fp2 =os .path .join (dirpath2 ,f2 )#line:1969
		total_size2 +=os .path .getsize (fp2 )#line:1970
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1971
if int (total_sizetext2 )>filesize_thumb :#line:1973
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1974
	if choice2 ==1 :#line:1975
		maintenance .deleteThumbnails ()#line:1976
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1978
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1979
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1981
time .sleep (3 )#line:1982
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:1984
        display_Votes ()#line:1985
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:1987
        file .write (str ('Done'))#line:1989
        file .close ()#line:1990
tele =(ADDON .getSetting ("auto_tele"))#line:1995
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:1997
    if tele =='true':#line:1999
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:2000
