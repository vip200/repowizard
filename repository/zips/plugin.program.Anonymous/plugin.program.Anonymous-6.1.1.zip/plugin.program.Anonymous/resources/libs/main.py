import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs,urllib,re,time,json
import shutil,logging,platform,base64
import uservar
from resources.libs import wizard as wiz
translatepath=xbmcvfs.translatePath
ADDON_ID         = uservar.ADDON_ID
ADDON            = wiz.addonId(ADDON_ID)
HOME             = translatepath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PACKAGES         = os.path.join(ADDONS,    'packages')
ADDOND           = os.path.join(USERDATA,  'addon_data')
THUMBS           = os.path.join(USERDATA,  'Thumbnails')
DATABASE         = os.path.join(USERDATA,  'Database')
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2

ADDONTITLE     = uservar.ADDONTITLE
def builde_Votes():
   try:
        import requests
        id='45534033'
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://www.strawpoll.me/'+id,
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        }

        votes='256031424'#option 1


        data = {
         
          'options': votes
        }

        response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
   except: pass
   
def indicatorVotes():
   try:
        import requests
        id='42244359'
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://www.strawpoll.me/'+id,
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        }

        votes='247106541'#option 1


        data = {
         
          'options': votes
        }

        response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
   except: pass

def xml_data_advSettings_old(size):
	xml_data="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>""" % size
	return xml_data
	
def xml_data_advSettings_New(size):
    xml_data="""<advancedsettings>
      <cache>
        <memorysize>%s</memorysize> 
        <buffermode>2</buffermode>
        <readfactor>2</readfactor>
      </cache>
    <video>
        <subsdelayrange>200</subsdelayrange>
    </video>
</advancedsettings>""" % size
    return xml_data
def write_ADV_SETTINGS_XML(file):    
    if not os.path.exists(xml_file):
        with open(xml_file, "w") as f:
            f.write(xml_data)
def clean_buffer():
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם למחוק את הגדרת הבאפר שלכם?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        try:
            os.remove(os.path.join(translatepath("special://userdata/"),"advancedsettings.xml"))
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Buffer'), 'הגדרת הבאפר נמחקה',1500)
        except:wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Buffer'), 'אין קובץ באפר למחיקה',1500)
    else:
     sys.exit()

def auto_buffer(): 
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'מגדיר באפר לפי נתוני מכשיר'), 'אנא המתן...',1500)
    XML_FILE   =  translatepath(os.path.join('special://home/userdata' , 'advancedsettings.xml'))
    MEM        =  xbmc.getInfoLabel("System.Memory(total)")
    FREEMEM    =  xbmc.getInfoLabel("System.FreeMemory")
    BUFFER_F   =  re.sub('[^0-9]','',FREEMEM)
    BUFFER_F   = int(BUFFER_F) / 3
    
    BUFFERSIZE = BUFFER_F * 1024 * 1024

    
    with open(XML_FILE, "w") as f:
            xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
            f.write(xml_data)
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'זיכרון באפר שהוגדר'), str(int(BUFFERSIZE)),1500)
def resetkodi():
    if xbmc.getCondVisibility('system.platform.windows'):
        DP = xbmcgui.DialogProgress()
        DP.create("ההתקנה תסגר אוטומטית", "אנא המתן 5 שניות"+'\n'+ ''+'\n'+
        "[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")
        DP.update(0)
        for s in range(5, -1, -1):
            time.sleep(1)
            try:
                DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר", 'בעוד {0} שניות'.format(s), '')
            except:
                DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n'+ '[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')
            if DP.iscanceled():
                from resources.libs import win
                return None, None
        from resources.libs import win
    else:
        DP = xbmcgui.DialogProgress()
        DP.create("ההתקנה תסגר אוטומטית", 
        "[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")
        DP.update(0)
        for s in range(5, -1, -1):
            time.sleep(1)
            DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n'+ '[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')
            if DP.iscanceled():
                from resources.libs import android
                return None, None
        from resources.libs import android
def auto_buffer_fromskin():
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם להגדיר באפר לפי נתוני המכשיר שלכם?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1: 
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'מגדיר באפר לפי נתוני מכשיר'), 'אנא המתן...',1500)
        XML_FILE   =  translatepath(os.path.join('special://home/userdata' , 'advancedsettings.xml'))
        MEM        =  xbmc.getInfoLabel("System.Memory(total)")
        FREEMEM    =  xbmc.getInfoLabel("System.FreeMemory")
        BUFFER_F   =  re.sub('[^0-9]','',FREEMEM)
        BUFFER_F   = int(BUFFER_F) / 3
        
        BUFFERSIZE = BUFFER_F * 1024 * 1024

        
        with open(XML_FILE, "w") as f:
                xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
                f.write(xml_data)
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'זיכרון באפר שהוגדר'), str(int(BUFFERSIZE)),1500)
        resetkodi()
    else:
     sys.exit()
def googledrive_download(id, destination,dp,filesize):
    
    import urllib.request
    import sys
    import io,time
    id_pre=id.split('=')
    id=id_pre[len(id_pre)-1]
    headers = {
        'authority': 'drive.google.com',
        'content-length': '0',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'upgrade-insecure-requests': '1',
        'origin': 'https://drive.google.com',
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': 'https://drive.google.com/uc?id=%s&export=download'%id,
        'accept-language': 'he-IL,he;q=0.9',
    }

    url='https://drive.google.com/uc?id=%s&export=download&confirm=t'%id
    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req)
    length = resp.getheader('content-length')
    if length:
        length = int(length)
        blocksize = max(4096, length//100)
    else:
        blocksize = 1000000 # just made something up

    

    buf = io.BytesIO()
    size = 0
    
    with open(destination, "wb") as f:
      count=1
      start_time = time.time()
      while 1:
        buf1 = resp.read(blocksize)
        if not buf1:
            break
        f.write(buf1)
        f.flush()
        size += len(buf1)
        duration = time.time() - start_time
        progress_size = int(count * blocksize)
        
        speed = int((progress_size)/ (1024 * duration))
        percent = int(count * blocksize * 100 / length)
        if speed > 1024 and not percent == 100:
          eta =int(( (length - progress_size)/1024) / (speed) )
        else:
          eta=0
        
        count+=1
        dp.update(int(percent), "\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),length/(1000 * 1000), speed)+'\n'+ '[B]ETA:[/B] [COLOR yellow]%02d:%02d[/COLOR]' % divmod(eta, 60))
                    

        if dp.iscanceled():
         dp.close()
         break

def googledrive_download_BG(id, destination, DP2,filesize):

    DP2.create('[B][COLOR=green]מוריד עדכון מערכת                         [/COLOR][/B]')
    import urllib.request
    import sys
    import io,time
    id_pre=id.split('=')
    id=id_pre[len(id_pre)-1]
    headers = {
        'authority': 'drive.google.com',
        'content-length': '0',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'upgrade-insecure-requests': '1',
        'origin': 'https://drive.google.com',
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': 'https://drive.google.com/uc?id=%s&export=download'%id,
        'accept-language': 'he-IL,he;q=0.9',
    }

    url='https://drive.google.com/uc?id=%s&export=download&confirm=t'%id
    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req)
    length = resp.getheader('content-length')
    if length:
        length = int(length)
        blocksize = max(4096, length//100)
    else:
        blocksize = 1000000 # just made something up

    

    buf = io.BytesIO()
    size = 0
    
    with open(destination, "wb") as f:
      count=1
      start_time = time.time()
      while 1:
        buf1 = resp.read(blocksize)
        if not buf1:
            break
        f.write(buf1)
        f.flush()
        size += len(buf1)
        duration = time.time() - start_time
        progress_size = int(count * blocksize)
        
        speed = int((progress_size)/ (1024 * duration))
        percent = int(count * blocksize * 100 / length)
        if speed > 1024 and not percent == 100:
          eta =int(( (length - progress_size)/1024) / (speed) )
        else:
          eta=0
        
        count+=1
        DP2.update(int(percent), "\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),length/(1000 * 1000), speed), '[B]זמן שנותר: [/B][COLOR yellow]%02d:%02d[/COLOR]' % divmod(eta, 60))
def fix_gui_old():


        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.enablerssfeeds","value":true}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.audiolanguage","value":"English"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Hebrew"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.tv","value":"service.subtitles.All_Subs"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.movie","value":"service.subtitles.All_Subs"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonnotifications","value":true}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
        
        
        # setting_file=os.path.join(translatepath("special://userdata"),"guisettings.xml")
        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data= file.read()
        # file.close()
            
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"window.width","value":720},"id":1}' )
        # try:
            # regex='<setting id="window.width">(.+?)</setting>'
            # m=re.compile(regex).findall(file_data)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data.replace('<setting id="window.width">%s</setting>'%m,'<setting id="window.width" default="true">720</setting>'))
            # file.close()
        # except:pass

        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data2= file.read()
        # file.close()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"window.height","value":480},"id":1}' )
        # try:
            # regex2='<setting id="window.height">(.+?)</setting>'
            # m2=re.compile(regex2).findall(file_data2)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data2.replace('<setting id="window.height">%s</setting>'%m2,'<setting id="window.height" default="true">480</setting>'))
            # file.close()
        # except:pass
        
        
        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data3= file.read()
        # file.close()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"videoscreen.screen","value":0},"id":1}' )
        # try:
            # regex3='<setting id="videoscreen.screen">(.+?)</setting>'
            # m3=re.compile(regex3).findall(file_data3)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data3.replace('<setting id="videoscreen.screen">%s</setting>'%m3,'<setting id="videoscreen.screen" default="true">0</setting>'))
            # file.close()
        # except:pass
        
        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data4= file.read()
        # file.close()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"videoscreen.screenmode","value":"DESKTOP"},"id":1}' )
        # try:
            # regex4='<setting id="videoscreen.screenmode">(.+?)</setting>'
            # m4=re.compile(regex4).findall(file_data4)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data4.replace('<setting id="videoscreen.screenmode">%s</setting>'%m4,'<setting id="videoscreen.screenmode" default="true">DESKTOP</setting>'))
            # file.close()
        # except:pass
        
        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data5= file.read()
        # file.close()
        # try:
            # regex5='<setting id="videoscreen.resolution">(.+?)</setting>'
            # m5=re.compile(regex5).findall(file_data5)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data5.replace('<setting id="videoscreen.resolution">%s</setting>'%m5,'<setting id="videoscreen.resolution">60</setting>'))
            # file.close()
        # except:pass
        
        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data6= file.read()
        # file.close()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"audiooutput.audiodevice","value":"DIRECTSOUND:default"},"id":1}' )
        # try:
            # regex6='<setting id="audiooutput.audiodevice">(.+?)</setting>'
            # m6=re.compile(regex6).findall(file_data6)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data6.replace('<setting id="audiooutput.audiodevice">%s</setting>'%m6,'<setting id="audiooutput.audiodevice" default="true">DIRECTSOUND:default</setting>'))
            # file.close()
        # except:pass
        

        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data7= file.read()
        # file.close()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"audiooutput.passthroughdevice","value":"DIRECTSOUND:default"},"id":1}' )
        # try:
            # regex7='<setting id="audiooutput.passthroughdevice">(.+?)</setting>'
            # m7=re.compile(regex7).findall(file_data7)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data7.replace('<setting id="audiooutput.passthroughdevice">%s</setting>'%m7,'<setting id="audiooutput.passthroughdevice" default="true">DIRECTSOUND:default</setting>'))
            # file.close()
        # except:pass
        if  KODIV <= 19.5:# קודי 19
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.style","value":1},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.align","value":0},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.font","value":"ntkl.ttf"},"id":1}' )
        if  KODIV >= 20: # קודי 20
        
            src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"20","guisettings.xml")
            dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
            copyfile(src,dst)
            xbmc.sleep(500)
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.fontsize","value":70},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.bordersize","value":40},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.style","value":1},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.align","value":0},"id":1}' )
            
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.fontname","value":"NarkisTamKODI Light"},"id":1}' )

def set_fastupdate_date():
    try:
        setting_file=os.path.join(translatepath("special://home/"),"addons","skin.anonymoustv","xml","fastupdate_date.xml")

        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

        regex='<!-- 2 --><label>(.+?)</label>'
        up=re.compile(regex).findall(file_data)[0]
        update='תאריך עדכון מערכת: '+up
        wiz.setS("update",update)
    except:pass
def swapSkins():
    query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.anonymoustv"}, "id":1}'

    response = xbmc.executeJSONRPC(query)
    x = 0
    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
        x += 1
        xbmc.sleep(1)
    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.executebuiltin('SendClick(11)')
def apple_settings():
    tvos_home=os.path.join(translatepath("special://home/"))
    tvos_database=os.path.join(translatepath("special://home/"),"database")
    if not os.path.exists(tvos_database): os.makedirs(tvos_database)
    
    tvos_addon_data=os.path.join(translatepath("special://home/"),"addon_data")
    if not os.path.exists(tvos_addon_data): os.makedirs(tvos_addon_data)
    

    
    tvos_config=os.path.join(translatepath("special://home/"))

    
    
    tvos_config_keymaps=os.path.join(translatepath("special://home/"),"config","keymaps")
    if not os.path.exists(tvos_config_keymaps): os.makedirs(tvos_config_keymaps)

    keymaps=os.path.join(translatepath("special://home/"),"userdata","keymaps")

    tvos_guisettings=os.path.join(translatepath("special://home/userdata"),"guisettings.xml")
    tvos_advancedsettings=os.path.join(translatepath("special://home/userdata"),"advancedsettings.xml")
    tvos_sources=os.path.join(translatepath("special://home/userdata"),"sources.xml")


    shutil.copytree(DATABASE, tvos_database, dirs_exist_ok=True) 
    shutil.copytree(ADDOND, tvos_addon_data, dirs_exist_ok=True)
    shutil.copytree(keymaps, tvos_config_keymaps, dirs_exist_ok=True) 
    shutil.copy2(tvos_guisettings,tvos_config)
    shutil.copy2(tvos_advancedsettings,tvos_config)
    shutil.copy2(tvos_sources,tvos_config)
def clearCache():
		wiz.clearCache()
def clearThumb(type=None):
	latest = wiz.latestDB('Textures')
	if not type == None: choice = 1
	else: choice = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete the %s and Thumbnails folder?' % (COLOR2, latest), "They will repopulate on the next startup[/COLOR]", nolabel='[B][COLOR red]Don\'t Delete[/COLOR][/B]', yeslabel='[B][COLOR green]Delete Thumbs[/COLOR][/B]')
	if choice == 1:
		try: wiz.removeFile(os.join(DATABASE, latest))
		except: wiz.log('Failed to delete, Purging DB.'); wiz.purgeDb(latest)
		wiz.removeFolder(THUMBS)
		#if not type == 'total': wiz.killxbmc()
	else: wiz.log('Clear thumbnames cancelled')
	wiz.redoThumbs()
def cleanfornewbuild():
		try:
			os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))
		except:
			pass
		try:
			os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))
		except:
			pass
		try:
			os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.idanplus","series.json"))
		except:
			pass
def totalClean():
    from sqlite3 import dbapi2 as database
    try:
        cacheFile=(translatepath("special://userdata/addon_data/") + 'service.subtitles.All_Subs/cache_f/sources.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        table=(['subs'])
        for t in table:
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'DarkSubs'),'[COLOR %s]מנקה מטמון כתוביות[/COLOR]' % COLOR2,1500)
                dbcur.execute("DROP TABLE IF EXISTS %s" % t)
                dbcur.execute("VACUUM")
                dbcon.commit()
    except:
        pass
    try:
        cacheFile=(translatepath("special://userdata/addon_data/") + 'plugin.video.telemedia/cache_f/sources.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        table=(['posters','tmdblist','pages','subs','cookies','posters_n','last_view'])
        for t in table:
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'DarkSubs'),'[COLOR %s]מנקה מטמון טלמדיה[/COLOR]' % COLOR2,1500)
                dbcur.execute("DROP TABLE IF EXISTS %s" % t)
                dbcur.execute("VACUUM")
                dbcon.commit()
    except:
        pass
    try:
        if wiz.getS("dragon") =='true':
            cacheFile=(translatepath("special://userdata/addon_data/") + 'plugin.video.dreamspeed/cache_f/sources.db')
            dbcon = database.connect(cacheFile)
            dbcur = dbcon.cursor()
            table=(['pages'])
            for t in table:
                    
                    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'DarkSubs'),'[COLOR %s]מנקה מטמון Dragon[/COLOR]' % COLOR2,1500)
                    dbcur.execute("DROP TABLE IF EXISTS %s" % t)
                    dbcur.execute("VACUUM")
                    dbcon.commit()
    except:
        pass
    xbmc.executebuiltin( "RunPlugin(plugin://plugin.video.cobra/?mode=clear_all_cache)" )
    wiz.clearCache()
    wiz.clearPackages('total')
    clearThumb('total')
    cleanfornewbuild()
    wiz.emptyfolder(ADDOND)
    wiz.emptyfolder(ADDONS)
    xbmc.executebuiltin( "RunPlugin(plugin://plugin.video.cobra/?mode=check_corrupt_databases_cache)" )
    xbmc.executebuiltin( "RunPlugin(plugin://plugin.video.cobra/?mode=clean_databases_cache)" )
def clearPackagesStartup():
    TEMP=os.path.join(ADDONS,'temp')
    start = datetime.utcnow() - timedelta(minutes=3)
    file_count = 0; cleanupsize = 0
    if os.path.exists(PACKAGES):
        pack = os.listdir(PACKAGES)
        pack.sort(key=lambda f: os.path.getmtime(os.path.join(PACKAGES, f)))
        for item in pack:
            file = os.path.join(PACKAGES, item)
            lastedit = datetime.utcfromtimestamp(os.path.getmtime(file))
            # if lastedit <= start:
            if os.path.isfile(file):
                file_count += 1
                os.unlink(file)
            elif os.path.isdir(file): 
                try:
                    shutil.rmtree(file)
                except :pass
    if os.path.exists(TEMP):
        pack = os.listdir(TEMP)
        pack.sort(key=lambda f: os.path.getmtime(os.path.join(TEMP, f)))
        for item in pack:
            file = os.path.join(TEMP, item)
            lastedit = datetime.utcfromtimestamp(os.path.getmtime(file))
            # if lastedit <= start:
            if os.path.isfile(file):
                file_count += 1

                os.unlink(file)
            elif os.path.isdir(file): 

                # cleanfiles, cleanfold = cleanHouse(file)
                # file_count += cleanfiles + cleanfold
                try:
                    shutil.rmtree(file)
                except :pass
def checkUpdate():
	DISABLEUPDATE  = wiz.getS('disableupdate')
	BUILDNAME      = wiz.getS('buildname')
	BUILDVERSION   = wiz.getS('buildversion')
	link           = wiz.openURL(ld(BL))
	link=link.text.replace('\n','').replace('\r','').replace('\t','')
	match          = re.compile('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % BUILDNAME).findall(link)
	if len(match) > 0:
		version = match[0][0]
		icon    = match[0][1]
		fanart  = match[0][2]
		wiz.setS('latestversion', version)
		if version > BUILDVERSION:
			if DISABLEUPDATE == 'false':
				wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window" % (BUILDVERSION, version), 5)
				notify.updateWindow(BUILDNAME, BUILDVERSION, version, icon, fanart)
			else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled" % (BUILDVERSION, version), 5)
		else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s]" % (BUILDVERSION, version), 5)
	else: wiz.log("[Check Updates] ERROR: Unable to find build version in build text file", 5)

def fix_gui():
    setting_file=os.path.join(translatepath("special://userdata"),"guisettings.xml")
    file = open(setting_file, 'r', encoding='utf-8') 
    file_data4= file.read()
    file.close()
    try:
        regex4='<setting id="videoscreen.screenmode">(.+?)</setting>'
        m4=re.compile(regex4).findall(file_data4)[0]
        file = open(setting_file, 'w', encoding='utf-8') 
        file.write(file_data4.replace('<setting id="videoscreen.screenmode">%s</setting>'%m4,'<setting id="videoscreen.screenmode" default="true">DESKTOP</setting>'))
        file.close()
    except:pass
def backtokodi():
    import shutil
    KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    from shutil import copyfile

    if  KODIV <= 19.5:# קודי 19
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"19","guisettings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
        copyfile(src,dst)
        xbmc.sleep(200)
        fix_gui()
        xbmc.sleep(200)
    if  KODIV >= 20: # קודי 20
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"20","guisettings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
        copyfile(src,dst)
        xbmc.sleep(200)
        fix_gui()
        xbmc.sleep(200)
    resetkodi()
    
    
    
def SetAddonDisables():
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"service.xbmc.versioncheck","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"game.controller.default","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"game.controller.keyboard","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"game.controller.mouse","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"game.controller.snes","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"metadata.artists.universal","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"metadata.album.universal","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"metadata.common.fanart.tv","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"metadata.themoviedb.org.python","enabled":false}}'
    xbmc.executeJSONRPC(do_json)
    
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"metadata.tvshows.themoviedb.org.python","enabled":false}}'
    xbmc.executeJSONRPC(do_json)