# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,HTMLParser ,glob ,zipfile ,json #line:21
import shutil ,logging #line:22
import errno #line:23
import string #line:24
import random #line:25
import urllib2 ,urllib #line:26
import re #line:27
import speedtest #line:28
import downloader #line:29
import downloaderbg #line:30
import downloaderwiz #line:31
import extract #line:32
import uservar #line:33
import skinSwitch #line:34
import time #line:35
import pyqrcode #line:36
from datetime import date ,datetime ,timedelta #line:38
try :from sqlite3 import dbapi2 as database #line:39
except :from pysqlite2 import dbapi2 as database #line:40
from string import digits #line:41
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:43
if KODIV >17 :#line:44
	from resources .libs import zfile as zipfile #line:45
else :#line:46
	import zipfile #line:47
ADDON_ID =uservar .ADDON_ID #line:49
ADDONTITLE =uservar .ADDONTITLE #line:50
ADDON =xbmcaddon .Addon (ADDON_ID )#line:51
VERSION =ADDON .getAddonInfo ('version')#line:52
USER_AGENT ='Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'#line:53
DIALOG =xbmcgui .Dialog ()#line:54
DP =xbmcgui .DialogProgress ()#line:55
DP2 =xbmcgui .DialogProgressBG ()#line:56
HOME =xbmc .translatePath ('special://home/')#line:57
XBMC =xbmc .translatePath ('special://xbmc/')#line:58
LOG =xbmc .translatePath ('special://logpath/')#line:59
PROFILE =xbmc .translatePath ('special://profile/')#line:60
SOURCE =xbmc .translatePath ('source://')#line:61
ADDONS =os .path .join (HOME ,'addons')#line:62
USERDATA =os .path .join (HOME ,'userdata')#line:63
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:64
PACKAGES =os .path .join (ADDONS ,'packages')#line:65
ADDOND =os .path .join (USERDATA ,'addon_data')#line:66
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:67
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:68
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:69
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:70
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:71
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:72
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:73
DATABASE =os .path .join (USERDATA ,'Database')#line:74
FANART =os .path .join (PLUGIN ,'fanart.jpg')#line:75
ICON =os .path .join (PLUGIN ,'icon.png')#line:76
ART =os .path .join (PLUGIN ,'resources','art')#line:77
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:78
WHITELIST =os .path .join (ADDONDATA ,'whitelist.txt')#line:79
QRCODES =os .path .join (ADDONDATA ,'QRCodes')#line:80
SKIN =xbmc .getSkinDir ()#line:81
TODAY =date .today ()#line:82
TOMORROW =TODAY +timedelta (days =1 )#line:83
TWODAYS =TODAY +timedelta (days =2 )#line:84
THREEDAYS =TODAY +timedelta (days =3 )#line:85
ONEWEEK =TODAY +timedelta (days =7 )#line:86
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:87
EXCLUDES =uservar .EXCLUDES #line:88
SPEEDFILE =speedtest .SPEEDFILE #line:89
APKFILE =uservar .APKFILE #line:90
YOUTUBEFILE =uservar .YOUTUBEFILE #line:91
ADDONFILE =uservar .ADDONFILE #line:92
ADVANCEDFILE =uservar .ADVANCEDFILE #line:93
AUTOUPDATE =uservar .AUTOUPDATE #line:94
WIZARDFILE =uservar .WIZARDFILE #line:95
NOTIFICATION =uservar .NOTIFICATION #line:96
NOTIFICATION2 =uservar .NOTIFICATION2 #line:97
NOTIFICATION3 =uservar .NOTIFICATION3 #line:98
ENABLE =uservar .ENABLE #line:99
AUTOINSTALL =uservar .AUTOINSTALL #line:100
REPOADDONXML =uservar .REPOADDONXML #line:101
REPOZIPURL =uservar .REPOZIPURL #line:102
CONTACT =uservar .CONTACT #line:103
COLOR1 =uservar .COLOR1 #line:104
COLOR2 =uservar .COLOR2 #line:105
HARDWAER =ADDON .getSetting ('action')#line:106
INCLUDEVIDEO =ADDON .getSetting ('includevideo')#line:107
INCLUDEALL =ADDON .getSetting ('includeall')#line:108
INCLUDEBOB =ADDON .getSetting ('includebob')#line:109
INCLUDEPHOENIX =ADDON .getSetting ('includephoenix')#line:110
INCLUDESPECTO =ADDON .getSetting ('includespecto')#line:111
INCLUDEGENESIS =ADDON .getSetting ('includegenesis')#line:112
INCLUDEEXODUS =ADDON .getSetting ('includeexodus')#line:113
INCLUDEONECHAN =ADDON .getSetting ('includeonechan')#line:114
INCLUDESALTS =ADDON .getSetting ('includesalts')#line:115
INCLUDESALTSHD =ADDON .getSetting ('includesaltslite')#line:116
SHOWADULT =ADDON .getSetting ('adult')#line:117
WIZDEBUGGING =ADDON .getSetting ('addon_debug')#line:118
DEBUGLEVEL =ADDON .getSetting ('debuglevel')#line:119
ENABLEWIZLOG =ADDON .getSetting ('wizardlog')#line:120
CLEANWIZLOG =ADDON .getSetting ('autocleanwiz')#line:121
CLEANWIZLOGBY =ADDON .getSetting ('wizlogcleanby')#line:122
CLEANDAYS =ADDON .getSetting ('wizlogcleandays')#line:123
CLEANSIZE =ADDON .getSetting ('wizlogcleansize')#line:124
CLEANLINES =ADDON .getSetting ('wizlogcleanlines')#line:125
INSTALLMETHOD =ADDON .getSetting ('installmethod')#line:126
DEVELOPER =ADDON .getSetting ('developer')#line:127
THIRDPARTY =ADDON .getSetting ('enable3rd')#line:128
THIRD1NAME =ADDON .getSetting ('wizard1name')#line:129
THIRD1URL =ADDON .getSetting ('wizard1url')#line:130
THIRD2NAME =ADDON .getSetting ('wizard2name')#line:131
THIRD2URL =ADDON .getSetting ('wizard2url')#line:132
THIRD3NAME =ADDON .getSetting ('wizard3name')#line:133
THIRD3URL =ADDON .getSetting ('wizard3url')#line:134
BUILDNAME =ADDON .getSetting ('buildname')#line:135
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:136
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:137
LOGFILES =['log','xbmc.old.log','kodi.log','kodi.old.log','spmc.log','spmc.old.log','tvmc.log','tvmc.old.log']#line:138
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:139
MAXWIZSIZE =[100 ,200 ,300 ,400 ,500 ,1000 ]#line:140
MAXWIZLINES =[100 ,200 ,300 ,400 ,500 ]#line:141
MAXWIZDATES =[1 ,2 ,3 ,7 ]#line:142
def getS (O0OOOO00O00O0O0O0 ):#line:149
	try :return ADDON .getSetting (O0OOOO00O00O0O0O0 )#line:150
	except :return False #line:151
def setS (OOOO0000000000O0O ,OOO0O000O0O0O000O ):#line:153
	try :ADDON .setSetting (OOOO0000000000O0O ,OOO0O000O0O0O000O )#line:154
	except :return False #line:155
def openS (name =""):#line:157
	ADDON .openSettings ()#line:158
def clearS (OOOOOOOOO0O0000OO ):#line:160
	O00OOOO00OOO0O0O0 ={'buildname':'','buildversion':'','buildtheme':'','latestversion':'','lastbuildcheck':'2016-01-01'}#line:161
	O0O0O00OO0OO0O0OO ={'installed':'false','extract':'','errors':''}#line:162
	OO0000O0OOO0O00O0 ={'defaultskinignore':'false','defaultskin':'','defaultskinname':''}#line:163
	O0O0OO0O0OO00OOO0 =['default.enablerssfeeds','default.font','default.rssedit','default.skincolors','default.skintheme','default.skinzoom','default.soundskin','default.startupwindow','default.stereostrength']#line:164
	if OOOOOOOOO0O0000OO =='build':#line:165
		for O00OOO0O0000OOO00 in O00OOOO00OOO0O0O0 :#line:166
			setS (O00OOO0O0000OOO00 ,O00OOOO00OOO0O0O0 [O00OOO0O0000OOO00 ])#line:167
		for O00OOO0O0000OOO00 in O0O0O00OO0OO0O0OO :#line:168
			setS (O00OOO0O0000OOO00 ,O0O0O00OO0OO0O0OO [O00OOO0O0000OOO00 ])#line:169
		for O00OOO0O0000OOO00 in OO0000O0OOO0O00O0 :#line:170
			setS (O00OOO0O0000OOO00 ,OO0000O0OOO0O00O0 [O00OOO0O0000OOO00 ])#line:171
		for O00OOO0O0000OOO00 in O0O0OO0O0OO00OOO0 :#line:172
			setS (O00OOO0O0000OOO00 ,'')#line:173
	elif OOOOOOOOO0O0000OO =='default':#line:174
		for O00OOO0O0000OOO00 in OO0000O0OOO0O00O0 :#line:175
			setS (O00OOO0O0000OOO00 ,OO0000O0OOO0O00O0 [O00OOO0O0000OOO00 ])#line:176
		for O00OOO0O0000OOO00 in O0O0OO0O0OO00OOO0 :#line:177
			setS (O00OOO0O0000OOO00 ,'')#line:178
	elif OOOOOOOOO0O0000OO =='install':#line:179
		for O00OOO0O0000OOO00 in O0O0O00OO0OO0O0OO :#line:180
			setS (O00OOO0O0000OOO00 ,O0O0O00OO0OO0O0OO [O00OOO0O0000OOO00 ])#line:181
	elif OOOOOOOOO0O0000OO =='lookfeel':#line:182
		for O00OOO0O0000OOO00 in O0O0OO0O0OO00OOO0 :#line:183
			setS (O00OOO0O0000OOO00 ,'')#line:184
theme_nox ='https://zxcsd-3bae5-default-rtdb.firebaseio.com'#line:200
ACTION_PREVIOUS_MENU =10 #line:212
ACTION_NAV_BACK =92 #line:213
ACTION_MOVE_LEFT =1 #line:214
ACTION_MOVE_RIGHT =2 #line:215
ACTION_MOVE_UP =3 #line:216
ACTION_MOVE_DOWN =4 #line:217
ACTION_MOUSE_WHEEL_UP =104 #line:218
ACTION_MOUSE_WHEEL_DOWN =105 #line:219
ACTION_MOVE_MOUSE =107 #line:220
ACTION_SELECT_ITEM =7 #line:221
ACTION_BACKSPACE =110 #line:222
ACTION_MOUSE_LEFT_CLICK =100 #line:223
ACTION_MOUSE_LONG_CLICK =108 #line:224
def TextBox (O00O0OOO0O00OOOOO ,OOO00OOOOOO0000O0 ):#line:225
	class OO00OO00000000OOO (xbmcgui .WindowXMLDialog ):#line:226
		def onInit (O0O0O000O0O0O0O0O ):#line:227
			O0O0O000O0O0O0O0O .title =101 #line:228
			O0O0O000O0O0O0O0O .msg =102 #line:229
			O0O0O000O0O0O0O0O .scrollbar =103 #line:230
			O0O0O000O0O0O0O0O .okbutton =201 #line:231
			O0O0O000O0O0O0O0O .showdialog ()#line:232
		def showdialog (O0O000O000OOO0O00 ):#line:234
			O0O000O000OOO0O00 .getControl (O0O000O000OOO0O00 .title ).setLabel (O00O0OOO0O00OOOOO )#line:235
			O0O000O000OOO0O00 .getControl (O0O000O000OOO0O00 .msg ).setText (OOO00OOOOOO0000O0 )#line:236
			O0O000O000OOO0O00 .setFocusId (O0O000O000OOO0O00 .scrollbar )#line:237
		def onClick (OOOOO00OO00O0O0O0 ,OO0OOOO000OOOO00O ):#line:239
			if (OO0OOOO000OOOO00O ==OOOOO00OO00O0O0O0 .okbutton ):#line:240
				OOOOO00OO00O0O0O0 .close ()#line:241
		def onAction (OO0OOOO0OO0OOOO00 ,O0OOOOOO00O00O0OO ):#line:243
			if O0OOOOOO00O00O0OO ==ACTION_PREVIOUS_MENU :OO0OOOO0OO0OOOO00 .close ()#line:244
			elif O0OOOOOO00O00O0OO ==ACTION_NAV_BACK :OO0OOOO0OO0OOOO00 .close ()#line:245
	OO0O0O00O000OOOOO =OO00OO00000000OOO ("Textbox.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =O00O0OOO0O00OOOOO ,msg =OOO00OOOOOO0000O0 )#line:247
	OO0O0O00O000OOOOO .doModal ()#line:248
	del OO0O0O00O000OOOOO #line:249
def ForceFastUpDate (O00O00O0O000OO000 ,OO00O0OO0000O0O0O ,forceUpdate =False ):#line:250
	class O00OO000000OO00OO (xbmcgui .WindowXMLDialog ):#line:251
		def onInit (OOO00OOO0OO0O00OO ):#line:252
			OOO00OOO0OO0O00OO .title =101 #line:253
			OOO00OOO0OO0O00OO .msg =102 #line:254
			OOO00OOO0OO0O00OO .scrollbar =103 #line:255
			OOO00OOO0OO0O00OO .okbutton =201 #line:256
			OOO00OOO0OO0O00OO .updateP =202 #line:257
			OOO00OOO0OO0O00OO .updateX =203 #line:258
			OOO00OOO0OO0O00OO .showdialog ()#line:259
		def showdialog (OO0OO0O0OO0O00000 ):#line:261
			OO0OO0O0OO0O00000 .getControl (OO0OO0O0OO0O00000 .title ).setLabel (O00O00O0O000OO000 )#line:262
			OO0OO0O0OO0O00000 .getControl (OO0OO0O0OO0O00000 .msg ).setText (OO00O0OO0000O0O0O )#line:263
			OO0OO0O0OO0O00000 .setFocusId (OO0OO0O0OO0O00000 .okbutton )#line:264
		def doupdateP (OO00OOO0O0O000O0O ):#line:265
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:266
			OO00OOO0O0O000O0O .close ()#line:267
		def doupdateX (OOO00000OO0OOO0OO ):#line:268
			xbmc .executebuiltin ("RunPlugin(PlayMedia(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium+18&url=gui)")#line:269
			OOO00000OO0OOO0OO .close ()#line:270
		def onClick (OO00O0O0O0OOOO000 ,O0OO0O0O00OO0O0O0 ):#line:271
			if (O0OO0O0O00OO0O0O0 ==OO00O0O0O0OOOO000 .okbutton ):#line:272
				OO00O0O0O0OOOO000 .close ()#line:273
			elif (O0OO0O0O00OO0O0O0 ==OO00O0O0O0OOOO000 .updateP ):OO00O0O0O0OOOO000 .doupdateP ()#line:274
			elif (O0OO0O0O00OO0O0O0 ==OO00O0O0O0OOOO000 .updateX ):OO00O0O0O0OOOO000 .doupdateX ()#line:276
		def onAction (O000O0000OO00O0O0 ,O0OOO0OO0OO0OOO00 ):#line:278
			if O0OOO0OO0OO0OOO00 ==ACTION_PREVIOUS_MENU :O000O0000OO00O0O0 .close ()#line:279
			elif O0OOO0OO0OO0OOO00 ==ACTION_NAV_BACK :O000O0000OO00O0O0 .close ()#line:280
	OO0O0OO0OOOOO0O00 =O00OO000000OO00OO ("FastUpDate.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =O00O00O0O000OO000 ,msg =OO00O0OO0000O0O0O )#line:282
	OO0O0OO0OOOOO0O00 .doModal ()#line:283
	del OO0O0OO0OOOOO0O00 #line:284
def highlightText (O00OO00OO0OO00O0O ):#line:286
	O00OO00OO0OO00O0O =O00OO00OO0OO00O0O .replace ('\n','[NL]')#line:287
	O0O000OOO000OOO00 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00OO00OO0OO00O0O )#line:288
	for OO00O0OOO0O00O000 in O0O000OOO000OOO00 :#line:289
		OO000O0OO0000OOO0 ='-->Python callback/script returned the following error<--%s-->End of Python script error report<--'%OO00O0OOO0O00O000 #line:290
		O00OO00OO0OO00O0O =O00OO00OO0OO00O0O .replace (OO000O0OO0000OOO0 ,'[COLOR red]%s[/COLOR]'%OO000O0OO0000OOO0 )#line:291
	O00OO00OO0OO00O0O =O00OO00OO0OO00O0O .replace ('WARNING','[COLOR yellow]WARNING[/COLOR]').replace ('ERROR','[COLOR red]ERROR[/COLOR]').replace ('[NL]','\n').replace (': EXCEPTION Thrown (PythonToCppException) :','[COLOR red]: EXCEPTION Thrown (PythonToCppException) :[/COLOR]')#line:292
	O00OO00OO0OO00O0O =O00OO00OO0OO00O0O .replace ('\\\\','\\').replace (HOME ,'')#line:293
	return O00OO00OO0OO00O0O #line:294
def LogNotify (O0O0O0OO0OOOOOOO0 ,OO000OOOO0OOOO000 ,times =2000 ,icon =ICON ,sound =False ):#line:296
	DIALOG .notification (O0O0O0OO0OOOOOOO0 ,OO000OOOO0OOOO000 ,icon ,int (times ),sound )#line:297
def percentage (OOOO0O0OOOOOOO000 ,O0OOOO0OO000OOOO0 ):#line:301
	return 100 *float (OOOO0O0OOOOOOO000 )/float (O0OOOO0OO000OOOO0 )#line:302
def read_skin (O00OOOO0O0OO00OOO ):#line:303
    from resources .modules .firebase import firebase #line:304
    firebase =firebase .FirebaseApplication (theme_nox ,None )#line:305
    OOOOO00O00OO000OO =firebase .get ('/',None )#line:306
    if O00OOOO0O0OO00OOO in OOOOO00O00OO000OO :#line:307
        return OOOOO00O00OO000OO [O00OOOO0O0OO00OOO ]#line:308
    else :#line:309
        return {}#line:310
def addonUpdates (do =None ):#line:311
	O00OOOO0O0OOOO0OO ='"general.addonupdates"'#line:312
	if do =='set':#line:313
		OOO0OOOO00000OO00 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00OOOO0O0OOOO0OO )#line:314
		OO00OOOO0O0OOOOO0 =xbmc .executeJSONRPC (OOO0OOOO00000OO00 )#line:315
		O0O00O000O0O0OO00 =re .compile ('{"value":(.+?)}').findall (OO00OOOO0O0OOOOO0 )#line:316
		if len (O0O00O000O0O0OO00 )>0 :O00O0O00000O0000O =O0O00O000O0O0OO00 [0 ]#line:317
		else :O00O0O00000O0000O =0 #line:318
		setS ('default.addonupdate',str (O00O0O00000O0000O ))#line:319
		OOO0OOOO00000OO00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00OOOO0O0OOOO0OO ,'2')#line:320
		OO00OOOO0O0OOOOO0 =xbmc .executeJSONRPC (OOO0OOOO00000OO00 )#line:321
	elif do =='reset':#line:322
		try :#line:323
			O0OOOOOOOO0OO0000 =int (float (getS ('default.addonupdate')))#line:324
		except :#line:325
			O0OOOOOOOO0OO0000 =0 #line:326
		if not O0OOOOOOOO0OO0000 in [0 ,1 ,2 ]:O0OOOOOOOO0OO0000 =0 #line:327
		OOO0OOOO00000OO00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00OOOO0O0OOOO0OO ,O0OOOOOOOO0OO0000 )#line:328
		OO00OOOO0O0OOOOO0 =xbmc .executeJSONRPC (OOO0OOOO00000OO00 )#line:329
def checkBuild (O0O0OOOOO0OO0O0OO ,OO0O00OOO00OO00O0 ):#line:335
    OOO0O000O00000O00 =[]#line:336
    O00O0OO0OO00000OO =read_skin ('favourite')#line:337
    for OO000OO0OO0OOOOO0 in O00O0OO0OO00000OO :#line:338
        O0O0O00OOOO0000O0 =O00O0OO0OO00000OO [OO000OO0OO0OOOOO0 ]#line:339
        OOO0O000O00000O00 .append ((O0O0O00OOOO0000O0 ['name'],O0O0O00OOOO0000O0 ['version'],O0O0O00OOOO0000O0 ['url'],O0O0O00OOOO0000O0 ['gui'],O0O0O00OOOO0000O0 ['Kodi'],O0O0O00OOOO0000O0 ['theme'],O0O0O00OOOO0000O0 ['icon'],O0O0O00OOOO0000O0 ['fanart'],O0O0O00OOOO0000O0 ['preview'],O0O0O00OOOO0000O0 ['adult'],O0O0O00OOOO0000O0 ['preview'],O0O0O00OOOO0000O0 ['filesize'],O0O0O00OOOO0000O0 ['updatesize']))#line:340
    if not workingURL (SPEEDFILE )==True :return False #line:341
    O00O00OO00OO0000O =openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:342
    O0000OOO0OO00000O ='587'#line:343
    if 'filesize'in O00O00OO00OO0000O :#line:344
     if len (OOO0O000O00000O00 )>0 :#line:346
        for O0O0OOOOO0OO0O0OO ,O00O00OOOO0000O00 ,OO0OOOOO0OOOOO00O ,OOOOOO00O0O0OOO0O ,OO0OOOOOOO00000O0 ,OOO0OO0O000OOO0O0 ,OOO0000OO0OOO0000 ,OO000OOOO0OOO00OO ,O0OOO0OO0OOOOO000 ,OO0O0OO00O0O000OO ,O00O0OOO0OO00OO0O ,O0000OOO0OO00000O ,O000OOO0OOO000OOO in OOO0O000O00000O00 :#line:347
            if OO0O00OOO00OO00O0 =='version':return O00O00OOOO0000O00 #line:350
            elif OO0O00OOO00OO00O0 =='url':return OO0OOOOO0OOOOO00O #line:351
            elif OO0O00OOO00OO00O0 =='gui':return OOOOOO00O0O0OOO0O #line:352
            elif OO0O00OOO00OO00O0 =='kodi':return OO0OOOOOOO00000O0 #line:353
            elif OO0O00OOO00OO00O0 =='theme':return OOO0OO0O000OOO0O0 #line:354
            elif OO0O00OOO00OO00O0 =='icon':return OOO0000OO0OOO0000 #line:355
            elif OO0O00OOO00OO00O0 =='fanart':return OO000OOOO0OOO00OO #line:356
            elif OO0O00OOO00OO00O0 =='preview':return O0OOO0OO0OOOOO000 #line:357
            elif OO0O00OOO00OO00O0 =='adult':return OO0O0OO00O0O000OO #line:358
            elif OO0O00OOO00OO00O0 =='description':return O00O0OOO0OO00OO0O #line:359
            elif OO0O00OOO00OO00O0 =='filesize':return O0000OOO0OO00000O #line:360
            elif OO0O00OOO00OO00O0 =='updatesize':return O000OOO0OOO000OOO #line:361
            elif OO0O00OOO00OO00O0 =='all':return O0O0OOOOO0OO0O0OO ,O00O00OOOO0000O00 ,OO0OOOOO0OOOOO00O ,OOOOOO00O0O0OOO0O ,OO0OOOOOOO00000O0 ,OOO0OO0O000OOO0O0 ,OOO0000OO0OOO0000 ,OO000OOOO0OOO00OO ,O0OOO0OO0OOOOO000 ,OO0O0OO00O0O000OO ,O00O0OOO0OO00OO0O ,O000OOO0OOO000OOO ,O0000OOO0OO00000O #line:362
     else :return False #line:363
    else :#line:364
     OOO0O000O00000O00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O0OOOOO0OO0O0OO ).findall (O00O00OO00OO0000O )#line:366
     if len (OOO0O000O00000O00 )>0 :#line:367
        for O00O00OOOO0000O00 ,OO0OOOOO0OOOOO00O ,OOOOOO00O0O0OOO0O ,OO0OOOOOOO00000O0 ,OOO0OO0O000OOO0O0 ,OOO0000OO0OOO0000 ,OO000OOOO0OOO00OO ,O0OOO0OO0OOOOO000 ,OO0O0OO00O0O000OO ,O00O0OOO0OO00OO0O in OOO0O000O00000O00 :#line:368
            if OO0O00OOO00OO00O0 =='version':return O00O00OOOO0000O00 #line:369
            elif OO0O00OOO00OO00O0 =='url':return OO0OOOOO0OOOOO00O #line:370
            elif OO0O00OOO00OO00O0 =='gui':return OOOOOO00O0O0OOO0O #line:371
            elif OO0O00OOO00OO00O0 =='kodi':return OO0OOOOOOO00000O0 #line:372
            elif OO0O00OOO00OO00O0 =='theme':return OOO0OO0O000OOO0O0 #line:373
            elif OO0O00OOO00OO00O0 =='icon':return OOO0000OO0OOO0000 #line:374
            elif OO0O00OOO00OO00O0 =='fanart':return OO000OOOO0OOO00OO #line:375
            elif OO0O00OOO00OO00O0 =='preview':return O0OOO0OO0OOOOO000 #line:376
            elif OO0O00OOO00OO00O0 =='adult':return OO0O0OO00O0O000OO #line:377
            elif OO0O00OOO00OO00O0 =='description':return O00O0OOO0OO00OO0O #line:378
            elif OO0O00OOO00OO00O0 =='all':return O0O0OOOOO0OO0O0OO ,O00O00OOOO0000O00 ,OO0OOOOO0OOOOO00O ,OOOOOO00O0O0OOO0O ,OO0OOOOOOO00000O0 ,OOO0OO0O000OOO0O0 ,OOO0000OO0OOO0000 ,OO000OOOO0OOO00OO ,O0OOO0OO0OOOOO000 ,OO0O0OO00O0O000OO ,O00O0OOO0OO00OO0O #line:379
            elif OO0O00OOO00OO00O0 =='filesize':return '587'#line:380
     else :return False #line:381
def tryinstall ():#line:382
       try :#line:383
          import json #line:384
          OOOOOO000OO0O00O0 =(ADDON .getSetting ("user"))#line:386
          OOOOO000000O0OO0O =(ADDON .getSetting ("pass"))#line:387
          O0O00OOOOOOOOOO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:388
          OO0O0OO00OO00O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDEzMDQxMzU5MTM6QUFITHdGMWRxbktSTGQ4WUdkUjdyRldpTFdOYmFVcnE4ekUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTM2NDU5OTc4NCZ0ZXh0Pdee16DXodeZ150g15zXlNeq16fXmdefINeQ16og15TXkdeZ15zXkyAt'#line:389
          O000O000O0OO0O00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:390
          OOO000O0000O0O00O =str (json .loads (O000O000O0OO0O00O )['ip'])#line:391
          O0OO00000OOO00O00 =OOOOOO000OO0O00O0 #line:392
          O00O00O0O0OO0OO00 =OOOOO000000O0OO0O #line:393
          import socket #line:394
          O000O000O0OO0O00O =urllib2 .urlopen (OO0O0OO00OO00O0O0 .decode ('base64')+ADDON .getLocalizedString (32011 )+(HARDWAER )+ADDON .getLocalizedString (32012 )+O0OO00000OOO00O00 +ADDON .getLocalizedString (32013 )+O00O00O0O0OO0OO00 +ADDON .getLocalizedString (32014 )+O0O00OOOOOOOOOO00 +ADDON .getLocalizedString (32015 )+OOO000O0000O0O00O +ADDON .getLocalizedString (32016 )+platform ()).readlines ()#line:395
       except :pass #line:397
def checkTheme (OO0OO0O000OO000OO ,O00000O0O0O00OOO0 ,OOOOO00000OOOOOOO ):#line:399
	O0OOOO0OOO0OO00O0 =checkBuild (OO0OO0O000OO000OO ,'theme')#line:400
	if not workingURL (O0OOOO0OOO0OO00O0 )==True :return False #line:401
	O0OO0O0O0OO000OOO =openURL (O0OOOO0OOO0OO00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:402
	OOO0O0000000OO0O0 =re .compile ('name="%s".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult=(.+?).+?escription="(.+?)"'%O00000O0O0O00OOO0 ).findall (O0OO0O0O0OO000OOO )#line:403
	if len (OOO0O0000000OO0O0 )>0 :#line:404
		for O0OOO00OO0O0O0OOO ,O0OOOO0OO0OO00OOO ,OO0000OOO0OOO0OOO ,OO0O000O0OO00000O ,O0000OO0OO0OO0O00 in OOO0O0000000OO0O0 :#line:405
			if OOOOO00000OOOOOOO =='url':return O0OOO00OO0O0O0OOO #line:406
			elif OOOOO00000OOOOOOO =='icon':return O0OOOO0OO0OO00OOO #line:407
			elif OOOOO00000OOOOOOO =='fanart':return OO0000OOO0OOO0OOO #line:408
			elif OOOOO00000OOOOOOO =='adult':return OO0O000O0OO00000O #line:409
			elif OOOOO00000OOOOOOO =='description':return O0000OO0OO0OO0O00 #line:410
			elif OOOOO00000OOOOOOO =='all':return OO0OO0O000OO000OO ,O00000O0O0O00OOO0 ,O0OOO00OO0O0O0OOO ,O0OOOO0OO0OO00OOO ,OO0000OOO0OOO0OOO ,OO0O000O0OO00000O ,O0000OO0OO0OO0O00 #line:411
	else :return False #line:412
def STARTP ():#line:413
    O0O00O0O0O00OOO00 =(ADDON .getSetting ("user"))#line:414
    O0O00OOO0O00O00O0 =[]#line:415
    OOOOO00OO0OO000OO =read_skin ('skin')#line:416
    for O00O0OOOO0OOO00OO in OOOOO00OO0OO000OO :#line:417
        OO00O000000OO0000 =OOOOO00OO0OO000OO [O00O0OOOO0OOO00OO ]#line:418
        O0O00OOO0O00O00O0 .append ((OO00O000000OO0000 ['u'],OO00O000000OO0000 ['p']))#line:419
    for O0O000O000O000000 ,OO0OO0O0O00O00O00 in O0O00OOO0O00O00O0 :#line:420
      OO0O000OOO00O0OOO =O0O000O000O000000 #line:421
      O00000000OO0O00O0 =OO0OO0O0O00O00O00 #line:422
    O00OO00OOO0O00000 =urllib2 .urlopen (OO0O000OOO00O0OOO )#line:423
    OOO0O0O0O0O00OOOO =O00OO00OOO0O00000 .readlines ()#line:424
    O0OOOOOOOOOO0O0O0 =0 #line:425
    for OOOOOOOO0OOOOO00O in OOO0O0O0O0O00OOOO :#line:426
        if OOOOOOOO0OOOOO00O .split (' ==')[0 ]==O0O00O0O0O00OOO00 or OOOOOOOO0OOOOO00O .split ()[0 ]==O0O00O0O0O00OOO00 :#line:427
            O0OOOOOOOOOO0O0O0 =1 #line:428
            break #line:429
    if O0OOOOOOOOOO0O0O0 ==0 :#line:430
        O000OO000OO0OO0OO =DIALOG .yesno ("%s"%ADDON .getLocalizedString (32001 ),ADDON .getLocalizedString (32002 ),ADDON .getLocalizedString (32003 ),nolabel =ADDON .getLocalizedString (32004 ),yeslabel =ADDON .getLocalizedString (32005 ))#line:431
        LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',ADDON .getLocalizedString (32006 )),'[COLOR %s]https://t.me/kodi17[/COLOR]'%COLOR2 )#line:432
        if BUILDNAME =="":#line:433
            xbmc .executebuiltin ("ActivateWindow(home)")#line:434
        tryinstall ()#line:435
        if O000OO000OO0OO0OO :#line:436
            ADDON .openSettings ()#line:437
            sys .exit ()#line:438
        else :#line:439
            sys .exit ()#line:440
    return 'ok'#line:441
def STARTP2 ():#line:442
    O0OOO000O0OO0OO0O =''#line:443
    O0O000O0000O0000O =''#line:444
    O000OO0OO0OO00OOO =(ADDON .getSetting ("user"))#line:445
    O0OOOO00OO0000000 =[]#line:446
    OO00OO00OO0OO00OO =read_skin ('skin')#line:447
    for O000OO00O0OOOOO0O in OO00OO00OO0OO00OO :#line:448
        OO0O00OO00O00OOO0 =OO00OO00OO0OO00OO [O000OO00O0OOOOO0O ]#line:449
        O0OOOO00OO0000000 .append ((OO0O00OO00O00OOO0 ['u'],OO0O00OO00O00OOO0 ['p']))#line:450
    for O0O0OO0OOOOOO0OO0 ,OOOO00OO0OOO00OO0 in O0OOOO00OO0000000 :#line:451
      O0OOO000O0OO0OO0O =O0O0OO0OOOOOO0OO0 #line:452
      O0O000O0000O0000O =OOOO00OO0OOO00OO0 #line:453
    O0OOO0OOO0O00O000 =urllib2 .urlopen (O0OOO000O0OO0OO0O )#line:454
    O0O00O0O000O0OO0O =O0OOO0OOO0O00O000 .readlines ()#line:455
    OO00OOOOOOOO0OO0O =0 #line:456
    for O0OOO0O000OOOOOOO in O0O00O0O000O0OO0O :#line:457
        if O0OOO0O000OOOOOOO .split (' ==')[0 ]==O000OO0OO0OO00OOO or O0OOO0O000OOOOOOO .split ()[0 ]==O000OO0OO0OO00OOO :#line:458
            OO00OOOOOOOO0OO0O =1 #line:459
            break #line:460
    if OO00OOOOOOOO0OO0O ==0 :#line:461
        O0O000O00000O000O =DIALOG .yesno ("%s"%ADDON .getLocalizedString (32001 ),ADDON .getLocalizedString (32002 ),ADDON .getLocalizedString (32003 ),nolabel =ADDON .getLocalizedString (32004 ),yeslabel =ADDON .getLocalizedString (32005 ))#line:462
        LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',ADDON .getLocalizedString (32006 )),'[COLOR %s]https://t.me/kodi17[/COLOR]'%COLOR2 )#line:463
        if BUILDNAME =="":#line:464
            xbmc .executebuiltin ("ActivateWindow(home)")#line:465
        tryinstall ()#line:466
        if O0O000O00000O000O :#line:467
            ADDON .openSettings ()#line:468
            sys .exit ()#line:469
        else :#line:470
            sys .exit ()#line:471
    OO00OO0OOOOO0O0O0 =(ADDON .getSetting ("pass"))#line:472
    O0OOO0OOO0O00O000 =urllib2 .urlopen (O0O000O0000O0000O )#line:473
    OOO00O0OOO0OOOO00 =O0OOO0OOO0O00O000 .readlines ()#line:474
    OO00OOOO00O0O0O00 =0 #line:475
    for O0OOO0O000OOOOOOO in OOO00O0OOO0OOOO00 :#line:476
        if O0OOO0O000OOOOOOO .split (' ==')[0 ]==OO00OO0OOOOO0O0O0 or O0OOO0O000OOOOOOO .split ()[0 ]==OO00OO0OOOOO0O0O0 :#line:477
            OO00OOOO00O0O0O00 =1 #line:478
            break #line:479
    if OO00OOOO00O0O0O00 ==0 :#line:480
        O0O000O00000O000O =DIALOG .yesno ("%s"%ADDON .getLocalizedString (32007 ),ADDON .getLocalizedString (32008 ),ADDON .getLocalizedString (32009 ),nolabel =ADDON .getLocalizedString (32004 ),yeslabel =ADDON .getLocalizedString (32010 ))#line:481
        LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',ADDON .getLocalizedString (32006 )),'[COLOR %s]https://t.me/kodi17[/COLOR]'%COLOR2 )#line:482
        if BUILDNAME =="":#line:483
            xbmc .executebuiltin ("ActivateWindow(home)")#line:484
        tryinstall ()#line:485
        if O0O000O00000O000O :#line:486
            ADDON .openSettings ()#line:487
            sys .exit ()#line:488
        else :#line:489
            sys .exit ()#line:490
    return 'ok'#line:491
def checkWizard (O0OO0O0OOOO00O0OO ):#line:492
	if not workingURL (WIZARDFILE )==True :return False #line:493
	OOO0OO0O000OOOOOO =openURL (WIZARDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:494
	OO00OOOOO0OO0O0O0 =re .compile ('id="%s".+?ersion="(.+?)".+?ip="(.+?)"'%ADDON_ID ).findall (OOO0OO0O000OOOOOO )#line:495
	if len (OO00OOOOO0OO0O0O0 )>0 :#line:496
		for O00OOOOO0O0OO0O00 ,OO000OOO00O0OO0OO in OO00OOOOO0OO0O0O0 :#line:497
			if O0OO0O0OOOO00O0OO =='version':return O00OOOOO0O0OO0O00 #line:498
			elif O0OO0O0OOOO00O0OO =='zip':return OO000OOO00O0OO0OO #line:499
			elif O0OO0O0OOOO00O0OO =='all':return ADDON_ID ,O00OOOOO0O0OO0O00 ,OO000OOO00O0OO0OO #line:500
	else :return False #line:501
def buildCount (ver =None ):#line:503
	OOO00O00000O0O0O0 =openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:504
	O0OOOO0000OO0O0O0 =re .compile ('name="(.+?)".+?odi="(.+?)".+?dult="(.+?)"').findall (OOO00O00000O0O0O0 )#line:505
	OO0000O00O00OOOO0 =0 ;OO0000O000OO00O00 =0 ;O00O0O00O0O0OO0OO =0 ;O00O0000O0O00O000 =0 ;O00OOO00O0O00OOOO =0 ;O000000000O0O00O0 =0 ;O0O0OOO0O00O0OO00 =0 #line:506
	if len (O0OOOO0000OO0O0O0 )>0 :#line:507
		for OOO00OO0OOOOOO000 ,OO00000OOO000OO00 ,OO00O0000O0OOOO0O in O0OOOO0000OO0O0O0 :#line:508
			if not SHOWADULT =='true'and OO00O0000O0OOOO0O .lower ()=='yes':O000000000O0O00O0 +=1 ;O0O0OOO0O00O0OO00 +=1 ;continue #line:509
			if not DEVELOPER =='true'and strTest (OOO00OO0OOOOOO000 ):O000000000O0O00O0 +=1 ;continue #line:510
			OO00000OOO000OO00 =int (float (OO00000OOO000OO00 ))#line:511
			OO0000O00O00OOOO0 +=1 #line:512
			if OO00000OOO000OO00 ==18 :O00OOO00O0O00OOOO +=1 #line:513
			elif OO00000OOO000OO00 ==17 :O00O0000O0O00O000 +=1 #line:514
			elif OO00000OOO000OO00 ==16 :O00O0O00O0O0OO0OO +=1 #line:515
			elif OO00000OOO000OO00 <=15 :OO0000O000OO00O00 +=1 #line:516
	return OO0000O00O00OOOO0 ,OO0000O000OO00O00 ,O00O0O00O0O0OO0OO ,O00O0000O0O00O000 ,O00OOO00O0O00OOOO ,O0O0OOO0O00O0OO00 ,O000000000O0O00O0 #line:517
def strTest (O0O0OO0OO000000OO ):#line:519
	OOOO0O00OOO00OO0O =(O0O0OO0OO000000OO .lower ()).split (' ')#line:520
	if 'test'in OOOO0O00OOO00OO0O :return True #line:521
	else :return False #line:522
def themeCount (OOOO00OOO0O0O00O0 ,count =True ):#line:524
	OO00OO000O00O0000 =checkBuild (OOOO00OOO0O0O00O0 ,'theme')#line:525
	if OO00OO000O00O0000 =='http://':return False #line:526
	O000OO000O000OOOO =openURL (OO00OO000O00O0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:527
	OO0OO0O000OOOOOO0 =re .compile ('name="(.+?)".+?dult="(.+?)"').findall (O000OO000O000OOOO )#line:528
	if len (OO0OO0O000OOOOOO0 )==0 :return False #line:529
	OOOOO0OO000O0OO00 =[]#line:530
	for O00000OOOO0O000O0 ,O0OOO0O0O0OO0O00O in OO0OO0O000OOOOOO0 :#line:531
		if not SHOWADULT =='true'and O0OOO0O0O0OO0O00O .lower ()=='yes':continue #line:532
		OOOOO0OO000O0OO00 .append (O00000OOOO0O000O0 )#line:533
	if len (OOOOO0OO000O0OO00 )>0 :#line:534
		if count ==True :return len (OOOOO0OO000O0OO00 )#line:535
		else :return OOOOO0OO000O0OO00 #line:536
	else :return False #line:537
def thirdParty (url =None ):#line:539
	if url ==None :return #line:540
	OOOOOO0O0O0OO0OO0 =openURL (url ).replace ('\n','').replace ('\r','').replace ('\t','')#line:541
	O00OOO00O0000O0O0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?odi="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOOO0O0O0OO0OO0 )#line:542
	OO0000OOOO0O0OOO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOOOOO0O0O0OO0OO0 )#line:543
	if len (O00OOO00O0000O0O0 )>0 :#line:544
		return True ,O00OOO00O0000O0O0 #line:545
	elif len (OO0000OOOO0O0OOO0 )>0 :#line:546
		return False ,OO0000OOOO0O0OOO0 #line:547
	else :#line:548
		return False ,[]#line:549
def workingURL (O000O0OOOOO0OOOO0 ):#line:555
	if O000O0OOOOO0OOOO0 in ['http://','https://','']:return False #line:556
	OOO00O00O00O0OOO0 =0 ;OO000O00O0OOOO00O =''#line:557
	while OOO00O00O00O0OOO0 <3 :#line:558
		OOO00O00O00O0OOO0 +=1 #line:559
		try :#line:560
			OOO0OO0OO0OO00000 =urllib2 .Request (O000O0OOOOO0OOOO0 )#line:561
			OOO0OO0OO0OO00000 .add_header ('User-Agent',USER_AGENT )#line:562
			O000OO00O00O0O000 =urllib2 .urlopen (OOO0OO0OO0OO00000 )#line:563
			O000OO00O00O0O000 .close ()#line:564
			OO000O00O0OOOO00O =True #line:565
			break #line:566
		except Exception as OO0OOOO0O00OO000O :#line:567
			OO000O00O0OOOO00O =str (OO0OOOO0O00OO000O )#line:568
			log ("Working Url Error: %s [%s]"%(OO0OOOO0O00OO000O ,O000O0OOOOO0OOOO0 ))#line:569
			xbmc .sleep (500 )#line:570
	return OO000O00O0OOOO00O #line:571
def openURL (O0000OOOO0O0O0OOO ):#line:573
	O0O00OO0O0O0O00OO =urllib2 .Request (O0000OOOO0O0O0OOO )#line:574
	O0O00OO0O0O0O00OO .add_header ('User-Agent',USER_AGENT )#line:575
	OO00OO00000OOO00O =urllib2 .urlopen (O0O00OO0O0O0O00OO )#line:576
	O000OO0OO00000OOO =OO00OO00000OOO00O .read ()#line:577
	OO00OO00000OOO00O .close ()#line:578
	return O000OO0OO00000OOO #line:579
def getKeyboard (default ="",heading ="",hidden =False ):#line:585
	O0O00O0O0O0O00O00 =xbmc .Keyboard (default ,heading ,hidden )#line:586
	O0O00O0O0O0O00O00 .doModal ()#line:587
	if O0O00O0O0O0O00O00 .isConfirmed ():#line:588
		return unicode (O0O00O0O0O0O00O00 .getText (),"utf-8")#line:589
	return default #line:590
def getSize (O00OOO000OO0OOOO0 ,total =0 ):#line:592
	for OOO0O0OOOO00000OO ,O0OOO000OOOO00OO0 ,OO00O0000O0O0OO00 in os .walk (O00OOO000OO0OOOO0 ):#line:593
		for OO0O0OOO0OOOOOO0O in OO00O0000O0O0OO00 :#line:594
			O00000O0O0O00OOOO =os .path .join (OOO0O0OOOO00000OO ,OO0O0OOO0OOOOOO0O )#line:595
			total +=os .path .getsize (O00000O0O0O00OOOO )#line:596
	return total #line:597
def convertSize (OOO00O00O000OOOOO ,suffix ='B'):#line:599
	for O0O00O0O0OO0O000O in ['','K','M','G']:#line:600
		if abs (OOO00O00O000OOOOO )<1024.0 :#line:601
			return "%3.02f %s%s"%(OOO00O00O000OOOOO ,O0O00O0O0OO0O000O ,suffix )#line:602
		OOO00O00O000OOOOO /=1024.0 #line:603
	return "%.02f %s%s"%(OOO00O00O000OOOOO ,'G',suffix )#line:604
def getCacheSize ():#line:606
	O00O000O00OO00OO0 =os .path .join (PROFILE ,'addon_data')#line:607
	O0O00O0000O0O0OOO =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:616
	O000OO0O000O0O0OO =[(O00O000O00OO00OO0 ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'script.module.simple.downloader')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (O00O000O00OO00OO0 ,'script.module.simple.downloader')),(os .path .join (O00O000O00OO00OO0 ,'plugin.video.itv','Images'))]#line:627
	OOOOOOOOO0OOOOOO0 =0 #line:629
	for O00000OO0OO000000 in O000OO0O000O0O0OO :#line:631
		if os .path .exists (O00000OO0OO000000 )and not O00000OO0OO000000 in [ADDONDATA ,O00O000O00OO00OO0 ]:#line:632
			OOOOOOOOO0OOOOOO0 =getSize (O00000OO0OO000000 ,OOOOOOOOO0OOOOOO0 )#line:633
		else :#line:634
			for OOOOOOOOO0O0OOOO0 ,O00O00OOOO000000O ,OOOOO00000O00O000 in os .walk (O00000OO0OO000000 ):#line:635
				for O0000OOO0OOO0O0OO in O00O00OOOO000000O :#line:636
					if 'cache'in O0000OOO0OOO0O0OO .lower ()and not O0000OOO0OOO0O0OO .lower ()=='meta_cache':OOOOOOOOO0OOOOOO0 =getSize (os .path .join (OOOOOOOOO0O0OOOO0 ,O0000OOO0OOO0O0OO ),OOOOOOOOO0OOOOOO0 )#line:637
	if INCLUDEVIDEO =='true':#line:639
		OOOOO00000O00O000 =[]#line:640
		if INCLUDEALL =='true':OOOOO00000O00O000 =O0O00O0000O0O0OOO #line:641
		else :#line:642
			if INCLUDEBOB =='true':OOOOO00000O00O000 .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:643
			if INCLUDEPHOENIX =='true':OOOOO00000O00O000 .append (os .path .join (ADDONDATA ,'plugin.video.phstreams','cache.db'))#line:644
			if INCLUDESPECTO =='true':OOOOO00000O00O000 .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:645
			if INCLUDEGENESIS =='true':OOOOO00000O00O000 .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:646
			if INCLUDEEXODUS =='true':OOOOO00000O00O000 .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:647
			if INCLUDEONECHAN =='true':OOOOO00000O00O000 .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:648
			if INCLUDESALTS =='true':OOOOO00000O00O000 .append (os .path .join (DATABASE ,'saltscache.db'))#line:649
			if INCLUDESALTSHD =='true':OOOOO00000O00O000 .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:650
		if len (OOOOO00000O00O000 )>0 :#line:651
			for O00000OO0OO000000 in OOOOO00000O00O000 :OOOOOOOOO0OOOOOO0 =getSize (O00000OO0OO000000 ,OOOOOOOOO0OOOOOO0 )#line:652
		else :log ("Clear Cache: Clear Video Cache Not Enabled",xbmc .LOGNOTICE )#line:653
	return OOOOOOOOO0OOOOOO0 #line:654
def getInfo (OO0OO000O0OO0OOOO ):#line:656
	try :return xbmc .getInfoLabel (OO0OO000O0OO0OOOO )#line:657
	except :return False #line:658
def removeFolder (O0OOO0O0OO0OOO0OO ):#line:660
	log ("Deleting Folder: %s"%O0OOO0O0OO0OOO0OO ,xbmc .LOGNOTICE )#line:661
	try :shutil .rmtree (O0OOO0O0OO0OOO0OO ,ignore_errors =True ,onerror =None )#line:662
	except :return False #line:663
def removeFile (O0OO0O0OOO0OOOO00 ):#line:665
	log ("Deleting File: %s"%O0OO0O0OOO0OOOO00 ,xbmc .LOGNOTICE )#line:666
	try :os .remove (O0OO0O0OOO0OOOO00 )#line:667
	except :return False #line:668
def currSkin ():#line:670
	return xbmc .getSkinDir ()#line:671
def cleanHouse (OO0OO00000OO0OOOO ,ignore =False ):#line:673
	log (OO0OO00000OO0OOOO )#line:674
	O0OO0OOOOO0000O0O =0 ;O0OOO000O00O0OOO0 =0 #line:675
	for OO0O0OO0OOO0O00O0 ,O0OOO00OOO000OOO0 ,O0OOOOO00OOOOOOO0 in os .walk (OO0OO00000OO0OOOO ):#line:676
		if ignore ==False :O0OOO00OOO000OOO0 [:]=[OOOOO0000O000000O for OOOOO0000O000000O in O0OOO00OOO000OOO0 if OOOOO0000O000000O not in EXCLUDES ]#line:677
		OOO0O0O0000OOOO00 =0 #line:678
		OOO0O0O0000OOOO00 +=len (O0OOOOO00OOOOOOO0 )#line:679
		if OOO0O0O0000OOOO00 >=0 :#line:680
			for O00000OOO0OO00O0O in O0OOOOO00OOOOOOO0 :#line:681
				try :#line:682
					os .unlink (os .path .join (OO0O0OO0OOO0O00O0 ,O00000OOO0OO00O0O ))#line:683
					O0OO0OOOOO0000O0O +=1 #line:684
				except :#line:685
					try :#line:686
						shutil .rmtree (os .path .join (OO0O0OO0OOO0O00O0 ,O00000OOO0OO00O0O ))#line:687
					except :#line:688
						log ("Error Deleting %s"%O00000OOO0OO00O0O ,xbmc .LOGERROR )#line:689
			for O000O00OOOO0OO00O in O0OOO00OOO000OOO0 :#line:690
				O0OOO000O00O0OOO0 +=1 #line:691
				try :#line:692
					shutil .rmtree (os .path .join (OO0O0OO0OOO0O00O0 ,O000O00OOOO0OO00O ))#line:693
					O0OOO000O00O0OOO0 +=1 #line:694
				except :#line:695
					log ("Error Deleting %s"%O000O00OOOO0OO00O ,xbmc .LOGERROR )#line:696
	return O0OO0OOOOO0000O0O ,O0OOO000O00O0OOO0 #line:697
def emptyfolder (OOO0OOOO0OO0O0O0O ):#line:699
	OO0000O00OOOO0OOO =0 #line:700
	for O0000000000OO0000 ,OOOO0O0O0O000O0OO ,OO0O0OO0OOO00O0OO in os .walk (OOO0OOOO0OO0O0O0O ,topdown =True ):#line:701
		OOOO0O0O0O000O0OO [:]=[OOOO0O00OOOOO000O for OOOO0O00OOOOO000O in OOOO0O0O0O000O0OO if OOOO0O00OOOOO000O not in EXCLUDES ]#line:702
		O0O00O00O0OOOOOO0 =0 #line:703
		O0O00O00O0OOOOOO0 +=len (OO0O0OO0OOO00O0OO )+len (OOOO0O0O0O000O0OO )#line:704
		if O0O00O00O0OOOOOO0 ==0 :#line:705
			shutil .rmtree (os .path .join (O0000000000OO0000 ))#line:706
			OO0000O00OOOO0OOO +=1 #line:707
			log ("Empty Folder: %s"%O0000000000OO0000 ,xbmc .LOGNOTICE )#line:708
	return OO0000O00OOOO0OOO #line:709
def log (O00O0OO0OOOOOO000 ,level =xbmc .LOGDEBUG ):#line:711
	if not os .path .exists (ADDONDATA ):os .makedirs (ADDONDATA )#line:712
	if not os .path .exists (WIZLOG ):O00000000O00OOOO0 =open (WIZLOG ,'w');O00000000O00OOOO0 .close ()#line:713
	if WIZDEBUGGING =='false':return False #line:714
	if DEBUGLEVEL =='0':return False #line:715
	if DEBUGLEVEL =='1'and not level in [xbmc .LOGNOTICE ,xbmc .LOGERROR ,xbmc .LOGSEVERE ,xbmc .LOGFATAL ]:return False #line:716
	if DEBUGLEVEL =='2':level =xbmc .LOGNOTICE #line:717
	try :#line:718
		if isinstance (O00O0OO0OOOOOO000 ,unicode ):#line:719
			O00O0OO0OOOOOO000 ='%s'%(O00O0OO0OOOOOO000 .encode ('utf-8'))#line:720
		xbmc .log ('%s: %s'%(ADDONTITLE ,O00O0OO0OOOOOO000 ),level )#line:721
	except Exception as OO0OOO0000OO0000O :#line:722
		try :xbmc .log ('Logging Failure: %s'%(OO0OOO0000OO0000O ),level )#line:723
		except :pass #line:724
	if ENABLEWIZLOG =='true':#line:725
		O0O0O0OO0OO000O0O =getS ('nextcleandate')if not getS ('nextcleandate')==''else str (TODAY )#line:726
		if CLEANWIZLOG =='true'and O0O0O0OO0OO000O0O <=str (TODAY ):checkLog ()#line:727
		with open (WIZLOG ,'a')as O00000000O00OOOO0 :#line:728
			O00OOO00OO0O0O0OO ="[%s %s] %s"%(datetime .now ().date (),str (datetime .now ().time ())[:8 ],O00O0OO0OOOOOO000 )#line:729
			O00000000O00OOOO0 .write (O00OOO00OO0O0O0OO .rstrip ('\r\n')+'\n')#line:730
def checkLog ():#line:732
	O00O0000000000000 =getS ('nextcleandate')#line:733
	OO0OOO000O000O0O0 =TOMORROW #line:734
	if CLEANWIZLOGBY =='0':#line:735
		O0O000OO0O00000OO =TODAY -timedelta (days =MAXWIZDATES [int (float (CLEANDAYS ))])#line:736
		OOO0OOOO00OOO0OO0 =0 #line:737
		OOO0OO0O0000OOO00 =open (WIZLOG );OOOO0O0OOO0OO0O0O =OOO0OO0O0000OOO00 .read ();OOO0OO0O0000OOO00 .close ();OOOOO0OOOO00OO00O =OOOO0O0OOO0OO0O0O .split ('\n')#line:738
		for OOO0OO0O00O0OO000 in OOOOO0OOOO00OO00O :#line:739
			if str (OOO0OO0O00O0OO000 [1 :11 ])>=str (O0O000OO0O00000OO ):#line:740
				break #line:741
			OOO0OOOO00OOO0OO0 +=1 #line:742
		OO00OO00000OO0OOO =OOOOO0OOOO00OO00O [OOO0OOOO00OOO0OO0 :]#line:743
		O0O0O0OOO0O000O0O ='\n'.join (OO00OO00000OO0OOO )#line:744
		OOO0OO0O0000OOO00 =open (WIZLOG ,'w');OOO0OO0O0000OOO00 .write (O0O0O0OOO0O000O0O );OOO0OO0O0000OOO00 .close ()#line:745
	elif CLEANWIZLOGBY =='1':#line:746
		O00O0000O0OO00OOO =MAXWIZSIZE [int (float (CLEANSIZE ))]*1024 #line:747
		OOO0OO0O0000OOO00 =open (WIZLOG );OOOO0O0OOO0OO0O0O =OOO0OO0O0000OOO00 .read ();OOO0OO0O0000OOO00 .close ();OOOOO0OOOO00OO00O =OOOO0O0OOO0OO0O0O .split ('\n')#line:748
		if os .path .getsize (WIZLOG )>=O00O0000O0OO00OOO :#line:749
			OO0O00O00O0OO00OO =len (OOOOO0OOOO00OO00O )/2 #line:750
			OO00OO00000OO0OOO =OOOOO0OOOO00OO00O [OO0O00O00O0OO00OO :]#line:751
			O0O0O0OOO0O000O0O ='\n'.join (OO00OO00000OO0OOO )#line:752
			OOO0OO0O0000OOO00 =open (WIZLOG ,'w');OOO0OO0O0000OOO00 .write (O0O0O0OOO0O000O0O );OOO0OO0O0000OOO00 .close ()#line:753
	elif CLEANWIZLOGBY =='2':#line:754
		OOO0OO0O0000OOO00 =open (WIZLOG );OOOO0O0OOO0OO0O0O =OOO0OO0O0000OOO00 .read ();OOO0OO0O0000OOO00 .close ();OOOOO0OOOO00OO00O =OOOO0O0OOO0OO0O0O .split ('\n')#line:755
		OO0O0000O00O0O00O =MAXWIZLINES [int (float (CLEANLINES ))]#line:756
		if len (OOOOO0OOOO00OO00O )>OO0O0000O00O0O00O :#line:757
			OO0O00O00O0OO00OO =len (OOOOO0OOOO00OO00O )-int (OO0O0000O00O0O00O /2 )#line:758
			OO00OO00000OO0OOO =OOOOO0OOOO00OO00O [OO0O00O00O0OO00OO :]#line:759
			O0O0O0OOO0O000O0O ='\n'.join (OO00OO00000OO0OOO )#line:760
			OOO0OO0O0000OOO00 =open (WIZLOG ,'w');OOO0OO0O0000OOO00 .write (O0O0O0OOO0O000O0O );OOO0OO0O0000OOO00 .close ()#line:761
	setS ('nextcleandate',str (OO0OOO000O000O0O0 ))#line:762
def latestDB (O0OOO00O00000OOOO ):#line:764
	if O0OOO00O00000OOOO in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:765
		O0O0O0O000O000O00 =glob .glob (os .path .join (DATABASE ,'%s*.db'%O0OOO00O00000OOOO ))#line:766
		O0OO00O0OOOOOO0O0 ='%s(.+?).db'%O0OOO00O00000OOOO [1 :]#line:767
		O0O000O0OO000OO0O =0 #line:768
		for O00O00O0OOO0O000O in O0O0O0O000O000O00 :#line:769
			try :OO0OOO000O0OOOO0O =int (re .compile (O0OO00O0OOOOOO0O0 ).findall (O00O00O0OOO0O000O )[0 ])#line:770
			except :OO0OOO000O0OOOO0O =0 #line:771
			if O0O000O0OO000OO0O <OO0OOO000O0OOOO0O :#line:772
				O0O000O0OO000OO0O =OO0OOO000O0OOOO0O #line:773
		return '%s%s.db'%(O0OOO00O00000OOOO ,O0O000O0OO000OO0O )#line:774
	else :return False #line:775
def addonId (O00O0OO00O00000O0 ):#line:777
	try :#line:778
		return xbmcaddon .Addon (id =O00O0OO00O00000O0 )#line:779
	except :#line:780
		return False #line:781
def toggleDependency (O0O000000O0000O00 ,DP =None ):#line:783
	OO0OOO00O00OO00OO =os .path .join (ADDONS ,O0O000000O0000O00 ,'addon.xml')#line:784
	if os .path .exists (OO0OOO00O00OO00OO ):#line:785
		O0OOOO0O0OOOOO00O =open (OO0OOO00O00OO00OO ,mode ='r');OOOOO00OOO000OO00 =O0OOOO0O0OOOOO00O .read ();O0OOOO0O0OOOOO00O .close ();#line:786
		O00O00OOO0O0OO000 =parseDOM (OOOOO00OOO000OO00 ,'import',ret ='addon')#line:787
		for O0OOO0OO0O00000OO in O00O00OOO0O0OO000 :#line:788
			if not 'xbmc.python'in O0OOO0OO0O00000OO :#line:789
				OOOO00O0OOOO0000O =os .path .join (ADDONS ,O0OOO0OO0O00000OO )#line:790
				if not DP ==None :#line:791
					DP .update ("","Checking Dependency [COLOR yellow]%s[/COLOR] for [COLOR yellow]%s[/COLOR]"%(O0OOO0OO0O00000OO ,O0O000000O0000O00 ),"")#line:792
				if os .path .exists (OOOO00O0OOOO0000O ):#line:793
					toggleAddon (O0O000000O0000O00 ,'true')#line:794
			xbmc .sleep (100 )#line:795
def toggleAdult ():#line:797
	O0OO00OOO0O0OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Enable[/COLOR] or [COLOR %s]Disable[/COLOR] all Adult addons?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Enable[/COLOR][/B]",nolabel ="[B][COLOR red]Disable[/COLOR][/B]")#line:798
	O0OO0OO00000O0O0O ='true'if O0OO00OOO0O0OO00O ==1 else 'false'#line:799
	OOOOO00O0O00OO0O0 ='Enabling'if O0OO00OOO0O0OO00O ==1 else 'Disabling'#line:800
	OO0O0O00O00OO00O0 =openURL ('http://noobsandnerds.com/TI/AddonPortal/adult.php').replace ('\n','').replace ('\r','').replace ('\t','')#line:801
	OOOOO000O00OOOO00 =re .compile ('i="(.+?)"').findall (OO0O0O00O00OO00O0 )#line:802
	OO0OO00OO0OOOO0O0 =[]#line:803
	for OO00O00O00O0OOOO0 in OOOOO000O00OOOO00 :#line:804
		OOOO0OO00OO00O0O0 =os .path .join (ADDONS ,OO00O00O00O0OOOO0 )#line:805
		if os .path .exists (OOOO0OO00OO00O0O0 ):#line:806
			OO0OO00OO0OOOO0O0 .append (OO00O00O00O0OOOO0 )#line:807
			toggleAddon (OO00O00O00O0OOOO0 ,O0OO0OO00000O0O0O ,True )#line:808
			log ("[Toggle Adult] %s %s"%(OOOOO00O0O00OO0O0 ,OO00O00O00O0OOOO0 ),xbmc .LOGNOTICE )#line:809
	if len (OO0OO00OO0OOOO0O0 )>0 :#line:810
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to view a list of the addons that where %s?[/COLOR]"%(COLOR2 ,OOOOO00O0O00OO0O0 .replace ('ing','ed')),yeslabel ="[B][COLOR green]View List[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:811
			OOOO0OO000O0O0000 ='[CR]'.join (OO0OO00OO0OOOO0O0 )#line:812
			TextBox (ADDONTITLE ,"[COLOR %s]Here are a list of the addons that where %s for Adult Content:[/COLOR][CR][CR][COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO00O0O00OO0O0 .replace ('ing','ed'),COLOR2 ,OOOO0OO000O0O0000 ))#line:813
		else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s][COLOR %s]%d[/COLOR] Adult Addons %s[/COLOR]"%(COLOR2 ,COLOR1 ,count ,OOOOO00O0O00OO0O0 .replace ('ing','ed')))#line:814
		forceUpdate (True )#line:815
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Adult Addons Found[/COLOR]"%COLOR2 )#line:816
def createTemp (OOOOO0OOOO0O000OO ):#line:818
	O000O00O0OOOOOO00 =os .path .join (PLUGIN ,'resources','tempaddon.xml')#line:819
	O0OOOOO0O0000OOO0 =open (O000O00O0OOOOOO00 ,'r');OOOO0OO000000OO0O =O0OOOOO0O0000OOO0 .read ();O0OOOOO0O0000OOO0 .close ()#line:820
	OOO0000O0O0O00OO0 =os .path .join (ADDONS ,OOOOO0OOOO0O000OO )#line:821
	if not os .path .exists (OOO0000O0O0O00OO0 ):os .makedirs (OOO0000O0O0O00OO0 )#line:822
	O0000000O0O0O0OOO =open (os .path .join (OOO0000O0O0O00OO0 ,'addon.xml'),'w')#line:823
	O0000000O0O0O0OOO .write (OOOO0OO000000OO0O .replace ('testid',OOOOO0OOOO0O000OO ).replace ('testversion','0.0.1'))#line:824
	O0000000O0O0O0OOO .close ()#line:825
	log ("%s: wrote addon.xml"%OOOOO0OOOO0O000OO )#line:826
def fixmetas ():#line:828
	OOOOOOO000OO0OOOO =['']#line:829
	OOO0O000OOO00OO0O =os .path .join (PLUGIN ,'resources','tempaddon.xml')#line:830
	O0O0O0O0OOO0OO0OO =open (OOO0O000OOO00OO0O ,'r');O0000OOO0O0O0OOO0 =O0O0O0O0OOO0OO0OO .read ();O0O0O0O0OOO0OO0OO .close ()#line:831
	for O0OO00OO00OOO00O0 in OOOOOOO000OO0OOOO :#line:832
		O00000OOOO00000O0 =os .path .join (ADDONS ,O0OO00OO00OOO00O0 )#line:833
		if os .path .exists (O00000OOOO00000O0 ):#line:834
			if not os .path .exists (os .path .join (O00000OOOO00000O0 ,'addon.xml')):continue #line:835
			O000O000O00O0OO0O =open (os .path .join (O00000OOOO00000O0 ,'addon.xml'),'w')#line:836
			O000O000O00O0OO0O .write (O0000OOO0O0O0OOO0 .replace ('testid',O0OO00OO00OOO00O0 ).replace ('testversion','0.0.1'))#line:837
			O000O000O00O0OO0O .close ()#line:838
			log ("%s: re-wrote addon.xml"%O0OO00OO00OOO00O0 )#line:839
def toggleAddon (OO0OO0OO00OO0OOO0 ,O0000OOO0O000OOO0 ,over =None ):#line:841
	if KODIV >=17 :#line:842
		addonDatabase (OO0OO0OO00OO0OOO0 ,O0000OOO0O000OOO0 )#line:843
		return #line:844
	O000OOOO00OOO00O0 =OO0OO0OO00OO0OOO0 #line:845
	O0OOOOOO0O0O000OO =os .path .join (ADDONS ,OO0OO0OO00OO0OOO0 ,'addon.xml')#line:846
	if os .path .exists (O0OOOOOO0O0O000OO ):#line:847
		O0OO0O00OO000OOO0 =open (O0OOOOOO0O0O000OO )#line:848
		O0OO000000O0O0O0O =O0OO0O00OO000OOO0 .read ()#line:849
		OOO0OOO000OO000OO =parseDOM (O0OO000000O0O0O0O ,'addon',ret ='id')#line:850
		O0OO0O000OOO00O0O =parseDOM (O0OO000000O0O0O0O ,'addon',ret ='name')#line:851
		O00OOO00O00OO0OO0 =parseDOM (O0OO000000O0O0O0O ,'extension',ret ='library',attrs ={'point':'xbmc.service'})#line:852
		try :#line:853
			if len (OOO0OOO000OO000OO )>0 :#line:854
				O000OOOO00OOO00O0 =OOO0OOO000OO000OO [0 ]#line:855
			if len (O00OOO00O00OO0OO0 )>0 :#line:856
				log ("We got a live one, stopping script: %s"%match [0 ],xbmc .LOGDEBUG )#line:857
				ebi ('StopScript(%s)'%os .path .join (ADDONS ,O000OOOO00OOO00O0 ))#line:858
				ebi ('StopScript(%s)'%O000OOOO00OOO00O0 )#line:859
				ebi ('StopScript(%s)'%os .path .join (ADDONS ,O000OOOO00OOO00O0 ,O00OOO00O00OO0OO0 [0 ]))#line:860
				xbmc .sleep (500 )#line:861
		except :#line:862
			pass #line:863
	OOOO000O0O0OOO0OO ='{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}, "id":1}'%(O000OOOO00OOO00O0 ,O0000OOO0O000OOO0 )#line:864
	O00OOOO000000OOO0 =xbmc .executeJSONRPC (OOOO000O0O0OOO0OO )#line:865
	if 'error'in O00OOOO000000OOO0 and over ==None :#line:866
		OOO00OO0000O0OOO0 ='Enabling'if O0000OOO0O000OOO0 =='true'else 'Disabling'#line:867
		DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error %s [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,OOO00OO0000O0OOO0 ,OO0OO0OO00OO0OOO0 ),"Check to make sure the addon list is upto date and try again.[/COLOR]")#line:868
		forceUpdate ()#line:869
def addonInfo (O0OOO0OOOOOO0000O ,OOO0O00O0OOOOO0OO ):#line:871
	O0OO0000000000OOO =addonId (O0OOO0OOOOOO0000O )#line:872
	if O0OO0000000000OOO :return O0OO0000000000OOO .getAddonInfo (OOO0O00O0OOOOO0OO )#line:873
	else :return False #line:874
def whileWindow (O000OOO0OOOOOO0O0 ,active =False ,count =0 ,counter =15 ):#line:876
	OOOO0OOO00O0OOO00 =getCond ('Window.IsActive(%s)'%O000OOO0OOOOOO0O0 )#line:877
	log ("%s is %s"%(O000OOO0OOOOOO0O0 ,OOOO0OOO00O0OOO00 ),xbmc .LOGDEBUG )#line:878
	while not OOOO0OOO00O0OOO00 and count <counter :#line:879
		log ("%s is %s(%s)"%(O000OOO0OOOOOO0O0 ,OOOO0OOO00O0OOO00 ,count ))#line:880
		OOOO0OOO00O0OOO00 =getCond ('Window.IsActive(%s)'%O000OOO0OOOOOO0O0 )#line:881
		count +=1 #line:882
		xbmc .sleep (500 )#line:883
	while OOOO0OOO00O0OOO00 :#line:885
		active =True #line:886
		log ("%s is %s"%(O000OOO0OOOOOO0O0 ,OOOO0OOO00O0OOO00 ),xbmc .LOGDEBUG )#line:887
		OOOO0OOO00O0OOO00 =getCond ('Window.IsActive(%s)'%O000OOO0OOOOOO0O0 )#line:888
		xbmc .sleep (250 )#line:889
	return active #line:890
def id_generator (size =6 ,chars =string .ascii_uppercase +string .digits ):#line:892
	return ''.join (random .choice (chars )for _OOO000OO0O0O0O0OO in range (size ))#line:893
def generateQR (OOOOOO00000O0OO00 ,OO000O00O00OOO0OO ):#line:895
    if not os .path .exists (QRCODES ):os .makedirs (QRCODES )#line:896
    O000O0OOO00O0O00O =os .path .join (QRCODES ,'%s.png'%OO000O00O00OOO0OO )#line:897
    O00OO0000OOOO0000 =pyqrcode .create (OOOOOO00000O0OO00 )#line:898
    O00OO0000OOOO0000 .png (O000O0OOO00O0O00O ,scale =10 )#line:899
    return O000O0OOO00O0O00O #line:900
def createQR ():#line:902
	O0O0OO00O000OOO00 =getKeyboard ('',"%s: Insert the URL for the QRCode."%ADDONTITLE )#line:903
	if O0O0OO00O000OOO00 =="":LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Create QR Code Cancelled![/COLOR]'%COLOR2 );return #line:904
	if not O0O0OO00O000OOO00 .startswith ('http://')and not O0O0OO00O000OOO00 .startswith ('https://'):LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:905
	if O0O0OO00O000OOO00 =='http://'or O0O0OO00O000OOO00 =='https://':LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:906
	O00OOOO0OO0O0O0O0 =workingURL (O0O0OO00O000OOO00 )#line:907
	if not O00OOOO0OO0O0O0O0 ==True :#line:908
		if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems the your enter isnt working, Would you like to create it anyways?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOOO0OO0O0O0O0 ),yeslabel ="[B][COLOR red]Yes Create[/COLOR][/B]",nolabel ="[B][COLOR green]No Cancel[/COLOR][/B]"):#line:909
			return #line:910
	O0O00OO0O0OOO0OO0 =getKeyboard ('',"%s: Insert the name for the QRCode."%ADDONTITLE )#line:911
	O0O00OO0O0OOO0OO0 ="QrImage_%s"%id_generator (6 )if O0O00OO0O0OOO0OO0 ==""else O0O00OO0O0OOO0OO0 #line:912
	OO000O00O000OOOO0 =generateQR (O0O0OO00O000OOO00 ,O0O00OO0O0OOO0OO0 )#line:913
	DIALOG .ok (ADDONTITLE ,"[COLOR %s]The QRCode image has been created and is located in the addondata directory:[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O00O000OOOO0 .replace (HOME ,'')))#line:914
def cleanupBackup ():#line:916
	OOOO0OO000OO00OO0 =xbmc .translatePath (MYBUILDS )#line:917
	OO0OO0OO0000OO0O0 =glob .glob (os .path .join (OOOO0OO000OO00OO0 ,"*"))#line:918
	O0OO0O0000000O00O =[];OOOO00OOOOOO0O000 =[]#line:919
	if len (OO0OO0OO0000OO0O0 )==0 :#line:920
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Backup Location: Empty[/COLOR]"%(COLOR2 ))#line:921
		return #line:922
	for O00O0OOO0O0OOO0O0 in sorted (OO0OO0OO0000OO0O0 ,key =os .path .getmtime ):#line:923
		OOOO00OOOOOO0O000 .append (O00O0OOO0O0OOO0O0 )#line:924
		OOO000O0O0O00OO0O =O00O0OOO0O0OOO0O0 .replace (OOOO0OO000OO00OO0 ,'')#line:925
		if os .path .isdir (O00O0OOO0O0OOO0O0 ):#line:926
			O0OO0O0000000O00O .append ('/%s/'%OOO000O0O0O00OO0O )#line:927
		elif os .path .isfile (O00O0OOO0O0OOO0O0 ):#line:928
			O0OO0O0000000O00O .append (OOO000O0O0O00OO0O )#line:929
	O0OO0O0000000O00O =['--- Remove All Items ---']+O0OO0O0000000O00O #line:930
	O0O0O0O0000O0OOO0 =DIALOG .select ("%s: Select the items to remove from 'MyBuilds'."%ADDONTITLE ,O0OO0O0000000O00O )#line:931
	if O0O0O0O0000O0OOO0 ==-1 :#line:933
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:934
	elif O0O0O0O0000O0OOO0 ==0 :#line:935
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to clean up all items in your 'My_Builds' folder?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,MYBUILDS ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:936
			OO0000OO00OOO0O00 ,OOOO0OO0O0OOOOOOO =cleanHouse (xbmc .translatePath (MYBUILDS ))#line:937
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Removed Files: [COLOR %s]%s[/COLOR] / Folders:[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,OO0000OO00OOO0O00 ,COLOR1 ,OOOO0OO0O0OOOOOOO ))#line:938
		else :#line:939
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:940
	else :#line:941
		OOO00OO0OO0000OOO =OOOO00OOOOOO0O000 [O0O0O0O0000O0OOO0 -1 ];O00000OO000OO00O0 =False #line:942
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove [COLOR %s]%s[/COLOR] from 'My_Builds' folder?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OO0O0000000O00O [O0O0O0O0000O0OOO0 ]),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00OO0OO0000OOO ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:943
			if os .path .isfile (OOO00OO0OO0000OOO ):#line:944
				try :#line:945
					os .remove (OOO00OO0OO0000OOO )#line:946
					O00000OO000OO00O0 =True #line:947
				except :#line:948
					log ("Unable to remove: %s"%OOO00OO0OO0000OOO )#line:949
			else :#line:950
				cleanHouse (OOO00OO0OO0000OOO )#line:951
				try :#line:952
					shutil .rmtree (OOO00OO0OO0000OOO )#line:953
					O00000OO000OO00O0 =True #line:954
				except Exception as OOOO00O0O000O000O :#line:955
					log ("Error removing %s"%OOO00OO0OO0000OOO ,xbmc .LOGNOTICE )#line:956
			if O00000OO000OO00O0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed![/COLOR]"%(COLOR2 ,O0OO0O0000000O00O [O0O0O0O0000O0OOO0 ]))#line:957
			else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Removing %s![/COLOR]"%(COLOR2 ,O0OO0O0000000O00O [O0O0O0O0000O0OOO0 ]))#line:958
		else :#line:959
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:960
def getCond (OO000OO0O0O00O0OO ):#line:962
	return xbmc .getCondVisibility (OO000OO0O0O00O0OO )#line:963
def ebi (OO0OOO00OOO0OOO00 ):#line:965
	xbmc .executebuiltin (OO0OOO00OOO0OOO00 )#line:966
def refresh ():#line:968
	ebi ('Container.Refresh()')#line:969
def splitNotify (O0O0O0O0OOO0OO0O0 ):#line:971
	O0OO000O0O0000O00 =openURL (O0O0O0O0OOO0OO0O0 ).replace ('\r','').replace ('\t','').replace ('\n','[CR]')#line:972
	if O0OO000O0O0000O00 .find ('|||')==-1 :return False ,False #line:973
	O0OOOO0OO00OO000O ,OO000O0O0000OO0O0 =O0OO000O0O0000O00 .split ('|||')#line:974
	if OO000O0O0000OO0O0 .startswith ('[CR]'):OO000O0O0000OO0O0 =OO000O0O0000OO0O0 [4 :]#line:975
	return O0OOOO0OO00OO000O .replace ('[CR]',''),OO000O0O0000OO0O0 #line:976
def forceUpdate (silent =False ):#line:978
	ebi ('UpdateAddonRepos()')#line:979
	ebi ('UpdateLocalAddons()')#line:980
	if silent ==False :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מעדכן הרחבות[/COLOR]'%COLOR2 )#line:982
def convertSpecial (OO0O000OO00OOOO0O ,over =False ):#line:984
	OOO00O0O000OO0O00 =fileCount (OO0O000OO00OOOO0O );O000O0000O00OO00O =0 #line:985
	DP .create (ADDONTITLE ,"[COLOR %s]Changing Physical Paths To Special"%COLOR2 ,"","Please Wait[/COLOR]")#line:986
	for O0O0O00O0O0000O0O ,O0OO0OO0O0O00OOO0 ,O0000OO00000000O0 in os .walk (OO0O000OO00OOOO0O ):#line:987
		for OO00OO0O0OOO00OO0 in O0000OO00000000O0 :#line:988
			O000O0000O00OO00O +=1 #line:989
			O0OOO0O000000O0O0 =int (percentage (O000O0000O00OO00O ,OOO00O0O000OO0O00 ))#line:990
			if OO00OO0O0OOO00OO0 .endswith (".xml")or OO00OO0O0OOO00OO0 .endswith (".hash")or OO00OO0O0OOO00OO0 .endswith ("properies"):#line:991
				DP .update (O0OOO0O000000O0O0 ,"[COLOR %s]Scanning: [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,O0O0O00O0O0000O0O .replace (HOME ,'')),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OO0O0OOO00OO0 ),"Please Wait[/COLOR]")#line:992
				O0OOOO0O0OOO0O0O0 =open (os .path .join (O0O0O00O0O0000O0O ,OO00OO0O0OOO00OO0 )).read ()#line:993
				OO0OO0O0OO0000O0O =urllib .quote (HOME )#line:994
				OO000O0000OO00O0O =urllib .quote (HOME ).replace ('%3A','%3a').replace ('%5C','%5c')#line:995
				OO00OOOO0000O0O0O =O0OOOO0O0OOO0O0O0 .replace (HOME ,'special://home/').replace (OO0OO0O0OO0000O0O ,'special://home/').replace (OO000O0000OO00O0O ,'special://home/')#line:996
				O0OO0OO0OOOOOOO0O =open ((os .path .join (O0O0O00O0O0000O0O ,OO00OO0O0OOO00OO0 )),mode ='w')#line:997
				O0OO0OO0OOOOOOO0O .write (str (OO00OOOO0000O0O0O ))#line:998
				O0OO0OO0OOOOOOO0O .close ()#line:999
	DP .close ()#line:1000
	log ("[Convert Paths to Special] Complete",xbmc .LOGNOTICE )#line:1001
	if over ==False :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Convert Paths to Special: Complete![/COLOR]"%COLOR2 )#line:1002
def clearCrash ():#line:1004
	OO00OO00OOOO000O0 =[]#line:1005
	for O0O00O0OOOO0O0O00 in glob .glob (os .path .join (LOG ,'*crashlog*.*')):#line:1006
		OO00OO00OOOO000O0 .append (O0O00O0OOOO0O0O00 )#line:1007
	if len (OO00OO00OOOO000O0 )>0 :#line:1008
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the Crash logs?'%COLOR2 ,'[COLOR %s]%s[/COLOR] Files Found[/COLOR]'%(COLOR1 ,len (OO00OO00OOOO000O0 )),yeslabel ="[B][COLOR green]Remove Logs[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Logs[/COLOR][/B]"):#line:1009
			for OOO00OOOOO000000O in OO00OO00OOOO000O0 :#line:1010
				os .remove (OOO00OOOOO000000O )#line:1011
			LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]%s Crash Logs Removed[/COLOR]'%(COLOR2 ,len (OO00OO00OOOO000O0 )))#line:1012
		else :LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Crash Logs Cancelled[/COLOR]'%COLOR2 )#line:1013
	else :LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]No Crash Logs Found[/COLOR]'%COLOR2 )#line:1014
def hidePassword ():#line:1016
	if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]hide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Hide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1017
		O0OOOOOO0OO0OO0OO =0 #line:1018
		for O0O0O0O0O0O000O00 in glob .glob (os .path .join (ADDONS ,'*/')):#line:1019
			OOOO0000O0O00000O =os .path .join (O0O0O0O0O0O000O00 ,'resources','settings.xml')#line:1020
			if os .path .exists (OOOO0000O0O00000O ):#line:1021
				O0OO00OO0OO00OO00 =open (OOOO0000O0O00000O ).read ()#line:1022
				OO0OO0OOOOO000OO0 =parseDOM (O0OO00OO0OO00OO00 ,'addon',ret ='id')#line:1023
				for OO00OOO0000O00O00 in OO0OO0OOOOO000OO0 :#line:1024
					if 'pass'in OO00OOO0000O00O00 :#line:1025
						if not 'option="hidden"'in OO00OOO0000O00O00 :#line:1026
							try :#line:1027
								O0OOOO0000O000O00 =OO00OOO0000O00O00 .replace ('/','option="hidden" /')#line:1028
								O0OO00OO0OO00OO00 .replace (OO00OOO0000O00O00 ,O0OOOO0000O000O00 )#line:1029
								O0OOOOOO0OO0OO0OO +=1 #line:1030
								log ("[Hide Passwords] found in %s on %s"%(OOOO0000O0O00000O .replace (HOME ,''),OO00OOO0000O00O00 ),xbmc .LOGDEBUG )#line:1031
							except :#line:1032
								pass #line:1033
				O0OOO0O0O00O000O0 =open (OOOO0000O0O00000O ,mode ='w');O0OOO0O0O00O000O0 .write (O0OO00OO0OO00OO00 );O0OOO0O0O00O000O0 .close ()#line:1034
		LogNotify ("[COLOR %s]Hide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,O0OOOOOO0OO0OO0OO ))#line:1035
		log ("[Hide Passwords] %s items changed"%O0OOOOOO0OO0OO0OO ,xbmc .LOGNOTICE )#line:1036
	else :log ("[Hide Passwords] Cancelled",xbmc .LOGNOTICE )#line:1037
def unhidePassword ():#line:1039
	if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]unhide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Unhide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1040
		OOO0O00OOOOOOO00O =0 #line:1041
		for OO00OO0O000O000OO in glob .glob (os .path .join (ADDONS ,'*/')):#line:1042
			O00OOOOOOO00OO00O =os .path .join (OO00OO0O000O000OO ,'resources','settings.xml')#line:1043
			if os .path .exists (O00OOOOOOO00OO00O ):#line:1044
				O0O00O0OOO000OOO0 =open (O00OOOOOOO00OO00O ).read ()#line:1045
				O000O0O00OOOO0O00 =parseDOM (O0O00O0OOO000OOO0 ,'addon',ret ='id')#line:1046
				for OO00000O0O0O0OO00 in O000O0O00OOOO0O00 :#line:1047
					if 'pass'in OO00000O0O0O0OO00 :#line:1048
						if 'option="hidden"'in OO00000O0O0O0OO00 :#line:1049
							try :#line:1050
								OOO0O000OOO0OOO0O =OO00000O0O0O0OO00 .replace ('option="hidden"','')#line:1051
								O0O00O0OOO000OOO0 .replace (OO00000O0O0O0OO00 ,OOO0O000OOO0OOO0O )#line:1052
								OOO0O00OOOOOOO00O +=1 #line:1053
								log ("[Unhide Passwords] found in %s on %s"%(O00OOOOOOO00OO00O .replace (HOME ,''),OO00000O0O0O0OO00 ),xbmc .LOGDEBUG )#line:1054
							except :#line:1055
								pass #line:1056
				OO00O00O00O0O0O0O =open (O00OOOOOOO00OO00O ,mode ='w');OO00O00O00O0O0O0O .write (O0O00O0OOO000OOO0 );OO00O00O00O0O0O0O .close ()#line:1057
		LogNotify ("[COLOR %s]Unhide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,OOO0O00OOOOOOO00O ))#line:1058
		log ("[Unhide Passwords] %s items changed"%OOO0O00OOOOOOO00O ,xbmc .LOGNOTICE )#line:1059
	else :log ("[Unhide Passwords] Cancelled",xbmc .LOGNOTICE )#line:1060
def chunk_report (OO00OOOOO0O0O0000 ,O00OO0O00OOOO000O ,OO00O0OOOO000O0O0 ):#line:1061
   O00O00000O0O000OO =float (OO00OOOOO0O0O0000 )/OO00O0OOOO000O0O0 #line:1062
   O00O00000O0O000OO =round (O00O00000O0O000OO *100 ,2 )#line:1063
   if OO00OOOOO0O0O0000 >=OO00O0OOOO000O0O0 :#line:1065
      sys .stdout .write ('\n')#line:1066
def chunk_read (O0OO0O0O000OOO000 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:1068
   import time #line:1069
   O0OOO0O000OO000OO =100 #line:1070
   O000O0OOO0OO000O0 =0 #line:1072
   O000OO00O00O000O0 =time .time ()#line:1073
   OOOO0000O0OO00OOO =0 #line:1074
   logging .warning ('Downloading')#line:1076
   with open (destination ,"wb")as OO0O00O00OOOO0OO0 :#line:1077
    while 1 :#line:1078
      OOO0OOO0O000O0000 =time .time ()-O000OO00O00O000O0 #line:1079
      OO0OOO0O00OOO000O =int (OOOO0000O0OO00OOO *chunk_size )#line:1080
      O00OO00O0OOOOOO00 =O0OO0O0O000OOO000 .read (chunk_size )#line:1081
      OO0O00O00OOOO0OO0 .write (O00OO00O0OOOOOO00 )#line:1082
      OO0O00O00OOOO0OO0 .flush ()#line:1083
      O000O0OOO0OO000O0 +=len (O00OO00O0OOOOOO00 )#line:1084
      O0OOO0000000O0000 =float (O000O0OOO0OO000O0 )/O0OOO0O000OO000OO #line:1085
      O0OOO0000000O0000 =round (O0OOO0000000O0000 *100 ,2 )#line:1086
      if int (OOO0OOO0O000O0000 )>0 :#line:1087
        OO0O00O000OOO0OO0 =int (OO0OOO0O00OOO000O /(1024 *OOO0OOO0O000O0000 ))#line:1088
      else :#line:1089
         OO0O00O000OOO0OO0 =0 #line:1090
      if OO0O00O000OOO0OO0 >1024 and not O0OOO0000000O0000 ==100 :#line:1091
          OOOOO00000000OOO0 =int (((O0OOO0O000OO000OO -OO0OOO0O00OOO000O )/1024 )/(OO0O00O000OOO0OO0 ))#line:1092
      else :#line:1093
          OOOOO00000000OOO0 =0 #line:1094
      if OOOOO00000000OOO0 <0 :#line:1095
        OOOOO00000000OOO0 =0 #line:1096
      dp .update (int (O0OOO0000000O0000 ),"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OOO0000000O0000 ,OO0OOO0O00OOO000O /(1024 *1024 ),O0OOO0O000OO000OO /(1000 *1000 ),OO0O00O000OOO0OO0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOOO00000000OOO0 ,60 ))#line:1097
      if dp .iscanceled ():#line:1098
         dp .close ()#line:1099
         break #line:1100
      if not O00OO00O0OOOOOO00 :#line:1101
         break #line:1102
      if report_hook :#line:1104
         report_hook (O000O0OOO0OO000O0 ,chunk_size ,O0OOO0O000OO000OO )#line:1105
      OOOO0000O0OO00OOO +=1 #line:1106
   logging .warning ('END Downloading')#line:1107
   return O000O0OOO0OO000O0 #line:1108
def googledrive_download (OOOO000O0000OOOOO ,O0OOO0O0O00O0O000 ,O00OO0OO00OOO00OO ,O00OOOO0OOO000000 ):#line:1110
    O0000OOOOOO0O0000 =[]#line:1114
    O000O0000000O000O =OOOO000O0000OOOOO .split ('=')#line:1115
    OOOO000O0000OOOOO =O000O0000000O000O [len (O000O0000000O000O )-1 ]#line:1116
    def OO0OO0O0OOOO00O00 (O0O00O0O000O0O00O ):#line:1118
        for O0O0OO0OOO00000OO in O0O00O0O000O0O00O :#line:1120
            logging .warning ('cookie.name')#line:1121
            logging .warning (O0O0OO0OOO00000OO .name )#line:1122
            OOO0O0000OOO0OOOO =O0O0OO0OOO00000OO .value #line:1123
            if 'download_warning'in O0O0OO0OOO00000OO .name :#line:1124
                logging .warning (O0O0OO0OOO00000OO .value )#line:1125
                logging .warning ('cookie.value')#line:1126
                return O0O0OO0OOO00000OO .value #line:1127
            return OOO0O0000OOO0OOOO #line:1128
        return None #line:1130
    def O00O00O0OO0O0OO00 (OOO0OOOO0OOOO0OOO ,O00OOOO00O000O0O0 ):#line:1132
        O0O0OO00OOOO0O000 =32768 #line:1134
        O00OO0OOO0OO000O0 =time .time ()#line:1135
        with open (O00OOOO00O000O0O0 ,"wb")as O00O00OO0OOOOO0OO :#line:1137
            OO0O00O0OO00OO0O0 =1 #line:1138
            OO0O00O000OO0OO0O =32768 #line:1139
            try :#line:1140
                OO0OOO00OO0O0O0OO =int (OOO0OOOO0OOOO0OOO .headers .get ('content-length'))#line:1141
                print ('file total size :',OO0OOO00OO0O0O0OO )#line:1142
            except TypeError :#line:1143
                print ('using dummy length !!!')#line:1144
                OO0OOO00OO0O0O0OO =int (O00OOOO0OOO000000 )*1000000 #line:1145
            for O0O000OOO0OOO000O in OOO0OOOO0OOOO0OOO .iter_content (O0O0OO00OOOO0O000 ):#line:1146
                if O0O000OOO0OOO000O :#line:1147
                    O00O00OO0OOOOO0OO .write (O0O000OOO0OOO000O )#line:1148
                    O00O00OO0OOOOO0OO .flush ()#line:1149
                    OO000O00000O000O0 =time .time ()-O00OO0OOO0OO000O0 #line:1150
                    OOOO00O0OO0OOO0OO =int (OO0O00O0OO00OO0O0 *OO0O00O000OO0OO0O )#line:1151
                    if OO000O00000O000O0 ==0 :#line:1152
                        OO000O00000O000O0 =0.1 #line:1153
                    O00O000OOO0O000O0 =int (OOOO00O0OO0OOO0OO /(1024 *OO000O00000O000O0 ))#line:1154
                    OO0000O0O0OO0OO00 =int (OO0O00O0OO00OO0O0 *OO0O00O000OO0OO0O *100 /OO0OOO00OO0O0O0OO )#line:1155
                    if O00O000OOO0O000O0 >1024 and not OO0000O0O0OO0OO00 ==100 :#line:1156
                      O00000000OO00O0OO =int (((OO0OOO00OO0O0O0OO -OOOO00O0OO0OOO0OO )/1024 )/(O00O000OOO0O000O0 ))#line:1157
                    else :#line:1158
                      O00000000OO00O0OO =0 #line:1159
                    O00OO0OO00OOO00OO .update (int (OO0000O0O0OO0OO00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0000O0O0OO0OO00 ,OOOO00O0OO0OOO0OO /(1024 *1024 ),OO0OOO00OO0O0O0OO /(1000 *1000 ),O00O000OOO0O000O0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O00000000OO00O0OO ,60 ))#line:1161
                    OO0O00O0OO00OO0O0 +=1 #line:1162
                    if O00OO0OO00OOO00OO .iscanceled ():#line:1163
                     O00OO0OO00OOO00OO .close ()#line:1164
                     break #line:1165
    O00OO00O000OOOO0O ="https://docs.google.com/uc?export=download"#line:1166
    import urllib2 #line:1171
    import cookielib #line:1172
    from cookielib import CookieJar #line:1174
    O00O0OOOO000OOO00 =CookieJar ()#line:1176
    O0OO0O0000O0OO000 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O00O0OOOO000OOO00 ))#line:1177
    O00OOO00O000000O0 ={'id':OOOO000O0000OOOOO }#line:1179
    OOOO00O0O0OOO0OOO =urllib .urlencode (O00OOO00O000000O0 )#line:1180
    logging .warning (O00OO00O000OOOO0O +'&'+OOOO00O0O0OOO0OOO )#line:1181
    OO00O0O00O00O00O0 =O0OO0O0000O0OO000 .open (O00OO00O000OOOO0O +'&'+OOOO00O0O0OOO0OOO )#line:1182
    O00OOO0000O0000OO =OO00O0O00O00O00O0 .read ()#line:1183
    for O0OOO0O0O0000OOOO in O00O0OOOO000OOO00 :#line:1185
         logging .warning (O0OOO0O0O0000OOOO )#line:1186
    OO0O00O00OO0OOO0O =OO0OO0O0OOOO00O00 (O00O0OOOO000OOO00 )#line:1187
    logging .warning (OO0O00O00OO0OOO0O )#line:1188
    if OO0O00O00OO0OOO0O :#line:1189
        OOOOOO000OOO00OO0 ={'id':OOOO000O0000OOOOO ,'confirm':OO0O00O00OO0OOO0O }#line:1190
        O0OO00OO0O0O0OO0O ={'Access-Control-Allow-Headers':'Content-Length'}#line:1191
        OOOO00O0O0OOO0OOO =urllib .urlencode (OOOOOO000OOO00OO0 )#line:1192
        OO00O0O00O00O00O0 =O0OO0O0000O0OO000 .open (O00OO00O000OOOO0O +'&'+OOOO00O0O0OOO0OOO )#line:1193
        chunk_read (OO00O0O00O00O00O0 ,report_hook =chunk_report ,dp =O00OO0OO00OOO00OO ,destination =O0OOO0O0O00O0O000 ,filesize =O00OOOO0OOO000000 )#line:1194
    return (O0000OOOOOO0O0000 )#line:1198
def wizardUpdate (startup =None ):#line:1199
	if workingURL (WIZARDFILE ):#line:1200
		OO0000O0O0OOO0OO0 =checkWizard ('version')#line:1201
		OO0OO0O000OOO0000 =checkWizard ('zip')#line:1202
		if OO0000O0O0OOO0OO0 >VERSION :#line:1203
			OOOOO000O0OOOO00O =1 #line:1204
			if OOOOO000O0OOOO00O :#line:1205
				log ("[Auto Update Wizard] Installing wizard v%s"%OO0000O0O0OOO0OO0 ,xbmc .LOGNOTICE )#line:1206
				O0OO0O0OO0OOOO0O0 =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,OO0000O0O0OOO0OO0 ))#line:1208
				try :os .remove (O0OO0O0OO0OOOO0O0 )#line:1209
				except :pass #line:1210
				if 'google'in OO0OO0O000OOO0000 :#line:1211
					O0OOO0O0OOOO0000O =googledrive_download (OO0OO0O000OOO0000 ,O0OO0O0OO0OOOO0O0 ,DP2 ,checkWizard ('filesize'))#line:1212
				downloaderwiz .download4 (OO0OO0O000OOO0000 ,O0OO0O0OO0OOOO0O0 ,DP2 )#line:1213
				xbmc .sleep (2000 )#line:1214
				DP2 .create ('מתקין')#line:1215
				DP2 .update (100 ,message ='אנא המתן ...')#line:1216
				extract .all (O0OO0O0OO0OOOO0O0 ,ADDONS )#line:1217
				DP2 .close ()#line:1218
				LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:1219
				log ("[Auto Update Wizard] Wizard updated to v%s"%OO0000O0O0OOO0OO0 ,xbmc .LOGNOTICE )#line:1220
				return #line:1222
			else :log ("[Auto Update Wizard] Install New Wizard Ignored: %s"%OO0000O0O0OOO0OO0 ,xbmc .LOGNOTICE )#line:1223
		else :#line:1224
			if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:1225
			log ("[Auto Update Wizard] No New Version v%s"%OO0000O0O0OOO0OO0 ,xbmc .LOGNOTICE )#line:1226
	else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,xbmc .LOGNOTICE )#line:1227
def wizardUpdateDP (startup =None ):#line:1229
	if workingURL (WIZARDFILE ):#line:1230
		OOO0OO00O0OO0O0O0 =checkWizard ('version')#line:1231
		OOOO00O00O0O0000O =checkWizard ('zip')#line:1232
		if OOO0OO00O0OO0O0O0 >VERSION :#line:1233
			OOO0OO0OO000OOOO0 =1 #line:1234
			if OOO0OO0OO000OOOO0 :#line:1235
				log ("[Auto Update Wizard] Installing wizard v%s"%OOO0OO00O0OO0O0O0 ,xbmc .LOGNOTICE )#line:1236
				DP .create (ADDONTITLE ,'[COLOR %s]עדכון אוטומטי לויזארד:'%COLOR2 ,'','אנא המתן[/COLOR]')#line:1237
				O000O0OOO00OO00OO =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,OOO0OO00O0OO0O0O0 ))#line:1238
				try :os .remove (O000O0OOO00OO00OO )#line:1239
				except :pass #line:1240
				if 'google'in OOOO00O00O0O0000O :#line:1241
					OO00O00OO0OO000O0 =googledrive_download (OOOO00O00O0O0000O ,O000O0OOO00OO00OO ,DP ,checkWizard ('filesize'))#line:1242
				downloader .download (OOOO00O00O0O0000O ,O000O0OOO00OO00OO ,DP )#line:1243
				xbmc .sleep (2000 )#line:1244
				DP .update (0 ,"","Installing %s update"%ADDONTITLE )#line:1245
				O0OOOOO000O0OO00O ,O00000OO0OOOO00OO ,O0OO0O00OO0OO0000 =extract .all (O000O0OOO00OO00OO ,ADDONS ,DP ,True )#line:1246
				DP .close ()#line:1247
				LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:1248
				log ("[Auto Update Wizard] Wizard updated to v%s"%OOO0OO00O0OO0O0O0 ,xbmc .LOGNOTICE )#line:1249
				return #line:1251
			else :log ("[Auto Update Wizard] Install New Wizard Ignored: %s"%OOO0OO00O0OO0O0O0 ,xbmc .LOGNOTICE )#line:1252
		else :#line:1253
			if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:1254
			log ("[Auto Update Wizard] No New Version v%s"%OOO0OO00O0OO0O0O0 ,xbmc .LOGNOTICE )#line:1255
	else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,xbmc .LOGNOTICE )#line:1256
def convertText ():#line:1258
	O0O0000000O0OOO0O =os .path .join (ADDONDATA ,'TextFiles')#line:1259
	if not os .path .exists (O0O0000000O0OOO0O ):os .makedirs (O0O0000000O0OOO0O )#line:1260
	DP .create (ADDONTITLE ,'[COLOR %s][B]Converting Text:[/B][/COLOR]'%(COLOR2 ),'','Please Wait')#line:1262
	if not SPEEDFILE =='http://':#line:1264
		OOO0O0O00O00OO000 =os .path .join (O0O0000000O0OOO0O ,'builds.txt')#line:1265
		O0OO00O00O0OOOO0O ='';OO0O00OO00OOO0O00 =0 #line:1266
		O000OOO00OOO0OOO0 =openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1267
		DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Builds.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1268
		if WIZARDFILE ==SPEEDFILE :#line:1269
			try :#line:1270
				O00OO0OOO0O0000OO ,OOO0O00OOOO0O00O0 ,O0000OOOOO00OO00O =checkWizard ('all')#line:1271
				O0OO00O00O0OOOO0O ='id="%s"\n'%O00OO0OOO0O0000OO #line:1272
				O0OO00O00O0OOOO0O +='version="%s"\n'%OOO0O00OOOO0O00O0 #line:1273
				O0OO00O00O0OOOO0O +='zip="%s"\n'%O0000OOOOO00OO00O #line:1274
			except :#line:1275
				pass #line:1276
		OOO000OO0O0OO00OO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O000OOO00OOO0OOO0 )#line:1277
		O0000OO0OOO0000OO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OOO00OOO0OOO0 )#line:1278
		if len (O0000OO0OOO0000OO )==0 :#line:1279
			for OO00OOO0000000O00 ,OOO0O00OOOO0O00O0 ,O0000OOOOO00OO00O ,OO0OO00OOO0000O00 ,OO0OOO00O0O0OOOO0 ,OO000O00OOOOOOOOO ,OOOOOO000OO000OOO ,OO00OO0000O000OO0 in OOO000OO0O0OO00OO :#line:1280
				OO0O00OO00OOO0O00 +=1 #line:1281
				DP .update (int (percentage (OO0O00OO00OOO0O00 ,len (O0000OO0OOO0000OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO0000000O00 ))#line:1282
				if not O0OO00O00O0OOOO0O =='':O0OO00O00O0OOOO0O +='\n'#line:1283
				O0OO00O00O0OOOO0O +='name="%s"\n'%OO00OOO0000000O00 #line:1284
				O0OO00O00O0OOOO0O +='version="%s"\n'%OOO0O00OOOO0O00O0 #line:1285
				O0OO00O00O0OOOO0O +='url="%s"\n'%O0000OOOOO00OO00O #line:1286
				O0OO00O00O0OOOO0O +='gui="%s"\n'%OO0OO00OOO0000O00 #line:1287
				O0OO00O00O0OOOO0O +='kodi="%s"\n'%OO0OOO00O0O0OOOO0 #line:1288
				O0OO00O00O0OOOO0O +='theme="%s"\n'%OO000O00OOOOOOOOO #line:1289
				O0OO00O00O0OOOO0O +='icon="%s"\n'%OOOOOO000OO000OOO #line:1290
				O0OO00O00O0OOOO0O +='fanart="%s"\n'%OO00OO0000O000OO0 #line:1291
				O0OO00O00O0OOOO0O +='preview="http://"\n'#line:1292
				O0OO00O00O0OOOO0O +='adult="no"\n'#line:1293
				O0OO00O00O0OOOO0O +='description="Download %s from %s"\n'%(OO00OOO0000000O00 ,ADDONTITLE )#line:1294
				if not OO000O00OOOOOOOOO =='http://':#line:1295
					O0OOOOOOO00O0O0OO =os .path .join (O0O0000000O0OOO0O ,'%s_theme.txt'%OO00OOO0000000O00 )#line:1296
					OOOO0OO0O0OO0OOOO ='';O0O0OO000OOO0O0OO =0 #line:1297
					O000OOO00OOO0OOO0 =openURL (OO000O00OOOOOOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1298
					DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOO0000000O00 ),'','Please Wait')#line:1299
					OOO0O0OO00OO0OOOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OOO00OOO0OOO0 )#line:1300
					for OO00OOO0000000O00 ,O0000OOOOO00OO00O ,OOOOOO000OO000OOO ,OO00OO0000O000OO0 ,O00OO0O00O0OO0O00 in OOO0O0OO00OO0OOOO :#line:1301
						O0O0OO000OOO0O0OO +=1 #line:1302
						DP .update (int (percentage (O0O0OO000OOO0O0OO ,len (O0000OO0OOO0000OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO0000000O00 ))#line:1303
						if not OOOO0OO0O0OO0OOOO =='':OOOO0OO0O0OO0OOOO +='\n'#line:1304
						OOOO0OO0O0OO0OOOO +='name="%s"\n'%OO00OOO0000000O00 #line:1305
						OOOO0OO0O0OO0OOOO +='url="%s"\n'%O0000OOOOO00OO00O #line:1306
						OOOO0OO0O0OO0OOOO +='icon="%s"\n'%OOOOOO000OO000OOO #line:1307
						OOOO0OO0O0OO0OOOO +='fanart="%s"\n'%OO00OO0000O000OO0 #line:1308
						OOOO0OO0O0OO0OOOO +='adult="no"\n'#line:1309
						OOOO0OO0O0OO0OOOO +='description="%s"\n'%O00OO0O00O0OO0O00 #line:1310
					OOO000O0O0O000O00 =open (O0OOOOOOO00O0O0OO ,'w');OOO000O0O0O000O00 .write (OOOO0OO0O0OO0OOOO );OOO000O0O0O000O00 .close ()#line:1311
		else :#line:1312
			for OO00OOO0000000O00 ,OOO0O00OOOO0O00O0 ,O0000OOOOO00OO00O ,OO0OO00OOO0000O00 ,OO0OOO00O0O0OOOO0 ,OO000O00OOOOOOOOO ,OOOOOO000OO000OOO ,OO00OO0000O000OO0 ,OO0OO0O0O00OOO0OO ,O00OO0O00O0OO0O00 in O0000OO0OOO0000OO :#line:1313
				OO0O00OO00OOO0O00 +=1 #line:1314
				DP .update (int (percentage (OO0O00OO00OOO0O00 ,len (O0000OO0OOO0000OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO0000000O00 ))#line:1315
				if not O0OO00O00O0OOOO0O =='':O0OO00O00O0OOOO0O +='\n'#line:1316
				O0OO00O00O0OOOO0O +='name="%s"\n'%OO00OOO0000000O00 #line:1317
				O0OO00O00O0OOOO0O +='version="%s"\n'%OOO0O00OOOO0O00O0 #line:1318
				O0OO00O00O0OOOO0O +='url="%s"\n'%O0000OOOOO00OO00O #line:1319
				O0OO00O00O0OOOO0O +='gui="%s"\n'%OO0OO00OOO0000O00 #line:1320
				O0OO00O00O0OOOO0O +='kodi="%s"\n'%OO0OOO00O0O0OOOO0 #line:1321
				O0OO00O00O0OOOO0O +='theme="%s"\n'%OO000O00OOOOOOOOO #line:1322
				O0OO00O00O0OOOO0O +='icon="%s"\n'%OOOOOO000OO000OOO #line:1323
				O0OO00O00O0OOOO0O +='fanart="%s"\n'%OO00OO0000O000OO0 #line:1324
				O0OO00O00O0OOOO0O +='preview="http://"\n'#line:1325
				O0OO00O00O0OOOO0O +='adult="%s"\n'%OO0OO0O0O00OOO0OO #line:1326
				O0OO00O00O0OOOO0O +='description="%s"\n'%O00OO0O00O0OO0O00 #line:1327
				if not OO000O00OOOOOOOOO =='http://':#line:1328
					O0OOOOOOO00O0O0OO =os .path .join (O0O0000000O0OOO0O ,'%s_theme.txt'%OO00OOO0000000O00 )#line:1329
					OOOO0OO0O0OO0OOOO ='';O0O0OO000OOO0O0OO =0 #line:1330
					O000OOO00OOO0OOO0 =openURL (OO000O00OOOOOOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1331
					DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOO0000000O00 ),'','Please Wait')#line:1332
					OOO0O0OO00OO0OOOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OOO00OOO0OOO0 )#line:1333
					for OO00OOO0000000O00 ,O0000OOOOO00OO00O ,OOOOOO000OO000OOO ,OO00OO0000O000OO0 ,O00OO0O00O0OO0O00 in OOO0O0OO00OO0OOOO :#line:1334
						O0O0OO000OOO0O0OO +=1 #line:1335
						DP .update (int (percentage (O0O0OO000OOO0O0OO ,len (O0000OO0OOO0000OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO0000000O00 ))#line:1336
						if not OOOO0OO0O0OO0OOOO =='':OOOO0OO0O0OO0OOOO +='\n'#line:1337
						OOOO0OO0O0OO0OOOO +='name="%s"\n'%OO00OOO0000000O00 #line:1338
						OOOO0OO0O0OO0OOOO +='url="%s"\n'%O0000OOOOO00OO00O #line:1339
						OOOO0OO0O0OO0OOOO +='icon="%s"\n'%OOOOOO000OO000OOO #line:1340
						OOOO0OO0O0OO0OOOO +='fanart="%s"\n'%OO00OO0000O000OO0 #line:1341
						OOOO0OO0O0OO0OOOO +='adult="no"\n'#line:1342
						OOOO0OO0O0OO0OOOO +='description="%s"\n'%O00OO0O00O0OO0O00 #line:1343
					OOO000O0O0O000O00 =open (O0OOOOOOO00O0O0OO ,'w');OOO000O0O0O000O00 .write (OOOO0OO0O0OO0OOOO );OOO000O0O0O000O00 .close ()#line:1344
		OOO000O0O0O000O00 =open (OOO0O0O00O00OO000 ,'w');OOO000O0O0O000O00 .write (O0OO00O00O0OOOO0O );OOO000O0O0O000O00 .close ()#line:1345
	if not APKFILE =='http://':#line:1347
		OOO0O0O00O00OO000 =os .path .join (O0O0000000O0OOO0O ,'apks.txt')#line:1348
		O0OO00O00O0OOOO0O ='';OO0O00OO00OOO0O00 =0 #line:1349
		O000OOO00OOO0OOO0 =openURL (APKFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1350
		DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Apks.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1351
		OOO000OO0O0OO00OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O000OOO00OOO0OOO0 )#line:1352
		O0000OO0OOO0000OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OOO00OOO0OOO0 )#line:1353
		if len (O0000OO0OOO0000OO )==0 :#line:1354
			for OO00OOO0000000O00 ,O0000OOOOO00OO00O ,OOOOOO000OO000OOO ,OO00OO0000O000OO0 in OOO000OO0O0OO00OO :#line:1355
				OO0O00OO00OOO0O00 +=1 #line:1356
				DP .update (int (percentage (OO0O00OO00OOO0O00 ,len (OOO000OO0O0OO00OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO0000000O00 ))#line:1357
				if not O0OO00O00O0OOOO0O =='':O0OO00O00O0OOOO0O +='\n'#line:1358
				O0OO00O00O0OOOO0O +='name="%s"\n'%OO00OOO0000000O00 #line:1359
				O0OO00O00O0OOOO0O +='section="no"'#line:1360
				O0OO00O00O0OOOO0O +='url="%s"\n'%O0000OOOOO00OO00O #line:1361
				O0OO00O00O0OOOO0O +='icon="%s"\n'%OOOOOO000OO000OOO #line:1362
				O0OO00O00O0OOOO0O +='fanart="%s"\n'%OO00OO0000O000OO0 #line:1363
				O0OO00O00O0OOOO0O +='adult="no"\n'#line:1364
				O0OO00O00O0OOOO0O +='description="Download %s from %s"\n'%(OO00OOO0000000O00 ,ADDONTITLE )#line:1365
		else :#line:1366
			for OO00OOO0000000O00 ,O0000OOOOO00OO00O ,OOOOOO000OO000OOO ,OO00OO0000O000OO0 ,OO0OO0O0O00OOO0OO ,O00OO0O00O0OO0O00 in O0000OO0OOO0000OO :#line:1367
				OO0O00OO00OOO0O00 +=1 #line:1368
				DP .update (int (percentage (OO0O00OO00OOO0O00 ,len (O0000OO0OOO0000OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO0000000O00 ))#line:1369
				if not O0OO00O00O0OOOO0O =='':O0OO00O00O0OOOO0O +='\n'#line:1370
				O0OO00O00O0OOOO0O +='name="%s"\n'%OO00OOO0000000O00 #line:1371
				O0OO00O00O0OOOO0O +='section="no"'#line:1372
				O0OO00O00O0OOOO0O +='url="%s"\n'%O0000OOOOO00OO00O #line:1373
				O0OO00O00O0OOOO0O +='icon="%s"\n'%OOOOOO000OO000OOO #line:1374
				O0OO00O00O0OOOO0O +='fanart="%s"\n'%OO00OO0000O000OO0 #line:1375
				O0OO00O00O0OOOO0O +='adult="%s"\n'%OO0OO0O0O00OOO0OO #line:1376
				O0OO00O00O0OOOO0O +='description="%s"\n'%O00OO0O00O0OO0O00 #line:1377
		OOO000O0O0O000O00 =open (OOO0O0O00O00OO000 ,'w');OOO000O0O0O000O00 .write (O0OO00O00O0OOOO0O );OOO000O0O0O000O00 .close ()#line:1378
	if not YOUTUBEFILE =='http://':#line:1380
		OOO0O0O00O00OO000 =os .path .join (O0O0000000O0OOO0O ,'youtube.txt')#line:1381
		O0OO00O00O0OOOO0O ='';OO0O00OO00OOO0O00 =0 #line:1382
		O000OOO00OOO0OOO0 =openURL (YOUTUBEFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1383
		DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]YouTube.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1384
		OOO000OO0O0OO00OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OOO00OOO0OOO0 )#line:1385
		for OO00OOO0000000O00 ,O0000OOOOO00OO00O ,OOOOOO000OO000OOO ,OO00OO0000O000OO0 ,O00OO0O00O0OO0O00 in OOO000OO0O0OO00OO :#line:1386
			OO0O00OO00OOO0O00 +=1 #line:1387
			DP .update (int (percentage (OO0O00OO00OOO0O00 ,len (OOO000OO0O0OO00OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO0000000O00 ))#line:1388
			if not O0OO00O00O0OOOO0O =='':O0OO00O00O0OOOO0O +='\n'#line:1389
			O0OO00O00O0OOOO0O +='name="%s"\n'%OO00OOO0000000O00 #line:1390
			O0OO00O00O0OOOO0O +='section="no"'#line:1391
			O0OO00O00O0OOOO0O +='url="%s"\n'%O0000OOOOO00OO00O #line:1392
			O0OO00O00O0OOOO0O +='icon="%s"\n'%OOOOOO000OO000OOO #line:1393
			O0OO00O00O0OOOO0O +='fanart="%s"\n'%OO00OO0000O000OO0 #line:1394
			O0OO00O00O0OOOO0O +='description="%s"\n'%O00OO0O00O0OO0O00 #line:1395
		OOO000O0O0O000O00 =open (OOO0O0O00O00OO000 ,'w');OOO000O0O0O000O00 .write (O0OO00O00O0OOOO0O );OOO000O0O0O000O00 .close ()#line:1396
	if not ADVANCEDFILE =='http://':#line:1398
		OOO0O0O00O00OO000 =os .path .join (O0O0000000O0OOO0O ,'advancedsettings.txt')#line:1399
		O0OO00O00O0OOOO0O ='';OO0O00OO00OOO0O00 =0 #line:1400
		O000OOO00OOO0OOO0 =openURL (ADVANCEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1401
		DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]AdvancedSettings.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1402
		OOO000OO0O0OO00OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OOO00OOO0OOO0 )#line:1403
		for OO00OOO0000000O00 ,O0000OOOOO00OO00O ,OOOOOO000OO000OOO ,OO00OO0000O000OO0 ,O00OO0O00O0OO0O00 in OOO000OO0O0OO00OO :#line:1404
			OO0O00OO00OOO0O00 +=1 #line:1405
			DP .update (int (percentage (OO0O00OO00OOO0O00 ,len (OOO000OO0O0OO00OO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOO0000000O00 ))#line:1406
			if not O0OO00O00O0OOOO0O =='':O0OO00O00O0OOOO0O +='\n'#line:1407
			O0OO00O00O0OOOO0O +='name="%s"\n'%OO00OOO0000000O00 #line:1408
			O0OO00O00O0OOOO0O +='section="no"'#line:1409
			O0OO00O00O0OOOO0O +='url="%s"\n'%O0000OOOOO00OO00O #line:1410
			O0OO00O00O0OOOO0O +='icon="%s"\n'%OOOOOO000OO000OOO #line:1411
			O0OO00O00O0OOOO0O +='fanart="%s"\n'%OO00OO0000O000OO0 #line:1412
			O0OO00O00O0OOOO0O +='description="%s"\n'%O00OO0O00O0OO0O00 #line:1413
		OOO000O0O0O000O00 =open (OOO0O0O00O00OO000 ,'w');OOO000O0O0O000O00 .write (O0OO00O00O0OOOO0O );OOO000O0O0O000O00 .close ()#line:1414
	DP .close ()#line:1416
	DIALOG .ok (ADDONTITLE ,'[COLOR %s]Your text files have been converted to 0.1.7 and are location in the [COLOR %s]/addon_data/%s/[/COLOR] folder[/COLOR]'%(COLOR2 ,COLOR1 ,ADDON_ID ))#line:1417
def reloadProfile (profile =None ):#line:1419
	if profile ==None :#line:1420
		ebi ('LoadProfile(Master user)')#line:1427
	else :ebi ('LoadProfile(%s)'%profile )#line:1428
def chunks (O0OOO00O00O0O0O0O ,O0OOOO0000O0000O0 ):#line:1430
	for OOOOOOO000O0OO000 in range (0 ,len (O0OOO00O00O0O0O0O ),O0OOOO0000O0000O0 ):#line:1431
		yield O0OOO00O00O0O0O0O [OOOOOOO000O0OO000 :OOOOOOO000O0OO000 +O0OOOO0000O0000O0 ]#line:1432
def asciiCheck (use =None ,over =False ):#line:1434
	if use ==None :#line:1435
		O0OOO0000O00OO00O =DIALOG .browse (3 ,'[COLOR %s]Select the folder you want to scan[/COLOR]'%COLOR2 ,'files','',False ,False ,HOME )#line:1436
		if over ==True :#line:1437
			O0O0O00OOOOO00OOO =1 #line:1438
		else :#line:1439
			O0O0O00OOOOO00OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Do you want to [COLOR %s]delete[/COLOR] all filenames with special characters or would you rather just [COLOR %s]scan and view[/COLOR] the results in the log?[/COLOR]'%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ='[B][COLOR green]Delete[/COLOR][/B]',nolabel ='[B][COLOR red]Scan[/COLOR][/B]')#line:1440
	else :#line:1441
		O0OOO0000O00OO00O =use #line:1442
		O0O0O00OOOOO00OOO =1 #line:1443
	if O0OOO0000O00OO00O =="":#line:1445
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: Cancelled[/COLOR]"%COLOR2 )#line:1446
		return #line:1447
	O0OOO0OO00O0OO000 =os .path .join (ADDONDATA ,'asciifiles.txt')#line:1449
	OO0OOOO00OOOOOOOO =os .path .join (ADDONDATA ,'asciifails.txt')#line:1450
	O0O000O0OO00O0OOO =open (O0OOO0OO00O0OO000 ,mode ='w+')#line:1451
	O00O00OO0OOOO000O =open (OO0OOOO00OOOOOOOO ,mode ='w+')#line:1452
	OO00O0OO000O0O0O0 =0 ;OOOO000O00O00000O =0 #line:1453
	OOO00O00OO0OO000O =fileCount (O0OOO0000O00OO00O )#line:1454
	OO0O0O00O0O00OO0O =''#line:1455
	OO0OO0OOO00O00O0O =[]#line:1456
	log ("Source file: (%s)"%str (O0OOO0000O00OO00O ),xbmc .LOGNOTICE )#line:1457
	DP .create (ADDONTITLE ,'Please wait...')#line:1459
	for OO000000000O0OOO0 ,OO0OOO0O0O0O0O0O0 ,OO0O0OOO00O0OO0O0 in os .walk (O0OOO0000O00OO00O ):#line:1460
		OO0OOO0O0O0O0O0O0 [:]=[OO0OOOO0O00OOOOO0 for OO0OOOO0O00OOOOO0 in OO0OOO0O0O0O0O0O0 ]#line:1461
		OO0O0OOO00O0OO0O0 [:]=[OOOOOOOOOO00000O0 for OOOOOOOOOO00000O0 in OO0O0OOO00O0OO0O0 ]#line:1462
		for O0O00OOO00000O00O in OO0O0OOO00O0OO0O0 :#line:1463
			OO0OO0OOO00O00O0O .append (O0O00OOO00000O00O )#line:1464
			O0OOOO0O0OOO0OOO0 =int (len (OO0OO0OOO00O00O0O )/float (OOO00O00OO0OO000O )*100 )#line:1465
			DP .update (O0OOOO0O0OOO0OOO0 ,"[COLOR %s]Checking for non ASCII files"%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,d ),'Please Wait[/COLOR]')#line:1466
			try :#line:1467
				O0O00OOO00000O00O .encode ('ascii')#line:1468
			except UnicodeDecodeError :#line:1469
				OO0OOOO0O0OO000O0 =os .path .join (OO000000000O0OOO0 ,O0O00OOO00000O00O )#line:1470
				if O0O0O00OOOOO00OOO :#line:1471
					try :#line:1472
						os .remove (OO0OOOO0O0OO000O0 )#line:1473
						for OOO0O00O0OOO0000O in chunks (OO0OOOO0O0OO000O0 ,75 ):#line:1474
							O0O000O0OO00O0OOO .write (OOO0O00O0OOO0000O +'\n')#line:1475
						O0O000O0OO00O0OOO .write ('\n')#line:1476
						OO00O0OO000O0O0O0 +=1 #line:1477
						log ("[ASCII Check] File Removed: %s "%OO0OOOO0O0OO000O0 ,xbmc .LOGERROR )#line:1478
					except :#line:1479
						for OOO0O00O0OOO0000O in chunks (OO0OOOO0O0OO000O0 ,75 ):#line:1480
							O00O00OO0OOOO000O .write (OOO0O00O0OOO0000O +'\n')#line:1481
						O00O00OO0OOOO000O .write ('\n')#line:1482
						OOOO000O00O00000O +=1 #line:1483
						log ("[ASCII Check] File Failed: %s "%OO0OOOO0O0OO000O0 ,xbmc .LOGERROR )#line:1484
				else :#line:1485
					for OOO0O00O0OOO0000O in chunks (OO0OOOO0O0OO000O0 ,75 ):#line:1486
						O0O000O0OO00O0OOO .write (OOO0O00O0OOO0000O +'\n')#line:1487
					O0O000O0OO00O0OOO .write ('\n')#line:1488
					OO00O0OO000O0O0O0 +=1 #line:1489
					log ("[ASCII Check] File Found: %s "%OO0OOOO0O0OO000O0 ,xbmc .LOGERROR )#line:1490
				pass #line:1491
	DP .close ();O0O000O0OO00O0OOO .close ();O00O00OO0OOOO000O .close ()#line:1492
	O0O00OOO00OO000OO =int (OO00O0OO000O0O0O0 )+int (OOOO000O00O00000O )#line:1493
	if O0O00OOO00OO000OO >0 :#line:1494
		if os .path .exists (O0OOO0OO00O0OO000 ):O0O000O0OO00O0OOO =open (O0OOO0OO00O0OO000 ,mode ='r');OO0O0O00O0O00OO0O =O0O000O0OO00O0OOO .read ();O0O000O0OO00O0OOO .close ()#line:1495
		if os .path .exists (OO0OOOO00OOOOOOOO ):O00O00OO0OOOO000O =open (OO0OOOO00OOOOOOOO ,mode ='r');OO0O0OOOO00OOO0O0 =O00O00OO0OOOO000O .read ();O00O00OO0OOOO000O .close ()#line:1496
		if O0O0O00OOOOO00OOO :#line:1497
			if use :#line:1498
				LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: %s Removed / %s Failed.[/COLOR]"%(COLOR2 ,OO00O0OO000O0O0O0 ,OOOO000O00O00000O ))#line:1499
			else :#line:1500
				TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Removed:[/B][/COLOR]\n %s\n\n[COLOR yellow][B]%s Files Failed:[B][/COLOR]\n %s"%(OO00O0OO000O0O0O0 ,OO0O0O00O0O00OO0O ,OOOO000O00O00000O ,OO0O0OOOO00OOO0O0 ))#line:1501
		else :#line:1502
			TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Found:[/B][/COLOR]\n %s"%(OO00O0OO000O0O0O0 ,OO0O0O00O0O00OO0O ))#line:1503
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: None Found.[/COLOR]"%COLOR2 )#line:1504
def fileCount (O0OO00000OOOO00OO ,excludes =True ):#line:1506
	OOO0000O0OOOO0000 =[ADDON_ID ,'cache','system','packages','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:1507
	OO0OOOOO0OOO0O0O0 =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:1508
	O00O0OOO0000OO0OO =[]#line:1509
	for OOO0OO00OO0OO0O00 ,O0O000000000O000O ,OO0OO0O0OO0O00O0O in os .walk (O0OO00000OOOO00OO ):#line:1510
		if excludes :#line:1511
			O0O000000000O000O [:]=[O00OOOOO0OOO000OO for O00OOOOO0OOO000OO in O0O000000000O000O if O00OOOOO0OOO000OO not in OOO0000O0OOOO0000 ]#line:1512
			OO0OO0O0OO0O00O0O [:]=[OOO0O00OOOO0OO0OO for OOO0O00OOOO0OO0OO in OO0OO0O0OO0O00O0O if OOO0O00OOOO0OO0OO not in OO0OOOOO0OOO0O0O0 ]#line:1513
		for O0O0O000O00OO00O0 in OO0OO0O0OO0O00O0O :#line:1514
			O00O0OOO0000OO0OO .append (O0O0O000O00OO00O0 )#line:1515
	return len (O00O0OOO0000OO0OO )#line:1516
def defaultSkin ():#line:1518
	log ("[Default Skin Check]",xbmc .LOGNOTICE )#line:1519
	OO0O0O00OOOOOO00O =os .path .join (USERDATA ,'guitemp.xml')#line:1520
	O00O000OO0O000OO0 =OO0O0O00OOOOOO00O if os .path .exists (OO0O0O00OOOOOO00O )else GUISETTINGS #line:1521
	if not os .path .exists (O00O000OO0O000OO0 ):return False #line:1522
	log ("Reading gui file: %s"%O00O000OO0O000OO0 ,xbmc .LOGNOTICE )#line:1523
	OO0O000O00OO00O00 =open (O00O000OO0O000OO0 ,'r+')#line:1524
	OOO0OO00OOOOO00O0 =OO0O000O00OO00O00 .read ().replace ('\n','').replace ('\r','').replace ('\t','').replace ('    ','');OO0O000O00OO00O00 .close ()#line:1525
	log ("Opening gui settings",xbmc .LOGNOTICE )#line:1526
	O00O00OO00O0OO000 =re .compile ('<lookandfeel>.+?<ski.+?>(.+?)</skin>.+?</lookandfeel>').findall (OOO0OO00OOOOO00O0 )#line:1527
	log ("Matches: %s"%str (O00O00OO00O0OO000 ),xbmc .LOGNOTICE )#line:1528
	if len (O00O00OO00O0OO000 )>0 :#line:1529
		O0000000000OOO0O0 =O00O00OO00O0OO000 [0 ]#line:1530
		O000O0OOO0OOO0O0O =os .path .join (ADDONS ,O00O00OO00O0OO000 [0 ],'addon.xml')#line:1531
		if os .path .exists (O000O0OOO0OOO0O0O ):#line:1532
			OOO0000OOO0O0O00O =open (O000O0OOO0OOO0O0O ,'r+')#line:1533
			O0000OOOOO0O00OO0 =OOO0000OOO0O0O00O .read ();OOO0000OOO0O0O00O .close ()#line:1534
			O0000O000O00OO0O0 =parseDOM (O0000OOOOO0O00OO0 ,'addon',ret ='name')#line:1535
			if len (O0000O000O00OO0O0 )>0 :OOO00O0000O0O0OOO =O0000O000O00OO0O0 [0 ]#line:1536
			else :OOO00O0000O0O0OOO ='no match'#line:1537
		else :OOO00O0000O0O0OOO ='no file'#line:1538
		log ("[Default Skin Check] Skin name: %s"%OOO00O0000O0O0OOO ,xbmc .LOGNOTICE )#line:1539
		log ("[Default Skin Check] Skin id: %s"%O0000000000OOO0O0 ,xbmc .LOGNOTICE )#line:1540
		setS ('defaultskin',O0000000000OOO0O0 )#line:1541
		setS ('defaultskinname',OOO00O0000O0O0OOO )#line:1542
		setS ('defaultskinignore','false')#line:1543
	if os .path .exists (OO0O0O00OOOOOO00O ):#line:1544
		log ("Deleting Temp Gui File.",xbmc .LOGNOTICE )#line:1545
		os .remove (OO0O0O00OOOOOO00O )#line:1546
	log ("[Default Skin Check] End",xbmc .LOGNOTICE )#line:1547
def lookandFeelData (do ='save'):#line:1549
	O00OO00O0000O00O0 =['lookandfeel.enablerssfeeds','lookandfeel.font','lookandfeel.rssedit','lookandfeel.skincolors','lookandfeel.skintheme','lookandfeel.skinzoom','lookandfeel.soundskin','lookandfeel.startupwindow','lookandfeel.stereostrength']#line:1550
	if do =='save':#line:1551
		for O0OO0OO00O0O0O000 in O00OO00O0000O00O0 :#line:1552
			OOOO00000OO000O0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":"%s"}, "id":1}'%(O0OO0OO00O0O0O000 )#line:1553
			OO0O0000OO0O00000 =xbmc .executeJSONRPC (OOOO00000OO000O0O )#line:1554
			if not 'error'in OO0O0000OO0O00000 :#line:1555
				O00O0O00O0OOO0OO0 =re .compile ('{"value":(.+?)}').findall (str (OO0O0000OO0O00000 ))#line:1556
				setS (O0OO0OO00O0O0O000 .replace ('lookandfeel','default'),O00O0O00O0OOO0OO0 [0 ])#line:1557
				log ("%s saved to %s"%(O0OO0OO00O0O0O000 ,O00O0O00O0OOO0OO0 [0 ]),xbmc .LOGNOTICE )#line:1558
	else :#line:1559
		for O0OO0OO00O0O0O000 in O00OO00O0000O00O0 :#line:1560
			OOOO00OOO000OO0OO =getS (O0OO0OO00O0O0O000 .replace ('lookandfeel','default'))#line:1561
			OOOO00000OO000O0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"%s","value":%s}, "id":1}'%(O0OO0OO00O0O0O000 ,OOOO00OOO000OO0OO )#line:1562
			OO0O0000OO0O00000 =xbmc .executeJSONRPC (OOOO00000OO000O0O )#line:1563
			log ("%s restored to %s"%(O0OO0OO00O0O0O000 ,OOOO00OOO000OO0OO ),xbmc .LOGNOTICE )#line:1564
def sep (middle =''):#line:1566
	OOOO00O0O00OO000O =uservar .SPACER #line:1567
	O00O0000OOOOO0O00 =OOOO00O0O00OO000O *40 #line:1568
	if not middle =='':#line:1569
		middle ='[ %s ]'%middle #line:1570
		O000O0O000O000OOO =int ((40 -len (middle ))/2 )#line:1571
		O00O0000OOOOO0O00 ="%s%s%s"%(O00O0000OOOOO0O00 [:O000O0O000O000OOO ],middle ,O00O0000OOOOO0O00 [:O000O0O000O000OOO +2 ])#line:1572
	return O00O0000OOOOO0O00 [:40 ]#line:1573
def convertAdvanced ():#line:1575
	if os .path .exists (ADVANCED ):#line:1576
		O0OO0000000OOO000 =open (ADVANCED )#line:1577
		OOOOO0O00000O0OO0 =O0OO0000000OOO000 .read ()#line:1578
		if KODIV >=17 :#line:1579
			return #line:1580
		else :#line:1581
			return #line:1582
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:1583
def backUpOptions (O0OOO0000O00OOOO0 ,name =""):#line:1588
	OOOO0OO00O0O0OOOO =[ADDON_ID ,'cache','system','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:1589
	OOOO0O0OOOO0O0O00 =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:1590
	OO0O00OOOO000O000 =[os .path .join (DATABASE ,'onechannelcache.db'),os .path .join (DATABASE ,'saltscache.db'),os .path .join (DATABASE ,'saltscache.db-shm'),os .path .join (DATABASE ,'saltscache.db-wal'),os .path .join (DATABASE ,'saltshd.lite.db'),os .path .join (DATABASE ,'saltshd.lite.db-shm'),os .path .join (DATABASE ,'saltshd.lite.db-wal'),os .path .join (ADDOND ,'script.trakt','queue.db'),os .path .join (HOME ,'cache','commoncache.db'),os .path .join (ADDOND ,'script.module.dudehere.routines','access.log'),os .path .join (ADDOND ,'script.module.dudehere.routines','trakt.db'),os .path .join (ADDOND ,'script.module.metahandler','meta_cache','video_cache.db')]#line:1602
	O0O0OO0OOO00O0OOO =xbmc .translatePath (BACKUPLOCATION )#line:1604
	OO00OOO00O0000O00 =xbmc .translatePath (MYBUILDS )#line:1605
	try :#line:1606
		if not os .path .exists (O0O0OO0OOO00O0OOO ):xbmcvfs .mkdirs (O0O0OO0OOO00O0OOO )#line:1607
		if not os .path .exists (OO00OOO00O0000O00 ):xbmcvfs .mkdirs (OO00OOO00O0000O00 )#line:1608
	except Exception as OO0O000OO00OOOOOO :#line:1609
		DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OO0O000OO00OOOOOO )))#line:1610
		return #line:1611
	if O0OOO0000O00OOOO0 =="build":#line:1612
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם ברצונך לגבות את הבילד?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR red]ביטול[/COLOR][/B]",yeslabel ="[B][COLOR green]גיבוי[/COLOR][/B]"):#line:1613
			if name =="":#line:1614
				name =getKeyboard ("","אנא הכנס שם ל %s באנגלית"%O0OOO0000O00OOOO0 )#line:1615
				if not name :return False #line:1616
				name =name .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:1617
			name =urllib .quote_plus (name );O0OOOOO0O0O0O0O0O =''#line:1618
			OOO0000O0O0O0000O =os .path .join (OO00OOO00O0000O00 ,'%s.zip'%name )#line:1619
			OO0O0OOO000OOO00O =0 #line:1620
			OO0O0O0O0OOOO0OOO =[]#line:1621
			if not DIALOG .yesno (ADDONTITLE ,"האם לשמור את תיקית האדון דאטה?",yeslabel ='[B][COLOR green]שמור[/COLOR][/B]',nolabel ='[B][COLOR red]לא לשמור[/COLOR][/B]'):#line:1622
				OOOO0OO00O0O0OOOO .append ('addon_data')#line:1623
			convertSpecial (HOME ,True )#line:1624
			asciiCheck (HOME ,True )#line:1625
			try :#line:1626
				OOO0OOO0O000OO00O =zipfile .ZipFile (xbmc .translatePath (OOO0000O0O0O0000O ),mode ='w')#line:1627
			except :#line:1628
				try :#line:1629
					O0OOOOO0O0O0O0O0O =os .path .join (PACKAGES ,'%s.zip'%name )#line:1630
					OOO0OOO0O000OO00O =zipfile .ZipFile (O0OOOOO0O0O0O0O0O ,mode ='w')#line:1631
				except :#line:1632
					log ("Unable to create %s.zip"%name ,xbmc .LOGERROR )#line:1633
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:1634
						openS ()#line:1635
						return #line:1636
					else :#line:1637
						return #line:1638
			DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:1639
			for O0O0OO0O00O00000O ,O0000OOOO000O0O00 ,O00O0OO0O0OO0OOO0 in os .walk (HOME ):#line:1640
				O0000OOOO000O0O00 [:]=[OO0O00OO0O0OO00OO for OO0O00OO0O0OO00OO in O0000OOOO000O0O00 if OO0O00OO0O0OO00OO not in OOOO0OO00O0O0OOOO ]#line:1641
				O00O0OO0O0OO0OOO0 [:]=[OO000O0OOOOO0O000 for OO000O0OOOOO0O000 in O00O0OO0O0OO0OOO0 if OO000O0OOOOO0O000 not in OOOO0O0OOOO0O0O00 ]#line:1642
				for O0OOOOOO00000OOO0 in O00O0OO0O0OO0OOO0 :#line:1643
					OO0O0O0O0OOOO0OOO .append (O0OOOOOO00000OOO0 )#line:1644
			O0O0OO0OO00OOO0O0 =len (OO0O0O0O0OOOO0OOO )#line:1645
			fixmetas ()#line:1646
			for O0O0OO0O00O00000O ,O0000OOOO000O0O00 ,O00O0OO0O0OO0OOO0 in os .walk (HOME ):#line:1647
				O0000OOOO000O0O00 [:]=[O00OOO0O0O0OOOO0O for O00OOO0O0O0OOOO0O in O0000OOOO000O0O00 if O00OOO0O0O0OOOO0O not in OOOO0OO00O0O0OOOO ]#line:1648
				O00O0OO0O0OO0OOO0 [:]=[OO0O0O0OOOO0O00O0 for OO0O0O0OOOO0O00O0 in O00O0OO0O0OO0OOO0 if OO0O0O0OOOO0O00O0 not in OOOO0O0OOOO0O0O00 ]#line:1649
				for O0OOOOOO00000OOO0 in O00O0OO0O0OO0OOO0 :#line:1650
					try :#line:1651
						OO0O0OOO000OOO00O +=1 #line:1652
						O00O0O00OO000OO00 =percentage (OO0O0OOO000OOO00O ,O0O0OO0OO00OOO0O0 )#line:1653
						DP .update (int (O00O0O00OO000OO00 ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OOO000OOO00O ,COLOR1 ,O0O0OO0OO00OOO0O0 ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOOOO00000OOO0 ),'')#line:1654
						O0O0OO00OO0OOOOOO =os .path .join (O0O0OO0O00O00000O ,O0OOOOOO00000OOO0 )#line:1655
						if O0OOOOOO00000OOO0 in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE );continue #line:1656
						elif os .path .join (O0O0OO0O00O00000O ,O0OOOOOO00000OOO0 )in OO0O00OOOO000O000 :log ("[Back Up] Type = '%s': Ignore %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE );continue #line:1657
						elif os .path .join ('addons','packages')in O0O0OO00OO0OOOOOO :log ("[Back Up] Type = '%s': Ignore %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE );continue #line:1658
						elif O0OOOOOO00000OOO0 .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE );continue #line:1659
						elif O0OOOOOO00000OOO0 .endswith ('.pyo'):continue #line:1660
						elif O0OOOOOO00000OOO0 .endswith ('.db')and 'Database'in O0O0OO0O00O00000O :#line:1661
							O00000000OO000O0O =O0OOOOOO00000OOO0 .replace ('.db','')#line:1662
							O00000000OO000O0O =''.join ([OO00OO0O0OOO000OO for OO00OO0O0OOO000OO in O00000000OO000O0O if not OO00OO0O0OOO000OO .isdigit ()])#line:1663
							if O00000000OO000O0O in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:1664
								if not O0OOOOOO00000OOO0 ==latestDB (O00000000OO000O0O ):log ("[Back Up] Type = '%s': Ignore %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE );continue #line:1665
						try :#line:1666
							OOO0OOO0O000OO00O .write (O0O0OO00OO0OOOOOO ,O0O0OO00OO0OOOOOO [len (HOME ):],zipfile .ZIP_DEFLATED )#line:1667
						except Exception as OO0O000OO00OOOOOO :#line:1668
							log ("[Back Up] Type = '%s': Unable to backup %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE )#line:1669
							log ("%s / %s"%(Exception ,OO0O000OO00OOOOOO ))#line:1670
					except Exception as OO0O000OO00OOOOOO :#line:1671
						log ("[Back Up] Type = '%s': Unable to backup %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE )#line:1672
						log ("Build Backup Error: %s"%str (OO0O000OO00OOOOOO ),xbmc .LOGNOTICE )#line:1673
			OOO0OOO0O000OO00O .close ()#line:1674
			xbmc .sleep (500 )#line:1675
			DP .update (100 ,"Creating %s_guisettings.zip"%name ,"","")#line:1676
			backUpOptions ('guifix',name )#line:1677
			if not O0OOOOO0O0O0O0O0O =='':#line:1678
				O0O000OO0OOO00OOO =xbmcvfs .rename (O0OOOOO0O0O0O0O0O ,OOO0000O0O0O0000O )#line:1679
				if O0O000OO0OOO00OOO ==0 :#line:1680
					xbmcvfs .copy (O0OOOOO0O0O0O0O0O ,OOO0000O0O0O0000O )#line:1681
					xbmcvfs .delete (O0OOOOO0O0O0O0O0O )#line:1682
			DP .close ()#line:1683
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR] [COLOR %s]backup successful:[/COLOR]"%(COLOR1 ,name ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0000O0O0O0000O ))#line:1684
	elif O0OOO0000O00OOOO0 =="guifix":#line:1685
		if name =="":#line:1686
			O0OOO00O0OOO0OOOO =getKeyboard ("","Please enter a name for the %s zip"%O0OOO0000O00OOOO0 )#line:1687
			if not O0OOO00O0OOO0OOOO :return False #line:1688
			convertSpecial (USERDATA ,True )#line:1689
			asciiCheck (USERDATA ,True )#line:1690
		else :O0OOO00O0OOO0OOOO =name #line:1691
		O0OOO00O0OOO0OOOO =urllib .quote_plus (O0OOO00O0OOO0OOOO );OOO00O0O0O0O00O0O =''#line:1692
		OO0OOOO0OOOOO000O =xbmc .translatePath (os .path .join (OO00OOO00O0000O00 ,'%s_guisettings.zip'%O0OOO00O0OOO0OOOO ))#line:1693
		if os .path .exists (GUISETTINGS ):#line:1694
			try :#line:1695
				OOO0OOO0O000OO00O =zipfile .ZipFile (OO0OOOO0OOOOO000O ,mode ='w')#line:1696
			except :#line:1697
				try :#line:1698
					OOO00O0O0O0O00O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOO00O0OOO0OOOO )#line:1699
					OOO0OOO0O000OO00O =zipfile .ZipFile (OOO00O0O0O0O00O0O ,mode ='w')#line:1700
				except :#line:1701
					log ("Unable to create %s_guisettings.zip"%O0OOO00O0OOO0OOOO ,xbmc .LOGERROR )#line:1702
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:1703
						openS ()#line:1704
						return #line:1705
					else :#line:1706
						return #line:1707
			try :#line:1708
				OOO0OOO0O000OO00O .write (GUISETTINGS ,'guisettings.xml',zipfile .ZIP_DEFLATED )#line:1709
				OOO0OOO0O000OO00O .write (PROFILES ,'profiles.xml',zipfile .ZIP_DEFLATED )#line:1710
				O0OOO0000O0OOO0O0 =glob .glob (os .path .join (ADDOND ,'skin.*',''))#line:1711
				log (str (O0OOO0000O0OOO0O0 ),xbmc .LOGNOTICE )#line:1712
				for O0O0O0OOO0O0OO000 in O0OOO0000O0OOO0O0 :#line:1713
					OOOOOOOOOO0000000 =os .path .split (O0O0O0OOO0O0OO000 [:-1 ])[1 ]#line:1714
					if not OOOOOOOOOO0000000 in ['skin.confluence','skin.re-touch','skin.estuary','skin.myconfluence','skin.estouchy','skin.anonymous.mod','skin.anonymous.nox','skin.Premium.mod']:#line:1715
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to add the following skin folder to the GuiFix Zip File?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOOOO0000000 ),yeslabel ="[B][COLOR green]Add Skin[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Skin[/COLOR][/B]"):#line:1716
							for O0O0OO0O00O00000O ,O0000OOOO000O0O00 ,O00O0OO0O0OO0OOO0 in os .walk (os .path .join (ADDOND ,O0O0O0OOO0O0OO000 )):#line:1717
								O00O0OO0O0OO0OOO0 [:]=[O00O0OOO0OO00000O for O00O0OOO0OO00000O in O00O0OO0O0OO0OOO0 if O00O0OOO0OO00000O not in OOOO0O0OOOO0O0O00 ]#line:1718
								for O0OOOOOO00000OOO0 in O00O0OO0O0OO0OOO0 :#line:1719
									O0O0OO00OO0OOOOOO =os .path .join (O0O0OO0O00O00000O ,O0OOOOOO00000OOO0 )#line:1720
									OOO0OOO0O000OO00O .write (O0O0OO00OO0OOOOOO ,O0O0OO00OO0OOOOOO [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:1721
							O0OOO0000O0OOO0O0 =parseDOM (link ,'import',ret ='addon')#line:1722
							if 'script.skinshortcuts'in O0OOO0000O0OOO0O0 :#line:1723
								for O0O0OO0O00O00000O ,O0000OOOO000O0O00 ,O00O0OO0O0OO0OOO0 in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:1724
									O00O0OO0O0OO0OOO0 [:]=[O000000OOOO00OO0O for O000000OOOO00OO0O in O00O0OO0O0OO0OOO0 if O000000OOOO00OO0O not in OOOO0O0OOOO0O0O00 ]#line:1725
									for O0OOOOOO00000OOO0 in O00O0OO0O0OO0OOO0 :#line:1726
										O0O0OO00OO0OOOOOO =os .path .join (O0O0OO0O00O00000O ,O0OOOOOO00000OOO0 )#line:1727
										OOO0OOO0O000OO00O .write (O0O0OO00OO0OOOOOO ,O0O0OO00OO0OOOOOO [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:1728
						else :log ("[Back Up] Type = '%s': %s ignored"%(O0OOO0000O00OOOO0 ,O0O0O0OOO0O0OO000 ),xbmc .LOGNOTICE )#line:1729
			except Exception as OO0O000OO00OOOOOO :#line:1730
				log ("[Back Up] Type = '%s': %s"%(O0OOO0000O00OOOO0 ,OO0O000OO00OOOOOO ),xbmc .LOGNOTICE )#line:1731
				pass #line:1732
			OOO0OOO0O000OO00O .close ()#line:1733
			if not OOO00O0O0O0O00O0O =='':#line:1734
				O0O000OO0OOO00OOO =xbmcvfs .rename (OOO00O0O0O0O00O0O ,OO0OOOO0OOOOO000O )#line:1735
				if O0O000OO0OOO00OOO ==0 :#line:1736
					xbmcvfs .copy (OOO00O0O0O0O00O0O ,OO0OOOO0OOOOO000O )#line:1737
					xbmcvfs .delete (OOO00O0O0O0O00O0O )#line:1738
		else :log ("[Back Up] Type = '%s': guisettings.xml not found"%O0OOO0000O00OOOO0 ,xbmc .LOGNOTICE )#line:1739
		if name =="":#line:1740
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]GuiFix backup successful:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOOO0OOOOO000O ))#line:1741
	elif O0OOO0000O00OOOO0 =="theme":#line:1742
		if not DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to create a theme backup?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Continue[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):LogNotify ("Theme Backup","Cancelled!");return False #line:1743
		if name =="":#line:1744
			O000OO00000000OO0 =getKeyboard ("","Please enter a name for the %s zip"%O0OOO0000O00OOOO0 )#line:1745
			if not O000OO00000000OO0 :return False #line:1746
		else :O000OO00000000OO0 =name #line:1747
		O000OO00000000OO0 =urllib .quote_plus (O000OO00000000OO0 );O0OOOOO0O0O0O0O0O =''#line:1748
		OOO0000O0O0O0000O =os .path .join (OO00OOO00O0000O00 ,'%s.zip'%O000OO00000000OO0 )#line:1749
		try :#line:1750
			OOO0OOO0O000OO00O =zipfile .ZipFile (xbmc .translatePath (OOO0000O0O0O0000O ),mode ='w')#line:1751
		except :#line:1752
			try :#line:1753
				O0OOOOO0O0O0O0O0O =os .path .join (PACKAGES ,'%s.zip'%O000OO00000000OO0 )#line:1754
				OOO0OOO0O000OO00O =zipfile .ZipFile (O0OOOOO0O0O0O0O0O ,mode ='w')#line:1755
			except :#line:1756
				log ("Unable to create %s.zip"%O000OO00000000OO0 ,xbmc .LOGERROR )#line:1757
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:1758
					openS ()#line:1759
					return #line:1760
				else :#line:1761
					return #line:1762
		convertSpecial (USERDATA ,True )#line:1763
		asciiCheck (USERDATA ,True )#line:1764
		try :#line:1765
			if not SKIN =='skin.confluence':#line:1766
				OOO00OOOOO00OO0OO =os .path .join (ADDONS ,SKIN ,'media')#line:1767
				O000O0OO000OOO0OO =glob .glob (os .path .join (OOO00OOOOO00OO0OO ,'*.xbt'))#line:1768
				if len (O000O0OO000OOO0OO )>1 :#line:1769
					if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go through the Texture Files for?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:1770
						OOO00OOOOO00OO0OO =os .path .join (ADDONS ,SKIN ,'media')#line:1771
						O000O0OO000OOO0OO =glob .glob (os .path .join (OOO00OOOOO00OO0OO ,'*.xbt'))#line:1772
						for OO00000OO0O000O0O in O000O0OO000OOO0OO :#line:1773
							if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR1 ,COLOR2 ,OO00000OO0O000O0O .replace (OOO00OOOOO00OO0OO ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:1774
								O0O0OO00OO0OOOOOO =OO00000OO0O000O0O #line:1775
								OOO0000O0OO0000OO =O0O0OO00OO0OOOOOO .replace (HOME ,"")#line:1776
								OOO0OOO0O000OO00O .write (O0O0OO00OO0OOOOOO ,OOO0000O0OO0000OO ,zipfile .ZIP_DEFLATED )#line:1777
				else :#line:1778
					for OO00000OO0O000O0O in O000O0OO000OOO0OO :#line:1779
						if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR2 ,COLOR1 ,OO00000OO0O000O0O .replace (OOO00OOOOO00OO0OO ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:1780
							O0O0OO00OO0OOOOOO =OO00000OO0O000O0O #line:1781
							OOO0000O0OO0000OO =O0O0OO00OO0OOOOOO .replace (HOME ,"")#line:1782
							OOO0OOO0O000OO00O .write (O0O0OO00OO0OOOOOO ,OOO0000O0OO0000OO ,zipfile .ZIP_DEFLATED )#line:1783
				OOO00OO0OO0OO0OOO =os .path .join (ADDOND ,SKIN ,'settings.xml')#line:1784
				if os .path .exists (OOO00OO0OO0OO0OOO ):#line:1785
					if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] in [COLOR %s]/addon_data/[/COLOR] for?"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:1786
						OOO00OOOOO00OO0OO =os .path .join (ADDOND ,SKIN )#line:1787
						OOO0OOO0O000OO00O .write (OOO00OO0OO0OO0OOO ,OOO00OO0OO0OO0OOO .replace (HOME ,""),zipfile .ZIP_DEFLATED )#line:1788
				O0O00O0O00OOOO0O0 =open (os .path .join (ADDONS ,SKIN ,'addon.xml'));OOO0OOO00O00OO0O0 =O0O00O0O00OOOO0O0 .read ();O0O00O0O00OOOO0O0 .close ()#line:1789
				O0OOO0000O0OOO0O0 =parseDOM (OOO0OOO00O00OO0O0 ,'import',ret ='addon')#line:1790
				if 'script.skinshortcuts'in O0OOO0000O0OOO0O0 :#line:1791
					if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] for [COLOR %s]script.skinshortcuts[/COLOR]?"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:1792
						for O0O0OO0O00O00000O ,O0000OOOO000O0O00 ,O00O0OO0O0OO0OOO0 in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:1793
							O00O0OO0O0OO0OOO0 [:]=[OOO0OO0OOOO0O0000 for OOO0OO0OOOO0O0000 in O00O0OO0O0OO0OOO0 if OOO0OO0OOOO0O0000 not in OOOO0O0OOOO0O0O00 ]#line:1794
							for O0OOOOOO00000OOO0 in O00O0OO0O0OO0OOO0 :#line:1795
								O0O0OO00OO0OOOOOO =os .path .join (O0O0OO0O00O00000O ,O0OOOOOO00000OOO0 )#line:1796
								OOO0OOO0O000OO00O .write (O0O0OO00OO0OOOOOO ,O0O0OO00OO0OOOOOO [len (HOME ):],zipfile .ZIP_DEFLATED )#line:1797
			if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include a [COLOR %s]Backgrounds[/COLOR] folder?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:1798
				O0O0OO00OO0OOOOOO =DIALOG .browse (0 ,'Select location of backgrounds','files','',True ,False ,HOME ,False )#line:1799
				if not O0O0OO00OO0OOOOOO ==HOME :#line:1800
					for O0O0OO0O00O00000O ,O0000OOOO000O0O00 ,O00O0OO0O0OO0OOO0 in os .walk (O0O0OO00OO0OOOOOO ):#line:1801
						O0000OOOO000O0O00 [:]=[OOOOO000O0000OOO0 for OOOOO000O0000OOO0 in O0000OOOO000O0O00 if OOOOO000O0000OOO0 not in OOOO0OO00O0O0OOOO ]#line:1802
						O00O0OO0O0OO0OOO0 [:]=[OO0O0OO000O000OO0 for OO0O0OO000O000OO0 in O00O0OO0O0OO0OOO0 if OO0O0OO000O000OO0 not in OOOO0O0OOOO0O0O00 ]#line:1803
						for O0OOOOOO00000OOO0 in O00O0OO0O0OO0OOO0 :#line:1804
							try :#line:1805
								OOO0000O0OO0000OO =os .path .join (O0O0OO0O00O00000O ,O0OOOOOO00000OOO0 )#line:1806
								OOO0OOO0O000OO00O .write (OOO0000O0OO0000OO ,OOO0000O0OO0000OO [len (HOME ):],zipfile .ZIP_DEFLATED )#line:1807
							except Exception as OO0O000OO00OOOOOO :#line:1808
								log ("[Back Up] Type = '%s': Unable to backup %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE )#line:1809
								log ("Backup Error: %s"%str (OO0O000OO00OOOOOO ),xbmc .LOGNOTICE )#line:1810
				OO00O000O0O0O00O0 =latestDB ('Textures')#line:1811
				if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00O000O0O0O00O0 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:1812
					OOO0OOO0O000OO00O .write (os .path .join (DATABASE ,OO00O000O0O0O00O0 ),'/userdata/Database/%s'%OO00O000O0O0O00O0 ,zipfile .ZIP_DEFLATED )#line:1813
			if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include any addons?[/COLOR]"%(COLOR2 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:1814
				O0O0O0OOO0O0OO000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:1815
				OO00OOOO0OO00O00O =[];O0OO00000OO0OO0O0 =[]#line:1816
				for OO000OO00OO00000O in sorted (O0O0O0OOO0O0OO000 ,key =lambda O00OO0OOOO0000OO0 :O00OO0OOOO0000OO0 ):#line:1817
					OO0O0OO00OO00O0OO =os .path .split (OO000OO00OO00000O [:-1 ])[1 ]#line:1818
					if OO0O0OO00OO00O0OO in EXCLUDES :continue #line:1819
					elif OO0O0OO00OO00O0OO in DEFAULTPLUGINS :continue #line:1820
					elif OO0O0OO00OO00O0OO =='packages':continue #line:1821
					OOOO0OOOO0O00OOO0 =os .path .join (OO000OO00OO00000O ,'addon.xml')#line:1822
					if os .path .exists (OOOO0OOOO0O00OOO0 ):#line:1823
						O0O00O0O00OOOO0O0 =open (OOOO0OOOO0O00OOO0 )#line:1824
						O00O000O0000OOOOO =O0O00O0O00OOOO0O0 .read ()#line:1825
						O0OOO0000O0OOO0O0 =parseDOM (O00O000O0000OOOOO ,'addon',ret ='name')#line:1826
						if len (O0OOO0000O0OOO0O0 )>0 :#line:1827
							OO00OOOO0OO00O00O .append (O0OOO0000O0OOO0O0 [0 ])#line:1828
							O0OO00000OO0OO0O0 .append (OO0O0OO00OO00O0OO )#line:1829
						else :#line:1830
							OO00OOOO0OO00O00O .append (OO0O0OO00OO00O0OO )#line:1831
							O0OO00000OO0OO0O0 .append (OO0O0OO00OO00O0OO )#line:1832
				if KODIV >16 :#line:1833
					OO0O00O0OOOO0O000 =DIALOG .multiselect ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,OO00OOOO0OO00O00O )#line:1834
				else :#line:1835
					OO0O00O0OOOO0O000 =[];OOO0000O0OO0OO0OO =0 #line:1836
					OOO000O0OO0OOO00O =["-- Click here to Continue --"]+OO00OOOO0OO00O00O #line:1837
					while not OOO0000O0OO0OO0OO ==-1 :#line:1838
						OOO0000O0OO0OO0OO =DIALOG .select ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,OOO000O0OO0OOO00O )#line:1839
						if OOO0000O0OO0OO0OO ==-1 :break #line:1840
						elif OOO0000O0OO0OO0OO ==0 :break #line:1841
						else :#line:1842
							OOOOO0O000OO000O0 =(OOO0000O0OO0OO0OO -1 )#line:1843
							if OOOOO0O000OO000O0 in OO0O00O0OOOO0O000 :#line:1844
								OO0O00O0OOOO0O000 .remove (OOOOO0O000OO000O0 )#line:1845
								OOO000O0OO0OOO00O [OOO0000O0OO0OO0OO ]=OO00OOOO0OO00O00O [OOOOO0O000OO000O0 ]#line:1846
							else :#line:1847
								OO0O00O0OOOO0O000 .append (OOOOO0O000OO000O0 )#line:1848
								OOO000O0OO0OOO00O [OOO0000O0OO0OO0OO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO00OOOO0OO00O00O [OOOOO0O000OO000O0 ])#line:1849
				if len (OO0O00O0OOOO0O000 )>0 :#line:1850
					for O000O0OOOO00O0000 in OO0O00O0OOOO0O000 :#line:1851
						for O0O0OO0O00O00000O ,O0000OOOO000O0O00 ,O00O0OO0O0OO0OOO0 in os .walk (os .path .join (ADDONS ,O0OO00000OO0OO0O0 [O000O0OOOO00O0000 ])):#line:1852
							O00O0OO0O0OO0OOO0 [:]=[O0O0OOO0O00O00OOO for O0O0OOO0O00O00OOO in O00O0OO0O0OO0OOO0 if O0O0OOO0O00O00OOO not in OOOO0O0OOOO0O0O00 ]#line:1853
							for O0OOOOOO00000OOO0 in O00O0OO0O0OO0OOO0 :#line:1854
								if O0OOOOOO00000OOO0 .endswith ('.pyo'):continue #line:1855
								O0O0OO00OO0OOOOOO =os .path .join (O0O0OO0O00O00000O ,O0OOOOOO00000OOO0 )#line:1856
								OOO0OOO0O000OO00O .write (O0O0OO00OO0OOOOOO ,O0O0OO00OO0OOOOOO [len (HOME ):],zipfile .ZIP_DEFLATED )#line:1857
			if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]guisettings.xml[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:1858
				OOO0OOO0O000OO00O .write (GUISETTINGS ,'/userdata/guisettings.xml',zipfile .ZIP_DEFLATED )#line:1859
		except Exception as OO0O000OO00OOOOOO :#line:1860
			OOO0OOO0O000OO00O .close ()#line:1861
			log ("[Back Up] Type = '%s': %s"%(O0OOO0000O00OOOO0 ,str (OO0O000OO00OOOOOO )),xbmc .LOGNOTICE )#line:1862
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip failed:[/COLOR]"%(COLOR1 ,O000OO00000000OO0 ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OO0O000OO00OOOOOO )))#line:1863
			if not O0OOOOO0O0O0O0O0O =='':#line:1864
				try :os .remove (xbmc .translatePath (O0OOOOO0O0O0O0O0O ))#line:1865
				except Exception as OO0O000OO00OOOOOO :log (str (OO0O000OO00OOOOOO ))#line:1866
			else :#line:1867
				try :os .remove (xbmc .translatePath (OOO0000O0O0O0000O ))#line:1868
				except Exception as OO0O000OO00OOOOOO :log (str (OO0O000OO00OOOOOO ))#line:1869
			return #line:1870
		OOO0OOO0O000OO00O .close ()#line:1871
		if not O0OOOOO0O0O0O0O0O =='':#line:1872
			O0O000OO0OOO00OOO =xbmcvfs .rename (O0OOOOO0O0O0O0O0O ,OOO0000O0O0O0000O )#line:1873
			if O0O000OO0OOO00OOO ==0 :#line:1874
				xbmcvfs .copy (O0OOOOO0O0O0O0O0O ,OOO0000O0O0O0000O )#line:1875
				xbmcvfs .delete (O0OOOOO0O0O0O0O0O )#line:1876
		DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip successful:[/COLOR]"%(COLOR1 ,O000OO00000000OO0 ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0000O0O0O0000O ))#line:1877
	elif O0OOO0000O00OOOO0 =="addondata":#line:1878
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]לבצע גיבוי הגדרות?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR white]ביטול [/COLOR][/B]",yeslabel ="[B][COLOR green]אישור[/COLOR][/B]"):#line:1879
			if name =="":#line:1880
				name =getKeyboard ("","הכנס שם באנגלית לקובץ הגיבוי")#line:1881
				if not name :return False #line:1882
				name =urllib .quote_plus (name )#line:1883
			name ='%s_addondata.zip'%name ;O0OOOOO0O0O0O0O0O =''#line:1884
			OOO0000O0O0O0000O =os .path .join (OO00OOO00O0000O00 ,name )#line:1885
			try :#line:1886
				OOO0OOO0O000OO00O =zipfile .ZipFile (xbmc .translatePath (OOO0000O0O0O0000O ),mode ='w')#line:1887
			except :#line:1888
				try :#line:1889
					O0OOOOO0O0O0O0O0O =os .path .join (PACKAGES ,'%s.zip'%name )#line:1890
					OOO0OOO0O000OO00O =zipfile .ZipFile (O0OOOOO0O0O0O0O0O ,mode ='w')#line:1891
				except :#line:1892
					log ("Unable to create %s_addondata.zip"%name ,xbmc .LOGERROR )#line:1893
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]אין באפשרותנו לכתוב לספריית הגיבוי הנוכחית, האם ברצונך לשנות את המיקום?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]אישור[/COLOR][/B]",nolabel ="[B][COLOR white]ביטול[/COLOR][/B]"):#line:1894
						openS ()#line:1895
						return #line:1896
					else :#line:1897
						return #line:1898
			OO0O0OOO000OOO00O =0 #line:1899
			OO0O0O0O0OOOO0OOO =[]#line:1900
			convertSpecial (ADDOND ,True )#line:1901
			asciiCheck (ADDOND ,True )#line:1902
			DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:1903
			for O0O0OO0O00O00000O ,O0000OOOO000O0O00 ,O00O0OO0O0OO0OOO0 in os .walk (ADDOND ):#line:1904
				O0000OOOO000O0O00 [:]=[O0O000OO0OO0000O0 for O0O000OO0OO0000O0 in O0000OOOO000O0O00 if O0O000OO0OO0000O0 not in OOOO0OO00O0O0OOOO ]#line:1905
				O00O0OO0O0OO0OOO0 [:]=[O00O0OOOOO0000OO0 for O00O0OOOOO0000OO0 in O00O0OO0O0OO0OOO0 if O00O0OOOOO0000OO0 not in OOOO0O0OOOO0O0O00 ]#line:1906
				for O0OOOOOO00000OOO0 in O00O0OO0O0OO0OOO0 :#line:1907
					OO0O0O0O0OOOO0OOO .append (O0OOOOOO00000OOO0 )#line:1908
			O0O0OO0OO00OOO0O0 =len (OO0O0O0O0OOOO0OOO )#line:1909
			for O0O0OO0O00O00000O ,O0000OOOO000O0O00 ,O00O0OO0O0OO0OOO0 in os .walk (ADDOND ):#line:1910
				O0000OOOO000O0O00 [:]=[OOO0O00OO00OOOOO0 for OOO0O00OO00OOOOO0 in O0000OOOO000O0O00 if OOO0O00OO00OOOOO0 not in OOOO0OO00O0O0OOOO ]#line:1911
				O00O0OO0O0OO0OOO0 [:]=[O00O000000O0OOOOO for O00O000000O0OOOOO in O00O0OO0O0OO0OOO0 if O00O000000O0OOOOO not in OOOO0O0OOOO0O0O00 ]#line:1912
				for O0OOOOOO00000OOO0 in O00O0OO0O0OO0OOO0 :#line:1913
					try :#line:1914
						OO0O0OOO000OOO00O +=1 #line:1915
						O00O0O00OO000OO00 =percentage (OO0O0OOO000OOO00O ,O0O0OO0OO00OOO0O0 )#line:1916
						DP .update (int (O00O0O00OO000OO00 ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OOO000OOO00O ,COLOR1 ,O0O0OO0OO00OOO0O0 ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOOOO00000OOO0 ),'')#line:1917
						O0O0OO00OO0OOOOOO =os .path .join (O0O0OO0O00O00000O ,O0OOOOOO00000OOO0 )#line:1918
						if O0OOOOOO00000OOO0 in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE );continue #line:1919
						elif os .path .join (O0O0OO0O00O00000O ,O0OOOOOO00000OOO0 )in OO0O00OOOO000O000 :log ("[Back Up] Type = '%s': Ignore %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE );continue #line:1920
						elif os .path .join ('addons','packages')in O0O0OO00OO0OOOOOO :log ("[Back Up] Type = '%s': Ignore %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE );continue #line:1921
						elif O0OOOOOO00000OOO0 .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE );continue #line:1922
						elif O0OOOOOO00000OOO0 .endswith ('.db')and 'Database'in O0O0OO0O00O00000O :#line:1923
							O00000000OO000O0O =O0OOOOOO00000OOO0 .replace ('.db','')#line:1924
							O00000000OO000O0O =''.join ([OOOO0OOOOO00OOO00 for OOOO0OOOOO00OOO00 in O00000000OO000O0O if not OOOO0OOOOO00OOO00 .isdigit ()])#line:1925
							if O00000000OO000O0O in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:1926
								if not O0OOOOOO00000OOO0 ==latestDB (O00000000OO000O0O ):log ("[Back Up] Type = '%s': Ignore %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE );continue #line:1927
						try :#line:1928
							OOO0OOO0O000OO00O .write (O0O0OO00OO0OOOOOO ,O0O0OO00OO0OOOOOO [len (ADDOND ):],zipfile .ZIP_DEFLATED )#line:1929
						except Exception as OO0O000OO00OOOOOO :#line:1930
							log ("[Back Up] Type = '%s': Unable to backup %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE )#line:1931
							log ("Backup Error: %s"%str (OO0O000OO00OOOOOO ),xbmc .LOGNOTICE )#line:1932
					except Exception as OO0O000OO00OOOOOO :#line:1933
						log ("[Back Up] Type = '%s': Unable to backup %s"%(O0OOO0000O00OOOO0 ,O0OOOOOO00000OOO0 ),xbmc .LOGNOTICE )#line:1934
						log ("Backup Error: %s"%str (OO0O000OO00OOOOOO ),xbmc .LOGNOTICE )#line:1935
			OOO0OOO0O000OO00O .close ()#line:1936
			if not O0OOOOO0O0O0O0O0O =='':#line:1937
				O0O000OO0OOO00OOO =xbmcvfs .rename (O0OOOOO0O0O0O0O0O ,OOO0000O0O0O0000O )#line:1938
				if O0O000OO0OOO00OOO ==0 :#line:1939
					xbmcvfs .copy (O0OOOOO0O0O0O0O0O ,OOO0000O0O0O0000O )#line:1940
					xbmcvfs .delete (O0OOOOO0O0O0O0O0O )#line:1941
			DP .close ()#line:1942
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]הגיבוי בוצע בהצלחה![/COLOR]"%(COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0000O0O0O0000O ))#line:1943
def restoreLocal (OO00OO0O0O00O000O ):#line:1945
	OOOOOO0O00O000O0O =xbmc .translatePath (BACKUPLOCATION )#line:1946
	O00000OO0000O0O00 =xbmc .translatePath (MYBUILDS )#line:1947
	try :#line:1948
		if not os .path .exists (OOOOOO0O00O000O0O ):xbmcvfs .mkdirs (OOOOOO0O00O000O0O )#line:1949
		if not os .path .exists (O00000OO0000O0O00 ):xbmcvfs .mkdirs (O00000OO0000O0O00 )#line:1950
	except Exception as O0OOOOOOO0OO0O000 :#line:1951
		DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (O0OOOOOOO0OO0O000 )))#line:1952
		return #line:1953
	O000O0O00OO0O0O00 =DIALOG .browse (1 ,'[COLOR %s]בחר את הקובץ שתרצה לשחזר[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:1954
	log ("[RESTORE BACKUP %s] File: %s "%(OO00OO0O0O00O000O .upper (),O000O0O00OO0O0O00 ),xbmc .LOGNOTICE )#line:1955
	if O000O0O00OO0O0O00 ==""or not O000O0O00OO0O0O00 .endswith ('.zip'):#line:1956
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore: Cancelled[/COLOR]"%COLOR2 )#line:1957
		return #line:1958
	DP .create (ADDONTITLE ,'[COLOR %s]Installing Local Backup'%COLOR2 ,'','Please Wait[/COLOR]')#line:1959
	if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:1960
	if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:1961
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1962
	if OO00OO0O0O00O000O =="gui":OO000000O0OO0O00O =USERDATA #line:1963
	elif OO00OO0O0O00O000O =="addondata":#line:1964
		OO000000O0OO0O00O =ADDOND #line:1965
	else :OO000000O0OO0O00O =HOME #line:1966
	log ("Restoring to %s"%OO000000O0OO0O00O ,xbmc .LOGNOTICE )#line:1967
	O00OO000OOOOO000O =os .path .split (O000O0O00OO0O0O00 )#line:1968
	OOOO0O00O0000OOO0 =O00OO000OOOOO000O [1 ]#line:1969
	try :#line:1970
		zipfile .ZipFile (O000O0O00OO0O0O00 ,'r')#line:1971
	except :#line:1972
		DP .update (0 ,'[COLOR %s]Unable to read zipfile from current location.'%COLOR2 ,'Copying file to packages')#line:1973
		OO00O0O00O000O00O =os .path .join ('special://home','addons','packages',OOOO0O00O0000OOO0 )#line:1974
		xbmcvfs .copy (O000O0O00OO0O0O00 ,OO00O0O00O000O00O )#line:1975
		O000O0O00OO0O0O00 =xbmc .translatePath (OO00O0O00O000O00O )#line:1976
		DP .update (0 ,'','Copying file to packages: Complete')#line:1977
		zipfile .ZipFile (O000O0O00OO0O0O00 ,'r')#line:1978
	OO00O0O0000O00OOO ,OO0O0OOO00OO00OO0 ,OO0O000O00OO00000 =extract .all (O000O0O00OO0O0O00 ,OO000000O0OO0O00O ,DP )#line:1979
	fixmetas ()#line:1980
	clearS ('build')#line:1981
	DP .close ()#line:1982
	defaultSkin ()#line:1983
	lookandFeelData ('save')#line:1984
	if not O000O0O00OO0O0O00 .find ('packages')==-1 :#line:1985
		try :os .remove (O000O0O00OO0O0O00 )#line:1986
		except :pass #line:1987
	if int (OO0O0OOO00OO00OO0 )>=1 :#line:1988
		OO0OOO0O00O0O00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O00O0000OOO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00O0O0000O00OOO ,'%',COLOR1 ,OO0O0OOO00OO00OO0 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:1989
		if OO0OOO0O00O0O00O0 :#line:1990
			if isinstance (OO0O0OOO00OO00OO0 ,unicode ):#line:1991
				OO0O000O00OO00000 =OO0O000O00OO00000 .encode ('utf-8')#line:1992
			TextBox (ADDONTITLE ,OO0O000O00OO00000 .replace ('\t',''))#line:1993
	setS ('installed','true')#line:1994
	setS ('extract',str (OO00O0O0000O00OOO ))#line:1995
	setS ('errors',str (OO0O0OOO00OO00OO0 ))#line:1996
	if INSTALLMETHOD ==1 :O00OOOOOO0OOOO0O0 =1 #line:1997
	elif INSTALLMETHOD ==2 :O00OOOOOO0OOOO0O0 =0 #line:1998
	else :DIALOG .ok (ADDONTITLE ,"[COLOR %s]השחזור בוצע בהצלחה![/COLOR]"%COLOR2 );killxbmc ('true')#line:1999
	if O00OOOOOO0OOOO0O0 ==1 :reloadFix ()#line:2000
	else :killxbmc (True )#line:2001
def restoreExternal (OOO0OO0O00O0O000O ):#line:2003
	O0OO00O000O0O0O0O =DIALOG .browse (1 ,'[COLOR %s]Select the backup file you want to restore[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2004
	if O0OO00O000O0O0O0O ==""or not O0OO00O000O0O0O0O .endswith ('.zip'):#line:2005
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Cancelled[/COLOR]"%COLOR2 )#line:2006
		return #line:2007
	if not O0OO00O000O0O0O0O .startswith ('http'):#line:2008
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Invalid URL[/COLOR]"%COLOR2 )#line:2009
		return #line:2010
	try :#line:2011
		OO0OO0000000O0O0O =workingURL (O0OO00O000O0O0O0O )#line:2012
	except :#line:2013
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Error Valid URL[/COLOR]"%COLOR2 )#line:2014
		log ("Not a working url, if source was local then use local restore option",xbmc .LOGNOTICE )#line:2015
		log ("External Source: %s"%O0OO00O000O0O0O0O ,xbmc .LOGNOTICE )#line:2016
		return #line:2017
	log ("[RESTORE EXT BACKUP %s] File: %s "%(OOO0OO0O00O0O000O .upper (),O0OO00O000O0O0O0O ),xbmc .LOGNOTICE )#line:2018
	OO0OO0O0OO00O0O00 =os .path .split (O0OO00O000O0O0O0O );O00OO00O0000O0O00 =OO0OO0O0OO00O0O00 [1 ]#line:2019
	DP .create (ADDONTITLE ,'[COLOR %s]Downloading Zip file'%COLOR2 ,'','Please Wait[/COLOR]')#line:2020
	if OOO0OO0O00O0O000O =="gui":OOOOO0000O0O000O0 =USERDATA #line:2021
	elif OOO0OO0O00O0O000O =="addondata":OOOOO0000O0O000O0 =ADDOND #line:2022
	else :OOOOO0000O0O000O0 =HOME #line:2023
	if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:2024
	if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:2025
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2026
	OO0OO00O00O0O0OO0 =os .path .join (PACKAGES ,O00OO00O0000O0O00 )#line:2027
	downloader .download (O0OO00O000O0O0O0O ,OO0OO00O00O0O0OO0 ,DP )#line:2028
	DP .update (0 ,'Installing External Backup','','Please Wait')#line:2029
	OO000OOO00O0OOO0O ,OOO0O000OOO0000O0 ,O0O00O00O0OO00OOO =extract .all (OO0OO00O00O0O0OO0 ,OOOOO0000O0O000O0 ,DP )#line:2030
	fixmetas ()#line:2031
	clearS ('build')#line:2032
	DP .close ()#line:2033
	defaultSkin ()#line:2034
	lookandFeelData ('save')#line:2035
	if int (OOO0O000OOO0000O0 )>=1 :#line:2036
		OO00O0O00OO00O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO00O0000O0O00 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO000OOO00O0OOO0O ,'%',COLOR1 ,OOO0O000OOO0000O0 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2037
		if OO00O0O00OO00O000 :#line:2038
			TextBox (ADDONTITLE ,O0O00O00O0OO00OOO .replace ('\t',''))#line:2039
	setS ('installed','true')#line:2040
	setS ('extract',str (OO000OOO00O0OOO0O ))#line:2041
	setS ('errors',str (OOO0O000OOO0000O0 ))#line:2042
	try :os .remove (OO0OO00O00O0O0OO0 )#line:2043
	except :pass #line:2044
	if INSTALLMETHOD ==1 :O00OOOO0O00O00OOO =1 #line:2045
	elif INSTALLMETHOD ==2 :O00OOOO0O00O00OOO =0 #line:2046
	else :O00OOOO0O00O00OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR green]Force Close[/COLOR][/B]")#line:2047
	if O00OOOO0O00O00OOO ==1 :reloadFix ()#line:2048
	else :killxbmc (True )#line:2049
def platform ():#line:2055
	if xbmc .getCondVisibility ('system.platform.android'):return 'android'#line:2056
	elif xbmc .getCondVisibility ('system.platform.linux'):return 'linux'#line:2057
	elif xbmc .getCondVisibility ('system.platform.linux.Raspberrypi'):return 'linux'#line:2058
	elif xbmc .getCondVisibility ('system.platform.windows'):return 'windows'#line:2059
	elif xbmc .getCondVisibility ('system.platform.osx'):return 'osx'#line:2060
	elif xbmc .getCondVisibility ('system.platform.atv2'):return 'atv2'#line:2061
	elif xbmc .getCondVisibility ('system.platform.ios'):return 'ios'#line:2062
	elif xbmc .getCondVisibility ('system.platform.darwin'):return 'ios'#line:2063
def Grab_Log (file =False ,old =False ,wizard =False ):#line:2065
	if wizard ==True :#line:2066
		if not os .path .exists (WIZLOG ):return False #line:2067
		else :#line:2068
			if file ==True :#line:2069
				return WIZLOG #line:2070
			else :#line:2071
				O0OO0OOO0000OOO00 =open (WIZLOG ,'r')#line:2072
				OOO0O0O0OO0O0O000 =O0OO0OOO0000OOO00 .read ()#line:2073
				O0OO0OOO0000OOO00 .close ()#line:2074
				return OOO0O0O0OO0O0O000 #line:2075
	OOO0O0OOOO0OO00OO =0 #line:2076
	OO0OOO000O0O00OO0 =os .listdir (LOG )#line:2077
	OOO00OO000OO0OOOO =[]#line:2078
	for O0OO000O000O0O0OO in OO0OOO000O0O00OO0 :#line:2080
		if old ==True and O0OO000O000O0O0OO .endswith ('.old.log'):OOO00OO000OO0OOOO .append (os .path .join (LOG ,O0OO000O000O0O0OO ))#line:2081
		elif old ==False and O0OO000O000O0O0OO .endswith ('.log')and not O0OO000O000O0O0OO .endswith ('.old.log'):OOO00OO000OO0OOOO .append (os .path .join (LOG ,O0OO000O000O0O0OO ))#line:2082
	if len (OOO00OO000OO0OOOO )>0 :#line:2084
		OOO00OO000OO0OOOO .sort (key =lambda O0000O0O0O0O0O000 :os .path .getmtime (O0000O0O0O0O0O000 ))#line:2085
		if file ==True :return OOO00OO000OO0OOOO [-1 ]#line:2086
		else :#line:2087
			O0OO0OOO0000OOO00 =open (OOO00OO000OO0OOOO [-1 ],'r')#line:2088
			OOO0O0O0OO0O0O000 =O0OO0OOO0000OOO00 .read ()#line:2089
			O0OO0OOO0000OOO00 .close ()#line:2090
			return OOO0O0O0OO0O0O000 #line:2091
	else :#line:2092
		return False #line:2093
def whiteList (O00O0OOO0OO00OOO0 ):#line:2095
	O00OO0OO00OO00OO0 =xbmc .translatePath (BACKUPLOCATION )#line:2096
	OO00OOO0O000000OO =xbmc .translatePath (MYBUILDS )#line:2097
	if O00O0OOO0OO00OOO0 =='edit':#line:2098
		O000OOOOO00O0O00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2099
		O0OOOO0O00000O000 =[];OOO0O0000O0OOOO0O =[];OO00000OOO0O0OO0O =[]#line:2100
		for OO0O0O0O0OOO000OO in sorted (O000OOOOO00O0O00O ,key =lambda O0OO00OOO00OO0OOO :O0OO00OOO00OO0OOO ):#line:2101
			O00OOOOOO00OO000O =os .path .split (OO0O0O0O0OOO000OO [:-1 ])[1 ]#line:2102
			if O00OOOOOO00OO000O in EXCLUDES :continue #line:2103
			elif O00OOOOOO00OO000O in DEFAULTPLUGINS :continue #line:2104
			elif O00OOOOOO00OO000O =='packages':continue #line:2105
			O00OO000O0OOO0OO0 =os .path .join (OO0O0O0O0OOO000OO ,'addon.xml')#line:2106
			if os .path .exists (O00OO000O0OOO0OO0 ):#line:2107
				O00OO0OOOOO0OO0O0 =open (O00OO000O0OOO0OO0 )#line:2108
				OOOOOO000O0OOO0O0 =O00OO0OOOOO0OO0O0 .read ()#line:2109
				O00OO0OOOOO0OO0O0 .close ()#line:2110
				O0O0O0000OOOO0O00 =parseDOM (OOOOOO000O0OOO0O0 ,'addon',ret ='id')#line:2111
				O0O00000OO00O0OO0 =parseDOM (OOOOOO000O0OOO0O0 ,'addon',ret ='name')#line:2112
				O0OOOOO0O0OO0O000 =O00OOOOOO00OO000O if len (O0O0O0000OOOO0O00 )==0 else O0O0O0000OOOO0O00 [0 ]#line:2113
				OO0OOOO00O0OO0O00 =O00OOOOOO00OO000O if len (O0O00000OO00O0OO0 )==0 else O0O00000OO00O0OO0 [0 ]#line:2114
				OO0OO0O00O00OO0O0 =OO0OOOO00O0OO0O00 .replace ('[','<').replace (']','>')#line:2115
				OO0OO0O00O00OO0O0 =re .sub ('<[^<]+?>','',OO0OO0O00O00OO0O0 )#line:2116
				O0OOOO0O00000O000 .append (OO0OO0O00O00OO0O0 )#line:2117
				OOO0O0000O0OOOO0O .append (O0OOOOO0O0OO0O000 )#line:2118
				OO00000OOO0O0OO0O .append (O00OOOOOO00OO000O )#line:2119
		OOOOOOOOO0000000O =glob .glob (os .path .join (ADDOND ,'*/'))#line:2120
		for OO0O0O0O0OOO000OO in sorted (OOOOOOOOO0000000O ,key =lambda O00OO0O00OO000O00 :O00OO0O00OO000O00 ):#line:2121
			O00OOOOOO00OO000O =os .path .split (OO0O0O0O0OOO000OO [:-1 ])[1 ]#line:2122
			if O00OOOOOO00OO000O in OO00000OOO0O0OO0O :continue #line:2123
			if O00OOOOOO00OO000O in EXCLUDES :continue #line:2124
			O00OO000O0OOO0OO0 =os .path .join (ADDONS ,O00OOOOOO00OO000O ,'addon.xml')#line:2125
			OO0O0OOOO00OO00OO =os .path .join (XBMC ,'addons',O00OOOOOO00OO000O ,'addon.xml')#line:2126
			if os .path .exists (O00OO000O0OOO0OO0 ):#line:2127
				O00OO0OOOOO0OO0O0 =open (O00OO000O0OOO0OO0 )#line:2128
			elif os .path .exists (OO0O0OOOO00OO00OO ):#line:2129
				O00OO0OOOOO0OO0O0 =open (OO0O0OOOO00OO00OO )#line:2130
			else :continue #line:2131
			OOOOOO000O0OOO0O0 =O00OO0OOOOO0OO0O0 .read ()#line:2132
			O00OO0OOOOO0OO0O0 .close ()#line:2133
			O0O0O0000OOOO0O00 =parseDOM (OOOOOO000O0OOO0O0 ,'addon',ret ='id')#line:2134
			O0O00000OO00O0OO0 =parseDOM (OOOOOO000O0OOO0O0 ,'addon',ret ='name')#line:2135
			O0OOOOO0O0OO0O000 =O00OOOOOO00OO000O if len (O0O0O0000OOOO0O00 )==0 else O0O0O0000OOOO0O00 [0 ]#line:2136
			OO0OOOO00O0OO0O00 =O00OOOOOO00OO000O if len (O0O00000OO00O0OO0 )==0 else O0O00000OO00O0OO0 [0 ]#line:2137
			OO0OO0O00O00OO0O0 =OO0OOOO00O0OO0O00 .replace ('[','<').replace (']','>')#line:2138
			OO0OO0O00O00OO0O0 =re .sub ('<[^<]+?>','',OO0OO0O00O00OO0O0 )#line:2139
			O0OOOO0O00000O000 .append (OO0OO0O00O00OO0O0 )#line:2140
			OOO0O0000O0OOOO0O .append (O0OOOOO0O0OO0O000 )#line:2141
			OO00000OOO0O0OO0O .append (O00OOOOOO00OO000O )#line:2142
		OOO0O00OOOO0OOO0O =[];O00O0O00O0O000OO0 =0 #line:2143
		O000O00O0OOOOO000 =["-- לחץ כאן להמשך --"]+O0OOOO0O00000O000 #line:2144
		O0OO00O0O0O0OO00O =whiteList ('read')#line:2145
		for O0OOOO0000OOOOO0O in O0OO00O0O0O0OO00O :#line:2146
			log (str (O0OOOO0000OOOOO0O ),xbmc .LOGDEBUG )#line:2147
			try :O0000OO0OO0O0000O ,O0000000O0OOO0000 ,O000OOOOO00O0O00O =O0OOOO0000OOOOO0O #line:2148
			except Exception as O00000O0OO0O00OO0 :log (str (O00000O0OO0O00OO0 ))#line:2149
			if O0000000O0OOO0000 in OOO0O0000O0OOOO0O :#line:2150
				O00OOOO000O0000OO =OOO0O0000O0OOOO0O .index (O0000000O0OOO0000 )+1 #line:2151
				OOO0O00OOOO0OOO0O .append (O00OOOO000O0000OO -1 )#line:2152
				O000O00O0OOOOO000 [O00OOOO000O0000OO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0000OO0OO0O0000O )#line:2153
			else :#line:2154
				OOO0O0000O0OOOO0O .append (O0000000O0OOO0000 )#line:2155
				O0OOOO0O00000O000 .append (O0000OO0OO0O0000O )#line:2156
				O000O00O0OOOOO000 .append ("[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0000OO0OO0O0000O ))#line:2157
		O00O0O00O0O000OO0 =1 #line:2158
		while not O00O0O00O0O000OO0 in [-1 ,0 ]:#line:2159
			O00O0O00O0O000OO0 =DIALOG .select ("%s: בחר הרחבות לשמירה ."%ADDONTITLE ,O000O00O0OOOOO000 )#line:2160
			if O00O0O00O0O000OO0 ==-1 :break #line:2161
			elif O00O0O00O0O000OO0 ==0 :break #line:2162
			else :#line:2163
				OOOO0O000OO0O000O =(O00O0O00O0O000OO0 -1 )#line:2164
				if OOOO0O000OO0O000O in OOO0O00OOOO0OOO0O :#line:2165
					OOO0O00OOOO0OOO0O .remove (OOOO0O000OO0O000O )#line:2166
					O000O00O0OOOOO000 [O00O0O00O0O000OO0 ]=O0OOOO0O00000O000 [OOOO0O000OO0O000O ]#line:2167
				else :#line:2168
					OOO0O00OOOO0OOO0O .append (OOOO0O000OO0O000O )#line:2169
					O000O00O0OOOOO000 [O00O0O00O0O000OO0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OOOO0O00000O000 [OOOO0O000OO0O000O ])#line:2170
		OOO0OO0OO0OOOOO0O =[]#line:2171
		if len (OOO0O00OOOO0OOO0O )>0 :#line:2172
			for O00O0OO000OO00000 in OOO0O00OOOO0OOO0O :#line:2173
				OOO0OO0OO0OOOOO0O .append ("['%s', '%s', '%s']"%(O0OOOO0O00000O000 [O00O0OO000OO00000 ],OOO0O0000O0OOOO0O [O00O0OO000OO00000 ],OO00000OOO0O0OO0O [O00O0OO000OO00000 ]))#line:2174
			OOO0O00O0OO000OOO ='\n'.join (OOO0OO0OO0OOOOO0O )#line:2175
			O00OO0OOOOO0OO0O0 =open (WHITELIST ,'w');O00OO0OOOOO0OO0O0 .write (OOO0O00O0OO000OOO );O00OO0OOOOO0OO0O0 .close ()#line:2176
		else :#line:2177
			try :os .remove (WHITELIST )#line:2178
			except :pass #line:2179
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Addons in White List[/COLOR]"%(COLOR2 ,len (OOO0O00OOOO0OOO0O )))#line:2180
	elif O00O0OOO0OO00OOO0 =='read':#line:2181
		OOO0O000O000OO000 =[]#line:2182
		if os .path .exists (WHITELIST ):#line:2183
			O00OO0OOOOO0OO0O0 =open (WHITELIST )#line:2184
			OOOOOO000O0OOO0O0 =O00OO0OOOOO0OO0O0 .read ()#line:2185
			O00OO0OOOOO0OO0O0 .close ()#line:2186
			O00O0O00OOO00OO0O =OOOOOO000O0OOO0O0 .split ('\n')#line:2187
			for O0OOOO0000OOOOO0O in O00O0O00OOO00OO0O :#line:2188
				try :#line:2189
					O0000OO0OO0O0000O ,O0000000O0OOO0000 ,O000OOOOO00O0O00O =eval (O0OOOO0000OOOOO0O )#line:2190
					OOO0O000O000OO000 .append (eval (O0OOOO0000OOOOO0O ))#line:2191
				except :#line:2192
					pass #line:2193
		return OOO0O000O000OO000 #line:2194
	elif O00O0OOO0OO00OOO0 =='view':#line:2195
		OOOO00O000OO0000O =whiteList ('read')#line:2196
		if len (OOOO00O000OO0000O )>0 :#line:2197
			OO00000O0OO0OOOO0 ="רשימת הרחבות שסימנתם שלא ימחקו בהתקנה נקיה או רגילה.[CR][CR]"#line:2198
			for O0OOOO0000OOOOO0O in OOOO00O000OO0000O :#line:2199
				try :O0000OO0OO0O0000O ,O0000000O0OOO0000 ,O000OOOOO00O0O00O =O0OOOO0000OOOOO0O #line:2200
				except Exception as O00000O0OO0O00OO0 :log (str (O00000O0OO0O00OO0 ))#line:2201
				OO00000O0OO0OOOO0 +="[COLOR %s]%s[/COLOR] [COLOR %s]\"%s\"[/COLOR][CR]"%(COLOR1 ,O0000OO0OO0O0000O ,COLOR2 ,O0000000O0OOO0000 )#line:2202
			TextBox ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),OO00000O0OO0OOOO0 )#line:2203
		else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No items in White List[/COLOR]"%COLOR2 )#line:2204
	elif O00O0OOO0OO00OOO0 =='import':#line:2205
		OO0OOO0O0000OOO00 =DIALOG .browse (1 ,'[COLOR %s]Select the whitelist file to import[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:2206
		log (str (OO0OOO0O0000OOO00 ))#line:2207
		if not OO0OOO0O0000OOO00 .endswith ('.txt'):#line:2208
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Cancelled![/COLOR]"%COLOR2 )#line:2209
			return #line:2210
		O00OO0OOOOO0OO0O0 =xbmcvfs .File (OO0OOO0O0000OOO00 )#line:2211
		OOOOOO000O0OOO0O0 =O00OO0OOOOO0OO0O0 .read ()#line:2212
		O00OO0OOOOO0OO0O0 .close ()#line:2213
		O00O0O0O0000OO0OO =whiteList ('read');O00O00000OO000OOO =[];O0O00O00O0OOO0OO0 =0 #line:2214
		for O0OOOO0000OOOOO0O in O00O0O0O0000OO0OO :#line:2215
			O0000OO0OO0O0000O ,O0000000O0OOO0000 ,O000OOOOO00O0O00O =O0OOOO0000OOOOO0O #line:2216
			O00O00000OO000OOO .append (O0000000O0OOO0000 )#line:2217
		O00O0O00OOO00OO0O =OOOOOO000O0OOO0O0 .split ('\n')#line:2218
		with open (WHITELIST ,'a')as O00OO0OOOOO0OO0O0 :#line:2219
			for O0OOOO0000OOOOO0O in O00O0O00OOO00OO0O :#line:2220
				try :#line:2221
					O0000OO0OO0O0000O ,O0000000O0OOO0000 ,OO0O0O0O0OOO000OO =eval (O0OOOO0000OOOOO0O )#line:2222
				except Exception as O00000O0OO0O00OO0 :#line:2223
					log ("Error Adding: '%s' / %s"%(O0OOOO0000OOOOO0O ,str (O00000O0OO0O00OO0 )),xbmc .LOGERROR )#line:2224
					continue #line:2225
				log ("%s / %s / %s"%(O0000OO0OO0O0000O ,O0000000O0OOO0000 ,OO0O0O0O0OOO000OO ),xbmc .LOGDEBUG )#line:2226
				if not O0000000O0OOO0000 in O00O00000OO000OOO :#line:2227
					O0O00O00O0OOO0OO0 +=1 #line:2228
					OOO0O00O0OO000OOO ="['%s', '%s', '%s']"%(O0000OO0OO0O0000O ,O0000000O0OOO0000 ,OO0O0O0O0OOO000OO )#line:2229
					if len (O00O00000OO000OOO )+O0O00O00O0OOO0OO0 >1 :OOO0O00O0OO000OOO ="\n%s"%OOO0O00O0OO000OOO #line:2230
					O00OO0OOOOO0OO0O0 .write (OOO0O00O0OO000OOO )#line:2231
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Item(s) Added[/COLOR]"%(COLOR2 ,O0O00O00O0OOO0OO0 ))#line:2232
	elif O00O0OOO0OO00OOO0 =='export':#line:2233
		OO0OOO0O0000OOO00 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the whitelist file[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:2234
		log (str (OO0OOO0O0000OOO00 ),xbmc .LOGDEBUG )#line:2235
		try :#line:2236
			xbmcvfs .copy (WHITELIST ,os .path .join (OO0OOO0O0000OOO00 ,'whitelist.txt'))#line:2237
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Whitelist has been exported to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO0OOO0O0000OOO00 ,'whitelist.txt')))#line:2238
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Exported[/COLOR]"%(COLOR2 ))#line:2239
		except Exception as O00000O0OO0O00OO0 :#line:2240
			log ("Export Error: %s"%str (O00000O0OO0O00OO0 ),xbmc .LOGERROR )#line:2241
			if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The location you selected isnt writable would you like to select another one?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Location[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:2242
				LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Export Cancelled[/COLOR]"%(COLOR2 ,O00000O0OO0O00OO0 ))#line:2243
			else :#line:2244
				OOO0OO0OO0OOOOO0O (export )#line:2245
	elif O00O0OOO0OO00OOO0 =='clear':#line:2246
		if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Are you sure you want to clear your whitelist?"%COLOR2 ,"This process can't be undone.[/COLOR]",yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:2247
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clear Whitelist Cancelled[/COLOR]"%(COLOR2 ))#line:2248
			return #line:2249
		try :#line:2250
			os .remove (WHITELIST )#line:2251
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Cleared[/COLOR]"%(COLOR2 ))#line:2252
		except :#line:2253
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Clearing Whitelist![/COLOR]"%(COLOR2 ))#line:2254
def clearPackages (over =None ):#line:2256
	if os .path .exists (PACKAGES ):#line:2257
		try :#line:2258
			for O00O0OO0OOO0OO00O ,OOOO0O0O0000O00OO ,OO0OO00O0OO0OOO00 in os .walk (PACKAGES ):#line:2259
				O0OOOO0O0OO00OOO0 =0 #line:2260
				O0OOOO0O0OO00OOO0 +=len (OO0OO00O0OO0OOO00 )#line:2261
				if O0OOOO0O0OO00OOO0 >0 :#line:2262
					O0O0O00OOO00O00OO =convertSize (getSize (PACKAGES ))#line:2263
					if over :OOOO0O0OO00OOOO00 =1 #line:2264
					else :OOOO0O0OO00OOOO00 =1 #line:2265
					if OOOO0O0OO00OOOO00 :#line:2266
						for O000O000O0O0000OO in OO0OO00O0OO0OOO00 :os .unlink (os .path .join (O00O0OO0OOO0OO00O ,O000O000O0O0000OO ))#line:2267
						for OOO000O00O0O00000 in OOOO0O0O0000O00OO :shutil .rmtree (os .path .join (O00O0OO0OOO0OO00O ,OOO000O00O0O00000 ))#line:2268
						LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success![/COLOR]'%COLOR2 )#line:2269
				else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2270
		except Exception as OO0OOOOOOO0OOOO0O :#line:2271
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:2272
			log ("Clear Packages Error: %s"%str (OO0OOOOOOO0OOOO0O ),xbmc .LOGERROR )#line:2273
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2274
def clearPackagesStartup ():#line:2276
	O0OO0OO000O000OO0 =datetime .utcnow ()-timedelta (minutes =3 )#line:2277
	OO0OO0O00O0O0OOOO =0 ;OOO000OO000O0O00O =0 #line:2278
	if os .path .exists (PACKAGES ):#line:2279
		OOOO0OOOO00OOO0OO =os .listdir (PACKAGES )#line:2280
		OOOO0OOOO00OOO0OO .sort (key =lambda OOOOO0OOO0O0OOOO0 :os .path .getmtime (os .path .join (PACKAGES ,OOOOO0OOO0O0OOOO0 )))#line:2281
		try :#line:2282
			for O0OO00OOO00OOOOOO in OOOO0OOOO00OOO0OO :#line:2283
				O0O0O0O000O00000O =os .path .join (PACKAGES ,O0OO00OOO00OOOOOO )#line:2284
				OOO0O0000O00000O0 =datetime .utcfromtimestamp (os .path .getmtime (O0O0O0O000O00000O ))#line:2285
				if OOO0O0000O00000O0 <=O0OO0OO000O000OO0 :#line:2286
					if os .path .isfile (O0O0O0O000O00000O ):#line:2287
						OO0OO0O00O0O0OOOO +=1 #line:2288
						OOO000OO000O0O00O +=os .path .getsize (O0O0O0O000O00000O )#line:2289
						os .unlink (O0O0O0O000O00000O )#line:2290
					elif os .path .isdir (O0O0O0O000O00000O ):#line:2291
						OOO000OO000O0O00O +=getSize (O0O0O0O000O00000O )#line:2292
						O0000OO0OOOO000O0 ,OOO00OO0O0000000O =cleanHouse (O0O0O0O000O00000O )#line:2293
						OO0OO0O00O0O0OOOO +=O0000OO0OOOO000O0 +OOO00OO0O0000000O #line:2294
						try :#line:2295
							shutil .rmtree (O0O0O0O000O00000O )#line:2296
						except Exception as O000OO00O0OOOO000 :#line:2297
							log ("Failed to remove %s: %s"%(O0O0O0O000O00000O ,str (O000OO00O0OOOO000 ),xbmc .LOGERROR ))#line:2298
			if OO0OO0O00O0O0OOOO >0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success: %s[/COLOR]'%(COLOR2 ,convertSize (OOO000OO000O0O00O )))#line:2299
			else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2300
		except Exception as O000OO00O0OOOO000 :#line:2301
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:2302
			log ("Clear Packages Error: %s"%str (O000OO00O0OOOO000 ),xbmc .LOGERROR )#line:2303
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2304
def clearCache (over =None ):#line:2306
	OO0O00OOO000000O0 =os .path .join (PROFILE ,'addon_data')#line:2319
	O0OOO000OO0OOO000 =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:2328
	OO00OO00O0O0000OO =[(OO0O00OOO000000O0 ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),os .path .join (xbmc .translatePath ('special://profile/addon_data/plugin.program.autocompletion/Google'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.skin.helper.colorpicker/colors'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/service.subtitles.All_Subs/aa_buff'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/service.subtitles.All_Subs/temp_wizdom'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/service.subtitles.All_Subs/temp'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.colorbox'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.module.metadatautils/animatedgifs'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/ArtistInformation'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/ArtistSlideshow'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/merge'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/temp'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/transition'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/resources'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/plugin.video.movixws/logos'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/service.subtitles.subscenter/temp'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/plugin.video.idanplus/epg.json'),''),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONS ,'temp')),(os .path .join (OO0O00OOO000000O0 ,'script.module.simple.downloader')),(os .path .join (OO0O00OOO000000O0 ,'plugin.video.itv','Images'))]#line:2357
	OO0O0O00OOO0000OO =0 #line:2358
	OO000O0OO0000O0O0 =['meta_cache','archive_cache']#line:2359
	for OO0OO0O0OO0O0OO00 in OO00OO00O0O0000OO :#line:2360
		if os .path .exists (OO0OO0O0OO0O0OO00 )and not OO0OO0O0OO0O0OO00 in [ADDONDATA ,OO0O00OOO000000O0 ]:#line:2361
			for O0OO0000000O0000O ,O00OO0O0O0OO000O0 ,OO0O0OOOOOOOOO000 in os .walk (OO0OO0O0OO0O0OO00 ):#line:2362
				O00OO0O0O0OO000O0 [:]=[OO00OOOOO0O000OOO for OO00OOOOO0O000OOO in O00OO0O0O0OO000O0 if OO00OOOOO0O000OOO not in OO000O0OO0000O0O0 ]#line:2363
				O000O0O0O0000O0OO =0 #line:2364
				O000O0O0O0000O0OO +=len (OO0O0OOOOOOOOO000 )#line:2365
				if O000O0O0O0000O0OO >0 :#line:2366
					for OO0O00OO000000OOO in OO0O0OOOOOOOOO000 :#line:2367
						if not OO0O00OO000000OOO in LOGFILES :#line:2368
							try :#line:2369
								os .unlink (os .path .join (O0OO0000000O0000O ,OO0O00OO000000OOO ))#line:2370
								log ("[Wiped] %s"%os .path .join (O0OO0000000O0000O ,OO0O00OO000000OOO ),xbmc .LOGNOTICE )#line:2371
								OO0O0O00OOO0000OO +=1 #line:2372
							except :#line:2373
								pass #line:2374
						else :log ('Ignore Log File: %s'%OO0O00OO000000OOO ,xbmc .LOGNOTICE )#line:2375
					for OO00O0O0000OO00OO in O00OO0O0O0OO000O0 :#line:2376
						try :#line:2377
							shutil .rmtree (os .path .join (O0OO0000000O0000O ,OO00O0O0000OO00OO ))#line:2378
							OO0O0O00OOO0000OO +=1 #line:2379
							log ("[Success] cleared %s files from %s"%(str (O000O0O0O0000O0OO ),os .path .join (OO0OO0O0OO0O0OO00 ,OO00O0O0000OO00OO )),xbmc .LOGNOTICE )#line:2380
						except :#line:2381
							log ("[Failed] to wipe cache in: %s"%os .path .join (OO0OO0O0OO0O0OO00 ,OO00O0O0000OO00OO ),xbmc .LOGNOTICE )#line:2382
	if os .path .exists (PACKAGES ):#line:2394
		try :#line:2395
			for O0OO0000000O0000O ,O00OO0O0O0OO000O0 ,OO0O0OOOOOOOOO000 in os .walk (PACKAGES ):#line:2396
				O000O0O0O0000O0OO =0 #line:2397
				O000O0O0O0000O0OO +=len (OO0O0OOOOOOOOO000 )#line:2398
				if O000O0O0O0000O0OO >0 :#line:2399
					OO000OO000O0OO0OO =convertSize (getSize (PACKAGES ))#line:2400
					if over :O0OO00O0O0O0000O0 =1 #line:2401
					else :O0OO00O0O0O0000O0 =1 #line:2402
					if O0OO00O0O0O0000O0 :#line:2403
						for OO0O00OO000000OOO in OO0O0OOOOOOOOO000 :os .unlink (os .path .join (O0OO0000000O0000O ,OO0O00OO000000OOO ))#line:2404
						for OO00O0O0000OO00OO in O00OO0O0O0OO000O0 :shutil .rmtree (os .path .join (O0OO0000000O0000O ,OO00O0O0000OO00OO ))#line:2405
						LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ניקוי קבצי התקנה: נמחקו![/COLOR]'%COLOR2 )#line:2406
		except Exception as OOO0OOO0O0O0O0OOO :#line:2408
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ניקוי קבצי התקנה: לא הצליח למחוק![/COLOR]'%COLOR2 )#line:2409
			log ("Clear Packages Error: %s"%str (OOO0OOO0O0O0O0OOO ),xbmc .LOGERROR )#line:2410
	if INCLUDEVIDEO =='true'and over ==None :#line:2412
		OO0O0OOOOOOOOO000 =[]#line:2413
		if INCLUDEALL =='true':OO0O0OOOOOOOOO000 =O0OOO000OO0OOO000 #line:2414
		else :#line:2415
			if INCLUDEBOB =='true':OO0O0OOOOOOOOO000 .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:2416
			if INCLUDEPHOENIX =='true':OO0O0OOOOOOOOO000 .append (os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db'))#line:2417
			if INCLUDESPECTO =='true':OO0O0OOOOOOOOO000 .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:2418
			if INCLUDEGENESIS =='true':OO0O0OOOOOOOOO000 .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:2419
			if INCLUDEEXODUS =='true':OO0O0OOOOOOOOO000 .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:2420
			if INCLUDEONECHAN =='true':OO0O0OOOOOOOOO000 .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:2421
			if INCLUDESALTS =='true':OO0O0OOOOOOOOO000 .append (os .path .join (DATABASE ,'saltscache.db'))#line:2422
			if INCLUDESALTSHD =='true':OO0O0OOOOOOOOO000 .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:2423
		if len (OO0O0OOOOOOOOO000 )>0 :#line:2424
			for OO0OO0O0OO0O0OO00 in OO0O0OOOOOOOOO000 :#line:2425
				if os .path .exists (OO0OO0O0OO0O0OO00 ):#line:2426
					OO0O0O00OOO0000OO +=1 #line:2427
					try :#line:2428
						O00OOOO0O0O0O0000 =database .connect (OO0OO0O0OO0O0OO00 )#line:2429
						O0000000O0O00O00O =O00OOOO0O0O0O0000 .cursor ()#line:2430
					except Exception as OOO0OOO0O0O0O0OOO :#line:2431
						log ("DB Connection error: %s"%str (OOO0OOO0O0O0O0OOO ),xbmc .LOGERROR )#line:2432
						continue #line:2433
					if 'Database'in OO0OO0O0OO0O0OO00 :#line:2434
						try :#line:2435
							O0000000O0O00O00O .execute ("DELETE FROM url_cache")#line:2436
							O0000000O0O00O00O .execute ("VACUUM")#line:2437
							O00OOOO0O0O0O0000 .commit ()#line:2438
							O0000000O0O00O00O .close ()#line:2439
							log ("[Success] wiped %s"%OO0OO0O0OO0O0OO00 ,xbmc .LOGNOTICE )#line:2440
						except Exception as OOO0OOO0O0O0O0OOO :#line:2441
							log ("[Failed] wiped %s: %s"%(OO0OO0O0OO0O0OO00 ,str (OOO0OOO0O0O0O0OOO )),xbmc .LOGNOTICE )#line:2442
					else :#line:2443
						O0000000O0O00O00O .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:2444
						for OO000O0O00O00000O in O0000000O0O00O00O .fetchall ():#line:2445
							try :#line:2446
								O0000000O0O00O00O .execute ("DELETE FROM %s"%OO000O0O00O00000O [0 ])#line:2447
								O0000000O0O00O00O .execute ("VACUUM")#line:2448
								O00OOOO0O0O0O0000 .commit ()#line:2449
								log ("[Success] wiped %s in %s"%(OO000O0O00O00000O ,OO0OO0O0OO0O0OO00 ),xbmc .LOGNOTICE )#line:2450
							except Exception as OOO0OOO0O0O0O0OOO :#line:2451
								log ("[Failed] wiped %s in %s: %s"%(OO000O0O00O00000O ,OO0OO0O0OO0O0OO00 ,str (OOO0OOO0O0O0O0OOO )),xbmc .LOGNOTICE )#line:2452
						O0000000O0O00O00O .close ()#line:2453
		else :log ("Clear Cache: Clear Video Cache Not Enabled",xbmc .LOGNOTICE )#line:2454
	LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ניקוי מטמון: נמחקו %s קבצים[/COLOR]'%(COLOR2 ,OO0O0O00OOO0000OO ))#line:2455
def clearCache3 ():#line:2457
    O0O0OOO0000OOOOOO =os .path .join (PROFILE ,'addon_data')#line:2458
    O00OO00OOO0O00O00 =[(O0O0OOO0000OOOOOO ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.bob.unleashed','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.covenant','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.elementum','app.db-wal')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db')),(os .path .join (O0O0OOO0000OOOOOO ,'script.module.simple.downloader')),(os .path .join (O0O0OOO0000OOOOOO ,'plugin.video.itv','Images'))]#line:2478
    O000OO0OOO0OO000O =0 #line:2480
    for O0O0OOOOO0O0OOO0O in O00OO00OOO0O00O00 :#line:2482
        if os .path .exists (O0O0OOOOO0O0OOO0O )and not O0O0OOOOO0O0OOO0O in [ADDONDATA ,O0O0OOO0000OOOOOO ]:#line:2483
            for O00O00O00OO000000 ,OOO00O0OO000OOOOO ,O00OO0O00O0OO0O0O in os .walk (O0O0OOOOO0O0OOO0O ):#line:2484
                O0O0OOO00OO00O0O0 =0 #line:2485
                O0O0OOO00OO00O0O0 +=len (O00OO0O00O0OO0O0O )#line:2486
                if O0O0OOO00OO00O0O0 >0 :#line:2487
                    for O0O0OO000O000000O in O00OO0O00O0OO0O0O :#line:2488
                        if not O0O0OO000O000000O in ['kodi.log','tvmc.log','spmc.log','xbmc.log']:#line:2489
                            try :#line:2490
                                os .unlink (os .path .join (O00O00O00OO000000 ,O0O0OO000O000000O ))#line:2491
                            except :#line:2492
                                pass #line:2493
                        else :log ('Ignore Log File: %s'%O0O0OO000O000000O )#line:2494
                    for O0O0O0O0OOO00O0OO in OOO00O0OO000OOOOO :#line:2495
                        try :#line:2496
                            shutil .rmtree (os .path .join (O00O00O00OO000000 ,O0O0O0O0OOO00O0OO ))#line:2497
                            O000OO0OOO0OO000O +=1 #line:2498
                            log ("[COLOR red][Success]  %s Files Removed From %s [/COLOR]"%(str (O0O0OOO00OO00O0O0 ),os .path .join (O0O0OOOOO0O0OOO0O ,O0O0O0O0OOO00O0OO )))#line:2499
                        except :#line:2500
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (O0O0OOOOO0O0OOO0O ,O0O0O0O0OOO00O0OO ))#line:2501
        else :#line:2502
            for O00O00O00OO000000 ,OOO00O0OO000OOOOO ,O00OO0O00O0OO0O0O in os .walk (O0O0OOOOO0O0OOO0O ):#line:2503
                for O0O0O0O0OOO00O0OO in OOO00O0OO000OOOOO :#line:2504
                    if 'cache'in O0O0O0O0OOO00O0OO .lower ():#line:2505
                        try :#line:2506
                            shutil .rmtree (os .path .join (O00O00O00OO000000 ,O0O0O0O0OOO00O0OO ))#line:2507
                            O000OO0OOO0OO000O +=1 #line:2508
                            log ("[COLOR white][Success] Wiped %s [/COLOR]"%os .path .join (O0O0OOOOO0O0OOO0O ,O0O0O0O0OOO00O0OO ))#line:2509
                        except :#line:2510
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (O0O0OOOOO0O0OOO0O ,O0O0O0O0OOO00O0OO ))#line:2511
    LogNotify (ADDONTITLE ,'[COLOR white]Cache:[/COLOR] [COLOR red] %s Items Removed[/COLOR]'%O000OO0OOO0OO000O )#line:2513
origfolder =(xbmc .translatePath ("special://home/addons"))#line:2514
def CleanPYO ():#line:2515
    OO0O0O00OOO00OOOO =0 #line:2516
    for (O00O00000O000O0OO ,O0OO0OOOO0O00OOOO ,O0OOOO00OOOOOO000 )in os .walk (origfolder ):#line:2517
       for O000OOOOOO00O000O in O0OOOO00OOOOOO000 :#line:2518
          if O000OOOOOO00O000O .endswith ('.pyo'):#line:2519
               os .remove (os .path .join (O00O00000O000O0OO ,O000OOOOOO00O000O ))#line:2521
def fixwizard (over =None ):#line:2523
	O00OOOO0OOOO000O0 =os .path .join (PROFILE ,'addon_data')#line:2525
	O000OO0O0OO00OOOO =[(O00OOOO0OOOO000O0 ),(ADDONDATA ),os .path .join (xbmc .translatePath ('special://profile/addon_data/plugin.program.Anonymous'),'')]#line:2530
	O0OOO0O00O000OO0O =0 #line:2531
	O0000OO0O0O00OOOO =['meta_cache','archive_cache']#line:2532
	for OOO000OOOO0O0000O in O000OO0O0OO00OOOO :#line:2533
		if os .path .exists (OOO000OOOO0O0000O )and not OOO000OOOO0O0000O in [ADDONDATA ,O00OOOO0OOOO000O0 ]:#line:2534
			for O00O0000OOO0OOOOO ,O000OO000OOO0OO0O ,OOOOOOO0000OOOOOO in os .walk (OOO000OOOO0O0000O ):#line:2535
				O000OO000OOO0OO0O [:]=[O0OO000OOO0O0OO0O for O0OO000OOO0O0OO0O in O000OO000OOO0OO0O if O0OO000OOO0O0OO0O not in O0000OO0O0O00OOOO ]#line:2536
				OOOOOOO00000000O0 =0 #line:2537
				OOOOOOO00000000O0 +=len (OOOOOOO0000OOOOOO )#line:2538
				if OOOOOOO00000000O0 >0 :#line:2539
					for OOOO0O0O0000O0OO0 in OOOOOOO0000OOOOOO :#line:2540
						if not OOOO0O0O0000O0OO0 in LOGFILES :#line:2541
							try :#line:2542
								os .unlink (os .path .join (O00O0000OOO0OOOOO ,OOOO0O0O0000O0OO0 ))#line:2543
								log ("[Wiped] %s"%os .path .join (O00O0000OOO0OOOOO ,OOOO0O0O0000O0OO0 ),xbmc .LOGNOTICE )#line:2544
								O0OOO0O00O000OO0O +=1 #line:2545
							except :#line:2546
								pass #line:2547
						else :log ('Ignore Log File: %s'%OOOO0O0O0000O0OO0 ,xbmc .LOGNOTICE )#line:2548
					for OOOO00OOO0O00000O in O000OO000OOO0OO0O :#line:2549
						try :#line:2550
							shutil .rmtree (os .path .join (O00O0000OOO0OOOOO ,OOOO00OOO0O00000O ))#line:2551
							O0OOO0O00O000OO0O +=1 #line:2552
							log ("[Success] cleared %s files from %s"%(str (OOOOOOO00000000O0 ),os .path .join (OOO000OOOO0O0000O ,OOOO00OOO0O00000O )),xbmc .LOGNOTICE )#line:2553
						except :#line:2554
							log ("[Failed] to wipe cache in: %s"%os .path .join (OOO000OOOO0O0000O ,OOOO00OOO0O00000O ),xbmc .LOGNOTICE )#line:2555
		else :#line:2556
			for O00O0000OOO0OOOOO ,O000OO000OOO0OO0O ,OOOOOOO0000OOOOOO in os .walk (OOO000OOOO0O0000O ):#line:2557
				O000OO000OOO0OO0O [:]=[O00O00O0OO00OOOOO for O00O00O0OO00OOOOO in O000OO000OOO0OO0O if O00O00O0OO00OOOOO not in O0000OO0O0O00OOOO ]#line:2558
				for OOOO00OOO0O00000O in O000OO000OOO0OO0O :#line:2559
					if not str (OOOO00OOO0O00000O .lower ()).find ('cache')==-1 :#line:2560
						try :#line:2561
							shutil .rmtree (os .path .join (O00O0000OOO0OOOOO ,OOOO00OOO0O00000O ))#line:2562
							O0OOO0O00O000OO0O +=1 #line:2563
							log ("[Success] wiped %s "%os .path .join (O00O0000OOO0OOOOO ,OOOO00OOO0O00000O ),xbmc .LOGNOTICE )#line:2564
						except :#line:2565
							log ("[Failed] to wipe cache in: %s"%os .path .join (OOO000OOOO0O0000O ,OOOO00OOO0O00000O ),xbmc .LOGNOTICE )#line:2566
	if os .path .exists (PACKAGES ):#line:2567
		try :#line:2568
			for O00O0000OOO0OOOOO ,O000OO000OOO0OO0O ,OOOOOOO0000OOOOOO in os .walk (PACKAGES ):#line:2569
				OOOOOOO00000000O0 =0 #line:2570
				OOOOOOO00000000O0 +=len (OOOOOOO0000OOOOOO )#line:2571
				if OOOOOOO00000000O0 >0 :#line:2572
					O0O00OOOO00OO0OO0 =convertSize (getSize (PACKAGES ))#line:2573
					if over :O0O0O000OO0O0O0O0 =1 #line:2574
					else :O0O0O000OO0O0O0O0 =1 #line:2575
					if O0O0O000OO0O0O0O0 :#line:2576
						for OOOO0O0O0000O0OO0 in OOOOOOO0000OOOOOO :os .unlink (os .path .join (O00O0000OOO0OOOOO ,OOOO0O0O0000O0OO0 ))#line:2577
						for OOOO00OOO0O00000O in O000OO000OOO0OO0O :shutil .rmtree (os .path .join (O00O0000OOO0OOOOO ,OOOO00OOO0O00000O ))#line:2578
						LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success![/COLOR]'%COLOR2 )#line:2579
		except Exception as OO00OOO00O00O0O0O :#line:2581
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:2582
			log ("Clear Packages Error: %s"%str (OO00OOO00O00O0O0O ),xbmc .LOGERROR )#line:2583
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2584
	LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]איפוס עבר בהצלחה %s Files[/COLOR]'%(COLOR2 ,O0OOO0O00O000OO0O ))#line:2586
def checkSources ():#line:2588
	if not os .path .exists (SOURCES ):#line:2589
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Sources.xml File Found![/COLOR]"%COLOR2 )#line:2590
		return False #line:2591
	OOO000OOO0OOO0O00 =0 #line:2592
	O00OOOO0O0OO00O00 =[]#line:2593
	O0O0OO000OOO0OO00 =[]#line:2594
	O0O0OO0O0O0OOO00O =open (SOURCES )#line:2595
	OOO00O0OOO0OOOO0O =O0O0OO0O0O0OOO00O .read ()#line:2596
	OO000OOO000OOO000 =OOO00O0OOO0OOOO0O .replace ('\r','').replace ('\n','').replace ('\t','')#line:2597
	O0000OOO00O00O0O0 =re .compile ('<files>.+?</files>').findall (OO000OOO000OOO000 )#line:2598
	O0O0OO0O0O0OOO00O .close ()#line:2599
	if len (O0000OOO00O00O0O0 )>0 :#line:2600
		O0OO00OO0OOOO000O =re .compile ('<source>.+?<name>(.+?)</name>.+?<path pathversion="1">(.+?)</path>.+?<allowsharing>(.+?)</allowsharing>.+?</source>').findall (O0000OOO00O00O0O0 [0 ])#line:2601
		DP .create (ADDONTITLE ,"[COLOR %s]Scanning Sources for Broken links[/COLOR]"%COLOR2 )#line:2602
		for O0000O0OOO000OOO0 ,OO0O000OOOO000000 ,OO0000O00O0OOO0O0 in O0OO00OO0OOOO000O :#line:2603
			OOO000OOO0OOO0O00 +=1 #line:2604
			O0O0OO0O00000000O =int (percentage (OOO000OOO0OOO0O00 ,len (O0OO00OO0OOOO000O )))#line:2605
			DP .update (O0O0OO0O00000000O ,'',"[COLOR %s]Checking [COLOR %s]%s[/COLOR]:[/COLOR]"%(COLOR2 ,COLOR1 ,O0000O0OOO000OOO0 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O000OOOO000000 ))#line:2606
			if 'http'in OO0O000OOOO000000 :#line:2607
				OOOO0OOOOOO0OO0OO =workingURL (OO0O000OOOO000000 )#line:2608
				if not OOOO0OOOOOO0OO0OO ==True :#line:2609
					O00OOOO0O0OO00O00 .append ([O0000O0OOO000OOO0 ,OO0O000OOOO000000 ,OO0000O00O0OOO0O0 ,OOOO0OOOOOO0OO0OO ])#line:2610
		log ("Bad Sources: %s"%len (O00OOOO0O0OO00O00 ),xbmc .LOGNOTICE )#line:2612
		if len (O00OOOO0O0OO00O00 )>0 :#line:2613
			O0O00O0O0OO0O0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] Source(s) have been found Broken"%(COLOR1 ,len (O00OOOO0O0OO00O00 ),COLOR2 ),"Would you like to Remove all or choose one by one?[/COLOR]",yeslabel ="[B][COLOR green]Remove All[/COLOR][/B]",nolabel ="[B][COLOR red]Choose to Delete[/COLOR][/B]")#line:2614
			if O0O00O0O0OO0O0OO0 ==1 :#line:2615
				O0O0OO000OOO0OO00 =O00OOOO0O0OO00O00 #line:2616
			else :#line:2617
				for O0000O0OOO000OOO0 ,OO0O000OOOO000000 ,OO0000O00O0OOO0O0 ,OOOO0OOOOOO0OO0OO in O00OOOO0O0OO00O00 :#line:2618
					log ("%s sources: %s, %s"%(O0000O0OOO000OOO0 ,OO0O000OOOO000000 ,OOOO0OOOOOO0OO0OO ),xbmc .LOGNOTICE )#line:2619
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] was reported as non working"%(COLOR1 ,O0000O0OOO000OOO0 ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O000OOOO000000 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOOOO0OO0OO ),yeslabel ="[B][COLOR green]Remove Source[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Source[/COLOR][/B]"):#line:2620
						O0O0OO000OOO0OO00 .append ([O0000O0OOO000OOO0 ,OO0O000OOOO000000 ,OO0000O00O0OOO0O0 ,OOOO0OOOOOO0OO0OO ])#line:2621
						log ("Removing Source %s"%O0000O0OOO000OOO0 ,xbmc .LOGNOTICE )#line:2622
					else :log ("Source %s was not removed"%O0000O0OOO000OOO0 ,xbmc .LOGNOTICE )#line:2623
			if len (O0O0OO000OOO0OO00 )>0 :#line:2624
				for O0000O0OOO000OOO0 ,OO0O000OOOO000000 ,OO0000O00O0OOO0O0 ,OOOO0OOOOOO0OO0OO in O0O0OO000OOO0OO00 :#line:2625
					OOO00O0OOO0OOOO0O =OOO00O0OOO0OOOO0O .replace ('\n        <source>\n            <name>%s</name>\n            <path pathversion="1">%s</path>\n            <allowsharing>%s</allowsharing>\n        </source>'%(O0000O0OOO000OOO0 ,OO0O000OOOO000000 ,OO0000O00O0OOO0O0 ),'')#line:2626
					log ("Removing Source %s"%O0000O0OOO000OOO0 ,xbmc .LOGNOTICE )#line:2627
				O0O0OO0O0O0OOO00O =open (SOURCES ,mode ='w')#line:2629
				O0O0OO0O0O0OOO00O .write (str (OOO00O0OOO0OOOO0O ))#line:2630
				O0O0OO0O0O0OOO00O .close ()#line:2631
				OOOOOO0000000000O =len (O0000OOO00O00O0O0 )-len (O00OOOO0O0OO00O00 )#line:2632
				OO000OO000O0000O0 =len (O00OOOO0O0OO00O00 )-len (O0O0OO000OOO0OO00 )#line:2633
				OO0000OO000O0O000 =len (O0O0OO000OOO0OO00 )#line:2634
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Checking sources for broken paths has been completed"%COLOR2 ,"Working: [COLOR %s]%s[/COLOR] | Kept: [COLOR %s]%s[/COLOR] | Removed: [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR2 ,COLOR1 ,OOOOOO0000000000O ,COLOR1 ,OO000OO000O0000O0 ,COLOR1 ,OO0000OO000O0O000 ))#line:2635
			else :log ("No Bad Sources to be removed.",xbmc .LOGNOTICE )#line:2636
		else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Sources Are Working[/COLOR]"%COLOR2 )#line:2637
	else :log ("No Sources Found",xbmc .LOGNOTICE )#line:2638
def checkRepos ():#line:2640
	DP .create (ADDONTITLE ,'[COLOR %s]Checking Repositories...[/COLOR]'%COLOR2 )#line:2641
	OOO000OO00OO0OOOO =[]#line:2642
	ebi ('UpdateAddonRepos')#line:2643
	OOOOO000O00OOO00O =glob .glob (os .path .join (ADDONS ,'repo*'))#line:2644
	if len (OOOOO000O00OOO00O )==0 :#line:2645
		DP .close ()#line:2646
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Repositories Found![/COLOR]"%COLOR2 )#line:2647
		return #line:2648
	O000000O0O0O0O0OO =len (OOOOO000O00OOO00O );O0O00O0OOO0OO00O0 =0 ;#line:2649
	while O0O00O0OOO0OO00O0 <O000000O0O0O0O0OO :#line:2650
		O0O00O0OOO0OO00O0 +=1 #line:2651
		if DP .iscanceled ():break #line:2652
		OO00OOOOO0O0OO00O =int (percentage (O0O00O0OOO0OO00O0 ,O000000O0O0O0O0OO ))#line:2653
		DP .update (OO00OOOOO0O0OO00O ,'','[COLOR %s]Checking: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO000O00OOO00O [O0O00O0OOO0OO00O0 -1 ].replace (ADDONS ,'')[1 :]))#line:2654
		xbmc .sleep (1000 )#line:2655
	if DP .iscanceled ():#line:2656
		DP .close ()#line:2657
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled[/COLOR]"%COLOR2 )#line:2658
		sys .exit ()#line:2659
	DP .close ()#line:2660
	OOO0000OOOO0O00O0 =Grab_Log (False )#line:2661
	O0OOO0O0O00OO0O0O =re .compile ('CRepositoryUpdateJob(.+?)failed').findall (OOO0000OOOO0O00O0 )#line:2662
	for O000OOOOOO0O0O0OO in O0OOO0O0O00OO0O0O :#line:2663
		log ("Bad Repository: %s "%O000OOOOOO0O0O0OO ,xbmc .LOGNOTICE )#line:2664
		O0O00OO00000000OO =O000OOOOOO0O0O0OO .replace ('[','').replace (']','').replace (' ','').replace ('/','').replace ('\\','')#line:2665
		if not O0O00OO00000000OO in OOO000OO00OO0OOOO :#line:2666
			OOO000OO00OO0OOOO .append (O0O00OO00000000OO )#line:2667
	if len (OOO000OO00OO0OOOO )>0 :#line:2668
		O0000O00O0O0OO000 ="[COLOR %s]Below is a list of Repositories that did not resolve.  This does not mean that they are Depreciated, sometimes hosts go down for a short period of time.  Please do serveral scans of your repository list before removing a repository just to make sure it is broken.[/COLOR][CR][CR][COLOR %s]"%(COLOR2 ,COLOR1 )#line:2669
		O0000O00O0O0OO000 +='[CR]'.join (OOO000OO00OO0OOOO )#line:2670
		O0000O00O0O0OO000 +='[/COLOR]'#line:2671
		TextBox ("%s: Bad Repositories"%ADDONTITLE ,O0000O00O0O0OO000 )#line:2672
	else :#line:2673
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Repositories Working![/COLOR]"%COLOR2 )#line:2674
def killxbmc (over =None ):#line:2680
		log ("Force Closing Kodi: Platform[%s]"%str (platform ()),xbmc .LOGNOTICE )#line:2681
		os ._exit (1 )#line:2682
def redoThumbs ():#line:2684
	if not os .path .exists (THUMBS ):os .makedirs (THUMBS )#line:2685
	O00OO0O0O0O00O000 ='0123456789abcdef'#line:2686
	OOOOO0OO000OO000O =os .path .join (THUMBS ,'Video','Bookmarks')#line:2687
	for O0OOOO0OO0O0OOO0O in O00OO0O0O0O00O000 :#line:2688
		O0O0OOO0OO000O0OO =os .path .join (THUMBS ,O0OOOO0OO0O0OOO0O )#line:2689
		if not os .path .exists (O0O0OOO0OO000O0OO ):os .makedirs (O0O0OOO0OO000O0OO )#line:2690
	if not os .path .exists (OOOOO0OO000OO000O ):os .makedirs (OOOOO0OO000OO000O )#line:2691
def reloadFix (default =None ):#line:2693
	DIALOG .ok (ADDONTITLE ,"[COLOR %s]WARNING: Sometimes Reloading the Profile causes Kodi to crash.  While Kodi is Reloading the Profile Please Do Not Press Any Buttons![/COLOR]"%COLOR2 )#line:2694
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2695
	if default ==None :#line:2696
		lookandFeelData ('save')#line:2697
	redoThumbs ()#line:2698
	ebi ('ActivateWindow(Home)')#line:2699
	xbmc .sleep (10000 )#line:2701
	if KODIV >=17 :kodi17Fix ()#line:2702
	if default ==None :#line:2703
		log ("Switching to: %s"%getS ('defaultskin'))#line:2704
		O0O00O00O00O00O0O =getS ('defaultskin')#line:2705
		skinSwitch .swapSkins (O0O00O00O00O00O0O )#line:2706
		OOO00O0OOOO0OO0OO =0 #line:2707
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO00O0OOOO0OO0OO <150 :#line:2708
			OOO00O0OOOO0OO0OO +=1 #line:2709
			xbmc .sleep (200 )#line:2710
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:2711
			ebi ('SendClick(11)')#line:2712
		lookandFeelData ('restore')#line:2713
	addonUpdates ('reset')#line:2714
	forceUpdate ()#line:2715
	ebi ("ReloadSkin()")#line:2716
def skinToDefault ():#line:2718
	if not currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary']:#line:2719
		OO0OOO000OO0OO00O ='skin.confluence'if KODIV <17 else 'skin.estuary'#line:2720
	swapSkins (OO0OOO000OO0OO00O )#line:2721
def swapSkins (O0OOO00O0O0OOOOO0 ):#line:2723
	skinSwitch .swapSkins (O0OOO00O0O0OOOOO0 )#line:2724
	O0000OOOOO0000000 =0 #line:2725
	xbmc .sleep (1000 )#line:2726
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000OOOOO0000000 <150 :#line:2727
		O0000OOOOO0000000 +=1 #line:2728
		xbmc .sleep (100 )#line:2729
		ebi ('SendAction(Select)')#line:2730
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:2732
		ebi ('SendClick(11)')#line:2733
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Fresh Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:2734
	xbmc .sleep (500 )#line:2735
def mediaCenter ():#line:2737
	if str (HOME ).lower ().find ('kodi'):#line:2738
		return 'Kodi'#line:2739
	elif str (HOME ).lower ().find ('spmc'):#line:2740
		return 'SPMC'#line:2741
	else :#line:2742
		return 'Unknown Fork'#line:2743
def kodi17Fix ():#line:2745
	O0O0OO000OOO00000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2746
	O000O0OOO0O00O000 =[]#line:2747
	for O0OOO0O0O0000000O in sorted (O0O0OO000OOO00000 ,key =lambda OOOOO00OOOOOOOOO0 :OOOOO00OOOOOOOOO0 ):#line:2748
		O0O00O000O0OO0OOO =os .path .join (O0OOO0O0O0000000O ,'addon.xml')#line:2749
		if os .path .exists (O0O00O000O0OO0OOO ):#line:2750
			OO00O0O00O00O000O =O0OOO0O0O0000000O .replace (ADDONS ,'')[1 :-1 ]#line:2751
			O0O0OO0OOO000O00O =open (O0O00O000O0OO0OOO )#line:2752
			OOO0O0OO00O00000O =O0O0OO0OOO000O00O .read ()#line:2753
			OO0O0OOO00O0O000O =parseDOM (OOO0O0OO00O00000O ,'addon',ret ='id')#line:2754
			O0O0OO0OOO000O00O .close ()#line:2755
			try :#line:2756
				OOO00O000OOOOOO00 =xbmcaddon .Addon (id =OO0O0OOO00O0O000O [0 ])#line:2757
			except :#line:2758
				try :#line:2759
					log ("%s was disabled"%OO0O0OOO00O0O000O [0 ],xbmc .LOGDEBUG )#line:2760
					O000O0OOO0O00O000 .append (OO0O0OOO00O0O000O [0 ])#line:2761
				except :#line:2762
					try :#line:2763
						log ("%s was disabled"%OO00O0O00O00O000O ,xbmc .LOGDEBUG )#line:2764
						O000O0OOO0O00O000 .append (OO00O0O00O00O000O )#line:2765
					except :#line:2766
						if len (OO0O0OOO00O0O000O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO00O0O00O00O000O ,xbmc .LOGERROR )#line:2767
						else :log ("Unabled to enable: %s"%O0OOO0O0O0000000O ,xbmc .LOGERROR )#line:2768
	if len (O000O0OOO0O00O000 )>0 :#line:2769
		O00O000O0OO00O000 =0 #line:2770
		DP .create (ADDONTITLE ,'[COLOR %s]מעדכן הרחבות'%COLOR2 ,'','אנא המתן[/COLOR]')#line:2771
		for O0OOO00OOOOOO00OO in O000O0OOO0O00O000 :#line:2772
			O00O000O0OO00O000 +=1 #line:2773
			O000OO000OO000O0O =int (percentage (O00O000O0OO00O000 ,len (O000O0OOO0O00O000 )))#line:2774
			DP .update (O000OO000OO000O0O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO00OOOOOO00OO ))#line:2775
			addonDatabase (O0OOO00OOOOOO00OO ,1 )#line:2776
			if DP .iscanceled ():break #line:2777
		if DP .iscanceled ():#line:2778
			DP .close ()#line:2779
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:2780
			sys .exit ()#line:2781
		DP .close ()#line:2782
	forceUpdate ()#line:2783
def addonDatabase (addon =None ,state =1 ):#line:2786
	OO00000OO0OOOOOOO =latestDB ('Addons')#line:2787
	OO00000OO0OOOOOOO =os .path .join (DATABASE ,OO00000OO0OOOOOOO )#line:2788
	OOO00O00O0OOOO00O =str (datetime .now ())[:-7 ]#line:2789
	if os .path .exists (OO00000OO0OOOOOOO ):#line:2790
		try :#line:2791
			O0O0OOOOO0OOOOO0O =database .connect (OO00000OO0OOOOOOO )#line:2792
			OOO0OOOOOOOO000O0 =O0O0OOOOO0OOOOO0O .cursor ()#line:2793
		except Exception as O00OO00OOO0OOOOO0 :#line:2794
			log ("DB Connection Error: %s"%str (O00OO00OOO0OOOOO0 ),xbmc .LOGERROR )#line:2795
			return False #line:2796
	else :return False #line:2797
	if state ==2 :#line:2798
		try :#line:2799
			OOO0OOOOOOOO000O0 .execute ("DELETE FROM installed WHERE addonID = ?",(addon ,))#line:2800
			O0O0OOOOO0OOOOO0O .commit ()#line:2801
			OOO0OOOOOOOO000O0 .close ()#line:2802
		except Exception as O00OO00OOO0OOOOO0 :#line:2803
			log ("Error Removing %s from DB"%addon )#line:2804
		return True #line:2805
	try :#line:2806
		OOO0OOOOOOOO000O0 .execute ("SELECT id, addonID, enabled FROM installed WHERE addonID = ?",(addon ,))#line:2807
		OOOO00OO0OO0O0O00 =OOO0OOOOOOOO000O0 .fetchone ()#line:2808
		if OOOO00OO0OO0O0O00 ==None :#line:2809
			OOO0OOOOOOOO000O0 .execute ('INSERT INTO installed (addonID , enabled, installDate) VALUES (?,?,?)',(addon ,state ,OOO00O00O0OOOO00O ,))#line:2810
			log ("Insert %s into db"%addon )#line:2811
		else :#line:2812
			OOO0OOO0OO0O000O0 ,O00OO000O0O00OOOO ,O0OOOOO00O0O0OOOO =OOOO00OO0OO0O0O00 #line:2813
			OOO0OOOOOOOO000O0 .execute ('UPDATE installed SET enabled = ? WHERE id = ? ',(state ,OOO0OOO0OO0O000O0 ,))#line:2814
			log ("Updated %s in db"%addon )#line:2815
		O0O0OOOOO0OOOOO0O .commit ()#line:2816
		OOO0OOOOOOOO000O0 .close ()#line:2817
	except Exception as O00OO00OOO0OOOOO0 :#line:2818
		log ("Erroring enabling addon: %s"%addon )#line:2819
def purgeDb (OO0O000OO0OO000OO ):#line:2824
	log ('Purging DB %s.'%OO0O000OO0OO000OO ,xbmc .LOGNOTICE )#line:2828
	if os .path .exists (OO0O000OO0OO000OO ):#line:2829
		try :#line:2830
			O000O0000OO0O00OO =database .connect (OO0O000OO0OO000OO )#line:2831
			O0O0O00OOOOO00OO0 =O000O0000OO0O00OO .cursor ()#line:2832
		except Exception as O000O00OOOOOO0OOO :#line:2833
			log ("DB Connection Error: %s"%str (O000O00OOOOOO0OOO ),xbmc .LOGERROR )#line:2834
			return False #line:2835
	else :log ('%s not found.'%OO0O000OO0OO000OO ,xbmc .LOGERROR );return False #line:2836
	O0O0O00OOOOO00OO0 .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:2837
	for OO0OO0O000O00OOO0 in O0O0O00OOOOO00OO0 .fetchall ():#line:2838
		if OO0OO0O000O00OOO0 [0 ]=='version':#line:2839
			log ('Data from table `%s` skipped.'%OO0OO0O000O00OOO0 [0 ],xbmc .LOGDEBUG )#line:2840
		else :#line:2841
			try :#line:2842
				O0O0O00OOOOO00OO0 .execute ("DELETE FROM %s"%OO0OO0O000O00OOO0 [0 ])#line:2843
				O000O0000OO0O00OO .commit ()#line:2844
				log ('Data from table `%s` cleared.'%OO0OO0O000O00OOO0 [0 ],xbmc .LOGDEBUG )#line:2845
			except Exception as O000O00OOOOOO0OOO :log ("DB Remove Table `%s` Error: %s"%(OO0OO0O000O00OOO0 [0 ],str (O000O00OOOOOO0OOO )),xbmc .LOGERROR )#line:2846
	O0O0O00OOOOO00OO0 .close ()#line:2847
	log ('%s DB Purging Complete.'%OO0O000OO0OO000OO ,xbmc .LOGNOTICE )#line:2848
	OOO00O0O00OOO0OO0 =OO0O000OO0OO000OO .replace ('\\','/').split ('/')#line:2849
	LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]%s Complete[/COLOR]"%(COLOR2 ,OOO00O0O00OOO0OO0 [len (OOO00O0O00OOO0OO0 )-1 ]))#line:2850
def oldThumbs ():#line:2852
	OO00O0O0O00O0O00O =os .path .join (DATABASE ,latestDB ('Textures'))#line:2853
	O0O000O00OO00OOOO =10 #line:2854
	OOOO0OO00OOOOOO00 =TODAY -timedelta (days =7 )#line:2855
	O0O0OOO00O000O0O0 =[]#line:2856
	O000OO00OO00O0OO0 =[]#line:2857
	O0O00O0O00OO0O0O0 =0 #line:2858
	if os .path .exists (OO00O0O0O00O0O00O ):#line:2859
		try :#line:2860
			O0000OOO00O0000OO =database .connect (OO00O0O0O00O0O00O )#line:2861
			O000O000OOOOOOOO0 =O0000OOO00O0000OO .cursor ()#line:2862
		except Exception as O0O00OOOOOO000OO0 :#line:2863
			log ("DB Connection Error: %s"%str (O0O00OOOOOO000OO0 ),xbmc .LOGERROR )#line:2864
			return False #line:2865
	else :log ('%s not found.'%OO00O0O0O00O0O00O ,xbmc .LOGERROR );return False #line:2866
	O000O000OOOOOOOO0 .execute ("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?",(O0O000O00OO00OOOO ,str (OOOO0OO00OOOOOO00 )))#line:2867
	OO0OOOO0O0O000OO0 =O000O000OOOOOOOO0 .fetchall ()#line:2868
	for O0OO0O00O0OO00OOO in OO0OOOO0O0O000OO0 :#line:2869
		OO0OO00O000OO0OO0 =O0OO0O00O0OO00OOO [0 ]#line:2870
		O0O0OOO00O000O0O0 .append (OO0OO00O000OO0OO0 )#line:2871
		O000O000OOOOOOOO0 .execute ("SELECT cachedurl FROM texture WHERE id = ?",(OO0OO00O000OO0OO0 ,))#line:2872
		OOOO0O000OO00000O =O000O000OOOOOOOO0 .fetchall ()#line:2873
		for O0000O000000O00O0 in OOOO0O000OO00000O :#line:2874
			O000OO00OO00O0OO0 .append (O0000O000000O00O0 [0 ])#line:2875
	log ("%s total thumbs cleaned up."%str (len (O000OO00OO00O0OO0 )),xbmc .LOGNOTICE )#line:2876
	for O0O00O000OOO000OO in O0O0OOO00O000O0O0 :#line:2877
		O000O000OOOOOOOO0 .execute ("DELETE FROM sizes   WHERE idtexture = ?",(O0O00O000OOO000OO ,))#line:2878
		O000O000OOOOOOOO0 .execute ("DELETE FROM texture WHERE id        = ?",(O0O00O000OOO000OO ,))#line:2879
	O000O000OOOOOOOO0 .execute ("VACUUM")#line:2880
	O0000OOO00O0000OO .commit ()#line:2881
	O000O000OOOOOOOO0 .close ()#line:2882
	for OO00OOOOO00OOOOO0 in O000OO00OO00O0OO0 :#line:2883
		O0OO00OO0O00OOO0O =os .path .join (THUMBS ,OO00OOOOO00OOOOO0 )#line:2884
		try :#line:2885
			O0OOO0OOOO00000OO =os .path .getsize (O0OO00OO0O00OOO0O )#line:2886
			os .remove (O0OO00OO0O00OOO0O )#line:2887
			O0O00O0O00OO0O0O0 +=O0OOO0OOOO00000OO #line:2888
		except :#line:2889
			pass #line:2890
	OOO0000000000O0O0 =convertSize (O0O00O0O00OO0O0O0 )#line:2891
	if len (O000OO00OO00O0OO0 )>0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: %s Files / %s MB[/COLOR]!'%(COLOR2 ,str (len (O000OO00OO00O0OO0 )),OOO0000000000O0O0 ))#line:2892
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: None Found![/COLOR]'%COLOR2 )#line:2893
def parseDOM (OO00O0OO000000000 ,name =u"",attrs ={},ret =False ):#line:2895
    if isinstance (OO00O0OO000000000 ,str ):#line:2898
        try :#line:2899
            OO00O0OO000000000 =[OO00O0OO000000000 .decode ("utf-8")]#line:2900
        except :#line:2901
            OO00O0OO000000000 =[OO00O0OO000000000 ]#line:2902
    elif isinstance (OO00O0OO000000000 ,unicode ):#line:2903
        OO00O0OO000000000 =[OO00O0OO000000000 ]#line:2904
    elif not isinstance (OO00O0OO000000000 ,list ):#line:2905
        return u""#line:2906
    if not name .strip ():#line:2908
        return u""#line:2909
    O00OO0O0000OOO0OO =[]#line:2911
    for OO0OO000OOO0OOO00 in OO00O0OO000000000 :#line:2912
        O0OOOOO0O00O0O000 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO0OO000OOO0OOO00 )#line:2913
        for OO00O0OO0O00OO00O in O0OOOOO0O00O0O000 :#line:2914
            OO0OO000OOO0OOO00 =OO0OO000OOO0OOO00 .replace (OO00O0OO0O00OO00O ,OO00O0OO0O00OO00O .replace ("\n"," "))#line:2915
        OO00O0O00OOOO00O0 =[]#line:2917
        for O00O0O000OOOOOO00 in attrs :#line:2918
            OO00OOO0O00000O00 =re .compile ('(<'+name +'[^>]*?(?:'+O00O0O000OOOOOO00 +'=[\'"]'+attrs [O00O0O000OOOOOO00 ]+'[\'"].*?>))',re .M |re .S ).findall (OO0OO000OOO0OOO00 )#line:2919
            if len (OO00OOO0O00000O00 )==0 and attrs [O00O0O000OOOOOO00 ].find (" ")==-1 :#line:2920
                OO00OOO0O00000O00 =re .compile ('(<'+name +'[^>]*?(?:'+O00O0O000OOOOOO00 +'='+attrs [O00O0O000OOOOOO00 ]+'.*?>))',re .M |re .S ).findall (OO0OO000OOO0OOO00 )#line:2921
            if len (OO00O0O00OOOO00O0 )==0 :#line:2923
                OO00O0O00OOOO00O0 =OO00OOO0O00000O00 #line:2924
                OO00OOO0O00000O00 =[]#line:2925
            else :#line:2926
                OOO00OOO00O0O00OO =range (len (OO00O0O00OOOO00O0 ))#line:2927
                OOO00OOO00O0O00OO .reverse ()#line:2928
                for O000OO0OOOO00OOO0 in OOO00OOO00O0O00OO :#line:2929
                    if not OO00O0O00OOOO00O0 [O000OO0OOOO00OOO0 ]in OO00OOO0O00000O00 :#line:2930
                        del (OO00O0O00OOOO00O0 [O000OO0OOOO00OOO0 ])#line:2931
        if len (OO00O0O00OOOO00O0 )==0 and attrs =={}:#line:2933
            OO00O0O00OOOO00O0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO0OO000OOO0OOO00 )#line:2934
            if len (OO00O0O00OOOO00O0 )==0 :#line:2935
                OO00O0O00OOOO00O0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO0OO000OOO0OOO00 )#line:2936
        if isinstance (ret ,str ):#line:2938
            OO00OOO0O00000O00 =[]#line:2939
            for OO00O0OO0O00OO00O in OO00O0O00OOOO00O0 :#line:2940
                O00000O00OOOOOO0O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO00O0OO0O00OO00O )#line:2941
                if len (O00000O00OOOOOO0O )==0 :#line:2942
                    O00000O00OOOOOO0O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO00O0OO0O00OO00O )#line:2943
                for OOO0O00000OO000O0 in O00000O00OOOOOO0O :#line:2944
                    O000O00OO0O000O00 =OOO0O00000OO000O0 [0 ]#line:2945
                    if O000O00OO0O000O00 in "'\"":#line:2946
                        if OOO0O00000OO000O0 .find ('='+O000O00OO0O000O00 ,OOO0O00000OO000O0 .find (O000O00OO0O000O00 ,1 ))>-1 :#line:2947
                            OOO0O00000OO000O0 =OOO0O00000OO000O0 [:OOO0O00000OO000O0 .find ('='+O000O00OO0O000O00 ,OOO0O00000OO000O0 .find (O000O00OO0O000O00 ,1 ))]#line:2948
                        if OOO0O00000OO000O0 .rfind (O000O00OO0O000O00 ,1 )>-1 :#line:2950
                            OOO0O00000OO000O0 =OOO0O00000OO000O0 [1 :OOO0O00000OO000O0 .rfind (O000O00OO0O000O00 )]#line:2951
                    else :#line:2952
                        if OOO0O00000OO000O0 .find (" ")>0 :#line:2953
                            OOO0O00000OO000O0 =OOO0O00000OO000O0 [:OOO0O00000OO000O0 .find (" ")]#line:2954
                        elif OOO0O00000OO000O0 .find ("/")>0 :#line:2955
                            OOO0O00000OO000O0 =OOO0O00000OO000O0 [:OOO0O00000OO000O0 .find ("/")]#line:2956
                        elif OOO0O00000OO000O0 .find (">")>0 :#line:2957
                            OOO0O00000OO000O0 =OOO0O00000OO000O0 [:OOO0O00000OO000O0 .find (">")]#line:2958
                    OO00OOO0O00000O00 .append (OOO0O00000OO000O0 .strip ())#line:2960
            OO00O0O00OOOO00O0 =OO00OOO0O00000O00 #line:2961
        else :#line:2962
            OO00OOO0O00000O00 =[]#line:2963
            for OO00O0OO0O00OO00O in OO00O0O00OOOO00O0 :#line:2964
                O0O00O0O00000OOO0 =u"</"+name #line:2965
                O0OOOO00O0OO0000O =OO0OO000OOO0OOO00 .find (OO00O0OO0O00OO00O )#line:2967
                O000O00O00O0O000O =OO0OO000OOO0OOO00 .find (O0O00O0O00000OOO0 ,O0OOOO00O0OO0000O )#line:2968
                OO000OOOO00O0OO0O =OO0OO000OOO0OOO00 .find ("<"+name ,O0OOOO00O0OO0000O +1 )#line:2969
                while OO000OOOO00O0OO0O <O000O00O00O0O000O and OO000OOOO00O0OO0O !=-1 :#line:2971
                    O00OOO000OO0O000O =OO0OO000OOO0OOO00 .find (O0O00O0O00000OOO0 ,O000O00O00O0O000O +len (O0O00O0O00000OOO0 ))#line:2972
                    if O00OOO000OO0O000O !=-1 :#line:2973
                        O000O00O00O0O000O =O00OOO000OO0O000O #line:2974
                    OO000OOOO00O0OO0O =OO0OO000OOO0OOO00 .find ("<"+name ,OO000OOOO00O0OO0O +1 )#line:2975
                if O0OOOO00O0OO0000O ==-1 and O000O00O00O0O000O ==-1 :#line:2977
                    O0000000O000O0O00 =u""#line:2978
                elif O0OOOO00O0OO0000O >-1 and O000O00O00O0O000O >-1 :#line:2979
                    O0000000O000O0O00 =OO0OO000OOO0OOO00 [O0OOOO00O0OO0000O +len (OO00O0OO0O00OO00O ):O000O00O00O0O000O ]#line:2980
                elif O000O00O00O0O000O >-1 :#line:2981
                    O0000000O000O0O00 =OO0OO000OOO0OOO00 [:O000O00O00O0O000O ]#line:2982
                elif O0OOOO00O0OO0000O >-1 :#line:2983
                    O0000000O000O0O00 =OO0OO000OOO0OOO00 [O0OOOO00O0OO0000O +len (OO00O0OO0O00OO00O ):]#line:2984
                if ret :#line:2986
                    O0O00O0O00000OOO0 =OO0OO000OOO0OOO00 [O000O00O00O0O000O :OO0OO000OOO0OOO00 .find (">",OO0OO000OOO0OOO00 .find (O0O00O0O00000OOO0 ))+1 ]#line:2987
                    O0000000O000O0O00 =OO00O0OO0O00OO00O +O0000000O000O0O00 +O0O00O0O00000OOO0 #line:2988
                OO0OO000OOO0OOO00 =OO0OO000OOO0OOO00 [OO0OO000OOO0OOO00 .find (O0000000O000O0O00 ,OO0OO000OOO0OOO00 .find (OO00O0OO0O00OO00O ))+len (O0000000O000O0O00 ):]#line:2990
                OO00OOO0O00000O00 .append (O0000000O000O0O00 )#line:2991
            OO00O0O00OOOO00O0 =OO00OOO0O00000O00 #line:2992
        O00OO0O0000OOO0OO +=OO00O0O00OOOO00O0 #line:2993
    return O00OO0O0000OOO0OO #line:2995
def replaceHTMLCodes (O00OOOO0OO0OO0O0O ):#line:2998
    O00OOOO0OO0OO0O0O =re .sub ("(&#[0-9]+)([^;^0-9]+)","\\1;\\2",O00OOOO0OO0OO0O0O )#line:2999
    O00OOOO0OO0OO0O0O =HTMLParser .HTMLParser ().unescape (O00OOOO0OO0OO0O0O )#line:3000
    O00OOOO0OO0OO0O0O =O00OOOO0OO0OO0O0O .replace ("&quot;","\"")#line:3001
    O00OOOO0OO0OO0O0O =O00OOOO0OO0OO0O0O .replace ("&amp;","&")#line:3002
    return O00OOOO0OO0OO0O0O #line:3003
import os #line:3005
from shutil import *#line:3006
def copytree (O0OOO0OO0OO0OO000 ,O00O0OO0OOOO000O0 ,symlinks =False ,ignore =None ):#line:3007
	O00O00OO00O0OOO00 =os .listdir (O0OOO0OO0OO0OO000 )#line:3008
	if ignore is not None :#line:3009
		OOOOO0OOO0O000000 =ignore (O0OOO0OO0OO0OO000 ,O00O00OO00O0OOO00 )#line:3010
	else :#line:3011
		OOOOO0OOO0O000000 =set ()#line:3012
	if not os .path .isdir (O00O0OO0OOOO000O0 ):#line:3013
		os .makedirs (O00O0OO0OOOO000O0 )#line:3014
	OOOO0OO0O00O0000O =[]#line:3015
	for OOO00OOO0OO0O0000 in O00O00OO00O0OOO00 :#line:3016
		if OOO00OOO0OO0O0000 in OOOOO0OOO0O000000 :#line:3017
			continue #line:3018
		O0OOOOOO00OOO00OO =os .path .join (O0OOO0OO0OO0OO000 ,OOO00OOO0OO0O0000 )#line:3019
		OO0000O0OO0O0OO00 =os .path .join (O00O0OO0OOOO000O0 ,OOO00OOO0OO0O0000 )#line:3020
		try :#line:3021
			if symlinks and os .path .islink (O0OOOOOO00OOO00OO ):#line:3022
				OOO0000000000OO00 =os .readlink (O0OOOOOO00OOO00OO )#line:3023
				os .symlink (OOO0000000000OO00 ,OO0000O0OO0O0OO00 )#line:3024
			elif os .path .isdir (O0OOOOOO00OOO00OO ):#line:3025
				copytree (O0OOOOOO00OOO00OO ,OO0000O0OO0O0OO00 ,symlinks ,ignore )#line:3026
			else :#line:3027
				copy2 (O0OOOOOO00OOO00OO ,OO0000O0OO0O0OO00 )#line:3028
		except Error as O0000OO0000O00O00 :#line:3029
			OOOO0OO0O00O0000O .extend (O0000OO0000O00O00 .args [0 ])#line:3030
		except EnvironmentError as OOOO0O0OO0O0O0OOO :#line:3031
			OOOO0OO0O00O0000O .append ((O0OOOOOO00OOO00OO ,OO0000O0OO0O0OO00 ,str (OOOO0O0OO0O0O0OOO )))#line:3032
	try :#line:3033
		copystat (O0OOO0OO0OO0OO000 ,O00O0OO0OOOO000O0 )#line:3034
	except OSError as OOOO0O0OO0O0O0OOO :#line:3035
		OOOO0OO0O00O0000O .extend ((O0OOO0OO0OO0OO000 ,O00O0OO0OOOO000O0 ,str (OOOO0O0OO0O0O0OOO )))#line:3036
