# coding: utf-8

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob,random,urllib,re,time,json,subprocess,zipfile
import shutil,logging,uservar,platform,base64

# socket.setdefaulttimeout(10)
from urllib.request import urlopen
from urllib.request import Request
from shutil import copyfile
import threading
from threading import Thread
from datetime import date, datetime, timedelta
from urllib.parse import parse_qsl

que=urllib.parse.quote_plus
url_encode=urllib.parse.urlencode
unque=urllib.parse.unquote_plus
translatepath=xbmcvfs.translatePath

from resources.libs import extract, downloader,notify
from resources.libs import wizard as wiz
code_link='empty'
ADDON_ID         = uservar.ADDON_ID
ADDONTITLE       = uservar.ADDONTITLE
ADDON            = wiz.addonId(ADDON_ID)
VERSION          = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH        = wiz.addonInfo(ADDON_ID,'path')
DIALOG           = xbmcgui.Dialog()
DP               = xbmcgui.DialogProgress()
HOME             = translatepath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PACKAGES         = os.path.join(ADDONS,    'packages')
ADDOND           = os.path.join(USERDATA,  'addon_data')
THUMBS           = os.path.join(USERDATA,  'Thumbnails')
DATABASE         = os.path.join(USERDATA,  'Database')
FANART           = os.path.join(ADDONPATH, 'fanart.jpg')
ICON             = os.path.join(ADDONPATH, 'icon.png')
DP2              = xbmcgui.DialogProgressBG()
BUILDNAME        = wiz.getS('buildname')
BUILDVERSION     = wiz.getS('buildversion')
BUILDLATEST      = wiz.getS('latestversion')
NOTIFY           = wiz.getS('notify')
NOTEDISMISS      = wiz.getS('notedismiss')
NOTEID           = wiz.getS('noteid')
NOTEID         = 0 if NOTEID == "" else int(NOTEID)
HARDWAER         = wiz.getS('action')
TODAY            = date.today()
TOMORROW         = TODAY + timedelta(days=1)
THREEDAYS        = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)
MONTH        = TODAY - timedelta(days=2)
LASTONEWEEK        = TODAY - timedelta(days=7)
KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
EXCLUDES         = uservar.EXCLUDES
APKFILE          = uservar.APKFILE
from resources.libs.wizard import BL
from resources.libs.wizard import send_user_info
UPDATECHECK      = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NEXTCHECK        = TODAY + timedelta(days=UPDATECHECK)
NOTIFICATION     = uservar.NOTIFICATION
TMDB_NEW_API     = uservar.TMDB_NEW_API
COLOR1           = uservar.COLOR1
COLOR2           = uservar.COLOR2
THEME1           = uservar.THEME1
THEME2           = uservar.THEME2
THEME3           = uservar.THEME3
TMDB_NEW_API2 = 'bG9qaw=='
ICONBUILDS       = uservar.ICONBUILDS if not uservar.ICONBUILDS == 'http://' else ICON


fullsecfold=translatepath('special://home')
code_link='empty'
addons_folder=os.path.join(fullsecfold,'addons')
remove_url = base64.b64decode('aHR0cHM6Ly9kaWdpdC5zZWVkaG9zdC5ldS9rb2RpL3dpemFyZC90eHQvcmVtb3ZlX2FkZG9ucy54bWw=').decode('utf-8')
reset_kodi_update = base64.b64decode('aHR0cHM6Ly9kaWdpdC5zZWVkaG9zdC5ldS9rb2RpL3dpemFyZC90eHQvcmVzZXRfa29kaS54bWw=').decode('utf-8')
user_folder=os.path.join(translatepath('special://masterprofile'),'addon_data')
remove_url2 = base64.b64decode('aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA==').decode('utf-8')
fanart         = translatepath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
icon           = translatepath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))

class Thread (threading.Thread):
   def __init__(self, target, *args):
    super().__init__(target=target, args=args)
   def run(self, *args):
      
      self._target(*self._args)
      return 0

oo='/key.xml'
from resources.libs.wizard import ld

def getOld(old):
	try:
		old = '"%s"' % old 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (old)
		
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)
		if 'result' in response:
			if 'value' in response['result']:
				return response ['result']['value'] 
	except:
		pass
	return None
    
server='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNFPyklMztaryM0BAPI5E0I=$'
def setNew(new, value):
	try:
		new = '"%s"' % new
		value = '"%s"' % value
		query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)

		response = xbmc.executeJSONRPC(query)
	except:
		pass
	return None    
def idle():
	return xbmc.executebuiltin('Dialog.Close(busydialog)')
def time_sync():

 DP2.create('[B]מבצע סנכרון[/B]')
 for s in range(60, -1, -1):
       time.sleep(1)
       DP2.update(int((60 - s) / 60.0 * 100), "[B]מסנכרן הרחבות                                 [/B]"+'\n'+"[B]אנא המתן...[/B]")
 DP2.close()

def resetkodi():
        if xbmc.getCondVisibility('system.platform.windows'):
            DP = xbmcgui.DialogProgress()
            DP.create("ההתקנה תסגר אוטומטית", "אנא המתן 5 שניות"+'\n'+ ''+'\n'+
            "[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")
            DP.update(0)
            for s in range(5, -1, -1):
                time.sleep(1)
                try:
                    DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר", 'בעוד {0} שניות'.format(s), '')
                except:
                    DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n'+ '[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')
                if DP.iscanceled():
                    from resources.libs import win
                    return None, None
            from resources.libs import win
        else:
            DP = xbmcgui.DialogProgress()
            DP.create("ההתקנה תסגר אוטומטית", 
            "[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")
            DP.update(0)
            for s in range(5, -1, -1):
                time.sleep(1)
                DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n'+ '[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')
                if DP.iscanceled():
                    from resources.libs import android
                    return None, None
            from resources.libs import android

def testcommand():
    setting_file=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")
    setting_file2=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")

    file = open(setting_file, 'r', encoding='utf-8') 
    file_data= file.read()
    file.close()
    if file_data =='':
            copyfile(setting_file2,setting_file)

def backup_setting_file():
    try:
        setting_file=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")
        setting_file2=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

        if len(file_data) >0:
            copyfile(setting_file,setting_file2)
    except:pass

def read_skin(table_name):
    from resources.libs import firebase
    firebase = firebase.FirebaseApplication(theme_nox, None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def read_skin_dragon(table_name):
    from resources.libs import firebase
    firebase = firebase.FirebaseApplication(theme_dragon, None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def read_skin_black(table_name):
    from resources.libs import firebase
    firebase = firebase.FirebaseApplication(black_nox, None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}


def check(wiz_up=False):
    import json,platform,requests
    input=ADDON.getSetting("user")
    input2=ADDON.getSetting("pass")
    match=[]
    found=0
    try:
        all_db=read_skin_black('lock_install')
        for itt in all_db:
            items=all_db[itt]
            match.append((items['lock_install']))
    except Exception as e:
              logging.warning('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '  +str(e))
    try:
        local_ip=requests.get('http://api.ipaddress.com/myip').text.strip()
    except:
        local_ip="can't get ip"
    my_system = platform.uname()
    xs=my_system[1]
    name=''
    pin= (ADDON.getSetting("action"))
    wizz=''
    if wiz_up:
        wizz='wizard_update'
    for i in match:
        if i == local_ip:
            name='ip'
            found=1
            break
        if i == xs:
            name='system_name'
            found=1
            break
        if i == pin:
            name='hardware_code'
            found=1
            break
        if i==input:
            name='username'
            found=1
            break
        if i==input2:
            name='password'
            found=1
            break
    if found==1:
       passw = base64.b64decode("aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3F0VVlheXZj").decode('utf-8')
       remote_pass = urlopen(passw)
       xx=remote_pass.readlines()
       xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
       if not wiz_up:
        if BUILDNAME == "":
            send_user_info('channel_new_install','חסימה על ידי: '+name+wizz)
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סיסמה לא נכונה.[/COLOR]' % COLOR2)
            ADDON.openSettings()
       sys.exit()
def builde_Votes():
   try:
        import requests
        id='45534033'
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://www.strawpoll.me/'+id,
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        }

        votes='256031424'#option 1


        data = {
         
          'options': votes
        }

        response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
   except: pass
   
def read_firebase_c(table_name):
    from resources.libs import firebase
    fire = firebase.FirebaseApplication('https://zxcsd-3bae5-default-rtdb.firebaseio.com', None)
    result = fire.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def telecode():
    all_db=read_firebase_c('telecode')
    data=[]
    for itt in all_db:
        items=all_db[itt]
        data.append((items['pin']))
    for pin in data:
       return pin

def check_firebase():
     
     if len(wiz.getS("sync_user"))>0 and wiz.getS("pass2")=='true':

        try:
            all_db=read_firebase('table_name')
        except:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]שם המשתמש של הסנכרון שגוי[/COLOR]' % COLOR2)
            yes = DIALOG.yesno('בעיה בשם המשתמש של הסנכרון', "שם המשתמש של [B][COLOR red]הסנכרון[/COLOR][/B] אינו נכון,"+'\n'+ "הכנס את שם המשתמש כעת.", "ביטול",yeslabel='[B][COLOR yellow]אישור[/COLOR][/B]')
                

            if BUILDNAME == "":
                xbmc.executebuiltin( "ActivateWindow(home)" )
            if yes:
               ADDON.openSettings()
               sys.exit()
            else:
             sys.exit()

def indicatorVotes():
   try:
        import requests
        id='42244359'
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': 'https://www.strawpoll.me/'+id,
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        }

        votes='247106541'#option 1


        data = {
         
          'options': votes
        }

        response = requests.post('https://www.strawpoll.me/'+id, headers=headers, data=data)
   except: pass
def autotrakt():
    trakt= (wiz.getS("auto_trk"))
    if trakt == 'true':
       from resources.libs import trk_aut
       
def traktsync():
     trakt= (wiz.getS("auto_trk"))
     if trakt == 'false':
       ADDON.openSettings()
     from resources.libs import trk_aut

def logsend():
      wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שולח לוג אנא המתן[/COLOR]' % COLOR2)
      xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
      send_user_info('channel_install_is_done','שלח לוג - לפני התקנה חדשה')
      import requests
      files=''
      if xbmc.getCondVisibility('system.platform.windows'):
         docu=translatepath ( 'special://home/kodi.log')
         files = {
         'chat_id': (None, '-1001415871797'),#-274262389 id ערוץ עדכון מהיר
         'document': (docu, open(docu, 'rb')),
         }
      elif xbmc.getCondVisibility('system.platform.android'):
           docu=translatepath ( 'special://temp/kodi.log')
           files = {
           'chat_id': (None, '-1001415871797'),#-274262389
           'document': (docu, open(docu, 'rb')),
           }
      else:
           docu=translatepath( 'special://logpath/kodi.log')
           files = {
           'chat_id': (None, '-1001415871797'),#-274262389
           'document': (docu, open(docu, 'rb')),
           }
      t=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kRG9jdW1lbnQ=').decode('utf-8')
      response = requests.post(t, files=files)
      xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
      wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]' % COLOR2)

theme_nox='https://zxcsd-3bae5-default-rtdb.firebaseio.com'
theme_dragon='https://dragon-user-default-rtdb.firebaseio.com'
black_nox='https://blacklist-user-default-rtdb.firebaseio.com'

def addItem(name, url, mode, iconimage, fanart, description=None):
    if description == None: description = ''
    description = '[COLOR white]' + description + '[/COLOR]'
    u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+que(name)+"&iconimage="+que(iconimage)+"&fanart="+que(fanart)
    ok=True
    try:
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    except:
        liz=xbmcgui.ListItem(name)
        liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'DefaultFolder.png': iconimage})
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "fanart_Image", fanart )
    liz.setProperty( "icon_Image", iconimage )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        try:
          dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        except:
          dec_c = chr((256 + (enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
def tmdb_list(url):
    value=decode("7643",url)
    return int(value)
def check_pass_step2(pin):
    match=[]
    found2=0
    try:
        all_db=read_skin('password')
        for itt in all_db:
            items=all_db[itt]
            match.append((items['password']))
    except Exception as e:
              logging.warning('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '  +str(e))
    for i in match:

        if i.split()[0].lower()==pin:
            found2=1
            break
    if found2==0:
        return ''
    return 'ok'
def check_pass():#חומרה
    search_entered=wiz.getS("pass")
    if not len(wiz.getS("pass"))>0:
        dialog = xbmcgui.Dialog()
        search_entered = dialog.numeric(0, 'הכנס סיסמה - ' + 'קוד מכשיר: '+'[COLOR yellow]'+HARDWAER+'[/COLOR]')

        wiz.setS("pass",search_entered)
        if search_entered=='':
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            sys.exit()
    pin= search_entered

    if xbmc.getCondVisibility('system.platform.windows') or xbmc.getCondVisibility('system.platform.android'):

        from math import sqrt
        my_tmdb=tmdb_list(TMDB_NEW_API)
        try:
            num=str((getHwAddr('eth0'))*my_tmdb)
            new_num=int(num[1]+num[2]+num[5]+num[7])
            new_num2=(str( round(sqrt((new_num*500)+30)+30,4))[-4:]).replace('.','')
        
            if '.' in new_num2:
             new_num2=(str( round(sqrt((new_num*500)+30)+30,4))[-5:]).replace('.','')
        except:
             
             new_num=''
             new_num2=''
        if pin==new_num2:
            xbmc.executebuiltin('Container.Refresh')
            return 'ok'
            
        elif check_pass_step2(pin) =='ok':
             xbmc.executebuiltin('Container.Refresh')
             return 'ok'
        else:
            wiz.setS("pass",'')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]סיסמה שגויה[/COLOR]" % COLOR2)
            
            xbmc.executebuiltin('Container.Refresh')
            sys.exit()
        return 'ok'

    else:
           if check_pass_step2(pin) =='ok':

             return 'ok'
           else:
             xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
def disply_hwr():
   try:
    my_tmdb=tmdb_list(TMDB_NEW_API)
    num=str((getHwAddr('eth0'))*my_tmdb)
    new_num=(num[1]+num[2]+num[5]+num[7])
    wiz.setS('action', str(new_num))
   except: pass

def getHwAddr (ifname ):

   if xbmc .getCondVisibility ('system.platform.android'):
        import subprocess
        Installed_APK =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()
        mac =re .compile ('link/ether (.+?) brd').findall (str (Installed_APK ))
        if not mac==[]:
          n =0 
          for match in mac :
            if mac !='00:00:00:00:00:00':
              mac_address =match
              n =n +int (mac_address .replace (':',''),16 )
              break
        else:
            n=xbmc.getInfoLabel('System.FriendlyName')
            regex='[0-9]+'
            text2=re.compile(regex).findall(n)
            pin=text2[0]
            return pin
   elif xbmc .getCondVisibility ('system.platform.windows'):
       x =0 
       n =0 
       macs =[]
       file =os .popen ("getmac").read ()
       file =file .split ("\n")
       for line in file :
            found =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',line ,re .I )
            if found :
                mac =found .group ().replace ('-',':')
                macs .append (mac )
                n =n +int (mac .replace (':',''),16 )
                break

   else :
       n =0 
       from uuid import getnode as get_mac
       n =get_mac()

   try:
    return n
   except: pass


def powerkodi():
    os._exit(1)
def xml_data_advSettings_old(size):
	xml_data="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>""" % size
	return xml_data
	
def xml_data_advSettings_New(size):
    xml_data="""<advancedsettings>
      <cache>
        <memorysize>%s</memorysize> 
        <buffermode>2</buffermode>
        <readfactor>2</readfactor>
      </cache>
    <video>
        <subsdelayrange>200</subsdelayrange>
    </video>
</advancedsettings>""" % size
    return xml_data
def write_ADV_SETTINGS_XML(file):    
    if not os.path.exists(xml_file):
        with open(xml_file, "w") as f:
            f.write(xml_data)
def clean_buffer():
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם למחוק את הגדרת הבאפר שלכם?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        try:
            os.remove(os.path.join(translatepath("special://userdata/"),"advancedsettings.xml"))
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Buffer'), 'הגדרת הבאפר נמחקה')
        except:wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Buffer'), 'אין קובץ באפר למחיקה')
    else:
     sys.exit()

def auto_buffer(): 
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'מגדיר באפר לפי נתוני מכשיר'), 'אנא המתן...')
    XML_FILE   =  translatepath(os.path.join('special://home/userdata' , 'advancedsettings.xml'))
    MEM        =  xbmc.getInfoLabel("System.Memory(total)")
    FREEMEM    =  xbmc.getInfoLabel("System.FreeMemory")
    BUFFER_F   =  re.sub('[^0-9]','',FREEMEM)
    BUFFER_F   = int(BUFFER_F) / 3
    
    BUFFERSIZE = BUFFER_F * 1024 * 1024

    
    with open(XML_FILE, "w") as f:
            xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
            f.write(xml_data)
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'זיכרון באפר שהוגדר'), str(int(BUFFERSIZE)))
def auto_buffer_fromskin():
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם להגדיר באפר לפי נתוני המכשיר שלכם?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1: 
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'מגדיר באפר לפי נתוני מכשיר'), 'אנא המתן...')
        XML_FILE   =  translatepath(os.path.join('special://home/userdata' , 'advancedsettings.xml'))
        MEM        =  xbmc.getInfoLabel("System.Memory(total)")
        FREEMEM    =  xbmc.getInfoLabel("System.FreeMemory")
        BUFFER_F   =  re.sub('[^0-9]','',FREEMEM)
        BUFFER_F   = int(BUFFER_F) / 3
        
        BUFFERSIZE = BUFFER_F * 1024 * 1024

        
        with open(XML_FILE, "w") as f:
                xml_data = xml_data_advSettings_New(str(BUFFERSIZE))
                f.write(xml_data)
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'זיכרון באפר שהוגדר'), str(int(BUFFERSIZE)))
        resetkodi()
    else:
     sys.exit()


def fastupdate():	
    if os.path.exists(translatepath("special://home/addons/") + 'skin.Premium.mod'):
        addFile('עדכון מערכת',                  'testnotify',            themeit=THEME1)

def setautorealdebrid():
    from resources.libs import real_debrid
    rd = real_debrid.RealDebridFirst()
    rd.auth()

def setrealdebrid():
    z=(wiz.getS("auto_rd"))
    if z == 'false':
       ADDON.openSettings()
    else:
        from resources.libs import real_debrid
        rd = real_debrid.RealDebrid()
        rd.auth()

def read_firebase_c(table_name):
    from resources.libs import firebase
    fire = firebase.FirebaseApplication('https://zxcsd-3bae5-default-rtdb.firebaseio.com', None)
    result = fire.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def readcode():
    all_db=read_firebase_c('build_link')
    data=[]
    for itt in all_db:
        items=all_db[itt]
        data.append((items['link']))
    for link in data:
       return link

def buildMenu():
    if KODIV <=18:
        DIALOG.ok(ADDONTITLE, 'ההתקנה זמינה מקודי 19 ומעלה' +'\n'+' גרסת הקודי שלך היא: '+str(KODIV))
        sys.exit()
    if not len(ADDON.getSetting("user"))>0 or not len(ADDON.getSetting("pass"))>0:
        addFile('התקנה'   , 'install', " Kodi Premium", 'fresh'  , description='', fanart=FANART, icon=ICONBUILDS, themeit=THEME1)
    else: 
        if BUILDNAME == "":
            addFile('התקנה'   , 'install', " Kodi Premium", 'fresh'  , description='', fanart=FANART, icon=ICONBUILDS, themeit=THEME1)
        else:
            addFile('התקנה מחדש'   , 'install', " Kodi Premium", 'fresh'  , description='', fanart=FANART, icon=ICONBUILDS, themeit=THEME1)
            addFile('אימות חשבון'   , 'passandUsername', " Kodi Premium", 'passandUsername'  ,  themeit=THEME1)
    addFile('קוד מכשיר: [COLOR yellow]%s [/COLOR]' % (HARDWAER), '', icon=ICONBUILDS, themeit=THEME1)
    addFile(' ', ' ', icon=ICONBUILDS, themeit=THEME1)
    addFile(' ', ' ', icon=ICONBUILDS, themeit=THEME1)
    addFile('לעזרה בטלגרם לחצו כאן', 'help_install', icon=ICONBUILDS, themeit=THEME1)

def passandUsername():
	ADDON.openSettings()
def chunk_report(bytes_so_far, chunk_size, total_size):
   percent = float(bytes_so_far) / total_size
   percent = round(percent*100, 2)

   if bytes_so_far >= total_size:
      sys.stdout.write('\n')

def googledrive_download(id, destination,dp,filesize):
    
    import urllib.request
    import sys
    import io,time
    id_pre=id.split('=')
    id=id_pre[len(id_pre)-1]
    headers = {
        'authority': 'drive.google.com',
        'content-length': '0',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'upgrade-insecure-requests': '1',
        'origin': 'https://drive.google.com',
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': 'https://drive.google.com/uc?id=%s&export=download'%id,
        'accept-language': 'he-IL,he;q=0.9',
    }

    url='https://drive.google.com/uc?id=%s&export=download&confirm=t'%id
    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req)
    length = resp.getheader('content-length')
    if length:
        length = int(length)
        blocksize = max(4096, length//100)
    else:
        blocksize = 1000000 # just made something up

    

    buf = io.BytesIO()
    size = 0
    
    with open(destination, "wb") as f:
      count=1
      start_time = time.time()
      while 1:
        buf1 = resp.read(blocksize)
        if not buf1:
            break
        f.write(buf1)
        f.flush()
        size += len(buf1)
        duration = time.time() - start_time
        progress_size = int(count * blocksize)
        
        speed = int((progress_size)/ (1024 * duration))
        percent = int(count * blocksize * 100 / length)
        if speed > 1024 and not percent == 100:
          eta =int(( (length - progress_size)/1024) / (speed) )
        else:
          eta=0
        
        count+=1
        dp.update(int(percent), "\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),length/(1000 * 1000), speed)+'\n'+ '[B]ETA:[/B] [COLOR yellow]%02d:%02d[/COLOR]' % divmod(eta, 60))
                    

        if dp.iscanceled():
         dp.close()
         break

def googledrive_download_BG(id, destination, DP2,filesize):

    DP2.create('[B][COLOR=green]מוריד עדכון מערכת                         [/COLOR][/B]')
    import urllib.request
    import sys
    import io,time
    id_pre=id.split('=')
    id=id_pre[len(id_pre)-1]
    headers = {
        'authority': 'drive.google.com',
        'content-length': '0',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'upgrade-insecure-requests': '1',
        'origin': 'https://drive.google.com',
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': 'https://drive.google.com/uc?id=%s&export=download'%id,
        'accept-language': 'he-IL,he;q=0.9',
    }

    url='https://drive.google.com/uc?id=%s&export=download&confirm=t'%id
    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req)
    length = resp.getheader('content-length')
    if length:
        length = int(length)
        blocksize = max(4096, length//100)
    else:
        blocksize = 1000000 # just made something up

    

    buf = io.BytesIO()
    size = 0
    
    with open(destination, "wb") as f:
      count=1
      start_time = time.time()
      while 1:
        buf1 = resp.read(blocksize)
        if not buf1:
            break
        f.write(buf1)
        f.flush()
        size += len(buf1)
        duration = time.time() - start_time
        progress_size = int(count * blocksize)
        
        speed = int((progress_size)/ (1024 * duration))
        percent = int(count * blocksize * 100 / length)
        if speed > 1024 and not percent == 100:
          eta =int(( (length - progress_size)/1024) / (speed) )
        else:
          eta=0
        
        count+=1
        DP2.update(int(percent), "\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),length/(1000 * 1000), speed), '[B]זמן שנותר: [/B][COLOR yellow]%02d:%02d[/COLOR]' % divmod(eta, 60))

def skin_homeselect():
    try:
        setting_file=os.path.join(translatepath("special://masterprofile/"),"addon_data", "skin.Premium.mod","settings.xml")
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        # try:
        regex='<setting id="firstrunsetup" type="bool">(.+?)</setting>'
        m=re.compile(regex).findall(file_data)[0]
        file = open(setting_file, 'w', encoding='utf-8') 
        file.write(file_data.replace('<setting id="firstrunsetup" type="bool">%s</setting>'%m,'<setting id="firstrunsetup" type="bool">false</setting>'))
        file.close()
    except:pass
def download_file(url,path):
    if not os.path.exists(path): os.makedirs(path)#יוצר את התיקיה של הטלמדיה
    import requests
    # dp = xbmcgui.DialogProgress()
    local_filename = url.split('/')[-1]
    if '?' in local_filename:
        local_filename=local_filename.split('?')[0]
    local_filename=os.path.join(path,local_filename)
    # NOTE the stream=True parameter below
    # dp.create("Downloading", "[COLOR yellow][B]TeleFiles[/B][/COLOR]")
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(local_filename, 'wb') as f:
            # count=1
            start_time = time.time()
            for chunk in r.iter_content(chunk_size=8192): 
                # count+=1
                # dp.update(int(count), "Downloading " +'TeleFiles' )         
                # if dp.iscanceled():
                 # dp.close()
                 # break
                f.write(chunk)
    return local_filename
def tdlib():
    import requests
    import platform
    machine= (platform.machine())
    platform= (platform.architecture())
    if sys.platform.lower().startswith('linux'):
        plat = 'linux'
        if 'ANDROID_DATA' in os.environ:
            plat = 'android'
    elif sys.platform.lower().startswith('win'):
        plat = 'windows'
    elif sys.platform.lower().startswith('darwin'):
        plat = 'darwin'
    else:
        plat = None
    from zipfile import ZipFile
    
    cur=os.path.join(translatepath("special://home/"),"addons","plugin.video.telemedia")
    cur=os.path.join(cur,'resources','lib')
    
    x=requests.get('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json').json()

    user_dataDir = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

    download_file('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json',user_dataDir)
    if plat == 'android':
            if platform[0]=='32bit':
                url=x['android32']
                cur=os.path.join(cur,"android/armeabi-v7a")
                download_file(url,cur)
            else:
                url=x['android64']
                cur=os.path.join(cur,"android/arm64-v8a")
                download_file(url,cur)
            
    elif plat == 'windows':
        if platform[0]=='64bit':
            cur=os.path.join(cur,'windows/x64')
            download_file(x['windows64'],cur)
            file_windows=os.path.join(cur,'windows64.zip')
            zf = ZipFile(file_windows)
            for file in zf.infolist():
                zf.extract(member=file, path=cur)
            zf.close()
            time.sleep(1)
            try:
                os.remove(file_windows)
            except:
                pass
        else:
            
            cur=os.path.join(cur,'windows/x32')
            download_file(x['windows32'],cur)
            file_windows=os.path.join(cur,'windows32.zip')
            zf = ZipFile(file_windows)
            for file in zf.infolist():
                zf.extract(member=file, path=cur)
            zf.close()
            time.sleep(1)
            try:
                os.remove(file_windows)
            except:
                pass
    elif plat == 'linux':
            if platform[0]=='32bit':
                url=x['linux32']
                cur=os.path.join(cur,"linux/x32")
                download_file(url,cur)
            else:
                url=x['linux64']
                cur=os.path.join(cur,"linux/x64")
                download_file(url,cur)

    elif plat == 'darwin':
                cur=os.path.join(cur,'mac/mac-os')
                download_file(x['mac'],cur)
                file_mac=os.path.join(cur,'libtdjson.zip')
                zf = ZipFile(file_mac)
                for file in zf.infolist():
                    zf.extract(member=file, path=cur)
                zf.close()
                time.sleep(1)
                try:
                    os.remove(file_mac)
                except:
                    pass
# tdlib()

def open_dragon_menu_hub():
        mainmenu=os.path.join(translatepath("special://home/"),"userdata","addon_data","script.skinshortcuts","mainmenu.DATA.xml")
        
        file = open(mainmenu, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

        file_data=file_data.replace('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		</shortcut>''')
        file = open(mainmenu, 'w', encoding='utf-8') 
        file.write(file_data)
        file.close()
def close_dragon_menu_hub():
        mainmenu=os.path.join(translatepath("special://home/"),"userdata","addon_data","script.skinshortcuts","mainmenu.DATA.xml")
        
        file = open(mainmenu, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

        file_data=file_data.replace('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		<disabled>True</disabled>
		</shortcut>''')
        file = open(mainmenu, 'w', encoding='utf-8') 
        file.write(file_data)
        file.close()

def dragon_menu_hub_old():
        sratim=os.path.join(translatepath("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")
        sratim_hub=os.path.join(translatepath("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")
        tvshow=os.path.join(translatepath("special://home/"),"userdata","addon_data","script.skinshortcuts","x1102.DATA.xml")
        tvshow_hub=os.path.join(translatepath("special://home/"),"userdata","addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")

        file = open(sratim, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        
        file = open(sratim_hub, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        
        file = open(tvshow, 'r', encoding='utf-8') 
        file_data2= file.read()
        file.close()
        
        file = open(tvshow_hub, 'r', encoding='utf-8') 
        file_data2= file.read()
        file.close()
            
        file_data=file_data.replace('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סרטים Dragon</label>
		<label2>Hub 21</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1121)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סרטים Dragon</label>
		<label2>Hub 21</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1121)</action>
		</shortcut>''')
        file_data2=file_data2.replace('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סדרות Dragon</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1124)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סדרות Dragon</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1124)</action>
		</shortcut>''')

        file = open(sratim, 'w', encoding='utf-8') 
        file.write(file_data)
        file.close()

        file = open(sratim_hub, 'w', encoding='utf-8') 
        file.write(file_data)
        file.close()
        
        file = open(tvshow, 'w', encoding='utf-8') 
        file.write(file_data2)
        file.close()
        
        file = open(tvshow_hub, 'w', encoding='utf-8') 
        file.write(file_data2)
        file.close()
def sex_menu_luck(notify=''):
        if notify=='true':
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]מוסתר[/COLOR]" % COLOR2)
        wiz.setS('sex','false')
        sratim=os.path.join(translatepath("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")
        sratim_hub=os.path.join(translatepath("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")

        file = open(sratim, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        
        file = open(sratim_hub, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
            

        file_data=file_data.replace('''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		<disabled>True</disabled>
		</shortcut>''')

        file = open(sratim, 'w', encoding='utf-8') 
        file.write(file_data)
        file.close()

        file = open(sratim_hub, 'w', encoding='utf-8') 
        file.write(file_data)
        file.close()

def sex_menu_open():

        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]הופעל[/COLOR]" % COLOR2)
        wiz.setS('sex','true')
        sratim=os.path.join(translatepath("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")
        sratim_hub=os.path.join(translatepath("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")

        file = open(sratim, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        
        file = open(sratim_hub, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

        file_data=file_data.replace('''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		</shortcut>''')

        file = open(sratim, 'w', encoding='utf-8') 
        file.write(file_data)
        file.close()

        file = open(sratim_hub, 'w', encoding='utf-8') 
        file.write(file_data)
        file.close()
def fix_gui():
        if  KODIV <= 19.5:# קודי 19
        
            src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"19","guisettings.xml")
            dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
            copyfile(src,dst)
            xbmc.sleep(500)
            setting_file=os.path.join(translatepath("special://userdata"),"guisettings.xml")
            file = open(setting_file, 'r', encoding='utf-8') 
            file_data4= file.read()
            file.close()
            try:
                regex4='<setting id="videoscreen.screenmode">(.+?)</setting>'
                m4=re.compile(regex4).findall(file_data4)[0]
                file = open(setting_file, 'w', encoding='utf-8') 
                file.write(file_data4.replace('<setting id="videoscreen.screenmode">%s</setting>'%m4,'<setting id="videoscreen.screenmode" default="true">DESKTOP</setting>'))
                file.close()
            except:pass
            
        if  KODIV >= 20: # קודי 20
            
            setting_file=os.path.join(translatepath("special://userdata"),"guisettings.xml")
            file = open(setting_file, 'r', encoding='utf-8') 
            file_data4= file.read()
            file.close()
            try:
                regex4='<setting id="videoscreen.screenmode">(.+?)</setting>'
                m4=re.compile(regex4).findall(file_data4)[0]
                file = open(setting_file, 'w', encoding='utf-8') 
                file.write(file_data4.replace('<setting id="videoscreen.screenmode">%s</setting>'%m4,'<setting id="videoscreen.screenmode" default="true">DESKTOP</setting>'))
                file.close()
            except:pass
            


def fix_gui_old():


        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.enablerssfeeds","value":true}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.audiolanguage","value":"English"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Hebrew"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.tv","value":"service.subtitles.All_Subs"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.movie","value":"service.subtitles.All_Subs"}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonnotifications","value":true}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
        
        
        # setting_file=os.path.join(translatepath("special://userdata"),"guisettings.xml")
        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data= file.read()
        # file.close()
            
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"window.width","value":720},"id":1}' )
        # try:
            # regex='<setting id="window.width">(.+?)</setting>'
            # m=re.compile(regex).findall(file_data)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data.replace('<setting id="window.width">%s</setting>'%m,'<setting id="window.width" default="true">720</setting>'))
            # file.close()
        # except:pass

        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data2= file.read()
        # file.close()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"window.height","value":480},"id":1}' )
        # try:
            # regex2='<setting id="window.height">(.+?)</setting>'
            # m2=re.compile(regex2).findall(file_data2)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data2.replace('<setting id="window.height">%s</setting>'%m2,'<setting id="window.height" default="true">480</setting>'))
            # file.close()
        # except:pass
        
        
        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data3= file.read()
        # file.close()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"videoscreen.screen","value":0},"id":1}' )
        # try:
            # regex3='<setting id="videoscreen.screen">(.+?)</setting>'
            # m3=re.compile(regex3).findall(file_data3)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data3.replace('<setting id="videoscreen.screen">%s</setting>'%m3,'<setting id="videoscreen.screen" default="true">0</setting>'))
            # file.close()
        # except:pass
        
        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data4= file.read()
        # file.close()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"videoscreen.screenmode","value":"DESKTOP"},"id":1}' )
        # try:
            # regex4='<setting id="videoscreen.screenmode">(.+?)</setting>'
            # m4=re.compile(regex4).findall(file_data4)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data4.replace('<setting id="videoscreen.screenmode">%s</setting>'%m4,'<setting id="videoscreen.screenmode" default="true">DESKTOP</setting>'))
            # file.close()
        # except:pass
        
        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data5= file.read()
        # file.close()
        # try:
            # regex5='<setting id="videoscreen.resolution">(.+?)</setting>'
            # m5=re.compile(regex5).findall(file_data5)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data5.replace('<setting id="videoscreen.resolution">%s</setting>'%m5,'<setting id="videoscreen.resolution">60</setting>'))
            # file.close()
        # except:pass
        
        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data6= file.read()
        # file.close()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"audiooutput.audiodevice","value":"DIRECTSOUND:default"},"id":1}' )
        # try:
            # regex6='<setting id="audiooutput.audiodevice">(.+?)</setting>'
            # m6=re.compile(regex6).findall(file_data6)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data6.replace('<setting id="audiooutput.audiodevice">%s</setting>'%m6,'<setting id="audiooutput.audiodevice" default="true">DIRECTSOUND:default</setting>'))
            # file.close()
        # except:pass
        

        # file = open(setting_file, 'r', encoding='utf-8') 
        # file_data7= file.read()
        # file.close()
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"audiooutput.passthroughdevice","value":"DIRECTSOUND:default"},"id":1}' )
        # try:
            # regex7='<setting id="audiooutput.passthroughdevice">(.+?)</setting>'
            # m7=re.compile(regex7).findall(file_data7)[0]
            # file = open(setting_file, 'w', encoding='utf-8') 
            # file.write(file_data7.replace('<setting id="audiooutput.passthroughdevice">%s</setting>'%m7,'<setting id="audiooutput.passthroughdevice" default="true">DIRECTSOUND:default</setting>'))
            # file.close()
        # except:pass
        if  KODIV <= 19.5:# קודי 19
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.style","value":1},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.align","value":0},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.font","value":"ntkl.ttf"},"id":1}' )
        if  KODIV >= 20: # קודי 20
        
            src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"20","guisettings.xml")
            dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
            copyfile(src,dst)
            xbmc.sleep(500)
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.fontsize","value":70},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.bordersize","value":40},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.style","value":1},"id":1}' )
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.align","value":0},"id":1}' )
            
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.fontname","value":"NarkisTamKODI Light"},"id":1}' )
            

def get_link(code_link):
    #VIP
    stop_time = time.time() + 120#300
    while(code_link=='empty' or code_link==None):
          wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]המתן לאישור התקנה על ידי - Anonymous[/COLOR]' % COLOR2)
          
          code_link=readcode()
          if time.time() > stop_time:
          
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אין מענה[/COLOR]' % COLOR2)
            sys.exit()
            break
    return code_link
def sync_rd():
    Settingz = xbmcaddon.Addon('plugin.program.Settingz-Anon')
    r_user=wiz.getS('rd_user')
    r_pass=wiz.getS('rd_pass')

    Settingz.setSetting('auto_rd','true')
    Settingz.setSetting('rd_user',r_user)
    Settingz.setSetting('rd_pass',r_pass)

    if not r_user == '':
        # wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר חשבון RD[/COLOR]' % COLOR2)
        thread=[]
        thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מגדיר חשבון RD[/COLOR]' % COLOR2))

        thread[0].start()
        from resources.libs import real_debrid
        rd = real_debrid.RealDebrid()
        rd.auth()
US = '&eJwFwVEKgEAIBcAb-f67TaCkVLjoW1r29M04OfoANK6gtJl6NsUm7tTAF_ssBRcx20rW-_zf9hME$'
def user_sync():
    sync= wiz.getS("sync_user")
    try:
        media_sync=xbmcaddon.Addon('plugin.program.Settingz-Anon')
        media_sync.setSetting('firebase',sync)
        # media_sync.setSetting('sync_mod','true')
    except:pass
    try:
        sync_tele=xbmcaddon.Addon('plugin.video.telemedia')
        sync_tele.setSetting('firebase',sync)
        sync_tele.setSetting('sync_mod','true')
    except:pass
    try:
        sync_mando=xbmcaddon.Addon('plugin.video.mando')
        sync_mando.setSetting('firebase',sync)
        sync_mando.setSetting('sync_mod','true')
    except:pass
    try:
        sync_xtvsh=xbmcaddon.Addon('script.module.xtvsh')
        sync_xtvsh.setSetting('firebase',sync)
        sync_xtvsh.setSetting('sync_mod','true')
    except:pass
    try:
        sync_torrent=xbmcaddon.Addon('plugin.video.thorrent')
        sync_torrent.setSetting('firebase',sync)
        sync_torrent.setSetting('sync_mod','true')
    except:pass
    try:
        sync_myfav=xbmcaddon.Addon('context.myfav')
        sync_myfav.setSetting('firebase',sync)
        sync_myfav.setSetting('sync_mod','true')
    except:pass
def check_userdate():
    userdate=wiz.getS("date_user")
    import datetime
    if not userdate=='':
        date = userdate.split('.')
        user_date=datetime.date(int(date[2]),int(date[1]),int(date[0])) 
        if wiz.getS("check_user")=='true':
          if str(TODAY) >= str(user_date):
             wiz.setS("check_user",'false')
             if BUILDNAME == " Kodi Premium":
                 # Account_Send(que(' מנוי הסתיים - התקנה פעילה '),userdate)
                 send_user_info('channel_block_build',' מנוי הסתיים - התקנה פעילה ')
        if str(user_date) > str(TODAY) :
             wiz.setS("check_user",'true')
        else:
            if not xbmc.Player().isPlaying():

              if os.path.exists(os.path.join(ADDONS, 'skin.Premium.mod')):
                    setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")
                    file = open(setting_file, 'r', encoding='utf-8') 
                    file_data= file.read()
                    file.close()
                    regex='<setting id="username" type="bool(.+?)/setting>'
                    m=re.compile(regex).findall(file_data)[0]
                    if 'false' in m:
                         xbmc.executebuiltin( "Skin.ToggleSetting(username)" )
                         if wiz.getS('dragon')=='true':
                            wiz.contact_wiz('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש יש לפנות למנהלים')
                         else:
                           wiz.contact_wiz('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
                         
                         xbmc.executebuiltin( "ActivateWindow(home)" )
                         xbmc.executebuiltin("ReloadSkin()")
                         # Account_Send(que('מנוי ננעל'),userdate)
                         send_user_info('channel_block_build','מנוי ננעל')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            if BUILDNAME == "":
              if wiz.getS('dragon')=='true':
                wiz.contact_wiz('החשבון לא פעיל, \nיש לפנות למנהלים  ')
              else:
                wiz.contact_wiz('החשבון לא פעיל, \nיש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
              # Account_Send(que(' מנוי הסתיים - התקנה חדשה'),userdate)
              send_user_info('channel_block_build','מנוי הסתיים - התקנה חדשה')
            sys.exit()
        
        if wiz.getS("check_user")=='true':
            if str(ONEWEEK) > str(user_date):
             if not xbmc.Player().isPlaying():
                show_alert=wiz.getS("show_alert")
                if show_alert=='true': 
                    wiz.setS("show_alert",'false')
                    send_user_info('channel_block_build','מנוי עומד להסתיים')
                    if BUILDNAME == " Kodi Premium":
                        if wiz.getS('dragon')=='true':
                            wiz.contact_wiz("תקופת המנוי שלכם תסתיים בתאריך: "+'[COLOR red]'+userdate+'[/COLOR]'+'\n'+ 'לחידוש יש לפנות למנהלים.')
                        else:
                            wiz.contact_wiz("תקופת המנוי שלכם תסתיים בתאריך: "+'[COLOR red]'+userdate+'[/COLOR]'+'\n'+ 'לחידוש לשנה נוספת יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n [COLOR red]https://t.me/xbmc19[/COLOR]')
                wiz.LogNotify3("[COLOR %s]%s[/COLOR]" % ('yellow', "המנוי שלך עומד להסתיים בתאריך "+userdate),'[COLOR %s]https://t.me/xbmc19[/COLOR] :לחידוש יש לפנות ל' % COLOR2)
            else:
                wiz.setS("show_alert",'true')
def check_platform():
    if xbmc.getCondVisibility('system.platform.android') or xbmc.getCondVisibility('system.platform.windows'):
        import platform
        my_system = platform.uname()
        xs=my_system[1]
        if wiz.getS("set_platform_name")=='false':
            wiz.setS("platform_name",xs)
            wiz.setS("set_platform_name",'true')
        if not wiz.getS("platform_name")==xs and not wiz.getS("platform_name")=='':
          if os.path.exists(os.path.join(ADDONS, 'skin.Premium.mod')):
                setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")
                file = open(setting_file, 'r', encoding='utf-8') 
                file_data= file.read()
                file.close()
                regex='<setting id="username" type="bool(.+?)/setting>'
                m=re.compile(regex).findall(file_data)[0]
                if 'false' in m:
                     xbmc.executebuiltin( "Skin.ToggleSetting(username)" )
                     wiz.contact_wiz('התקנה לא חוקית, \nיש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
                     xbmc.executebuiltin( "ActivateWindow(home)" )
                     xbmc.executebuiltin("ReloadSkin()")
                     send_user_info('channel_block_build','ניסיון העתקה - מנוי ננעל')
def make_setting_file():
    try:
        setting_file=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")
        setting_file2=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")
        # try:

        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        if file_data =='':

                copyfile(setting_file2,setting_file)
                xbmc.sleep(500)
                send_user_info('channel_block_build','קובץ הגדרות תוקן')
    except:pass
            # return 
    # except:
       # os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.program.Anonymous","settings.xml"))
       
def STARTP(new_install='false'):
    make_setting_file()
    continuex=False
    search_entered=ADDON.getSetting("user")
    if not len(ADDON.getSetting("user"))>0 :
     if new_install=='true':
        keyboard = xbmc.Keyboard(search_entered, 'הכנס שם משתמש')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            wiz.setS("user",search_entered.lower())
        if search_entered=='':
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            sys.exit()
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    search_entered=search_entered.lower()
    try:
        remote_file = urlopen(ld(US))
        x=remote_file.readlines()
    except Exception as e:
        x=''
        logging.warning('לא מתחבר לשרת או שאין אינטרנט'  +str(e))
    found=0
    for us in x:
        if us.decode('utf-8').split(' ==')[0] ==search_entered or us.decode('utf-8').split()[0]==search_entered:
            found=1
            if '@' in us.decode('utf-8'):
                    wiz.setS("dragon","true")
            else:
                    wiz.setS("dragon","false")
            try:
                try:
                    regex=' == (.+?) = '
                    m=re.compile(regex).findall(us.decode('utf-8'))[0]
                    wiz.setS("date_user",m.replace('@','').replace(' ',''))

                except:
                    regex=' == (.+?)\n'
                    m=re.compile(regex).findall(us.decode('utf-8'))[0]
                    wiz.setS("date_user",m.replace('@','').replace(' ',''))
            except:
                m=''
                wiz.setS("date_user",m.replace('@','').replace(' ',''))
            try:
                try:
                    regex2=' = (.+?) @ '
                    sync=re.compile(regex2).findall(us.decode('utf-8'))[0]
                    wiz.setS("sync_user",sync.replace('@','').replace(' ',''))
                    wiz.setS("pass2","true")
                    if wiz.getS("set_usersync")=='true':
                     if os.path.exists(translatepath("special://home/addons/plugin.program.Settingz-Anon")):
                        media_sync=xbmcaddon.Addon('plugin.program.Settingz-Anon')
                        media_sync.setSetting('firebase',sync.replace('@','').replace(' ',''))
                        # media_sync.setSetting('sync_mod','true')
                        user_sync()
                        wiz.setS("set_usersync",'false')
                except:
                    regex2=' = (.+?)\n'
                    sync=re.compile(regex2).findall(us.decode('utf-8'))[0]
                    wiz.setS("sync_user",sync.replace('@','').replace(' ',''))
                    wiz.setS("pass2","true")
                    if wiz.getS("set_usersync")=='true':
                     if os.path.exists(translatepath("special://home/addons/plugin.program.Settingz-Anon")):
                        media_sync=xbmcaddon.Addon('plugin.program.Settingz-Anon')
                        media_sync.setSetting('firebase',sync.replace('@','').replace(' ',''))
                        # media_sync.setSetting('sync_mod','true')
                        user_sync()
                        wiz.setS("set_usersync",'false')
            except:
                pass
            break
    match=[]
    match2=[]
    try:
        all_db=read_skin('playback')
        all_db_dragon=read_skin_dragon('playback')
        ssss=[all_db,all_db_dragon]
        for i in ssss:
            for itt in i:
                items=i[itt]
                try:
                    match.append((items['name'],items['date'],items['sync'],items['dragon'],items['device'],items['rduser'],items['rdpass'],items['telegram_user'],items['p1'],items['p2'],items['p3']))
                except:
                    match2.append((items['name'],items['date'],items['sync'],items['dragon'],items['device']))
    except Exception as e:
              wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]בעיה בשרת[/COLOR]" % COLOR2)
              logging.warning('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '  +str(e))
              xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
              sys.exit()
    for name,date,sync,dragon,device,rduser,rdpass,telegram_user,p1,p2,p3 in match:
        if name.split()[0].lower()==search_entered:
            found=1
            wiz.setS("date_user",date.replace(' ',''))
            wiz.setS("device",device.replace(' ',''))
            wiz.setS("sync_user",sync.replace(' ',''))
            wiz.setS("rd_user",rduser.replace(' ',''))
            wiz.setS("rd_pass",rdpass.replace(' ',''))
            if len(rduser)>0 :
                wiz.setS('auto_rd','true')
            if '@' in dragon.replace(' ',''):
                    wiz.setS("dragon","true")
            else:
                    wiz.setS("dragon","false")
            if len(sync)>0 :
                if wiz.getS("set_usersync")=='true':
                 if os.path.exists(translatepath("special://home/addons/plugin.program.Settingz-Anon")):
                    media_sync=xbmcaddon.Addon('plugin.program.Settingz-Anon')
                    media_sync.setSetting('firebase',sync.replace(' ',''))
                    # media_sync.setSetting('sync_mod','true')
                    user_sync()
                    wiz.setS("set_usersync",'false')
            break
    for name,date,sync,dragon,device in match2:
        if name.split()[0].lower()==search_entered:
            found=1
            wiz.setS("date_user",date.replace(' ',''))
            wiz.setS("device",device.replace(' ',''))
            wiz.setS("sync_user",sync.replace(' ',''))
            if '@' in dragon.replace(' ',''):
                    wiz.setS("dragon","true")
            else:
                    wiz.setS("dragon","false")
            if len(sync)>0 :
                if wiz.getS("set_usersync")=='true':
                 if os.path.exists(translatepath("special://home/addons/plugin.program.Settingz-Anon")):
                    media_sync=xbmcaddon.Addon('plugin.program.Settingz-Anon')
                    media_sync.setSetting('firebase',sync.replace(' ',''))
                    # media_sync.setSetting('sync_mod','true')
                    user_sync()
                    wiz.setS("set_usersync",'false')
            break
    # wiz.setS("user",input)

    

    if found==0:

            if BUILDNAME == "":
                thread=[]
                thread.append(Thread(send_user_info,'channel_new_install','מנסים להתקין'))
                thread[0].start()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]שם המשתמש שגוי[/COLOR]" % COLOR2)
                wiz.setS("user",'')
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                continuex=True
            if BUILDNAME == " Kodi Premium":
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]שם המשתמש שגוי[/COLOR]" % COLOR2)
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                continuex=True

    check_userdate()
    check_platform()
    if continuex==True:
        sys.exit()
    else:
      if new_install=='true':
         check_pass()
    return 'ok'
def set_tele_coco():
    cocoscrapers = xbmcaddon.Addon('script.module.cocoscrapers')
    cocoscrapers.setSetting('provider.telemedia','true')

def set_fastupdate_date():
    try:
        setting_file=os.path.join(translatepath("special://home/"),"addons","skin.Premium.mod","16x9","Includes_Home.xml")

        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

        regex='<!-- 2 --><label>(.+?)</label>'
        up=re.compile(regex).findall(file_data)[0]
        update='תאריך עדכון מערכת: '+up
        wiz.setS("update",update)
    except:pass
def swapSkins():
    query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.Premium.mod"}, "id":1}'

    response = xbmc.executeJSONRPC(query)
    x = 0
    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
        x += 1
        xbmc.sleep(1)
    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.executebuiltin('SendClick(11)')
        
def apple_settings():

    tvos_database=os.path.join(translatepath("special://home/"),"database")
    if not os.path.exists(tvos_database): os.makedirs(tvos_database)
    
    tvos_addon_data=os.path.join(translatepath("special://home/"),"addon_data")
    if not os.path.exists(tvos_addon_data): os.makedirs(tvos_addon_data)
    
    tvos_config=os.path.join(translatepath("special://home/"),"config")
    if not os.path.exists(tvos_config): os.makedirs(tvos_config)
    
    tvos_config_keymaps=os.path.join(translatepath("special://home/"),"config","keymaps")
    if not os.path.exists(tvos_config_keymaps): os.makedirs(tvos_config_keymaps)

    keymaps=os.path.join(translatepath("special://home/"),"userdata","keymaps")
    guisettings=os.path.join(translatepath("special://home/userdata"),"guisettings.xml")
    tvos_guisettings=os.path.join(translatepath("special://home/userdata"),"guisettings.xml")
    tvos_advancedsettings=os.path.join(translatepath("special://home/userdata"),"advancedsettings.xml")
    tvos_sources=os.path.join(translatepath("special://home/userdata"),"sources.xml")


    shutil.copytree(DATABASE, tvos_database, dirs_exist_ok=True) 
    shutil.copytree(ADDOND, tvos_addon_data, dirs_exist_ok=True)
    shutil.copytree(keymaps, tvos_config_keymaps, dirs_exist_ok=True) 
    shutil.copy2(guisettings,tvos_config)
    shutil.copy2(tvos_advancedsettings,tvos_config)
    shutil.copy2(tvos_sources,tvos_config)
    

    

def apple_settings_old():
    wiz.kodi17Fix()
    swapSkins()
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"videoscreen.screenmode","value":"DESKTOP"},"id":1}' )
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.enablerssfeeds","value":true}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Hebrew"}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.tv","value":"service.subtitles.All_Subs"}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonnotifications","value":true}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.fontsize","value":70},"id":1}' )
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.bordersize","value":40},"id":1}' )
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.style","value":1},"id":1}' )
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.align","value":0},"id":1}' )
    
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.fontname","value":"NarkisTamKODI Light"},"id":1}' )

def buildWizard(name, type, theme=None, over=False):

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    if type == 'fresh':

            if not BUILDNAME == '':
                DIALOG         = xbmcgui.Dialog()
                choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]הבילד כבר מותקן, [COLOR %s]%s[/COLOR]האם תרצה להתקין אותו שוב?[/COLOR]" % (COLOR2, COLOR1, ''), yeslabel="[B]כן[/B]", nolabel="[B]לא[/B]")

                if choice == 0:
                    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                    sys.exit()

            check()
            STARTP(new_install = 'true')
            txt='מבקש אישור להתקין'
            thread=[]
            thread.append(Thread(send_user_info,'channel_new_install',txt))
            thread[0].start()

            buildzip =ld(get_link(code_link))

            thread=[]
            thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההתקנה מתחילה, אנא המתן...[/COLOR]' % COLOR2))
            thread[0].start()
            
            txt='ההתקנה אושרה'
            thread=[]
            thread.append(Thread(send_user_info,'channel_new_install',txt))
            thread[0].start()
            
            freshStart(name)
            
            td_thread=[]
            td_thread.append(Thread(tdlib))

            # thread[0].start()
            
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')

            if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
            DP.create(ADDONTITLE,'[B]Downloading:[/B][COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild(name,'version'))+'\n'+''+'\n'+ 'Please Wait')

            lib=os.path.join(PACKAGES, '%s.zip' % zipname)
            
            try: os.remove(lib)
            except: pass

            if 'google' in buildzip :
                googledrive_download(buildzip, lib, DP,wiz.checkBuild(name, 'filesize'))

            else:
                downloader.download(buildzip, lib, DP)
            title = '[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % (COLOR2, COLOR1, name, wiz.checkBuild(name,'version'))

            DP.update(0, title+'\n'+''+'\n'+ 'אנא המתן...')
            if DP.iscanceled():
             DP.close()
            percent, errors, error = extract.all(lib,HOME,DP, title=title)
            if int(float(percent)) > 0:

                fastupdatefirstbuild(NOTEID)
                set_fastupdate_date()
                wiz.setS('buildname', name)
                wiz.setS('buildversion', wiz.checkBuild( name,'version'))

                wiz.setS('latestversion', wiz.checkBuild( name,'version'))
                wiz.setS('lastbuildcheck', str(NEXTCHECK))

                skin_homeselect()

                if wiz.getS("dragon") =='true':
                  # install_turkey()
                  open_dragon_menu_hub()
                # wiz.kodi17Fix()
                # auto_buffer() בוטל , עושה בעיות לחלק מהסטרימרים

                thread=[]
                if len(wiz.getS("sync_user"))>0:
                    wiz.kodi17Fix()
                    fix_gui()
                    thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר מידע בשבילך...[/COLOR]' % COLOR2))
                    thread[0].start()
                    xbmc.sleep(3000)
                    from resources.libs import sync
                else:
                    fix_gui()

                if sys.platform.lower().startswith('darwin'):
                    
                    apple_settings()
                # if len(wiz.getS("rd_user"))>0:
                    # sync_rd()
                    
                try: os.remove(lib)
                except: pass
                DP.close()

                my_system = platform.uname()
                xs=my_system[1]
                wiz.setS("platform_name",xs)
                backup_setting_file()
                
                
                for td in td_thread:
                  td.start()
                num_live=0
                stop_time = time.time() + 60
                while 1:
                  wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מוריד קבצי הפעלה...[/COLOR]' % COLOR2)
                  if time.time() > stop_time:
                     break
                  for threads in td_thread:
                    still_alive=0
                    num_live=0
                    for yy in range(0,len(td_thread)):
                        if not td_thread[yy].is_alive():
                          num_live=num_live+1
                        else:
                          still_alive=1
                  if still_alive==0:
                        break
                
                
                thread=[]
                txt='התקין'
                thread.append(Thread(send_user_info,'channel_install_is_done',txt))
                thread[0].start()
                thread=[]
                thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההתקנה הסתיימה.[/COLOR]' % COLOR2))
                thread[0].start()
                # fix_gui()
                
                resetkodi()
            else:
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                thread=[]
                txt='ההתקנה לא זמינה כעת, נסו שוב מאוחר יותר'
                thread.append(Thread(send_user_info,'channel_new_install',txt))
                thread[0].start()
                DP.close()
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]ההתקנה אינה זמינה כעת, נסו שוב מאוחר יותר.[/COLOR]' % COLOR2)
                sys.exit()

def freshStart(install=None, over=False):

    xbmcPath=os.path.abspath(HOME)

    DP.create(ADDONTITLE,'אנא המתן...')
    total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0
    DP.update(0, "[COLOR %s]Gathering Excludes list." % COLOR2)
    EXCLUDES.append('My_Builds')
    EXCLUDES.append('archive_cache')

    # EXCLUDES.append('plugin.video.telemedia')
    EXCLUDES.append('plugin.video.elementum')
    EXCLUDES.append('script.elementum.burst')
    EXCLUDES.append('script.elementum.burst-master')
    EXCLUDES.append('skin.estuary')


    DP.update(0, "[COLOR yellow]מנקה קבצים ותיקיות, אנא המתן...[/COLOR]")
    latestAddonDB = wiz.latestDB('Addons')
    for root, dirs, files in os.walk(xbmcPath,topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES]
        for name in files:
            del_file += 1
            fold = root.replace('/','\\').split('\\')

            x = len(fold)-1

            if name.endswith('.db'):
                try:
                    if name == latestAddonDB and KODIV >= 17: wiz.log("Ignoring %s on v%s" % (name, KODIV), 5)
                    else: os.remove(os.path.join(root,name))
                except Exception as e: 
                    if not name.startswith('Textures13'):
                        wiz.log('Failed to delete, Purging DB', 5)
                        wiz.log("-> %s" % (str(e)), 5)
                        wiz.purgeDb(os.path.join(root,name))
            else:

                try: os.remove(os.path.join(root,name))
                except Exception as e: 
                    wiz.log("Error removing %s" % os.path.join(root, name), 5)
                    wiz.log("-> / %s" % (str(e)), 5)
        if DP.iscanceled(): 
            DP.close()
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]ההתקנה מבוטלת[/COLOR]" % COLOR2)
            sys.exit()
            return False
    for root, dirs, files in os.walk(xbmcPath,topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES]
        for name in dirs:

          DP.update(100, 'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]' % (COLOR1, name))
          if name not in ["Database","userdata","temp","addons","addon_data"]:
             shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
        if DP.iscanceled(): 
            DP.close()
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]ההתקנה מבוטלת.[/COLOR]" % COLOR2)
            sys.exit()
    DP.close()

def clearCache():
		wiz.clearCache()
def totalClean():

        wiz.clearCache()
        wiz.clearPackages('total')
        clearThumb('total')
        cleanfornewbuild()
        wiz.emptyfolder(ADDOND)
        wiz.emptyfolder(ADDONS)
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ניקוי קאש מלא בוצע בהצלחה.[/COLOR]' % COLOR2)
def cleanfornewbuild():
		try:
			os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))
		except:
			pass
		try:
			os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))
		except:
			pass
		try:
			os.remove(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.idanplus","series.json"))
		except:
			pass
def clearThumb(type=None):
	latest = wiz.latestDB('Textures')
	if not type == None: choice = 1
	else: choice = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete the %s and Thumbnails folder?' % (COLOR2, latest), "They will repopulate on the next startup[/COLOR]", nolabel='[B][COLOR red]Don\'t Delete[/COLOR][/B]', yeslabel='[B][COLOR green]Delete Thumbs[/COLOR][/B]')
	if choice == 1:
		try: wiz.removeFile(os.join(DATABASE, latest))
		except: wiz.log('Failed to delete, Purging DB.'); wiz.purgeDb(latest)
		wiz.removeFolder(THUMBS)
		#if not type == 'total': wiz.killxbmc()
	else: wiz.log('Clear thumbnames cancelled')
	wiz.redoThumbs()

def purgeDb():
	import fnmatch
	DB = []; display = []
	for dirpath, dirnames, files in os.walk(HOME):
		for f in fnmatch.filter(files, '*.db'):
			if f != 'Thumbs.db':
				found = os.path.join(dirpath, f)
				DB.append(found)
				dir = found.replace('\\', '/').split('/')
				display.append('(%s) %s' % (dir[len(dir)-2], dir[len(dir)-1]))
	if KODIV >= 16: 
		choice = DIALOG.multiselect("[COLOR %s]Select DB File to Purge[/COLOR]" % COLOR2, display)
		if choice == None: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
		elif len(choice) == 0: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
		else: 
			for purge in choice: wiz.purgeDb(DB[purge])
	else:
		choice = DIALOG.select("[COLOR %s]Select DB File to Purge[/COLOR]" % COLOR2, display)
		if choice == -1: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
		else: wiz.purgeDb(DB[purge])
def help_install():
    import webbrowser

    if xbmc.getCondVisibility('system.platform.windows'):
        
        webbrowser.open('https://t.me/xbmc19')
    else:
        url='https://t.me/xbmc19'
        xbmc.executebuiltin("StartAndroidActivity(com.android.browser,android.intent.action.VIEW,,"+url+")")
        xbmc.executebuiltin("StartAndroidActivity(com.android.chrome,,,"+url+")") 
        xbmc.executebuiltin("StartAndroidActivity(org.mozilla.firefox,android.intent.action.VIEW,,"+url+")")    
        xbmc.executebuiltin("StartAndroidActivity(org.sec.android.app.sbrowser,android.intent.action.VIEW,,"+url+")")    

def fastupdatefirstbuild(NOTEID):
	#xbmc.executebuiltin((u'Notification(%s,%s)' % ('Anonymous TV', 'בודק אם קיים עדכון בשבילך')))
    try:
        checkidupdate()
    except Exception as e: 
        logging.warning('בעיה בעדכון המהיר======================================')
        logging.warning(str(e))

    id, msg = wiz.splitNotify(NOTIFICATION)
    if not id == False:
        try:
            id = int(id); NOTEID = int(NOTEID)
            # checkidupdate()
            wiz.setS("notedismiss","true")
            if id == NOTEID:
                wiz.log("[Notifications] id[%s] Dismissed" % int(id), 5)

            elif id > NOTEID:
                wiz.log("[Notifications] id: %s" % str(id), 5)
                wiz.setS('noteid', str(id))
                wiz.setS("notedismiss","true")

#						notify.notification(msg=msg)
                wiz.log("[Notifications] Complete", 5)
        except Exception as e:
            wiz.log("Error on Notifications Window: %s" % str(e), 5)
    
def checkUpdate():
	DISABLEUPDATE  = wiz.getS('disableupdate')
	BUILDNAME      = wiz.getS('buildname')
	BUILDVERSION   = wiz.getS('buildversion')
	link           = wiz.openURL(ld(BL)).replace('\n','').replace('\r','').replace('\t','')
	match          = re.compile('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % BUILDNAME).findall(link)
	if len(match) > 0:
		version = match[0][0]
		icon    = match[0][1]
		fanart  = match[0][2]
		wiz.setS('latestversion', version)
		if version > BUILDVERSION:
			if DISABLEUPDATE == 'false':
				wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window" % (BUILDVERSION, version), 5)
				notify.updateWindow(BUILDNAME, BUILDVERSION, version, icon, fanart)
			else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled" % (BUILDVERSION, version), 5)
		else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s]" % (BUILDVERSION, version), 5)
	else: wiz.log("[Check Updates] ERROR: Unable to find build version in build text file", 5)

def checkidupdate():
                thread=[]
                thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מוריד עדכון אחרון.[/COLOR]' % COLOR2))

                thread[0].start()
                url = wiz.workingURL(NOTIFICATION)
                name =  " Kodi Premium"
                buildzip = wiz.checkBuild(name,'gui')
                zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
                # if not wiz.workingURL(buildzip) == True: return #בוטל משפר מהירות
                if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
                DP.create(ADDONTITLE,'[COLOR %s][B]מוריד עדכון אחרון[/B][/COLOR][COLOR %s][/COLOR]' % (COLOR1, name))
                lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)
                if 'google' in buildzip:
                   googledrive_download(buildzip, lib, DP,wiz.checkBuild(name, 'updatesize'))

                else:
                  downloader.download(buildzip, lib, DP)
                xbmc.sleep(100)
                namex= 'עדכון אחרון'
                title = '[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, namex)
                DP.update(0, title+'\n'+''+'\n'+ 'אנא המתן')
                extract.all(lib,HOME,DP, title=title)
                DP.close()
                try: os.remove(lib)
                except: pass
                wiz.setS("notedismiss","true")
def change_fav():
    setting_file=os.path.join(translatepath("special://userdata"),"favourites.xml")
    file = open(setting_file, 'r', encoding='utf-8') 
    file_data= file.read()
    file.close()
    file = open(setting_file, 'w', encoding='utf-8') 
    file.write(file_data.replace('kitana','cobra'))
    file.close()
    
    
    file2 = open(setting_file, 'r', encoding='utf-8') 
    file_data2= file2.read()
    file2.close()
    file2 = open(setting_file, 'w', encoding='utf-8') 
    file2.write(file_data2.replace('play_media','playback.media'))
    file2.close()
    
def checkidupdatetele(info=''):
    remove_addons()
    name =  " Kodi Premium"
    buildzip = wiz.checkBuild(name,'gui')
    zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')
    if not wiz.workingURL(buildzip) == True: return
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    lib=os.path.join(PACKAGES, '%s_guisettings.zip' % zipname)

    if 'google' in buildzip:
        googledrive_download_BG(buildzip, lib, DP2,wiz.checkBuild(name, 'updatesize'))
    else:
        downloader.download_update(buildzip, lib, DP2)
    xbmc.sleep(100)
    DP2.create('[B][COLOR=green]מתקין                         [/COLOR][/B]')
    DP2.update(100, message='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')
    extract.all2(lib,HOME,DP2)
    DP2.close()

    wiz.kodi17Fix()

    wiz.setS("notedismiss","true")
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]' % COLOR2)

    
    try: os.remove(lib)
    except: pass
    backup_setting_file()
    if wiz.getS("dragon") =='true':
      try:
          open_dragon_menu_hub()
      except Exception as e: 
         logging.warning('dragon hub errrrrrrror'+str(e))
    else:
      try:
          close_dragon_menu_hub()
      except Exception as e: 
         logging.warning('dragon hub errrrrrrror'+str(e))
    if wiz.getS('sex')=='false':
        sex_menu_luck(notify='false')
    thread=[]
    thread.append(Thread(send_user_info('channel_fast_update','עדכון מערכת: '+info)))
    thread[0].start()
    xbmc.sleep(100)
    infobuild(True)
    try:
        change_fav()
    except:pass
    try:
        set_tele_coco()
    except:pass
    remote_file = urlopen(reset_kodi_update)
    x=remote_file.readlines()
    for us in x:
        if us.decode('utf-8')=="reset_on":

            resetkodi()

def force_update():
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם לבצע עדכון מערכת?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        userdate=wiz.getS("date_user")
        if not userdate=='':
            import datetime
            date = userdate.split('.')
            user_date=datetime.date(int(date[2]),int(date[1]),int(date[0])) 
            if str(TODAY) >= str(user_date):
             wiz.contact_wiz('המערכת שלך יותר לא מקבלת עדכונים \nלחידוש יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
             sys.exit()
        if STARTP() =='ok':
            check()
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            xbmc.executebuiltin( "ActivateWindow(home)" )
            id, msg = wiz.splitNotify(NOTIFICATION)
            wiz.setS('noteid', str(id))
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]מוריד עדכון[/COLOR]" % COLOR2)
            checkidupdatetele('ידני: ')

    else:
      sys.exit()

def clearPackagesStartup():
    TEMP=os.path.join(ADDONS,'temp')
    start = datetime.utcnow() - timedelta(minutes=3)
    file_count = 0; cleanupsize = 0
    if os.path.exists(PACKAGES):
        pack = os.listdir(PACKAGES)
        pack.sort(key=lambda f: os.path.getmtime(os.path.join(PACKAGES, f)))
        for item in pack:
            file = os.path.join(PACKAGES, item)
            lastedit = datetime.utcfromtimestamp(os.path.getmtime(file))
            # if lastedit <= start:
            if os.path.isfile(file):
                file_count += 1
                os.unlink(file)
            elif os.path.isdir(file): 
                try:
                    shutil.rmtree(file)
                except :pass
    if os.path.exists(TEMP):
        pack = os.listdir(TEMP)
        pack.sort(key=lambda f: os.path.getmtime(os.path.join(TEMP, f)))
        for item in pack:
            file = os.path.join(TEMP, item)
            lastedit = datetime.utcfromtimestamp(os.path.getmtime(file))
            # if lastedit <= start:
            if os.path.isfile(file):
                file_count += 1

                os.unlink(file)
            elif os.path.isdir(file): 

                # cleanfiles, cleanfold = cleanHouse(file)
                # file_count += cleanfiles + cleanfold
                try:
                    shutil.rmtree(file)
                except :pass

def auto_build_update(NOTEID):
    counter_ten=5
    while(counter_ten)>0:
        counter_ten-=1
        time.sleep(1)
    try:
        clearPackagesStartup()
    except:pass

    x=xbmc.executebuiltin("UpdateLocalAddons")
    x=xbmc.executebuiltin("UpdateAddonRepos")
    if not xbmc.Player().isPlaying():
        if BUILDNAME == " Kodi Premium" or os.path.exists(translatepath("special://home/addons/") + 'skin.Premium.mod'):
            wiz.wizardUpdate('startup')
            if STARTP() =='ok':
                # check()
                if not NOTIFY == 'true':
                    # url = wiz.workingURL(NOTIFICATION)
                    # if url == True:
                    id, msg = wiz.splitNotify(NOTIFICATION)
                    if not id == False:
                        try:
                            id = int(id); NOTEID = int(NOTEID)
                            if id == NOTEID:
                                if NOTEDISMISS == 'false':
                                    checkidupdatetele('אוטומטי: ')# notify.notification(msg)
                                else: wiz.log("[Notifications] id[%s] Dismissed" % int(id), 5)
                            elif id > NOTEID:

                                wiz.setS('noteid', str(id))
                                wiz.setS('notedismiss', 'false')
                                checkidupdatetele('אוטומטי: ')

                        except Exception as e:
                            wiz.log("Error on Notifications Window: %s" % str(e), 5)

def install_turkey():

    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Dragon Turkey'),'[COLOR %s]מוריד חיבלת תוכן טורקי[/COLOR]' % COLOR2)
    name =  "Dragon Turkey"
    buildzip ='https://github.com/vip200/victory/blob/master/plugin.video.dreamspeed.zip?raw=true'#wiz.checkBuild(name,'gui')

    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]' % (COLOR1, name))
    lib=os.path.join(PACKAGES, '%s_guisettings.zip' % name)
    try: os.remove(lib)
    except: pass
    #logging.warning(buildzip)
    if 'google' in buildzip:
       googledrive_download(buildzip, lib, DP,wiz.checkBuild(name, 'updatesize'))

    else:
      downloader.download(buildzip, lib, DP)
    xbmc.sleep(100)
    namex= 'מעדכן קבצים'
    title = '[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, namex)
    DP.update(0, title+'\n'+''+'\n'+ 'אנא המתן')
    extract.all(lib,ADDONS,DP, title=title)
    try:
        open_dragon_menu_hub()
    except Exception as e: 
                    logging.warning('dragon hub errrrrrrror'+str(e))
    DP.close()
def disply_hwr3():
    from datetime import date
    today = date.today()
    zz=str(today).split('-')[2]
    my_tmdb=tmdb_list(TMDB_NEW_API2)
    num=str((getHwAddr('eth0'))*my_tmdb)
    new_num=(num[1]+num[2]+zz)
    send_user_info('channel_install_is_done','בקשה לפתיחת תוכן טורקי '+str(new_num))


def install_turkey_bot():
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Dragon Turkey'),'[COLOR %s]מוריד חיבלת תוכן טורקי[/COLOR]' % COLOR2)
    name =  "Dragon Turkey"
    buildzip ='https://github.com/vip200/victory/blob/master/plugin.video.dreamspeed.zip?raw=true'
    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]' % (COLOR1, name))
    lib=os.path.join(PACKAGES, '%s_guisettings.zip' % name)
    if 'google' in buildzip:
       googledrive_download(buildzip, lib, DP,wiz.checkBuild(name, 'updatesize'))
    else:
      downloader.download(buildzip, lib, DP)
    xbmc.sleep(100)
    namex= 'מעדכן קבצים'
    title = '[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, namex)
    DP.update(0, title+'\n'+''+'\n'+ 'אנא המתן')
    extract.all(lib,ADDONS,DP, title=title)
    DP.close()
    xbmc.sleep(100)
    try: os.remove(lib)
    except: pass
    wiz.kodi17Fix()
def get_pincode(code_link):
    #VIP
    stop_time = time.time() + 300
    while(code_link=='empty' or code_link==None):
          wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Dragon'),'[COLOR %s]המתן לתגובה מ Dragon[/COLOR]' % COLOR2)
          code_link=telecode()
          if time.time() > stop_time:
            code_link='play_tele'
    return code_link

def open_turkey():
    if wiz.getS("dragon") =='true':
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        DIALOG         = xbmcgui.Dialog()
        choice = DIALOG.yesno('Dragon Turkey', "התהליך מתבצע פחות מדקה, להמשך לחצו אישור.", yeslabel="[B][COLOR WHITE]אישור[/COLOR][/B]", nolabel="[B][COLOR white]ביטול[/COLOR][/B]")
        if choice == 0:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            sys.exit()
        else:
        # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המתן...[/COLOR]' % COLOR2)
            from datetime import date

            today = date.today()
            zz=str(today).split('-')[2]
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Dragon Turkey'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]' % COLOR2)
            # zz=str(time.strftime("%H/%M").replace('/','-')).split('-')[0]
            from math import sqrt
            my_tmdb=tmdb_list(TMDB_NEW_API2)
            num=str((getHwAddr('eth0'))*my_tmdb)
            new_num=int(num[1]+num[2]+zz)
            new_num2=(str( round(sqrt((new_num*200)+40)+40,4))[-4:]).replace('.','')
            if '.' in new_num2:
             new_num2=(str( round(sqrt((new_num*200)+40)+40,4))[-5:]).replace('.','')
            disply_hwr3()
            search_entered=get_pincode(code_link)
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            if search_entered==new_num2:
                install_turkey_bot()
                try:
                    open_dragon_menu_hub()
                except Exception as e: 
                                logging.warning('dragon hub errrrrrrror'+str(e))
                wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Dragon Turkey'),'[COLOR %s]התוכן נפתח![/COLOR]' % COLOR2)
            else:
              wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Dragon Turkey'),'[COLOR %s]אין גישה לתוכן[/COLOR]' % COLOR2)
              sys.exit()
    else:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Dragon Turkey'),'[COLOR %s]לא פעיל[/COLOR]' % COLOR2)

def testnotify():
    try:
        dialog = xbmcgui.DialogBusy()
        dialog.create()
    except:
       xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    url = wiz.workingURL(NOTIFICATION)
    if url == True:
        try:
            id, msg = wiz.splitNotify(NOTIFICATION)
            if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון [/COLOR]" % COLOR2); return
            if STARTP()=='ok': 
                # check()
                notify.notification(msg, True)
        except Exception as e:
            wiz.log("Error on Notifications Window: %s" % str(e), 5)
    else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון[/COLOR]" % COLOR2)
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

def infobuild(test=''):

    try:
        id, msg = wiz.splitNotify(NOTIFICATION)
        if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2); return
        notify.updateinfo(msg, test)
    except Exception as e:
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין עדכון מהיר[/COLOR]" % COLOR2)
def infoupdate_busydialog(test=''):
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        id, msg = wiz.splitNotify(NOTIFICATION)
        notify.updateinfo(msg, test)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    except Exception as e:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אין מידע[/COLOR]" % COLOR2)

def testupdate():
	if BUILDNAME == "":
		notify.updateWindow()
	else:
		notify.updateWindow(BUILDNAME, BUILDVERSION, BUILDLATEST, wiz.checkBuild(BUILDNAME, 'icon'), wiz.checkBuild(BUILDNAME, 'fanart'))

def addDir(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
    u = sys.argv[0]
    if not mode == None: u += "?mode=%s" % que(mode)
    if not name == None: u += "&name="+que(name)
    if not url == None: u += "&url="+que(url)
    ok=True
    if themeit: display = themeit % display
    try:
      liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    except:
      liz=xbmcgui.ListItem(display)
      liz.setArt({'thumb' : icon, 'fanart': icon, 'DefaultFolder.png': icon})
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addFile(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
    u = sys.argv[0]
    try:
        if not mode == None: u += "?mode=%s" % que(mode)
        if not name == None: u += "&name="+que(name)
        if not url == None: u += "&url="+que(url)
    except:#kodi19
        if not mode == None: u += "?mode=%s" % que(mode)
        if not name == None: u += "&name="+que(name)
        if not url == None: u += "&url="+que(url)
    ok=True
    if themeit: display = themeit % display
    try:
        liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    except:
        liz=xbmcgui.ListItem(display)
        liz.setArt({'thumb' : icon, 'fanart': icon, 'DefaultFolder.png': icon})
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def get_params(user_params=''):
       
        param = dict(parse_qsl(user_params.replace('?','')))
        return param   
def remove_addons():
	try:
			import json
			r = urlopen(remove_url).readlines()
			for line in r:
				
				add_name =line.decode('utf-8').split(':')[1].strip()
				do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}' % (add_name, 'false')
				query = xbmc.executeJSONRPC(do_json)
				response = json.loads(query)
				
				url_folder=os.path.join(addons_folder,add_name)
				
				if os.path.exists(url_folder):
					for root, dirs, files in os.walk(url_folder):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder)

			xbmc.executebuiltin('Container.Refresh')
			xbmc.executebuiltin("UpdateLocalAddons()")
			xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
	except:  pass

def remove_addons2():
	try:
			import json
			r = urlopen(remove_url2).readlines()
			for line in r:
				
				add_name =line.split(':')[1].strip() 
				do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}' % (add_name, 'false')
				query = xbmc.executeJSONRPC(do_json)
				response = json.loads(query)
				
				url_folder2=os.path.join(user_folder,add_name)
				
				if os.path.exists(url_folder2):
					for root, dirs, files in os.walk(url_folder2):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder2)

	except:  pass
def backtokodi():
    import shutil
    KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    from shutil import copyfile

    if  KODIV <= 19.5:# קודי 19
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"19","guisettings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
        copyfile(src,dst)
        xbmc.sleep(200)
        fix_gui()
        xbmc.sleep(200)
    resetkodi()
    if  KODIV >= 20: # קודי 20
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"20","guisettings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
        copyfile(src,dst)
        xbmc.sleep(200)
        fix_gui()
        xbmc.sleep(200)
    resetkodi()


def refresh_list(user_params,sys_arg_1_data,Addon_id=""):
    global name

    params=get_params(user_params=user_params)

    url=None
    name=None
    mode=None

    try:     mode=unque(params["mode"])
    except:  pass
    try:     name=unque(params["name"])
    except:  pass
    try:     url=unque(params["url"])
    except:  pass
    if   mode==None             : buildMenu()#index()
    elif mode=='user_info'   : wiz.user_info()
    elif mode=='wizardupdate'   : wiz.wizardUpdate()
    elif mode=='builds'         : buildMenu()
    elif mode=='STARTP'         : STARTP()

    
    elif mode=='install'        : buildWizard(name, url)
    elif mode=='theme'          : buildWizard(name, mode, url)



    elif mode=='kodi17fix'      : wiz.kodi17Fix()
    elif mode=='kodi177fix'      : wiz.kodi177Fix()
    elif mode=='autoadvanced'   : showAutoAdvanced(); wiz.refresh()
    elif mode=='removeadvanced' : removeAdvanced(); wiz.refresh()



    elif mode=='clearbackup'    : wiz.cleanupBackup()
    elif mode=='currentsettings': viewAdvanced()
    elif mode=='fullclean'      : totalClean(); wiz.refresh()
    elif mode=='clearcache'     : clearCache(); wiz.refresh()
    elif mode=='testcommand'        : testcommand()
    elif mode=='logsend'        : logsend()
    elif mode=='setrd'          : setrealdebrid()
    elif mode=='setrd2'         : setautorealdebrid()
    elif mode=='clearpackages'  : wiz.clearPackages(); wiz.refresh()
    elif mode=='clearcrash'     : wiz.clearCrash(); wiz.refresh()
    elif mode=='clearthumb'     : clearThumb(); wiz.refresh()
    elif mode=='freshstart'     : freshStart()
    elif mode=='forceupdate'    : wiz.forceUpdate()
    elif mode=='forceprofile'   : wiz.reloadProfile(wiz.getInfo('System.ProfileName'))
    elif mode=='forceclose'     : wiz.killxbmc()
    elif mode=='forceskin'      : wiz.ebi("ReloadSkin()"); wiz.refresh()
    elif mode=='enableaddons'   : enableAddons()



    elif mode=='purgedb'        : purgeDb()

    elif mode=='removeaddon'    : removeAddon(name)
    elif mode=='removeaddondata': removeAddonDataMenu()
    elif mode=='removedata'     : removeAddonData(name)

    elif mode=='systeminfo'     : systemInfo()





    elif mode=='writeadvanced'  : writeAdvanced(name, url)
    elif mode=='traktsync'  : traktsync()

    elif mode=='apk'            : apkMenu(name)
    elif mode=='apkscrape'      : apkScraper(name)
    elif mode=='apkinstall'     : apkInstaller(name, url)
    elif mode=='speed'          : speedMenu()
    elif mode=='net'            : net_tools()
    elif mode=='GetList'        : GetList(url)
    elif mode=='viewVideo'      : playVideo(url)


    elif mode=='addoninstall'   : addonInstaller(name, url)

    elif mode=='togglesetting'  : wiz.setS(name, 'false' if wiz.getS(name) == 'true' else 'true'); wiz.refresh()



    elif mode=='login'          : loginMenu()


    elif mode=='settings'       : wiz.openS(name); wiz.refresh()
    elif mode=='opensettings'   : id = eval(url.upper()+'ID')[name]['plugin']; addonid = wiz.addonId(id); addonid.openSettings(); wiz.refresh()


    elif mode=='testnotify'     : testnotify()


    elif mode=='testupdate'     : testupdate()
    elif mode=='testfirst'      : testfirst()
    elif mode=='testfirstrun'   : testfirstRun()
    elif mode=='testapk'        : notify.apkInstaller('SPMC')

    elif mode=='bg'        : wiz.bg_install(name,url)
    elif mode=='bgcustom'        : wiz.bg_custom()
    elif mode=='bgremove'        : wiz.bg_remove()
    elif mode=='bgdefault'        : wiz.bg_default()
    elif mode=='rdset'        : rdsetup()
    elif mode=='mor'        : morsetup()
    elif mode=='mor2'        : morsetup2()
    elif mode=='firstinstall'        : firstinstall()
    elif mode=='resolveurl'        : resolveurlsetup()
    elif mode=='urlresolver'        : urlresolversetup()
    elif mode=='help_install'        : help_install()

    elif mode=='traktset'        : traktsetup()
    elif mode=='placentaset'        : placentasetup()
    elif mode=='flixnetset'        : flixnetsetup()
    elif mode=='reptiliaset'        : reptiliasetup()
    elif mode=='yodasset'        : yodasetup()
    elif mode=='numbersset'        : numberssetup()
    elif mode=='uranusset'        : uranussetup()
    elif mode=='genesisset'        : genesissetup()
    elif mode=='fastupdate'        : fastupdate()

    elif mode=='menudata'        : Menu()
    elif mode=='infoupdate'        : infobuild(False)
    elif mode=='infoupdate_busydialog'        : infoupdate_busydialog(False)
    elif mode=='wait'        : wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אנא המתן[/COLOR]" % COLOR2)



    elif mode=='sex_menu_open'   :sex_menu_open()
    elif mode=='sex_menu_luck'   :sex_menu_luck(notify='true')
    elif mode=='tv_widget_tele'   :tv_widget_tele(notify='true')
    elif mode=='tv_widget_kitana'   :tv_widget_kitana(notify='true')
    elif mode=='open_turkey'   :open_turkey()
    elif mode=='force_update'   :force_update()
    elif mode=='update_tele'   :auto_build_update(NOTEID)
    elif mode=='adv_settings'   : auto_buffer()
    elif mode=='adv_settings_fromskin'   : auto_buffer_fromskin()
    elif mode=='check_firebase'       : check_firebase()

    elif mode=='passandUsername'       : passandUsername()
    elif mode=='9'        : disply_hwr()
    elif mode=='80'        : send_user_info('channel_new_install','שלח קוד')
    elif mode=='fixskin'        : backtokodi()

#send_hwr()

    xbmcplugin.endOfDirectory(int(sys.argv[1]))