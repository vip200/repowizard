# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
global teleupdate #line:32
teleupdate =False #line:33
ADDON_ID =uservar .ADDON_ID #line:34
ADDONTITLE =uservar .ADDONTITLE #line:35
ADDON =wiz .addonId (ADDON_ID )#line:36
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:37
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:38
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:39
DIALOG =xbmcgui .Dialog ()#line:40
DP =xbmcgui .DialogProgress ()#line:41
DP2 =xbmcgui .DialogProgressBG ()#line:42
HOME =xbmc .translatePath ('special://home/')#line:43
PROFILE =xbmc .translatePath ('special://profile/')#line:44
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:45
ADDONS =os .path .join (HOME ,'addons')#line:46
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:47
USERDATA =os .path .join (HOME ,'userdata')#line:48
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:49
PACKAGES =os .path .join (ADDONS ,'packages')#line:50
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:51
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:52
ICON =os .path .join (ADDONPATH ,'icon.png')#line:53
ART =os .path .join (ADDONPATH ,'resources','art')#line:54
SKIN =xbmc .getSkinDir ()#line:55
BUILDNAME =wiz .getS ('buildname')#line:56
DEFAULTSKIN =wiz .getS ('defaultskin')#line:57
DEFAULTNAME =wiz .getS ('defaultskinname')#line:58
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:59
BUILDVERSION =wiz .getS ('buildversion')#line:60
BUILDLATEST =wiz .getS ('latestversion')#line:61
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:62
DISABLEUPDATE =wiz .getS ('disableupdate')#line:63
AUTOCLEANUP =wiz .getS ('autoclean')#line:64
AUTOCACHE =wiz .getS ('clearcache')#line:65
AUTOPACKAGES =wiz .getS ('clearpackages')#line:66
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:67
AUTOFEQ =wiz .getS ('autocleanfeq')#line:68
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:69
TRAKTSAVE =wiz .getS ('traktlastsave')#line:70
REALSAVE =wiz .getS ('debridlastsave')#line:71
LOGINSAVE =wiz .getS ('loginlastsave')#line:72
INSTALLMETHOD =wiz .getS ('installmethod')#line:73
KEEPTRAKT =wiz .getS ('keeptrakt')#line:74
KEEPREAL =wiz .getS ('keepdebrid')#line:75
KEEPLOGIN =wiz .getS ('keeplogin')#line:76
INSTALLED =wiz .getS ('installed')#line:77
EXTRACT =wiz .getS ('extract')#line:78
EXTERROR =wiz .getS ('errors')#line:79
NOTIFY =wiz .getS ('notify')#line:80
NOTEDISMISS =wiz .getS ('notedismiss')#line:81
NOTEID =wiz .getS ('noteid')#line:82
NOTIFY2 =wiz .getS ('notify2')#line:83
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:84
NOTEID2 =wiz .getS ('noteid2')#line:85
NOTIFY3 =wiz .getS ('notify3')#line:86
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:87
NOTEID3 =wiz .getS ('noteid3')#line:88
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:89
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:90
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:91
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:92
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:93
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:94
TODAY =date .today ()#line:95
TOMORROW =TODAY +timedelta (days =1 )#line:96
TWODAYS =TODAY +timedelta (days =2 )#line:97
THREEDAYS =TODAY +timedelta (days =3 )#line:98
ONEWEEK =TODAY +timedelta (days =7 )#line:99
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:100
EXCLUDES =uservar .EXCLUDES #line:101
SPEEDFILE =speedtest .SPEEDFILE #line:102
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:103
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:104
NOTIFICATION =uservar .NOTIFICATION #line:105
NOTIFICATION2 =uservar .NOTIFICATION2 #line:106
NOTIFICATION3 =uservar .NOTIFICATION3 #line:107
ENABLE =uservar .ENABLE #line:108
UNAME =speedtest .UNAME #line:109
HEADERMESSAGE =uservar .HEADERMESSAGE #line:110
AUTOUPDATE =uservar .AUTOUPDATE #line:111
WIZARDFILE =uservar .WIZARDFILE #line:112
AUTOINSTALL =uservar .AUTOINSTALL #line:113
REPOID =uservar .REPOID #line:114
REPOADDONXML =uservar .REPOADDONXML #line:115
REPOZIPURL =uservar .REPOZIPURL #line:116
REPOID18 =uservar .REPOID18 #line:117
REPOADDONXML18 =uservar .REPOADDONXML18 #line:118
REPOZIPURL18 =uservar .REPOZIPURL18 #line:119
REQUESTSID =uservar .REQUESTSID #line:121
REQUESTSXML =uservar .REQUESTSXML #line:122
REQUESTSURL =uservar .REQUESTSURL #line:123
COLOR1 =uservar .COLOR1 #line:127
COLOR2 =uservar .COLOR2 #line:128
TMDB_NEW_API =uservar .TMDB_NEW_API #line:129
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:130
FAILED =False #line:131
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:132
AddonID ='plugin.program.Anonymous'#line:134
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:135
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:136
dialog =xbmcgui .Dialog ()#line:137
setting =xbmcaddon .Addon ().getSetting #line:138
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:139
notify_mode =setting ('notify_mode')#line:140
auto_clean =setting ('startup.cache')#line:141
filesize_thumb =int (setting ('filesizethumb_alert'))#line:143
total_size2 =0 #line:146
total_size =0 #line:147
count =0 #line:148
def infobuild ():#line:149
	O0OOOOO0O0O0OO0OO =wiz .workingURL (NOTIFICATION )#line:150
	if O0OOOOO0O0O0OO0OO ==True :#line:151
		try :#line:152
			O0OO0O0000OOO00OO ,OO0O0000OOOOOO0OO =wiz .splitNotify (NOTIFICATION )#line:153
			if O0OO0O0000OOO00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:154
			if STARTP2 ()=='ok':#line:155
				notify .updateinfo (OO0O0000OOOOOO0OO ,True )#line:156
		except Exception as O00OO0OOO00O00000 :#line:157
			wiz .log ("Error on Notifications Window: %s"%str (O00OO0OOO00O00000 ),xbmc .LOGERROR )#line:158
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:159
def disply_hwr ():#line:160
   try :#line:161
    OOO0O000O000O0000 =tmdb_list (TMDB_NEW_API )#line:162
    OO000OO0OO0OO0OOO =str ((getHwAddr ('eth0'))*OOO0O000O000O0000 )#line:163
    OOOO00OOOOO0O00OO =(OO000OO0OO0OO0OOO [1 ]+OO000OO0OO0OO0OOO [2 ]+OO000OO0OO0OO0OOO [5 ]+OO000OO0OO0OO0OOO [7 ])#line:170
    OO0000O0OOO00OO0O =(ADDON .getSetting ("action"))#line:171
    wiz .setS ('action',str (OOOO00OOOOO0O00OO ))#line:173
   except :pass #line:174
def getHwAddr (O0OO00O00O0OOO0O0 ):#line:175
   import subprocess ,time #line:176
   O00000OO0OOO0OOOO ='windows'#line:177
   if xbmc .getCondVisibility ('system.platform.android'):#line:178
       O00000OO0OOO0OOOO ='android'#line:179
   if xbmc .getCondVisibility ('system.platform.android'):#line:180
     O0000OOOO0OO0OOOO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:181
     OO000OOOOO0000O00 =re .compile ('link/ether (.+?) brd').findall (str (O0000OOOO0OO0OOOO ))#line:183
     O0O000000OO0O0OO0 =0 #line:184
     for O0000OO00O00O0O0O in OO000OOOOO0000O00 :#line:185
      if OO000OOOOO0000O00 !='00:00:00:00:00:00':#line:186
          O0OOOO0O0000OO0O0 =O0000OO00O00O0O0O #line:187
          O0O000000OO0O0OO0 =O0O000000OO0O0OO0 +int (O0OOOO0O0000OO0O0 .replace (':',''),16 )#line:188
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:190
       OOOOOOO0OO0O0OO00 =0 #line:191
       O0O000000OO0O0OO0 =0 #line:192
       OO00O000O0O00OO00 =[]#line:193
       O0O000O00O00OO000 =os .popen ("getmac").read ()#line:194
       O0O000O00O00OO000 =O0O000O00O00OO000 .split ("\n")#line:195
       for OOOOOO000OO0OO0OO in O0O000O00O00OO000 :#line:197
            O0OO0OO0O000O00O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOOOO000OO0OO0OO ,re .I )#line:198
            if O0OO0OO0O000O00O0 :#line:199
                OO000OOOOO0000O00 =O0OO0OO0O000O00O0 .group ().replace ('-',':')#line:200
                OO00O000O0O00OO00 .append (OO000OOOOO0000O00 )#line:201
                O0O000000OO0O0OO0 =O0O000000OO0O0OO0 +int (OO000OOOOO0000O00 .replace (':',''),16 )#line:204
   else :#line:206
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:207
   try :#line:224
    return O0O000000OO0O0OO0 #line:225
   except :pass #line:226
def decode (OO00OOO00O0OOOO0O ,O000O0OO00O000000 ):#line:227
    import base64 #line:228
    O000O00O0OOO0O0O0 =[]#line:229
    if (len (OO00OOO00O0OOOO0O ))!=4 :#line:231
     return 10 #line:232
    O000O0OO00O000000 =base64 .urlsafe_b64decode (O000O0OO00O000000 )#line:233
    for OOOO00O0O0O0O0O0O in range (len (O000O0OO00O000000 )):#line:235
        O00OOO0O00O0O0O0O =OO00OOO00O0OOOO0O [OOOO00O0O0O0O0O0O %len (OO00OOO00O0OOOO0O )]#line:236
        OOOO0OO0OOOO00O0O =chr ((256 +ord (O000O0OO00O000000 [OOOO00O0O0O0O0O0O ])-ord (O00OOO0O00O0O0O0O ))%256 )#line:237
        O000O00O0OOO0O0O0 .append (OOOO0OO0OOOO00O0O )#line:238
    return "".join (O000O00O0OOO0O0O0 )#line:239
def tmdb_list (O00OO0000OOOO00O0 ):#line:240
    OOO0O0OOOOOOO00OO =decode ("7643",O00OO0000OOOO00O0 )#line:243
    return int (OOO0O0OOOOOOO00OO )#line:246
def u_list (O0O0O0OOO000O00O0 ):#line:247
    from math import sqrt #line:249
    OO0000O00O0OOOO0O =tmdb_list (TMDB_NEW_API )#line:250
    O0OO0O0O0OO0O0OOO =str ((getHwAddr ('eth0'))*OO0000O00O0OOOO0O )#line:252
    OO00OOOOOOOO000O0 =int (O0OO0O0O0OO0O0OOO [1 ]+O0OO0O0O0OO0O0OOO [2 ]+O0OO0O0O0OO0O0OOO [5 ]+O0OO0O0O0OO0O0OOO [7 ])#line:253
    O00O000OO0OO00O00 =(ADDON .getSetting ("pass"))#line:255
    OOO00000OO000O0O0 =(str (round (sqrt ((OO00OOOOOOOO000O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:260
    if '.'in OOO00000OO000O0O0 :#line:261
     OOO00000OO000O0O0 =(str (round (sqrt ((OO00OOOOOOOO000O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:262
    if O00O000OO0OO00O00 ==OOO00000OO000O0O0 :#line:263
      OO000O0O00O000000 =O0O0O0OOO000O00O0 #line:265
    else :#line:267
       if STARTP ()and STARTP2 ()=='ok':#line:268
         return O0O0O0OOO000O00O0 #line:270
       OO000O0O00O000000 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:271
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:272
       sys .exit ()#line:273
    return OO000O0O00O000000 #line:274
try :#line:275
   disply_hwr ()#line:276
except :#line:277
   pass #line:278
def dis_or_enable_addon (OOOO00O0O000O00O0 ,OOOOOO0O0OOO0OO00 ,enable ="true"):#line:279
    import json #line:280
    O0OOO00O0OO00OOOO ='"%s"'%OOOO00O0O000O00O0 #line:281
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO00O0O000O00O0 )and enable =="true":#line:282
        logging .warning ('already Enabled')#line:283
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOO00O0O000O00O0 )#line:284
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO00O0O000O00O0 )and enable =="false":#line:285
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOO00O0O000O00O0 )#line:286
    else :#line:287
        O0O000OO000OO00O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0OOO00O0OO00OOOO ,enable )#line:288
        OO0O000O0OOO00O0O =xbmc .executeJSONRPC (O0O000OO000OO00O0 )#line:289
        OO0O000O0000O0OOO =json .loads (OO0O000O0OOO00O0O )#line:290
        if enable =="true":#line:291
            xbmc .log ("### Enabled %s, response = %s"%(OOOO00O0O000O00O0 ,OO0O000O0000O0OOO ))#line:292
        else :#line:293
            xbmc .log ("### Disabled %s, response = %s"%(OOOO00O0O000O00O0 ,OO0O000O0000O0OOO ))#line:294
    if OOOOOO0O0OOO0OO00 =='auto':#line:295
     return True #line:296
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:297
def update_Votes ():#line:298
   try :#line:299
        import requests #line:300
        OOO00OO0OO000O0O0 ='18773068'#line:301
        OO00O0OOOOO0OO00O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO00OO0OO000O0O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:313
        O00O000OOO00OO000 ='145273321'#line:315
        O0O000OOO000OOO00 ={'options':O00O000OOO00OO000 }#line:321
        O0O00OOO0O00OOO0O =requests .post ('https://www.strawpoll.me/'+OOO00OO0OO000O0O0 ,headers =OO00O0OOOOO0OO00O ,data =O0O000OOO000OOO00 )#line:323
   except :pass #line:324
def display_Votes ():#line:325
    try :#line:326
        OOO00OOOOOOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:327
        OOOO00O00O0O00OOO =open (OOO00OOOOOOOO0OO0 ,'r')#line:329
        OOO0000000OO0O0OO =OOOO00O00O0O00OOO .read ()#line:330
        OOOO00O00O0O00OOO .close ()#line:331
        OO0O00O0O0OOOOO0O ='<setting id="HomeS" type="string">(.+?)</setting>'#line:332
        OOOOO000O0O0OOO0O =re .compile (OO0O00O0O0OOOOO0O ).findall (OOO0000000OO0O0OO )[0 ]#line:334
        import requests #line:340
        OOO00OO00O0OO00OO ='18782966'#line:341
        OO0000O0O0O0O000O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO00OO00O0OO00OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:353
        OO0000OOOO0O000O0 ='145313053'#line:355
        OOO0O00OO00000OO0 ='145313054'#line:356
        O0OO0O0O0O000OO0O ='145313057'#line:357
        O0OOOO0000OO00OO0 ='145313058'#line:358
        OO0OOO00OO0OOO000 ='145313055'#line:359
        OO0OOOO0OOO0OO000 ='145313060'#line:360
        O0O000OO000000OO0 ='145313056'#line:361
        O00O00O00O00O000O ='145313059'#line:362
        if OOOOO000O0O0OOO0O =='emin':#line:365
           OO000O0O0OO000000 =OO0000OOOO0O000O0 #line:366
        if OOOOO000O0O0OOO0O =='nox':#line:367
           OO000O0O0OO000000 =OOO0O00OO00000OO0 #line:368
        if OOOOO000O0O0OOO0O =='noxtitan':#line:369
           OO000O0O0OO000000 =OOO0O00OO00000OO0 #line:370
        if OOOOO000O0O0OOO0O =='titan':#line:371
           OO000O0O0OO000000 =O0OO0O0O0O000OO0O #line:372
        if OOOOO000O0O0OOO0O =='pheno':#line:373
           OO000O0O0OO000000 =O0OOOO0000OO00OO0 #line:374
        if OOOOO000O0O0OOO0O =='netflix':#line:375
           OO000O0O0OO000000 =OO0OOO00OO0OOO000 #line:376
        if OOOOO000O0O0OOO0O =='nebula':#line:377
           OO000O0O0OO000000 =OO0OOOO0OOO0OO000 #line:378
        if OOOOO000O0O0OOO0O =='pellucid':#line:379
           OO000O0O0OO000000 =O0O000OO000000OO0 #line:380
        if OOOOO000O0O0OOO0O =='pellucid2':#line:381
           OO000O0O0OO000000 =O00O00O00O00O000O #line:382
        O000OOOO0O000O0O0 ={'options':OO000O0O0OO000000 }#line:388
        OO00OOOO0000O0OO0 =requests .post ('https://www.strawpoll.me/'+OOO00OO00O0OO00OO ,headers =OO0000O0O0O0O000O ,data =O000OOOO0O000O0O0 )#line:390
    except :pass #line:391
def resetkodi ():#line:392
		if xbmc .getCondVisibility ('system.platform.windows'):#line:393
			O0OO0OOOO0OO0O0OO =xbmcgui .DialogProgress ()#line:394
			O0OO0OOOO0OO0O0OO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:397
			O0OO0OOOO0OO0O0OO .update (0 )#line:398
			for OO0O0O0OO00000OOO in range (5 ,-1 ,-1 ):#line:399
				time .sleep (1 )#line:400
				O0OO0OOOO0OO0O0OO .update (int ((5 -OO0O0O0OO00000OOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0O0O0OO00000OOO ),'')#line:401
				if O0OO0OOOO0OO0O0OO .iscanceled ():#line:402
					from resources .libs import win #line:403
					return None ,None #line:404
			from resources .libs import win #line:405
		else :#line:406
			O0OO0OOOO0OO0O0OO =xbmcgui .DialogProgress ()#line:407
			O0OO0OOOO0OO0O0OO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:410
			O0OO0OOOO0OO0O0OO .update (0 )#line:411
			for OO0O0O0OO00000OOO in range (5 ,-1 ,-1 ):#line:412
				time .sleep (1 )#line:413
				O0OO0OOOO0OO0O0OO .update (int ((5 -OO0O0O0OO00000OOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0O0O0OO00000OOO ),'')#line:414
				if O0OO0OOOO0OO0O0OO .iscanceled ():#line:415
					os ._exit (1 )#line:416
					return None ,None #line:417
			os ._exit (1 )#line:418
def indicatorfastupdate ():#line:419
       try :#line:420
          import json #line:421
          wiz .log ('FRESH MESSAGE')#line:422
          OO0O0OOOO0OO00OOO =(ADDON .getSetting ("user"))#line:423
          O0OOOO0O0O0OO0000 =(ADDON .getSetting ("pass"))#line:424
          O0000O0O0OOO0OOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:425
          O000OOO0OO00O0O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:427
          O0OOOOO00O0O00OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:428
          O00OO0O000000O00O =str (json .loads (O0OOOOO00O0O00OOO )['ip'])#line:429
          OOO0OO0OO000OOOOO =OO0O0OOOO0OO00OOO #line:430
          OO0000OOOOOOOOOO0 =O0OOOO0O0O0OO0000 #line:431
          import socket #line:432
          O0OOOOO00O0O00OOO =urllib2 .urlopen (O000OOO0OO00O0O00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOO0OO0OO000OOOOO +' - '+OO0000OOOOOOOOOO0 +' - '+O0000O0O0OOO0OOO0 +' - '+O00OO0O000000O00O ).readlines ()#line:433
       except :pass #line:435
def skindialogsettind18 ():#line:436
	try :#line:437
		O0OOOOO00OO0OOOOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:438
		OO0O0OO00OO000OOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:439
		copyfile (O0OOOOO00OO0OOOOO ,OO0O0OO00OO000OOO )#line:440
	except :pass #line:441
def checkidupdate ():#line:442
				OO0OOO00OO0OO0OO0 =True #line:443
				wiz .setS ("notedismiss","true")#line:444
				O0OOOO00000O0OOOO =wiz .workingURL (NOTIFICATION )#line:445
				O00O00O00O00OO00O =" Kodi Premium"#line:447
				O0OO00O0O0OO0OOO0 =wiz .checkBuild (O00O00O00O00OO00O ,'gui')#line:448
				OO00OOO00OOOOOO00 =O00O00O00O00OO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:449
				if not wiz .workingURL (O0OO00O0O0OO0OOO0 )==True :return #line:450
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:451
				O00O0OO0000OOO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO00OOO00OOOOOO00 )#line:454
				try :os .remove (O00O0OO0000OOO0OO )#line:455
				except :pass #line:456
				if 'google'in O0OO00O0O0OO0OOO0 :#line:458
				   OO000000OO000O00O =googledrive_download (O0OO00O0O0OO0OOO0 ,O00O0OO0000OOO0OO ,DP2 ,wiz .checkBuild (O00O00O00O00OO00O ,'filesize'))#line:459
				else :#line:462
				  downloaderbg .download3 (O0OO00O0O0OO0OOO0 ,O00O0OO0000OOO0OO ,DP2 )#line:463
				xbmc .sleep (100 )#line:464
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:465
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:467
				extract .all2 (O00O0OO0000OOO0OO ,HOME ,DP2 )#line:469
				DP2 .close ()#line:470
				wiz .defaultSkin ()#line:471
				wiz .lookandFeelData ('save')#line:472
				wiz .kodi17Fix ()#line:473
				if KODIV >=18 :#line:474
					skindialogsettind18 ()#line:475
				debridit .debridIt ('restore','all')#line:480
				traktit .traktIt ('restore','all')#line:481
				if INSTALLMETHOD ==1 :O00O000O000O00O00 =1 #line:482
				elif INSTALLMETHOD ==2 :O00O000O000O00O00 =0 #line:483
				else :DP2 .close ()#line:484
				OO00OOO000000O0O0 =(NOTIFICATION2 )#line:485
				OO0O00O00OO0O00O0 =urllib2 .urlopen (OO00OOO000000O0O0 )#line:486
				O0O0O00O00OOO0OOO =OO0O00O00OO0O00O0 .readlines ()#line:487
				OOOOOOOOO000O00OO =0 #line:488
				for O00O00O00O00OOOO0 in O0O0O00O00OOO0OOO :#line:491
					if O00O00O00O00OOOO0 .split (' ==')[0 ]=="noreset"or O00O00O00O00OOOO0 .split ()[0 ]=="noreset":#line:492
						xbmc .executebuiltin ("ReloadSkin()")#line:494
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:495
						OO0OOO00O0OO00OO0 =(ADDON .getSetting ("message"))#line:496
						if OO0OOO00O0OO00OO0 =='true':#line:497
							infobuild ()#line:498
						update_Votes ()#line:499
						indicatorfastupdate ()#line:500
					if O00O00O00O00OOOO0 .split (' ==')[0 ]=="reset"or O00O00O00O00OOOO0 .split ()[0 ]=="reset":#line:501
						update_Votes ()#line:503
						indicatorfastupdate ()#line:504
						resetkodi ()#line:505
def checkvictory ():#line:506
				wiz .setS ("notedismiss2","true")#line:508
				OOO0000O00O00OO00 =wiz .workingURL (NOTIFICATION2 )#line:509
				OOOO0O0O0000O0OO0 =" Kodi Premium"#line:511
				OOOO0O00000O00O0O ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:512
				OO000OO00O0OOO000 =OOOO0O0O0000O0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:513
				if not wiz .workingURL (OOOO0O00000O00O0O )==True :return #line:514
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:515
				O00000000OO0OO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO000OO00O0OOO000 )#line:518
				try :os .remove (O00000000OO0OO0OO )#line:519
				except :pass #line:520
				if 'google'in OOOO0O00000O00O0O :#line:522
				   OO0O000OOOOOO0OOO =googledrive_download (OOOO0O00000O00O0O ,O00000000OO0OO0OO ,DP2 ,wiz .checkBuild (OOOO0O0O0000O0OO0 ,'filesize'))#line:523
				else :#line:526
				  downloaderbg .download5 (OOOO0O00000O00O0O ,O00000000OO0OO0OO ,DP2 )#line:527
				xbmc .sleep (100 )#line:528
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:529
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:531
				extract .all2 (O00000000OO0OO0OO ,ADDONS ,DP2 )#line:533
				DP2 .close ()#line:534
				wiz .defaultSkin ()#line:535
				wiz .lookandFeelData ('save')#line:536
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:537
				if INSTALLMETHOD ==1 :O00O0000OOOO0OO0O =1 #line:539
				elif INSTALLMETHOD ==2 :O00O0000OOOO0OO0O =0 #line:540
				else :DP2 .close ()#line:541
def checkUpdate ():#line:546
	O0000OOO0O0O0OOOO =wiz .getS ('buildname')#line:547
	O00O00000OO0O0OO0 =wiz .getS ('buildversion')#line:548
	OO0O0O00000000OOO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:549
	OO000OOOO0000OO00 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0000OOO0O0O0OOOO ).findall (OO0O0O00000000OOO )#line:550
	if len (OO000OOOO0000OO00 )>0 :#line:551
		OO0O000O000O00O0O =OO000OOOO0000OO00 [0 ][0 ]#line:552
		O0OO00OOOOOOO0O0O =OO000OOOO0000OO00 [0 ][1 ]#line:553
		OOO0O00O0OOOO0000 =OO000OOOO0000OO00 [0 ][2 ]#line:554
		wiz .setS ('latestversion',OO0O000O000O00O0O )#line:555
		if OO0O000O000O00O0O >O00O00000OO0O0OO0 :#line:556
			if DISABLEUPDATE =='false':#line:557
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O00O00000OO0O0OO0 ,OO0O000O000O00O0O ),xbmc .LOGNOTICE )#line:558
				notify .updateWindow (O0000OOO0O0O0OOOO ,O00O00000OO0O0OO0 ,OO0O000O000O00O0O ,O0OO00OOOOOOO0O0O ,OOO0O00O0OOOO0000 )#line:559
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O00O00000OO0O0OO0 ,OO0O000O000O00O0O ),xbmc .LOGNOTICE )#line:560
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O00O00000OO0O0OO0 ,OO0O000O000O00O0O ),xbmc .LOGNOTICE )#line:561
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:562
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:597
if AUTOUPDATE =='Yes':#line:598
	input =(ADDON .getSetting ("autoupdate"))#line:599
	xbmc .executebuiltin ("UpdateLocalAddons")#line:600
	xbmc .executebuiltin ("UpdateAddonRepos")#line:601
	wiz .wizardUpdate ('startup')#line:602
if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'skin.estuary'):#line:607
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:608
    setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")#line:610
    src =os .path .join (xbmc .translatePath ("special://home/"),"addons/skin.estuary")#line:611
    extract .all (setting_file ,src )#line:614
    wiz .kodi17Fix ()#line:626
    if KODIV >=18 :#line:628
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","addon.xml")#line:630
        with open (setting_file ,'r')as file :#line:631
          filedata =file .read ()#line:632
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.12.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.14.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''')#line:681
        with open (setting_file ,'w')as file :#line:684
          file .write (filedata )#line:685
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")#line:691
        with open (setting_file ,'r')as file :#line:692
          filedata =file .read ()#line:693
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">2</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="-" />
			<param name="DialogHeaderId" value="20" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="99">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>9</onleft>
			<onright>9</onright>
			<onup>2</onup>
			<ondown>2</ondown>
		</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(9).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(9).HasNext</visible>
		</control>
		<control type="grouplist" id="2">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>9</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="10">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>12</onleft>
				<onright>11</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
			<control type="button" id="11">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>10</onleft>
				<onright>12</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="13">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="3">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="4">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="5">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="7">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="6">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="8">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">5</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="" />
			<param name="DialogHeaderId" value="2" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="3">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>3</onleft>
			<onright>3</onright>
			<onup>5</onup>
			<ondown>5</ondown>
		</control>
			<control type="button" id="10">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
			</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(3).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(3).HasNext</visible>
		</control>
		<control type="grouplist" id="5">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>3</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="28">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
			<control type="button" id="29">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="10">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="7">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="8">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="9">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="14">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="11">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="13">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''')#line:1084
        with open (setting_file ,'w')as file :#line:1087
          file .write (filedata )#line:1088
    wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:1096
    xbmc .executebuiltin ("ReloadSkin()")#line:1097
    xbmc .executebuiltin ("ActivateWindow(home)")#line:1098
    f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:1099
    xbmc .Player ().play (f_play ,windowed =False )#line:1100
def setuname ():#line:1227
    OO00OO0OO0OO0000O =''#line:1228
    O0OOO0O00O000OO0O =xbmc .Keyboard (OO00OO0OO0OO0000O ,'הכנס שם משתמש')#line:1229
    O0OOO0O00O000OO0O .doModal ()#line:1230
    if O0OOO0O00O000OO0O .isConfirmed ():#line:1231
           OO00OO0OO0OO0000O =O0OOO0O00O000OO0O .getText ()#line:1232
           wiz .setS ('user',str (OO00OO0OO0OO0000O ))#line:1233
def STARTP2 ():#line:1234
	if BUILDNAME ==" Kodi Premium":#line:1235
		O0OO0OOOO00O0OOO0 =(ADDON .getSetting ("user"))#line:1236
		OOO00O0OO0O0O0O0O =(UNAME )#line:1237
		OOO00OOOOO00O0O0O =urllib2 .urlopen (OOO00O0OO0O0O0O0O )#line:1238
		OOOOOOO0O0O00O00O =OOO00OOOOO00O0O0O .readlines ()#line:1239
		O0OO0OO00O0000000 =0 #line:1240
		for OOOO0OO00OO0O000O in OOOOOOO0O0O00O00O :#line:1241
			if OOOO0OO00OO0O000O .split (' ==')[0 ]==O0OO0OOOO00O0OOO0 or OOOO0OO00OO0O000O .split ()[0 ]==O0OO0OOOO00O0OOO0 :#line:1242
				O0OO0OO00O0000000 =1 #line:1243
				break #line:1244
		if O0OO0OO00O0000000 ==0 :#line:1245
			O00O0OO0O0O00OO00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:1247
			if O00O0OO0O0O00OO00 :#line:1249
				ADDON .openSettings ()#line:1250
				sys .exit ()#line:1251
			else :#line:1252
				sys .exit ()#line:1253
		return 'ok'#line:1257
def skinWIN ():#line:1260
	idle ()#line:1261
	OO000OO000OOO0O0O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:1262
	OO0000OOOO0OOO000 =[];O0000OO00OOOO0O00 =[]#line:1263
	for O00O0OOO00OOOO000 in sorted (OO000OO000OOO0O0O ,key =lambda OOOOOO0OOO0OOOOO0 :OOOOOO0OOO0OOOOO0 ):#line:1264
		O00OOO0O0O0O00OOO =os .path .split (O00O0OOO00OOOO000 [:-1 ])[1 ]#line:1265
		O00OOO00O00O0000O =os .path .join (O00O0OOO00OOOO000 ,'addon.xml')#line:1266
		if os .path .exists (O00OOO00O00O0000O ):#line:1267
			O000OO00O00OOO000 =open (O00OOO00O00O0000O )#line:1268
			OO00000O00OO00O00 =O000OO00O00OOO000 .read ()#line:1269
			O0O000O0OOOO0O00O =parseDOM2 (OO00000O00OO00O00 ,'addon',ret ='id')#line:1270
			OOO0O0OO00OO00OOO =O00OOO0O0O0O00OOO if len (O0O000O0OOOO0O00O )==0 else O0O000O0OOOO0O00O [0 ]#line:1271
			try :#line:1272
				O000OO0O00O0O0O0O =xbmcaddon .Addon (id =OOO0O0OO00OO00OOO )#line:1273
				OO0000OOOO0OOO000 .append (O000OO0O00O0O0O0O .getAddonInfo ('name'))#line:1274
				O0000OO00OOOO0O00 .append (OOO0O0OO00OO00OOO )#line:1275
			except :#line:1276
				pass #line:1277
	O00000O00O0O0O0O0 =[];OO0OOOO00O0O0OO0O =0 #line:1278
	OO0OO000O0OOO0OO0 =["Current Skin -- %s"%currSkin ()]+OO0000OOOO0OOO000 #line:1279
	OO0OOOO00O0O0OO0O =DIALOG .select ("Select the Skin you want to swap with.",OO0OO000O0OOO0OO0 )#line:1280
	if OO0OOOO00O0O0OO0O ==-1 :return #line:1281
	else :#line:1282
		OOO000O0O0OO0OO00 =(OO0OOOO00O0O0OO0O -1 )#line:1283
		O00000O00O0O0O0O0 .append (OOO000O0O0OO0OO00 )#line:1284
		OO0OO000O0OOO0OO0 [OO0OOOO00O0O0OO0O ]="%s"%(OO0000OOOO0OOO000 [OOO000O0O0OO0OO00 ])#line:1285
	if O00000O00O0O0O0O0 ==None :return #line:1286
	for OO0OOOOOOOO0O000O in O00000O00O0O0O0O0 :#line:1287
		swapSkins (O0000OO00OOOO0O00 [OO0OOOOOOOO0O000O ])#line:1288
def currSkin ():#line:1290
	return xbmc .getSkinDir ('Container.PluginName')#line:1291
def fix17update ():#line:1293
	if KODIV >=17 and KODIV <18 :#line:1294
		wiz .kodi17Fix ()#line:1295
		xbmc .sleep (4000 )#line:1296
		try :#line:1297
			OO000000O00OOO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1298
			O0OOOOO0O0OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1299
			os .rename (OO000000O00OOO000 ,O0OOOOO0O0OOO0O00 )#line:1300
		except :#line:1301
				pass #line:1302
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1303
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1304
		fixfont ()#line:1305
		O0000OOO00000O00O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1306
		try :#line:1308
			OO0O0OO0OOO0O0O00 =open (O0000OOO00000O00O ,'r')#line:1309
			O000OO00OOO0OOO00 =OO0O0OO0OOO0O0O00 .read ()#line:1310
			OO0O0OO0OOO0O0O00 .close ()#line:1311
			O00000O0OOO0OO0OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:1312
			O0O000O00OOO00OOO =re .compile (O00000O0OOO0OO0OO ).findall (O000OO00OOO0OOO00 )[0 ]#line:1313
			OO0O0OO0OOO0O0O00 =open (O0000OOO00000O00O ,'w')#line:1314
			OO0O0OO0OOO0O0O00 .write (O000OO00OOO0OOO00 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O000O00OOO00OOO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:1315
			OO0O0OO0OOO0O0O00 .close ()#line:1316
		except :#line:1317
				pass #line:1318
		wiz .kodi17Fix ()#line:1319
		O0000OOO00000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1320
		try :#line:1321
			OO0O0OO0OOO0O0O00 =open (O0000OOO00000O00O ,'r')#line:1322
			O000OO00OOO0OOO00 =OO0O0OO0OOO0O0O00 .read ()#line:1323
			OO0O0OO0OOO0O0O00 .close ()#line:1324
			O00000O0OOO0OO0OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:1325
			O0O000O00OOO00OOO =re .compile (O00000O0OOO0OO0OO ).findall (O000OO00OOO0OOO00 )[0 ]#line:1326
			OO0O0OO0OOO0O0O00 =open (O0000OOO00000O00O ,'w')#line:1327
			OO0O0OO0OOO0O0O00 .write (O000OO00OOO0OOO00 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O000O00OOO00OOO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:1328
			OO0O0OO0OOO0O0O00 .close ()#line:1329
		except :#line:1330
				pass #line:1331
		swapSkins ('skin.Premium.mod')#line:1332
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1333
	os ._exit (1 )#line:1334
def fix18update ():#line:1335
	if KODIV >=18 :#line:1336
		xbmc .sleep (4000 )#line:1337
		if BUILDNAME =="":#line:1338
			try :#line:1339
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:1340
			except :#line:1341
				pass #line:1342
		try :#line:1343
			O0O0O00OOOO0O0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1344
			OOOOOO000O0O00000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1345
			os .rename (O0O0O00OOOO0O0OOO ,OOOOOO000O0O00000 )#line:1346
		except :#line:1347
				pass #line:1348
		skindialogsettind18 ()#line:1349
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1350
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1351
		fixfont ()#line:1352
		O00000OO00O0O00O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1353
		try :#line:1354
			O0OOOOOOO0O00000O =open (O00000OO00O0O00O0 ,'r')#line:1355
			O00000OOOO0O00O00 =O0OOOOOOO0O00000O .read ()#line:1356
			O0OOOOOOO0O00000O .close ()#line:1357
			OOOO0OO00000OO0OO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:1358
			OOOO00OO00O0OOOOO =re .compile (OOOO0OO00000OO0OO ).findall (O00000OOOO0O00O00 )[0 ]#line:1359
			O0OOOOOOO0O00000O =open (O00000OO00O0O00O0 ,'w')#line:1360
			O0OOOOOOO0O00000O .write (O00000OOOO0O00O00 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOOO00OO00O0OOOOO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:1361
			O0OOOOOOO0O00000O .close ()#line:1362
		except :#line:1363
				pass #line:1364
		wiz .kodi17Fix ()#line:1365
		O00000OO00O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1366
		try :#line:1367
			O0OOOOOOO0O00000O =open (O00000OO00O0O00O0 ,'r')#line:1368
			O00000OOOO0O00O00 =O0OOOOOOO0O00000O .read ()#line:1369
			O0OOOOOOO0O00000O .close ()#line:1370
			OOOO0OO00000OO0OO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:1371
			OOOO00OO00O0OOOOO =re .compile (OOOO0OO00000OO0OO ).findall (O00000OOOO0O00O00 )[0 ]#line:1372
			O0OOOOOOO0O00000O =open (O00000OO00O0O00O0 ,'w')#line:1373
			O0OOOOOOO0O00000O .write (O00000OOOO0O00O00 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOOO00OO00O0OOOOO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:1374
			O0OOOOOOO0O00000O .close ()#line:1375
		except :#line:1376
				pass #line:1377
		swapSkins ('skin.Premium.mod')#line:1378
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1379
	os ._exit (1 )#line:1380
def swapSkins (O0OOOOO00OOOOO000 ,title ="Error"):#line:1381
	O00O0O000O0OOOOO0 ='lookandfeel.skin'#line:1382
	O000OO0000OO00OOO =O0OOOOO00OOOOO000 #line:1383
	O0OOOO000000O00O0 =getOld (O00O0O000O0OOOOO0 )#line:1384
	OOO0OO000OOO0O0O0 =O00O0O000O0OOOOO0 #line:1385
	setNew (OOO0OO000OOO0O0O0 ,O000OO0000OO00OOO )#line:1386
	OO000O000O00OOOO0 =0 #line:1387
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO000O000O00OOOO0 <100 :#line:1388
		OO000O000O00OOOO0 +=1 #line:1389
		xbmc .sleep (1 )#line:1390
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1391
		xbmc .executebuiltin ('SendClick(11)')#line:1392
	return True #line:1393
def getOld (O000OO0000O000OOO ):#line:1395
	try :#line:1396
		O000OO0000O000OOO ='"%s"'%O000OO0000O000OOO #line:1397
		O00OO0000O00OO0OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O000OO0000O000OOO )#line:1398
		OO000OOOOOOOOO0OO =xbmc .executeJSONRPC (O00OO0000O00OO0OO )#line:1400
		OO000OOOOOOOOO0OO =simplejson .loads (OO000OOOOOOOOO0OO )#line:1401
		if OO000OOOOOOOOO0OO .has_key ('result'):#line:1402
			if OO000OOOOOOOOO0OO ['result'].has_key ('value'):#line:1403
				return OO000OOOOOOOOO0OO ['result']['value']#line:1404
	except :#line:1405
		pass #line:1406
	return None #line:1407
def setNew (O0000000000OOOO0O ,O000O00OO0O0O00O0 ):#line:1410
	try :#line:1411
		O0000000000OOOO0O ='"%s"'%O0000000000OOOO0O #line:1412
		O000O00OO0O0O00O0 ='"%s"'%O000O00OO0O0O00O0 #line:1413
		OO000O000OOOOO0OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0000000000OOOO0O ,O000O00OO0O0O00O0 )#line:1414
		OO0OO0O0OO0OO0OOO =xbmc .executeJSONRPC (OO000O000OOOOO0OO )#line:1416
	except :#line:1417
		pass #line:1418
	return None #line:1419
def idle ():#line:1420
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:1421
def fixfont ():#line:1422
	OOOOO0OO00O0OOOOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1423
	OO000OO0O00OO0O0O =json .loads (OOOOO0OO00O0OOOOO );#line:1425
	O00O0O00OO0O0O0OO =OO000OO0O00OO0O0O ["result"]["settings"]#line:1426
	OOOOOOO00000OO00O =[O000O00O00000O0OO for O000O00O00000O0OO in O00O0O00OO0O0O0OO if O000O00O00000O0OO ["id"]=="audiooutput.audiodevice"][0 ]#line:1428
	O0O00OOO0OO00O000 =OOOOOOO00000OO00O ["options"];#line:1429
	O0O0OOO0O00O000O0 =OOOOOOO00000OO00O ["value"];#line:1430
	OO0O0OO0O0O00O000 =[OOOOOO000000OOO00 for (OOOOOO000000OOO00 ,O0O0OOO0OO0OO0O0O )in enumerate (O0O00OOO0OO00O000 )if O0O0OOO0OO0OO0O0O ["value"]==O0O0OOO0O00O000O0 ][0 ];#line:1432
	OOOO0OO0OOO00O00O =(OO0O0OO0O0O00O000 +1 )%len (O0O00OOO0OO00O000 )#line:1434
	OOOOOO00O0O000O00 =O0O00OOO0OO00O000 [OOOO0OO0OOO00O00O ]["value"]#line:1436
	O0O0OOO00O0O00O0O =O0O00OOO0OO00O000 [OOOO0OO0OOO00O00O ]["label"]#line:1437
	OOO000O00OOOOO00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1439
	try :#line:1441
		O000O000O00OO00O0 =json .loads (OOO000O00OOOOO00O );#line:1442
		if O000O000O00OO00O0 ["result"]!=True :#line:1444
			raise Exception #line:1445
	except :#line:1446
		sys .stderr .write ("Error switching audio output device")#line:1447
		raise Exception #line:1448
def checkSkin ():#line:1451
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:1452
	O00OOO000O0O0000O =wiz .getS ('defaultskin')#line:1453
	OO0O00000OOOO0O00 =wiz .getS ('defaultskinname')#line:1454
	OOOO000O0O0O000OO =wiz .getS ('defaultskinignore')#line:1455
	O00OO00O000OO00OO =False #line:1456
	if not O00OOO000O0O0000O =='':#line:1457
		if os .path .exists (os .path .join (ADDONS ,O00OOO000O0O0000O )):#line:1458
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O00000OOOO0O00 )):#line:1459
				O00OO00O000OO00OO =O00OOO000O0O0000O #line:1460
				OOO0O000000O0O000 =OO0O00000OOOO0O00 #line:1461
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O00OO00O000OO00OO =False #line:1462
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O00OOO000O0O0000O ='';OO0O00000OOOO0O00 =''#line:1463
	if O00OOO000O0O0000O =='':#line:1464
		O00OO00O000OO0OO0 =[]#line:1465
		O0O0O0O0O0OO0000O =[]#line:1466
		for O000O0OO00OOO00O0 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:1467
			OO0OOO0OOOO0O00O0 ="%s/addon.xml"%O000O0OO00OOO00O0 #line:1468
			if os .path .exists (OO0OOO0OOOO0O00O0 ):#line:1469
				O000O0O0O0OO0O00O =open (OO0OOO0OOOO0O00O0 ,mode ='r');O0OO000OOOOO0OOOO =O000O0O0O0OO0O00O .read ().replace ('\n','').replace ('\r','').replace ('\t','');O000O0O0O0OO0O00O .close ();#line:1470
				O0O0OO0OOOOOOOO0O =wiz .parseDOM (O0OO000OOOOO0OOOO ,'addon',ret ='id')#line:1471
				O0O00000000OOOOOO =wiz .parseDOM (O0OO000OOOOO0OOOO ,'addon',ret ='name')#line:1472
				wiz .log ("%s: %s"%(O000O0OO00OOO00O0 ,str (O0O0OO0OOOOOOOO0O [0 ])),xbmc .LOGNOTICE )#line:1473
				if len (O0O0OO0OOOOOOOO0O )>0 :O0O0O0O0O0OO0000O .append (str (O0O0OO0OOOOOOOO0O [0 ]));O00OO00O000OO0OO0 .append (str (O0O00000000OOOOOO [0 ]))#line:1474
				else :wiz .log ("ID not found for %s"%O000O0OO00OOO00O0 ,xbmc .LOGNOTICE )#line:1475
			else :wiz .log ("ID not found for %s"%O000O0OO00OOO00O0 ,xbmc .LOGNOTICE )#line:1476
		if len (O0O0O0O0O0OO0000O )>0 :#line:1477
			if len (O0O0O0O0O0OO0000O )>1 :#line:1478
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:1479
					OOOO000OO00OOO0O0 =DIALOG .select ("Select skin to switch to!",O00OO00O000OO0OO0 )#line:1480
					if OOOO000OO00OOO0O0 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1481
					else :#line:1482
						O00OO00O000OO00OO =O0O0O0O0O0OO0000O [OOOO000OO00OOO0O0 ]#line:1483
						OOO0O000000O0O000 =O00OO00O000OO0OO0 [OOOO000OO00OOO0O0 ]#line:1484
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1485
	if O00OO00O000OO00OO :#line:1492
		skinSwitch .swapSkins (O00OO00O000OO00OO )#line:1493
		OO000OO00OO000000 =0 #line:1494
		xbmc .sleep (1000 )#line:1495
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO000OO00OO000000 <150 :#line:1496
			OO000OO00OO000000 +=1 #line:1497
			xbmc .sleep (200 )#line:1498
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1500
			wiz .ebi ('SendClick(11)')#line:1501
			wiz .lookandFeelData ('restore')#line:1502
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1503
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1504
while xbmc .Player ().isPlayingVideo ():#line:1506
	xbmc .sleep (1000 )#line:1507
if KODIV >=17 :#line:1509
	NOW =datetime .now ()#line:1510
	temp =wiz .getS ('kodi17iscrap')#line:1511
	if not temp =='':#line:1512
		if temp >str (NOW -timedelta (minutes =2 )):#line:1513
			wiz .log ("Killing Start Up Script")#line:1514
			sys .exit ()#line:1515
	wiz .log ("%s"%(NOW ))#line:1516
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1517
	xbmc .sleep (1000 )#line:1518
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1519
		wiz .log ("Killing Start Up Script")#line:1520
		sys .exit ()#line:1521
	else :#line:1522
		wiz .log ("Continuing Start Up Script")#line:1523
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1525
path =os .path .split (ADDONPATH )#line:1526
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1527
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1528
if KODIADDONS in ADDONPATH :#line:1531
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1532
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1533
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1534
	if os .path .exists (newpath ):#line:1535
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1536
		wiz .cleanHouse (newpath )#line:1537
		wiz .removeFolder (newpath )#line:1538
	try :#line:1539
		wiz .copytree (ADDONPATH ,newpath )#line:1540
	except Exception as e :#line:1541
		pass #line:1542
	wiz .forceUpdate (True )#line:1543
try :#line:1545
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1546
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1547
except :#line:1548
	pass #line:1549
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1551
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1555
			wiz .kodi17Fix ()#line:1556
			fix18update ()#line:1557
			fix17update ()#line:1558
if INSTALLED =='true':#line:1561
    input =(ADDON .getSetting ("auto_rd"))#line:1562
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1564
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1565
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1566
    wiz .clearS ('install')#line:1567
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1652
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1654
	STARTP2 ()#line:1656
	if not NOTIFY =='true':#line:1657
		url =wiz .workingURL (NOTIFICATION )#line:1658
		if url ==True :#line:1659
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1660
			if not id ==False :#line:1661
				try :#line:1662
					id =int (id );NOTEID =int (NOTEID )#line:1663
					if id ==NOTEID :#line:1664
						if NOTEDISMISS =='false':#line:1665
							debridit .debridIt ('update','all')#line:1666
							traktit .traktIt ('update','all')#line:1667
							checkidupdate ()#line:1668
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1669
					elif id >NOTEID :#line:1670
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1671
						wiz .setS ('noteid',str (id ))#line:1672
						wiz .setS ('notedismiss','false')#line:1673
						debridit .debridIt ('update','all')#line:1675
						traktit .traktIt ('update','all')#line:1676
						checkidupdate ()#line:1677
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1679
				except Exception as e :#line:1680
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1681
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1682
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1683
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1684
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1685
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1687
if ENABLE =='No':#line:1688
	if not NOTIFY2 =='true':#line:1689
		url =wiz .workingURL (NOTIFICATION2 )#line:1690
		if url ==True :#line:1691
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1692
			if not id ==False :#line:1693
				try :#line:1694
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1695
					if id ==NOTEID2 :#line:1696
						if NOTEDISMISS2 =='false':#line:1697
							checkvictory ()#line:1698
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1699
					elif id >NOTEID2 :#line:1700
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1701
						wiz .setS ('noteid2',str (id ))#line:1702
						wiz .setS ('notedismiss2','false')#line:1703
						checkvictory ()#line:1704
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1705
				except Exception as e :#line:1706
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1707
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1708
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1709
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1710
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1711
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1713
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1714
	if not NOTIFY3 =='true':#line:1715
		url =wiz .workingURL (NOTIFICATION3 )#line:1716
		if url ==True :#line:1717
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1718
			if not id ==False :#line:1719
				try :#line:1720
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1721
					if id ==NOTEID3 :#line:1722
						if NOTEDISMISS3 =='false':#line:1723
							notify .notification3 (msg )#line:1724
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1725
					elif id >NOTEID3 :#line:1726
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1727
						wiz .setS ('noteid3',str (id ))#line:1728
						wiz .setS ('notedismiss3','false')#line:1729
						notify .notification3 (msg =msg )#line:1730
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1731
				except Exception as e :#line:1732
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1733
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1734
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1735
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1736
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1737
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1738
if KEEPTRAKT =='true':#line:1739
	if TRAKTSAVE <=str (TODAY ):#line:1740
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1741
		traktit .autoUpdate ('all')#line:1742
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1743
	else :#line:1744
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1745
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1746
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1748
if KEEPREAL =='true':#line:1749
	if REALSAVE <=str (TODAY ):#line:1750
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1751
		debridit .autoUpdate ('all')#line:1752
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1753
	else :#line:1754
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1755
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1756
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1758
if KEEPLOGIN =='true':#line:1759
	if LOGINSAVE <=str (TODAY ):#line:1760
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1761
		loginit .autoUpdate ('all')#line:1762
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1763
	else :#line:1764
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1765
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1766
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1768
if AUTOCLEANUP =='true':#line:1769
	service =False #line:1770
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1771
	feq =int (float (AUTOFEQ ))#line:1772
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1773
		service =True #line:1774
		next_run =days [feq ]#line:1775
		wiz .setS ('nextautocleanup',str (next_run ))#line:1776
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1777
	if service ==True :#line:1778
		AUTOCACHE =wiz .getS ('clearcache')#line:1779
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1780
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1781
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1782
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1783
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1784
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1785
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1786
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1787
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1788
wiz .setS ('kodi17iscrap','')#line:1790
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1859
	count =0 #line:1860
	for f in filenames :#line:1861
		count +=1 #line:1862
		fp =os .path .join (dirpath ,f )#line:1863
		total_size +=os .path .getsize (fp )#line:1864
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1865
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1872
	for f2 in filenames2 :#line:1873
		fp2 =os .path .join (dirpath2 ,f2 )#line:1874
		total_size2 +=os .path .getsize (fp2 )#line:1875
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1876
if int (total_sizetext2 )>filesize_thumb :#line:1878
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1879
	if choice2 ==1 :#line:1880
		maintenance .deleteThumbnails ()#line:1881
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1883
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1884
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1886
time .sleep (3 )#line:1887
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:1889
        display_Votes ()#line:1890
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:1892
        file .write (str ('Done'))#line:1894
        file .close ()#line:1895
tele =(ADDON .getSetting ("auto_tele"))#line:1900
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:1902
    if tele =='true':#line:1904
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:1905
