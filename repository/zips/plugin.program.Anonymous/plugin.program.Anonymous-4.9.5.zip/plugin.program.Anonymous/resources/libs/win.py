# -*- coding: utf-8 -*-
import subprocess
import xbmc ,os#,xbmcvfs
# from threading import Thread

def callprocess(process, args=False):
    if args:
        subprocess.call([process, args], creationflags=0x08000000)
    else:
        subprocess.call([process], creationflags=0x08000000)

# try:
    # try:
        # kodipath = [os.path.join(xbmc.translatePath('special://xbmc/'), 'kodi.exe')]
    # except:
        # kodipath = [os.path.join(xbmcvfs.translatePath('special://xbmc/'), 'kodi.exe')]
    # try:
        # if 'portable_data' in xbmc.translatePath('special://home/'):
            # kodipath += ['-p']
    # except:
        # if 'portable_data' in xbmcvfs.translatePath('special://home/'):
            # kodipath += ['-p']
    # Thread(target=callprocess, args=kodipath).start()
# except:
    # pass
try:
    exe = os.path.normcase(r'C:\AnonymousTV\AnonymousTV.lnk')
    subprocess.Popen(exe, shell=True)
except:
    pass
# try:
    # exe = os.path.normcase(r'C:\Program Files (x86)\Kodi\kodi.exe')
    # subprocess.Popen(exe, shell=True)
# except:
    # pass
# try:
    # exe = os.path.normcase(r'C:\Program Files\Kodi\kodi.exe')
    # subprocess.Popen(exe, shell=True)
# except:
    # pass
# try:
    # exe = os.path.normcase(r'C:\Program Files (x86)\Anonymous TV\kodi.exe')
    # subprocess.Popen(exe, shell=True)
# except:
    # pass
# try:
    # exe = os.path.normcase(r'C:\Program Files\Anonymous TV\kodi.exe')
    # subprocess.Popen(exe, shell=True)
# except:
    # pass
# try:
    # Thread(target=callprocess, args=[r'C:\Program Files (x86)\Kodi\kodi.exe']).start()
# except:
    # pass
# try:
    # Thread(target=callprocess, args=[r'C:\Program Files\Kodi\kodi.exe']).start()
# except:
    # pass
# '''
xbmc.sleep(150)
os._exit(1)
