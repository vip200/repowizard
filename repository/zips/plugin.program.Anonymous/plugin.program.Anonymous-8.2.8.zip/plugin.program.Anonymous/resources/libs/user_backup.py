# coding: utf-8
"""
גיבוי ושחזור נתוני משתמש לשרת (ZIP).
"""
import json
import logging
import mimetypes
import os
import time
import uuid
import zipfile
from datetime import date, datetime, timedelta

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.libs import wizard as wiz
from resources.libs.device_id import get_device_id

translatepath = xbmcvfs.translatePath
ADDON = xbmcaddon.Addon()
PROFILE = translatepath('special://profile/')
BASE_URL = "https://kodivip.com"
ADDONTITLE = "Anonymous TV"

_backup_lock = False
_LAST_BACKUP_STAMP_NAME = "last_backup.stamp"
_BACKUP_LOCK_NAME = "backup.lock"
_BACKUP_LOCK_MAX_AGE = 600  # 10 minutes


def get_device_name():
    device_id = wiz.getS("device_id") or get_device_id()
    if " | " in device_id:
        return device_id.split(" | ", 1)[0].strip()
    return device_id.strip() or "device"


def _addon_data_dir():
    return translatepath(ADDON.getAddonInfo("profile"))


def _stamp_path():
    return os.path.join(_addon_data_dir(), _LAST_BACKUP_STAMP_NAME)


def _lock_path():
    return os.path.join(_addon_data_dir(), _BACKUP_LOCK_NAME)


def _get_setting(name, default=""):
    val = wiz.getS(name)
    if val is False or val is None:
        return default
    return str(val).strip() or default


def _get_last_backup_date():
    """תאריך הגיבוי האחרון — קובץ stamp (אמין) ואז settings."""
    stamp_file = _stamp_path()
    if os.path.isfile(stamp_file):
        try:
            with open(stamp_file, "r", encoding="utf-8") as f:
                parsed = _parse_date(f.read().strip())
            if parsed:
                return parsed
        except Exception:
            pass

    parsed = _parse_date(_get_setting("last_backup_date"))
    if parsed:
        _write_last_backup_date(parsed, sync_settings=False)
    return parsed


def _write_last_backup_date(when=None, sync_settings=True):
    if when is None:
        when = date.today()
    stamp = when.strftime("%d.%m.%Y")
    try:
        data_dir = _addon_data_dir()
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
        tmp = _stamp_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(stamp)
        os.replace(tmp, _stamp_path())
    except Exception as e:
        logging.warning("Failed to write backup stamp: %s", e)
    if sync_settings:
        try:
            wiz.setS("last_backup_date", stamp)
        except Exception:
            pass


def _is_backup_locked():
    lock_file = _lock_path()
    if not os.path.isfile(lock_file):
        return False
    try:
        age = time.time() - os.path.getmtime(lock_file)
        if age > _BACKUP_LOCK_MAX_AGE:
            os.remove(lock_file)
            return False
        return True
    except Exception:
        return False


def _acquire_backup_lock():
    global _backup_lock
    if _backup_lock or _is_backup_locked():
        return False
    _backup_lock = True
    try:
        data_dir = _addon_data_dir()
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
        with open(_lock_path(), "w", encoding="utf-8") as f:
            f.write(datetime.now().isoformat())
        return True
    except Exception:
        _backup_lock = False
        return False


def _release_backup_lock():
    global _backup_lock
    _backup_lock = False
    try:
        if os.path.isfile(_lock_path()):
            os.remove(_lock_path())
    except Exception:
        pass


def _post_json(url, payload):
    import urllib.error
    import urllib.request

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode("utf-8"))
        except Exception:
            return {"success": False, "message": "שגיאת HTTP: %s" % e.code}
    except Exception as e:
        return {"success": False, "message": str(e)}


def _post_multipart(url, fields, file_path):
    import urllib.request

    boundary = str(uuid.uuid4())
    file_name = os.path.basename(file_path)
    mime_type, _ = mimetypes.guess_type(file_path)
    mime_type = mime_type or "application/zip"

    with open(file_path, "rb") as f:
        file_data = f.read()

    parts = []

    def add_part(name, value):
        parts.append(
            "--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n"
            % (boundary, name, value)
        )

    def add_file_part(name, filename, content_type, data):
        parts.append(
            "--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\n"
            "Content-Type: %s\r\n\r\n" % (boundary, name, filename, content_type)
        )
        parts.append(data)
        parts.append("\r\n")

    for key, value in fields.items():
        add_part(key, value)
    add_file_part("file", file_name, mime_type, file_data)
    parts.append("--%s--\r\n" % boundary)

    body = b""
    for part in parts:
        body += part if isinstance(part, bytes) else part.encode("utf-8")

    headers = {
        "Content-Type": "multipart/form-data; boundary=%s" % boundary,
        "Content-Length": str(len(body)),
    }
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=300) as resp:
        return json.loads(resp.read().decode("utf-8"))


def get_backup_file_paths():
    """רשימת קבצים לגיבוי (נתיב מלא, נתיב יחסי בתוך profile)."""
    paths = []

    favourites = os.path.join(PROFILE, "favourites.xml")
    if os.path.isfile(favourites):
        paths.append((favourites, favourites[len(PROFILE):].replace("\\", "/")))

    myvideos_db = wiz.latestDB("MyVideos")
    if myvideos_db:
        db_path = os.path.join(PROFILE, "Database", myvideos_db)
        if os.path.isfile(db_path):
            rel = db_path[len(PROFILE):].replace("\\", "/")
            paths.append((db_path, rel))

    tele = translatepath("special://profile/addon_data/plugin.video.telemedia")
    for rel_name in ("cache_play.db", "database.db"):
        full = os.path.join(tele, rel_name)
        if os.path.isfile(full):
            paths.append((full, full[len(PROFILE):].replace("\\", "/")))

    novix = translatepath("special://profile/addon_data/plugin.video.novix")
    for rel_name in ("settings.xml", "watched.db"):
        full = os.path.join(novix, rel_name)
        if os.path.isfile(full):
            paths.append((full, full[len(PROFILE):].replace("\\", "/")))

    skin = translatepath("special://profile/addon_data/skin.anonymoustv")
    skin_settings = os.path.join(skin, "settings.xml")
    if os.path.isfile(skin_settings):
        paths.append((skin_settings, skin_settings[len(PROFILE):].replace("\\", "/")))

    drax = translatepath("special://profile/addon_data/plugin.video.drax")
    drax_playstate = os.path.join(drax, "playstate.db")
    if os.path.isfile(drax_playstate):
        paths.append((drax_playstate, drax_playstate[len(PROFILE):].replace("\\", "/")))

    return paths


def has_local_backup_data():
    return len(get_backup_file_paths()) > 0


def create_local_zip(username):
    """יוצר ZIP מקומי ומחזיר את הנתיב."""
    paths = get_backup_file_paths()
    if not paths:
        return None

    data_dir = _addon_data_dir()
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)

    zip_name = "user_backup_%s.zip" % username.strip().lower()
    zip_path = os.path.join(data_dir, zip_name)

    if os.path.isfile(zip_path):
        try:
            os.remove(zip_path)
        except OSError:
            pass

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for full_path, arc_name in paths:
            try:
                zf.write(full_path, arc_name)
            except Exception as e:
                logging.warning("Backup skip %s: %s", full_path, e)

    return zip_path


def check_server_backup_exists(username, password):
    url = "%s/api/user-backup/exists" % BASE_URL
    return _post_json(url, {"username": username, "password": password})


def upload_backup(username, password, zip_path=None, silent=False, force=False):
    if not force and not _acquire_backup_lock():
        logging.info("Backup skipped: another backup is already running")
        return False

    try:
        if not zip_path:
            zip_path = create_local_zip(username)
        if not zip_path or not os.path.isfile(zip_path):
            if not silent:
                xbmcgui.Dialog().ok(ADDONTITLE, "אין קבצים לגיבוי")
            return False

        url = "%s/api/user-backup/upload" % BASE_URL
        try:
            result = _post_multipart(
                url,
                {
                    "username": username,
                    "password": password,
                    "device_name": get_device_name(),
                },
                zip_path,
            )
        except Exception as e:
            logging.warning("Backup upload failed: %s", e)
            if not silent:
                xbmcgui.Dialog().ok(ADDONTITLE, "שגיאה בהעלאת הגיבוי:\n%s" % e)
            return False

        if result.get("success"):
            _write_last_backup_date()
            wiz.setS("device_backup", "true")
            if not silent:
                xbmcgui.Dialog().ok(
                    ADDONTITLE,
                    "הגיבוי הועלה בהצלחה\nמכשיר: %s\nתאריך: %s"
                    % (result.get("device_name", get_device_name()), result.get("date", "")),
                )
            return True

        if not silent:
            xbmcgui.Dialog().ok(ADDONTITLE, result.get("message", "הגיבוי נכשל"))
        return False
    finally:
        _release_backup_lock()


def download_backup(username, password, filename=None):
    import urllib.error
    import urllib.request

    url = "%s/api/user-backup/download" % BASE_URL
    payload = {"username": username, "password": password}
    if filename:
        payload["filename"] = filename

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    data_dir = _addon_data_dir()
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)

    dest = os.path.join(data_dir, "restore_backup.zip")
    try:
        with urllib.request.urlopen(req, timeout=300) as response:
            with open(dest, "wb") as f:
                while True:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
        return dest
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read().decode("utf-8"))
            logging.warning("Download backup failed: %s", err.get("message"))
        except Exception:
            logging.warning("Download backup HTTP error: %s", e.code)
        return None
    except Exception as e:
        logging.warning("Download backup failed: %s", e)
        return None


def restore_from_zip(zip_path):
    """משחזר קבצים מ-ZIP לתיקיית profile."""
    if not zip_path or not os.path.isfile(zip_path):
        return False

    restored = 0
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.namelist():
            if member.endswith("/"):
                continue
            dest = os.path.join(PROFILE, member.replace("/", os.sep))
            dest_dir = os.path.dirname(dest)
            if dest_dir and not os.path.exists(dest_dir):
                os.makedirs(dest_dir)
            try:
                with zf.open(member) as src, open(dest, "wb") as out:
                    out.write(src.read())
                restored += 1
            except Exception as e:
                logging.warning("Restore skip %s: %s", member, e)

    try:
        os.remove(zip_path)
    except OSError:
        pass

    return restored > 0


def list_server_backups(username, password):
    url = "%s/api/user-backup/list" % BASE_URL
    return _post_json(url, {"username": username, "password": password})


def _format_size(size_bytes):
    try:
        size_bytes = int(size_bytes)
    except (TypeError, ValueError):
        return ""
    if size_bytes < 1024:
        return "%d B" % size_bytes
    if size_bytes < 1024 * 1024:
        return "%.1f KB" % (size_bytes / 1024.0)
    return "%.1f MB" % (size_bytes / (1024.0 * 1024.0))


def restore_backup(username, password, filename=None, silent=False):
    zip_path = download_backup(username, password, filename=filename)
    if not zip_path:
        if not silent:
            xbmcgui.Dialog().ok(ADDONTITLE, "לא נמצא גיבוי בשרת")
        return False

    ok = restore_from_zip(zip_path)
    if not silent:
        if ok:
            xbmcgui.Dialog().ok(ADDONTITLE, "השחזור הושלם בהצלחה")
        else:
            xbmcgui.Dialog().ok(ADDONTITLE, "השחזור נכשל")
    return ok


def backup_if_no_server_copy(username, password, silent=True):
    """גיבוי אוטומטי לפני התקנה אם אין גיבוי קודם בשרת."""
    if not has_local_backup_data():
        return False

    info = check_server_backup_exists(username, password)
    if not info.get("success"):
        return False
    if info.get("exists"):
        return False

    zip_path = create_local_zip(username)
    if not zip_path:
        return False
    return upload_backup(username, password, zip_path=zip_path, silent=silent)


def choose_backup_and_restore(username, password, silent=False):
    """מציג רשימת גיבויים מהשרת ומשחזר את הנבחר."""
    result = list_server_backups(username, password)
    if not result.get("success"):
        if not silent:
            xbmcgui.Dialog().ok(ADDONTITLE, result.get("message", "שגיאה בטעינת רשימת הגיבויים"))
        return False

    backups = result.get("backups") or []
    if not backups:
        if not silent:
            xbmcgui.Dialog().ok(ADDONTITLE, "לא נמצאו גיבויים בשרת")
        return False

    labels = []
    for item in backups:
        device_label = item.get("device_name") or "מכשיר לא ידוע"
        date_label = item.get("date") or item.get("filename", "")
        size_label = _format_size(item.get("size_bytes"))
        if size_label:
            labels.append("%s  |  %s  (%s)" % (device_label, date_label, size_label))
        else:
            labels.append("%s  |  %s" % (device_label, date_label))

    selected = xbmcgui.Dialog().select("בחר גיבוי לשחזור", labels)
    if selected < 0:
        return False

    chosen = backups[selected]
    filename = chosen.get("filename")
    device_label = chosen.get("device_name") or "מכשיר לא ידוע"
    date_label = chosen.get("date", "")

    confirm = xbmcgui.Dialog().yesno(
        ADDONTITLE,
        "האם לשחזר את הגיבוי של %s%s?"
        % (device_label, " מתאריך %s" % date_label if date_label else ""),
        yeslabel="[B]כן[/B]",
        nolabel="[B]לא[/B]",
    )
    if not confirm:
        return False

    return restore_backup(username, password, filename=filename, silent=silent)


def prompt_restore_after_install(username, password):
    """שואל את המשתמש אם לשחזר גיבוי אחרי התקנה."""
    info = check_server_backup_exists(username, password)
    if not info.get("success") or not info.get("exists"):
        return False

    count = info.get("count", 0)
    choice = xbmcgui.Dialog().yesno(
        ADDONTITLE,
        "נמצאו %d גיבויים בשרת.\nהאם לשחזר נתונים מגיבוי?" % count,
        yeslabel="[B]כן, בחר גיבוי[/B]",
        nolabel="[B]לא[/B]",
    )
    if choice:
        return choose_backup_and_restore(username, password, silent=False)
    return False


def _parse_date(date_str):
    if not date_str:
        return None
    try:
        return datetime.strptime(date_str.strip(), "%d.%m.%Y").date()
    except Exception:
        return None


def _parse_display_datetime(date_str):
    if not date_str:
        return None
    try:
        return datetime.strptime(date_str.strip(), "%d.%m.%Y %H:%M").date()
    except Exception:
        return _parse_date(date_str)


def _sync_last_backup_from_server(username, password):
    """אם אין stamp מקומי — מסנכרן מתאריך הגיבוי האחרון בשרת."""
    if _get_last_backup_date():
        return
    info = check_server_backup_exists(username, password)
    if not info.get("success") or not info.get("exists"):
        return
    latest = info.get("latest") or {}
    backup_date = _parse_display_datetime(latest.get("date", ""))
    if backup_date:
        _write_last_backup_date(backup_date)


def should_run_scheduled_backup():
    if _get_setting("device_backup") != "true":
        return False

    schedule = _get_setting("backup_schedule", "0")
    last_date = _get_last_backup_date()
    today = date.today()

    if schedule == "0":
        interval_days = 1
    elif schedule == "1":
        interval_days = 2
    else:
        interval_days = 7

    if not last_date:
        return True
    return (today - last_date).days >= interval_days


def run_scheduled_backup_if_due():
    username = _get_setting("user")
    password = _get_setting("password")
    if not username or not password:
        return False
    _sync_last_backup_from_server(username, password)
    if not should_run_scheduled_backup():
        return False
    if not has_local_backup_data():
        return False
    return upload_backup(username, password, silent=True)


def manual_backup():
    username = wiz.getS("user")
    password = wiz.getS("password")
    if not username:
        username = xbmcgui.Dialog().input("שם משתמש", type=xbmcgui.INPUT_ALPHANUM)
    if not password:
        password = xbmcgui.Dialog().input("סיסמה", option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not username or not password:
        xbmcgui.Dialog().ok(ADDONTITLE, "יש להזין שם משתמש וסיסמה")
        return
    upload_backup(username, password, silent=False, force=True)


def manual_restore():
    username = wiz.getS("user")
    password = wiz.getS("password")
    if not username:
        username = xbmcgui.Dialog().input("שם משתמש", type=xbmcgui.INPUT_ALPHANUM)
    if not password:
        password = xbmcgui.Dialog().input("סיסמה", option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not username or not password:
        xbmcgui.Dialog().ok(ADDONTITLE, "יש להזין שם משתמש וסיסמה")
        return

    choose_backup_and_restore(username, password, silent=False)
