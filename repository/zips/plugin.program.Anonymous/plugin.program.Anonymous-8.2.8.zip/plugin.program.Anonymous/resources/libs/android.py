import xbmc,os
xbmc.executebuiltin('StartAndroidActivity(org.xbmc.kodi)')
# xbmc.executebuiltin('StartAndroidActivity(vip.xbmc.kodi)')
xbmc.sleep(45)
os._exit(1)
