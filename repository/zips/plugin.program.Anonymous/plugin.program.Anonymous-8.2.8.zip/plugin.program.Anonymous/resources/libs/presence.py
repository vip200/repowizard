"""Report the presence of a registered Kodi device."""
import json
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener

import xbmc

from resources.libs import wizard
from resources.libs.device_id import get_device_id

URL = "https://kodivip.com/kodivip-control/api/device-presence"


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def run():
    monitor = xbmc.Monitor()
    opener = build_opener(NoRedirect())
    while not monitor.abortRequested():
        username = wizard.getS("user")
        password = wizard.getS("password")
        if username and password:
            payload = {"username": username, "password": password, "device_id": get_device_id()}
            request = Request(URL, json.dumps(payload).encode("utf-8"),
                              {"Content-Type": "application/json"}, method="POST")
            try:
                with opener.open(request, timeout=8):
                    pass
            except HTTPError as error:
                error.close()
            except (URLError, OSError):
                pass
        if monitor.waitForAbort(60):
            break
