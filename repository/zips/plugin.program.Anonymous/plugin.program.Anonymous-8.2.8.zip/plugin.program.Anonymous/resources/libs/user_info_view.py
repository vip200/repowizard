# -*- coding: utf-8 -*-

import json
import random

import xbmc
import xbmcaddon
import xbmcvfs

from resources.libs import wizard as wiz
from resources.libs.details_realdebrid import get_debrid_status_line
from resources.libs.send import get_version_update, post_json_local, send_user_info


def user_info():
    from threading import Thread

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    resuaddon = xbmcaddon.Addon('plugin.video.telemedia')
    settingz_addon = xbmcaddon.Addon('plugin.program.Settingz-Anon')
    backup_name = settingz_addon.getSetting('user_name')
    device_cunt = 'כמות מכשירים מותרת: ' + (wiz.getS('device') or '0')
    listen_port = resuaddon.getSetting('port')
    serialnumber = 'מכשיר רשום במערכת: ' + wiz.getS('device_id')

    rd = get_debrid_status_line()

    try:
        num = random.randint(1, 1001)
        data = {'type': 'td_send', 'info': json.dumps({'@type': 'getOption', 'name': 'my_id', '@extra': num})}
        event2 = post_json_local('http://127.0.0.1:%s/' % listen_port, data)
        my_id = event2.get('value', '')
        if not my_id:
            raise Exception('No TDLib ID returned')

        load_chats_until_ready(listen_port)
        data = {'type': 'getallchats', 'info': ''}
        event = post_json_local('http://127.0.0.1:%s/' % listen_port, data)
        status = event.get('status', {})
        if not status:
            wiz.setS('loadChats', '')
            load_chats_until_ready(listen_port)
            event = post_json_local('http://127.0.0.1:%s/' % listen_port, {'type': 'getallchats', 'info': ''})
            status = event.get('status', {})


        tele = 'חשבון טלמדיה: פעיל'
        wiz.setS('tele_on', 'true')
    except Exception:
        tele = 'חשבון טלמדיה: אינו פעיל'
        wiz.setS('tele_on', '')

    userdate = 'תקופת המנוי תסתיים בתאריך: ' + wiz.getS('date_user')
    update = 'גירסת מערכת: ' + get_version_update()
    username = 'שם משתמש: ' + wiz.getS('user')
    device = 'כמות מכשירים: ' + wiz.getS('device')
    wiz.setS('update', update)
    wiz.setS('tele_info', tele)
    wiz.setS('rd_info', rd)

    if backup_name:
        wiz.setS('device_backup', 'true')
        wiz.setS('device_backup_name', backup_name)
        device_backup = 'גיבוי מערכת: פעיל - שם הגיבוי הוא: ' + backup_name
    else:
        device_backup = 'גיבוי מערכת: לא פעיל'

    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    Thread(target=send_user_info, args=('channel_new_install', 'לחץ על החשבון שלי')).start()
    wiz.user_info_Window(tele, update, rd, userdate, username, device, device_backup, serialnumber, device_cunt)


def load_chats_until_ready(listen_port):
    if wiz.getS('loadChats') != '':
        return

    fail_count = 0
    max_tries = 5
    while fail_count < max_tries:
        num = random.randint(1, 1001)
        data1 = {
            'type': 'td_send',
            'info': json.dumps({
                '@type': 'loadChats',
                'limit': '1000',
                'chat_list': {'@type': 'chatListArchive'},
                '@extra': num,
            }),
        }
        event1 = post_json_local('http://127.0.0.1:%s/' % listen_port, data1)

        num = random.randint(1, 1001)
        data2 = {
            'type': 'td_send',
            'info': json.dumps({
                '@type': 'loadChats',
                'limit': '1000',
                'chat_list': {'@type': 'chatListMain'},
                '@extra': num,
            }),
        }
        event2 = post_json_local('http://127.0.0.1:%s/' % listen_port, data2)

        if event1.get('@type') == 'error' and event2.get('@type') == 'error':
            fail_count += 1
        else:
            fail_count = 0
        xbmc.sleep(200)

    wiz.setS('loadChats', 'stop')
