# -*- coding: utf-8 -*-
"""
Debrid account details for Anonymous TV user info window.
Reads credentials and enabled services from plugin.video.novix.
"""

import json
import logging
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.libs import wizard as wiz

NOVIX_ID = 'plugin.video.novix'
COBRA_ID = 'plugin.video.cobra'
MYACCOUNTS_ID = 'script.module.myaccounts'
REQUEST_TIMEOUT = 15

DEBRID_SERVICES = (
    {'prefix': 'rd', 'name': 'Real-Debrid', 'priority_key': 'rd.priority'},
    {'prefix': 'pm', 'name': 'Premiumize', 'priority_key': 'pm.priority'},
    {'prefix': 'ad', 'name': 'All Debrid', 'priority_key': 'ad.priority'},
    {'prefix': 'tb', 'name': 'TorBox', 'priority_key': 'tb.priority'},
    {'prefix': 'oc', 'name': 'Offcloud', 'priority_key': 'oc.priority'},
)

dialog = xbmcgui.Dialog()


class DebridAuthError(Exception):
    pass


def _addons_path():
    return xbmcvfs.translatePath('special://home/addons/')


def _addon_exists(addon_id):
    return os.path.exists(os.path.join(_addons_path(), addon_id))


def _settings_path(addon_id):
    return xbmcvfs.translatePath('special://profile/addon_data/%s/settings.xml' % addon_id)


def _addon_id_for_settings():
    if _addon_exists(NOVIX_ID):
        return NOVIX_ID
    if _addon_exists(COBRA_ID):
        return COBRA_ID
    if _addon_exists(MYACCOUNTS_ID):
        return MYACCOUNTS_ID
    return ''


def _fresh_setting(setting_id, default=''):
    addon_id = _addon_id_for_settings()
    if addon_id:
        path = _settings_path(addon_id)
        if os.path.exists(path):
            try:
                for node in ET.parse(path).getroot().findall('setting'):
                    if node.get('id') == setting_id:
                        return (node.text or default) if node.text is not None else default
            except Exception as e:
                logging.warning('_fresh_setting xml %s: %s' % (setting_id, e))
        try:
            return xbmcaddon.Addon(addon_id).getSetting(setting_id) or default
        except Exception:
            pass
    return default


def _write_setting(setting_id, value):
    addon_id = _addon_id_for_settings()
    if not addon_id:
        return
    try:
        xbmcaddon.Addon(addon_id).setSetting(setting_id, value)
    except Exception as e:
        logging.warning('_write_setting %s: %s' % (setting_id, e))


def _get_settings_addon():
    addon_id = _addon_id_for_settings()
    return xbmcaddon.Addon(addon_id) if addon_id else None


def _setting_keys(prefix):
    if prefix == 'rd' and _addon_exists(MYACCOUNTS_ID) and not _addon_exists(NOVIX_ID) and not _addon_exists(COBRA_ID):
        return {
            'enabled': 'realdebrid.enabled',
            'token': 'realdebrid.token',
            'client_id': 'realdebrid.client_id',
            'secret': 'realdebrid.secret',
            'refresh': 'realdebrid.refresh',
            'username': 'realdebrid.username',
        }
    return {
        'enabled': '%s.enabled' % prefix,
        'token': '%s.token' % prefix,
        'client_id': '%s.client_id' % prefix,
        'secret': '%s.secret' % prefix,
        'refresh': '%s.refresh' % prefix,
        'username': '%s.username' % prefix if prefix == 'rd' else '%s.account_id' % prefix,
    }


def _service_enabled(prefix):
    keys = _setting_keys(prefix)
    if _fresh_setting(keys['enabled']) != 'true':
        return False
    return bool(_fresh_setting(keys['token']))


def _enabled_services():
    services = [svc for svc in DEBRID_SERVICES if _service_enabled(svc['prefix'])]
    services.sort(key=lambda svc: int(_fresh_setting(svc['priority_key']) or '10'))
    return services


def _build_request(url, headers=None, data=None, http_method=None):
    headers = dict(headers or {})
    headers.setdefault('Connection', 'close')
    if data is not None and isinstance(data, dict):
        encoded = urllib.parse.urlencode(data).encode('utf-8')
        return urllib.request.Request(url, data=encoded, headers=headers)
    return urllib.request.Request(url, headers=headers)


def _as_dict(value):
    return value if isinstance(value, dict) else {}


def _refresh_rd_token():
    keys = _setting_keys('rd')
    client_id = _fresh_setting(keys['client_id'])
    secret = _fresh_setting(keys['secret'])
    refresh = _fresh_setting(keys['refresh'])
    if not all((client_id, secret, refresh)):
        return ''
    try:
        response = _request_json(
            'https://api.real-debrid.com/oauth/v2/token',
            data={
                'client_id': client_id,
                'client_secret': secret,
                'code': refresh,
                'grant_type': 'http://oauth.net/grant_type/device/1.0',
            },
            retries=1,
        )
        if not response or 'error' in response:
            return ''
        token = response.get('access_token', '')
        if not token:
            return ''
        _write_setting(keys['token'], token)
        _write_setting(keys['refresh'], response.get('refresh_token', refresh))
        return token
    except Exception as e:
        logging.warning('_refresh_rd_token: %s' % e)
        return ''


def _request_json(url, headers=None, data=None, method=None, retries=2):
    last_error = None
    for attempt in range(retries):
        try:
            req = _build_request(url, headers=headers, data=data, http_method=method)
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as response:
                body = response.read().decode('utf-8', errors='replace')
                if not body:
                    return {}
                result = json.loads(body)
                if result is None:
                    return {}
                if not isinstance(result, dict):
                    return {}
                if result.get('error') in ('bad_token', 'invalid_token'):
                    raise DebridAuthError(result.get('error'))
                return result
        except DebridAuthError:
            last_error = DebridAuthError('bad_token')
            if attempt + 1 < retries:
                time.sleep(0.3)
                continue
            raise
        except urllib.error.HTTPError as e:
            last_error = e
            if e.code == 401 and attempt + 1 < retries:
                time.sleep(0.3)
                continue
            logging.warning('_request_json HTTP %s %s: %s' % (e.code, url, e))
            raise
        except Exception as e:
            last_error = e
            if attempt + 1 < retries:
                time.sleep(0.3)
                continue
            logging.warning('_request_json %s: %s' % (url, e), exc_info=True)
            raise
    if last_error:
        raise last_error
    return {}


def _format_date(value, fmt=None):
    if value in (None, '', 0, '0'):
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value).strftime('%d.%m.%Y')
    value = str(value)
    for pattern in ('%Y-%m-%dT%H:%M:%S.%fZ', '%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%d'):
        try:
            return datetime.strptime(value[:26] if '.%f' in pattern else value[:10], pattern).strftime('%d.%m.%Y')
        except ValueError:
            continue
    match = re.findall(r'(.+?)T', value)
    if match:
        parts = match[0].split('-')
        if len(parts) == 3:
            return '%s.%s.%s' % (parts[2], parts[1], parts[0])
    return value


def _days_remaining(date_value):
    if date_value in (None, '', 0, '0'):
        return None
    if isinstance(date_value, (int, float)):
        expires = datetime.fromtimestamp(date_value)
        return (expires.date() - datetime.today().date()).days
    for pattern in ('%Y-%m-%dT%H:%M:%S.%fZ', '%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%d', '%d.%m.%Y'):
        try:
            if pattern == '%d.%m.%Y':
                expires = datetime.strptime(date_value, pattern)
            else:
                raw = date_value if isinstance(date_value, str) else str(date_value)
                expires = datetime.strptime(raw[:26] if '.%f' in pattern else raw[:10], pattern)
            return (expires.date() - datetime.today().date()).days
        except ValueError:
            continue
    return None


def _expiry_text(date_value):
    date = _format_date(date_value)
    days = _days_remaining(date_value)
    if date and days is not None:
        return 'מסתיים בתאריך: %s (%s ימים)' % (date, days)
    if date:
        return 'מסתיים בתאריך: %s' % date
    if days is not None:
        return 'נותרו %s ימים' % days
    return None


def _info_parts(prefix, token):
    headers = {'Authorization': 'Bearer %s' % token}
    if prefix == 'rd':
        try:
            info = _as_dict(_request_json('https://app.real-debrid.com/rest/1.0/user', headers=headers))
        except (urllib.error.HTTPError, DebridAuthError) as e:
            if not isinstance(e, DebridAuthError) and getattr(e, 'code', 0) != 401:
                raise
            token = _refresh_rd_token()
            if not token:
                raise
            headers = {'Authorization': 'Bearer %s' % token}
            info = _as_dict(_request_json('https://app.real-debrid.com/rest/1.0/user', headers=headers, retries=1))
        parts = []
        expiry = _expiry_text(info.get('expiration'))
        if expiry:
            parts.append(expiry)
        if 'points' in info:
            parts.append('נקודות: %s' % info.get('points'))
            if int(info.get('points') or 0) >= 1000:
                xbmc.executebuiltin('Skin.SetString(points, true)')
            else:
                xbmc.executebuiltin('Skin.SetString(points,)')
        return parts

    if prefix == 'pm':
        headers['User-Agent'] = 'Novix'
        info = _as_dict(_request_json('https://www.premiumize.me/api/account/info', headers=headers))
        parts = []
        if info.get('customer_id'):
            parts.append('מזהה: %s' % info.get('customer_id'))
        expiry = _expiry_text(info.get('premium_until'))
        if expiry:
            parts.append(expiry)
        return parts

    if prefix == 'ad':
        response = _as_dict(_request_json('https://api.alldebrid.com/v4/user', headers=headers))
        data = _as_dict(response.get('data'))
        user = _as_dict(data.get('user') or response.get('user'))
        parts = []
        expiry = _expiry_text(user.get('premiumUntil'))
        if expiry:
            parts.append(expiry)
        return parts

    if prefix == 'tb':
        headers['User-Agent'] = 'Novix'
        info = _as_dict(_request_json('https://api.torbox.app/v1/api/user/me', headers=headers))
        data = info.get('data')
        if isinstance(data, dict):
            info = data
        plans = {0: 'Free', 1: 'Essential', 2: 'Pro', 3: 'Standard'}
        parts = []
        if info.get('plan') in plans:
            parts.append('חבילה: %s' % plans[info.get('plan')])
        expiry = _expiry_text(info.get('premium_expires_at'))
        if expiry:
            parts.append(expiry)
        return parts

    if prefix == 'oc':
        info = _as_dict(_request_json('https://offcloud.com/api/account/info', headers=headers))
        parts = []
        if info.get('user_id'):
            parts.append('מזהה: %s' % info.get('user_id'))
        status = 'Premium' if info.get('is_premium') else 'Expired'
        parts.append('סטטוס: %s' % status)
        expiry = _expiry_text(info.get('expiration_date'))
        if expiry:
            parts.append(expiry)
        return parts

    return []


def get_debrid_status_line():
    if not _addon_id_for_settings():
        return 'שירות Debrid: אינו פעיל'

    enabled = _enabled_services()
    if not enabled:
        return 'שירות Debrid: אינו פעיל'

    lines = []
    for svc in enabled:
        keys = _setting_keys(svc['prefix'])
        token = _fresh_setting(keys['token'])
        if not token:
            continue
        try:
            parts = _info_parts(svc['prefix'], token)
            if parts:
                lines.append('שירות %s: פעיל - %s' % (svc['name'], ', '.join(parts)))
            else:
                lines.append('שירות %s: פעיל' % svc['name'])
        except Exception as e:
            logging.warning('get_debrid_status_line %s: %s' % (svc['prefix'], e), exc_info=True)
            cached = _cached_debrid_line(svc['name'])
            if cached:
                lines.append(cached)
            else:
                lines.append('שירות %s: פעיל' % svc['name'])
    if not lines:
        return 'שירות Debrid: אינו פעיל'
    result = '[CR]'.join(lines)
    wiz.setS('rd_info_cache', result)
    return result


def _cached_debrid_line(service_name):
    cached = wiz.getS('rd_info_cache') or ''
    if not cached or service_name not in cached:
        return ''
    for chunk in cached.replace('[CR]', '\n').split('\n'):
        if chunk.strip().startswith('שירות %s:' % service_name):
            return chunk.strip()
    return ''


class RealDebrid:
    name = 'Real-Debrid'

    def __init__(self):
        self.addon = _get_settings_addon()
        self.keys = _setting_keys('rd')
        self.token = ''
        self.client_ID = 'X245A4XAIBGVM'
        self.secret = ''
        self.device_code = ''
        if self.addon:
            self.token = _fresh_setting(self.keys['token'])
            self.client_ID = _fresh_setting(self.keys['client_id']) or self.client_ID
            self.secret = _fresh_setting(self.keys['secret'])

    def account_info(self):
        if not self.token:
            return None
        return _request_json(
            'https://app.real-debrid.com/rest/1.0/user',
            headers={'Authorization': 'Bearer %s' % self.token},
        )

    def account_info_to_dialog(self):
        try:
            if not _service_enabled('rd'):
                return None
            parts = _info_parts('rd', self.token)
            if not parts:
                return None
            if len(parts) >= 2:
                return parts[0], parts[1]
            return parts[0], ''
        except Exception as e:
            logging.warning('account_info_to_dialog: %s' % e)
            return None

    def set_points(self):
        try:
            url = 'https://api.real-debrid.com/rest/1.0/settings/convertPoints/?auth_token=%s' % self.token
            req = urllib.request.Request(url, data=b'')
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
                if resp.status == 204:
                    user_info = self.account_info()
                    date = _format_date(user_info.get('expiration'))
                    wiz.LogNotify('Anonymous TV', 'הושלם, חשבון RD מסתיים ב: ' + (date or ''), 8000)
                    return
        except urllib.error.HTTPError as e:
            try:
                err = json.loads(e.read().decode())
                wiz.LogNotify('[COLOR gold]%s[/COLOR]' % err, '[COLOR white]רק מעל 1000 נקודות ניתן לממש[/COLOR]', 3500)
            except Exception:
                pass

    def refresh_token(self):
        try:
            if not self.addon:
                return False
            self.client_ID = _fresh_setting(self.keys['client_id'])
            self.secret = _fresh_setting(self.keys['secret'])
            self.device_code = _fresh_setting(self.keys['refresh'])
            if not self.client_ID or not self.secret or not self.device_code:
                return False
            success, error = self.get_token()
            if not success:
                logging.warning('Unable to refresh RD token: %s' % error)
                return False
            return True
        except Exception as e:
            logging.warning('refresh_token: %s' % e)
            return False

    def get_token(self):
        try:
            post_data = {
                'client_id': self.client_ID,
                'client_secret': self.secret,
                'code': self.device_code,
                'grant_type': 'http://oauth.net/grant_type/device/1.0',
            }
            response = _request_json('https://api.real-debrid.com/oauth/v2/token', data=post_data)
            if 'error' in response:
                return False, response
            self.token = response['access_token']
            time.sleep(0.5)
            account_info = self.account_info()
            username = account_info.get('username', '')
            self.addon.setSetting(self.keys['username'], username)
            _write_setting(self.keys['username'], username)
            _write_setting(self.keys['client_id'], self.client_ID)
            _write_setting(self.keys['secret'], self.secret)
            _write_setting(self.keys['token'], self.token)
            _write_setting(self.keys['refresh'], response['refresh_token'])
            return True, None
        except Exception as e:
            logging.warning('get_token: %s' % e)
            return False, None

    def revoke(self):
        try:
            if not self.addon:
                return
            for key in ('client_id', 'secret', 'token', 'refresh', 'username'):
                self.addon.setSetting(self.keys.get(key, 'rd.%s' % key), '')
        except Exception as e:
            logging.warning('revoke: %s' % e)
