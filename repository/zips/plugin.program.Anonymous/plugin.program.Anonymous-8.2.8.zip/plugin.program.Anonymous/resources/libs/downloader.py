
import xbmc, xbmcgui, urllib, sys, time, uservar

ADDONTITLE     = uservar.ADDONTITLE
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
from resources.libs.wizard import openURL
from resources.libs import wizard as wiz

def download(url, dest, dp = None):
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create(ADDONTITLE ,"Downloading Content",' ', ' ')
    dp.update(0)
    with open(dest, 'wb') as f:
        response = openURL(url, stream=True)
        if not response:
            from resources.libs import wizard as wiz
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]הורדה לא פעילה[/COLOR]" % COLOR2,1500)
            return
        else:
            total = response.headers.get('Content-Length')

        if total is None:
            f.write(response.content)
        else:
            downloaded = 0
            total = int(total)
            start_time = time.time()
            mb = 1024*1024
            for chunk in response.iter_content(chunk_size=max(int(total/512), mb)):
                downloaded += len(chunk)
                f.write(chunk)
                
                done = int(100 * downloaded / total)
                kbps_speed = downloaded / (time.time() - start_time)
                
                if kbps_speed > 0 and not done >= 100:
                    eta = (total - downloaded) / kbps_speed
                else:
                    eta = 0
                kbps_speed = kbps_speed / 1024
                type_speed = 'KB'
                if kbps_speed >= 1024:
                    kbps_speed = kbps_speed / 1024
                    type_speed = 'MB'
                currently_downloaded = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % (COLOR2, COLOR1, downloaded / mb, COLOR1, total / mb)
                speed = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % (COLOR2, COLOR1, kbps_speed, type_speed)
                div = divmod(eta, 60)
                speed += '[B]ETA:[/B] [COLOR %s]%02d:%02d[/COLOR][/COLOR]' % (COLOR1, div[0], div[1])
                dp.update(done, '\n' + str(currently_downloaded) + '\n' + str(speed)) 
                if dp.iscanceled(): 
                    dp.close()
                    from resources.libs import wizard as wiz
                    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Download Cancelled[/COLOR]" % COLOR2,1500)
                    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                    sys.exit()
    
def download_update(url, dest, dp = None):
    dp = xbmcgui.DialogProgressBG()
    dp.create('[B][COLOR=white] מוריד עדכון מערכת [/COLOR][/B]', '[B][COLOR=silver]אנא המתן....[/COLOR][/B]')
    with open(dest, 'wb') as f:
        response = openURL(url, stream=True)
        if not response:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]עדכון המערכת לא זמין כעת.[/COLOR]" % COLOR2,1500)
            dp.close()
            sys.exit()
        else:
            total = response.headers.get('Content-Length')
        if total is None:
            f.write(response.content)
        else:
            downloaded = 0
            total = int(total)
            start_time = time.time()
            mb = 1024*1024
            for chunk in response.iter_content(chunk_size=max(int(total/512), mb)):
                downloaded += len(chunk)
                f.write(chunk)
                done = int(100 * downloaded / total)
                dp.update(int(done))
    dp.close()
def download_WizardBG(url, dest, dp = None):
    dp = xbmcgui.DialogProgressBG()
    dp.create('[B] Download Wizard Update [/B]','[B][COLOR=yellow]אנא המתן....[/COLOR][/B]')
    with open(dest, 'wb') as f:
        response = openURL(url, stream=True)
        if not response:
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]עדכון הויזארד לא זמין כעת.[/COLOR]" % COLOR2,1500)
            dp.close()
            sys.exit()
        else:
            total = response.headers.get('Content-Length')
        if total is None:
            f.write(response.content)
        else:
            downloaded = 0
            total = int(total)
            start_time = time.time()
            mb = 1024*1024
            for chunk in response.iter_content(chunk_size=max(int(total/512), mb)):
                downloaded += len(chunk)
                f.write(chunk)
                done = int(100 * downloaded / total)
                dp.update(int(done))
    dp.close()
def download_old(url, dest, dp = None):
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create(ADDONTITLE ,"Downloading Content",' ', ' ')
    dp.update(0)
    start_time=time.time()

    urllib.request.urlretrieve(url,dest,lambda nb, bs, fs: _pbhook(nb,bs,fs,dp, start_time))
def download_update_old(url, dest, dp = None):
     dp = xbmcgui.DialogProgressBG()
     dp.create('[B] מוריד עדכון מערכת [/B]', '[B][COLOR=silver]אנא המתן....                                         [/COLOR][/B]')

     
     urllib.request.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhookBG(nb,bs,fs,url,dp))
     dp.close()
def download_WizardBG_old(url, dest, dp = None):
     dp = xbmcgui.DialogProgressBG()
     dp.create('[B][COLOR=green]   Download Wizard Update                                      [/COLOR][/B]', '[B][COLOR=yellow]אנא המתן....                                         [/COLOR][/B]')
     urllib.request.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhookBG(nb,bs,fs,url,dp))
     dp.close()
def _pbhook(numblocks, blocksize, filesize, dp, start_time):
    # try: 
    percent = min(numblocks * blocksize * 100 / filesize, 100) 
    currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
    kbps_speed = numblocks * blocksize / (time.time() - start_time) 
    if kbps_speed > 0 and not percent == 100: 
        eta = (filesize - numblocks * blocksize) / kbps_speed 
    else: 
        eta = 0
    kbps_speed = kbps_speed / 1024 
    type_speed = 'KB'
    if kbps_speed >= 1024:
        kbps_speed = kbps_speed / 1024 
        type_speed = 'MB'
    total = float(filesize) / (1024 * 1024) 
    mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % (COLOR2, COLOR1, currently_downloaded, COLOR1, total) 
    e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % (COLOR2, COLOR1, kbps_speed, type_speed)
    e  += '[B]ETA:[/B] [COLOR '+COLOR1+']%02d:%02d[/COLOR][/COLOR]' % divmod(eta, 60)

    dp.update(int(percent), mbs+'\n'+e)

    if dp.iscanceled(): 
        dp.close()
        from resources.libs import wizard as wiz
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Download Cancelled[/COLOR]" % COLOR2,1500)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        sys.exit()
        
        
        
def _pbhookBG(numblocks, blocksize, filesize, url=None,dp=None):
     percent = min((numblocks*blocksize*100)/filesize, 100)
     dp.update(int(percent))