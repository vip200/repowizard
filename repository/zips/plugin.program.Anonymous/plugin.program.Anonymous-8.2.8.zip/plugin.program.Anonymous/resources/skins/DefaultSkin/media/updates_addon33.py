# -*- coding: utf-8 -*-
import json
import os
import time
import secrets
from datetime import datetime
from flask import Flask, jsonify, request, redirect, render_template_string, send_file
import requests
from security_manager import (
    security_manager,
    error_handler,
    extract_email_from_path,
    get_real_client_ip,
)

app = Flask(__name__)

UPDATES_FILE = "data_wizard/updates_posts.json"
VERSION_FILE = "data_wizard/version.json"
ADDON_VERSION = "1.0.0"
AUTHORIZED_USERS_FILE = security_manager.authorized_emails_file
DEFAULT_POSTER = "https://kodivip.com/files/logo/stremio_addon.png"
DEFAULT_BG = "https://kodivip.com/files/logo/stremio_back_update.png"
POSTER_VERSION_INFO = "https://kodivip.com/files/logo/version-logo.png"
POSTER_SYSTEM_UPDATE = "https://kodivip.com/files/logo/stremio_update.png"
POSTER_SYSTEM_REINSTALL = "https://kodivip.com/files/logo/reinstall.png"
WHAT_NEW = "https://kodivip.com/files/logo/what_new.png"
SUBSCRIPTION = "https://kodivip.com/files/logo/subscription.png"
QR_IMAGE_FILE = os.path.join(os.path.dirname(__file__), "images", "qr.jpg")
MAX_ITEMS = 50
ACTION_TOKEN_TTL_SECONDS = 180
ACTION_TOKENS = {}


@app.after_request
def after_request(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-User-Email"
    return response


def _check_authorization(email_from_path=None):
    """Reuse the same auth flow as the other addons."""
    email = email_from_path or request.args.get("email") or request.headers.get("X-User-Email")
    if not email:
        email = extract_email_from_path(request.path)

    if not email:
        return False, "התקנה ישירה לא מורשית - השתמש בממשק ההתקנה הרשמי", None

    real_ip = get_real_client_ip(request.headers, (request.remote_addr,))
    authorized, message = security_manager.check_authorization(email=email, ip=real_ip)
    return authorized, message, email


def _safe_str(value):
    if value is None:
        return ""
    return str(value).strip()


def _is_subscription_expired_message(message: str) -> bool:
    return "המנוי הסתיים" in _safe_str(message)


def _build_subscription_renew_qr_item():
    qr_url = f"{request.host_url.rstrip('/')}/updates/assets/qr.jpg"
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    return {
        "id": "update_subscription_renew_qr",
        "title": "💳 חידוש מנוי - סריקת ברקוד",
        "body": (
            "המנוי שלך הסתיים.\n"
            "סרוק את הברקוד שבתמונה כדי לחדש את המנוי.\n"
            "לאחר התשלום, נסה להיכנס שוב תוך כמה דקות."
        ),
        "published_at": now_str,
        "channel_name": "Billing",
        "image_url": qr_url,
    }


def _load_updates():
    if not os.path.exists(UPDATES_FILE):
        return {"items": []}

    try:
        with open(UPDATES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("items"), list):
            return data
    except Exception as exc:
        print(f"[updates] failed loading updates file: {exc}")

    return {"items": []}


def _get_latest_updates_text():
    """Return latest update body/title from updates_posts.json for system update card."""
    items = _load_updates().get("items", [])
    if not items:
        return "לא נמצאו פרטי עדכון נוספים בקובץ העדכונים."

    latest = items[0]
    title = _safe_str(latest.get("title"))
    body = _safe_str(latest.get("body"))

    if title and body:
        return f"{title}\n\n{body}"
    return body or title or "לא נמצאו פרטי עדכון נוספים בקובץ העדכונים."


def _parse_version(version_text):
    """Parse semantic-like versions safely, e.g. '1.2.10' -> (1, 2, 10)."""
    parts = []
    for raw in _safe_str(version_text).split("."):
        try:
            parts.append(int(raw))
        except ValueError:
            parts.append(0)
    return tuple(parts or [0])


def _load_version_info():
    defaults = {
        "current_version": ADDON_VERSION,
        "latest_version": "1.0.0",
        "release_notes": "",
        "released_at": "",
    }
    if not os.path.exists(VERSION_FILE):
        return defaults
    try:
        with open(VERSION_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            defaults.update({k: _safe_str(v) for k, v in data.items()})
    except Exception as exc:
        print(f"[updates] failed loading version file: {exc}")
    return defaults


def _is_system_update_available(version_info):
    return _parse_version(version_info.get("latest_version")) > _parse_version(ADDON_VERSION)


def _get_user_installed_version(email: str):
    """Read installed system version for a specific user from authorized_users.json."""
    if not email:
        return "0.0.0"
    try:
        if os.path.exists(AUTHORIZED_USERS_FILE):
            with open(AUTHORIZED_USERS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            for entry in data.get("authorized_emails", []):
                if isinstance(entry, dict) and _safe_str(entry.get("email")).lower() == email.lower():
                    return _safe_str(entry.get("installed_version")) or "0.0.0"
    except Exception as exc:
        print(f"[updates] failed loading user installed_version for {email}: {exc}")
    return "0.0.0"


def _get_authorized_user_entry(email: str):
    if not email:
        return None
    try:
        if os.path.exists(AUTHORIZED_USERS_FILE):
            with open(AUTHORIZED_USERS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            for entry in data.get("authorized_emails", []):
                if isinstance(entry, dict) and _safe_str(entry.get("email")).lower() == email.lower():
                    return entry
    except Exception as exc:
        print(f"[updates] failed loading authorized user entry for {email}: {exc}")
    return None


def _parse_iso_datetime(value: str):
    if not value:
        return None
    text = _safe_str(value)
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None


def _build_subscription_info_item(email: str):
    now = datetime.now()
    entry = _get_authorized_user_entry(email)
    if not entry:
        return {
            "id": "update_subscription_info",
            "title": "🧾 פרטי מנוי",
            "body": "לא נמצאו פרטי מנוי לחשבון זה.",
            "published_at": now.strftime("%Y-%m-%d %H:%M"),
            "channel_name": "System",
            "image_url": SUBSCRIPTION,
        }

    created_raw = _safe_str(entry.get("created_at"))
    expiry_raw = _safe_str(entry.get("expiry_date"))
    created_dt = _parse_iso_datetime(created_raw)
    expiry_dt = _parse_iso_datetime(expiry_raw)

    if expiry_dt:
        delta_days = (expiry_dt.date() - now.date()).days
        if delta_days < 0:
            remaining_label = f"פג לפני {abs(delta_days)} ימים"
        elif delta_days == 0:
            remaining_label = "פג היום"
        else:
            remaining_label = f"{delta_days} ימים"
        expiry_label = expiry_dt.strftime("%d/%m/%Y")
    else:
        remaining_label = "לא ידוע"
        expiry_label = "לא ידוע"

    if created_dt and expiry_dt:
        period_days = max((expiry_dt.date() - created_dt.date()).days, 0)
        period_label = f"{period_days} ימים"
    else:
        period_label = "לא ידוע"

    body = (
        f"תקופת מנוי: {period_label}\n"
        f"תאריך תפוגה: {expiry_label}\n"
        f"נותרו: {remaining_label}"
    )

    return {
        "id": "update_subscription_info",
        "title": "🧾 פרטי מנוי",
        "body": body,
        "published_at": now.strftime("%Y-%m-%d %H:%M"),
        "channel_name": "System",
        "image_url": SUBSCRIPTION,
    }


def _is_user_update_available(email: str, version_info):
    latest = _safe_str(version_info.get("latest_version")) or "0.0.0"
    installed = _get_user_installed_version(email)
    return _parse_version(latest) > _parse_version(installed)


def _to_meta(item):
    update_id = _safe_str(item.get("id"))
    title = _safe_str(item.get("title")) or "עדכון מערכת"
    body = _safe_str(item.get("body"))
    published_at = _safe_str(item.get("published_at"))
    channel_name = _safe_str(item.get("channel_name"))
    poster = _safe_str(item.get("image_url")) or WHAT_NEW

    short_desc = body[:220]
    if len(body) > 220:
        short_desc += "..."

    if published_at:
        short_desc = f"📅 {published_at}\n\n{short_desc}"
    if channel_name:
        short_desc += f"\n\n📢 {channel_name}"

    return {
        "id": update_id,
        "type": "📢 עדכונים",
        "name": title,
        "poster": poster,
        "background": DEFAULT_BG,
        "logo": poster,
        "posterShape": "poster",
        "description": short_desc or "עדכון חדש זמין",
        "genres": ["Updates"],
        "releaseInfo": published_at or "",
    }


def _error_catalog_response(message):
    return jsonify(error_handler.get_catalog_error_response(message))


@app.route("/assets/qr.jpg", methods=["GET", "OPTIONS"])
@app.route("/updates/assets/qr.jpg", methods=["GET", "OPTIONS"])
def renewal_qr_asset():
    if not os.path.exists(QR_IMAGE_FILE):
        return jsonify({"error": "QR image not found"}), 404
    return send_file(QR_IMAGE_FILE, mimetype="image/jpeg")


def _issue_action_token(email: str, mode: str) -> str:
    """Create one-time token so action runs only after user clicks a stream source."""
    now = time.time()
    # ניקוי טוקנים שפגו
    expired = [tok for tok, meta in ACTION_TOKENS.items() if meta.get("exp", 0) < now]
    for tok in expired:
        ACTION_TOKENS.pop(tok, None)

    token = secrets.token_urlsafe(24)
    ACTION_TOKENS[token] = {
        "email": email,
        "mode": mode,
        "exp": now + ACTION_TOKEN_TTL_SECONDS,
    }
    return token


def _consume_action_token(token: str):
    meta = ACTION_TOKENS.pop(token, None)
    if not meta:
        return None
    if meta.get("exp", 0) < time.time():
        return None
    return meta


def _render_action_result_page(mode: str, ok: bool, expired: bool = False):
    if expired:
        title = "תוקף הפעולה פג"
        subtitle = "הפעולה לא בוצעה"
        message = "תוקף הקישור פג. חזור לתוסף העדכונים ובצע את הפעולה מחדש."
        icon = "⏱"
        color = "#f59e0b"
    elif ok:
        title = "הפעולה הסתיימה בהצלחה"
        subtitle = "עדכון המערכת הושלם" if mode == "update" else "התקנה מחדש הושלמה"
        message = "יש להפעיל את Stremio מחדש כדי לוודא שכל השינויים נטענו."
        icon = "✅"
        color = "#10b981"
    else:
        title = "הפעולה נכשלה"
        subtitle = "עדכון/התקנה לא הושלמו"
        message = "נסה שוב מאוחר יותר או פנה למנהל המערכת."
        icon = "❌"
        color = "#ef4444"

    html = """
<!doctype html>
<html lang="he" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>{{ title }}</title>
  <style>
    body {
      margin: 0;
      background: #0b1020;
      color: #e5e7eb;
      font-family: Arial, sans-serif;
      display: grid;
      place-items: center;
      min-height: 100vh;
    }
    .card {
      width: min(92vw, 520px);
      background: #111827;
      border: 1px solid #1f2937;
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
      text-align: center;
    }
    .icon {
      font-size: 40px;
      margin-bottom: 12px;
    }
    h1 {
      margin: 0;
      font-size: 24px;
      color: {{ color }};
    }
    h2 {
      margin: 10px 0 0;
      font-size: 18px;
      color: #d1d5db;
      font-weight: 500;
    }
    p {
      margin-top: 16px;
      line-height: 1.6;
      color: #cbd5e1;
    }
    .note {
      margin-top: 18px;
      font-size: 13px;
      color: #94a3b8;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">{{ icon }}</div>
    <h1>{{ title }}</h1>
    <h2>{{ subtitle }}</h2>
    <p>{{ message }}</p>
    <div class="note">אפשר לסגור את החלון ולחזור ל‑Stremio.</div>
  </div>
</body>
</html>
"""
    return render_template_string(
        html,
        icon=icon,
        title=title,
        subtitle=subtitle,
        message=message,
        color=color,
    )


@app.route("/manifest.json", methods=["GET", "OPTIONS"])
@app.route("/updates/manifest.json", methods=["GET", "OPTIONS"])
@app.route("/updates/<email>/manifest.json", methods=["GET", "OPTIONS"])
def manifest(email=None):
    authorized, message, _ = _check_authorization(email)
    if not authorized and not _is_subscription_expired_message(message):
        return _error_catalog_response(message)

    version_info = _load_version_info()
    return jsonify(
        {
            "id": "com.stremio.vip.updates",
            "version": ADDON_VERSION,
            "name": "Stremio VIP Updates",
            "description": "עדכוני מערכת והודעות שירות",
            "logo": DEFAULT_POSTER,
            "background": DEFAULT_BG,
            "resources": ["catalog", "meta", "stream"],
            "types": ["📢 עדכונים"],
            "catalogs": [
                {
                    "type": "📢 עדכונים",
                    "id": "updates_feed",
                    "name": "📢 עדכונים",
                    "extra": [{"name": "search", "isRequired": False}],
                }
            ],
            "idPrefixes": ["update_"],
            "behaviorHints": {"p2p": False},
        }
    )


@app.route("/catalog/<type>/<catalog_id>.json", methods=["GET", "OPTIONS"])
@app.route("/updates/catalog/<type>/<catalog_id>.json", methods=["GET", "OPTIONS"])
@app.route("/updates/<email>/catalog/<type>/<catalog_id>.json", methods=["GET", "OPTIONS"])
def catalog(type, catalog_id, email=None):
    authorized, message, current_email = _check_authorization(email)
    if not authorized:
        if _is_subscription_expired_message(message):
            renew_item = _build_subscription_renew_qr_item()
            return jsonify({"metas": [_to_meta(renew_item)]})
        return _error_catalog_response(message)

    if type != "📢 עדכונים" or catalog_id != "updates_feed":
        return jsonify({"metas": []})

    search = _safe_str(request.args.get("search")).lower()

    # פריטים מיוחדים לפעולות מערכת
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    version_info = _load_version_info()
    addon_version = ADDON_VERSION
    user_installed_version = _get_user_installed_version(current_email)
    latest_version = _safe_str(version_info.get("latest_version")) or user_installed_version
    has_update = _is_user_update_available(current_email, version_info)

    special_items = [
        {
            "id": "update_version_info",
            "title": f"ℹ️ גרסת מערכת אצלך: {user_installed_version}",
            "body": (
                f"גרסת מערכת מותקנת אצלך: {user_installed_version}\n"
                f"גרסה אחרונה זמינה: {latest_version}\n"
                f"סטטוס: {'🆕 יש עדכון זמין' if has_update else '✅ המערכת מעודכנת'}"
            ),
            "published_at": _safe_str(version_info.get("released_at")) or now_str,
            "channel_name": "System",
            "image_url": POSTER_VERSION_INFO,
        },
        _build_subscription_info_item(current_email),
    ]

    if has_update:
        latest_updates_text = _get_latest_updates_text()
        special_items.append(
            {
                "id": "update_system_soft",
                "title": f"🆕 קיים עדכון מערכת: {latest_version}",
                "body": (
                    f"נמצאה גרסה חדשה ({latest_version}).\n\n"
                    f"{latest_updates_text}"
                ),
                "published_at": _safe_str(version_info.get("released_at")) or now_str,
                "channel_name": "System",
                "image_url": POSTER_SYSTEM_UPDATE,
            }
        )

    special_items.extend([
        {
            "id": "update_system_full",
            "title": "🧹 התקנה מחדש מלאה",
            "body": "מנקה את רשימת התוספים ומתקין מחדש את חבילת התוספים המלאה עבור החשבון.",
            "published_at": now_str,
            "channel_name": "System",
            "image_url": POSTER_SYSTEM_REINSTALL,
        },
    ])

    items = special_items + _load_updates().get("items", [])
    metas = []

    for item in items[:MAX_ITEMS]:
        title = _safe_str(item.get("title")).lower()
        body = _safe_str(item.get("body")).lower()
        if search and search not in title and search not in body:
            continue
        metas.append(_to_meta(item))

    return jsonify({"metas": metas})


@app.route("/meta/<type>/<id>.json", methods=["GET", "OPTIONS"])
@app.route("/updates/meta/<type>/<id>.json", methods=["GET", "OPTIONS"])
@app.route("/updates/<email>/meta/<type>/<id>.json", methods=["GET", "OPTIONS"])
def meta(type, id, email=None):
    authorized, message, current_email = _check_authorization(email)
    if not authorized:
        if id == "update_subscription_renew_qr" and _is_subscription_expired_message(message):
            item = _build_subscription_renew_qr_item()
            meta_data = _to_meta(item)
            meta_data["description"] = _safe_str(item.get("body")) or "סרוק את הברקוד לחידוש מנוי."
            return jsonify({"meta": meta_data})
        return _error_catalog_response(message)

    if type != "📢 עדכונים":
        return jsonify({"meta": None})

    # פריטי מערכת מיוחדים שלא נשמרים בקובץ העדכונים
    if id in ("update_version_info", "update_subscription_info", "update_system_soft", "update_system_full"):
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
        version_info = _load_version_info()
        addon_version = ADDON_VERSION
        user_installed_version = _get_user_installed_version(current_email)
        latest_version = _safe_str(version_info.get("latest_version")) or user_installed_version
        has_update = _is_user_update_available(current_email, version_info)

        if id == "update_version_info":
            title = f"ℹ️ גרסת מערכת אצלך: {user_installed_version}"
            body = (

                f"גרסת מערכת מותקנת אצלך: {user_installed_version}\n"
                f"גרסה אחרונה זמינה: {latest_version}\n"
                f"סטטוס: {'🆕 יש עדכון זמין' if has_update else '✅ המערכת מעודכנת'}\n"
                f"תאריך שחרור: {_safe_str(version_info.get('released_at')) or 'לא ידוע'}\n\n"
                f"הערות שחרור:\n{_safe_str(version_info.get('release_notes')) or 'אין הערות שחרור'}"
            )
            image_url = POSTER_VERSION_INFO
        elif id == "update_subscription_info":
            subscription_item = _build_subscription_info_item(current_email)
            title = _safe_str(subscription_item.get("title")) or "🧾 פרטי מנוי"
            body = _safe_str(subscription_item.get("body")) or "לא נמצאו פרטי מנוי לחשבון זה."
            image_url = _safe_str(subscription_item.get("image_url")) or SUBSCRIPTION
        elif id == "update_system_soft":
            latest_updates_text = _get_latest_updates_text()
            title = f"🆕 קיים עדכון מערכת: {user_installed_version} -> {latest_version}"
            body = (
                f"יעד עדכון: {latest_version}\n\n"
                f"{latest_updates_text}"
            )
            image_url = POSTER_SYSTEM_UPDATE
        else:
            title = "🧹 התקנה מחדש מלאה"
            body = "מנקה את רשימת התוספים ומתקין מחדש את חבילת התוספים המלאה עבור החשבון."
            image_url = POSTER_SYSTEM_REINSTALL

        item = {
            "id": id,
            "title": title,
            "body": body,
            "published_at": _safe_str(version_info.get("released_at")) or now_str,
            "channel_name": "System",
            "image_url": image_url,
        }
    else:
        items = _load_updates().get("items", [])
        item = next((x for x in items if _safe_str(x.get("id")) == id), None)
        if not item:
            return jsonify({"meta": None})

    meta_data = _to_meta(item)
    full_body = _safe_str(item.get("body")) or "אין תוכן לעדכון"
    published_at = _safe_str(item.get("published_at"))
    channel_name = _safe_str(item.get("channel_name"))

    description = full_body
    if published_at:
        description = f"📅 {published_at}\n\n{description}"
    if channel_name:
        description += f"\n\n📢 מקור: {channel_name}"

    meta_data["description"] = description
    return jsonify({"meta": meta_data})


@app.route("/stream/<type>/<id>.json", methods=["GET", "OPTIONS"])
@app.route("/updates/stream/<type>/<id>.json", methods=["GET", "OPTIONS"])
@app.route("/updates/<email>/stream/<type>/<id>.json", methods=["GET", "OPTIONS"])
def stream(type, id, email=None):
    """מחזיר מקור פעולה; ההפעלה עצמה תתרחש רק אחרי לחיצה על המקור."""
    authorized, message, email = _check_authorization(email)
    if not authorized:
        return _error_catalog_response(message)

    if type != "📢 עדכונים":
        return jsonify({"streams": []})

    if id not in ("update_system_full", "update_system_soft"):
        return jsonify({"streams": []})

    # עדכון מערכת זמין רק כשיש גרסה חדשה למשתמש הנוכחי
    if id == "update_system_soft" and not _is_user_update_available(email, _load_version_info()):
        return jsonify({"streams": []})

    mode = "reinstall" if id == "update_system_full" else "update"
    token = _issue_action_token(email=email, mode=mode)
    action_url = f"https://www.stremio.site/updates/action/{token}"

    title = "🚀 הפעל עדכון מערכת" if mode == "update" else "🧹 הפעל התקנה מחדש מלאה"
    info = "הפעולה תתבצע רק אחרי לחיצה על המקור הזה."

    return jsonify({
        "streams": [{
            "title": title,
            "info": info,
            "externalUrl": action_url
        }]
    })


@app.route("/action/<token>", methods=["GET"])
@app.route("/updates/action/<token>", methods=["GET"])
def run_action(token):
    """Run update/reinstall action after explicit stream-source click."""
    meta = _consume_action_token(token)
    if not meta:
        return _render_action_result_page(mode="update", ok=False, expired=True)

    email = meta["email"]
    mode = meta["mode"]
    api_path = "/api/account/reinstall" if mode == "reinstall" else "/api/account/update-addons"
    api_url = f"https://www.stremio.site{api_path}"

    try:
        resp = requests.post(api_url, json={"email": email}, timeout=30)
        data = resp.json() if resp.ok else {}
        ok = resp.ok and bool(data.get("ok"))
        print(f"[updates-action] mode={mode} email={email} ok={ok}")
    except Exception as exc:
        print(f"[updates-action] failed calling {api_url}: {exc}")

    return _render_action_result_page(mode=mode, ok=ok)


if __name__ == "__main__":
    port = int(os.getenv("PORT", "7014"))
    print(f"📢 Updates Addon running on port {port}")
    print("📱 Add to Stremio: https://www.stremio.site/updates/manifest.json")
    app.run(host="0.0.0.0", port=port, debug=False)
