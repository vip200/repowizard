
import xbmcaddon

Addon = xbmcaddon.Addon()
params_pre=""

def routing(argv1,argv2):
    from resources.default import refresh_list
    
    refresh_list(argv1,argv2,Addon_id=Addon)
    