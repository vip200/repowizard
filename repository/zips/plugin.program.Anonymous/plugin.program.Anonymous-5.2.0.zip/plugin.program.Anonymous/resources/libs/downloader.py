
import xbmc, xbmcgui, urllib, sys, time, uservar



from urllib.request import urlopen
from urllib.request import Request

ADDONTITLE     = uservar.ADDONTITLE
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2

try:
    urllib.URLopener.version = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'
except:pass
def download(url, dest, dp = None):
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create(ADDONTITLE ,"Downloading Content",' ', ' ')
    dp.update(0)
    start_time=time.time()

    urllib.request.urlretrieve(url,dest,lambda nb, bs, fs: _pbhook(nb,bs,fs,dp, start_time))
def download_update(url, dest, dp = None):
     dp = xbmcgui.DialogProgressBG()
     dp.create('[B][COLOR=green]   מוריד עדכון מערכת                                     [/COLOR][/B]', '[B][COLOR=silver]אנא המתן....                                         [/COLOR][/B]')
     urllib.request.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhookBG(nb,bs,fs,url,dp))
     dp.close()
def download_WizardBG(url, dest, dp = None):
     dp = xbmcgui.DialogProgressBG()
     dp.create('[B][COLOR=green]   Download Wizard Update                                      [/COLOR][/B]', '[B][COLOR=yellow]אנא המתן....                                         [/COLOR][/B]')
     urllib.request.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhookBG(nb,bs,fs,url,dp))
     dp.close()
def _pbhook(numblocks, blocksize, filesize, dp, start_time):
    # try: 
    percent = min(numblocks * blocksize * 100 / filesize, 100) 
    currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
    kbps_speed = numblocks * blocksize / (time.time() - start_time) 
    if kbps_speed > 0 and not percent == 100: 
        eta = (filesize - numblocks * blocksize) / kbps_speed 
    else: 
        eta = 0
    kbps_speed = kbps_speed / 1024 
    type_speed = 'KB'
    if kbps_speed >= 1024:
        kbps_speed = kbps_speed / 1024 
        type_speed = 'MB'
    total = float(filesize) / (1024 * 1024) 
    mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % (COLOR2, COLOR1, currently_downloaded, COLOR1, total) 
    e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % (COLOR2, COLOR1, kbps_speed, type_speed)
    e  += '[B]ETA:[/B] [COLOR '+COLOR1+']%02d:%02d[/COLOR][/COLOR]' % divmod(eta, 60)

    dp.update(int(percent), mbs+'\n'+e)

    if dp.iscanceled(): 
        dp.close()
        from resources.libs import wizard as wiz
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Download Cancelled[/COLOR]" % COLOR2)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        sys.exit()
        
        
        
def _pbhookBG(numblocks, blocksize, filesize, url=None,dp=None):
     percent = min((numblocks*blocksize*100)/filesize, 100)
     dp.update(int(percent))