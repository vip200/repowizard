# -*- coding: utf-8 -*-
import subprocess
import xbmc ,os


def callprocess(process, args=False):
    if args:
        subprocess.call([process, args], creationflags=0x08000000)
    else:
        subprocess.call([process], creationflags=0x08000000)



try:
    exe = os.path.normcase(r'C:\AnonymousTV\AnonymousTV.lnk')
    subprocess.Popen(exe, shell=True)
except:
    pass

xbmc.sleep(45)
os._exit(1)
