import os
import uuid
import platform
import subprocess
import re
import hashlib
import urllib.request
import json


def is_android():
    return (
        "ANDROID_ARGUMENT" in os.environ or
        "ANDROID_STORAGE" in os.environ or
        "android" in platform.platform().lower()
    )

def getprop(prop_name):
    try:
        return subprocess.check_output(['getprop', prop_name]).decode().strip()
    except:
        return ""

def get_android_device_id():
    for key in ['ro.serialno', 'ril.serialnumber', 'ro.boot.serialno']:
        serial = getprop(key)
        if serial and serial != "unknown":
            return serial

    try:
        props = subprocess.check_output(['getprop']).decode()
        macs = re.findall(r'\[([0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5})\]', props)
        macs = list(dict.fromkeys(macs))
        macs = [m for m in macs if m != "00:00:00:00:00:00"]
        if macs:
            return macs[0]
    except:
        pass

    digest = getprop("ro.boot.vbmeta.digest")
    if digest:
        m = hashlib.md5()
        m.update(digest.encode())
        return 'R' + str(int(m.hexdigest(), 16))[:12]

    return "unknown-android"

def get_android_device_model():
    model = getprop("ro.product.model")
    brand = getprop("ro.product.brand")

    return f"{brand} {model}".strip()

def get_mac_address():
    mac = uuid.getnode()
    if (mac >> 40) % 2 == 0:
        return ':'.join(('%012X' % mac)[i:i + 2] for i in range(0, 12, 2)).lower()
    return None

def get_mac_address_windows_wmic():
    try:
        output = subprocess.check_output("wmic nic where (MACAddress is not null and NetEnabled=true) get MACAddress", shell=True).decode(errors="ignore")
        macs = re.findall(r'([0-9A-Fa-f]{2}(?::?[0-9A-Fa-f]{2}){5})', output)
        for mac in macs:
            mac = mac.replace("-", ":").lower()
            if mac != "00:00:00:00:00:00":
                return mac
    except:
        pass
    return None

def get_mac_address_windows_getmac():
    try:
        output = subprocess.check_output("getmac", shell=True).decode()
        macs = re.findall(r'([0-9A-Fa-f]{2}(?:[-:][0-9A-Fa-f]{2}){5})', output)
        for mac in macs:
            if mac != "00-00-00-00-00-00":
                return mac.replace("-", ":").lower()
    except:
        pass
    return None

def get_possible_paths():
    system = platform.system()
    paths = []

    if system == "Windows":
        base = os.getenv("LOCALAPPDATA") or os.getenv("APPDATA") or os.path.expanduser("~")
        paths.append(os.path.join(base, "kodi_device_id.txt"))

    elif is_android():
        # שים לב שהנתיב של media בא אחרון
        paths += [
            "/storage/emulated/0/kodi_device_id.txt",
            "/sdcard/kodi_device_id.txt",
            # נסיון אחרון
            "/storage/emulated/0/Android/media/org.xbmc.kodi/kodi_device_id.txt"
        ]

    elif system in ["Linux", "Darwin"]:
        paths += [
            os.path.expanduser("~/.kodi_device_id.txt"),
            os.path.expanduser("~/kodi_device_id.txt")
        ]

    else:
        paths.append(os.path.expanduser("~/kodi_device_id.txt"))

    return paths

def get_device_id():


    for path in get_possible_paths():
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    return f.read().strip()
            except:
                continue

    if is_android():
        identifier = get_android_device_id()
        model = get_android_device_model()
        device_id = f"{model} | {identifier}"
    elif platform.system() == "Windows":
        identifier = get_mac_address() or get_mac_address_windows_wmic() or get_mac_address_windows_getmac() or str(uuid.uuid4())
        system_info = platform.uname().node or "Windows"
        device_id = f"{system_info} | {identifier}"
    else:
        identifier = get_mac_address() or str(uuid.uuid4())
        system_info = platform.uname().node or platform.system()
        device_id = f"{system_info} | {identifier}"

    for path in get_possible_paths():
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as f:
                f.write(device_id)
            break  # יציאה ברגע שכתיבה הצליחה
        except:
            continue

    return device_id