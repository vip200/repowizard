import json,os,xbmcvfs,uservar,sys,time,base64,xbmc,re,logging,xbmcgui,shutil,subprocess,urllib
from urllib.request import urlopen
from resources.libs import wizard as wiz
from resources.libs import downloader
from resources.libs import notify
from shutil import copyfile

ADDON_ID         = uservar.ADDON_ID
ADDON            = wiz.addonId(ADDON_ID)
HOME             = xbmcvfs.translatePath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
PACKAGES         = os.path.join(ADDONS,    'packages')
ADDONPATH      = wiz.addonInfo(ADDON_ID,'path')
DP               = xbmcgui.DialogProgress()
# server_lib='https://digit.seedhost.eu/kodi/wizard/Tdlib/data.json'
# remove_url = base64.b64decode('aHR0cDovL2RpZ2l0LnNlZWRob3N0LmV1L2tvZGkvd2l6YXJkL3R4dC9yZW1vdmVfYWRkb25zLnhtbA==').decode('utf-8')


server_lib='https://kodivip.com/files/Tdlib/data.json'
remove_url = base64.b64decode('aHR0cDovL3YyMjAyNTA2MjgwNjE2MzUwNDMxLm1lZ2FzcnYuZGU6ODAwMC9rb2RpL3R4dC9yZW1vdmVfYWRkb25zLnhtbA==').decode('utf-8')
addons_folder=os.path.join(xbmcvfs.translatePath('special://home'),'addons')

def download_file(url, path):
    from urllib.request import Request, urlopen
    if not os.path.exists(path):
        os.makedirs(path)
    filename = url.split("/")[-1].split("?")[0]
    local_path = os.path.join(path, filename)

    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urlopen(req) as response, open(local_path, 'wb') as out_file:
            while True:
                chunk = response.read(8192)
                if not chunk:
                    break
                out_file.write(chunk)
        return local_path
    except Exception as e:
        logging.warning(f"Failed to download {url}: {e}")
        return None

def tdlib():

    import platform
    machine= (platform.machine())
    platform= (platform.architecture())
    if sys.platform.lower().startswith('linux'):
        plat = 'linux'
        if 'ANDROID_DATA' in os.environ:
            plat = 'android'
    elif sys.platform.lower().startswith('win'):
        plat = 'windows'
    elif sys.platform.lower().startswith('darwin'):
        plat = 'darwin'
    else:
        plat = None
    from zipfile import ZipFile
    cur=os.path.join(xbmcvfs.translatePath("special://home/"),"addons","plugin.video.telemedia")
    cur=os.path.join(cur,'resources','lib')
    x = json.load(urllib.request.urlopen(server_lib))
    user_dataDir = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    download_file(server_lib,user_dataDir)
    if plat == 'android':
            if platform[0]=='32bit':
                url=x['android32']
                cur=os.path.join(cur,"android/armeabi-v7a")
                download_file(url,cur)
            else:
                url=x['android64']
                cur=os.path.join(cur,"android/arm64-v8a")
                download_file(url,cur)
    elif plat == 'windows':
        if platform[0]=='64bit':
            cur=os.path.join(cur,'windows/x64')
            download_file(x['windows64'],cur)
            file_windows=os.path.join(cur,'windows64.zip')
            zf = ZipFile(file_windows)
            for file in zf.infolist():
                zf.extract(member=file, path=cur)
            zf.close()
            time.sleep(1)
            try:
                os.remove(file_windows)
            except:
                pass
        else:
            cur=os.path.join(cur,'windows/x32')
            download_file(x['windows32'],cur)
            file_windows=os.path.join(cur,'windows32.zip')
            zf = ZipFile(file_windows)
            for file in zf.infolist():
                zf.extract(member=file, path=cur)
            zf.close()
            time.sleep(1)
            try:
                os.remove(file_windows)
            except:
                pass
    elif plat == 'linux':
            if platform[0]=='32bit':
                url=x['linux32']
                cur=os.path.join(cur,"linux/x32")
                download_file(url,cur)
            else:
                url=x['linux64']
                cur=os.path.join(cur,"linux/x64")
                download_file(url,cur)
    elif plat == 'darwin':
                cur=os.path.join(cur,'mac/mac-os')
                download_file(x['mac'],cur)
                file_mac=os.path.join(cur,'libtdjson.zip')
                zf = ZipFile(file_mac)
                for file in zf.infolist():
                    zf.extract(member=file, path=cur)
                zf.close()
                time.sleep(1)
                try:
                    os.remove(file_mac)
                except:
                    pass
def remove_addons():
    try:
        r = urlopen(remove_url).readlines()
        for line in r:
            
            add_name =line.decode('utf-8').split(':')[1].strip()
            do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}' % (add_name, 'false')
            query = xbmc.executeJSONRPC(do_json)
            response = json.loads(query)
            
            url_folder=os.path.join(addons_folder,add_name)
            
            if os.path.exists(url_folder):
                for root, dirs, files in os.walk(url_folder):
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                os.rmdir(url_folder)
        xbmc.executebuiltin('Container.Refresh')
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
    except:  pass
def skin_homeselect():
    try:
        setting_file=os.path.join(xbmcvfs.translatePath("special://masterprofile/"),"addon_data", "skin.anonymoustv","settings.xml")
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        # try:
        regex='<setting id="firsttimerun" type="bool">(.+?)</setting>'
        m=re.compile(regex).findall(file_data)[0]
        file = open(setting_file, 'w', encoding='utf-8') 
        file.write(file_data.replace('<setting id="firsttimerun" type="bool">%s</setting>'%m,'<setting id="firsttimerun" type="bool">false</setting>'))
        file.close()
    except:pass
def skin_dragon_set():
    try:
        setting_file=os.path.join(xbmcvfs.translatePath("special://masterprofile/"),"addon_data", "skin.anonymoustv","settings.xml")
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
        # try:
        regex='<setting id="homemenunocustom4button" type="bool">(.+?)</setting>'
        m=re.compile(regex).findall(file_data)[0]
        file = open(setting_file, 'w', encoding='utf-8') 
        file.write(file_data.replace('<setting id="homemenunocustom4button" type="bool">%s</setting>'%m,'<setting id="homemenunocustom4button" type="bool">false</setting>'))
        file.close()
    except:pass
def help_install():
    import webbrowser
    if xbmc.getCondVisibility('system.platform.windows'):
        webbrowser.open('https://t.me/xbmc19')
    else:
        url='https://t.me/xbmc19'
        xbmc.executebuiltin("StartAndroidActivity(com.android.browser,android.intent.action.VIEW,,"+url+")")
        xbmc.executebuiltin("StartAndroidActivity(com.android.chrome,,,"+url+")") 
        xbmc.executebuiltin("StartAndroidActivity(org.mozilla.firefox,android.intent.action.VIEW,,"+url+")")    
        xbmc.executebuiltin("StartAndroidActivity(org.sec.android.app.sbrowser,android.intent.action.VIEW,,"+url+")")    


def dialog_install_apk():
    import platform
    machine= (platform.machine())
    platform= (platform.architecture())
    if sys.platform.lower().startswith('linux'):
        plat = 'linux'
        if 'ANDROID_DATA' in os.environ:
            plat = 'android'
    elif sys.platform.lower().startswith('win'):
        plat = 'windows'
    elif sys.platform.lower().startswith('darwin'):
        plat = 'darwin'
    else:
        plat = None
    KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    r = urlopen('https://kodivip.com/files/txt/kodi_version.xml').read()

    if str(KODIV) == r.decode('utf-8'): 
        xbmcgui.Dialog().ok('Anonymous TV', 'גרסת הקודי שלך כבר מעודכנת: '+str(KODIV))
        return
    choice = xbmcgui.Dialog().yesno('Anonymous TV', "האם לבצע עדכון אפליקציה?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        if plat == 'android':
            downloader_image = os.path.join(ADDONPATH,   'resources', 'skins/DefaultSkin/media/Background/downloader.png')
            notify.kodi_version_update(downloader_image)
        if plat == 'windows':
            downloader_image = os.path.join(ADDONPATH,   'resources', 'skins/DefaultSkin/media/Background/windows.png')
            notify.kodi_version_update(downloader_image)
def install_apk():
    import platform
    machine= (platform.machine())
    platform= (platform.architecture())
    if sys.platform.lower().startswith('linux'):
        plat = 'linux'
        if 'ANDROID_DATA' in os.environ:
            plat = 'android'
    elif sys.platform.lower().startswith('win'):
        plat = 'windows'
    elif sys.platform.lower().startswith('darwin'):
        plat = 'darwin'
    else:
        plat = None
    if plat == 'android':
            if platform[0]=='32bit':
                zipname =  "AnonymousTV-32Bit.apk"
                link= 'https://kodivip.com/files/apk/AnonymousTV-32Bit.apk'
                apk='/sdcard/Download/Downloader/%s'%zipname
            else:
                zipname =  "AnonymousTV-64Bit.apk"
                link= 'https://kodivip.com/files/apk/AnonymousTV-64Bit.apk'
                apk='/Storage/emulated/0/download/Downloader/%s'%zipname
    elif plat == 'windows':
            zipname =  "windows.exe"
            link= 'https://kodivip.com/files/apk/wizard.exe'
            apk='c:/AnonymousTV/%s'%zipname
    else:
        xbmcgui.Dialog().ok('Anonymous TV', 'כרגע תומך רק למערכת ההפעלה אנדרואיד וינדוס')
        return

    if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
    DP.create('Anonymous TV','[B]Downloading[/B]'+'\n'+ 'Please Wait')
    lib=os.path.join(PACKAGES,zipname)

    downloader.download(link, lib, DP)
    title='מפעיל קובץ: '+ zipname
    DP.update(0, title+'\n'+''+'\n'+ 'אנא המתן...')
    if DP.iscanceled():
     DP.close()
    try:
        # shutil.move(lib,apk)
        shutil.copyfile(lib, apk)

        
    except Exception as e:
        logging.warning('File copy err:'+str(e))
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'),'[COLOR %s]תקלה[/COLOR]' % 'white',500)
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'),str(e),500)
        DP.close()
        try: os.remove(lib)
        except: pass
        pass
    if plat == 'android':
        xbmc.executebuiltin('StartAndroidActivity({},,,"content://{}")'.format('com.esaba.downloader', apk))
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'),'[COLOR %s]מפעיל את Downloader[/COLOR]' % 'white',2500)
    else:
        exe = os.path.normcase(apk)
        subprocess.Popen(exe, shell=True)
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'),'[COLOR %s]מפעיל את הקובץ...[/COLOR]' % 'white',1500)
def backup_setting_file():
    try:
        setting_file=os.path.join(xbmcvfs.translatePath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")
        setting_file2=os.path.join(xbmcvfs.translatePath("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

        if len(file_data) >0:
            copyfile(setting_file,setting_file2)
    except:pass