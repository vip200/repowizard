# coding: utf-8

import xbmc,xbmcgui,xbmcplugin,os,sys,xbmcvfs,urllib,uservar
# socket.setdefaulttimeout(10)
from urllib.request import urlopen
from urllib.parse import parse_qsl
from resources.libs.main import totalClean,backtokodi
que=urllib.parse.quote_plus
unque=urllib.parse.unquote_plus
translatepath=xbmcvfs.translatePath
from resources.libs import notify
from resources.libs.send_log import logsend as log_send

from resources.libs import wizard as wiz
from resources.libs.utils import help_install,install_apk,dialog_install_apk
from resources.libs.send import send_user_info,logsend,user_info,get_version_update
from resources.libs.setup import buildWizard,startup,auto_build_update,force_update,freshStart,infobuild,infoupdate_busydialog,open_skin

from resources.libs.details_realdebrid import RealDebrid
ADDON_ID         = uservar.ADDON_ID
ADDONTITLE       = uservar.ADDONTITLE
ADDON            = wiz.addonId(ADDON_ID)
ADDONPATH        = wiz.addonInfo(ADDON_ID,'path')
DIALOG           = xbmcgui.Dialog()
FANART           = os.path.join(ADDONPATH, 'fanart.jpg')
ICON             = os.path.join(ADDONPATH, 'icon.png')
BUILDNAME        = wiz.getS('buildname')
NOTEID           = wiz.getS('noteid')
try:
    NOTEID = int(NOTEID)
except (ValueError, TypeError):
    NOTEID = 0

KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
COLOR1           = uservar.COLOR1
COLOR2           = uservar.COLOR2
THEME1           = uservar.THEME1
ICONBUILDS       = uservar.ICONBUILDS if not uservar.ICONBUILDS == 'http://' else ICON
fanart         = translatepath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
icon           = translatepath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))

def addItem(name, url, mode, iconimage, fanart, description=None):
    if description == None: description = ''
    description = '[COLOR white]' + description + '[/COLOR]'
    u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+que(name)+"&iconimage="+que(iconimage)+"&fanart="+que(fanart)
    ok=True
    try:
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    except:
        liz=xbmcgui.ListItem(name)
        liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'DefaultFolder.png': iconimage})
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "fanart_Image", fanart )
    liz.setProperty( "icon_Image", iconimage )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def buildMenu():
    if KODIV >= 20: # קודי 20
        if BUILDNAME == "":
            addFile('התקנה'   , 'install', " Kodi Premium", 'fresh'  , description='', fanart=FANART, icon=ICONBUILDS, themeit=THEME1)
            
        else:
            addFile('התקנה מחדש'   , 'install', " Kodi Premium", 'fresh'  , description='', fanart=FANART, icon=ICONBUILDS, themeit=THEME1)
        addFile('הגדרות'   , 'passandUsername', " Kodi Premium", 'passandUsername'  ,  themeit=THEME1)
        addFile('לעזרה בטלגרם לחצו כאן', 'help_install', icon=ICONBUILDS, themeit=THEME1)
    else:
        DIALOG.ok(ADDONTITLE, 'ההתקנה זמינה מקודי 20 ומעלה' +'\n'+' גרסת הקודי שלך היא: '+str(KODIV))
        sys.exit()

def addDir(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
    u = sys.argv[0]
    if not mode == None: u += "?mode=%s" % que(mode)
    if not name == None: u += "&name="+que(name)
    if not url == None: u += "&url="+que(url)
    ok=True
    if themeit: display = themeit % display
    try:
      liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    except:
      liz=xbmcgui.ListItem(display)
      liz.setArt({'thumb' : icon, 'fanart': icon, 'DefaultFolder.png': icon})
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addFile(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
    u = sys.argv[0]
    try:
        if not mode == None: u += "?mode=%s" % que(mode)
        if not name == None: u += "&name="+que(name)
        if not url == None: u += "&url="+que(url)
    except:#kodi19
        if not mode == None: u += "?mode=%s" % que(mode)
        if not name == None: u += "&name="+que(name)
        if not url == None: u += "&url="+que(url)
    ok=True
    if themeit: display = themeit % display
    try:
        liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
    except:
        liz=xbmcgui.ListItem(display)
        liz.setArt({'thumb' : icon, 'fanart': icon, 'DefaultFolder.png': icon})
    liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
    liz.setProperty( "Fanart_Image", fanart )
    if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def get_params(user_params=''):
        param = dict(parse_qsl(user_params.replace('?','')))
        return param   

def refresh_list(user_params,sys_arg_1_data,Addon_id=""):
    global name
    params=get_params(user_params=user_params)
    url=None
    name=None
    mode=None
    try:     mode=unque(params["mode"])
    except:  pass
    try:     name=unque(params["name"])
    except:  pass
    try:     url=unque(params["url"])
    except:  pass
    if   mode==None             : buildMenu()#index()
    elif mode=='user_info'      : user_info()
    # elif mode=='STARTP'         : STARTP()
    elif mode=='install'        : buildWizard(name, url)
    elif mode=='kodi17fix'      : wiz.kodi17Fix()
    elif mode=='clearbackup'    : wiz.cleanupBackup()
    elif mode=='fullclean'      : totalClean(); wiz.refresh()
    elif mode=='logsend'        : logsend()
    elif mode=='clearpackages'  : wiz.clearPackages(); wiz.refresh()
    elif mode=='freshstart'     : freshStart()
    elif mode=='testapk'        : notify.apkInstaller('SPMC')
    elif mode=='help_install'        : help_install()
    elif mode=='infoupdate'        : infobuild(False)
    elif mode=='infoupdate_busydialog'        : infoupdate_busydialog(False)
    elif mode=='wait'        : wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]אנא המתן[/COLOR]" % COLOR2,1500)

    elif mode=='force_update'   :force_update()
    elif mode=='update_tele'   :auto_build_update(NOTEID)
    elif mode=='passandUsername'       : ADDON.openSettings()
    elif mode=='80'        : send_user_info('channel_new_install','שלח קוד')
    elif mode=='fixskin'        : backtokodi()
    elif mode=='check_id'        : check_id('true')
    elif mode=='set_points'        : RealDebrid().set_points()
    elif mode=='startup'        : startup()
    elif mode=='dialog_install_apk'        : dialog_install_apk()
    elif mode=='install_apk'        : install_apk()
    elif mode=='open_skin'        : open_skin()
    elif mode=='send_log'        : log_send()
    
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))