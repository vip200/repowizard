# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
global teleupdate #line:32
teleupdate =False #line:33
ADDON_ID =uservar .ADDON_ID #line:34
ADDONTITLE =uservar .ADDONTITLE #line:35
ADDON =wiz .addonId (ADDON_ID )#line:36
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:37
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:38
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:39
DIALOG =xbmcgui .Dialog ()#line:40
DP =xbmcgui .DialogProgress ()#line:41
DP2 =xbmcgui .DialogProgressBG ()#line:42
HOME =xbmc .translatePath ('special://home/')#line:43
PROFILE =xbmc .translatePath ('special://profile/')#line:44
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:45
ADDONS =os .path .join (HOME ,'addons')#line:46
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:47
USERDATA =os .path .join (HOME ,'userdata')#line:48
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:49
PACKAGES =os .path .join (ADDONS ,'packages')#line:50
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:51
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:52
ICON =os .path .join (ADDONPATH ,'icon.png')#line:53
ART =os .path .join (ADDONPATH ,'resources','art')#line:54
SKIN =xbmc .getSkinDir ()#line:55
BUILDNAME =wiz .getS ('buildname')#line:56
DEFAULTSKIN =wiz .getS ('defaultskin')#line:57
DEFAULTNAME =wiz .getS ('defaultskinname')#line:58
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:59
BUILDVERSION =wiz .getS ('buildversion')#line:60
BUILDLATEST =wiz .getS ('latestversion')#line:61
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:62
DISABLEUPDATE =wiz .getS ('disableupdate')#line:63
AUTOCLEANUP =wiz .getS ('autoclean')#line:64
AUTOCACHE =wiz .getS ('clearcache')#line:65
AUTOPACKAGES =wiz .getS ('clearpackages')#line:66
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:67
AUTOFEQ =wiz .getS ('autocleanfeq')#line:68
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:69
TRAKTSAVE =wiz .getS ('traktlastsave')#line:70
REALSAVE =wiz .getS ('debridlastsave')#line:71
LOGINSAVE =wiz .getS ('loginlastsave')#line:72
INSTALLMETHOD =wiz .getS ('installmethod')#line:73
KEEPTRAKT =wiz .getS ('keeptrakt')#line:74
KEEPREAL =wiz .getS ('keepdebrid')#line:75
KEEPLOGIN =wiz .getS ('keeplogin')#line:76
INSTALLED =wiz .getS ('installed')#line:77
EXTRACT =wiz .getS ('extract')#line:78
EXTERROR =wiz .getS ('errors')#line:79
NOTIFY =wiz .getS ('notify')#line:80
NOTEDISMISS =wiz .getS ('notedismiss')#line:81
NOTEID =wiz .getS ('noteid')#line:82
NOTIFY2 =wiz .getS ('notify2')#line:83
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:84
NOTEID2 =wiz .getS ('noteid2')#line:85
NOTIFY3 =wiz .getS ('notify3')#line:86
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:87
NOTEID3 =wiz .getS ('noteid3')#line:88
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:89
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:90
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:91
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:92
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:93
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:94
TODAY =date .today ()#line:95
TOMORROW =TODAY +timedelta (days =1 )#line:96
TWODAYS =TODAY +timedelta (days =2 )#line:97
THREEDAYS =TODAY +timedelta (days =3 )#line:98
ONEWEEK =TODAY +timedelta (days =7 )#line:99
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:100
EXCLUDES =uservar .EXCLUDES #line:101
SPEEDFILE =speedtest .SPEEDFILE #line:102
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:103
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:104
NOTIFICATION =uservar .NOTIFICATION #line:105
NOTIFICATION2 =uservar .NOTIFICATION2 #line:106
NOTIFICATION3 =uservar .NOTIFICATION3 #line:107
ENABLE =uservar .ENABLE #line:108
UNAME =speedtest .UNAME #line:109
HEADERMESSAGE =uservar .HEADERMESSAGE #line:110
AUTOUPDATE =uservar .AUTOUPDATE #line:111
WIZARDFILE =uservar .WIZARDFILE #line:112
AUTOINSTALL =uservar .AUTOINSTALL #line:113
REPOID =uservar .REPOID #line:114
REPOADDONXML =uservar .REPOADDONXML #line:115
REPOZIPURL =uservar .REPOZIPURL #line:116
REPOID18 =uservar .REPOID18 #line:117
REPOADDONXML18 =uservar .REPOADDONXML18 #line:118
REPOZIPURL18 =uservar .REPOZIPURL18 #line:119
REQUESTSID =uservar .REQUESTSID #line:121
REQUESTSXML =uservar .REQUESTSXML #line:122
REQUESTSURL =uservar .REQUESTSURL #line:123
COLOR1 =uservar .COLOR1 #line:127
COLOR2 =uservar .COLOR2 #line:128
TMDB_NEW_API =uservar .TMDB_NEW_API #line:129
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:130
FAILED =False #line:131
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:132
AddonID ='plugin.program.Anonymous'#line:134
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:135
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:136
dialog =xbmcgui .Dialog ()#line:137
setting =xbmcaddon .Addon ().getSetting #line:138
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:139
notify_mode =setting ('notify_mode')#line:140
auto_clean =setting ('startup.cache')#line:141
filesize_thumb =int (setting ('filesizethumb_alert'))#line:143
total_size2 =0 #line:146
total_size =0 #line:147
count =0 #line:148
def infobuild ():#line:159
	OO00OO00000O0OOOO =wiz .workingURL (NOTIFICATION )#line:160
	if OO00OO00000O0OOOO ==True :#line:161
		try :#line:162
			OOOOO0OOOOOO0OO0O ,O0O0O0OO0O00000O0 =wiz .splitNotify (NOTIFICATION )#line:163
			if OOOOO0OOOOOO0OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:164
			if STARTP2 ()=='ok':#line:165
				notify .updateinfo (O0O0O0OO0O00000O0 ,True )#line:166
		except Exception as OO00O0O00O0O00OO0 :#line:167
			wiz .log ("Error on Notifications Window: %s"%str (OO00O0O00O0O00OO0 ),xbmc .LOGERROR )#line:168
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:169
def disply_hwr ():#line:170
   try :#line:171
    OOO0O0O00O000OOOO =tmdb_list (TMDB_NEW_API )#line:172
    O0O0O00OO00O000OO =str ((getHwAddr ('eth0'))*OOO0O0O00O000OOOO )#line:173
    OO00OO0O00O00OO0O =(O0O0O00OO00O000OO [1 ]+O0O0O00OO00O000OO [2 ]+O0O0O00OO00O000OO [5 ]+O0O0O00OO00O000OO [7 ])#line:180
    OO0OO00OOOOOOOOOO =(ADDON .getSetting ("action"))#line:181
    wiz .setS ('action',str (OO00OO0O00O00OO0O ))#line:183
   except :pass #line:184
def getHwAddr (O000000O0O000O0OO ):#line:185
   import subprocess ,time #line:186
   OO0000OOOO0O000OO ='windows'#line:187
   if xbmc .getCondVisibility ('system.platform.android'):#line:188
       OO0000OOOO0O000OO ='android'#line:189
   if xbmc .getCondVisibility ('system.platform.android'):#line:190
     OO0OO000O000OO0OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:191
     O0OOO00000OOOOOOO =re .compile ('link/ether (.+?) brd').findall (str (OO0OO000O000OO0OO ))#line:193
     OO0OOOOO0OOO000OO =0 #line:194
     for O00OO0O0O0000O000 in O0OOO00000OOOOOOO :#line:195
      if O0OOO00000OOOOOOO !='00:00:00:00:00:00':#line:196
          OO0OO0OOO00000000 =O00OO0O0O0000O000 #line:197
          OO0OOOOO0OOO000OO =OO0OOOOO0OOO000OO +int (OO0OO0OOO00000000 .replace (':',''),16 )#line:198
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:200
       O00OO0O0OO0O0OOO0 =0 #line:201
       OO0OOOOO0OOO000OO =0 #line:202
       OO0OOO0OOOOO0O00O =[]#line:203
       O00OOOOOOO00O0O0O =os .popen ("getmac").read ()#line:204
       O00OOOOOOO00O0O0O =O00OOOOOOO00O0O0O .split ("\n")#line:205
       for O00O0OOO00O00OOO0 in O00OOOOOOO00O0O0O :#line:207
            OOOOOO0O00OOO000O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00O0OOO00O00OOO0 ,re .I )#line:208
            if OOOOOO0O00OOO000O :#line:209
                O0OOO00000OOOOOOO =OOOOOO0O00OOO000O .group ().replace ('-',':')#line:210
                OO0OOO0OOOOO0O00O .append (O0OOO00000OOOOOOO )#line:211
                OO0OOOOO0OOO000OO =OO0OOOOO0OOO000OO +int (O0OOO00000OOOOOOO .replace (':',''),16 )#line:214
   else :#line:216
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:217
   try :#line:234
    return OO0OOOOO0OOO000OO #line:235
   except :pass #line:236
def decode (OOO0OOOO0000OO0O0 ,OO000O0O0O0O0000O ):#line:237
    import base64 #line:238
    O00000000OO0000OO =[]#line:239
    if (len (OOO0OOOO0000OO0O0 ))!=4 :#line:241
     return 10 #line:242
    OO000O0O0O0O0000O =base64 .urlsafe_b64decode (OO000O0O0O0O0000O )#line:243
    for O0000000000O000OO in range (len (OO000O0O0O0O0000O )):#line:245
        O0O0O0O0OO0OOOOOO =OOO0OOOO0000OO0O0 [O0000000000O000OO %len (OOO0OOOO0000OO0O0 )]#line:246
        O0OOOO00OO0OOO00O =chr ((256 +ord (OO000O0O0O0O0000O [O0000000000O000OO ])-ord (O0O0O0O0OO0OOOOOO ))%256 )#line:247
        O00000000OO0000OO .append (O0OOOO00OO0OOO00O )#line:248
    return "".join (O00000000OO0000OO )#line:249
def tmdb_list (OO0OO00000OOO00O0 ):#line:250
    O00OOO00OO0O00OOO =decode ("7643",OO0OO00000OOO00O0 )#line:253
    return int (O00OOO00OO0O00OOO )#line:256
def u_list (O0OOOOOOO0OOO0OOO ):#line:257
    from math import sqrt #line:259
    OO00O0O0000OO0O00 =tmdb_list (TMDB_NEW_API )#line:260
    O0OOOOOOOO0O0O000 =str ((getHwAddr ('eth0'))*OO00O0O0000OO0O00 )#line:262
    OOOO0O00000O0O000 =int (O0OOOOOOOO0O0O000 [1 ]+O0OOOOOOOO0O0O000 [2 ]+O0OOOOOOOO0O0O000 [5 ]+O0OOOOOOOO0O0O000 [7 ])#line:263
    OOO00OOO0OO000OO0 =(ADDON .getSetting ("pass"))#line:265
    OOOOO00O0O0O0O0OO =(str (round (sqrt ((OOOO0O00000O0O000 *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:270
    if '.'in OOOOO00O0O0O0O0OO :#line:271
     OOOOO00O0O0O0O0OO =(str (round (sqrt ((OOOO0O00000O0O000 *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:272
    if OOO00OOO0OO000OO0 ==OOOOO00O0O0O0O0OO :#line:273
      OOOOOOOO0OOO0O00O =O0OOOOOOO0OOO0OOO #line:275
    else :#line:277
       if STARTP ()and STARTP2 ()=='ok':#line:278
         return O0OOOOOOO0OOO0OOO #line:280
       OOOOOOOO0OOO0O00O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:281
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:282
       sys .exit ()#line:283
    return OOOOOOOO0OOO0O00O #line:284
try :#line:285
   disply_hwr ()#line:286
except :#line:287
   pass #line:288
def dis_or_enable_addon (O0OOO0O0O00OO0O0O ,OO0OO00000OO0OO0O ,enable ="true"):#line:289
    import json #line:290
    OO0OO00OOO00OO000 ='"%s"'%O0OOO0O0O00OO0O0O #line:291
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOO0O0O00OO0O0O )and enable =="true":#line:292
        logging .warning ('already Enabled')#line:293
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OOO0O0O00OO0O0O )#line:294
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOO0O0O00OO0O0O )and enable =="false":#line:295
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OOO0O0O00OO0O0O )#line:296
    else :#line:297
        OOOO00O0O00O0O00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0OO00OOO00OO000 ,enable )#line:298
        O0OO0O00OO0O0000O =xbmc .executeJSONRPC (OOOO00O0O00O0O00O )#line:299
        O00OO00OOOOOOO000 =json .loads (O0OO0O00OO0O0000O )#line:300
        if enable =="true":#line:301
            xbmc .log ("### Enabled %s, response = %s"%(O0OOO0O0O00OO0O0O ,O00OO00OOOOOOO000 ))#line:302
        else :#line:303
            xbmc .log ("### Disabled %s, response = %s"%(O0OOO0O0O00OO0O0O ,O00OO00OOOOOOO000 ))#line:304
    if OO0OO00000OO0OO0O =='auto':#line:305
     return True #line:306
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:307
def update_Votes ():#line:308
   try :#line:309
        import requests #line:310
        OOOOO0OOOO000O00O ='18773068'#line:311
        O0OO00O0O0000OOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOOO0OOOO000O00O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:323
        O00O0OO0OO0O0000O ='145273321'#line:325
        O00O00OOO0OO0000O ={'options':O00O0OO0OO0O0000O }#line:331
        O0OOO0O0OO000OO0O =requests .post ('https://www.strawpoll.me/'+OOOOO0OOOO000O00O ,headers =O0OO00O0O0000OOOO ,data =O00O00OOO0OO0000O )#line:333
   except :pass #line:334
def display_Votes ():#line:335
    try :#line:336
        OOO0000OOO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:337
        O0OO00OOOOOOO0O0O =open (OOO0000OOO0O000O0 ,'r')#line:339
        OO000O00O00OOO000 =O0OO00OOOOOOO0O0O .read ()#line:340
        O0OO00OOOOOOO0O0O .close ()#line:341
        O0O0O0OO000O0000O ='<setting id="HomeS" type="string">(.+?)</setting>'#line:342
        OO00OO00OO0OO00OO =re .compile (O0O0O0OO000O0000O ).findall (OO000O00O00OOO000 )[0 ]#line:344
        import requests #line:350
        OOO00O000000OOOOO ='18782966'#line:351
        O0O000O0OOOOO00O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO00O000000OOOOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:363
        OOOOO0OO0OOOOOOOO ='145313053'#line:365
        OOO0O00O0OOOOOO0O ='145313054'#line:366
        O00OOO0OO0O0OO00O ='145313057'#line:367
        O000OO0O00OOO000O ='145313058'#line:368
        O0O000OOOO00OO000 ='145313055'#line:369
        O0OOO0O0OOOO0000O ='145313060'#line:370
        OOO0OO00000O000O0 ='145313056'#line:371
        OOO0O00OO0O000OOO ='145313059'#line:372
        if OO00OO00OO0OO00OO =='emin':#line:375
           OO00OOOO0OOOOO0OO =OOOOO0OO0OOOOOOOO #line:376
        if OO00OO00OO0OO00OO =='nox':#line:377
           OO00OOOO0OOOOO0OO =OOO0O00O0OOOOOO0O #line:378
        if OO00OO00OO0OO00OO =='noxtitan':#line:379
           OO00OOOO0OOOOO0OO =OOO0O00O0OOOOOO0O #line:380
        if OO00OO00OO0OO00OO =='titan':#line:381
           OO00OOOO0OOOOO0OO =O00OOO0OO0O0OO00O #line:382
        if OO00OO00OO0OO00OO =='pheno':#line:383
           OO00OOOO0OOOOO0OO =O000OO0O00OOO000O #line:384
        if OO00OO00OO0OO00OO =='netflix':#line:385
           OO00OOOO0OOOOO0OO =O0O000OOOO00OO000 #line:386
        if OO00OO00OO0OO00OO =='nebula':#line:387
           OO00OOOO0OOOOO0OO =O0OOO0O0OOOO0000O #line:388
        if OO00OO00OO0OO00OO =='pellucid':#line:389
           OO00OOOO0OOOOO0OO =OOO0OO00000O000O0 #line:390
        if OO00OO00OO0OO00OO =='pellucid2':#line:391
           OO00OOOO0OOOOO0OO =OOO0O00OO0O000OOO #line:392
        O000O0000OO0O00OO ={'options':OO00OOOO0OOOOO0OO }#line:398
        O0O000000OO00O00O =requests .post ('https://www.strawpoll.me/'+OOO00O000000OOOOO ,headers =O0O000O0OOOOO00O0 ,data =O000O0000OO0O00OO )#line:400
    except :pass #line:401
def resetkodi ():#line:402
		if xbmc .getCondVisibility ('system.platform.windows'):#line:403
			OOOO0O0O0OO000O0O =xbmcgui .DialogProgress ()#line:404
			OOOO0O0O0OO000O0O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:407
			OOOO0O0O0OO000O0O .update (0 )#line:408
			for OOOO0OO000O000000 in range (5 ,-1 ,-1 ):#line:409
				time .sleep (1 )#line:410
				OOOO0O0O0OO000O0O .update (int ((5 -OOOO0OO000O000000 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OOOO0OO000O000000 ),'')#line:411
				if OOOO0O0O0OO000O0O .iscanceled ():#line:412
					from resources .libs import win #line:413
					return None ,None #line:414
			from resources .libs import win #line:415
		else :#line:416
			OOOO0O0O0OO000O0O =xbmcgui .DialogProgress ()#line:417
			OOOO0O0O0OO000O0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:420
			OOOO0O0O0OO000O0O .update (0 )#line:421
			for OOOO0OO000O000000 in range (5 ,-1 ,-1 ):#line:422
				time .sleep (1 )#line:423
				OOOO0O0O0OO000O0O .update (int ((5 -OOOO0OO000O000000 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOOO0OO000O000000 ),'')#line:424
				if OOOO0O0O0OO000O0O .iscanceled ():#line:425
					os ._exit (1 )#line:426
					return None ,None #line:427
			os ._exit (1 )#line:428
def indicatorfastupdate ():#line:429
       try :#line:430
          import json #line:431
          wiz .log ('FRESH MESSAGE')#line:432
          OOOO000O0O0OO0000 =(ADDON .getSetting ("user"))#line:433
          O0OO000OO0O0000OO =(ADDON .getSetting ("pass"))#line:434
          OO0O00O0OOOO00O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:435
          OOO0OO00O0O000OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:437
          OO0OO0000OO00O0OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:438
          OOO0O0O00OO00OO00 =str (json .loads (OO0OO0000OO00O0OO )['ip'])#line:439
          O0OO0O0OOOOOOO0O0 =OOOO000O0O0OO0000 #line:440
          O000O00O0OOOOO0O0 =O0OO000OO0O0000OO #line:441
          import socket #line:442
          OO0OO0000OO00O0OO =urllib2 .urlopen (OOO0OO00O0O000OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OO0O0OOOOOOO0O0 +' - '+O000O00O0OOOOO0O0 +' - '+OO0O00O0OOOO00O0O +' - '+OOO0O0O00OO00OO00 ).readlines ()#line:443
       except :pass #line:445
def skindialogsettind18 ():#line:446
	try :#line:447
		OO00O000O00OOOO0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:448
		OO00O0OO00OO00O0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:449
		copyfile (OO00O000O00OOOO0O ,OO00O0OO00OO00O0O )#line:450
	except :pass #line:451
def telemedia_android5fix ():#line:452
    O00O0OOO0OO0O00OO =ADDON .getSetting ('systemtype')#line:453
    OO00O00OOO0O0O00O =ADDON .getSetting ('teleandro')#line:454
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in O00O0OOO0OO0O00OO or OO00O00OOO0O0O00O =='true':#line:455
        OO0O00OO0O0O00O00 ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:457
        O0O000OO0OO0OOO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:458
        OO0O00000O0O0OOO0 =xbmcgui .DialogProgress ()#line:459
        OO0O00000O0O0OOO0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:460
        OOOO0O00OOOOO0000 =os .path .join (PACKAGES ,'isr.zip')#line:461
        O0OOOO00000O000OO =urllib2 .Request (OO0O00OO0O0O00O00 )#line:462
        OOOO0OOO0OOOOOOOO =urllib2 .urlopen (O0OOOO00000O000OO )#line:463
        O000OO0O0OO00OOO0 =xbmcgui .DialogProgress ()#line:465
        O000OO0O0OO00OOO0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:466
        O000OO0O0OO00OOO0 .update (0 )#line:467
        O000O0000O0OOO00O =open (OOOO0O00OOOOO0000 ,'wb')#line:469
        try :#line:471
          O0OOO00O000000OO0 =OOOO0OOO0OOOOOOOO .info ().getheader ('Content-Length').strip ()#line:472
          O0OOO0OO0OOO0O0OO =True #line:473
        except AttributeError :#line:474
              O0OOO0OO0OOO0O0OO =False #line:475
        if O0OOO0OO0OOO0O0OO :#line:477
              O0OOO00O000000OO0 =int (O0OOO00O000000OO0 )#line:478
        O00O00O00OOOO0O0O =0 #line:480
        OO0OO0O0OO0OOOO00 =time .time ()#line:481
        while True :#line:482
              O00O00000OO0OO0OO =OOOO0OOO0OOOOOOOO .read (8192 )#line:483
              if not O00O00000OO0OO0OO :#line:484
                  sys .stdout .write ('\n')#line:485
                  break #line:486
              O00O00O00OOOO0O0O +=len (O00O00000OO0OO0OO )#line:488
              O000O0000O0OOO00O .write (O00O00000OO0OO0OO )#line:489
              if not O0OOO0OO0OOO0O0OO :#line:491
                  O0OOO00O000000OO0 =O00O00O00OOOO0O0O #line:492
              if O000OO0O0OO00OOO0 .iscanceled ():#line:493
                 O000OO0O0OO00OOO0 .close ()#line:494
                 try :#line:495
                  os .remove (OOOO0O00OOOOO0000 )#line:496
                 except :#line:497
                  pass #line:498
                 break #line:499
              O0OO00OOOO0OOO00O =float (O00O00O00OOOO0O0O )/O0OOO00O000000OO0 #line:500
              O0OO00OOOO0OOO00O =round (O0OO00OOOO0OOO00O *100 ,2 )#line:501
              OO0O0O0000000OOOO =O00O00O00OOOO0O0O /(1024 *1024 )#line:502
              OOO000OO0O0OO00OO =O0OOO00O000000OO0 /(1024 *1024 )#line:503
              OO00O0OO00O000OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0O0000000OOOO ,'teal',OOO000OO0O0OO00OO )#line:504
              if (time .time ()-OO0OO0O0OO0OOOO00 )>0 :#line:505
                OO0000000O0OO0OO0 =O00O00O00OOOO0O0O /(time .time ()-OO0OO0O0OO0OOOO00 )#line:506
                OO0000000O0OO0OO0 =OO0000000O0OO0OO0 /1024 #line:507
              else :#line:508
               OO0000000O0OO0OO0 =0 #line:509
              O0OOOOO0O00O00O0O ='KB'#line:510
              if OO0000000O0OO0OO0 >=1024 :#line:511
                 OO0000000O0OO0OO0 =OO0000000O0OO0OO0 /1024 #line:512
                 O0OOOOO0O00O00O0O ='MB'#line:513
              if OO0000000O0OO0OO0 >0 and not O0OO00OOOO0OOO00O ==100 :#line:514
                  O0O0O0O00O00OO00O =(O0OOO00O000000OO0 -O00O00O00OOOO0O0O )/OO0000000O0OO0OO0 #line:515
              else :#line:516
                  O0O0O0O00O00OO00O =0 #line:517
              OO000O00OO0O000OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0000000O0OO0OO0 ,O0OOOOO0O00O00O0O )#line:518
              O000OO0O0OO00OOO0 .update (int (O0OO00OOOO0OOO00O ),OO00O0OO00O000OOO ,OO000O00OO0O000OO +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:520
        OO0000OO0000O0000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:523
        O000O0000O0OOO00O .close ()#line:526
        extract .all (OOOO0O00OOOOO0000 ,OO0000OO0000O0000 ,O000OO0O0OO00OOO0 )#line:527
        try :#line:531
          os .remove (OOOO0O00OOOOO0000 )#line:532
        except :#line:533
          pass #line:534
def checkidupdate ():#line:535
				O0000O0O00OO0OOO0 =True #line:536
				wiz .setS ("notedismiss","true")#line:537
				O000O0000O0O00OOO =wiz .workingURL (NOTIFICATION )#line:538
				OO0O0OOOOOOO0OOOO =" Kodi Premium"#line:540
				O0OOOOOOOOO0OOOO0 =wiz .checkBuild (OO0O0OOOOOOO0OOOO ,'gui')#line:541
				OO0OO000OOO000000 =OO0O0OOOOOOO0OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:542
				if not wiz .workingURL (O0OOOOOOOOO0OOOO0 )==True :return #line:543
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:544
				O0000000OOO00OOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OO000OOO000000 )#line:547
				try :os .remove (O0000000OOO00OOO0 )#line:548
				except :pass #line:549
				if 'google'in O0OOOOOOOOO0OOOO0 :#line:551
				   OOO0OO0OOO0000OO0 =googledrive_download (O0OOOOOOOOO0OOOO0 ,O0000000OOO00OOO0 ,DP2 ,wiz .checkBuild (OO0O0OOOOOOO0OOOO ,'filesize'))#line:552
				else :#line:555
				  downloaderbg .download3 (O0OOOOOOOOO0OOOO0 ,O0000000OOO00OOO0 ,DP2 )#line:556
				xbmc .sleep (100 )#line:557
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:558
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:560
				extract .all2 (O0000000OOO00OOO0 ,HOME ,DP2 )#line:562
				DP2 .close ()#line:563
				wiz .defaultSkin ()#line:564
				wiz .lookandFeelData ('save')#line:565
				try :#line:566
					telemedia_android5fix ()#line:567
				except :pass #line:568
				wiz .kodi17Fix ()#line:569
				if KODIV >=18 :#line:570
					skindialogsettind18 ()#line:571
				debridit .debridIt ('restore','all')#line:576
				traktit .traktIt ('restore','all')#line:577
				if INSTALLMETHOD ==1 :OOO0000O0O00OO000 =1 #line:578
				elif INSTALLMETHOD ==2 :OOO0000O0O00OO000 =0 #line:579
				else :DP2 .close ()#line:580
				O00OOO0O0OOOOO0OO =(NOTIFICATION2 )#line:581
				OO0OO0OOO00OOO00O =urllib2 .urlopen (O00OOO0O0OOOOO0OO )#line:582
				OOO00O00OO00O00O0 =OO0OO0OOO00OOO00O .readlines ()#line:583
				OOOOO00O000O0OO0O =0 #line:584
				for OOOOOO0OOOO0OO0O0 in OOO00O00OO00O00O0 :#line:587
					if OOOOOO0OOOO0OO0O0 .split (' ==')[0 ]=="noreset"or OOOOOO0OOOO0OO0O0 .split ()[0 ]=="noreset":#line:588
						xbmc .executebuiltin ("ReloadSkin()")#line:590
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:591
						OO0O0O00OOOO00O0O =(ADDON .getSetting ("message"))#line:592
						if OO0O0O00OOOO00O0O =='true':#line:593
							infobuild ()#line:594
						update_Votes ()#line:595
						indicatorfastupdate ()#line:596
					if OOOOOO0OOOO0OO0O0 .split (' ==')[0 ]=="reset"or OOOOOO0OOOO0OO0O0 .split ()[0 ]=="reset":#line:597
						update_Votes ()#line:599
						indicatorfastupdate ()#line:600
						resetkodi ()#line:601
def checkvictory ():#line:602
				wiz .setS ("notedismiss2","true")#line:604
				O0OO00OOOOO00OOOO =wiz .workingURL (NOTIFICATION2 )#line:605
				O0OO0OOO0O0O0O0OO =" Kodi Premium"#line:607
				O0OO0O0O000O00O0O ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:608
				O00O0000OO0000OO0 =O0OO0OOO0O0O0O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:609
				if not wiz .workingURL (O0OO0O0O000O00O0O )==True :return #line:610
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:611
				O0OO00000OO0OOOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0000OO0000OO0 )#line:614
				try :os .remove (O0OO00000OO0OOOO0 )#line:615
				except :pass #line:616
				if 'google'in O0OO0O0O000O00O0O :#line:618
				   OOO00000OO0O0O00O =googledrive_download (O0OO0O0O000O00O0O ,O0OO00000OO0OOOO0 ,DP2 ,wiz .checkBuild (O0OO0OOO0O0O0O0OO ,'filesize'))#line:619
				else :#line:622
				  downloaderbg .download5 (O0OO0O0O000O00O0O ,O0OO00000OO0OOOO0 ,DP2 )#line:623
				xbmc .sleep (100 )#line:624
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:625
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:627
				extract .all2 (O0OO00000OO0OOOO0 ,ADDONS ,DP2 )#line:629
				DP2 .close ()#line:630
				wiz .defaultSkin ()#line:631
				wiz .lookandFeelData ('save')#line:632
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:633
				if INSTALLMETHOD ==1 :O00OO0OOO0000OO00 =1 #line:635
				elif INSTALLMETHOD ==2 :O00OO0OOO0000OO00 =0 #line:636
				else :DP2 .close ()#line:637
def checkUpdate ():#line:642
	OO0OOOOO0O00OOO00 =wiz .getS ('buildname')#line:643
	OOO00000OO0O0OO0O =wiz .getS ('buildversion')#line:644
	O0OO0O0OO0OOO000O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:645
	O000O0O0O00OOO0OO =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OO0OOOOO0O00OOO00 ).findall (O0OO0O0OO0OOO000O )#line:646
	if len (O000O0O0O00OOO0OO )>0 :#line:647
		OO00OO00OOO000O00 =O000O0O0O00OOO0OO [0 ][0 ]#line:648
		O0000OO0000O0000O =O000O0O0O00OOO0OO [0 ][1 ]#line:649
		O0000O0000O0O0000 =O000O0O0O00OOO0OO [0 ][2 ]#line:650
		wiz .setS ('latestversion',OO00OO00OOO000O00 )#line:651
		if OO00OO00OOO000O00 >OOO00000OO0O0OO0O :#line:652
			if DISABLEUPDATE =='false':#line:653
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OOO00000OO0O0OO0O ,OO00OO00OOO000O00 ),xbmc .LOGNOTICE )#line:654
				notify .updateWindow (OO0OOOOO0O00OOO00 ,OOO00000OO0O0OO0O ,OO00OO00OOO000O00 ,O0000OO0000O0000O ,O0000O0000O0O0000 )#line:655
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OOO00000OO0O0OO0O ,OO00OO00OOO000O00 ),xbmc .LOGNOTICE )#line:656
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OOO00000OO0O0OO0O ,OO00OO00OOO000O00 ),xbmc .LOGNOTICE )#line:657
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:658
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:693
if AUTOUPDATE =='Yes':#line:694
	input =(ADDON .getSetting ("autoupdate"))#line:695
	xbmc .executebuiltin ("UpdateLocalAddons")#line:696
	xbmc .executebuiltin ("UpdateAddonRepos")#line:697
	wiz .wizardUpdate ('startup')#line:698
if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'skin.estuary'):#line:703
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:704
    setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")#line:706
    src =os .path .join (xbmc .translatePath ("special://home/"),"addons/skin.estuary")#line:707
    extract .all (setting_file ,src )#line:710
    wiz .kodi17Fix ()#line:722
    if KODIV >=18 :#line:724
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","addon.xml")#line:726
        with open (setting_file ,'r')as file :#line:727
          filedata =file .read ()#line:728
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.12.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.14.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''')#line:777
        with open (setting_file ,'w')as file :#line:780
          file .write (filedata )#line:781
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")#line:787
        with open (setting_file ,'r')as file :#line:788
          filedata =file .read ()#line:789
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">2</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="-" />
			<param name="DialogHeaderId" value="20" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="99">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>9</onleft>
			<onright>9</onright>
			<onup>2</onup>
			<ondown>2</ondown>
		</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(9).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(9).HasNext</visible>
		</control>
		<control type="grouplist" id="2">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>9</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="10">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>12</onleft>
				<onright>11</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
			<control type="button" id="11">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>10</onleft>
				<onright>12</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="13">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="3">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="4">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="5">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="7">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="6">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="8">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">5</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="" />
			<param name="DialogHeaderId" value="2" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="3">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>3</onleft>
			<onright>3</onright>
			<onup>5</onup>
			<ondown>5</ondown>
		</control>
			<control type="button" id="10">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
			</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(3).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(3).HasNext</visible>
		</control>
		<control type="grouplist" id="5">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>3</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="28">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
			<control type="button" id="29">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="10">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="7">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="8">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="9">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="14">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="11">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="13">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''')#line:1180
        with open (setting_file ,'w')as file :#line:1183
          file .write (filedata )#line:1184
    wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:1192
    xbmc .executebuiltin ("ReloadSkin()")#line:1193
    xbmc .executebuiltin ("ActivateWindow(home)")#line:1194
    f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:1195
    xbmc .Player ().play (f_play ,windowed =False )#line:1196
def setuname ():#line:1323
    O00OOO0O0OOO00OOO =''#line:1324
    OO000O0000O00O0O0 =xbmc .Keyboard (O00OOO0O0OOO00OOO ,'הכנס שם משתמש')#line:1325
    OO000O0000O00O0O0 .doModal ()#line:1326
    if OO000O0000O00O0O0 .isConfirmed ():#line:1327
           O00OOO0O0OOO00OOO =OO000O0000O00O0O0 .getText ()#line:1328
           wiz .setS ('user',str (O00OOO0O0OOO00OOO ))#line:1329
def STARTP2 ():#line:1330
	if BUILDNAME ==" Kodi Premium":#line:1331
		O000O0O0OO0O00O0O =(ADDON .getSetting ("user"))#line:1332
		O000OOOOO00OO0O00 =(UNAME )#line:1333
		O0OOO0OOO00O0O00O =urllib2 .urlopen (O000OOOOO00OO0O00 )#line:1334
		OO00OOOOO00OO0OOO =O0OOO0OOO00O0O00O .readlines ()#line:1335
		O0O0O0OOO0OO0OO0O =0 #line:1336
		for OO00O0O0O0OOOOO0O in OO00OOOOO00OO0OOO :#line:1337
			if OO00O0O0O0OOOOO0O .split (' ==')[0 ]==O000O0O0OO0O00O0O or OO00O0O0O0OOOOO0O .split ()[0 ]==O000O0O0OO0O00O0O :#line:1338
				O0O0O0OOO0OO0OO0O =1 #line:1339
				break #line:1340
		if O0O0O0OOO0OO0OO0O ==0 :#line:1341
			OO00O00O0O0OO0O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:1343
			if OO00O00O0O0OO0O0O :#line:1345
				ADDON .openSettings ()#line:1346
				sys .exit ()#line:1347
			else :#line:1348
				sys .exit ()#line:1349
		return 'ok'#line:1353
def skinWIN ():#line:1356
	idle ()#line:1357
	O0OO00O000O00O000 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:1358
	OO0O000000OO00OOO =[];O00O0000O0O000OOO =[]#line:1359
	for O0OO0O000OO0O0000 in sorted (O0OO00O000O00O000 ,key =lambda OOO00OO00OOOOO00O :OOO00OO00OOOOO00O ):#line:1360
		O0O0OOO000OO00000 =os .path .split (O0OO0O000OO0O0000 [:-1 ])[1 ]#line:1361
		OOO0OOOOOOOO00O00 =os .path .join (O0OO0O000OO0O0000 ,'addon.xml')#line:1362
		if os .path .exists (OOO0OOOOOOOO00O00 ):#line:1363
			OO0000OO0000O000O =open (OOO0OOOOOOOO00O00 )#line:1364
			OOOOO0000O0O0O0OO =OO0000OO0000O000O .read ()#line:1365
			O0OOOOOOOOOOO000O =parseDOM2 (OOOOO0000O0O0O0OO ,'addon',ret ='id')#line:1366
			OO00O0OOOO000O00O =O0O0OOO000OO00000 if len (O0OOOOOOOOOOO000O )==0 else O0OOOOOOOOOOO000O [0 ]#line:1367
			try :#line:1368
				O0OO000O0O0OO0OOO =xbmcaddon .Addon (id =OO00O0OOOO000O00O )#line:1369
				OO0O000000OO00OOO .append (O0OO000O0O0OO0OOO .getAddonInfo ('name'))#line:1370
				O00O0000O0O000OOO .append (OO00O0OOOO000O00O )#line:1371
			except :#line:1372
				pass #line:1373
	OOO0OOO0OOO0O0OOO =[];OO0OOO0OO00OO0O00 =0 #line:1374
	O0O0000OOO0O0O000 =["Current Skin -- %s"%currSkin ()]+OO0O000000OO00OOO #line:1375
	OO0OOO0OO00OO0O00 =DIALOG .select ("Select the Skin you want to swap with.",O0O0000OOO0O0O000 )#line:1376
	if OO0OOO0OO00OO0O00 ==-1 :return #line:1377
	else :#line:1378
		OO0000000OO00O0O0 =(OO0OOO0OO00OO0O00 -1 )#line:1379
		OOO0OOO0OOO0O0OOO .append (OO0000000OO00O0O0 )#line:1380
		O0O0000OOO0O0O000 [OO0OOO0OO00OO0O00 ]="%s"%(OO0O000000OO00OOO [OO0000000OO00O0O0 ])#line:1381
	if OOO0OOO0OOO0O0OOO ==None :return #line:1382
	for O00000O00000O00O0 in OOO0OOO0OOO0O0OOO :#line:1383
		swapSkins (O00O0000O0O000OOO [O00000O00000O00O0 ])#line:1384
def currSkin ():#line:1386
	return xbmc .getSkinDir ('Container.PluginName')#line:1387
def fix17update ():#line:1389
	if KODIV >=17 and KODIV <18 :#line:1390
		wiz .kodi17Fix ()#line:1391
		xbmc .sleep (4000 )#line:1392
		try :#line:1393
			OO00000O0O0O0O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1394
			OOO00O000O0O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1395
			os .rename (OO00000O0O0O0O000 ,OOO00O000O0O0O0O0 )#line:1396
		except :#line:1397
				pass #line:1398
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1399
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1400
		fixfont ()#line:1401
		OOOOO00OOO00OOO0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1402
		try :#line:1404
			O0OO0O00O00O000OO =open (OOOOO00OOO00OOO0O ,'r')#line:1405
			OO00O0OO0O000000O =O0OO0O00O00O000OO .read ()#line:1406
			O0OO0O00O00O000OO .close ()#line:1407
			O000O000OO0000000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:1408
			O000O0O0OO000OOOO =re .compile (O000O000OO0000000 ).findall (OO00O0OO0O000000O )[0 ]#line:1409
			O0OO0O00O00O000OO =open (OOOOO00OOO00OOO0O ,'w')#line:1410
			O0OO0O00O00O000OO .write (OO00O0OO0O000000O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O000O0O0OO000OOOO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:1411
			O0OO0O00O00O000OO .close ()#line:1412
		except :#line:1413
				pass #line:1414
		wiz .kodi17Fix ()#line:1415
		OOOOO00OOO00OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1416
		try :#line:1417
			O0OO0O00O00O000OO =open (OOOOO00OOO00OOO0O ,'r')#line:1418
			OO00O0OO0O000000O =O0OO0O00O00O000OO .read ()#line:1419
			O0OO0O00O00O000OO .close ()#line:1420
			O000O000OO0000000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:1421
			O000O0O0OO000OOOO =re .compile (O000O000OO0000000 ).findall (OO00O0OO0O000000O )[0 ]#line:1422
			O0OO0O00O00O000OO =open (OOOOO00OOO00OOO0O ,'w')#line:1423
			O0OO0O00O00O000OO .write (OO00O0OO0O000000O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O000O0O0OO000OOOO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:1424
			O0OO0O00O00O000OO .close ()#line:1425
		except :#line:1426
				pass #line:1427
		swapSkins ('skin.Premium.mod')#line:1428
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1429
	os ._exit (1 )#line:1430
def fix18update ():#line:1431
	if KODIV >=18 :#line:1432
		xbmc .sleep (4000 )#line:1433
		if BUILDNAME =="":#line:1434
			try :#line:1435
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:1436
			except :#line:1437
				pass #line:1438
		try :#line:1439
			OO0O00OO0OO0OO00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1440
			O0OOO00000000OO0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1441
			os .rename (OO0O00OO0OO0OO00O ,O0OOO00000000OO0O )#line:1442
		except :#line:1443
				pass #line:1444
		skindialogsettind18 ()#line:1445
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1446
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1447
		fixfont ()#line:1448
		OOO000000O00O0O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1449
		try :#line:1450
			OOOOOO00OO0OO000O =open (OOO000000O00O0O00 ,'r')#line:1451
			OOO00OOOO0O000000 =OOOOOO00OO0OO000O .read ()#line:1452
			OOOOOO00OO0OO000O .close ()#line:1453
			O00O00O00O0000000 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:1454
			O0O00O0OOOOO00OO0 =re .compile (O00O00O00O0000000 ).findall (OOO00OOOO0O000000 )[0 ]#line:1455
			OOOOOO00OO0OO000O =open (OOO000000O00O0O00 ,'w')#line:1456
			OOOOOO00OO0OO000O .write (OOO00OOOO0O000000 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O00O0OOOOO00OO0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:1457
			OOOOOO00OO0OO000O .close ()#line:1458
		except :#line:1459
				pass #line:1460
		wiz .kodi17Fix ()#line:1461
		OOO000000O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1462
		try :#line:1463
			OOOOOO00OO0OO000O =open (OOO000000O00O0O00 ,'r')#line:1464
			OOO00OOOO0O000000 =OOOOOO00OO0OO000O .read ()#line:1465
			OOOOOO00OO0OO000O .close ()#line:1466
			O00O00O00O0000000 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:1467
			O0O00O0OOOOO00OO0 =re .compile (O00O00O00O0000000 ).findall (OOO00OOOO0O000000 )[0 ]#line:1468
			OOOOOO00OO0OO000O =open (OOO000000O00O0O00 ,'w')#line:1469
			OOOOOO00OO0OO000O .write (OOO00OOOO0O000000 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O00O0OOOOO00OO0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:1470
			OOOOOO00OO0OO000O .close ()#line:1471
		except :#line:1472
				pass #line:1473
		swapSkins ('skin.Premium.mod')#line:1474
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1475
	os ._exit (1 )#line:1476
def swapSkins (O00OO0OOOO00O0OO0 ,title ="Error"):#line:1477
	O0O0O000O0O0O00OO ='lookandfeel.skin'#line:1478
	OO0O0OOO000O0O0O0 =O00OO0OOOO00O0OO0 #line:1479
	O0OOOOO00OOOO000O =getOld (O0O0O000O0O0O00OO )#line:1480
	OO0O0O0O0OO00O0OO =O0O0O000O0O0O00OO #line:1481
	setNew (OO0O0O0O0OO00O0OO ,OO0O0OOO000O0O0O0 )#line:1482
	O0O00OO0O0OO0O0OO =0 #line:1483
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00OO0O0OO0O0OO <100 :#line:1484
		O0O00OO0O0OO0O0OO +=1 #line:1485
		xbmc .sleep (1 )#line:1486
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1487
		xbmc .executebuiltin ('SendClick(11)')#line:1488
	return True #line:1489
def getOld (O0OOOO0OO00OOO000 ):#line:1491
	try :#line:1492
		O0OOOO0OO00OOO000 ='"%s"'%O0OOOO0OO00OOO000 #line:1493
		OO0O000OO0O0O000O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOOO0OO00OOO000 )#line:1494
		O00O0OOO0OO00OOO0 =xbmc .executeJSONRPC (OO0O000OO0O0O000O )#line:1496
		O00O0OOO0OO00OOO0 =simplejson .loads (O00O0OOO0OO00OOO0 )#line:1497
		if O00O0OOO0OO00OOO0 .has_key ('result'):#line:1498
			if O00O0OOO0OO00OOO0 ['result'].has_key ('value'):#line:1499
				return O00O0OOO0OO00OOO0 ['result']['value']#line:1500
	except :#line:1501
		pass #line:1502
	return None #line:1503
def setNew (OO000OO000O0000OO ,O0000O0OOO0OO0000 ):#line:1506
	try :#line:1507
		OO000OO000O0000OO ='"%s"'%OO000OO000O0000OO #line:1508
		O0000O0OOO0OO0000 ='"%s"'%O0000O0OOO0OO0000 #line:1509
		O0O0OOO000O00O000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO000OO000O0000OO ,O0000O0OOO0OO0000 )#line:1510
		OOOOO0O00OOOOOO00 =xbmc .executeJSONRPC (O0O0OOO000O00O000 )#line:1512
	except :#line:1513
		pass #line:1514
	return None #line:1515
def idle ():#line:1516
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:1517
def fixfont ():#line:1518
	O0O0O0O00OOO0O00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1519
	O00O00OOOOO0OOOOO =json .loads (O0O0O0O00OOO0O00O );#line:1521
	O0000O00OO0O00OO0 =O00O00OOOOO0OOOOO ["result"]["settings"]#line:1522
	O0O00OOOOO0O0O0OO =[OO0OO000OOOOO0O00 for OO0OO000OOOOO0O00 in O0000O00OO0O00OO0 if OO0OO000OOOOO0O00 ["id"]=="audiooutput.audiodevice"][0 ]#line:1524
	OOOOO000000000OOO =O0O00OOOOO0O0O0OO ["options"];#line:1525
	OOO00OO000O0OOOOO =O0O00OOOOO0O0O0OO ["value"];#line:1526
	OO00OOO0000O0OOOO =[OO00OOO000O0O00OO for (OO00OOO000O0O00OO ,O00000OOOO0O0OO00 )in enumerate (OOOOO000000000OOO )if O00000OOOO0O0OO00 ["value"]==OOO00OO000O0OOOOO ][0 ];#line:1528
	OO000OOO000OO00O0 =(OO00OOO0000O0OOOO +1 )%len (OOOOO000000000OOO )#line:1530
	O0OO00O000OOOOO0O =OOOOO000000000OOO [OO000OOO000OO00O0 ]["value"]#line:1532
	OOO0O0O0OO0OOOOOO =OOOOO000000000OOO [OO000OOO000OO00O0 ]["label"]#line:1533
	O0000OOO0000O0000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1535
	try :#line:1537
		OO000O0O00000O0OO =json .loads (O0000OOO0000O0000 );#line:1538
		if OO000O0O00000O0OO ["result"]!=True :#line:1540
			raise Exception #line:1541
	except :#line:1542
		sys .stderr .write ("Error switching audio output device")#line:1543
		raise Exception #line:1544
def checkSkin ():#line:1547
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:1548
	OO00O00O0O0OOO00O =wiz .getS ('defaultskin')#line:1549
	O0OO0000O0O00O0OO =wiz .getS ('defaultskinname')#line:1550
	O0000O0OOOOO0OOOO =wiz .getS ('defaultskinignore')#line:1551
	O0O00000OO0OO0O00 =False #line:1552
	if not OO00O00O0O0OOO00O =='':#line:1553
		if os .path .exists (os .path .join (ADDONS ,OO00O00O0O0OOO00O )):#line:1554
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0000O0O00O0OO )):#line:1555
				O0O00000OO0OO0O00 =OO00O00O0O0OOO00O #line:1556
				O0O0O00OO0OO0O00O =O0OO0000O0O00O0OO #line:1557
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O0O00000OO0OO0O00 =False #line:1558
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');OO00O00O0O0OOO00O ='';O0OO0000O0O00O0OO =''#line:1559
	if OO00O00O0O0OOO00O =='':#line:1560
		OOOO0O0000000OOOO =[]#line:1561
		OOO0O0OO0O00O00OO =[]#line:1562
		for O00OOO0000O0OO00O in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:1563
			O00O00O0O0OO0OOOO ="%s/addon.xml"%O00OOO0000O0OO00O #line:1564
			if os .path .exists (O00O00O0O0OO0OOOO ):#line:1565
				O0OOOOOOO0O0OOOO0 =open (O00O00O0O0OO0OOOO ,mode ='r');OOOOO0O000OO00O0O =O0OOOOOOO0O0OOOO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','');O0OOOOOOO0O0OOOO0 .close ();#line:1566
				O0O00OOOO000O0000 =wiz .parseDOM (OOOOO0O000OO00O0O ,'addon',ret ='id')#line:1567
				OO0O000OOO0OOO0OO =wiz .parseDOM (OOOOO0O000OO00O0O ,'addon',ret ='name')#line:1568
				wiz .log ("%s: %s"%(O00OOO0000O0OO00O ,str (O0O00OOOO000O0000 [0 ])),xbmc .LOGNOTICE )#line:1569
				if len (O0O00OOOO000O0000 )>0 :OOO0O0OO0O00O00OO .append (str (O0O00OOOO000O0000 [0 ]));OOOO0O0000000OOOO .append (str (OO0O000OOO0OOO0OO [0 ]))#line:1570
				else :wiz .log ("ID not found for %s"%O00OOO0000O0OO00O ,xbmc .LOGNOTICE )#line:1571
			else :wiz .log ("ID not found for %s"%O00OOO0000O0OO00O ,xbmc .LOGNOTICE )#line:1572
		if len (OOO0O0OO0O00O00OO )>0 :#line:1573
			if len (OOO0O0OO0O00O00OO )>1 :#line:1574
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:1575
					O0OOO0O00OOOOOO00 =DIALOG .select ("Select skin to switch to!",OOOO0O0000000OOOO )#line:1576
					if O0OOO0O00OOOOOO00 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1577
					else :#line:1578
						O0O00000OO0OO0O00 =OOO0O0OO0O00O00OO [O0OOO0O00OOOOOO00 ]#line:1579
						O0O0O00OO0OO0O00O =OOOO0O0000000OOOO [O0OOO0O00OOOOOO00 ]#line:1580
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1581
	if O0O00000OO0OO0O00 :#line:1588
		skinSwitch .swapSkins (O0O00000OO0OO0O00 )#line:1589
		O0000O00OO0OOOO0O =0 #line:1590
		xbmc .sleep (1000 )#line:1591
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000O00OO0OOOO0O <150 :#line:1592
			O0000O00OO0OOOO0O +=1 #line:1593
			xbmc .sleep (200 )#line:1594
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1596
			wiz .ebi ('SendClick(11)')#line:1597
			wiz .lookandFeelData ('restore')#line:1598
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1599
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1600
while xbmc .Player ().isPlayingVideo ():#line:1602
	xbmc .sleep (1000 )#line:1603
if KODIV >=17 :#line:1605
	NOW =datetime .now ()#line:1606
	temp =wiz .getS ('kodi17iscrap')#line:1607
	if not temp =='':#line:1608
		if temp >str (NOW -timedelta (minutes =2 )):#line:1609
			wiz .log ("Killing Start Up Script")#line:1610
			sys .exit ()#line:1611
	wiz .log ("%s"%(NOW ))#line:1612
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1613
	xbmc .sleep (1000 )#line:1614
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1615
		wiz .log ("Killing Start Up Script")#line:1616
		sys .exit ()#line:1617
	else :#line:1618
		wiz .log ("Continuing Start Up Script")#line:1619
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1621
path =os .path .split (ADDONPATH )#line:1622
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1623
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1624
if KODIADDONS in ADDONPATH :#line:1627
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1628
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1629
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1630
	if os .path .exists (newpath ):#line:1631
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1632
		wiz .cleanHouse (newpath )#line:1633
		wiz .removeFolder (newpath )#line:1634
	try :#line:1635
		wiz .copytree (ADDONPATH ,newpath )#line:1636
	except Exception as e :#line:1637
		pass #line:1638
	wiz .forceUpdate (True )#line:1639
try :#line:1641
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1642
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1643
except :#line:1644
	pass #line:1645
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1647
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1651
			wiz .kodi17Fix ()#line:1652
			fix18update ()#line:1653
			fix17update ()#line:1654
if INSTALLED =='true':#line:1657
    input =(ADDON .getSetting ("auto_rd"))#line:1658
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1660
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1661
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1662
    wiz .clearS ('install')#line:1663
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1748
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1750
	STARTP2 ()#line:1752
	if not NOTIFY =='true':#line:1753
		url =wiz .workingURL (NOTIFICATION )#line:1754
		if url ==True :#line:1755
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1756
			if not id ==False :#line:1757
				try :#line:1758
					id =int (id );NOTEID =int (NOTEID )#line:1759
					if id ==NOTEID :#line:1760
						if NOTEDISMISS =='false':#line:1761
							debridit .debridIt ('update','all')#line:1762
							traktit .traktIt ('update','all')#line:1763
							checkidupdate ()#line:1764
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1765
					elif id >NOTEID :#line:1766
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1767
						wiz .setS ('noteid',str (id ))#line:1768
						wiz .setS ('notedismiss','false')#line:1769
						debridit .debridIt ('update','all')#line:1771
						traktit .traktIt ('update','all')#line:1772
						checkidupdate ()#line:1773
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1775
				except Exception as e :#line:1776
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1777
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1778
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1779
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1780
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1781
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1783
if ENABLE =='No':#line:1784
	if not NOTIFY2 =='true':#line:1785
		url =wiz .workingURL (NOTIFICATION2 )#line:1786
		if url ==True :#line:1787
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1788
			if not id ==False :#line:1789
				try :#line:1790
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1791
					if id ==NOTEID2 :#line:1792
						if NOTEDISMISS2 =='false':#line:1793
							checkvictory ()#line:1794
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1795
					elif id >NOTEID2 :#line:1796
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1797
						wiz .setS ('noteid2',str (id ))#line:1798
						wiz .setS ('notedismiss2','false')#line:1799
						checkvictory ()#line:1800
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1801
				except Exception as e :#line:1802
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1803
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1804
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1805
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1806
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1807
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1809
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1810
	if not NOTIFY3 =='true':#line:1811
		url =wiz .workingURL (NOTIFICATION3 )#line:1812
		if url ==True :#line:1813
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1814
			if not id ==False :#line:1815
				try :#line:1816
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1817
					if id ==NOTEID3 :#line:1818
						if NOTEDISMISS3 =='false':#line:1819
							notify .notification3 (msg )#line:1820
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1821
					elif id >NOTEID3 :#line:1822
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1823
						wiz .setS ('noteid3',str (id ))#line:1824
						wiz .setS ('notedismiss3','false')#line:1825
						notify .notification3 (msg =msg )#line:1826
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1827
				except Exception as e :#line:1828
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1829
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1830
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1831
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1832
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1833
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1834
if KEEPTRAKT =='true':#line:1835
	if TRAKTSAVE <=str (TODAY ):#line:1836
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1837
		traktit .autoUpdate ('all')#line:1838
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1839
	else :#line:1840
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1841
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1842
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1844
if KEEPREAL =='true':#line:1845
	if REALSAVE <=str (TODAY ):#line:1846
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1847
		debridit .autoUpdate ('all')#line:1848
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1849
	else :#line:1850
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1851
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1852
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1854
if KEEPLOGIN =='true':#line:1855
	if LOGINSAVE <=str (TODAY ):#line:1856
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1857
		loginit .autoUpdate ('all')#line:1858
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1859
	else :#line:1860
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1861
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1862
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1864
if AUTOCLEANUP =='true':#line:1865
	service =False #line:1866
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1867
	feq =int (float (AUTOFEQ ))#line:1868
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1869
		service =True #line:1870
		next_run =days [feq ]#line:1871
		wiz .setS ('nextautocleanup',str (next_run ))#line:1872
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1873
	if service ==True :#line:1874
		AUTOCACHE =wiz .getS ('clearcache')#line:1875
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1876
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1877
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1878
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1879
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1880
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1881
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1882
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1883
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1884
wiz .setS ('kodi17iscrap','')#line:1886
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1955
	count =0 #line:1956
	for f in filenames :#line:1957
		count +=1 #line:1958
		fp =os .path .join (dirpath ,f )#line:1959
		total_size +=os .path .getsize (fp )#line:1960
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1961
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1968
	for f2 in filenames2 :#line:1969
		fp2 =os .path .join (dirpath2 ,f2 )#line:1970
		total_size2 +=os .path .getsize (fp2 )#line:1971
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1972
if int (total_sizetext2 )>filesize_thumb :#line:1974
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1975
	if choice2 ==1 :#line:1976
		maintenance .deleteThumbnails ()#line:1977
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1979
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1980
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1982
time .sleep (3 )#line:1983
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:1985
        display_Votes ()#line:1986
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:1988
        file .write (str ('Done'))#line:1990
        file .close ()#line:1991
tele =(ADDON .getSetting ("auto_tele"))#line:1996
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:1998
    if tele =='true':#line:2000
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:2001
