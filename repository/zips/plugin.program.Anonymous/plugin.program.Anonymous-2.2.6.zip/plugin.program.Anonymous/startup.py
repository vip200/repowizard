# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
global teleupdate #line:32
teleupdate =False #line:33
ADDON_ID =uservar .ADDON_ID #line:34
ADDONTITLE =uservar .ADDONTITLE #line:35
ADDON =wiz .addonId (ADDON_ID )#line:36
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:37
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:38
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:39
DIALOG =xbmcgui .Dialog ()#line:40
DP =xbmcgui .DialogProgress ()#line:41
DP2 =xbmcgui .DialogProgressBG ()#line:42
HOME =xbmc .translatePath ('special://home/')#line:43
PROFILE =xbmc .translatePath ('special://profile/')#line:44
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:45
ADDONS =os .path .join (HOME ,'addons')#line:46
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:47
USERDATA =os .path .join (HOME ,'userdata')#line:48
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:49
PACKAGES =os .path .join (ADDONS ,'packages')#line:50
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:51
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:52
ICON =os .path .join (ADDONPATH ,'icon.png')#line:53
ART =os .path .join (ADDONPATH ,'resources','art')#line:54
SKIN =xbmc .getSkinDir ()#line:55
BUILDNAME =wiz .getS ('buildname')#line:56
DEFAULTSKIN =wiz .getS ('defaultskin')#line:57
DEFAULTNAME =wiz .getS ('defaultskinname')#line:58
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:59
BUILDVERSION =wiz .getS ('buildversion')#line:60
BUILDLATEST =wiz .getS ('latestversion')#line:61
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:62
DISABLEUPDATE =wiz .getS ('disableupdate')#line:63
AUTOCLEANUP =wiz .getS ('autoclean')#line:64
AUTOCACHE =wiz .getS ('clearcache')#line:65
AUTOPACKAGES =wiz .getS ('clearpackages')#line:66
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:67
AUTOFEQ =wiz .getS ('autocleanfeq')#line:68
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:69
TRAKTSAVE =wiz .getS ('traktlastsave')#line:70
REALSAVE =wiz .getS ('debridlastsave')#line:71
LOGINSAVE =wiz .getS ('loginlastsave')#line:72
INSTALLMETHOD =wiz .getS ('installmethod')#line:73
KEEPTRAKT =wiz .getS ('keeptrakt')#line:74
KEEPREAL =wiz .getS ('keepdebrid')#line:75
KEEPLOGIN =wiz .getS ('keeplogin')#line:76
INSTALLED =wiz .getS ('installed')#line:77
EXTRACT =wiz .getS ('extract')#line:78
EXTERROR =wiz .getS ('errors')#line:79
NOTIFY =wiz .getS ('notify')#line:80
NOTEDISMISS =wiz .getS ('notedismiss')#line:81
NOTEID =wiz .getS ('noteid')#line:82
NOTIFY2 =wiz .getS ('notify2')#line:83
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:84
NOTEID2 =wiz .getS ('noteid2')#line:85
NOTIFY3 =wiz .getS ('notify3')#line:86
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:87
NOTEID3 =wiz .getS ('noteid3')#line:88
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:89
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:90
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:91
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:92
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:93
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:94
TODAY =date .today ()#line:95
TOMORROW =TODAY +timedelta (days =1 )#line:96
TWODAYS =TODAY +timedelta (days =2 )#line:97
THREEDAYS =TODAY +timedelta (days =3 )#line:98
ONEWEEK =TODAY +timedelta (days =7 )#line:99
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:100
EXCLUDES =uservar .EXCLUDES #line:101
SPEEDFILE =speedtest .SPEEDFILE #line:102
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:103
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:104
NOTIFICATION =uservar .NOTIFICATION #line:105
NOTIFICATION2 =uservar .NOTIFICATION2 #line:106
NOTIFICATION3 =uservar .NOTIFICATION3 #line:107
ENABLE =uservar .ENABLE #line:108
UNAME =speedtest .UNAME #line:109
HEADERMESSAGE =uservar .HEADERMESSAGE #line:110
AUTOUPDATE =uservar .AUTOUPDATE #line:111
WIZARDFILE =uservar .WIZARDFILE #line:112
AUTOINSTALL =uservar .AUTOINSTALL #line:113
REPOID =uservar .REPOID #line:114
REPOADDONXML =uservar .REPOADDONXML #line:115
REPOZIPURL =uservar .REPOZIPURL #line:116
REPOID18 =uservar .REPOID18 #line:117
REPOADDONXML18 =uservar .REPOADDONXML18 #line:118
REPOZIPURL18 =uservar .REPOZIPURL18 #line:119
REQUESTSID =uservar .REQUESTSID #line:121
REQUESTSXML =uservar .REQUESTSXML #line:122
REQUESTSURL =uservar .REQUESTSURL #line:123
COLOR1 =uservar .COLOR1 #line:127
COLOR2 =uservar .COLOR2 #line:128
TMDB_NEW_API =uservar .TMDB_NEW_API #line:129
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:130
FAILED =False #line:131
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:132
AddonID ='plugin.program.Anonymous'#line:134
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:135
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:136
dialog =xbmcgui .Dialog ()#line:137
setting =xbmcaddon .Addon ().getSetting #line:138
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:139
notify_mode =setting ('notify_mode')#line:140
auto_clean =setting ('startup.cache')#line:141
filesize_thumb =int (setting ('filesizethumb_alert'))#line:143
total_size2 =0 #line:146
total_size =0 #line:147
count =0 #line:148
def infobuild ():#line:149
	O00000O000OOO0O0O =wiz .workingURL (NOTIFICATION )#line:150
	if O00000O000OOO0O0O ==True :#line:151
		try :#line:152
			OOOO00OO0OOOO00OO ,OOOOO0OOOO0O000O0 =wiz .splitNotify (NOTIFICATION )#line:153
			if OOOO00OO0OOOO00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:154
			if STARTP2 ()=='ok':#line:155
				notify .updateinfo (OOOOO0OOOO0O000O0 ,True )#line:156
		except Exception as OOO0O0OOOOOO0O000 :#line:157
			wiz .log ("Error on Notifications Window: %s"%str (OOO0O0OOOOOO0O000 ),xbmc .LOGERROR )#line:158
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:159
def disply_hwr ():#line:160
   try :#line:161
    O0000OOOOOO0OO0OO =tmdb_list (TMDB_NEW_API )#line:162
    O00000O0O0O0OO0OO =str ((getHwAddr ('eth0'))*O0000OOOOOO0OO0OO )#line:163
    O0O00OOO00OOO0O0O =(O00000O0O0O0OO0OO [1 ]+O00000O0O0O0OO0OO [2 ]+O00000O0O0O0OO0OO [5 ]+O00000O0O0O0OO0OO [7 ])#line:170
    O00O000OOO000O0O0 =(ADDON .getSetting ("action"))#line:171
    wiz .setS ('action',str (O0O00OOO00OOO0O0O ))#line:173
   except :pass #line:174
def getHwAddr (O000OO0000O00O000 ):#line:175
   import subprocess ,time #line:176
   OO0000O000O0O0000 ='windows'#line:177
   if xbmc .getCondVisibility ('system.platform.android'):#line:178
       OO0000O000O0O0000 ='android'#line:179
   if xbmc .getCondVisibility ('system.platform.android'):#line:180
     OO00OO0OO00OOOO00 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:181
     O00O00O0O00O0O0O0 =re .compile ('link/ether (.+?) brd').findall (str (OO00OO0OO00OOOO00 ))#line:183
     O0O0000000O000OO0 =0 #line:184
     for OOOOOOO00O0OOO00O in O00O00O0O00O0O0O0 :#line:185
      if O00O00O0O00O0O0O0 !='00:00:00:00:00:00':#line:186
          OOO0O00OO0O00000O =OOOOOOO00O0OOO00O #line:187
          O0O0000000O000OO0 =O0O0000000O000OO0 +int (OOO0O00OO0O00000O .replace (':',''),16 )#line:188
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:190
       O0O00O00O00000OO0 =0 #line:191
       O0O0000000O000OO0 =0 #line:192
       O00OO0OOO00O0OO00 =[]#line:193
       OOO00OOO00OO0OO0O =os .popen ("getmac").read ()#line:194
       OOO00OOO00OO0OO0O =OOO00OOO00OO0OO0O .split ("\n")#line:195
       for O00O0OOOOOO000OO0 in OOO00OOO00OO0OO0O :#line:197
            OOOO000O0OO0O0OO0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00O0OOOOOO000OO0 ,re .I )#line:198
            if OOOO000O0OO0O0OO0 :#line:199
                O00O00O0O00O0O0O0 =OOOO000O0OO0O0OO0 .group ().replace ('-',':')#line:200
                O00OO0OOO00O0OO00 .append (O00O00O0O00O0O0O0 )#line:201
                O0O0000000O000OO0 =O0O0000000O000OO0 +int (O00O00O0O00O0O0O0 .replace (':',''),16 )#line:204
   else :#line:206
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:207
   try :#line:224
    return O0O0000000O000OO0 #line:225
   except :pass #line:226
def decode (OO00000000O0OOO00 ,OOOOOOOO0O0000OOO ):#line:227
    import base64 #line:228
    O0000O0OO0OO0O00O =[]#line:229
    if (len (OO00000000O0OOO00 ))!=4 :#line:231
     return 10 #line:232
    OOOOOOOO0O0000OOO =base64 .urlsafe_b64decode (OOOOOOOO0O0000OOO )#line:233
    for OO00O00OOO00O0O00 in range (len (OOOOOOOO0O0000OOO )):#line:235
        OOO0O0O0O000OO000 =OO00000000O0OOO00 [OO00O00OOO00O0O00 %len (OO00000000O0OOO00 )]#line:236
        O00O000O000OOO0O0 =chr ((256 +ord (OOOOOOOO0O0000OOO [OO00O00OOO00O0O00 ])-ord (OOO0O0O0O000OO000 ))%256 )#line:237
        O0000O0OO0OO0O00O .append (O00O000O000OOO0O0 )#line:238
    return "".join (O0000O0OO0OO0O00O )#line:239
def tmdb_list (O0OO0OO0000000000 ):#line:240
    O00OO0O00000OOOO0 =decode ("7643",O0OO0OO0000000000 )#line:243
    return int (O00OO0O00000OOOO0 )#line:246
def u_list (O0000OO0O0OO0OO00 ):#line:247
    from math import sqrt #line:249
    O0000000OOOOOO00O =tmdb_list (TMDB_NEW_API )#line:250
    O0O00OOOO000O00O0 =str ((getHwAddr ('eth0'))*O0000000OOOOOO00O )#line:252
    O0OO0O0000OO0O0OO =int (O0O00OOOO000O00O0 [1 ]+O0O00OOOO000O00O0 [2 ]+O0O00OOOO000O00O0 [5 ]+O0O00OOOO000O00O0 [7 ])#line:253
    O00OOOOOOO0OO0OOO =(ADDON .getSetting ("pass"))#line:255
    OOOOO00OO00OOOOO0 =(str (round (sqrt ((O0OO0O0000OO0O0OO *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:260
    if '.'in OOOOO00OO00OOOOO0 :#line:261
     OOOOO00OO00OOOOO0 =(str (round (sqrt ((O0OO0O0000OO0O0OO *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:262
    if O00OOOOOOO0OO0OOO ==OOOOO00OO00OOOOO0 :#line:263
      OO00O0O0OO0O000OO =O0000OO0O0OO0OO00 #line:265
    else :#line:267
       if STARTP ()and STARTP2 ()=='ok':#line:268
         return O0000OO0O0OO0OO00 #line:270
       OO00O0O0OO0O000OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:271
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:272
       sys .exit ()#line:273
    return OO00O0O0OO0O000OO #line:274
try :#line:275
   disply_hwr ()#line:276
except :#line:277
   pass #line:278
def dis_or_enable_addon (O0OOOO0OOO0OOOOO0 ,OO0OOO0O00OO0O00O ,enable ="true"):#line:279
    import json #line:280
    OO00OOOO0O0OO00OO ='"%s"'%O0OOOO0OOO0OOOOO0 #line:281
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOO0OOO0OOOOO0 )and enable =="true":#line:282
        logging .warning ('already Enabled')#line:283
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OOOO0OOO0OOOOO0 )#line:284
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOO0OOO0OOOOO0 )and enable =="false":#line:285
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OOOO0OOO0OOOOO0 )#line:286
    else :#line:287
        O0O0O0OO0OOOOO000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO00OOOO0O0OO00OO ,enable )#line:288
        OOOO0O0OO000O0OO0 =xbmc .executeJSONRPC (O0O0O0OO0OOOOO000 )#line:289
        O0OO0O00OO000O0O0 =json .loads (OOOO0O0OO000O0OO0 )#line:290
        if enable =="true":#line:291
            xbmc .log ("### Enabled %s, response = %s"%(O0OOOO0OOO0OOOOO0 ,O0OO0O00OO000O0O0 ))#line:292
        else :#line:293
            xbmc .log ("### Disabled %s, response = %s"%(O0OOOO0OOO0OOOOO0 ,O0OO0O00OO000O0O0 ))#line:294
    if OO0OOO0O00OO0O00O =='auto':#line:295
     return True #line:296
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:297
def update_Votes ():#line:298
   try :#line:299
        import requests #line:300
        O0000OO00O0OOOO00 ='18773068'#line:301
        OOO000000OOO0OOO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0000OO00O0OOOO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:313
        O00OOO0000O00O000 ='145273321'#line:315
        O0OO00OO000O0OO00 ={'options':O00OOO0000O00O000 }#line:321
        O0O0OO0OOOO00O000 =requests .post ('https://www.strawpoll.me/'+O0000OO00O0OOOO00 ,headers =OOO000000OOO0OOO0 ,data =O0OO00OO000O0OO00 )#line:323
   except :pass #line:324
def display_Votes ():#line:325
    try :#line:326
        O0000OO0OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:327
        O00OOO0000O000O0O =open (O0000OO0OOO000OO0 ,'r')#line:329
        OO0OO000OOOOOO0O0 =O00OOO0000O000O0O .read ()#line:330
        O00OOO0000O000O0O .close ()#line:331
        OO0OO00O000000O0O ='<setting id="HomeS" type="string">(.+?)</setting>'#line:332
        O0000OO0O0000O00O =re .compile (OO0OO00O000000O0O ).findall (OO0OO000OOOOOO0O0 )[0 ]#line:334
        import requests #line:340
        OOO00OO000O00OOOO ='18782966'#line:341
        O00O0O0OO0000O0OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO00OO000O00OOOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:353
        O00000O00O0000000 ='145313053'#line:355
        O00OOO0OOO0O0OO0O ='145313054'#line:356
        OO0O00OO0OOOO0OOO ='145313057'#line:357
        O0O00O00OOO000O00 ='145313058'#line:358
        OO000O0OO00O0O0O0 ='145313055'#line:359
        O0000O000O00OOOOO ='145313060'#line:360
        OOO000O000OOOOO00 ='145313056'#line:361
        O0O000OO000OO00O0 ='145313059'#line:362
        if O0000OO0O0000O00O =='emin':#line:365
           OOOOOO0OOOO00OO00 =O00000O00O0000000 #line:366
        if O0000OO0O0000O00O =='nox':#line:367
           OOOOOO0OOOO00OO00 =O00OOO0OOO0O0OO0O #line:368
        if O0000OO0O0000O00O =='noxtitan':#line:369
           OOOOOO0OOOO00OO00 =O00OOO0OOO0O0OO0O #line:370
        if O0000OO0O0000O00O =='titan':#line:371
           OOOOOO0OOOO00OO00 =OO0O00OO0OOOO0OOO #line:372
        if O0000OO0O0000O00O =='pheno':#line:373
           OOOOOO0OOOO00OO00 =O0O00O00OOO000O00 #line:374
        if O0000OO0O0000O00O =='netflix':#line:375
           OOOOOO0OOOO00OO00 =OO000O0OO00O0O0O0 #line:376
        if O0000OO0O0000O00O =='nebula':#line:377
           OOOOOO0OOOO00OO00 =O0000O000O00OOOOO #line:378
        if O0000OO0O0000O00O =='pellucid':#line:379
           OOOOOO0OOOO00OO00 =OOO000O000OOOOO00 #line:380
        if O0000OO0O0000O00O =='pellucid2':#line:381
           OOOOOO0OOOO00OO00 =O0O000OO000OO00O0 #line:382
        O000OO000OOOOO0O0 ={'options':OOOOOO0OOOO00OO00 }#line:388
        O0000OO0OO000OOO0 =requests .post ('https://www.strawpoll.me/'+OOO00OO000O00OOOO ,headers =O00O0O0OO0000O0OO ,data =O000OO000OOOOO0O0 )#line:390
    except :pass #line:391
def resetkodi ():#line:392
		if xbmc .getCondVisibility ('system.platform.windows'):#line:393
			OOOOOO0O0000OOO00 =xbmcgui .DialogProgress ()#line:394
			OOOOOO0O0000OOO00 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:397
			OOOOOO0O0000OOO00 .update (0 )#line:398
			for O0O000O00OOO0O0O0 in range (5 ,-1 ,-1 ):#line:399
				time .sleep (1 )#line:400
				OOOOOO0O0000OOO00 .update (int ((5 -O0O000O00OOO0O0O0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O000O00OOO0O0O0 ),'')#line:401
				if OOOOOO0O0000OOO00 .iscanceled ():#line:402
					from resources .libs import win #line:403
					return None ,None #line:404
			from resources .libs import win #line:405
		else :#line:406
			OOOOOO0O0000OOO00 =xbmcgui .DialogProgress ()#line:407
			OOOOOO0O0000OOO00 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:410
			OOOOOO0O0000OOO00 .update (0 )#line:411
			for O0O000O00OOO0O0O0 in range (5 ,-1 ,-1 ):#line:412
				time .sleep (1 )#line:413
				OOOOOO0O0000OOO00 .update (int ((5 -O0O000O00OOO0O0O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O000O00OOO0O0O0 ),'')#line:414
				if OOOOOO0O0000OOO00 .iscanceled ():#line:415
					os ._exit (1 )#line:416
					return None ,None #line:417
			os ._exit (1 )#line:418
def indicatorfastupdate ():#line:419
       try :#line:420
          import json #line:421
          wiz .log ('FRESH MESSAGE')#line:422
          OOO0O0OOO000O0OO0 =(ADDON .getSetting ("user"))#line:423
          O0OOOOOO00O0O0OOO =(ADDON .getSetting ("pass"))#line:424
          O0OO0O0O0O00OO0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:425
          OO00OO0000OO0OOO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:427
          OOOO0OO000OOO0OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:428
          OO0OO000OOO0OO000 =str (json .loads (OOOO0OO000OOO0OOO )['ip'])#line:429
          OOO0OO00O0O0O0O00 =OOO0O0OOO000O0OO0 #line:430
          OO000O0000O00O0O0 =O0OOOOOO00O0O0OOO #line:431
          import socket #line:432
          OOOO0OO000OOO0OOO =urllib2 .urlopen (OO00OO0000OO0OOO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOO0OO00O0O0O0O00 +' - '+OO000O0000O00O0O0 +' - '+O0OO0O0O0O00OO0O0 +' - '+OO0OO000OOO0OO000 ).readlines ()#line:433
       except :pass #line:435
def skindialogsettind18 ():#line:436
	try :#line:437
		OO000OOO0O0OO00O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:438
		O00O0OO0OO000OO00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:439
		copyfile (OO000OOO0O0OO00O0 ,O00O0OO0OO000OO00 )#line:440
	except :pass #line:441
def telemedia_android5fix ():#line:442
    if xbmc .getCondVisibility ('system.platform.android'):#line:444
      xbmc .getInfoLabel ('System.OSVersionInfo')#line:445
      xbmc .sleep (2000 )#line:446
      OO00O00OO000OOO0O =xbmc .getInfoLabel ('System.OSVersionInfo')#line:447
      if 'Android 5'in OO00O00OO000OOO0O :#line:448
        OOOO0OOO00OO0OOOO ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:449
        O0O0O0O0000OO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:450
        OOOO0000O0OOOOO00 =xbmcgui .DialogProgress ()#line:451
        OOOO0000O0OOOOO00 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:452
        O0OOO0OOOOOOO0O00 =os .path .join (PACKAGES ,'isr.zip')#line:453
        O0O0OOO0OOO0OOO00 =urllib2 .Request (OOOO0OOO00OO0OOOO )#line:454
        O0O0OO0OOO000OO0O =urllib2 .urlopen (O0O0OOO0OOO0OOO00 )#line:455
        OOO00O0O0OOO0OOOO =xbmcgui .DialogProgress ()#line:457
        OOO00O0O0OOO0OOOO .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:458
        OOO00O0O0OOO0OOOO .update (0 )#line:459
        OOO0OO0000OOOOO0O =open (O0OOO0OOOOOOO0O00 ,'wb')#line:461
        try :#line:463
          OO0OO00O00O0OO00O =O0O0OO0OOO000OO0O .info ().getheader ('Content-Length').strip ()#line:464
          OOOO00OOOOOO0O0OO =True #line:465
        except AttributeError :#line:466
              OOOO00OOOOOO0O0OO =False #line:467
        if OOOO00OOOOOO0O0OO :#line:469
              OO0OO00O00O0OO00O =int (OO0OO00O00O0OO00O )#line:470
        OOOO0OOOO00O00000 =0 #line:472
        OO0O0O000OOOO0OOO =time .time ()#line:473
        while True :#line:474
              O000OOO00O000O000 =O0O0OO0OOO000OO0O .read (8192 )#line:475
              if not O000OOO00O000O000 :#line:476
                  sys .stdout .write ('\n')#line:477
                  break #line:478
              OOOO0OOOO00O00000 +=len (O000OOO00O000O000 )#line:480
              OOO0OO0000OOOOO0O .write (O000OOO00O000O000 )#line:481
              if not OOOO00OOOOOO0O0OO :#line:483
                  OO0OO00O00O0OO00O =OOOO0OOOO00O00000 #line:484
              if OOO00O0O0OOO0OOOO .iscanceled ():#line:485
                 OOO00O0O0OOO0OOOO .close ()#line:486
                 try :#line:487
                  os .remove (O0OOO0OOOOOOO0O00 )#line:488
                 except :#line:489
                  pass #line:490
                 break #line:491
              O0O0O0OOOOOO0O000 =float (OOOO0OOOO00O00000 )/OO0OO00O00O0OO00O #line:492
              O0O0O0OOOOOO0O000 =round (O0O0O0OOOOOO0O000 *100 ,2 )#line:493
              O000000O0O000000O =OOOO0OOOO00O00000 /(1024 *1024 )#line:494
              OOO0O00OOO0OO0OO0 =OO0OO00O00O0OO00O /(1024 *1024 )#line:495
              OOOOOOO0000O0O0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000000O0O000000O ,'teal',OOO0O00OOO0OO0OO0 )#line:496
              if (time .time ()-OO0O0O000OOOO0OOO )>0 :#line:497
                O0O0O000OO0OOO0O0 =OOOO0OOOO00O00000 /(time .time ()-OO0O0O000OOOO0OOO )#line:498
                O0O0O000OO0OOO0O0 =O0O0O000OO0OOO0O0 /1024 #line:499
              else :#line:500
               O0O0O000OO0OOO0O0 =0 #line:501
              O0OO00OOOOO00OOOO ='KB'#line:502
              if O0O0O000OO0OOO0O0 >=1024 :#line:503
                 O0O0O000OO0OOO0O0 =O0O0O000OO0OOO0O0 /1024 #line:504
                 O0OO00OOOOO00OOOO ='MB'#line:505
              if O0O0O000OO0OOO0O0 >0 and not O0O0O0OOOOOO0O000 ==100 :#line:506
                  O0O0OOO00O00O0OOO =(OO0OO00O00O0OO00O -OOOO0OOOO00O00000 )/O0O0O000OO0OOO0O0 #line:507
              else :#line:508
                  O0O0OOO00O00O0OOO =0 #line:509
              OOOOO00000OO00OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0O000OO0OOO0O0 ,O0OO00OOOOO00OOOO )#line:510
              OOO00O0O0OOO0OOOO .update (int (O0O0O0OOOOOO0O000 ),OOOOOOO0000O0O0O0 ,OOOOO00000OO00OO0 +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:512
        O000OOOO0O0OO0OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:515
        OOO0OO0000OOOOO0O .close ()#line:518
        extract .all (O0OOO0OOOOOOO0O00 ,O000OOOO0O0OO0OO0 ,OOO00O0O0OOO0OOOO )#line:519
        try :#line:523
          os .remove (O0OOO0OOOOOOO0O00 )#line:524
        except :#line:525
          pass #line:526
def checkidupdate ():#line:527
				OO0O00O0OO0OOO0O0 =True #line:528
				wiz .setS ("notedismiss","true")#line:529
				O00O000O0OOO0O00O =wiz .workingURL (NOTIFICATION )#line:530
				O0O0O0OO000OOO000 =" Kodi Premium"#line:532
				OO00OO0000O0OOO0O =wiz .checkBuild (O0O0O0OO000OOO000 ,'gui')#line:533
				O0O000000OO0O00OO =O0O0O0OO000OOO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:534
				if not wiz .workingURL (OO00OO0000O0OOO0O )==True :return #line:535
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:536
				O000O0O00OOOO000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O000000OO0O00OO )#line:539
				try :os .remove (O000O0O00OOOO000O )#line:540
				except :pass #line:541
				if 'google'in OO00OO0000O0OOO0O :#line:543
				   O000O00000O00OO00 =googledrive_download (OO00OO0000O0OOO0O ,O000O0O00OOOO000O ,DP2 ,wiz .checkBuild (O0O0O0OO000OOO000 ,'filesize'))#line:544
				else :#line:547
				  downloaderbg .download3 (OO00OO0000O0OOO0O ,O000O0O00OOOO000O ,DP2 )#line:548
				xbmc .sleep (100 )#line:549
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:550
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:552
				extract .all2 (O000O0O00OOOO000O ,HOME ,DP2 )#line:554
				DP2 .close ()#line:555
				wiz .defaultSkin ()#line:556
				wiz .lookandFeelData ('save')#line:557
				try :#line:558
					telemedia_android5fix ()#line:559
				except :pass #line:560
				wiz .kodi17Fix ()#line:561
				if KODIV >=18 :#line:562
					skindialogsettind18 ()#line:563
				debridit .debridIt ('restore','all')#line:568
				traktit .traktIt ('restore','all')#line:569
				if INSTALLMETHOD ==1 :O00O000O0OOO0000O =1 #line:570
				elif INSTALLMETHOD ==2 :O00O000O0OOO0000O =0 #line:571
				else :DP2 .close ()#line:572
				OOOO0OOO000O0O0OO =(NOTIFICATION2 )#line:573
				O00O000O0OO000O00 =urllib2 .urlopen (OOOO0OOO000O0O0OO )#line:574
				OO0000O0OO0OO000O =O00O000O0OO000O00 .readlines ()#line:575
				O0O0O00OOO00OOOO0 =0 #line:576
				for O0O0O00O0OOOOO0O0 in OO0000O0OO0OO000O :#line:579
					if O0O0O00O0OOOOO0O0 .split (' ==')[0 ]=="noreset"or O0O0O00O0OOOOO0O0 .split ()[0 ]=="noreset":#line:580
						xbmc .executebuiltin ("ReloadSkin()")#line:582
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:583
						OO00O0OOOO0OOO00O =(ADDON .getSetting ("message"))#line:584
						if OO00O0OOOO0OOO00O =='true':#line:585
							infobuild ()#line:586
						update_Votes ()#line:587
						indicatorfastupdate ()#line:588
					if O0O0O00O0OOOOO0O0 .split (' ==')[0 ]=="reset"or O0O0O00O0OOOOO0O0 .split ()[0 ]=="reset":#line:589
						update_Votes ()#line:591
						indicatorfastupdate ()#line:592
						resetkodi ()#line:593
def checkvictory ():#line:594
				wiz .setS ("notedismiss2","true")#line:596
				O0000000OOOOOO000 =wiz .workingURL (NOTIFICATION2 )#line:597
				O00O0OO0000OO0000 =" Kodi Premium"#line:599
				O00OOOO0OO0O0O0O0 ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:600
				OOO0O0OO00OO0OOOO =O00O0OO0000OO0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:601
				if not wiz .workingURL (O00OOOO0OO0O0O0O0 )==True :return #line:602
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:603
				OO00OO00O0OOO0O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O0OO00OO0OOOO )#line:606
				try :os .remove (OO00OO00O0OOO0O0O )#line:607
				except :pass #line:608
				if 'google'in O00OOOO0OO0O0O0O0 :#line:610
				   OO00O0OO0OO000OOO =googledrive_download (O00OOOO0OO0O0O0O0 ,OO00OO00O0OOO0O0O ,DP2 ,wiz .checkBuild (O00O0OO0000OO0000 ,'filesize'))#line:611
				else :#line:614
				  downloaderbg .download5 (O00OOOO0OO0O0O0O0 ,OO00OO00O0OOO0O0O ,DP2 )#line:615
				xbmc .sleep (100 )#line:616
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:617
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:619
				extract .all2 (OO00OO00O0OOO0O0O ,ADDONS ,DP2 )#line:621
				DP2 .close ()#line:622
				wiz .defaultSkin ()#line:623
				wiz .lookandFeelData ('save')#line:624
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:625
				if INSTALLMETHOD ==1 :OOO0000O0O00O0O0O =1 #line:627
				elif INSTALLMETHOD ==2 :OOO0000O0O00O0O0O =0 #line:628
				else :DP2 .close ()#line:629
def checkUpdate ():#line:634
	OOOO000O00OO0O000 =wiz .getS ('buildname')#line:635
	O0OOO00OOOO00OOO0 =wiz .getS ('buildversion')#line:636
	OOOOO0O00O0000O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:637
	OOOO00O00OOO00O00 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOOO000O00OO0O000 ).findall (OOOOO0O00O0000O0O )#line:638
	if len (OOOO00O00OOO00O00 )>0 :#line:639
		OOO0OOOOOOOO0OO0O =OOOO00O00OOO00O00 [0 ][0 ]#line:640
		O00O0OO00OO0OOO00 =OOOO00O00OOO00O00 [0 ][1 ]#line:641
		O0O0OO00000O0000O =OOOO00O00OOO00O00 [0 ][2 ]#line:642
		wiz .setS ('latestversion',OOO0OOOOOOOO0OO0O )#line:643
		if OOO0OOOOOOOO0OO0O >O0OOO00OOOO00OOO0 :#line:644
			if DISABLEUPDATE =='false':#line:645
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0OOO00OOOO00OOO0 ,OOO0OOOOOOOO0OO0O ),xbmc .LOGNOTICE )#line:646
				notify .updateWindow (OOOO000O00OO0O000 ,O0OOO00OOOO00OOO0 ,OOO0OOOOOOOO0OO0O ,O00O0OO00OO0OOO00 ,O0O0OO00000O0000O )#line:647
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0OOO00OOOO00OOO0 ,OOO0OOOOOOOO0OO0O ),xbmc .LOGNOTICE )#line:648
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0OOO00OOOO00OOO0 ,OOO0OOOOOOOO0OO0O ),xbmc .LOGNOTICE )#line:649
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:650
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:685
if AUTOUPDATE =='Yes':#line:686
	input =(ADDON .getSetting ("autoupdate"))#line:687
	xbmc .executebuiltin ("UpdateLocalAddons")#line:688
	xbmc .executebuiltin ("UpdateAddonRepos")#line:689
	wiz .wizardUpdate ('startup')#line:690
if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'skin.estuary'):#line:695
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:696
    setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")#line:698
    src =os .path .join (xbmc .translatePath ("special://home/"),"addons/skin.estuary")#line:699
    extract .all (setting_file ,src )#line:702
    wiz .kodi17Fix ()#line:714
    if KODIV >=18 :#line:716
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","addon.xml")#line:718
        with open (setting_file ,'r')as file :#line:719
          filedata =file .read ()#line:720
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.12.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.14.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''')#line:769
        with open (setting_file ,'w')as file :#line:772
          file .write (filedata )#line:773
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")#line:779
        with open (setting_file ,'r')as file :#line:780
          filedata =file .read ()#line:781
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">2</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="-" />
			<param name="DialogHeaderId" value="20" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="99">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>9</onleft>
			<onright>9</onright>
			<onup>2</onup>
			<ondown>2</ondown>
		</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(9).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(9).HasNext</visible>
		</control>
		<control type="grouplist" id="2">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>9</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="10">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>12</onleft>
				<onright>11</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
			<control type="button" id="11">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>10</onleft>
				<onright>12</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="13">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="3">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="4">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="5">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="7">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="6">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="8">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">5</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="" />
			<param name="DialogHeaderId" value="2" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="3">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>3</onleft>
			<onright>3</onright>
			<onup>5</onup>
			<ondown>5</ondown>
		</control>
			<control type="button" id="10">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
			</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(3).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(3).HasNext</visible>
		</control>
		<control type="grouplist" id="5">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>3</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="28">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
			<control type="button" id="29">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="10">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="7">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="8">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="9">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="14">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="11">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="13">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''')#line:1172
        with open (setting_file ,'w')as file :#line:1175
          file .write (filedata )#line:1176
    wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:1184
    xbmc .executebuiltin ("ReloadSkin()")#line:1185
    xbmc .executebuiltin ("ActivateWindow(home)")#line:1186
    f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:1187
    xbmc .Player ().play (f_play ,windowed =False )#line:1188
def setuname ():#line:1315
    OOOO0000000000O0O =''#line:1316
    OO000O00O0OOOOO00 =xbmc .Keyboard (OOOO0000000000O0O ,'הכנס שם משתמש')#line:1317
    OO000O00O0OOOOO00 .doModal ()#line:1318
    if OO000O00O0OOOOO00 .isConfirmed ():#line:1319
           OOOO0000000000O0O =OO000O00O0OOOOO00 .getText ()#line:1320
           wiz .setS ('user',str (OOOO0000000000O0O ))#line:1321
def STARTP2 ():#line:1322
	if BUILDNAME ==" Kodi Premium":#line:1323
		OO00OO0O00O0OOO00 =(ADDON .getSetting ("user"))#line:1324
		O0O0O0000OO0OOO00 =(UNAME )#line:1325
		O00O000O000000OO0 =urllib2 .urlopen (O0O0O0000OO0OOO00 )#line:1326
		O0OOO00000O0OOOO0 =O00O000O000000OO0 .readlines ()#line:1327
		O0O0O0OOOOOOO0OO0 =0 #line:1328
		for O00O0O000O00OOOO0 in O0OOO00000O0OOOO0 :#line:1329
			if O00O0O000O00OOOO0 .split (' ==')[0 ]==OO00OO0O00O0OOO00 or O00O0O000O00OOOO0 .split ()[0 ]==OO00OO0O00O0OOO00 :#line:1330
				O0O0O0OOOOOOO0OO0 =1 #line:1331
				break #line:1332
		if O0O0O0OOOOOOO0OO0 ==0 :#line:1333
			O00O000000O00O0OO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:1335
			if O00O000000O00O0OO :#line:1337
				ADDON .openSettings ()#line:1338
				sys .exit ()#line:1339
			else :#line:1340
				sys .exit ()#line:1341
		return 'ok'#line:1345
def skinWIN ():#line:1348
	idle ()#line:1349
	OO0O00OOO00O0O00O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:1350
	O00O0O00O00OOO00O =[];O0OOO00OOOOO000OO =[]#line:1351
	for O00000000O00OOOOO in sorted (OO0O00OOO00O0O00O ,key =lambda OOO00O000OO0O00OO :OOO00O000OO0O00OO ):#line:1352
		O0O0OO0OOO0O00O0O =os .path .split (O00000000O00OOOOO [:-1 ])[1 ]#line:1353
		OO0000O00O000O000 =os .path .join (O00000000O00OOOOO ,'addon.xml')#line:1354
		if os .path .exists (OO0000O00O000O000 ):#line:1355
			OOOOOO0OOO00OOO00 =open (OO0000O00O000O000 )#line:1356
			OOOO0O0OOOO0O0000 =OOOOOO0OOO00OOO00 .read ()#line:1357
			O0OOO00OOO0OO0OOO =parseDOM2 (OOOO0O0OOOO0O0000 ,'addon',ret ='id')#line:1358
			O0O00O0000O00O0O0 =O0O0OO0OOO0O00O0O if len (O0OOO00OOO0OO0OOO )==0 else O0OOO00OOO0OO0OOO [0 ]#line:1359
			try :#line:1360
				O0O00OO0O00OOO0OO =xbmcaddon .Addon (id =O0O00O0000O00O0O0 )#line:1361
				O00O0O00O00OOO00O .append (O0O00OO0O00OOO0OO .getAddonInfo ('name'))#line:1362
				O0OOO00OOOOO000OO .append (O0O00O0000O00O0O0 )#line:1363
			except :#line:1364
				pass #line:1365
	O00OOOO00000O0000 =[];O0OO00O000OO0O00O =0 #line:1366
	OO0O0OO0O0O000OO0 =["Current Skin -- %s"%currSkin ()]+O00O0O00O00OOO00O #line:1367
	O0OO00O000OO0O00O =DIALOG .select ("Select the Skin you want to swap with.",OO0O0OO0O0O000OO0 )#line:1368
	if O0OO00O000OO0O00O ==-1 :return #line:1369
	else :#line:1370
		O000OOOO00O0OOO00 =(O0OO00O000OO0O00O -1 )#line:1371
		O00OOOO00000O0000 .append (O000OOOO00O0OOO00 )#line:1372
		OO0O0OO0O0O000OO0 [O0OO00O000OO0O00O ]="%s"%(O00O0O00O00OOO00O [O000OOOO00O0OOO00 ])#line:1373
	if O00OOOO00000O0000 ==None :return #line:1374
	for OO0OOOO00O00OO0OO in O00OOOO00000O0000 :#line:1375
		swapSkins (O0OOO00OOOOO000OO [OO0OOOO00O00OO0OO ])#line:1376
def currSkin ():#line:1378
	return xbmc .getSkinDir ('Container.PluginName')#line:1379
def fix17update ():#line:1381
	if KODIV >=17 and KODIV <18 :#line:1382
		wiz .kodi17Fix ()#line:1383
		xbmc .sleep (4000 )#line:1384
		try :#line:1385
			O00OOO00O000O0O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1386
			O00OOO00OO000O00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1387
			os .rename (O00OOO00O000O0O0O ,O00OOO00OO000O00O )#line:1388
		except :#line:1389
				pass #line:1390
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1391
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1392
		fixfont ()#line:1393
		O00O000O0O0OO000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1394
		try :#line:1396
			OO0O0000O00OO000O =open (O00O000O0O0OO000O ,'r')#line:1397
			O0O000O00000O0000 =OO0O0000O00OO000O .read ()#line:1398
			OO0O0000O00OO000O .close ()#line:1399
			O0O0OOO0OO0O0000O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:1400
			OOOO0000O0O00O0O0 =re .compile (O0O0OOO0OO0O0000O ).findall (O0O000O00000O0000 )[0 ]#line:1401
			OO0O0000O00OO000O =open (O00O000O0O0OO000O ,'w')#line:1402
			OO0O0000O00OO000O .write (O0O000O00000O0000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOO0000O0O00O0O0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:1403
			OO0O0000O00OO000O .close ()#line:1404
		except :#line:1405
				pass #line:1406
		wiz .kodi17Fix ()#line:1407
		O00O000O0O0OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1408
		try :#line:1409
			OO0O0000O00OO000O =open (O00O000O0O0OO000O ,'r')#line:1410
			O0O000O00000O0000 =OO0O0000O00OO000O .read ()#line:1411
			OO0O0000O00OO000O .close ()#line:1412
			O0O0OOO0OO0O0000O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:1413
			OOOO0000O0O00O0O0 =re .compile (O0O0OOO0OO0O0000O ).findall (O0O000O00000O0000 )[0 ]#line:1414
			OO0O0000O00OO000O =open (O00O000O0O0OO000O ,'w')#line:1415
			OO0O0000O00OO000O .write (O0O000O00000O0000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOO0000O0O00O0O0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:1416
			OO0O0000O00OO000O .close ()#line:1417
		except :#line:1418
				pass #line:1419
		swapSkins ('skin.Premium.mod')#line:1420
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1421
	os ._exit (1 )#line:1422
def fix18update ():#line:1423
	if KODIV >=18 :#line:1424
		xbmc .sleep (4000 )#line:1425
		if BUILDNAME =="":#line:1426
			try :#line:1427
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:1428
			except :#line:1429
				pass #line:1430
		try :#line:1431
			O0OOO000OOOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1432
			OO0O0O00000O0O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1433
			os .rename (O0OOO000OOOOO00O0 ,OO0O0O00000O0O000 )#line:1434
		except :#line:1435
				pass #line:1436
		skindialogsettind18 ()#line:1437
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1438
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1439
		fixfont ()#line:1440
		O0O000O0O0OO0OO00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1441
		try :#line:1442
			OO00OOOOO0O0OOO00 =open (O0O000O0O0OO0OO00 ,'r')#line:1443
			OO000O0O0OO0O00OO =OO00OOOOO0O0OOO00 .read ()#line:1444
			OO00OOOOO0O0OOO00 .close ()#line:1445
			OO0O0OOO0OOO00OOO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:1446
			O0O0OOO0OOOOOOOO0 =re .compile (OO0O0OOO0OOO00OOO ).findall (OO000O0O0OO0O00OO )[0 ]#line:1447
			OO00OOOOO0O0OOO00 =open (O0O000O0O0OO0OO00 ,'w')#line:1448
			OO00OOOOO0O0OOO00 .write (OO000O0O0OO0O00OO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O0OOO0OOOOOOOO0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:1449
			OO00OOOOO0O0OOO00 .close ()#line:1450
		except :#line:1451
				pass #line:1452
		wiz .kodi17Fix ()#line:1453
		O0O000O0O0OO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1454
		try :#line:1455
			OO00OOOOO0O0OOO00 =open (O0O000O0O0OO0OO00 ,'r')#line:1456
			OO000O0O0OO0O00OO =OO00OOOOO0O0OOO00 .read ()#line:1457
			OO00OOOOO0O0OOO00 .close ()#line:1458
			OO0O0OOO0OOO00OOO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:1459
			O0O0OOO0OOOOOOOO0 =re .compile (OO0O0OOO0OOO00OOO ).findall (OO000O0O0OO0O00OO )[0 ]#line:1460
			OO00OOOOO0O0OOO00 =open (O0O000O0O0OO0OO00 ,'w')#line:1461
			OO00OOOOO0O0OOO00 .write (OO000O0O0OO0O00OO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O0OOO0OOOOOOOO0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:1462
			OO00OOOOO0O0OOO00 .close ()#line:1463
		except :#line:1464
				pass #line:1465
		swapSkins ('skin.Premium.mod')#line:1466
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1467
	os ._exit (1 )#line:1468
def swapSkins (O0O000OOOOO000OO0 ,title ="Error"):#line:1469
	OO0OO0O0O0OO0O00O ='lookandfeel.skin'#line:1470
	O000O0OOO00O0O0O0 =O0O000OOOOO000OO0 #line:1471
	OOOOOOO00O0O0O0O0 =getOld (OO0OO0O0O0OO0O00O )#line:1472
	OOOOOOO000O000O0O =OO0OO0O0O0OO0O00O #line:1473
	setNew (OOOOOOO000O000O0O ,O000O0OOO00O0O0O0 )#line:1474
	O00O0O0O0000OO0OO =0 #line:1475
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O0O0000OO0OO <100 :#line:1476
		O00O0O0O0000OO0OO +=1 #line:1477
		xbmc .sleep (1 )#line:1478
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1479
		xbmc .executebuiltin ('SendClick(11)')#line:1480
	return True #line:1481
def getOld (O00OOOOO0OO0OOOOO ):#line:1483
	try :#line:1484
		O00OOOOO0OO0OOOOO ='"%s"'%O00OOOOO0OO0OOOOO #line:1485
		OOO00OO00000OO0O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00OOOOO0OO0OOOOO )#line:1486
		O00000O00O0OO0OOO =xbmc .executeJSONRPC (OOO00OO00000OO0O0 )#line:1488
		O00000O00O0OO0OOO =simplejson .loads (O00000O00O0OO0OOO )#line:1489
		if O00000O00O0OO0OOO .has_key ('result'):#line:1490
			if O00000O00O0OO0OOO ['result'].has_key ('value'):#line:1491
				return O00000O00O0OO0OOO ['result']['value']#line:1492
	except :#line:1493
		pass #line:1494
	return None #line:1495
def setNew (OO0OO000OOOO00OOO ,OO0OO0O0O0O0O0OO0 ):#line:1498
	try :#line:1499
		OO0OO000OOOO00OOO ='"%s"'%OO0OO000OOOO00OOO #line:1500
		OO0OO0O0O0O0O0OO0 ='"%s"'%OO0OO0O0O0O0O0OO0 #line:1501
		O000O00OOOO0O0O00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0OO000OOOO00OOO ,OO0OO0O0O0O0O0OO0 )#line:1502
		OO00O00OOOO0000OO =xbmc .executeJSONRPC (O000O00OOOO0O0O00 )#line:1504
	except :#line:1505
		pass #line:1506
	return None #line:1507
def idle ():#line:1508
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:1509
def fixfont ():#line:1510
	OO00O0000OO0OO00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1511
	OOOO00OO0O0O00OO0 =json .loads (OO00O0000OO0OO00O );#line:1513
	OOOO00OO00OO0000O =OOOO00OO0O0O00OO0 ["result"]["settings"]#line:1514
	OOO0O0000000OO000 =[O00O00OO0O00OO00O for O00O00OO0O00OO00O in OOOO00OO00OO0000O if O00O00OO0O00OO00O ["id"]=="audiooutput.audiodevice"][0 ]#line:1516
	O00OOOO000OO000OO =OOO0O0000000OO000 ["options"];#line:1517
	OOOO00O000000O00O =OOO0O0000000OO000 ["value"];#line:1518
	OO0OOO0O00OOOO00O =[OO0OO0OOOO0OOO000 for (OO0OO0OOOO0OOO000 ,OO0O0000O0O0000O0 )in enumerate (O00OOOO000OO000OO )if OO0O0000O0O0000O0 ["value"]==OOOO00O000000O00O ][0 ];#line:1520
	OO0OO0000OO0OO000 =(OO0OOO0O00OOOO00O +1 )%len (O00OOOO000OO000OO )#line:1522
	OO000000O0OOO00OO =O00OOOO000OO000OO [OO0OO0000OO0OO000 ]["value"]#line:1524
	O000OO0O0O000O00O =O00OOOO000OO000OO [OO0OO0000OO0OO000 ]["label"]#line:1525
	O00O0OOOOOO0OO00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1527
	try :#line:1529
		OOO0O0O0O0OO0OO0O =json .loads (O00O0OOOOOO0OO00O );#line:1530
		if OOO0O0O0O0OO0OO0O ["result"]!=True :#line:1532
			raise Exception #line:1533
	except :#line:1534
		sys .stderr .write ("Error switching audio output device")#line:1535
		raise Exception #line:1536
def checkSkin ():#line:1539
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:1540
	O00OO000O00O000OO =wiz .getS ('defaultskin')#line:1541
	OO00OOO0O00O0OOOO =wiz .getS ('defaultskinname')#line:1542
	O0O0OO00000O0OO00 =wiz .getS ('defaultskinignore')#line:1543
	O0O0O000000O0OO00 =False #line:1544
	if not O00OO000O00O000OO =='':#line:1545
		if os .path .exists (os .path .join (ADDONS ,O00OO000O00O000OO )):#line:1546
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OOO0O00O0OOOO )):#line:1547
				O0O0O000000O0OO00 =O00OO000O00O000OO #line:1548
				OOOOO000OO0O0O00O =OO00OOO0O00O0OOOO #line:1549
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O0O0O000000O0OO00 =False #line:1550
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O00OO000O00O000OO ='';OO00OOO0O00O0OOOO =''#line:1551
	if O00OO000O00O000OO =='':#line:1552
		O0O0O0OOOO0OOO000 =[]#line:1553
		OO0O000OO00O00O00 =[]#line:1554
		for OOOOOOOO0OO00OO0O in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:1555
			O000OO0OO0000O00O ="%s/addon.xml"%OOOOOOOO0OO00OO0O #line:1556
			if os .path .exists (O000OO0OO0000O00O ):#line:1557
				OO00O0OO0O0O0OOO0 =open (O000OO0OO0000O00O ,mode ='r');OOO0O0OOOOO0OOOO0 =OO00O0OO0O0O0OOO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','');OO00O0OO0O0O0OOO0 .close ();#line:1558
				OOO0000O0OOOO0OOO =wiz .parseDOM (OOO0O0OOOOO0OOOO0 ,'addon',ret ='id')#line:1559
				OOO00000OOO0OOOO0 =wiz .parseDOM (OOO0O0OOOOO0OOOO0 ,'addon',ret ='name')#line:1560
				wiz .log ("%s: %s"%(OOOOOOOO0OO00OO0O ,str (OOO0000O0OOOO0OOO [0 ])),xbmc .LOGNOTICE )#line:1561
				if len (OOO0000O0OOOO0OOO )>0 :OO0O000OO00O00O00 .append (str (OOO0000O0OOOO0OOO [0 ]));O0O0O0OOOO0OOO000 .append (str (OOO00000OOO0OOOO0 [0 ]))#line:1562
				else :wiz .log ("ID not found for %s"%OOOOOOOO0OO00OO0O ,xbmc .LOGNOTICE )#line:1563
			else :wiz .log ("ID not found for %s"%OOOOOOOO0OO00OO0O ,xbmc .LOGNOTICE )#line:1564
		if len (OO0O000OO00O00O00 )>0 :#line:1565
			if len (OO0O000OO00O00O00 )>1 :#line:1566
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:1567
					O00O00OO0O0O0O00O =DIALOG .select ("Select skin to switch to!",O0O0O0OOOO0OOO000 )#line:1568
					if O00O00OO0O0O0O00O ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1569
					else :#line:1570
						O0O0O000000O0OO00 =OO0O000OO00O00O00 [O00O00OO0O0O0O00O ]#line:1571
						OOOOO000OO0O0O00O =O0O0O0OOOO0OOO000 [O00O00OO0O0O0O00O ]#line:1572
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1573
	if O0O0O000000O0OO00 :#line:1580
		skinSwitch .swapSkins (O0O0O000000O0OO00 )#line:1581
		OOO000O0O0OO00O00 =0 #line:1582
		xbmc .sleep (1000 )#line:1583
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO000O0O0OO00O00 <150 :#line:1584
			OOO000O0O0OO00O00 +=1 #line:1585
			xbmc .sleep (200 )#line:1586
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1588
			wiz .ebi ('SendClick(11)')#line:1589
			wiz .lookandFeelData ('restore')#line:1590
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1591
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1592
while xbmc .Player ().isPlayingVideo ():#line:1594
	xbmc .sleep (1000 )#line:1595
if KODIV >=17 :#line:1597
	NOW =datetime .now ()#line:1598
	temp =wiz .getS ('kodi17iscrap')#line:1599
	if not temp =='':#line:1600
		if temp >str (NOW -timedelta (minutes =2 )):#line:1601
			wiz .log ("Killing Start Up Script")#line:1602
			sys .exit ()#line:1603
	wiz .log ("%s"%(NOW ))#line:1604
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1605
	xbmc .sleep (1000 )#line:1606
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1607
		wiz .log ("Killing Start Up Script")#line:1608
		sys .exit ()#line:1609
	else :#line:1610
		wiz .log ("Continuing Start Up Script")#line:1611
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1613
path =os .path .split (ADDONPATH )#line:1614
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1615
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1616
if KODIADDONS in ADDONPATH :#line:1619
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1620
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1621
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1622
	if os .path .exists (newpath ):#line:1623
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1624
		wiz .cleanHouse (newpath )#line:1625
		wiz .removeFolder (newpath )#line:1626
	try :#line:1627
		wiz .copytree (ADDONPATH ,newpath )#line:1628
	except Exception as e :#line:1629
		pass #line:1630
	wiz .forceUpdate (True )#line:1631
try :#line:1633
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1634
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1635
except :#line:1636
	pass #line:1637
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1639
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1643
			wiz .kodi17Fix ()#line:1644
			fix18update ()#line:1645
			fix17update ()#line:1646
if INSTALLED =='true':#line:1649
    input =(ADDON .getSetting ("auto_rd"))#line:1650
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1652
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1653
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1654
    wiz .clearS ('install')#line:1655
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1740
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1742
	STARTP2 ()#line:1744
	if not NOTIFY =='true':#line:1745
		url =wiz .workingURL (NOTIFICATION )#line:1746
		if url ==True :#line:1747
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1748
			if not id ==False :#line:1749
				try :#line:1750
					id =int (id );NOTEID =int (NOTEID )#line:1751
					if id ==NOTEID :#line:1752
						if NOTEDISMISS =='false':#line:1753
							debridit .debridIt ('update','all')#line:1754
							traktit .traktIt ('update','all')#line:1755
							checkidupdate ()#line:1756
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1757
					elif id >NOTEID :#line:1758
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1759
						wiz .setS ('noteid',str (id ))#line:1760
						wiz .setS ('notedismiss','false')#line:1761
						debridit .debridIt ('update','all')#line:1763
						traktit .traktIt ('update','all')#line:1764
						checkidupdate ()#line:1765
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1767
				except Exception as e :#line:1768
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1769
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1770
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1771
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1772
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1773
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1775
if ENABLE =='No':#line:1776
	if not NOTIFY2 =='true':#line:1777
		url =wiz .workingURL (NOTIFICATION2 )#line:1778
		if url ==True :#line:1779
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1780
			if not id ==False :#line:1781
				try :#line:1782
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1783
					if id ==NOTEID2 :#line:1784
						if NOTEDISMISS2 =='false':#line:1785
							checkvictory ()#line:1786
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1787
					elif id >NOTEID2 :#line:1788
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1789
						wiz .setS ('noteid2',str (id ))#line:1790
						wiz .setS ('notedismiss2','false')#line:1791
						checkvictory ()#line:1792
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1793
				except Exception as e :#line:1794
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1795
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1796
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1797
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1798
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1799
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1801
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1802
	if not NOTIFY3 =='true':#line:1803
		url =wiz .workingURL (NOTIFICATION3 )#line:1804
		if url ==True :#line:1805
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1806
			if not id ==False :#line:1807
				try :#line:1808
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1809
					if id ==NOTEID3 :#line:1810
						if NOTEDISMISS3 =='false':#line:1811
							notify .notification3 (msg )#line:1812
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1813
					elif id >NOTEID3 :#line:1814
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1815
						wiz .setS ('noteid3',str (id ))#line:1816
						wiz .setS ('notedismiss3','false')#line:1817
						notify .notification3 (msg =msg )#line:1818
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1819
				except Exception as e :#line:1820
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1821
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1822
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1823
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1824
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1825
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1826
if KEEPTRAKT =='true':#line:1827
	if TRAKTSAVE <=str (TODAY ):#line:1828
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1829
		traktit .autoUpdate ('all')#line:1830
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1831
	else :#line:1832
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1833
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1834
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1836
if KEEPREAL =='true':#line:1837
	if REALSAVE <=str (TODAY ):#line:1838
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1839
		debridit .autoUpdate ('all')#line:1840
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1841
	else :#line:1842
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1843
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1844
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1846
if KEEPLOGIN =='true':#line:1847
	if LOGINSAVE <=str (TODAY ):#line:1848
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1849
		loginit .autoUpdate ('all')#line:1850
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1851
	else :#line:1852
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1853
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1854
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1856
if AUTOCLEANUP =='true':#line:1857
	service =False #line:1858
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1859
	feq =int (float (AUTOFEQ ))#line:1860
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1861
		service =True #line:1862
		next_run =days [feq ]#line:1863
		wiz .setS ('nextautocleanup',str (next_run ))#line:1864
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1865
	if service ==True :#line:1866
		AUTOCACHE =wiz .getS ('clearcache')#line:1867
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1868
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1869
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1870
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1871
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1872
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1873
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1874
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1875
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1876
wiz .setS ('kodi17iscrap','')#line:1878
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1947
	count =0 #line:1948
	for f in filenames :#line:1949
		count +=1 #line:1950
		fp =os .path .join (dirpath ,f )#line:1951
		total_size +=os .path .getsize (fp )#line:1952
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1953
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1960
	for f2 in filenames2 :#line:1961
		fp2 =os .path .join (dirpath2 ,f2 )#line:1962
		total_size2 +=os .path .getsize (fp2 )#line:1963
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1964
if int (total_sizetext2 )>filesize_thumb :#line:1966
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1967
	if choice2 ==1 :#line:1968
		maintenance .deleteThumbnails ()#line:1969
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1971
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1972
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1974
time .sleep (3 )#line:1975
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:1977
        display_Votes ()#line:1978
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:1980
        file .write (str ('Done'))#line:1982
        file .close ()#line:1983
tele =(ADDON .getSetting ("auto_tele"))#line:1988
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:1990
    if tele =='true':#line:1992
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:1993
