# coding: utf-8

import xbmc, xbmcaddon, xbmcgui, os,xbmcvfs,uservar,time
from resources.libs import wizard as wiz
translatepath=xbmcvfs.translatePath
ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = wiz.addonId(ADDON_ID)
VERSION        = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH      = wiz.addonInfo(ADDON_ID,'path')
ADDONID        = wiz.addonInfo(ADDON_ID,'id')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = translatepath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
SKIN           = xbmc.getSkinDir()
BUILDNAME      = wiz.getS('buildname')
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
thumbnails    =  translatepath('special://home/userdata/Thumbnails')
setting = xbmcaddon.Addon().getSetting
filesize_thumb = int(setting('filesizethumb_alert'))
total_size2 = 0

def backtokodi():
    import shutil
    from shutil import copyfile
    choice = DIALOG.yesno(ADDONTITLE, "נראה שהייתה תקלה , האם לחזור לבילד", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    from resources.default import fix_gui,resetkodi
    if choice == 1:
            src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"20","guisettings.xml")
            dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
            copyfile(src,dst)
            xbmc.sleep(200)
            fix_gui()
            resetkodi()
            
if SKIN in ['skin.confluence', 'skin.estuary', 'skin.estouchy'] and not BUILDNAME == "":
      backtokodi()
if not os.path.exists(os.path.join(ADDONDATA, '4.5.0')):   
    try:
        file = open(os.path.join(ADDONDATA, '4.5.0'), 'w') 
         
        file.write(str('Done'))
        file.close()
    except:pass
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.Anonymous?mode=startup&url=www)')
if BUILDNAME == "" and not os.path.exists(translatepath("special://home/addons/") + 'skin.Premium.mod') or BUILDNAME == "" and not os.path.exists(translatepath("special://home/addons/") + 'skin.anonymoustv'):
    wiz.wizardUpdateDP('startup')

try:
    if not os.path.exists(translatepath("special://home/addons/") + 'skin.estuary'):
            from resources.libs import extract
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
            setting_file=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")
            src=os.path.join(translatepath("special://home/"),"addons/skin.estuary")
            extract.all(setting_file,src)
            xbmc.executebuiltin('UpdateLocalAddons()')
            xbmc.executebuiltin( "ActivateWindow(home)" )
            # f_play=(os.path.join(ADDONPATH, 'resources', 'netflix.mp4'))
            # xbmc.Player().play(f_play,windowed=False)
            xbmc.executebuiltin("ReloadSkin()")
except:pass

def every(delay, task):
  next_time = time.time() + delay
  while True:
    time.sleep(max(0, next_time - time.time()))
    try:
      task()
    except Exception:
      pass
    next_time += (time.time() - next_time) // delay * delay + delay

def check_update():
    refreshCommand = 'RunPlugin(plugin://plugin.program.Anonymous/?mode=update_tele)'
    xbmc.executebuiltin(refreshCommand)

if os.path.exists(translatepath("special://home/addons/") + 'skin.Premium.mod') or os.path.exists(translatepath("special://home/addons/") + 'skin.anonymoustv'):
    import threading
    #7200 שעתיים
    threading.Thread(target=lambda: every(7200, check_update)).start()
    refreshCommand = 'RunPlugin(plugin://plugin.program.Anonymous/?mode=update_tele)'
    xbmc.executebuiltin(refreshCommand)

for dirpath2, dirnames2, filenames2 in os.walk(thumbnails):
	for f2 in filenames2:
		fp2 = os.path.join(dirpath2, f2)
		total_size2 += os.path.getsize(fp2)
total_sizetext2 = "%.0f" % (total_size2/1024000.0)

if int(total_sizetext2) > filesize_thumb:
		from resources.libs import maintenance
		maintenance.deleteThumbnails()

if BUILDNAME == " Kodi Premium":
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]System Is Started[/COLOR]' % COLOR2)