# -*- coding: utf-8 -*-
################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import zipfile, xbmcaddon, xbmc, uservar, sys, os, time,logging, xbmcvfs
import sys
try:
 import wizard as wiz
except:
 from resources.libs import wizard as wiz



import zipfile

import xbmcvfs
xbmc_tranlate_path=xbmcvfs.translatePath
ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
ADDON          = wiz.addonId(ADDON_ID)
HOME           = xbmc_tranlate_path('special://home/')
USERDATA       = os.path.join(HOME,      'userdata')
GUISETTINGS    = os.path.join(USERDATA,  'guisettings.xml')
KEEPMOVIEWALL    = wiz.getS('keepmoviewall')
KEEPMOVIELIST    = wiz.getS('keepmovielist')
KEEPINFO         = wiz.getS('keepinfo')
KEEPSOUND        = wiz.getS('keepsound')
KEEPTORNET       = wiz.getS('keeptornet')
KEEPREAL         = wiz.getS('keepdebrid')
KEEPVIEW         = wiz.getS('keepview')
KEEPPLAYLIST     = wiz.getS('keepplaylist')
KEEPRD2          = wiz.getS('keeprd2')
KEEPSKIN         = wiz.getS('keepskin')
KEEPTVLIST       = wiz.getS('keeptvlist')
KEEPHUBMOVIE       = wiz.getS('keephubmovie')
KEEPHUBTVSHOW       = wiz.getS('keephubtvshow')
KEEPHUBTV       = wiz.getS('keephubtv')
KEEPHUBVOD       = wiz.getS('keephubvod')
KEEPHUBKIDS       = wiz.getS('keephubkids')
KEEPHUBMUSIC       = wiz.getS('keephubmusic')
KEEPHUBMENU       = wiz.getS('keephubmenu')
KEEPSKIN2        = wiz.getS('keepskin2')
KEEPSKIN3        = wiz.getS('keepskin3')
KEEPPVR          = wiz.getS('keeppvr')
KEEPFAVS       = wiz.getS('keepfavourites')
KEEPSOURCES    = wiz.getS('keepsources')
KEEPPROFILES   = wiz.getS('keepprofiles')
KEEPADVANCED   = wiz.getS('keepadvanced')
KEEPSUPER      = wiz.getS('keepsuper')
KEEPREPOS      = wiz.getS('keeprepos')
KEEPWHITELIST  = wiz.getS('keepwhitelist')
KEEPWEATHER    = wiz.getS('keepweather')
KEEPHUBSPORT   = wiz.getS('keephubsport')
KEEPVICTORY    = wiz.getS('keepvictory')
KEEPTELEMEDIA   = wiz.getS('keeptelemedia')

LOGFILES       = ['xbmc.log', 'xbmc.old.log', 'kodi.log', 'kodi.old.log', 'spmc.log', 'spmc.old.log', 'tvmc.log', 'tvmc.old.log', 'Thumbs.db', '.gitignore', '.DS_Store']
bad_files      = ['onechannelcache.db', 'saltscache.db', 'saltscache.db-shm', 'saltscache.db-wal', 'saltshd.lite.db', 'saltshd.lite.db-shm', 'saltshd.lite.db-wal', 'queue.db', 'commoncache.db', 'access.log', 'trakt.db', 'video_cache.db']

def all(_in, _out, dp=None, ignore=None, title=None,keep_userdata=False):
	if dp: return allWithProgress(_in, _out, dp, ignore, title,keep_userdata)
	else: return allNoProgress(_in, _out, ignore)
def all2(_in, _out, dp2=None, ignore=None, title=None,keep_userdata=False):
	if dp2: return allWithProgress2(_in, _out, dp2, ignore, title,keep_userdata)
def all3(_in, _out, dp2=None, ignore=None, title=None,keep_userdata=False):
	allWithProgress3(_in, _out,  ignore, title,keep_userdata)

def allNoProgress(_in, _out, ignore):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception as e:
		print (e)
		return False
	return True

def allWithProgress(_in, _out, dp, ignore, title,keep_userdata):
    try:
        reload(sys)
        sys.setdefaultencoding("utf-8")
    except:pass
    count = 0; errors = 0; error = ''; update = 0; size = 0; excludes = []
    try:
        zin = zipfile.ZipFile(_in,  'r')
    except Exception as e:
        errors += 1; error += '%s\n' % e
        wiz.log('Error Checking Zip: %s' % str(e), 5)
        return update, errors, error
    
    whitelist = wiz.whiteList('read')
    for item in whitelist:
        try: name, id, fold = item
        except: pass
        excludes.append(fold)
        if fold.startswith('pvr'):
            wiz.setS('pvrclient', id)
    
    nFiles = float(len(zin.namelist()))
    zipsize = wiz.convertSize(sum([item.file_size for item in zin.infolist()]))

    zipit = str(_in).replace('\\', '/').split('/')
    title = title if not title == None else zipit[-1].replace('.zip', '')
    dragon=wiz.getS("dragon")
    for item in zin.infolist():
        count += 1; prog = int(count / nFiles * 100); size += item.file_size
        logging.warning(item.filename)
        file = (item.filename).split('/')
        skip = False
        line1  = '%s [COLOR %s][B]:מחלץ קבצים[/B][/COLOR]' % (title, COLOR2)
        line2  = '[COLOR %s][B]File:[/B][/COLOR] [COLOR %s]%s/%s[/COLOR] ' % (COLOR2, COLOR1, count, int(nFiles))
        line2 += '[COLOR %s][B]Size:[/B][/COLOR] [COLOR %s]%s/%s[/COLOR]' % (COLOR2, COLOR1, wiz.convertSize(size), zipsize)
        line3  = '[COLOR %s]%s[/COLOR]' % (COLOR1, item.filename)
        
        # if 'script.skinshortcuts' in item.filename:
          # try:
             # try:
                # os.remove(os.path.join(xbmcvfs.translatePath("special://home/addons/skin.Premium.mod/16x9"),"script-skinshortcuts-includes.xml"))
             # except:pass
          # except:
             # try:
                # os.remove(os.path.join(xbmc.translatePath("special://home/addons/skin.Premium.mod/16x9"),"script-skinshortcuts-includes.xml"))
             # except:pass

        if item.filename == 'userdata/sources.xml' and KEEPSOURCES == 'true': skip = True
        elif 'plugin.video.dreamspeed' in item.filename and dragon=='false': skip = True
        elif 'script.skinshortcuts' in item.filename and 'userdata' in item.filename and KEEPSKIN =='true':skip=True
        elif item.filename == 'userdata/Database/MyVideos99.db' and KEEPMOVIEWALL =='false':skip=True
        elif item.filename == 'userdata/Database/MyVideos107.db' and KEEPMOVIEWALL =='false':skip=True
        elif item.filename == 'userdata/Database/MyVideos116.db' and KEEPMOVIEWALL =='false':skip=True
        elif item.filename == 'userdata/Database/MyVideos99.db' and KEEPMOVIELIST =='true':skip=True
        elif item.filename == 'userdata/Database/MyVideos107.db' and KEEPMOVIELIST =='true':skip=True
        elif item.filename == 'userdata/Database/MyVideos116.db' and KEEPMOVIELIST =='true':skip=True
        
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/quicknav.DATA.xml' and KEEPTVLIST =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1101.DATA.xml' and KEEPHUBMOVIE =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-srtym-b.DATA.xml' and KEEPHUBMOVIE =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1102.DATA.xml' and KEEPHUBTVSHOW =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-sdrvt-b.DATA.xml' and KEEPHUBTVSHOW =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1112.DATA.xml' and KEEPHUBTV =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-tlvvyzyh-b.DATA.xml' and KEEPHUBTV =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1111.DATA.xml' and KEEPHUBVOD =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-tvknyshrly-b.DATA.xml' and KEEPHUBVOD =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/mainmenu.DATA.xml' and KEEPHUBMENU =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/skin.Premium.mod.properties' and KEEPHUBKIDS =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1110.DATA.xml' and KEEPHUBMENU =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-yldym-b.DATA.xml' and KEEPHUBKIDS =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1114.DATA.xml' and KEEPHUBMUSIC =='true':skip=True
        
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1122.DATA.xml' and KEEPHUBSPORT =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-spvrt-b.DATA.xml' and KEEPHUBSPORT =='true':skip=True
        
        elif item.filename == 'userdata/addon_data/myfav.anon/cache_play.db' and KEEPFAVS =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-mvzyqh-b.DATA.xml' and KEEPHUBMUSIC =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.anonymous.mod' and KEEPVIEW =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.anonymous.nox' and KEEPVIEW =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.Premium.mod' and KEEPVIEW =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.phenomenal' and KEEPVIEW =='true':skip=True
        elif 'pvr.iptvsimple' in item.filename and 'userdata' in item.filename and KEEPPVR =='true':skip=True
        elif file[0] == 'userdata' and keep_userdata==True:skip=True
        elif file[1] == 'plugin.video.anonymous.wall' and KEEPMOVIEWALL =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.anonymous.wall' and KEEPMOVIEWALL =='false':skip=True
        elif file[1] == 'skin.eminence.2.mod.Krypton' and KEEPSKIN2 =='false':skip=True	
        elif file[1] == 'skin.eminence.2.mod' and KEEPSKIN2 =='false':skip=True	
        elif file[1] == 'skin.titan' and KEEPSKIN3 =='false':skip=True
        #elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.phenomenal' and KEEPSKIN2 =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.eminence.2.mod.Krypton' and KEEPSKIN2 =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.eminence.2.mod' and KEEPSKIN2 =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.titan' and KEEPSKIN3 =='false':skip=True
        elif item.filename == 'userdata/favourites.xml' and KEEPFAVS == 'true': skip = True
        elif item.filename == 'userdata/guisettings.xml' and KEEPSOUND == 'true': skip = True
        elif item.filename == 'userdata/profiles.xml' and KEEPPROFILES == 'true': skip = True
        elif item.filename == 'userdata/advancedsettings.xml' and KEEPADVANCED == 'true': skip = True
        elif file[0] == 'addons' and file[1] in excludes: skip = True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] in excludes: skip = True
        elif file[-1] in LOGFILES: skip = True
        elif file[-1] in bad_files: skip = True
        elif file[-1].endswith('.csv'): skip = True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.sdarot.tv' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'program.apollo' and KEEPINFO =='true':skip=True
        
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.elementum' and KEEPINFO =='true':skip=True
        #elif item.filename == 'userdata/addon_data/plugin.video.gaia/settings.xml' and KEEPRD2 =='true':skip=True
        #elif item.filename == 'userdata/addon_data/plugin.video.seren/settings.xml' and KEEPRD2 =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.allmoviesin' and KEEPVICTORY =='true':skip=True
        # elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.telemedia' and KEEPTELEMEDIA =='true':skip=True
        # elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'service.subtitles.All_Subs' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.audio.soundcloud' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.kodipopcorntime' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.quasar' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.playlistLoader' and KEEPPLAYLIST =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'script.module.resolveurl' and KEEPREAL =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'weather.yahoo' and KEEPWEATHER =='true':skip=True
        elif not (item.filename).find('plugin.program.super.favourites') == -1 and KEEPSUPER == 'true': skip = True

        elif not (item.filename).find(ADDON_ID)                          == -1 and ignore == None: skip = True
        if skip == True: wiz.log("Skipping: %s" % item.filename, 5)
        else:
            try:
                zin.extract(item, _out)
            except Exception as e:
                errormsg  = "[COLOR %s]File:[/COLOR] [COLOR %s]%s[/COLOR]\n" % (COLOR2, COLOR1, file[-1])
                errormsg += "[COLOR %s]Folder:[/COLOR] [COLOR %s]%s[/COLOR]\n" % (COLOR2, COLOR1, (item.filename).replace(file[-1],''))
                errormsg += "[COLOR %s]Error:[/COLOR] [COLOR %s]%s[/COLOR]\n\n" % (COLOR2, COLOR1, str(e).replace('\\\\','\\').replace("'%s'" % item.filename, ''))
                errormsg += ('Error on line {}'.format(sys.exc_info()[-1].tb_lineno))
                errors += 1; error += errormsg
                wiz.log('Error Extracting: %s(%s)' % (item.filename, str(e)), 5)
                pass
        try:
            dp.update(prog, line1,line2,line3)
        except:
            dp.update(prog, line1+'\n'+ line2+'\n'+ line3)
        #dp.update(prog, line1, line2, line3)
        if dp.iscanceled(): break
    if dp.iscanceled(): 
        dp.close()
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Extract Cancelled[/COLOR]" % COLOR2)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        sys.exit()
    return prog, errors, error
def allWithProgress2(_in, _out, dp2, ignore, title,keep_userdata):
    try:
        reload(sys)
        sys.setdefaultencoding("utf-8")
    except:pass
    count = 0; errors = 0; error = ''; update = 0; size = 0; excludes = []
    try:
        zin = zipfile.ZipFile(_in,  'r')
    except Exception as e:
        errors += 1; error += '%s\n' % e
        wiz.log('Error Checking Zip: %s' % str(e), 5)
        return update, errors, error
    
    whitelist = wiz.whiteList('read')
    for item in whitelist:
        try: name, id, fold = item
        except: pass
        excludes.append(fold)
        if fold.startswith('pvr'):
            wiz.setS('pvrclient', id)
    
    nFiles = float(len(zin.namelist()))
    zipsize = wiz.convertSize(sum([item.file_size for item in zin.infolist()]))

    zipit = str(_in).replace('\\', '/').split('/')
    title = title if not title == None else zipit[-1].replace('.zip', '')
    dragon=wiz.getS("dragon")
    for item in zin.infolist():
        count += 1; prog = int(count / nFiles * 100); size += item.file_size
        logging.warning(item.filename)
        file = (item.filename).split('/')
        skip = False
        #line1  = '%s [Errors:%s]' % (title, errors)
        line2  = 'File:%s/%s' % (count, int(nFiles))
        # line2 += '%s/%s' % (wiz.convertSize(size), zipsize)
        line3  = '%s' % (item.filename)
        # if 'script.skinshortcuts' in item.filename:
          # try:
             # try:
                # os.remove(os.path.join(xbmcvfs.translatePath("special://home/addons/skin.Premium.mod/16x9"),"script-skinshortcuts-includes.xml"))
             # except:pass
          # except:
             # try:
                # os.remove(os.path.join(xbmc.translatePath("special://home/addons/skin.Premium.mod/16x9"),"script-skinshortcuts-includes.xml"))
             # except:pass
        
        if item.filename == 'userdata/sources.xml' and KEEPSOURCES == 'true': skip = True
        elif 'plugin.video.dreamspeed' in item.filename and dragon=='false': skip = True
        elif 'script.skinshortcuts' in item.filename and 'userdata' in item.filename and KEEPSKIN =='true':skip=True
        elif item.filename == 'userdata/Database/MyVideos99.db' and KEEPMOVIEWALL =='false':skip=True
        elif item.filename == 'userdata/Database/MyVideos107.db' and KEEPMOVIEWALL =='false':skip=True
        elif item.filename == 'userdata/Database/MyVideos116.db' and KEEPMOVIEWALL =='false':skip=True
        elif item.filename == 'userdata/Database/MyVideos99.db' and KEEPMOVIELIST =='true':skip=True
        elif item.filename == 'userdata/Database/MyVideos107.db' and KEEPMOVIELIST =='true':skip=True
        elif item.filename == 'userdata/Database/MyVideos116.db' and KEEPMOVIELIST =='true':skip=True
        
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/quicknav.DATA.xml' and KEEPTVLIST =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1101.DATA.xml' and KEEPHUBMOVIE =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-srtym-b.DATA.xml' and KEEPHUBMOVIE =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1102.DATA.xml' and KEEPHUBTVSHOW =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-sdrvt-b.DATA.xml' and KEEPHUBTVSHOW =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1112.DATA.xml' and KEEPHUBTV =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-tlvvyzyh-b.DATA.xml' and KEEPHUBTV =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1111.DATA.xml' and KEEPHUBVOD =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-tvknyshrly-b.DATA.xml' and KEEPHUBVOD =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/mainmenu.DATA.xml' and KEEPHUBMENU =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/skin.Premium.mod.properties' and KEEPHUBKIDS =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1110.DATA.xml' and KEEPHUBMENU =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-yldym-b.DATA.xml' and KEEPHUBKIDS =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1114.DATA.xml' and KEEPHUBMUSIC =='true':skip=True
        elif item.filename == 'userdata/addon_data/myfav.anon/cache_play.db' and KEEPFAVS =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-mvzyqh-b.DATA.xml' and KEEPHUBMUSIC =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.anonymous.mod' and KEEPVIEW =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.anonymous.nox' and KEEPVIEW =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.Premium.mod' and KEEPVIEW =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.phenomenal' and KEEPVIEW =='true':skip=True
        elif 'pvr.iptvsimple' in item.filename and 'userdata' in item.filename and KEEPPVR =='true':skip=True
        elif file[0] == 'userdata' and keep_userdata==True:skip=True
        elif file[1] == 'plugin.video.anonymous.wall' and KEEPMOVIEWALL =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.anonymous.wall' and KEEPMOVIEWALL =='false':skip=True
        elif file[1] == 'skin.eminence.2.mod.Krypton' and KEEPSKIN2 =='false':skip=True	
        elif file[1] == 'skin.eminence.2.mod' and KEEPSKIN2 =='false':skip=True	
        elif file[1] == 'skin.titan' and KEEPSKIN3 =='false':skip=True
        #elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.phenomenal' and KEEPSKIN2 =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.eminence.2.mod.Krypton' and KEEPSKIN2 =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.eminence.2.mod' and KEEPSKIN2 =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.titan' and KEEPSKIN3 =='false':skip=True
        elif item.filename == 'userdata/favourites.xml' and KEEPFAVS == 'true': skip = True
        elif item.filename == 'userdata/guisettings.xml' and KEEPSOUND == 'true': skip = True
        elif item.filename == 'userdata/profiles.xml' and KEEPPROFILES == 'true': skip = True
        elif item.filename == 'userdata/advancedsettings.xml' and KEEPADVANCED == 'true': skip = True
        elif file[0] == 'addons' and file[1] in excludes: skip = True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] in excludes: skip = True
        elif file[-1] in LOGFILES: skip = True
        elif file[-1] in bad_files: skip = True
        elif file[-1].endswith('.csv'): skip = True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.sdarot.tv' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'program.apollo' and KEEPINFO =='true':skip=True
        
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.elementum' and KEEPINFO =='true':skip=True
        #elif item.filename == 'userdata/addon_data/plugin.video.gaia/settings.xml' and KEEPRD2 =='true':skip=True
        #elif item.filename == 'userdata/addon_data/plugin.video.seren/settings.xml' and KEEPRD2 =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.allmoviesin' and KEEPVICTORY =='true':skip=True
        # elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.telemedia' and KEEPTELEMEDIA =='true':skip=True
        # elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'service.subtitles.All_Subs' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.audio.soundcloud' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.kodipopcorntime' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.quasar' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.playlistLoader' and KEEPPLAYLIST =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'script.module.resolveurl' and KEEPREAL =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'weather.yahoo' and KEEPWEATHER =='true':skip=True
        elif not (item.filename).find('plugin.program.super.favourites') == -1 and KEEPSUPER == 'true': skip = True

        elif not (item.filename).find(ADDON_ID)                          == -1 and ignore == None: skip = True
        if skip == True: wiz.log("Skipping: %s" % item.filename, 5)
        else:
            try:
                zin.extract(item, _out)
            except Exception as e:
                errormsg  = "[COLOR %s]File:[/COLOR] [COLOR %s]%s[/COLOR]\n" % (COLOR2, COLOR1, file[-1])
                errormsg += "[COLOR %s]Folder:[/COLOR] [COLOR %s]%s[/COLOR]\n" % (COLOR2, COLOR1, (item.filename).replace(file[-1],''))
                errormsg += "[COLOR %s]Error:[/COLOR] [COLOR %s]%s[/COLOR]\n\n" % (COLOR2, COLOR1, str(e).replace('\\\\','\\').replace("'%s'" % item.filename, ''))
                errormsg += ('Error on line {}'.format(sys.exc_info()[-1].tb_lineno))
                errors += 1; error += errormsg
                wiz.log('Error Extracting: %s(%s)' % (item.filename, str(e)), 5)
                pass
        # עדכון ברקע
        dp2.update(prog, line3, line2)
        # עדכון ברקע
        
        # if dp2.iscanceled(): break
    # if dp2.iscanceled(): 
        # dp2.close()
        # wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Extract Cancelled[/COLOR]" % COLOR2)
        # sys.exit()
    return prog, errors, error
def allWithProgress3(_in, _out, ignore, title,keep_userdata):
    try:
        reload(sys)
        sys.setdefaultencoding("utf-8")
    except:pass
    count = 0; errors = 0; error = ''; update = 0; size = 0; excludes = []
    try:
        zin = zipfile.ZipFile(_in,  'r')
    except Exception as e:
        errors += 1; error += '%s\n' % e
        wiz.log('Error Checking Zip: %s' % str(e), 5)
        return update, errors, error
    
    whitelist = wiz.whiteList('read')
    for item in whitelist:
        try: name, id, fold = item
        except: pass
        excludes.append(fold)
        if fold.startswith('pvr'):
            wiz.setS('pvrclient', id)
    
    nFiles = float(len(zin.namelist()))
    zipsize = wiz.convertSize(sum([item.file_size for item in zin.infolist()]))

    zipit = str(_in).replace('\\', '/').split('/')
    title = title if not title == None else zipit[-1].replace('.zip', '')
    dragon=wiz.getS("dragon")
    for item in zin.infolist():
        count += 1; prog = int(count / nFiles * 100); size += item.file_size
        logging.warning(item.filename)
        file = (item.filename).split('/')
        skip = False
        #line1  = '%s [Errors:%s]' % (title, errors)
        line2  = 'File:%s/%s' % (count, int(nFiles))
        # line2 += '%s/%s' % (wiz.convertSize(size), zipsize)
        line3  = '%s' % (item.filename)
        # if 'script.skinshortcuts' in item.filename:
          # try:
             # try:
                # os.remove(os.path.join(xbmcvfs.translatePath("special://home/addons/skin.Premium.mod/16x9"),"script-skinshortcuts-includes.xml"))
             # except:pass
          # except:
             # try:
                # os.remove(os.path.join(xbmc.translatePath("special://home/addons/skin.Premium.mod/16x9"),"script-skinshortcuts-includes.xml"))
             # except:pass
        if item.filename == 'userdata/sources.xml' and KEEPSOURCES == 'true': skip = True
        elif 'plugin.video.dreamspeed' in item.filename and dragon=='false': skip = True
        elif 'script.skinshortcuts' in item.filename and 'userdata' in item.filename and KEEPSKIN =='true':skip=True
        elif item.filename == 'userdata/Database/MyVideos99.db' and KEEPMOVIEWALL =='false':skip=True
        elif item.filename == 'userdata/Database/MyVideos107.db' and KEEPMOVIEWALL =='false':skip=True
        elif item.filename == 'userdata/Database/MyVideos116.db' and KEEPMOVIEWALL =='false':skip=True
        elif item.filename == 'userdata/Database/MyVideos99.db' and KEEPMOVIELIST =='true':skip=True
        elif item.filename == 'userdata/Database/MyVideos107.db' and KEEPMOVIELIST =='true':skip=True
        elif item.filename == 'userdata/Database/MyVideos116.db' and KEEPMOVIELIST =='true':skip=True
        
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/quicknav.DATA.xml' and KEEPTVLIST =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1101.DATA.xml' and KEEPHUBMOVIE =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-srtym-b.DATA.xml' and KEEPHUBMOVIE =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1102.DATA.xml' and KEEPHUBTVSHOW =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-sdrvt-b.DATA.xml' and KEEPHUBTVSHOW =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1112.DATA.xml' and KEEPHUBTV =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-tlvvyzyh-b.DATA.xml' and KEEPHUBTV =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1111.DATA.xml' and KEEPHUBVOD =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-tvknyshrly-b.DATA.xml' and KEEPHUBVOD =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/mainmenu.DATA.xml' and KEEPHUBMENU =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/skin.Premium.mod.properties' and KEEPHUBKIDS =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1110.DATA.xml' and KEEPHUBMENU =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-yldym-b.DATA.xml' and KEEPHUBKIDS =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/x1114.DATA.xml' and KEEPHUBMUSIC =='true':skip=True
        elif item.filename == 'userdata/addon_data/myfav.anon/cache_play.db' and KEEPFAVS =='true':skip=True
        elif item.filename == 'userdata/addon_data/script.skinshortcuts/b-mvzyqh-b.DATA.xml' and KEEPHUBMUSIC =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.anonymous.mod' and KEEPVIEW =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.anonymous.nox' and KEEPVIEW =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.Premium.mod' and KEEPVIEW =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.phenomenal' and KEEPVIEW =='true':skip=True
        elif 'pvr.iptvsimple' in item.filename and 'userdata' in item.filename and KEEPPVR =='true':skip=True
        elif file[0] == 'userdata' and keep_userdata==True:skip=True
        elif file[1] == 'plugin.video.anonymous.wall' and KEEPMOVIEWALL =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.anonymous.wall' and KEEPMOVIEWALL =='false':skip=True
        elif file[1] == 'skin.eminence.2.mod.Krypton' and KEEPSKIN2 =='false':skip=True	
        elif file[1] == 'skin.eminence.2.mod' and KEEPSKIN2 =='false':skip=True	
        elif file[1] == 'skin.titan' and KEEPSKIN3 =='false':skip=True
        #elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.phenomenal' and KEEPSKIN2 =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.eminence.2.mod.Krypton' and KEEPSKIN2 =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.eminence.2.mod' and KEEPSKIN2 =='false':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.titan' and KEEPSKIN3 =='false':skip=True
        elif item.filename == 'userdata/favourites.xml' and KEEPFAVS == 'true': skip = True
        elif item.filename == 'userdata/guisettings.xml' and KEEPSOUND == 'true': skip = True
        elif item.filename == 'userdata/profiles.xml' and KEEPPROFILES == 'true': skip = True
        elif item.filename == 'userdata/advancedsettings.xml' and KEEPADVANCED == 'true': skip = True
        elif file[0] == 'addons' and file[1] in excludes: skip = True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] in excludes: skip = True
        elif file[-1] in LOGFILES: skip = True
        elif file[-1] in bad_files: skip = True
        elif file[-1].endswith('.csv'): skip = True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.sdarot.tv' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'program.apollo' and KEEPINFO =='true':skip=True
        
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.elementum' and KEEPINFO =='true':skip=True
        #elif item.filename == 'userdata/addon_data/plugin.video.gaia/settings.xml' and KEEPRD2 =='true':skip=True
        #elif item.filename == 'userdata/addon_data/plugin.video.seren/settings.xml' and KEEPRD2 =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.allmoviesin' and KEEPVICTORY =='true':skip=True
        # elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.telemedia' and KEEPTELEMEDIA =='true':skip=True
        # elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'service.subtitles.All_Subs' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.audio.soundcloud' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.kodipopcorntime' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.quasar' and KEEPINFO =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.playlistLoader' and KEEPPLAYLIST =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'script.module.resolveurl' and KEEPREAL =='true':skip=True
        elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'weather.yahoo' and KEEPWEATHER =='true':skip=True
        elif not (item.filename).find('plugin.program.super.favourites') == -1 and KEEPSUPER == 'true': skip = True

        elif not (item.filename).find(ADDON_ID)                          == -1 and ignore == None: skip = True
        if skip == True: wiz.log("Skipping: %s" % item.filename, 5)
        else:
            try:
                zin.extract(item, _out)
            except Exception as e:
                errormsg  = "[COLOR %s]File:[/COLOR] [COLOR %s]%s[/COLOR]\n" % (COLOR2, COLOR1, file[-1])
                errormsg += "[COLOR %s]Folder:[/COLOR] [COLOR %s]%s[/COLOR]\n" % (COLOR2, COLOR1, (item.filename).replace(file[-1],''))
                errormsg += "[COLOR %s]Error:[/COLOR] [COLOR %s]%s[/COLOR]\n\n" % (COLOR2, COLOR1, str(e).replace('\\\\','\\').replace("'%s'" % item.filename, ''))
                errormsg += ('Error on line {}'.format(sys.exc_info()[-1].tb_lineno))
                errors += 1; error += errormsg
                wiz.log('Error Extracting: %s(%s)' % (item.filename, str(e)), 5)
                pass
        # עדכון ברקע
        # dp2.update(prog, line3, line2)
        # עדכון ברקע
        
        # if dp2.iscanceled(): break
    # if dp2.iscanceled(): 
        # dp2.close()
        # wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Extract Cancelled[/COLOR]" % COLOR2)
        # sys.exit()
    return prog, errors, error