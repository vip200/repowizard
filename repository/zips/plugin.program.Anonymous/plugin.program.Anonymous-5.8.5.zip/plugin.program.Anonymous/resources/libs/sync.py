
# coding: utf-8
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob,random
import shutil,logging,re
import time
import uservar
import threading
from threading import Thread
try:
 import wizard as wiz
except:
 from resources.libs import wizard as wiz
COLOR1           = uservar.COLOR1
COLOR2           = uservar.COLOR2
THEME1           = uservar.THEME1
THEME2           = uservar.THEME2
ADDON_ID         = uservar.ADDON_ID
ADDONTITLE       = uservar.ADDONTITLE
ADDON            = wiz.addonId(ADDON_ID)


translatepath=xbmcvfs.translatePath


class Thread (threading.Thread):
   def __init__(self, target, *args):
    super().__init__(target=target, args=args)
   def run(self, *args):
      
      self._target(*self._args)
      return 0


def read_firebase(table_name):
    from resources.libs import firebase
    firebase = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%wiz.getS("sync_user"), None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def delete_firebase(table_name,record):
    from resources.libs import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%wiz.getS("firebase"), None)
    result = fb_app.delete(table_name, record)
    return 'OK'
def write_favourite(file_data,table_name):
    from resources.libs import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%wiz.getS("firebase"), None)


    result = fb_app.post(table_name, {'favourite':file_data})
    return 'OK'

def read_skin(table_name):
    from resources.libs import firebase
    firebase = firebase.FirebaseApplication(theme_nox, None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def user_sync():
    sync= (wiz.getS("sync_user"))
    try:
        media_sync=xbmcaddon.Addon('plugin.program.Settingz-Anon')
        media_sync.setSetting('firebase',sync)
        # media_sync.setSetting('sync_mod','true')
    except:pass
    try:
        sync_tele=xbmcaddon.Addon('plugin.video.telemedia')
        sync_tele.setSetting('firebase',sync)
        sync_tele.setSetting('sync_mod','true')
    except:pass
    try:
        sync_mando=xbmcaddon.Addon('plugin.video.mando')
        sync_mando.setSetting('firebase',sync)
        sync_mando.setSetting('sync_mod','true')
    except:pass
    try:
        sync_xtvsh=xbmcaddon.Addon('script.module.xtvsh')
        sync_xtvsh.setSetting('firebase',sync)
        sync_xtvsh.setSetting('sync_mod','true')
    except:pass
    try:
        sync_torrent=xbmcaddon.Addon('plugin.video.thorrent')
        sync_torrent.setSetting('firebase',sync)
        sync_torrent.setSetting('sync_mod','true')
    except:pass
    try:
        sync_myfav=xbmcaddon.Addon('context.myfav')
        sync_myfav.setSetting('firebase',sync)
        sync_myfav.setSetting('sync_mod','true')
    except:pass
def sync_addons():
    if os.path.exists(translatepath("special://home/addons/") + 'plugin.video.telemedia'):
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=207&url=www)")
    if os.path.exists(translatepath("special://home/addons/") + 'plugin.video.mando'):
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.mando?mode=200&url=www)")
    if os.path.exists(translatepath("special://home/addons/") + 'script.module.xtvsh'):
        xbmc.executebuiltin("RunPlugin(plugin://script.module.xtvsh?mode=19&url=www)")
    if os.path.exists(translatepath("special://home/addons/") + 'context.myfav'):
        xbmc.executebuiltin("RunPlugin(plugin://context.myfav?mode=15&url=www)")

def sync_skin():
        setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")
        all_db=read_firebase('skin')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['skin']))
        for file_data in data:

            thread=[]
            thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר הגדרות מעטפת ותצוגה.[/COLOR]' % COLOR2))

            thread[0].start()

            file = open(setting_file, 'w', encoding='utf-8') 
            file.write(file_data)
            file.close()
def sync_guisettings():

        setting_file=os.path.join(translatepath("special://userdata"),"guisettings.xml")
        all_db=read_firebase('guisettings')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['guisettings']))
        for file_data in data:

            thread=[]
            thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר הגדרות סאונד.[/COLOR]' % COLOR2))

            thread[0].start()

            file = open(setting_file, 'w', encoding='utf-8') 
            file.write(file_data)
            file.close()

def sync_rd():
    Settingz = xbmcaddon.Addon('plugin.program.Settingz-Anon')
    ard=wiz.getS("auto_rd")
    if ard=='false':
        
        all_db=read_firebase('rd_save')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['r_user'],items['r_pass']))
        for r_user,r_pass in data:
        
            wiz.setS('auto_rd','true')
            wiz.setS('rd_user',r_user)
            wiz.setS('rd_pass',r_pass)

            Settingz.setSetting('auto_rd','true')
            Settingz.setSetting('rd_user',r_user)
            Settingz.setSetting('rd_pass',r_pass)
            # xbmc.sleep(5000)
            z=wiz.getS("rd_user")

            thread=[]
            thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר חשבון RD[/COLOR]' % COLOR2))

            thread[0].start()
            from resources.libs import real_debrid
            rd = real_debrid.RealDebrid()
            rd.auth()

def sync_trakt():
    Settingz = xbmcaddon.Addon('plugin.program.Settingz-Anon')
    trk=wiz.getS("auto_trk")
    
    if trk=='false':
        all_db=read_firebase('trakt_save')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['r_user'],items['r_pass']))
            
        for r_user,r_pass in data:
            
            wiz.setS('auto_trk','true')
            wiz.setS('trk_user',r_user)
            wiz.setS('trk_pass',r_pass)

            Settingz.setSetting('auto_trk','true')
            Settingz.setSetting('trk_user',r_user)
            Settingz.setSetting('trk_pass',r_pass)
            # xbmc.sleep(5000)
            z=wiz.getS("trk_user")
        if not z == '':

            thread=[]
            thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר חשבון טראקט.[/COLOR]' % COLOR2))

            thread[0].start()
            from resources.libs import trk_aut
def sync_sdarot_tv():
    if os.path.exists(translatepath("special://home/addons/") + 'script.module.xtvsh'):
        xtvsh = xbmcaddon.Addon('script.module.xtvsh')

        all_db=read_firebase('sdarot_tv')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['user'],items['pas']))
        for r_user,r_pass in data:
            # wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר חשבון Sdarot-TV[/COLOR]' % COLOR2)
            thread=[]
            thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר חשבון Sdarot-TV[/COLOR]' % COLOR2))

            thread[0].start()
            xtvsh.setSetting('username',r_user)
            xtvsh.setSetting('Password_sdr',r_pass)

def sync_iptv():
    
    all_db=read_firebase('iptvsimple')
    data=[]
    for itt in all_db:
        items=all_db[itt]
        data.append((items['m3u'],items['epg']))
    for m3u,epg in data:

            setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "pvr.iptvsimple","settings.xml")

            thread=[]
            thread.append(Thread(wiz.LogNotify,"[COLOR %s]%s[/COLOR]" % (COLOR1, 'משחזר את חשבון ה IPTV שלך'),'[COLOR %s]מגדיר כתובת ערוצים...[/COLOR]' % COLOR2))

            thread[0].start()

            file = open(setting_file, 'r', encoding='utf-8') 
            file_data= file.read()
            file.close()
            regex='<setting id="m3uUrl" default="(.+?)/>'
            m=re.compile(regex).findall(file_data)[0]
            file = open(setting_file, 'w', encoding='utf-8') 
            file.write(file_data.replace('<setting id="m3uUrl" default="%s/>'%m,'<setting id="m3uUrl">%s</setting>'%m3u))
            file.close()



            file = open(setting_file, 'r', encoding='utf-8') 
            file_data= file.read()
            file.close()
            regex='<setting id="epgUrl" default="(.+?)/>'
            m=re.compile(regex).findall(file_data)[0]
            file = open(setting_file, 'w', encoding='utf-8') 
            file.write(file_data.replace('<setting id="epgUrl" default="%s/>'%m,'<setting id="epgUrl">%s</setting>'%epg))
            file.close()

def sync_favourite():

        setting_file=os.path.join(translatepath("special://userdata"),"favourites.xml")
        all_db=read_firebase('favourite')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['favourite']))
        for file_data in data:

                file = open(setting_file, 'w', encoding='utf-8') 
                file.write(file_data)
                file.close()

            t1 = Thread(target=check, args=(info,))
            t1.start()
def ff():
    try:
        all_db=read_firebase('table_name')
        user_sync()
        thread=[]
        if wiz.getS("sync_skin")=='true':
            thread.append(Thread(sync_skin))
        if wiz.getS("sync_guisettings")=='true':
            thread.append(Thread(sync_guisettings))
        thread.append(Thread(sync_addons))
        thread.append(Thread(sync_rd))
        thread.append(Thread(sync_sdarot_tv))
        thread.append(Thread(sync_iptv))
        thread.append(Thread(sync_favourite))
        thread.append(Thread(sync_trakt))
        for td in thread:
          td.start()
        num_live=0
        stop_time = time.time() + 90
        while 1:
          wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]בתהליך שחזור מידע...[/COLOR]' % COLOR2)
          if time.time() > stop_time:
             break
          for threads in thread:
            still_alive=0
            num_live=0
            for yy in range(0,len(thread)):
                if not thread[yy].is_alive():
                  num_live=num_live+1
                else:
                  still_alive=1
          if still_alive==0:
                break

    except Exception as e: 
        logging.warning('בעיה בשחזור מידע firebase errrrrrrror'+str(e))
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הסנכרון בוטל - ID שגוי[/COLOR]' % COLOR2)
ff()