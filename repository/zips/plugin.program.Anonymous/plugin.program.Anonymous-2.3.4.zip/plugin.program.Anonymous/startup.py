# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
global teleupdate #line:32
teleupdate =False #line:33
ADDON_ID =uservar .ADDON_ID #line:34
ADDONTITLE =uservar .ADDONTITLE #line:35
ADDON =wiz .addonId (ADDON_ID )#line:36
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:37
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:38
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:39
DIALOG =xbmcgui .Dialog ()#line:40
DP =xbmcgui .DialogProgress ()#line:41
DP2 =xbmcgui .DialogProgressBG ()#line:42
HOME =xbmc .translatePath ('special://home/')#line:43
PROFILE =xbmc .translatePath ('special://profile/')#line:44
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:45
ADDONS =os .path .join (HOME ,'addons')#line:46
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:47
USERDATA =os .path .join (HOME ,'userdata')#line:48
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:49
PACKAGES =os .path .join (ADDONS ,'packages')#line:50
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:51
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:52
ICON =os .path .join (ADDONPATH ,'icon.png')#line:53
ART =os .path .join (ADDONPATH ,'resources','art')#line:54
SKIN =xbmc .getSkinDir ()#line:55
BUILDNAME =wiz .getS ('buildname')#line:56
DEFAULTSKIN =wiz .getS ('defaultskin')#line:57
DEFAULTNAME =wiz .getS ('defaultskinname')#line:58
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:59
BUILDVERSION =wiz .getS ('buildversion')#line:60
BUILDLATEST =wiz .getS ('latestversion')#line:61
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:62
DISABLEUPDATE =wiz .getS ('disableupdate')#line:63
AUTOCLEANUP =wiz .getS ('autoclean')#line:64
AUTOCACHE =wiz .getS ('clearcache')#line:65
AUTOPACKAGES =wiz .getS ('clearpackages')#line:66
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:67
AUTOFEQ =wiz .getS ('autocleanfeq')#line:68
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:69
TRAKTSAVE =wiz .getS ('traktlastsave')#line:70
REALSAVE =wiz .getS ('debridlastsave')#line:71
LOGINSAVE =wiz .getS ('loginlastsave')#line:72
INSTALLMETHOD =wiz .getS ('installmethod')#line:73
KEEPTRAKT =wiz .getS ('keeptrakt')#line:74
KEEPREAL =wiz .getS ('keepdebrid')#line:75
KEEPLOGIN =wiz .getS ('keeplogin')#line:76
INSTALLED =wiz .getS ('installed')#line:77
EXTRACT =wiz .getS ('extract')#line:78
EXTERROR =wiz .getS ('errors')#line:79
NOTIFY =wiz .getS ('notify')#line:80
NOTEDISMISS =wiz .getS ('notedismiss')#line:81
NOTEID =wiz .getS ('noteid')#line:82
NOTIFY2 =wiz .getS ('notify2')#line:83
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:84
NOTEID2 =wiz .getS ('noteid2')#line:85
NOTIFY3 =wiz .getS ('notify3')#line:86
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:87
NOTEID3 =wiz .getS ('noteid3')#line:88
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:89
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:90
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:91
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:92
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:93
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:94
TODAY =date .today ()#line:95
TOMORROW =TODAY +timedelta (days =1 )#line:96
TWODAYS =TODAY +timedelta (days =2 )#line:97
THREEDAYS =TODAY +timedelta (days =3 )#line:98
ONEWEEK =TODAY +timedelta (days =7 )#line:99
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:100
EXCLUDES =uservar .EXCLUDES #line:101
SPEEDFILE =speedtest .SPEEDFILE #line:102
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:103
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:104
NOTIFICATION =uservar .NOTIFICATION #line:105
NOTIFICATION2 =uservar .NOTIFICATION2 #line:106
NOTIFICATION3 =uservar .NOTIFICATION3 #line:107
ENABLE =uservar .ENABLE #line:108
UNAME =speedtest .UNAME #line:109
HEADERMESSAGE =uservar .HEADERMESSAGE #line:110
AUTOUPDATE =uservar .AUTOUPDATE #line:111
WIZARDFILE =uservar .WIZARDFILE #line:112
AUTOINSTALL =uservar .AUTOINSTALL #line:113
REPOID =uservar .REPOID #line:114
REPOADDONXML =uservar .REPOADDONXML #line:115
REPOZIPURL =uservar .REPOZIPURL #line:116
REPOID18 =uservar .REPOID18 #line:117
REPOADDONXML18 =uservar .REPOADDONXML18 #line:118
REPOZIPURL18 =uservar .REPOZIPURL18 #line:119
REQUESTSID =uservar .REQUESTSID #line:121
REQUESTSXML =uservar .REQUESTSXML #line:122
REQUESTSURL =uservar .REQUESTSURL #line:123
COLOR1 =uservar .COLOR1 #line:127
COLOR2 =uservar .COLOR2 #line:128
TMDB_NEW_API =uservar .TMDB_NEW_API #line:129
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:130
FAILED =False #line:131
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:132
AddonID ='plugin.program.Anonymous'#line:134
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:135
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:136
telecach =xbmc .translatePath ('special://home/userdata/addon_data/plugin.video.telemedia/logo')#line:137
dialog =xbmcgui .Dialog ()#line:138
setting =xbmcaddon .Addon ().getSetting #line:139
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:140
notify_mode =setting ('notify_mode')#line:141
auto_clean =setting ('startup.cache')#line:142
filesize_thumb =int (setting ('filesizethumb_alert'))#line:144
filesize_tele =int (setting ('filesizetele_alert'))#line:145
total_size2 =0 #line:148
total_size =0 #line:149
count =0 #line:150
def infobuild ():#line:161
	O0O0O0000OO00OO00 =wiz .workingURL (NOTIFICATION )#line:162
	if O0O0O0000OO00OO00 ==True :#line:163
		try :#line:164
			O0OOOO0000OOOOOOO ,OO00OOO0O000000O0 =wiz .splitNotify (NOTIFICATION )#line:165
			if O0OOOO0000OOOOOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:166
			if STARTP2 ()=='ok':#line:167
				notify .updateinfo (OO00OOO0O000000O0 ,True )#line:168
		except Exception as O0O0OOO0O00000O0O :#line:169
			wiz .log ("Error on Notifications Window: %s"%str (O0O0OOO0O00000O0O ),xbmc .LOGERROR )#line:170
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:171
def disply_hwr ():#line:172
   try :#line:173
    OOOOOOO0000O0O0O0 =tmdb_list (TMDB_NEW_API )#line:174
    O0OOO0O0O00000O0O =str ((getHwAddr ('eth0'))*OOOOOOO0000O0O0O0 )#line:175
    O0OO0OO0O0O0OOOO0 =(O0OOO0O0O00000O0O [1 ]+O0OOO0O0O00000O0O [2 ]+O0OOO0O0O00000O0O [5 ]+O0OOO0O0O00000O0O [7 ])#line:182
    OOOOOO00O0OO00OOO =(ADDON .getSetting ("action"))#line:183
    wiz .setS ('action',str (O0OO0OO0O0O0OOOO0 ))#line:185
   except :pass #line:186
def getHwAddr (O0O000O00O0O000OO ):#line:187
   import subprocess ,time #line:188
   OOO0OOOOO000000O0 ='windows'#line:189
   if xbmc .getCondVisibility ('system.platform.android'):#line:190
       OOO0OOOOO000000O0 ='android'#line:191
   if xbmc .getCondVisibility ('system.platform.android'):#line:192
     OO000OO000000O0O0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:193
     O0OO0O0OO0OO0OOO0 =re .compile ('link/ether (.+?) brd').findall (str (OO000OO000000O0O0 ))#line:195
     OOO00000OO000OO00 =0 #line:196
     for O00O0OOO00OO0000O in O0OO0O0OO0OO0OOO0 :#line:197
      if O0OO0O0OO0OO0OOO0 !='00:00:00:00:00:00':#line:198
          O0OO00OOO0O000O0O =O00O0OOO00OO0000O #line:199
          OOO00000OO000OO00 =OOO00000OO000OO00 +int (O0OO00OOO0O000O0O .replace (':',''),16 )#line:200
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:202
       OOOOOOOOOO00O0OO0 =0 #line:203
       OOO00000OO000OO00 =0 #line:204
       OOOO00OOO000O0000 =[]#line:205
       O0OOO0OOO00OOOOO0 =os .popen ("getmac").read ()#line:206
       O0OOO0OOO00OOOOO0 =O0OOO0OOO00OOOOO0 .split ("\n")#line:207
       for O0OOOO0OOOO0O0000 in O0OOO0OOO00OOOOO0 :#line:209
            O00O00OOO00O0O0O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OOOO0OOOO0O0000 ,re .I )#line:210
            if O00O00OOO00O0O0O0 :#line:211
                O0OO0O0OO0OO0OOO0 =O00O00OOO00O0O0O0 .group ().replace ('-',':')#line:212
                OOOO00OOO000O0000 .append (O0OO0O0OO0OO0OOO0 )#line:213
                OOO00000OO000OO00 =OOO00000OO000OO00 +int (O0OO0O0OO0OO0OOO0 .replace (':',''),16 )#line:216
   else :#line:218
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:219
   try :#line:236
    return OOO00000OO000OO00 #line:237
   except :pass #line:238
def decode (OOO00OOOO0000O00O ,O0O000O0OO00OOOOO ):#line:239
    import base64 #line:240
    OOOO0OOO0000OO0OO =[]#line:241
    if (len (OOO00OOOO0000O00O ))!=4 :#line:243
     return 10 #line:244
    O0O000O0OO00OOOOO =base64 .urlsafe_b64decode (O0O000O0OO00OOOOO )#line:245
    for OO0O0OOOOO0OOOO0O in range (len (O0O000O0OO00OOOOO )):#line:247
        OOOOOO0OOO0OO000O =OOO00OOOO0000O00O [OO0O0OOOOO0OOOO0O %len (OOO00OOOO0000O00O )]#line:248
        O000OO0O0OOO00O00 =chr ((256 +ord (O0O000O0OO00OOOOO [OO0O0OOOOO0OOOO0O ])-ord (OOOOOO0OOO0OO000O ))%256 )#line:249
        OOOO0OOO0000OO0OO .append (O000OO0O0OOO00O00 )#line:250
    return "".join (OOOO0OOO0000OO0OO )#line:251
def tmdb_list (O00O000O0O000OOOO ):#line:252
    O0O00O0000O0OO00O =decode ("7643",O00O000O0O000OOOO )#line:255
    return int (O0O00O0000O0OO00O )#line:258
def u_list (OOOOOOOOO00O0OO00 ):#line:259
    from math import sqrt #line:261
    OO0O00OOO00000O00 =tmdb_list (TMDB_NEW_API )#line:262
    OO00O00O0O00000O0 =str ((getHwAddr ('eth0'))*OO0O00OOO00000O00 )#line:264
    OO0OOOOOO0O0O0O00 =int (OO00O00O0O00000O0 [1 ]+OO00O00O0O00000O0 [2 ]+OO00O00O0O00000O0 [5 ]+OO00O00O0O00000O0 [7 ])#line:265
    OOO0O0O0000O000O0 =(ADDON .getSetting ("pass"))#line:267
    OO0O00000O0O0OO00 =(str (round (sqrt ((OO0OOOOOO0O0O0O00 *500 )+30 )+30 ,4 ))[-4 :]).replace ('.','')#line:272
    if '.'in OO0O00000O0O0OO00 :#line:273
     OO0O00000O0O0OO00 =(str (round (sqrt ((OO0OOOOOO0O0O0O00 *500 )+30 )+30 ,4 ))[-5 :]).replace ('.','')#line:274
    if OOO0O0O0000O000O0 ==OO0O00000O0O0OO00 :#line:275
      OOOOOO0000OO0OO00 =OOOOOOOOO00O0OO00 #line:277
    else :#line:279
       if STARTP ()and STARTP2 ()=='ok':#line:280
         return OOOOOOOOO00O0OO00 #line:282
       OOOOOO0000OO0OO00 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:283
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:284
       sys .exit ()#line:285
    return OOOOOO0000OO0OO00 #line:286
try :#line:287
   disply_hwr ()#line:288
except :#line:289
   pass #line:290
def dis_or_enable_addon (O0O0OOOO00O0O0O00 ,OOOOO000OOO0OO00O ,enable ="true"):#line:291
    import json #line:292
    OO000OOO0O0O0O0O0 ='"%s"'%O0O0OOOO00O0O0O00 #line:293
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0OOOO00O0O0O00 )and enable =="true":#line:294
        logging .warning ('already Enabled')#line:295
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0O0OOOO00O0O0O00 )#line:296
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0OOOO00O0O0O00 )and enable =="false":#line:297
        return xbmc .log ("### Skipped %s, reason = not installed"%O0O0OOOO00O0O0O00 )#line:298
    else :#line:299
        O00000OOOO0OOO0O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO000OOO0O0O0O0O0 ,enable )#line:300
        O0O0OO0O0OO0OOOOO =xbmc .executeJSONRPC (O00000OOOO0OOO0O0 )#line:301
        O0OO0O0O0O000OOO0 =json .loads (O0O0OO0O0OO0OOOOO )#line:302
        if enable =="true":#line:303
            xbmc .log ("### Enabled %s, response = %s"%(O0O0OOOO00O0O0O00 ,O0OO0O0O0O000OOO0 ))#line:304
        else :#line:305
            xbmc .log ("### Disabled %s, response = %s"%(O0O0OOOO00O0O0O00 ,O0OO0O0O0O000OOO0 ))#line:306
    if OOOOO000OOO0OO00O =='auto':#line:307
     return True #line:308
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:309
def update_Votes ():#line:310
   try :#line:311
        import requests #line:312
        OO000OO00OOOOOO0O ='18773068'#line:313
        OOOO0O0O000000O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO000OO00OOOOOO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:325
        OOO00OO0O00OO0000 ='145273321'#line:327
        O0OO0O000OOO00O0O ={'options':OOO00OO0O00OO0000 }#line:333
        OOO0000OOO0O0O000 =requests .post ('https://www.strawpoll.me/'+OO000OO00OOOOOO0O ,headers =OOOO0O0O000000O0O ,data =O0OO0O000OOO00O0O )#line:335
   except :pass #line:336
def display_Votes ():#line:337
    try :#line:338
        O0OOO00O00O0OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:339
        O00O00OO000000OOO =open (O0OOO00O00O0OO0OO ,'r')#line:341
        O0O000O0O0O000OO0 =O00O00OO000000OOO .read ()#line:342
        O00O00OO000000OOO .close ()#line:343
        OO0OO0O000OOOOO00 ='<setting id="HomeS" type="string">(.+?)</setting>'#line:344
        O0O0O00O0000O0OO0 =re .compile (OO0OO0O000OOOOO00 ).findall (O0O000O0O0O000OO0 )[0 ]#line:346
        import requests #line:352
        O0O0000O0O0OO00OO ='18782966'#line:353
        O0O0OO0OOO00O0000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0000O0O0OO00OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:365
        OOO0OOO00OOOO0O0O ='145313053'#line:367
        OO000OO000O00OOOO ='145313054'#line:368
        O0O000000000O0OOO ='145313057'#line:369
        O0O00OOOO0O00000O ='145313058'#line:370
        OOO0O0OO00O00OO0O ='145313055'#line:371
        OOOO0O000OOO00000 ='145313060'#line:372
        O00OO0O0OOOOO0000 ='145313056'#line:373
        O0O0O000O0OOOO00O ='145313059'#line:374
        if O0O0O00O0000O0OO0 =='emin':#line:377
           O0OO00OO000000O0O =OOO0OOO00OOOO0O0O #line:378
        if O0O0O00O0000O0OO0 =='nox':#line:379
           O0OO00OO000000O0O =OO000OO000O00OOOO #line:380
        if O0O0O00O0000O0OO0 =='noxtitan':#line:381
           O0OO00OO000000O0O =OO000OO000O00OOOO #line:382
        if O0O0O00O0000O0OO0 =='titan':#line:383
           O0OO00OO000000O0O =O0O000000000O0OOO #line:384
        if O0O0O00O0000O0OO0 =='pheno':#line:385
           O0OO00OO000000O0O =O0O00OOOO0O00000O #line:386
        if O0O0O00O0000O0OO0 =='netflix':#line:387
           O0OO00OO000000O0O =OOO0O0OO00O00OO0O #line:388
        if O0O0O00O0000O0OO0 =='nebula':#line:389
           O0OO00OO000000O0O =OOOO0O000OOO00000 #line:390
        if O0O0O00O0000O0OO0 =='pellucid':#line:391
           O0OO00OO000000O0O =O00OO0O0OOOOO0000 #line:392
        if O0O0O00O0000O0OO0 =='pellucid2':#line:393
           O0OO00OO000000O0O =O0O0O000O0OOOO00O #line:394
        OO0OO00OO000O00OO ={'options':O0OO00OO000000O0O }#line:400
        O00OOOOOOOO00OO0O =requests .post ('https://www.strawpoll.me/'+O0O0000O0O0OO00OO ,headers =O0O0OO0OOO00O0000 ,data =OO0OO00OO000O00OO )#line:402
    except :pass #line:403
def resetkodi ():#line:404
		if xbmc .getCondVisibility ('system.platform.windows'):#line:405
			OOOO000OO00O0000O =xbmcgui .DialogProgress ()#line:406
			OOOO000OO00O0000O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:409
			OOOO000OO00O0000O .update (0 )#line:410
			for O000OO00OOOOO0OO0 in range (5 ,-1 ,-1 ):#line:411
				time .sleep (1 )#line:412
				OOOO000OO00O0000O .update (int ((5 -O000OO00OOOOO0OO0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O000OO00OOOOO0OO0 ),'')#line:413
				if OOOO000OO00O0000O .iscanceled ():#line:414
					from resources .libs import win #line:415
					return None ,None #line:416
			from resources .libs import win #line:417
		else :#line:418
			OOOO000OO00O0000O =xbmcgui .DialogProgress ()#line:419
			OOOO000OO00O0000O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:422
			OOOO000OO00O0000O .update (0 )#line:423
			for O000OO00OOOOO0OO0 in range (5 ,-1 ,-1 ):#line:424
				time .sleep (1 )#line:425
				OOOO000OO00O0000O .update (int ((5 -O000OO00OOOOO0OO0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O000OO00OOOOO0OO0 ),'')#line:426
				if OOOO000OO00O0000O .iscanceled ():#line:427
					os ._exit (1 )#line:428
					return None ,None #line:429
			os ._exit (1 )#line:430
def indicatorfastupdate ():#line:431
       try :#line:432
          import json #line:433
          wiz .log ('FRESH MESSAGE')#line:434
          O0O000OOO00000O0O =(ADDON .getSetting ("user"))#line:435
          O00OOO0O00OOOO000 =(ADDON .getSetting ("pass"))#line:436
          O0OOOOO0O0O000OO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:437
          O0O0OO00O00O00O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:439
          O000O00OO000OOO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:440
          OO000O00OO0O0OOOO =str (json .loads (O000O00OO000OOO00 )['ip'])#line:441
          OO0O00OO0O00O0000 =O0O000OOO00000O0O #line:442
          OOO0O0OOO000OOO00 =O00OOO0O00OOOO000 #line:443
          import socket #line:444
          O000O00OO000OOO00 =urllib2 .urlopen (O0O0OO00O00O00O00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO0O00OO0O00O0000 +' - '+OOO0O0OOO000OOO00 +' - '+O0OOOOO0O0O000OO0 +' - '+OO000O00OO0O0OOOO ).readlines ()#line:445
       except :pass #line:447
def skindialogsettind18 ():#line:448
	try :#line:449
		O0O0000OO00OO00O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:450
		O0O00OO0O0OOO0OO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:451
		copyfile (O0O0000OO00OO00O0 ,O0O00OO0O0OOO0OO0 )#line:452
	except :pass #line:453
def telemedia_android5fix ():#line:454
    OO0OO0OO0000O00OO =ADDON .getSetting ('systemtype')#line:455
    OOO0OOOOO00OO0000 =ADDON .getSetting ('teleandro')#line:456
    if xbmc .getCondVisibility ('system.platform.android')and 'Android 5'in OO0OO0OO0000O00OO or OOO0OOOOO00OO0000 =='true':#line:457
        O00O00O0OO0OO0O00 ='https://github.com/kodianonymous1/build/blob/master/tele.zip?raw=true'#line:459
        OO000O00OOOOO00O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:460
        O00O0000O00OO000O =xbmcgui .DialogProgress ()#line:461
        O00O0000O00OO000O .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]" '','אנא המתן')#line:462
        OO0OO000O0OO0OOOO =os .path .join (PACKAGES ,'isr.zip')#line:463
        OOOOO0OO00O0000O0 =urllib2 .Request (O00O00O0OO0OO0O00 )#line:464
        O0O0OOO0O0O0OOO0O =urllib2 .urlopen (OOOOO0OO00O0000O0 )#line:465
        O0OOOO0O00OO0O0O0 =xbmcgui .DialogProgress ()#line:467
        O0OOOO0O00OO0O0O0 .create ("[B][COLOR=yellow]מתאים את ההרחבה טלמדיה למערכת ההפעלה שלך[/COLOR][/B]","[B][COLOR=green]מוריד....[/COLOR][/B]")#line:468
        O0OOOO0O00OO0O0O0 .update (0 )#line:469
        O0OOOO0000OOO0O0O =open (OO0OO000O0OO0OOOO ,'wb')#line:471
        try :#line:473
          OOOO0OOOOO0O00OO0 =O0O0OOO0O0O0OOO0O .info ().getheader ('Content-Length').strip ()#line:474
          O00O0000O0O000O0O =True #line:475
        except AttributeError :#line:476
              O00O0000O0O000O0O =False #line:477
        if O00O0000O0O000O0O :#line:479
              OOOO0OOOOO0O00OO0 =int (OOOO0OOOOO0O00OO0 )#line:480
        O0000OO0OOOO000OO =0 #line:482
        O00O00O0O000O00OO =time .time ()#line:483
        while True :#line:484
              OO00O00000O0OO000 =O0O0OOO0O0O0OOO0O .read (8192 )#line:485
              if not OO00O00000O0OO000 :#line:486
                  sys .stdout .write ('\n')#line:487
                  break #line:488
              O0000OO0OOOO000OO +=len (OO00O00000O0OO000 )#line:490
              O0OOOO0000OOO0O0O .write (OO00O00000O0OO000 )#line:491
              if not O00O0000O0O000O0O :#line:493
                  OOOO0OOOOO0O00OO0 =O0000OO0OOOO000OO #line:494
              if O0OOOO0O00OO0O0O0 .iscanceled ():#line:495
                 O0OOOO0O00OO0O0O0 .close ()#line:496
                 try :#line:497
                  os .remove (OO0OO000O0OO0OOOO )#line:498
                 except :#line:499
                  pass #line:500
                 break #line:501
              O0O00OOO0000O00OO =float (O0000OO0OOOO000OO )/OOOO0OOOOO0O00OO0 #line:502
              O0O00OOO0000O00OO =round (O0O00OOO0000O00OO *100 ,2 )#line:503
              OOO0000OO0O000OOO =O0000OO0OOOO000OO /(1024 *1024 )#line:504
              OO0O0000O0OO0OOO0 =OOOO0OOOOO0O00OO0 /(1024 *1024 )#line:505
              O0O00OOO00OOO00O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0000OO0O000OOO ,'teal',OO0O0000O0OO0OOO0 )#line:506
              if (time .time ()-O00O00O0O000O00OO )>0 :#line:507
                O0000OO00O00OOO0O =O0000OO0OOOO000OO /(time .time ()-O00O00O0O000O00OO )#line:508
                O0000OO00O00OOO0O =O0000OO00O00OOO0O /1024 #line:509
              else :#line:510
               O0000OO00O00OOO0O =0 #line:511
              OO000O00OO00O0O0O ='KB'#line:512
              if O0000OO00O00OOO0O >=1024 :#line:513
                 O0000OO00O00OOO0O =O0000OO00O00OOO0O /1024 #line:514
                 OO000O00OO00O0O0O ='MB'#line:515
              if O0000OO00O00OOO0O >0 and not O0O00OOO0000O00OO ==100 :#line:516
                  O0O0O0000O0O0O0OO =(OOOO0OOOOO0O00OO0 -O0000OO0OOOO000OO )/O0000OO00O00OOO0O #line:517
              else :#line:518
                  O0O0O0000O0O0O0OO =0 #line:519
              OO0OO000O0000O000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0000OO00O00OOO0O ,OO000O00OO00O0O0O )#line:520
              O0OOOO0O00OO0O0O0 .update (int (O0O00OOO0000O00OO ),O0O00OOO00OOO00O0 ,OO0OO000O0000O000 +"[B][COLOR=green]מוריד.... [/COLOR][/B]")#line:522
        O00OOO0OOO00O0OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:525
        O0OOOO0000OOO0O0O .close ()#line:528
        extract .all (OO0OO000O0OO0OOOO ,O00OOO0OOO00O0OOO ,O0OOOO0O00OO0O0O0 )#line:529
        try :#line:533
          os .remove (OO0OO000O0OO0OOOO )#line:534
        except :#line:535
          pass #line:536
def checkidupdate ():#line:537
				O0000O0O00O000O0O =True #line:538
				wiz .setS ("notedismiss","true")#line:539
				OOOO0O0O0O0O0O0O0 =wiz .workingURL (NOTIFICATION )#line:540
				O0OO0O0O00O0OOO0O =" Kodi Premium"#line:542
				O0OOO0O00O00O0OOO =wiz .checkBuild (O0OO0O0O00O0OOO0O ,'gui')#line:543
				OOO0OOO00O00OO0OO =O0OO0O0O00O0OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:544
				if not wiz .workingURL (O0OOO0O00O00O0OOO )==True :return #line:545
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:546
				OOO0OOOOOO0OO00O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0OOO00O00OO0OO )#line:549
				try :os .remove (OOO0OOOOOO0OO00O0 )#line:550
				except :pass #line:551
				if 'google'in O0OOO0O00O00O0OOO :#line:553
				   OO00O00O0000OOO00 =googledrive_download (O0OOO0O00O00O0OOO ,OOO0OOOOOO0OO00O0 ,DP2 ,wiz .checkBuild (O0OO0O0O00O0OOO0O ,'filesize'))#line:554
				else :#line:557
				  downloaderbg .download3 (O0OOO0O00O00O0OOO ,OOO0OOOOOO0OO00O0 ,DP2 )#line:558
				xbmc .sleep (100 )#line:559
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:560
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:562
				extract .all2 (OOO0OOOOOO0OO00O0 ,HOME ,DP2 )#line:564
				DP2 .close ()#line:565
				wiz .defaultSkin ()#line:566
				wiz .lookandFeelData ('save')#line:567
				try :#line:568
					telemedia_android5fix ()#line:569
				except :pass #line:570
				wiz .kodi17Fix ()#line:571
				if KODIV >=18 :#line:572
					skindialogsettind18 ()#line:573
				debridit .debridIt ('restore','all')#line:578
				traktit .traktIt ('restore','all')#line:579
				if INSTALLMETHOD ==1 :O00OO0O0OO0O000OO =1 #line:580
				elif INSTALLMETHOD ==2 :O00OO0O0OO0O000OO =0 #line:581
				else :DP2 .close ()#line:582
				O000O00O0O0OO0000 =(NOTIFICATION2 )#line:583
				OOOO0OOO0O0O00OO0 =urllib2 .urlopen (O000O00O0O0OO0000 )#line:584
				O0OO00000OOO0000O =OOOO0OOO0O0O00OO0 .readlines ()#line:585
				OOOO000OOO00OO0OO =0 #line:586
				for OO000OOOOOO0OOO00 in O0OO00000OOO0000O :#line:589
					if OO000OOOOOO0OOO00 .split (' ==')[0 ]=="noreset"or OO000OOOOOO0OOO00 .split ()[0 ]=="noreset":#line:590
						xbmc .executebuiltin ("ReloadSkin()")#line:592
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:593
						OO0O00OOOO0000000 =(ADDON .getSetting ("message"))#line:594
						if OO0O00OOOO0000000 =='true':#line:595
							infobuild ()#line:596
						update_Votes ()#line:597
						indicatorfastupdate ()#line:598
					if OO000OOOOOO0OOO00 .split (' ==')[0 ]=="reset"or OO000OOOOOO0OOO00 .split ()[0 ]=="reset":#line:599
						update_Votes ()#line:601
						indicatorfastupdate ()#line:602
						resetkodi ()#line:603
def checkvictory ():#line:604
				wiz .setS ("notedismiss2","true")#line:606
				O0O00O0000OOOO00O =wiz .workingURL (NOTIFICATION2 )#line:607
				OO0OO00000O0OOOOO =" Kodi Premium"#line:609
				O0OO0OOOO00OOO00O ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:610
				O00000O0O0OO00000 =OO0OO00000O0OOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:611
				if not wiz .workingURL (O0OO0OOOO00OOO00O )==True :return #line:612
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:613
				OO0OOO000O0OOO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00000O0O0OO00000 )#line:616
				try :os .remove (OO0OOO000O0OOO00O )#line:617
				except :pass #line:618
				if 'google'in O0OO0OOOO00OOO00O :#line:620
				   O0O0OO00O00O0O0O0 =googledrive_download (O0OO0OOOO00OOO00O ,OO0OOO000O0OOO00O ,DP2 ,wiz .checkBuild (OO0OO00000O0OOOOO ,'filesize'))#line:621
				else :#line:624
				  downloaderbg .download5 (O0OO0OOOO00OOO00O ,OO0OOO000O0OOO00O ,DP2 )#line:625
				xbmc .sleep (100 )#line:626
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:627
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:629
				extract .all2 (OO0OOO000O0OOO00O ,ADDONS ,DP2 )#line:631
				DP2 .close ()#line:632
				wiz .defaultSkin ()#line:633
				wiz .lookandFeelData ('save')#line:634
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:635
				if INSTALLMETHOD ==1 :OO0000OOOOO00OO00 =1 #line:637
				elif INSTALLMETHOD ==2 :OO0000OOOOO00OO00 =0 #line:638
				else :DP2 .close ()#line:639
def checkUpdate ():#line:644
	OOO00O00O0O0O0O0O =wiz .getS ('buildname')#line:645
	O0O0O0O0OO00O0000 =wiz .getS ('buildversion')#line:646
	OO0000OO00OO00O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:647
	O0000O00O000OO0OO =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOO00O00O0O0O0O0O ).findall (OO0000OO00OO00O00 )#line:648
	if len (O0000O00O000OO0OO )>0 :#line:649
		OOOO0O000OOO0000O =O0000O00O000OO0OO [0 ][0 ]#line:650
		OOOOOOO0OO0000O00 =O0000O00O000OO0OO [0 ][1 ]#line:651
		O0OOO0OO0OO0OO0O0 =O0000O00O000OO0OO [0 ][2 ]#line:652
		wiz .setS ('latestversion',OOOO0O000OOO0000O )#line:653
		if OOOO0O000OOO0000O >O0O0O0O0OO00O0000 :#line:654
			if DISABLEUPDATE =='false':#line:655
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0O0O0O0OO00O0000 ,OOOO0O000OOO0000O ),xbmc .LOGNOTICE )#line:656
				notify .updateWindow (OOO00O00O0O0O0O0O ,O0O0O0O0OO00O0000 ,OOOO0O000OOO0000O ,OOOOOOO0OO0000O00 ,O0OOO0OO0OO0OO0O0 )#line:657
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0O0O0O0OO00O0000 ,OOOO0O000OOO0000O ),xbmc .LOGNOTICE )#line:658
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0O0O0O0OO00O0000 ,OOOO0O000OOO0000O ),xbmc .LOGNOTICE )#line:659
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:660
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:695
if AUTOUPDATE =='Yes':#line:696
	input =(ADDON .getSetting ("autoupdate"))#line:697
	xbmc .executebuiltin ("UpdateLocalAddons")#line:698
	xbmc .executebuiltin ("UpdateAddonRepos")#line:699
	if BUILDNAME ==" Kodi Premium":#line:700
		wiz .wizardUpdate ('startup')#line:701
	if BUILDNAME =="":#line:702
		wiz .wizardUpdateDP ('startup')#line:703
if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'skin.estuary'):#line:707
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:708
    setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")#line:710
    src =os .path .join (xbmc .translatePath ("special://home/"),"addons/skin.estuary")#line:711
    extract .all (setting_file ,src )#line:714
    wiz .kodi17Fix ()#line:726
    if KODIV >=18 :#line:728
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","addon.xml")#line:730
        with open (setting_file ,'r')as file :#line:731
          filedata =file .read ()#line:732
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.12.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''','''<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.estuary" version="9.9.9" name="Estuary" provider-name="phil65, Ichabod Fletchman">
	<requires>
		<!-- <import addon="xbmc.gui" version="5.14.0"/> -->
	</requires>
	<extension point="xbmc.gui.skin" debugging="false" effectslowdown="1.0">
		<res width="1280" height="720" aspect="16:9" default="true" folder="720p" />
	</extension>
	<extension point="xbmc.addon.metadata">

		<platform>all</platform>
		<license>GNU General Public License version 2</license>
		<forum>http://forum.kodi.tv/forumdisplay.php?fid=125</forum>
		<website/>
		<email/>
		<source>https://github.com/xbmc/skin.confluence</source>
		<assets>
			<icon>resources/icon.png</icon>
			<fanart>resources/fanart.jpg</fanart>
		</assets>
		<news>Updated language files</news>
	</extension>
</addon>
''')#line:781
        with open (setting_file ,'w')as file :#line:784
          file .write (filedata )#line:785
        setting_file =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")#line:791
        with open (setting_file ,'r')as file :#line:792
          filedata =file .read ()#line:793
        filedata =filedata .replace ('''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">2</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="-" />
			<param name="DialogHeaderId" value="20" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="99">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>9</onleft>
			<onright>9</onright>
			<onup>2</onup>
			<ondown>2</ondown>
		</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(9).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(9).HasNext</visible>
		</control>
		<control type="grouplist" id="2">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>9</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="10">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>12</onleft>
				<onright>11</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
			<control type="button" id="11">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>10</onleft>
				<onright>12</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="13">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="3">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="4">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="5">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="7">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="6">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="8">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''','''<?xml version="1.0" encoding="UTF-8"?>
<window>
	<defaultcontrol always="true">5</defaultcontrol>
	<coordinates>
		<left>240</left>
		<top>60</top>
	</coordinates>
	<include>dialogeffect</include>
	<controls>
		<include content="DialogBackgroundCommons">
			<param name="DialogBackgroundWidth" value="800" />
			<param name="DialogBackgroundHeight" value="600" />
			<param name="DialogHeaderWidth" value="720" />
			<param name="DialogHeaderLabel" value="" />
			<param name="DialogHeaderId" value="2" />
			<param name="CloseButtonLeft" value="710" />
			<param name="CloseButtonNav" value="3" />
		</include>
		<control type="grouplist" id="3">
			<description>button area</description>
			<left>45</left>
			<top>70</top>
			<width>710</width>
			<height>40</height>
			<itemgap>5</itemgap>
			<align>center</align>
			<orientation>horizontal</orientation>
			<onleft>3</onleft>
			<onright>3</onright>
			<onup>5</onup>
			<ondown>5</ondown>
		</control>
			<control type="button" id="10">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
			</control>
		<control type="image">
			<description>Has Previous</description>
			<left>25</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-left-focus.png</texture>
			<visible>Container(3).HasPrevious</visible>
		</control>
		<control type="image">
			<description>Has Next</description>
			<left>755</left>
			<top>80</top>
			<width>20</width>
			<height>20</height>
			<texture>scroll-right-focus.png</texture>
			<visible>Container(3).HasNext</visible>
		</control>
		<control type="grouplist" id="5">
			<description>control area</description>
			<left>40</left>
			<top>120</top>
			<width>720</width>
			<height>380</height>
			<itemgap>5</itemgap>
			<pagecontrol>30</pagecontrol>
			<onup>3</onup>
			<ondown>9001</ondown>
			<onleft>2</onleft>
			<onright>30</onright>
		</control>
		<control type="scrollbar" id="30">
			<left>765</left>
			<top>120</top>
			<width>25</width>
			<height>380</height>
			<texturesliderbackground border="0,14,0,14">ScrollBarV.png</texturesliderbackground>
			<texturesliderbar border="2,16,2,16">ScrollBarV_bar.png</texturesliderbar>
			<texturesliderbarfocus border="2,16,2,16">ScrollBarV_bar_focus.png</texturesliderbarfocus>
			<textureslidernib>ScrollBarNib.png</textureslidernib>
			<textureslidernibfocus>ScrollBarNib.png</textureslidernibfocus>
			<onleft>2</onleft>
			<onright>2</onright>
			<showonepage>false</showonepage>
			<orientation>vertical</orientation>
		</control>
		<control type="group" id="9001">
			<top>535</top>
			<left>190</left>
			<control type="button" id="28">
				<description>OK Button</description>
				<left>0</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>186</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
			<control type="button" id="29">
				<description>Cancel Button</description>
				<left>210</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>222</label>
				<onleft>28</onleft>
				<onright>29</onright>
				<onup>5</onup>
				<ondown>5</ondown>
			</control>
<!-- 			<control type="button" id="12">
				<description>Defaults Button</description>
				<left>420</left>
				<top>0</top>
				<width>200</width>
				<height>40</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font12_title</font>
				<label>409</label>
				<onleft>11</onleft>
				<onright>10</onright>
				<onup>2</onup>
				<ondown>2</ondown>
			</control> -->
		</control>
		<control type="button" id="10">
			<description>Default Category Button</description>
			<height>40</height>
			<width>173</width>
			<align>center</align>
			<aligny>center</aligny>
			<font>font12_title</font>
			<textcolor>white</textcolor>
			<pulseonselect>false</pulseonselect>
		</control>
		<control type="button" id="7">
			<description>Default Button</description>
			<height>40</height>
			<font>font13</font>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="radiobutton" id="8">
			<description>Default RadioButton</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>668</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
		<control type="spincontrolex" id="9">
			<description>Default spincontrolex</description>
			<height>40</height>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturenofocus border="5">button-nofocus.png</texturenofocus>
			<texturefocus border="5">button-focus2.png</texturefocus>
			<font>font13</font>
			<aligny>center</aligny>
			<reverse>yes</reverse>
		</control>
		<control type="label" id="14">
			<height>35</height>
			<font>font13_title</font>
			<label>-</label>
			<textcolor>blue</textcolor>
			<shadowcolor>black</shadowcolor>
			<align>right</align>
			<aligny>center</aligny>
		</control>
		<control type="image" id="11">
			<description>Default Seperator</description>
			<height>2</height>
			<texture>separator2.png</texture>
		</control>
		<control type="sliderex" id="13">
			<description>Default Slider</description>
			<height>40</height>
			<font>font13</font>
			<textwidth>518</textwidth>
			<textcolor>grey2</textcolor>
			<focusedcolor>white</focusedcolor>
			<texturefocus border="5">button-focus2.png</texturefocus>
		</control>
	</controls>
</window>
''')#line:1184
        with open (setting_file ,'w')as file :#line:1187
          file .write (filedata )#line:1188
    wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:1196
    xbmc .executebuiltin ("ReloadSkin()")#line:1197
    xbmc .executebuiltin ("ActivateWindow(home)")#line:1198
    f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:1199
    xbmc .Player ().play (f_play ,windowed =False )#line:1200
def setuname ():#line:1337
    O0OOO0O0O0O0O0OO0 =''#line:1338
    O0O00000OOOOO00O0 =xbmc .Keyboard (O0OOO0O0O0O0O0OO0 ,'הכנס שם משתמש')#line:1339
    O0O00000OOOOO00O0 .doModal ()#line:1340
    if O0O00000OOOOO00O0 .isConfirmed ():#line:1341
           O0OOO0O0O0O0O0OO0 =O0O00000OOOOO00O0 .getText ()#line:1342
           wiz .setS ('user',str (O0OOO0O0O0O0O0OO0 ))#line:1343
def STARTP2 ():#line:1344
	if BUILDNAME ==" Kodi Premium":#line:1345
		OOO000O0000O00O00 =(ADDON .getSetting ("user"))#line:1346
		OOO0OOO00OOOO0OOO =(UNAME )#line:1347
		O0000000O0OO00O0O =urllib2 .urlopen (OOO0OOO00OOOO0OOO )#line:1348
		OOO00OOOOO0OO0O0O =O0000000O0OO00O0O .readlines ()#line:1349
		OO0OOOOO00O0O0OO0 =0 #line:1350
		for O0O0OOOOO0OO0OOO0 in OOO00OOOOO0OO0O0O :#line:1351
			if O0O0OOOOO0OO0OOO0 .split (' ==')[0 ]==OOO000O0000O00O00 or O0O0OOOOO0OO0OOO0 .split ()[0 ]==OOO000O0000O00O00 :#line:1352
				OO0OOOOO00O0O0OO0 =1 #line:1353
				break #line:1354
		if OO0OOOOO00O0O0OO0 ==0 :#line:1355
			O000OOO0OOOOO0O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:1357
			if O000OOO0OOOOO0O0O :#line:1359
				ADDON .openSettings ()#line:1360
				sys .exit ()#line:1361
			else :#line:1362
				sys .exit ()#line:1363
		return 'ok'#line:1367
def skinWIN ():#line:1370
	idle ()#line:1371
	O0000000OOO0O00OO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:1372
	OO00000OOO0OO0O0O =[];OO00O0000OO0OO000 =[]#line:1373
	for O0OOO000O00000O00 in sorted (O0000000OOO0O00OO ,key =lambda O0O0O0OOO000000OO :O0O0O0OOO000000OO ):#line:1374
		OOO00000O00OOOO00 =os .path .split (O0OOO000O00000O00 [:-1 ])[1 ]#line:1375
		O00O000O000OO0OO0 =os .path .join (O0OOO000O00000O00 ,'addon.xml')#line:1376
		if os .path .exists (O00O000O000OO0OO0 ):#line:1377
			OO000OOOO00OO0O0O =open (O00O000O000OO0OO0 )#line:1378
			O0OOO000000OO0O00 =OO000OOOO00OO0O0O .read ()#line:1379
			OO000OO00O00OO00O =parseDOM2 (O0OOO000000OO0O00 ,'addon',ret ='id')#line:1380
			OOOOO00OO0OOOOOOO =OOO00000O00OOOO00 if len (OO000OO00O00OO00O )==0 else OO000OO00O00OO00O [0 ]#line:1381
			try :#line:1382
				O000OOO00O000O0O0 =xbmcaddon .Addon (id =OOOOO00OO0OOOOOOO )#line:1383
				OO00000OOO0OO0O0O .append (O000OOO00O000O0O0 .getAddonInfo ('name'))#line:1384
				OO00O0000OO0OO000 .append (OOOOO00OO0OOOOOOO )#line:1385
			except :#line:1386
				pass #line:1387
	O0OOO0OO00O0OO0O0 =[];O00OO0O0000000O00 =0 #line:1388
	O0OO00O0O0OO0OOO0 =["Current Skin -- %s"%currSkin ()]+OO00000OOO0OO0O0O #line:1389
	O00OO0O0000000O00 =DIALOG .select ("Select the Skin you want to swap with.",O0OO00O0O0OO0OOO0 )#line:1390
	if O00OO0O0000000O00 ==-1 :return #line:1391
	else :#line:1392
		OO0O0OOO0OOO0000O =(O00OO0O0000000O00 -1 )#line:1393
		O0OOO0OO00O0OO0O0 .append (OO0O0OOO0OOO0000O )#line:1394
		O0OO00O0O0OO0OOO0 [O00OO0O0000000O00 ]="%s"%(OO00000OOO0OO0O0O [OO0O0OOO0OOO0000O ])#line:1395
	if O0OOO0OO00O0OO0O0 ==None :return #line:1396
	for OOO0OOO0O0O0000OO in O0OOO0OO00O0OO0O0 :#line:1397
		swapSkins (OO00O0000OO0OO000 [OOO0OOO0O0O0000OO ])#line:1398
def currSkin ():#line:1400
	return xbmc .getSkinDir ('Container.PluginName')#line:1401
def fix17update ():#line:1403
	if KODIV >=17 and KODIV <18 :#line:1404
		wiz .kodi17Fix ()#line:1405
		xbmc .sleep (4000 )#line:1406
		try :#line:1407
			O0O00OO000O00O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1408
			OO000OO000OOO0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1409
			os .rename (O0O00OO000O00O000 ,OO000OO000OOO0OOO )#line:1410
		except :#line:1411
				pass #line:1412
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1413
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1414
		OO000OOOOOOOOOO00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1416
		try :#line:1418
			O00OOO00O00O0O0OO =open (OO000OOOOOOOOOO00 ,'r')#line:1419
			OOOO000O00OO0O00O =O00OOO00O00O0O0OO .read ()#line:1420
			O00OOO00O00O0O0OO .close ()#line:1421
			OOO000OOOO0OOOOOO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:1422
			OO00O00O0O0000OO0 =re .compile (OOO000OOOO0OOOOOO ).findall (OOOO000O00OO0O00O )[0 ]#line:1423
			O00OOO00O00O0O0OO =open (OO000OOOOOOOOOO00 ,'w')#line:1424
			O00OOO00O00O0O0OO .write (OOOO000O00OO0O00O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO00O00O0O0000OO0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:1425
			O00OOO00O00O0O0OO .close ()#line:1426
		except :#line:1427
				pass #line:1428
		wiz .kodi17Fix ()#line:1429
		OO000OOOOOOOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1430
		try :#line:1431
			O00OOO00O00O0O0OO =open (OO000OOOOOOOOOO00 ,'r')#line:1432
			OOOO000O00OO0O00O =O00OOO00O00O0O0OO .read ()#line:1433
			O00OOO00O00O0O0OO .close ()#line:1434
			OOO000OOOO0OOOOOO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:1435
			OO00O00O0O0000OO0 =re .compile (OOO000OOOO0OOOOOO ).findall (OOOO000O00OO0O00O )[0 ]#line:1436
			O00OOO00O00O0O0OO =open (OO000OOOOOOOOOO00 ,'w')#line:1437
			O00OOO00O00O0O0OO .write (OOOO000O00OO0O00O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO00O00O0O0000OO0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:1438
			O00OOO00O00O0O0OO .close ()#line:1439
		except :#line:1440
				pass #line:1441
		swapSkins ('skin.Premium.mod')#line:1442
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1443
	os ._exit (1 )#line:1444
def fix18update ():#line:1445
	if KODIV >=18 :#line:1446
		xbmc .sleep (4000 )#line:1447
		if BUILDNAME =="":#line:1448
			try :#line:1449
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:1450
			except :#line:1451
				pass #line:1452
		try :#line:1453
			O000O0O0OOOO0OOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:1454
			OO0O0OO0OOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:1455
			os .rename (O000O0O0OOOO0OOOO ,OO0O0OO0OOOOOOO0O )#line:1456
		except :#line:1457
				pass #line:1458
		skindialogsettind18 ()#line:1459
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:1460
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:1461
		OOOO0O00O000000OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:1463
		try :#line:1464
			O0O0OOO000OOO00O0 =open (OOOO0O00O000000OO ,'r')#line:1465
			O000OOO00OOO0OO00 =O0O0OOO000OOO00O0 .read ()#line:1466
			O0O0OOO000OOO00O0 .close ()#line:1467
			O0O0000OOO00OO0OO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:1468
			O0O0000OO0OO0OOO0 =re .compile (O0O0000OOO00OO0OO ).findall (O000OOO00OOO0OO00 )[0 ]#line:1469
			O0O0OOO000OOO00O0 =open (OOOO0O00O000000OO ,'w')#line:1470
			O0O0OOO000OOO00O0 .write (O000OOO00OOO0OO00 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O0000OO0OO0OOO0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:1471
			O0O0OOO000OOO00O0 .close ()#line:1472
		except :#line:1473
				pass #line:1474
		wiz .kodi17Fix ()#line:1475
		OOOO0O00O000000OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:1476
		try :#line:1477
			O0O0OOO000OOO00O0 =open (OOOO0O00O000000OO ,'r')#line:1478
			O000OOO00OOO0OO00 =O0O0OOO000OOO00O0 .read ()#line:1479
			O0O0OOO000OOO00O0 .close ()#line:1480
			O0O0000OOO00OO0OO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:1481
			O0O0000OO0OO0OOO0 =re .compile (O0O0000OOO00OO0OO ).findall (O000OOO00OOO0OO00 )[0 ]#line:1482
			O0O0OOO000OOO00O0 =open (OOOO0O00O000000OO ,'w')#line:1483
			O0O0OOO000OOO00O0 .write (O000OOO00OOO0OO00 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O0000OO0OO0OOO0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:1484
			O0O0OOO000OOO00O0 .close ()#line:1485
		except :#line:1486
				pass #line:1487
		swapSkins ('skin.Premium.mod')#line:1488
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:1489
	os ._exit (1 )#line:1490
def swapSkins (O00O00O00OOO0OOO0 ,title ="Error"):#line:1491
	O000O00OO0O00O00O ='lookandfeel.skin'#line:1492
	OOO000O0O0O000O0O =O00O00O00OOO0OOO0 #line:1493
	OOOOO0O0OOO0O0OO0 =getOld (O000O00OO0O00O00O )#line:1494
	OOO0O0O0OOOOOO0OO =O000O00OO0O00O00O #line:1495
	setNew (OOO0O0O0OOOOOO0OO ,OOO000O0O0O000O0O )#line:1496
	O00O0O0OOO0OO000O =0 #line:1497
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O0OOO0OO000O <100 :#line:1498
		O00O0O0OOO0OO000O +=1 #line:1499
		xbmc .sleep (1 )#line:1500
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1501
		xbmc .executebuiltin ('SendClick(11)')#line:1502
	return True #line:1503
def getOld (OO00OOOO00O000OO0 ):#line:1505
	try :#line:1506
		OO00OOOO00O000OO0 ='"%s"'%OO00OOOO00O000OO0 #line:1507
		OO0OO0O0O0OO0OOO0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO00OOOO00O000OO0 )#line:1508
		OO0000O00000OO0OO =xbmc .executeJSONRPC (OO0OO0O0O0OO0OOO0 )#line:1510
		OO0000O00000OO0OO =simplejson .loads (OO0000O00000OO0OO )#line:1511
		if OO0000O00000OO0OO .has_key ('result'):#line:1512
			if OO0000O00000OO0OO ['result'].has_key ('value'):#line:1513
				return OO0000O00000OO0OO ['result']['value']#line:1514
	except :#line:1515
		pass #line:1516
	return None #line:1517
def setNew (OOO000OOOO0000O0O ,O0000O00OOO0O0000 ):#line:1520
	try :#line:1521
		OOO000OOOO0000O0O ='"%s"'%OOO000OOOO0000O0O #line:1522
		O0000O00OOO0O0000 ='"%s"'%O0000O00OOO0O0000 #line:1523
		O0OO0OO00OO00O00O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO000OOOO0000O0O ,O0000O00OOO0O0000 )#line:1524
		OO00OOOOO00O00O0O =xbmc .executeJSONRPC (O0OO0OO00OO00O00O )#line:1526
	except :#line:1527
		pass #line:1528
	return None #line:1529
def idle ():#line:1530
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:1531
def fixfont ():#line:1532
	O0OO000OOO00OOOOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1533
	O0O000OO0OOOO000O =json .loads (O0OO000OOO00OOOOO );#line:1535
	OO0O0OO0OOOOOO00O =O0O000OO0OOOO000O ["result"]["settings"]#line:1536
	OOO0OOO0O00OO0OO0 =[O0OO0O0000O0000O0 for O0OO0O0000O0000O0 in OO0O0OO0OOOOOO00O if O0OO0O0000O0000O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1538
	O0000O0OOO0O000OO =OOO0OOO0O00OO0OO0 ["options"];#line:1539
	OO0000O0OOOOO00OO =OOO0OOO0O00OO0OO0 ["value"];#line:1540
	OO0O0OO0O00OO0000 =[OOOO0O0OO000O0OOO for (OOOO0O0OO000O0OOO ,O00000O0O00O00OO0 )in enumerate (O0000O0OOO0O000OO )if O00000O0O00O00OO0 ["value"]==OO0000O0OOOOO00OO ][0 ];#line:1542
	O0O0O0OO0000O0OOO =(OO0O0OO0O00OO0000 +1 )%len (O0000O0OOO0O000OO )#line:1544
	O00O00OO0O0OO0O0O =O0000O0OOO0O000OO [O0O0O0OO0000O0OOO ]["value"]#line:1546
	O000O000O0O0OOOOO =O0000O0OOO0O000OO [O0O0O0OO0000O0OOO ]["label"]#line:1547
	OOOO0OOOO00O00O00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1549
	try :#line:1551
		OO0OO0OO0O0O00O00 =json .loads (OOOO0OOOO00O00O00 );#line:1552
		if OO0OO0OO0O0O00O00 ["result"]!=True :#line:1554
			raise Exception #line:1555
	except :#line:1556
		sys .stderr .write ("Error switching audio output device")#line:1557
		raise Exception #line:1558
def checkSkin ():#line:1561
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:1562
	O00O0O000O0O0OOO0 =wiz .getS ('defaultskin')#line:1563
	OO000OOO0000OOO00 =wiz .getS ('defaultskinname')#line:1564
	OO000000000OOOO0O =wiz .getS ('defaultskinignore')#line:1565
	OO000O00OO0O0O0O0 =False #line:1566
	if not O00O0O000O0O0OOO0 =='':#line:1567
		if os .path .exists (os .path .join (ADDONS ,O00O0O000O0O0OOO0 )):#line:1568
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO000OOO0000OOO00 )):#line:1569
				OO000O00OO0O0O0O0 =O00O0O000O0O0OOO0 #line:1570
				OOO0000O0OO0OO000 =OO000OOO0000OOO00 #line:1571
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');OO000O00OO0O0O0O0 =False #line:1572
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O00O0O000O0O0OOO0 ='';OO000OOO0000OOO00 =''#line:1573
	if O00O0O000O0O0OOO0 =='':#line:1574
		O0O0O0O0O0000O000 =[]#line:1575
		OO0O0OO0OOOOOO0OO =[]#line:1576
		for O00OOOOOOOO00O0OO in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:1577
			O0O0OO00OO0O000OO ="%s/addon.xml"%O00OOOOOOOO00O0OO #line:1578
			if os .path .exists (O0O0OO00OO0O000OO ):#line:1579
				O00O00O0O000OOO0O =open (O0O0OO00OO0O000OO ,mode ='r');O0O0O000OOOO0O000 =O00O00O0O000OOO0O .read ().replace ('\n','').replace ('\r','').replace ('\t','');O00O00O0O000OOO0O .close ();#line:1580
				OOO0O00OO00O00000 =wiz .parseDOM (O0O0O000OOOO0O000 ,'addon',ret ='id')#line:1581
				OOO0000000OO0OO0O =wiz .parseDOM (O0O0O000OOOO0O000 ,'addon',ret ='name')#line:1582
				wiz .log ("%s: %s"%(O00OOOOOOOO00O0OO ,str (OOO0O00OO00O00000 [0 ])),xbmc .LOGNOTICE )#line:1583
				if len (OOO0O00OO00O00000 )>0 :OO0O0OO0OOOOOO0OO .append (str (OOO0O00OO00O00000 [0 ]));O0O0O0O0O0000O000 .append (str (OOO0000000OO0OO0O [0 ]))#line:1584
				else :wiz .log ("ID not found for %s"%O00OOOOOOOO00O0OO ,xbmc .LOGNOTICE )#line:1585
			else :wiz .log ("ID not found for %s"%O00OOOOOOOO00O0OO ,xbmc .LOGNOTICE )#line:1586
		if len (OO0O0OO0OOOOOO0OO )>0 :#line:1587
			if len (OO0O0OO0OOOOOO0OO )>1 :#line:1588
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:1589
					OO0OO000OO000OO0O =DIALOG .select ("Select skin to switch to!",O0O0O0O0O0000O000 )#line:1590
					if OO0OO000OO000OO0O ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1591
					else :#line:1592
						OO000O00OO0O0O0O0 =OO0O0OO0OOOOOO0OO [OO0OO000OO000OO0O ]#line:1593
						OOO0000O0OO0OO000 =O0O0O0O0O0000O000 [OO0OO000OO000OO0O ]#line:1594
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:1595
	if OO000O00OO0O0O0O0 :#line:1602
		skinSwitch .swapSkins (OO000O00OO0O0O0O0 )#line:1603
		OOOO0OOO00O0OO00O =0 #line:1604
		xbmc .sleep (1000 )#line:1605
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO0OOO00O0OO00O <150 :#line:1606
			OOOO0OOO00O0OO00O +=1 #line:1607
			xbmc .sleep (200 )#line:1608
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1610
			wiz .ebi ('SendClick(11)')#line:1611
			wiz .lookandFeelData ('restore')#line:1612
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1613
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1614
while xbmc .Player ().isPlayingVideo ():#line:1616
	xbmc .sleep (1000 )#line:1617
if KODIV >=17 :#line:1619
	NOW =datetime .now ()#line:1620
	temp =wiz .getS ('kodi17iscrap')#line:1621
	if not temp =='':#line:1622
		if temp >str (NOW -timedelta (minutes =2 )):#line:1623
			wiz .log ("Killing Start Up Script")#line:1624
			sys .exit ()#line:1625
	wiz .log ("%s"%(NOW ))#line:1626
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1627
	xbmc .sleep (1000 )#line:1628
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1629
		wiz .log ("Killing Start Up Script")#line:1630
		sys .exit ()#line:1631
	else :#line:1632
		wiz .log ("Continuing Start Up Script")#line:1633
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1635
path =os .path .split (ADDONPATH )#line:1636
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1637
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1638
if KODIADDONS in ADDONPATH :#line:1641
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1642
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1643
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1644
	if os .path .exists (newpath ):#line:1645
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1646
		wiz .cleanHouse (newpath )#line:1647
		wiz .removeFolder (newpath )#line:1648
	try :#line:1649
		wiz .copytree (ADDONPATH ,newpath )#line:1650
	except Exception as e :#line:1651
		pass #line:1652
	wiz .forceUpdate (True )#line:1653
try :#line:1655
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1656
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1657
except :#line:1658
	pass #line:1659
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1661
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1665
			wiz .kodi17Fix ()#line:1666
			fix18update ()#line:1667
			fix17update ()#line:1668
if INSTALLED =='true':#line:1671
    input =(ADDON .getSetting ("auto_rd"))#line:1672
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1674
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1675
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1676
    wiz .clearS ('install')#line:1677
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1762
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1764
	STARTP2 ()#line:1766
	if not NOTIFY =='true':#line:1767
		url =wiz .workingURL (NOTIFICATION )#line:1768
		if url ==True :#line:1769
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1770
			if not id ==False :#line:1771
				try :#line:1772
					id =int (id );NOTEID =int (NOTEID )#line:1773
					if id ==NOTEID :#line:1774
						if NOTEDISMISS =='false':#line:1775
							debridit .debridIt ('update','all')#line:1776
							traktit .traktIt ('update','all')#line:1777
							checkidupdate ()#line:1778
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1779
					elif id >NOTEID :#line:1780
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1781
						wiz .setS ('noteid',str (id ))#line:1782
						wiz .setS ('notedismiss','false')#line:1783
						debridit .debridIt ('update','all')#line:1785
						traktit .traktIt ('update','all')#line:1786
						checkidupdate ()#line:1787
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1789
				except Exception as e :#line:1790
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1791
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1792
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1793
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1794
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1795
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1797
if ENABLE =='No':#line:1798
	if not NOTIFY2 =='true':#line:1799
		url =wiz .workingURL (NOTIFICATION2 )#line:1800
		if url ==True :#line:1801
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1802
			if not id ==False :#line:1803
				try :#line:1804
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1805
					if id ==NOTEID2 :#line:1806
						if NOTEDISMISS2 =='false':#line:1807
							checkvictory ()#line:1808
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1809
					elif id >NOTEID2 :#line:1810
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1811
						wiz .setS ('noteid2',str (id ))#line:1812
						wiz .setS ('notedismiss2','false')#line:1813
						checkvictory ()#line:1814
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1815
				except Exception as e :#line:1816
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1817
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1818
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1819
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1820
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1821
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1823
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1824
	if not NOTIFY3 =='true':#line:1825
		url =wiz .workingURL (NOTIFICATION3 )#line:1826
		if url ==True :#line:1827
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1828
			if not id ==False :#line:1829
				try :#line:1830
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1831
					if id ==NOTEID3 :#line:1832
						if NOTEDISMISS3 =='false':#line:1833
							notify .notification3 (msg )#line:1834
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1835
					elif id >NOTEID3 :#line:1836
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1837
						wiz .setS ('noteid3',str (id ))#line:1838
						wiz .setS ('notedismiss3','false')#line:1839
						notify .notification3 (msg =msg )#line:1840
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1841
				except Exception as e :#line:1842
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1843
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1844
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1845
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1846
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1847
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1848
if KEEPTRAKT =='true':#line:1849
	if TRAKTSAVE <=str (TODAY ):#line:1850
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1851
		traktit .autoUpdate ('all')#line:1852
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1853
	else :#line:1854
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1855
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1856
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1858
if KEEPREAL =='true':#line:1859
	if REALSAVE <=str (TODAY ):#line:1860
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1861
		debridit .autoUpdate ('all')#line:1862
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1863
	else :#line:1864
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1865
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1866
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1868
if KEEPLOGIN =='true':#line:1869
	if LOGINSAVE <=str (TODAY ):#line:1870
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1871
		loginit .autoUpdate ('all')#line:1872
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1873
	else :#line:1874
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1875
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1876
wiz .clearCache (True )#line:1877
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1878
if AUTOCLEANUP =='false':#line:1879
	service =False #line:1880
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1881
	feq =int (float (AUTOFEQ ))#line:1882
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1883
		service =True #line:1884
		next_run =days [feq ]#line:1885
		wiz .setS ('nextautocleanup',str (next_run ))#line:1886
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1887
	if service ==True :#line:1888
		AUTOCACHE =wiz .getS ('clearcache')#line:1889
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1890
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1891
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1892
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1893
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1894
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1895
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1896
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1897
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1898
wiz .setS ('kodi17iscrap','')#line:1900
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1969
	count =0 #line:1970
	for f in filenames :#line:1971
		count +=1 #line:1972
		fp =os .path .join (dirpath ,f )#line:1973
		total_size +=os .path .getsize (fp )#line:1974
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1975
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1982
	for f2 in filenames2 :#line:1983
		fp2 =os .path .join (dirpath2 ,f2 )#line:1984
		total_size2 +=os .path .getsize (fp2 )#line:1985
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1986
if int (total_sizetext2 )>filesize_thumb :#line:1988
		maintenance .deleteThumbnails ()#line:1990
for dirpath2 ,dirnames2 ,filenames2 in os .walk (telecach ):#line:1994
	for f2 in filenames2 :#line:1995
		fp2 =os .path .join (dirpath2 ,f2 )#line:1996
		total_size2 +=os .path .getsize (fp2 )#line:1997
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1998
if int (total_sizetext2 )>filesize_tele :#line:2000
		maintenance .deleteTele ()#line:2002
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:2007
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:2008
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:2010
time .sleep (3 )#line:2011
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:2013
        display_Votes ()#line:2014
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:2016
        file .write (str ('Done'))#line:2018
        file .close ()#line:2019
tele =(ADDON .getSetting ("auto_tele"))#line:2024
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:2026
    if tele =='true':#line:2028
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:2029
